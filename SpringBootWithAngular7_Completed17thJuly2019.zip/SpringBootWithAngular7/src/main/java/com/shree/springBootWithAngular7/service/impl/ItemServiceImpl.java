package com.shree.springBootWithAngular7.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shree.springBootWithAngular7.dao.ItemDao;
import com.shree.springBootWithAngular7.model.Item;
import com.shree.springBootWithAngular7.service.ItemService;
@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	private ItemDao itemDao;

	@Override
	public List<Item> getAllItems() {
		return itemDao.findAll();
	}

}
