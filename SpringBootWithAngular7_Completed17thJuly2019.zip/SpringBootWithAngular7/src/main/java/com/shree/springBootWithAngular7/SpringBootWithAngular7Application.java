package com.shree.springBootWithAngular7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithAngular7Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithAngular7Application.class, args);
	}

}
