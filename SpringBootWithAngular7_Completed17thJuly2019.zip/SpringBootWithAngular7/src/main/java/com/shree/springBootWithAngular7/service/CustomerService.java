package com.shree.springBootWithAngular7.service;

import java.util.List;

import com.shree.springBootWithAngular7.model.Customer;

public interface CustomerService {
public List<Customer> getAllCustomers();
}
