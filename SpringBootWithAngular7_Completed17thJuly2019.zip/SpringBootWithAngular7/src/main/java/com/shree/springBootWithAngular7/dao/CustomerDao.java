package com.shree.springBootWithAngular7.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shree.springBootWithAngular7.model.Customer;

public interface CustomerDao extends JpaRepository<Customer, Long>{

}
