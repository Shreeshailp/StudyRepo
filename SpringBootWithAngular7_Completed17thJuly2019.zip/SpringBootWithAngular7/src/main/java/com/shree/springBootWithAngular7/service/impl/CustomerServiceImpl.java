package com.shree.springBootWithAngular7.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shree.springBootWithAngular7.dao.CustomerDao;
import com.shree.springBootWithAngular7.model.Customer;
import com.shree.springBootWithAngular7.service.CustomerService;
@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.findAll();
	}

}
