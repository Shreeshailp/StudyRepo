package com.shree.springBootWithAngular7.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shree.springBootWithAngular7.dao.OrderDao;
import com.shree.springBootWithAngular7.model.Order;
import com.shree.springBootWithAngular7.model.OrderItemDto;
import com.shree.springBootWithAngular7.model.Orders;
import com.shree.springBootWithAngular7.model.OrdersDto;
import com.shree.springBootWithAngular7.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDao orderDao;

	@Override
	public void saveOrder(Orders orders) {
		orderDao.save(orders);
	}

	@Override
	public List<OrdersDto> getOrdersList() {
		List<String[]> list = orderDao.findAllOrders();
		
		List<OrdersDto> ordersList= new ArrayList<>();
		for (String[] strArray : list) {
			OrdersDto ordersDto= new OrdersDto();
			ordersDto.setOrderId(Long.valueOf(strArray[0]));
			ordersDto.setOrderNo(strArray[1]);
			ordersDto.setCustomerName(strArray[2]);
			
			ordersDto.setgTotal(Float.valueOf(strArray[3]));
			ordersDto.setpMethod(strArray[4]);
			ordersList.add(ordersDto);
			
		}
		return ordersList;
	}

	@Override
	public Order getOrderById(Long orderId) {
		Orders orders = orderDao.findById(orderId).get();
		Order order= new Order();
		order.setOrderId(orders.getOrderId());
		order.setCustomerId(orders.getCustomerId());
		order.setOrderNo(orders.getOrderNo());
		order.setpMethod(orders.getpMethod());
		order.setgTotal(orders.getgTotal());
		
		List<String[]> orderItemsList = orderDao.findOrderItemsByOrderId(orderId);
		List<OrderItemDto> newOrderItemsList= new ArrayList<>();
		for (String[] strArray : orderItemsList) {
			OrderItemDto orderItemDto= new OrderItemDto();
			orderItemDto.setOrderItemId(Long.valueOf(strArray[0]));
			orderItemDto.setItemId(Integer.valueOf(strArray[1]));
			orderItemDto.setItemName(strArray[2]);
			orderItemDto.setPrice(Double.valueOf(strArray[3]));
			orderItemDto.setQuantity(Integer.valueOf(strArray[4]));
			orderItemDto.setTotal(orderItemDto.getPrice() * orderItemDto.getQuantity());
			newOrderItemsList.add(orderItemDto);
		}
		order.getOrderItems().addAll(newOrderItemsList);
		return order;
	}

	@Override
	public void updateOrder(Orders orders) {
		if(orders !=null && orders.getDeletedOrderItemIds() !=null){
			String [] deletedOrderItemsArray=orders.getDeletedOrderItemIds().split(",");
			List<Integer> idsList = new ArrayList<>(deletedOrderItemsArray.length);
			for (int i = 0; i < deletedOrderItemsArray.length; i++) {
				idsList.add(Integer.parseInt(deletedOrderItemsArray[i]));
			}
			orderDao.deleteOrderItemsWithIds(idsList);
		}
		orderDao.save(orders);
		
	}

	@Override
	public void deleteOrderById(long id) {
		orderDao.deleteOrderWithOrderId(id);
		orderDao.deleteOrderById(id);
	}

}
