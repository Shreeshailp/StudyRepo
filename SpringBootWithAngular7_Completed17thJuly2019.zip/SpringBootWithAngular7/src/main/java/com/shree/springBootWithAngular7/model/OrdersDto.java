package com.shree.springBootWithAngular7.model;

public class OrdersDto {
	private Long orderId;
	private String orderNo;
	private String customerName;
	private String pMethod;
	private Float gTotal;
	
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getpMethod() {
		return pMethod;
	}
	public void setpMethod(String pMethod) {
		this.pMethod = pMethod;
	}
	public Float getgTotal() {
		return gTotal;
	}
	public void setgTotal(Float gTotal) {
		this.gTotal = gTotal;
	}
	@Override
	public String toString() {
		return "OrdersDto [orderId=" + orderId + ", orderNo=" + orderNo + ", customerName=" + customerName
				+ ", pMethod=" + pMethod + ", gTotal=" + gTotal + "]";
	}
	
	
}
