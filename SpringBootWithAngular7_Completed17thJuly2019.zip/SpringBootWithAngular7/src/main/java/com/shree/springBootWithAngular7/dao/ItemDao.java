package com.shree.springBootWithAngular7.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shree.springBootWithAngular7.model.Item;

public interface ItemDao extends JpaRepository<Item, Long>{

}
