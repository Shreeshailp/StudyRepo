package com.shree.springBootWithAngular7.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long orderId;
	private String orderNo;
	private int customerId;
	private String pMethod;
	private Float gTotal;
	@OneToMany(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	@JoinColumn(name = "orderId")
	private List<OrderItem> orderItems = new ArrayList<>();
	private transient String deletedOrderItemIds;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getpMethod() {
		return pMethod;
	}
	public void setpMethod(String pMethod) {
		this.pMethod = pMethod;
	}
	public Float getgTotal() {
		return gTotal;
	}
	public void setgTotal(Float gTotal) {
		this.gTotal = gTotal;
	}
	public List<OrderItem> getOrderItems() {
		return orderItems;
	}
	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}
	public String getDeletedOrderItemIds() {
		return deletedOrderItemIds;
	}
	public void setDeletedOrderItemIds(String deletedOrderItemIds) {
		this.deletedOrderItemIds = deletedOrderItemIds;
	}
	
	
	
}
