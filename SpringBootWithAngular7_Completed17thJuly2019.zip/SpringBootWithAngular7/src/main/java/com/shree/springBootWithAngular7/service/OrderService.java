package com.shree.springBootWithAngular7.service;

import java.util.List;

import com.shree.springBootWithAngular7.model.Order;
import com.shree.springBootWithAngular7.model.Orders;
import com.shree.springBootWithAngular7.model.OrdersDto;

public interface OrderService {
	public void saveOrder(Orders orders);
	
   public List<OrdersDto> getOrdersList();
   
   public  Order  getOrderById(Long orderId);

public void updateOrder(Orders orders);

public void deleteOrderById(long id);
}
