package com.shree.springBootWithAngular7.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.shree.springBootWithAngular7.model.Orders;

public interface OrderDao extends JpaRepository<Orders, Long> {
	 @Query(value = "SELECT o.ORDER_ID,o.ORDER_NO,c.NAME,o.G_TOTAL,o.P_METHOD FROM ORDERS o INNER JOIN CUSTOMER c ON o.CUSTOMER_ID=c.CUSTOMER_ID", nativeQuery = true)
	 public List<String[]> findAllOrders();
	 @Query(value="SELECT OI.ORDER_ITEM_ID,OI.ITEM_ID,I.NAME,I.PRICE,OI.QUANTITY FROM ORDER_ITEM  OI INNER JOIN ITEM I ON I.ITEM_ID=OI.ITEM_ID WHERE OI.ORDER_ID=?1", nativeQuery=true)
	 public List<String[]> findOrderItemsByOrderId(Long orderId);
	 @Transactional
	 @Modifying
	 @Query(value="DELETE FROM ORDER_ITEM OI where OI.ORDER_ITEM_ID in ?1", nativeQuery=true)
	 public void deleteOrderItemsWithIds(List<Integer> ids);
	 @Transactional
	 @Modifying
	 @Query(value="DELETE FROM ORDERS o where o.ORDER_ID=?1", nativeQuery=true)
	 public void deleteOrderById(long id);
	 @Transactional
	 @Modifying
	 @Query(value="DELETE FROM ORDER_ITEM OI where OI.ORDER_ID=?1", nativeQuery=true)
	 public void deleteOrderWithOrderId(long id);
	 
}
