package com.shree.springBootWithAngular7.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shree.springBootWithAngular7.model.Customer;
import com.shree.springBootWithAngular7.model.Item;
import com.shree.springBootWithAngular7.model.Order;
import com.shree.springBootWithAngular7.model.Orders;
import com.shree.springBootWithAngular7.model.OrdersDto;
import com.shree.springBootWithAngular7.service.CustomerService;
import com.shree.springBootWithAngular7.service.ItemService;
import com.shree.springBootWithAngular7.service.OrderService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class MyCartAppController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private ItemService itemService;
	
	@Autowired
	private OrderService orderService;

	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> customers() {
		List<Customer> customersList = customerService.getAllCustomers();
		return new ResponseEntity<>(customersList, HttpStatus.OK);
	}

	@GetMapping("/items")
	/*@CrossOrigin(origins = "http://localhost:4200")*/
	public ResponseEntity<List<Item>> items() {
		List<Item> itemList = itemService.getAllItems();
		System.out.println(itemList);
		return new ResponseEntity<>(itemList, HttpStatus.OK);
	}

	@PostMapping("/order")
	/*@CrossOrigin(origins = "http://localhost:4200")*/
	public void createOrder(@RequestBody Orders orders) {
		if(orders != null && orders.getOrderId()==null){
			orderService.saveOrder(orders);
		}else{
			orderService.updateOrder(orders);
		}
		
		
	}
	
	@GetMapping("/orders")
	/*@CrossOrigin(origins = "http://localhost:4200")*/
	public ResponseEntity<List<OrdersDto>> orders() {
		List<OrdersDto> ordersList= orderService.getOrdersList();
		System.out.println(ordersList);
		return new ResponseEntity<>(ordersList, HttpStatus.OK);
	}
	 @GetMapping(value = "/order/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Order> getOrderById(@PathVariable("id") long id) {
	        Order order = orderService.getOrderById(id);
	        if (order == null) {
	            return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
	        }
	        return new ResponseEntity<Order>(order, HttpStatus.OK);
	    }
	 
	 @DeleteMapping(value = "/order/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Order> deleteOrderById(@PathVariable("id") long id) {
	         orderService.deleteOrderById(id);
	        return new ResponseEntity<Order>(HttpStatus.OK);
	    }
}
