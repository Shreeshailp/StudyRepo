INSERT INTO customer VALUES(1, 'Shreeshail');
INSERT INTO customer  VALUES(2, 'Dinesh');
INSERT INTO customer VALUES(3, 'Ranjit');
INSERT INTO customer  VALUES(4, 'Indra');
INSERT INTO customer  VALUES(5, 'Kapil');



INSERT INTO ITEM VALUES(1, 'Eraser',10.5);
INSERT INTO ITEM VALUES(2, 'Sunglasses',550);
INSERT INTO ITEM VALUES(3, 'Lip gloss',55.80);
INSERT INTO ITEM VALUES(4, 'Rubber Duck',10.5);
INSERT INTO ITEM VALUES(5, 'Slipper',400);
INSERT INTO ITEM VALUES(6, 'Bottle Cap',150);

SELECT *FROM ORDERS;

SELECT *FROM ORDER_ITEM ;