define([
    '{angular}/angular',
    '{angular-resource}/angular-resource'

], function (angular) {
    'use strict';

    var module = angular.module('home', ['ngResource', 'i18nitialisation']);

    module.factory('DataService', ['$resource', function ($resource) {
        return $resource(require.toUrl('{wltp}/data/data.json'));
    }]);

    module.controller('HomeController', ['$scope', 'DataService', 'HomeService', function ($scope, dataService, homeService) {

        $scope.imagePath = 'images/washedout.png';

        homeService('wltp').enter('families').get(function (res) {
            angular.forEach(res.$embedded('families'), function (fam) {
                console.info('family found : ' + angular.toJson(fam));
            });
            res.$embedded('families')[0].$links('self').get();
        });

    }]);

    return {
        angularModules: ['home']
    };
});
