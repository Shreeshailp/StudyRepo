define([
    '{lodash}/lodash'
], function (lodash) {
    'use strict';

    function factoryFunc($http, $resource) {
        return {
            executeUnitaryWltpHubConsultation: function (appName, requestObj) {
                let reqBody = lodash.assign({
                version16C: "",
                colorExtInt: "",
                options5C: "",
                options7C: "",
                extensionDate: "",
                mountingCenter: "",
                requestType: "",
                ecomDate: "",
                tradingCountry: "",
                extendedTitleAttributes: "",
                tvv: "",
                requestID:""
                }, requestObj);
                return $resource('/api/wltphubUnitarySimulation/callWltphubWS', { appName: appName }).save({ request: reqBody }).$promise;
            },

            getAllCollections: function (userId) {
                return $resource('/api/wltphubUnitarySimulation/allCollections', { userId: userId }).get().$promise;
            },

            createCollection: function (params) {
                return $resource('/api/wltphubUnitarySimulation/createCollection', params).save(null).$promise;
            },
            updateCollection: function (params) {
                return $resource('/api/wltphubUnitarySimulation/updateCollection', params).save(null).$promise;
            },

            deleteCollection: function (collId) {
                return $resource('/api/wltphubUnitarySimulation/deleteCollection', { collectionId: collId }).save(null).$promise;
            },
            saveRequestToCollection: function (collectionId, requestId, requestName, reqBody) {
                return $resource('/api/wltphubUnitarySimulation/saveOrUpdateRequestToCollection', { collectionId: collectionId, requestId: requestId, requestName: requestName })
                    .save(reqBody).$promise;
            },

            deleteRequest: function (reqId) {
                return $resource('/api/wltphubUnitarySimulation/deleteRequest', { requestId: reqId }).save(null).$promise;
            },

            getLabelFromCode: function (code) {
                return $resource('/api/references/measuretypes/:code', { code: code }).get().$promise;
            }

        }
    }

    factoryFunc.$inject = ['$http', '$resource'];

    return factoryFunc;
});
