define([
    '{angular}/angular'

], function(angular) {
    'use strict';

    var module = angular.module('i18nitialisation', []);

    module.run(['$rootScope', 'CultureService', function($rootScope, cultureService) {
        $rootScope.$on('w20.security.authenticated', localeHandler);
        
        function localeHandler(_, user) {
            cultureService.culture(user.principals.locale);
        } 
    }]);

    return {
        angularModules : [ 'i18nitialisation' ]
    };
});
