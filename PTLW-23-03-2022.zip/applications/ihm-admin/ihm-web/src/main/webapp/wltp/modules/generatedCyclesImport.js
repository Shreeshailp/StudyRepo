/**
 * 
 */

define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'
], function (angular, angular_resource, angularFileUpload, check_role, ComponentRoleCheckService) {
    'use strict';
     
    var module = angular.module('generatedCyclesImport', ['ngResource', 'ngMaterial', 'angularFileUpload', 'i18nitialisation']);
                                        

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('GeneratedCyclesImportController', ['$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', 'FileUploader', '$location', 'AuthorizationService', '$route', '$window','ComponentRoleCheckService', function ($scope, homeService, CultureService, $mdToast, $mdDialog, FileUploader, $location, authorizationService, $route, $window, componentRoleCheckService) {

        $scope.componentRoleCheckService = componentRoleCheckService;
                                            /* File Import */
        $scope.uploader = new FileUploader({
            url: homeService('wltp').getDefinition('importGeneratedCycles').href + '/upload',
            formData: [{
                forceUpdate: false
            }],
            autoUpload: false
            
        });
        
        // /**
        //  * **********************************Start : Role Wise
        //  * Access************************************
        //  */
        // if(!authorizationService.hasRole('wltp', 'wltpaccess')){
        //        $mdToast.show($mdToast.simple()
        //                .textContent("You don't have permission for this tab")
        //                .position('top right')
        //                .hideDelay(1000)
        //            );
        //         $location.path('/wltp/wltphome');
        //         return;
        //    }
        //    /**
        //      * **********************************End : Role Wise
        //      * Access************************************
        //      */
            var successMessage = CultureService.localize('application.view.wltp.generatedcycle.upload.success');
            var validFileErrorMessage = CultureService.localize('application.view.wltp.generatedcycle.upload.error');
            var connectionFailureMessage = CultureService.localize('application.view.wltp.generatedcycle.connection.failure.message');           
           
           
            $scope.displayView = false;
           
            $scope.totalRecordCount = 0;
            
           function toastTemplate() {
               return $mdToast.simple().hideDelay(2000).position('top right');
           }
    
           //select files
               $scope.selectFile = function(){
                    $("#file").click();
           
               }
           
               $scope.selectFiles = function(){
                    $("#files").click();
               }
           
           //clear files
    function clearFileUpload() {
        document.querySelector('#file').value = '';
        $scope.uploader.clearQueue();
    }
               
           //filter excel file
    $scope.uploader.filters.push({
        name: 'excelFilter',
        fn: function(item) {
            var fileExt = ['.xlsx', '.xls'];
            var fileType = item.name;
            fileType = fileType.substring(fileType.lastIndexOf('.'));
            return fileExt.indexOf(fileType) >= 0;
        }
    });
    
    $scope.uploader.onWhenAddingFileFailed = function(item /* {File|FileLikeObject} */, filter, options) {
        
        $mdToast.show(toastTemplate().textContent(validFileErrorMessage));
       
        console.info('onWhenAddingFileFailed', item, filter, options);
    };
    
    $scope.uploader.hasFile = function(file) {
        return this.queue.some(function(item) {
            return (item.file.name === file.name && item.file.size === file.size);
        });
    };

 //isSucess   item.isReady || item.isUploading
       
    /*$scope.uploadMultipleFiles  = function(status){
         
         $scope.items=$scope.uploader.queue;
         
        for(var i=0;i<$scope.items.length; i++){
            
               var item = $scope.items[i];
              
    
                if (item != null) {
                    
                    var confirm = $mdDialog.confirm().ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes')).cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));
                    
                    if($mdDialog.show(confirm)) {
                 
                      item.formData = [{
                       forceUpdate: false,
                        autoUpload: false
                    }];
                      
                     item.upload();

                    };
                    continue;
                    
                }  else {
                   
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .hideDelay(0));
                    console.info('onErrorItem', item, error, status);
                }
                
               
            }
        
}*/

    
$scope.uploadMultipleFiles=function(){
        
        $scope.items=$scope.uploader.queue;
        for(var i=0;i<$scope.items.length;i++){
            $scope.uploader.onErrorItem=function(item, error, status){
                if (status === 409) {
                   // alert(CultureService.localize('application.view.wltp.file.exists'));
                   $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.file.exists')).hideDelay(5000));
                   
                    item.formData = [{
                        forceUpdate: true,                        
                    }];
                   
                } else {
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .hideDelay(0));
                    console.info('onErrorItem', item, error, status);
                }
            }
            $scope.items[i].upload();
            }
    }
     
//on Error Item
   $scope.uploader.onErrorItem = function(item, error, status) {
        if (status === 409 ) {
        	
            var confirm = $mdDialog.confirm()
                .title(CultureService.localize('application.view.wltp.generatedcycle.upload.conflict.title2'))
                .textContent(CultureService.localize('application.view.wltp.generatedcycle.upload.conflict.message'))
                .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                // .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yestoAll'))
                .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));
          
            $mdDialog.show(confirm).then(function() {
               
            	
                item.formData = [{
                    forceUpdate: true
                   
                    
                }];
                item.upload();
                
            }).catch(function() {
                $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.cancelled'))); 
            });
            
        } else {
           
            $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                .hideDelay(0));
            console.info('onErrorItem', item, error, status);
            
        }
        
    };
   
         
            //on Success
    $scope.uploader.onSuccessItem = function(item, response) {    
        $mdToast.show(toastTemplate().textContent(CultureService.localize(successMessage)));
        $scope.filePath = response.fileName;
        
        console.info('onSuccessItem', item, response);
       
    };    

   
   $scope.search=function(){
           
            homeService('wltp').enter('generatedCycleSearch', { 'generatedCode': $scope.generatedCode, 'cycleCode': $scope.cycleCode, 'phase': $scope.phase, 'downscaleFlag': $scope.downscaleFlag, 'fdsc': $scope.fdsc, 'speedLimitFlag': $scope.speedLimitFlag, 'vMax': $scope.vMax, }).get(function(res) {
                $scope.generatedCyclesImportData = res.$embedded('generatedCycleSearch');
                if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length === 0) {
                    $scope.displayView = false;
                }
                else if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length > 0) {
                    for(var i=0;i<$scope.generatedCyclesImportData.length;i++){
                        if($scope.generatedCyclesImportData[i].speedLimitFlag==true && $scope.generatedCyclesImportData[i].downscaleFlag==false){
                            $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                            $scope.generatedCyclesImportData[i].downscaleFlag='N';
                        }
                        if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==false){
                            $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                            $scope.generatedCyclesImportData[i].speedLimitFlag='N';
                        }
                        if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==true){
                            $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                            $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                        }
                    }
                    $scope.displayView = true;
                    $scope.totalRecordCount = $scope.generatedCyclesImportData.length;
                }
               
            }, function() {
                $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
            });

        }
       
   
       $scope.resetAll = function () {
                
                $scope.generatedCode = '';            
                $scope.cycleCode = '';
                $scope.phase = '';
                $scope.downscaleFlag = '';
                $scope.fdsc= '';
                $scope.speedLimitFlag= '';
                $scope.vMax= '';
                homeService('wltp').enter('importGeneratedCycles').get(function(res) {
                    $scope.generatedCyclesImportData = res.$embedded('importGeneratedCycles');
                    $route.reload();
                if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length === 0) {
                        $scope.displayView = false;
                    }
                else if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length > 0) {
                        for(var i=0;i<$scope.generatedCyclesImportData.length;i++){
                            if($scope.generatedCyclesImportData[i].speedLimitFlag==true && $scope.generatedCyclesImportData[i].downscaleFlag==false){
                                $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                                $scope.generatedCyclesImportData[i].downscaleFlag='N';
                            }
                            if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==false){
                                $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                                $scope.generatedCyclesImportData[i].speedLimitFlag='N';
                            }
                            if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==true){
                                $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                                $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                            }
                        }
                        $scope.displayView = true;
                        $scope.totalRecordCount = $scope.generatedCyclesImportData.length;
                        
                    }
                }, function() {
                    $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                });
                
             
        }
            
         // column to sort
            $scope.column = 'generatedCode';
            
            // sort ordering (Ascending or Descending). Set true for desending
            $scope.reverse = false; 
            
            // called on header click
            $scope.sortColumn = function(col){
             $scope.column = col;
             if($scope.reverse){
              $scope.reverse = false;
              $scope.reverseclass = 'arrow-up';
             }else{
              $scope.reverse = true;
              $scope.reverseclass = 'arrow-down';
             }
            };
            
            // remove and change class
            $scope.sortClass = function(col){
             if($scope.column == col ){
              if($scope.reverse){
               return 'arrow-down'; 
              }else{
               return 'arrow-up';
              }
             }else{
              return '';
             }
            } 
        
        
        fetchGeneratedCyclesDetails();  
        
        function fetchGeneratedCyclesDetails(){
            homeService('wltp').enter('importGeneratedCycles').get(function(res) {
                $scope.generatedCyclesImportData = res.$embedded('importGeneratedCycles');
                if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length === 0) {
                    $scope.displayView = false;
                }
                else if ($scope.generatedCyclesImportData != null && $scope.generatedCyclesImportData.length > 0) {
                    for(var i=0;i<$scope.generatedCyclesImportData.length;i++){
                        if($scope.generatedCyclesImportData[i].speedLimitFlag==true && $scope.generatedCyclesImportData[i].downscaleFlag==false){
                            $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                            $scope.generatedCyclesImportData[i].downscaleFlag='N';
                        }
                        if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==false){
                            $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                            $scope.generatedCyclesImportData[i].speedLimitFlag='N';
                        }
                        if($scope.generatedCyclesImportData[i].downscaleFlag==true && $scope.generatedCyclesImportData[i].speedLimitFlag==true){
                            $scope.generatedCyclesImportData[i].downscaleFlag='Y';
                            $scope.generatedCyclesImportData[i].speedLimitFlag='Y';
                        }
                    }
                    
                    $scope.displayView = true;
                    $scope.totalRecordCount = $scope.generatedCyclesImportData.length;
                    
                }
              }, function() {
                  $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
              });
        }
 
  
$scope.close =function(){
    clearFileUpload();
    $route.reload();
    $('.modal-backdrop').remove();
   // $window.location.reload();
}


function yyyymmdd() {
var now = new Date();
var y = now.getFullYear();
var m = now.getMonth() + 1;
var d = now.getDate();
var h = now.getHours();
var m1 = now.getMinutes();
var s = now.getSeconds();
return '' + y + (m < 10 ? '0' : '') + m + (d < 10 ? '0' : '') + d+h+m1+s;
}
var fileName = "report".concat(yyyymmdd(),".log");

var fileContent,fileText;
$scope.getLogFile = function(){
    homeService('wltp').enter('download').get(function (res) {
                    
            fileContent = res.fileContent;
            
            // fileName = res.fileName;
            fileText = new Blob([fileContent]);
            if (window.navigator.msSaveOrOpenBlob) {
                // Store Blob in IE
                window.navigator.msSaveOrOpenBlob(fileText, fileName);
            } else {
                // Store Blob in others
                var anchorElement = document.body.appendChild(document.createElement('a'));
                anchorElement.href = URL.createObjectURL(fileText);
                anchorElement.download = fileName;
                anchorElement.style.display = 'none';
                anchorElement.click();
                anchorElement.parentNode.removeChild(anchorElement);
            }
    }, function() {
        $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
    });
}

       
$scope.goToLink = function(generatedCyclesData) {
            $scope.path= '/wltp/consultGeneratedCycle/' + generatedCyclesData.guid;
            $location.path($scope.path);
          };
 
        $scope.rowNumber = null;
        $scope.rowselected = function (row) {
             $scope.rowNumber = row;
          }
    }]);

    return {
        angularModules: ['generatedCyclesImport']
    };
});