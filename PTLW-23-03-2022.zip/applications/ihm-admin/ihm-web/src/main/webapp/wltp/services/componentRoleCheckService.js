define([], function(){
    'use strict';

    function factoryFunc(authorizationService, authenticationService){
        var service = {
            checkRole: checkRolesArray,
            getCurrentUser : currentUser,
            isAdmin : isUserAdmin,
        }

        function checkRolesArray(role_array){
            return role_array.some(function(role){
                return authorizationService.hasRole('wltp', role);
            });
        }

        function currentUser(){
            return authenticationService.subjectId();
        }

        function isUserAdmin(){
            return authorizationService.hasRole('wltp','wltpaccess');
        }





        return service;
    }

    factoryFunc.$inject=['AuthorizationService', 'AuthenticationService'];

    return factoryFunc;
});
