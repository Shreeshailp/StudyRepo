define([], function(){
    'use strict';

    function dialogController($scope, $mdDialog, cultureService) {

            $scope.cancel = function () {
                $mdDialog.cancel();
            };

            $scope.block = function (blockingForm) {
                $mdDialog.hide(blockingForm);
            };
    }

    dialogController.$inject = ["$scope", "$mdDialog","CultureService"];

    return dialogController;
});
