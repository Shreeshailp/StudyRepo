define([], function () {
    'use strict';

    function factoryFunc($http, $resource) {
        return {
            getFamilies: function () {
                return $resource('/api/families').get().$promise;
            },
            getData: function() {
                return $resource(require.toUrl('wltp/data/dummy.json')).query().$promise;
            },
            getAdditionalData: function(familyRef){
                return $resource('/api/additionalFamily/getfamilyadditionaldata').save(familyRef,null).$promise;
            },
            getPhysicalQuantities: function(){
                return $resource('/api/references/physicalquantities').get().$promise;
            },
            getExtendedFamilyDetails: function(id){
                return $resource('api/families/:id',{id:id}).get().$promise;
            },
            getAllTestVehicles:function(){
                return $resource('/api/references/allTestVehicles').get().$promise;
            }
        
            
        }
    }

    factoryFunc.$inject = ['$http', '$resource'];

    return factoryFunc;
});
