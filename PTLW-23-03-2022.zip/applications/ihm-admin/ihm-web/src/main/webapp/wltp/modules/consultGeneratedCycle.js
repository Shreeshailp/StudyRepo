define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{FileSaver}/FileSaver'
], function(angular) {
    'use strict';
    
    var module = angular.module('consultGeneratedCycle', ['ngResource', 'ngMaterial', 'i18nitialisation']);

    module.controller('ConsultGeneratedCycleController', [ '$scope', '$mdToast', '$filter', '$routeParams', 'HomeService', '$window', '$http', function($scope, $mdToast, $filter, $routeParams, homeService, $window, $http) {
        console.log("Calling console.log");
        var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');
        
        homeService('wltp').enter('consultGeneratedCycle', { 'cycle': $routeParams.id }).get(function (res) {
            $scope.consultGeneratedCycleData = res.$embedded('consultGeneratedCycle');
            $scope.generatedCycleData = res.$embedded('importGeneratedCycles');
            if($scope.generatedCycleData !=null && $scope.generatedCycleData.length > 0)
            {
                for(var i=0;i<$scope.generatedCycleData.length;i++){
                    if($scope.generatedCycleData[i].speedLimitFlag==true && $scope.generatedCycleData[i].downscaleFlag==false){
                        $scope.generatedCycleData[i].speedLimitFlag='Y';
                        $scope.generatedCycleData[i].downscaleFlag='N';
                    }
                    if($scope.generatedCycleData[i].downscaleFlag==true && $scope.generatedCycleData[i].speedLimitFlag==false){
                        $scope.generatedCycleData[i].downscaleFlag='Y';
                        $scope.generatedCycleData[i].speedLimitFlag='N';
                    }
                    if($scope.generatedCycleData[i].downscaleFlag==true && $scope.generatedCycleData[i].speedLimitFlag==true){
                        $scope.generatedCycleData[i].downscaleFlag='Y';
                        $scope.generatedCycleData[i].speedLimitFlag='Y';
                    }
                }
            }
            $scope.cycleDetailsData = res.$embedded('cycle');
        }, function(response){
            $mdToast.show($mdToast.simple()
                    .textContent(connectionFailureMessage)
                    .position('top right')
                    .hideDelay(1000)
                );
        });
        
    }]);
    
	return {
        angularModules : [ 'consultGeneratedCycle' ]
    };
});
