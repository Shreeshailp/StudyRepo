define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'
], function (angular,angular_resource, angularFileUpload, check_role, ComponentRoleCheckService) {
    'use strict';

    var module = angular.module('cycle-profiles', ['ngResource', 'angularFileUpload', 'i18nitialisation']);

     // role wise access -> key has to be what was declared in check property of route definition.
     module.value("has_role", check_role);
     // end of role wise access
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('CycleProfilesController', ['$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', '$filter', 'FileUploader', '$location', 'AuthorizationService','ComponentRoleCheckService', function ($scope, homeService, CultureService, $mdToast, $mdDialog, $filter, FileUploader, $location, authorizationService, componentRoleCheckService) { // NOSONAR

        $scope.componentRoleCheckService = componentRoleCheckService;

        var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');

        homeService('wltp').enter('cycles').get(function(res) {
            $scope.cycles = res.$embedded('cycles');
        }, function() {
            $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
        });
        
        function toastTemplate() {
            return $mdToast.simple().hideDelay(2000).position('top right');
        }

        $scope.uploader = new FileUploader({
            url: homeService('wltp').getDefinition('cycles').href + '/upload',
            autoUpload: true
        });
        
        // /************************************Start : Role Wise Access*************************************/
        // if(!authorizationService.hasRole('wltp', 'wltpaccess')){
        //     $mdToast.show($mdToast.simple()
        //             .textContent("You don't have permission for this tab")
        //             .position('top right')
        //             .hideDelay(1000)
        //         );
        //      $location.path('/wltp/wltphome');
        //      return;
        // }
        // /************************************End : Role Wise Access*************************************/
        
        var validFileErrorMessage = $filter('localize')('application.view.wltp.family.upload.error');


        $scope.openFileInput = function() {
            document.querySelector('#file').click();
        };

        function clearFileUpload() {
            document.querySelector('#file').value = '';
            $scope.uploader.clearQueue();
        }

        $scope.uploader.filters.push({
            name: 'excelFilter',
            fn: function(item) {
                return ['xlsx', 'xls'].some(function (ext) {
                    return new RegExp('\.'+ext+'$').test(item.name);
                });
            }
        });

        $scope.uploader.onErrorItem = function(item, error, status) {
            if (status === 409 || error.errorCode === "RG20") {
                var confirm; 
                
                confirm = $mdDialog.confirm()
                    .title(CultureService.localize('application.view.wltp.cycle-profiles.upload.conflict.title'))
                    .textContent(CultureService.localize('application.view.wltp.cycle-profiles.upload.conflict.message'))
                    .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                    .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));

                //fix for JIRA-439 POP UP
                if(error.errorCode == "RG20"){
                    confirm = $mdDialog.confirm()
                    .title(CultureService.localize('application.view.wltp.cycle-profiles.upload.conflict.title'))
                    .textContent(CultureService.localize('application.view.wltp.cycle-profiles.upload.conflict.message.generated.cyle'))
                    .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                    .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));
                }
                    
                $mdDialog.show(confirm).then(function() {
                    item.formData = [{
                        forceUpdate: true
                    }];
                    item.upload();
                }).catch(function() {
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.cancelled')));
                    clearFileUpload();
                })
                
            } else {
                $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                    .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                    .hideDelay(0));
                clearFileUpload();
            }
        };

        $scope.uploader.onSuccessItem = function(item, response) {
            $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.success')));
            clearFileUpload();
            $location.path('/wltp/cycle-profiles/' + response._embedded.cycles[0].guid);
        };

        $scope.uploader.onWhenAddingFileFailed = function() {
            $mdToast.show(toastTemplate().textContent(validFileErrorMessage));
        };

    }]);

    return {
        angularModules: ['cycle-profiles']
    };
});