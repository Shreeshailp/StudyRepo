define([], function () {
    'use strict';

    function factoryFunc($http, $resource) {
        return {
            changeTabStatus: function (requestBody) {
                return $resource('/api/references/familyTabCheckFlag').save(null,requestBody).$promise;
            },
            changeStatus: function(requestObj) {
                return $resource('/api/references/familyTabCheckStatus').save(requestObj,null).$promise;
            },
            getFamilyTabCheckStatus: function(familyRef){
                return $resource('/api/references/familyTabCheckFlages/:T8C/:T8D',familyRef).get().$promise;
            },
            toggleBlock: function(requestObj){
                return $resource('/api/references/familyTabCheckStatus').save(requestObj,null).$promise;
            },

            getAdditionalData: function(familyRef){
                return $resource('/api/additionalFamily/getfamilyadditionaldata').save(familyRef,null).$promise;
            },

            saveAdditionalData: function(additionalDataObj,familyRef){
                return $resource('/api/additionalFamily/saveupdatefamilyadditionaldata').save(familyRef,additionalDataObj).$promise;
            },

            getAllGearBoxDetails: function(){
                return $resource('/api/moteurgearbox/getgearboxdetails').save(null).$promise;
            },

            getAllMoteurDetails: function(){
                return $resource('/api/moteurgearbox/getmoteurdetails').save(null).$promise;
            }

        }
    }

    factoryFunc.$inject = ['$http', '$resource'];

    return factoryFunc;
});
