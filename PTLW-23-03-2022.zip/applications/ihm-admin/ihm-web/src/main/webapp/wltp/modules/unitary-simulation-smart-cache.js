
define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{lodash}/lodash',
    'moment/moment',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService',
    '{wltp}/services/wltphubUnitarySimulationService',
    '{angular-file-upload}/angular-file-upload'
], function (angular, angular_resource, lodash, moment, check_role, ComponentRoleCheckService, wltphubUnitarySimulationService, angularFileUpload) {
    'use strict';

    var module = angular.module('unitarySimulationSmartCache', ['ngResource', 'ngMaterial', 'i18nitialisation', 'ui.grid', 'ui.grid.autoResize', 'ngAnimate', 'angularFileUpload']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access

    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.factory('wltphubUnitarySimulationService', wltphubUnitarySimulationService);
    module.filter('codeToLabel', codeToLabel);
    module.directive('multipleValidator', [function () {
        return {
            restrict: 'AC',
            require: 'ngModel',
            link: function (scope, elem, attr, ngModelCtrl) {

                if (!ngModelCtrl) {
                    return;
                }

                var multiple = parseInt(attr.multipleValidator);

                if (!multiple) {
                    return;
                }

                ngModelCtrl.$validators.multipleValidator = function (modelValue, viewValue) {
                    if (!modelValue) {
                        return true;
                    }
                    return modelValue.length % multiple === 0;
                }
            }
        }
    }])
    module.controller('UnitarySimulationSmartCacheController', ['$q', '$window', '$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', 'FileUploader', '$location', 'AuthorizationService', 'ComponentRoleCheckService', 'wltphubUnitarySimulationService', '$timeout', 'uiGridConstants', function ($q, $window, $scope, homeService, CultureService, $mdToast, $mdDialog, FileUploader, $location, authorizationService, componentRoleCheckService, wltphubUnitarySimulationService, $timeout, uiGridConstants) {


        var showErrorToast = function (message) {
        if (message.status === 400) {
                $mdToast.show($mdToast.simple()
                    .textContent(CultureService.localize(message.data.errorMsg))
                    .action(CultureService.localize('application.view.wltp.toast.action.ok')).position('top right')
                    .hideDelay(0));
                    $scope.loader = false;
            }
            else {
            $mdToast.show($mdToast.simple()
                .textContent(message)
                .position('top right')
                .hideDelay(1000)
            );
             $scope.loader = false;
            }
        };


        $scope.appName = "WLTPHUB";

        var DEFAULT_FORM_STATE = {
            requestType: 'FULL',
            tradingCountry: 'FR'
        }

        $scope.selectedTab = 0;

        $scope.userId = componentRoleCheckService.getCurrentUser();




        $scope.requestFormUWC;// ng form 

        $scope.requestObj;


        $scope.requestFormObj = lodash.assign({}, DEFAULT_FORM_STATE); //ngmodel for the request form
        $scope.responseObj = {}; //only visual

        $scope.loader = false;
        $scope.gridOptions = {
            enableSorting: false,
            enableFiltering: false,
            enableColumnMenus: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            noUnselect: true,
            rowHeight: 30,
            columnDefs: [
                {
                    displayName: '',
                    field: 'type',
                    width: '25%',
                    cellTooltip: true,
                    cellFilter: 'codeToLabel',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.low'),
                    field: 'LOW',
                    cellClass: 'values-per-phase blue'

                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.mid'),
                    field: 'MID',
                    cellClass: 'values-per-phase blue'

                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.high'),
                    field: 'HIGH',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.ehigh'),
                    field: 'EHIGH',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.city'),
                    field: 'CITY',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.combined'),
                    field: 'COMB',
                    cellClass: 'values-per-phase blue'
                }
            ],
            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
            },
        };

        var phaseTypes = [];



        $scope.reset = function () {
            $scope.requestObj = null;
            $scope.requestFormObj = lodash.assign({}, DEFAULT_FORM_STATE);
            $scope.responseObj = null;
            $scope.gridOptions.data = [];
            $scope.selectedRequest = null;
            $scope.selectedCollectionId = null;
            $scope.requestFormUWC.$setPristine();
            $scope.requestFormUWC.$setUntouched();
        }

        $scope.sendRequest = function () {
            //save request form to requestObject
            if (!$scope.requestObj) {
                $scope.requestObj = lodash.cloneDeep(lodash.assign({}, $scope.requestFormObj));
            }


            //map response to RequestObj and set form to pristine
            $scope.loader = true;
            wltphubUnitarySimulationService.executeUnitaryWltpHubConsultation($scope.appName, buildDtoFromRequest($scope.requestObj)).then(function (data) {
                $scope.responseObj = data;
                $scope.loader = false;
                //map response to request form
                $scope.requestFormObj = lodash.assign($scope.requestFormObj, $scope.responseObj.request, function (a, b) {
                    return !a || a != b ? b : a;
                });
                mapPhasetoForm($scope.responseObj.phase);
                $scope.requestFormUWC.$setPristine();
                $scope.requestFormUWC.$setUntouched();
            }, function (err) {
                showErrorToast(err);
            });

        }

        function buildDtoFromRequest(requestObj) {
            const dto = lodash.cloneDeep(requestObj);
            //calculate nbgestion/ nbOptions------------------
            dto.nbOptions = dto.options7C ? (dto.options7C.length / 7).toString() : dto.options5C ? (dto.options5C.length / 5).toString() : '';
            //dto.nbGestion = dto.gestion7C ? (dto.gestion7C.length / 7).toString() : dto.gestion5C ? (dto.gestion5C.length / 5).toString() : '';



            //return a new object 

            return dto;
        }

        function mapPhasetoForm(phases) {
            if (!phases) {
                $scope.gridOptions.data = [];
                return;
            }
            phaseTypes = [];
            phases.forEach(function (phase) {
                phase.result.forEach(function (type) {
                    phaseTypes.push(type.code)
                });
            });

            phaseTypes = lodash.uniq(phaseTypes)
            let result = [];
            if (phases.length > 0) {
                phaseTypes.forEach(function (type) {
                    const obj = {};
                    obj['type'] = type;
                    lodash.map(phases, function (phase) {
                        obj[phase.code] = lodash.find(phase.result, { 'code': type }) ? lodash.find(phase.result, { 'code': type }).value : '';
                    });
                    result.push(obj);
                });
            }

            let promiseArray = [];
            result.forEach(function (result) {
                if (!codeToLabelMap[result.type]) {
                    promiseArray.push(wltphubUnitarySimulationService.getLabelFromCode(result.type))
                }
            });
            $q.all(promiseArray).then(function (data) {
                data.forEach(function (data) {
                    codeToLabelMap[data.code] = data.label;
                });
                $scope.gridOptions.data = result;
            })

        }

//        $scope.isResponseData = function (code) {
//            return !lodash.find($scope.requestObj.conversionData, { 'code': code }).value;
//        }
        $scope.getPhysicalValue = function (code) {
            return $scope.responseObj ? (lodash.findIndex($scope.responseObj.physResult, { 'code': code }) > -1 ? lodash.find($scope.responseObj.physResult, { 'code': code }).value : '') : '';
        }


        $scope.$watch('requestFormUWC.$dirty', function (NewValue, oldValue) {
            if (NewValue == true) {
                $scope.requestObj = null;
            }

        }, true);



        // ****************************************************************************collections******************************

        $scope.collectionsApi = {
            loadRequest: loadSelectedRequest,
            updateCollection: updateCollection,
            createNewCollection: createCollectionOnFly,
            createOrUpdateRequest: saveOrUpdate,
            updateRequestName: updateRequestName,
            deleteCollection: deleteCollection,
            deleteRequest: deleteRequest,
            createCollectionPopup: createCollectionPopup,
            toggleInlineEdit: toggleEdit,//takes a callback function as optional parameter
        }

        $scope.maxCollectionLimit;
        $scope.maxRequestLimit;

        $scope.userCollections = {};
        $scope.newCollectionName;
        $scope.newRequestName;
        $scope.selectedRequest;

        $scope.selectedCollectionId;

        $scope.menuState = {};
        $scope.saveToolbar = false;

        $scope.toggle = function (collectionId) {
            $scope.menuState[collectionId] = !$scope.menuState[collectionId];
        };


        $scope.toggleSaveToolbar = function () {
            $scope.newCollectionName = null;
            $scope.newRequestName = null;
            $scope.saveToolbar = !$scope.saveToolbar;
            if ($scope.saveToolbar) {
                $window.onclick = function (event) {
                    var isSelf = event.target.classList.contains('toolbar-toggle-group');
                    var isChild = $window.document.querySelector('.toolbar-toggle-group.panel').contains(event.target)
                    if (isSelf || isChild) return;


                    $timeout(function () {
                        $scope.saveToolbar = false;
                        $window.onclick = null;
                    }, 0);//--> trigger digest cycle and make angular aware.
                    };
            } else {
                $window.onclick = null;
            }
        }


        function toggleEdit(id, callBack) {
            const el = document.getElementById(id);
            if (callBack) {
                setTimeout(lodash.bind(function (event, el) {
                    if (el.classList.contains('editing')) {
                        el.classList.remove('editing');
                    }
                    callBack.call($scope, event.target.value, event.target.id);
                }, this, event, el), 500);
                return;
            }
            if (!el.classList.contains('editing')) {
                el.classList.add('editing')
                el.focus();
            } else {
                el.classList.remove('editing');
            }
        }

        function updateRequestName(newName, requestId) {
            let requestBody;
            let collectionId;

            lodash.forEach($scope.userCollections.collections, function (collection) {
                const req = lodash.find(collection.requests, function (request) {
                    return request.collectionRequestId === requestId;
                });
                if (req) {
                    collectionId = collection.collectionId;
                    requestBody = req.request.request;
                }
            });
            //call api
            wltphubUnitarySimulationService.saveRequestToCollection(collectionId, requestId, newName, { request: requestBody }).then(function (res) {
                console.log(res);
                //getAllCollections();// refreshing collections
            }, function (err) {
                showErrorToast(err)
            })
        }


        function createCollectionPopup(event) {
            //check if limit reached
            if ($scope.userCollections && !($scope.userCollections.collections.length < $scope.maxCollectionLimit)) {
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxCollectionLimit', [$scope.maxCollectionLimit]), event);
                return;
            }
            //show prompt
            showPrompt(CultureService.localize('application.view.wltp.unitarysimulation.newCollection'),
                CultureService.localize('application.view.wltp.unitarysimulation.nameOfCollection'), '', '', event, true, CultureService.localize('application.view.wltp.unitarysimulation.create'), CultureService.localize('application.view.wltp.unitarysimulation.cancel')).then(function (name) {
                    if (!name) {
                        showErrorToast("Collection name cannot be empty");
                        return;
                    }
                    $scope.newCollectionName = name;
                    createCollection();
                }, function () { })
        }

        function createCollectionOnFly(callBack) {
            if ($scope.userCollections && !($scope.userCollections.collections.length < $scope.maxCollectionLimit)) {//check
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxCollectionLimit', [$scope.maxCollectionLimit]), event);
                return;
            }
            createCollection(callBack);
        }

        function loadSelectedRequest(requestId, collectionId) {
            $scope.reset();
            $scope.selectedTab = 0;
            //set SelectedRequest to request from collections
            let selectedCollection = lodash.find($scope.userCollections.collections, function (collection) {
                return collection.collectionId == collectionId;
            });
            $scope.selectedCollectionId = selectedCollection.collectionId;
            $scope.selectedRequest = lodash.find(selectedCollection.requests, function (request) {
                return request.collectionRequestId == requestId;
            });
            mapReqToForm($scope.selectedRequest.request.request)

        }

        function saveOrUpdate(collectionid, isNewRequest) {

            if (!collectionid) {
                collectionid = getCollectionIdofSelectedRequest();
            }
            //check max limit
            if (isNewRequest && $scope.userCollections && !(getSizeOfCollection(collectionid) < $scope.maxRequestLimit)) {//check
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxRequestLimit', [$scope.maxRequestLimit]), event);
                return;
            }
            //get user from scope
            let requestBody;
            let requestId;
            let requestName;
            requestId = isNewRequest ? null : $scope.selectedRequest.collectionRequestId;
            requestBody = lodash.assign({}, $scope.requestObj || $scope.requestFormObj);
            requestName = isNewRequest ? $scope.newRequestName : $scope.selectedRequest.requestName;
            //call api
            wltphubUnitarySimulationService.saveRequestToCollection(collectionid, requestId, requestName, { request: requestBody }).then(function (res) {
                $scope.newRequestName = null;
                if (isNewRequest) {
                    $scope.selectedRequest = res; //set current request to new request
                    $scope.selectedCollectionId = collectionid; // set current collectionId
                }
                getAllCollections();// refreshing collections
            }, function (err) {
                showErrorToast(err);
            })
        }

        function getCollectionIdofSelectedRequest() {
            let id = '';
            lodash.forEach($scope.userCollections.collections, function (collection) {
                const req = lodash.find(collection.requests, function (request) {
                    return request.collectionRequestId === $scope.selectedRequest.collectionRequestId
                });
                if (req) {
                    id = collection.collectionId
                }
            });
            return id;
        }

        function deleteRequest(collId, reqId) {

            showConfirm(CultureService.localize('application.view.wltp.unitarySimulation.deleteRequest'), CultureService.localize('application.view.wltp.unitarySimulation.confirmRequestDelete'), event, CultureService.localize('application.view.wltp.yes'), CultureService.localize('application.view.wltp.no')).then(function () {
                //optimistic delete
                const index = lodash.findIndex($scope.userCollections.collections, function (collection) {
                    return collection.collectionId == collId;
                })
                if (index > -1) {
                    if ($scope.selectedRequest && $scope.selectedRequest.collectionRequestId === reqId) {
                        $scope.selectedRequest = null;
                    }
                    $scope.userCollections.collections[index].requests = lodash.filter($scope.userCollections.collections[index].requests, function (request) {
                        return request.collectionRequestId !== reqId;
                    });

                }
                //api call
                wltphubUnitarySimulationService.deleteRequest(reqId).then(function () {
                }).catch(function (err) {
                    showErrorToast(err);
                })
            }).catch(function (err) {
                console.info(err)
            })
        }

        function getAllCollections() {
            wltphubUnitarySimulationService.getAllCollections($scope.userId).then(function (result) {
                console.info(result);
                $scope.userCollections = result;
                $scope.maxCollectionLimit = result.maximumCollectionLimit;
                $scope.maxRequestLimit = result.maximumRequestLimit;
            }, function (err) {
                showErrorToast(err);
            }).catch(function (err) {
                console.info(err)
            })


        }

        function createCollection(callback) {
            //call service with name and user
            wltphubUnitarySimulationService.createCollection({ collectionName: $scope.newCollectionName, userId: $scope.userId }).then(function (res) {
                $scope.newCollectionName = null;
                if (!callback) {
                    getAllCollections();
                } else {
                    if (!typeof callback == 'function') {
                        throw new Error(callback + " is not a function")
                    }
                    callback.call($scope, res.collectionId, true)
                }
            }).catch(function (err) {
                showErrorToast(err);
            })
        }

        function updateCollection(newname, collId) {
            wltphubUnitarySimulationService.updateCollection({ collectionName: newname, collectionId: collId }).then(function () {
                getAllCollections();
            }).catch(function (err) {
                showErrorToast(err);
            })
        }

        function deleteCollection(collId) {

            showConfirm(CultureService.localize('application.view.wltp.unitarysimulation.deleteCollection'), CultureService.localize('application.view.wltp.unitarySimulation.confirmCollectionDelete'), event, CultureService.localize('application.view.wltp.yes'), CultureService.localize('application.view.wltp.no')).then(function () {
                if ($scope.selectedRequest && getCollectionIdofSelectedRequest() === collId) {
                    $scope.selectedRequest = null;
                }

                //optimistic delete
                $scope.userCollections.collections = lodash.filter($scope.userCollections.collections, function (collection) {
                    return collection.collectionId !== collId;
                });

                wltphubUnitarySimulationService.deleteCollection(collId).then(function () {
                    //success
                }).catch(function (err) {
                    showErrorToast(err);
                })
            }).catch(function () { });

        }

        function getSizeOfCollection(collectionId) {
            const collection = lodash.find($scope.userCollections.collections, function (collection) {
                return collection.collectionId === collectionId;
            })

            return collection ? collection.requests.length : 0;
        }

        getAllCollections();




        /*********************************Import export************************************** */

        FileUploader.FileSelect.prototype.isEmptyAfterSelection = function () {
            return true; // true|false
        };

        $scope.uploader = new FileUploader();

        $scope.importExportApi = {
            exportReq: exportReq,
            exportFromForm: exportForm,
            importToForm: importReqFile

        };


        $scope.uploader.onAfterAddingFile = function (item) {
            importReqFile(item._file);
            $scope.uploader.clearQueue();
        }

        function exportForm() {
            const req = lodash.cloneDeep(lodash.assign({}, $scope.requestObj || $scope.requestFormObj));
            exportReq(req)
        }

        function exportReq(req, reqName) {
            if (!req) {
                console.log("request empty");
                return;
            }
            req = lodash.assign({}, {
                version16C: "",
                colorExtInt: "",
                options5C: "",
                options7C: "",
                extensionDate: "",
                mountingCenter: "",
                requestType: "",
                ecomDate: "",
                tradingCountry: "",
                extendedTitleAttributes: "",
                tvv: "",
                requestID:""
            }, req);
            const requestName = reqName ? reqName : $scope.selectedRequest ? $scope.selectedRequest.requestName : 'new';
            const objBlob = new Blob([JSON.stringify(req)], { type: 'application/json' });
            const filename = requestName + '_' + moment().format('DD_MM_YYYY') + '_' + 'export.json';
            if (window.navigator && window.navigator.msSaveOrOpenBlob) { // for IE
                window.navigator.msSaveOrOpenBlob(objBlob, filename);
                return;
            }
            const link = document.createElement('a');
            link.href = URL.createObjectURL(objBlob);
            link.download = filename;
            document.getElementsByTagName('body')[0].appendChild(link);
            link.click();
            if (!('remove' in Element.prototype)) { //for IE
                Element.prototype.remove = function () {
                    if (this.parentNode) {
                        this.parentNode.removeChild(this);
                    }
                };
            }
            link.remove();
        }

        function importReqFile(file) {
            const jsonBlob = new FileReader();
            jsonBlob.readAsText(file);
            jsonBlob.onload = function () {
                try {
                    $scope.reset();
                    const obj = JSON.parse(jsonBlob.result);
                    if (!validateImportObject(obj)) {
                        throw new Error();
                    }
                    $timeout(function () {
                        mapReqToForm(lodash.assign({}, obj));
                    }, 0);
                } catch (err) {
                    showErrorToast(CultureService.localize('application.view.wltp.unitarySimulation.importError'))
                }

            }

        }

        function mapReqToForm(requestObj) {
            $scope.requestFormObj = lodash.assign({}, lodash.omit(requestObj));
        }

        function validateImportObject(obj) {
            const requiredProperties = [
                "version16C",
                "colorExtInt",
                "options5C",
                "options7C",
                "extensionDate",
                "mountingCenter",
                "requestType",
                "ecomDate",
                "tradingCountry",
                "extendedTitleAttributes",
                "tvv",
                "requestID",
            ];
            const objKeys = lodash.keys(obj);

            return lodash.filter(requiredProperties, function (prop) {
                return !lodash.contains(objKeys, prop)
            }).length === 0;

        }


        /*************************************************dialogs and popups*/
        function showPrompt(title, textContent, placeholder, initialValue, ev, required, okayLabel, cancelLabel) {

            var confirm = $mdDialog.prompt()
                .title(title)
                .textContent(textContent)
                .placeholder(placeholder)
                .ariaLabel('popup')
                .initialValue(initialValue)
                .targetEvent(ev)
                .ok(okayLabel || 'OK')
                .cancel(cancelLabel);

            return $mdDialog.show(confirm);
        }

        function showConfirm(title, textContent, ev, okLabel, cancelLabel) {

            var confirm = $mdDialog.confirm()
                .title(title)
                .textContent(textContent)
                .ariaLabel('Confirm Popup')
                .targetEvent(ev)
                .ok(okLabel || 'OK')
                .cancel(cancelLabel);

            return $mdDialog.show(confirm);
        }

        function showAlert(title, textContent, ev, okLabel) {

            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('body')))
                    .clickOutsideToClose(true)
                    .title(title)
                    .textContent(textContent)
                    .ariaLabel('Alert Dialog')
                    .ok(okLabel || 'OK')
                    .targetEvent(ev)
            );
        }

    }]);


    var codeToLabelMap = {};


    function codeToLabel() {
        return function (input) {
            return codeToLabelMap[input] || input;
        }
    }

    return {
        angularModules: ['unitarySimulationSmartCache']
    };
});
