define([
    '{lodash}/lodash'
], function (lodash) {
    'use strict';

    function factoryFunc($http, $resource) {
        return {
            executeSimulation: function (appName, requestObj) {
                let reqBody = lodash.assign({
                    version16C: "",
                    colorExtInt: "",
                    nbOptions: "",
                    nbGestion: "",
                    gestion5C: "",
                    gestion7C: "",
                    options5C: "",
                    options7C: "",
                    extensionDate: "",
                    mountingCenter: "",

                    requestType: "",
                    vin: "",
                    ecomDate: "",
                    tradingCountry: "",
                    extendedTitleAttributes: "",
                    tvv: ""
                }, requestObj);
                return $resource('/api/unitarySimulation/callWltpWS', { appName: appName }).save({ request: reqBody }).$promise;
            },

            getAllCollections: function (userId) {
                return $resource('/api/unitarySimulation/allCollections', { userId: userId }).get().$promise;
            },

            createCollection: function (params) {
                return $resource('/api/unitarySimulation/createCollection', params).save(null).$promise;
            },
            updateCollection: function (params) {
                return $resource('/api/unitarySimulation/updateCollection', params).save(null).$promise;
            },

            deleteCollection: function (collId) {
                return $resource('/api/unitarySimulation/deleteCollection', { collectionId: collId }).save(null).$promise;
            },
            saveRequestToCollection: function (collectionId, requestId, requestName, reqBody) {
                return $resource('/api/unitarySimulation/saveOrUpdateRequestToCollection', { collectionId: collectionId, requestId: requestId, requestName: requestName })
                    .save(reqBody).$promise;
            },

            deleteRequest: function (reqId) {
                return $resource('/api/unitarySimulation/deleteRequest', { requestId: reqId }).save(null).$promise;
            },

            getLabelFromCode: function (code) {
                return $resource('/api/references/measuretypes/:code', { code: code }).get().$promise;
            }

        }
    }

    factoryFunc.$inject = ['$http', '$resource'];

    return factoryFunc;
});
