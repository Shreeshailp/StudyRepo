
define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{lodash}/lodash',
    'moment/moment',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService',
    '{wltp}/services/unitarySimulationService',
    '{angular-file-upload}/angular-file-upload'
], function (angular, angular_resource, lodash, moment, check_role, ComponentRoleCheckService, unitarySimulationService, angularFileUpload) {
    'use strict';

    var module = angular.module('unitarySimulation', ['ngResource', 'ngMaterial', 'i18nitialisation', 'ui.grid', 'ui.grid.autoResize', 'ngAnimate', 'angularFileUpload']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access

    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.factory('unitarySimulationService', unitarySimulationService);
    module.filter('codeToLabel', codeToLabel);
    module.directive('multipleValidator', [function () {
        return {
            restrict: 'AC',
            require: 'ngModel',
            link: function (scope, elem, attr, ngModelCtrl) {

                if (!ngModelCtrl) {
                    return;
                }

                var multiple = parseInt(attr.multipleValidator);

                if (!multiple) {
                    return;
                }

                ngModelCtrl.$validators.multipleValidator = function (modelValue, viewValue) {
                    if (!modelValue) {
                        return true;
                    }
                    return modelValue.length % multiple === 0;
                }
            }
        }
    }])
    module.controller('UnitarySimulationController', ['$q', '$window', '$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', 'FileUploader', '$location', 'AuthorizationService', 'ComponentRoleCheckService', 'unitarySimulationService', '$timeout', 'uiGridConstants', function ($q, $window, $scope, homeService, CultureService, $mdToast, $mdDialog, FileUploader, $location, authorizationService, componentRoleCheckService, unitarySimulationService, $timeout, uiGridConstants) {


        var showErrorToast = function (message) {
            if (message.status === 400) {// jira-618 fixed
                $mdToast.show($mdToast.simple()
                    .textContent(CultureService.localize(message.data.errorMsg))
                    .action(CultureService.localize('application.view.wltp.toast.action.ok')).position('top right')
                    .hideDelay(0));
            }
            else {
                $mdToast.show($mdToast.simple()
                    .textContent(message)
                    .position('top right')
                    .hideDelay(1000)
                );
            }
        };


        $scope.appName = "CALCULWLTP";

        var DEFAULT_FORM_STATE = {
            requestType: 'FULL',
            tradingCountry: 'FR'
        }

        $scope.selectedTab = 0;

        $scope.userId = componentRoleCheckService.getCurrentUser();




        $scope.requestForm;// ng form 

        $scope.requestObj;

        $scope.conversionDataLabelMap = {
            DMTR: "DM_TR"
        }

        $scope.conversionData = [
            {
                code: "DEPOL",
                value: "N"
            },
            {
                code: "SPECIAL",
                value: "N"
            },
            {
                code: "MTACTR",
                value: "2500"
            },
            {
                code: "MCOR",
                value: "1344"
            },
            {
                code: "MOPTTR",
                value: "0"
            },

            {
                code: "DMTR",
                value: "0"
            },
            {
                code: "CATTR",
                value: "M1"
            },
            {
                code: "SCXTR",
                value: "0.65"
            },
            {
                code: "CRRTR",
                value: "7.1"
            },
            {
                code: "RCRRTR",
                value: "4.9"
            },
            {
                code: "STR",
                value: ""
            },
            {
                code: "COOLSTR",
                value: ""
            },
            {
                code: "MROTR",
                value: "1500"
            },
            {
                code: "HTR",
                value: ""
            },
            {
                code: "LTR",
                value: ""
            },
            {
                code: "CXTR",//lot23
                value: "0"
            }
        ]
        $scope.conversionData.forEach(function (elem) {
            elem.value = '';
        });
        $scope.requestFormObj = lodash.assign({}, DEFAULT_FORM_STATE); //ngmodel for the request form
        $scope.responseObj = {}; //only visual

        $scope.loader = false;
        $scope.gridOptions = {
            enableSorting: false,
            enableFiltering: false,
            enableColumnMenus: false,
            enableRowSelection: false,
            enableRowHeaderSelection: false,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            noUnselect: true,
            rowHeight: 30,
            columnDefs: [
                {
                    displayName: '',
                    field: 'type',
                    width: '25%',
                    cellTooltip: true,
                    cellFilter: 'codeToLabel',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.low'),
                    field: 'LOW',
                    cellClass: 'values-per-phase blue'

                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.mid'),
                    field: 'MID',
                    cellClass: 'values-per-phase blue'

                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.high'),
                    field: 'HIGH',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.ehigh'),
                    field: 'EHIGH',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.city'),
                    field: 'CITY',
                    cellClass: 'values-per-phase blue'
                },
                {
                    displayName: CultureService.localize('application.view.wltp.destination.combined'),
                    field: 'COMB',
                    cellClass: 'values-per-phase blue'
                }
            ],
            onRegisterApi: function (gridApi) {
                $scope.gridApi = gridApi;
            },
        };

        var phaseTypes = [];



        $scope.reset = function () {
            $scope.requestObj = null;
            $scope.requestFormObj = lodash.assign({}, DEFAULT_FORM_STATE);
            $scope.conversionData.forEach(function (elem) {
                elem.value = '';
            });
            $scope.responseObj = null;
            $scope.gridOptions.data = [];
            $scope.selectedRequest = null;
            $scope.selectedCollectionId = null;
            $scope.requestForm.$setPristine();
            $scope.requestForm.$setUntouched();
        }

        $scope.sendRequest = function () {
            //save request form to requestObject
            if (!$scope.requestObj) {
                $scope.requestObj = lodash.cloneDeep(lodash.assign({}, $scope.requestFormObj, { conversionData: $scope.conversionData }));
            }


            //map response to RequestObj and set form to pristine
            $scope.loader = true;
            unitarySimulationService.executeSimulation($scope.appName, buildDtoFromRequest($scope.requestObj)).then(function (data) {
                $scope.responseObj = data;
                $scope.loader = false;
                //map response to request form
                $scope.requestFormObj = lodash.assign($scope.requestFormObj, $scope.responseObj.request, function (a, b) {
                    return !a || a != b ? b : a;
                });
                //map response to conversion data form
                //Added the below 2 if-else conditions to fix the get property value null of conversionData
                if($scope.responseObj.request.conversionData == null || $scope.responseObj.request.conversionData == undefined || $scope.responseObj.request.conversionData == "" ||    $scope.responseObj.request.conversionData.lenght == 0){

                        console.log("Conversion data is null");
                }else{
                 mapConversionDataToForm($scope.responseObj.request.conversionData);
                }
                if($scope.responseObj.phase == null || $scope.responseObj.phase == undefined || $scope.responseObj.phase == "" || $scope.responseObj.phase.lenght == 0){

                        console.log("Phase data is null");
                }else{
                 mapPhasetoForm($scope.responseObj.phase);
                }
               
                $scope.requestForm.$setPristine();
                $scope.requestForm.$setUntouched();
            }, function (err) {
                $scope.loader = false;
                showErrorToast(err);
            });

        }
        
        
        
        
        

        function buildDtoFromRequest(requestObj) {
            const dto = lodash.cloneDeep(requestObj);
            //calculate nbgestion/ nbOptions------------------
            dto.nbOptions = dto.options7C ? (dto.options7C.length / 7).toString() : dto.options5C ? (dto.options5C.length / 5).toString() : '';
            dto.nbGestion = dto.gestion7C ? (dto.gestion7C.length / 7).toString() : dto.gestion5C ? (dto.gestion5C.length / 5).toString() : '';

            //determine conversion data block -----
            dto.conversionData = lodash.some(dto.conversionData, function (data) {
                return !!data.value;
            }) ? dto.conversionData : null;

            //return a new object 

            return dto;
        }

        function mapPhasetoForm(phases) {
            if (!phases) {
                $scope.gridOptions.data = [];
                return;
            }
            phaseTypes = [];
            phases.forEach(function (phase) {
                phase.result.forEach(function (type) {
                    phaseTypes.push(type.code)
                });
            });

            phaseTypes = lodash.uniq(phaseTypes)
            let result = [];
            if (phases.length > 0) {
                phaseTypes.forEach(function (type) {
                    let obj = {};
                    obj['type'] = type;
                    lodash.map(phases, function (phase) {
                        obj[phase.code] = lodash.find(phase.result, { 'code': type }) ? lodash.find(phase.result, { 'code': type }).value : '';
                    });
                    result.push(obj);
                });
            }

            let promiseArray = [];
            result.forEach(function (result) {
                if (!codeToLabelMap[result.type]) {
                    promiseArray.push(unitarySimulationService.getLabelFromCode(result.type));
                }
            });
            $q.all(promiseArray).then(function (data) {
                data.forEach(function (data) {
                    codeToLabelMap[data.code] = data.label;
                });
                //Regression issue fix
                result.forEach(function (resultData) {
                    resultData.type=codeToLabelMap[resultData.type];
                });
                $scope.gridOptions.data = result;
            });
        }

        function mapConversionDataToForm(newData) {
            if (!newData || newData.length == 0) {
                return;
            }
            $scope.conversionData.forEach(function (data) {
                //fixed jira-756
                for(let i=0;i<newData.length;i++){
                if(newData[i].code === data.code){
                data.value = lodash.find(newData, { 'code': data.code }).value;
                }}
            });
        }


        $scope.isResponseData = function (code) {
            return !lodash.find($scope.requestObj.conversionData, { 'code': code }).value;
        }
        $scope.getPhysicalValue = function (code) {
            return $scope.responseObj ? (lodash.findIndex($scope.responseObj.physResult, { 'code': code }) > -1 ? lodash.find($scope.responseObj.physResult, { 'code': code }).value : '') : '';
        }


        $scope.$watch('requestForm.$dirty', function (NewValue, oldValue) {
            if (NewValue == true) {
                $scope.requestObj = null;
            }

        }, true);



        // ****************************************************************************collections******************************

        $scope.collectionsApi = {
            loadRequest: loadSelectedRequest,
            updateCollection: updateCollection,
            createNewCollection: createCollectionOnFly,
            createOrUpdateRequest: saveOrUpdate,
            updateRequestName: updateRequestName,
            deleteCollection: deleteCollection,
            deleteRequest: deleteRequest,
            createCollectionPopup: createCollectionPopup,
            toggleInlineEdit: toggleEdit,//takes a callback function as optional parameter
        }

        $scope.maxCollectionLimit;
        $scope.maxRequestLimit;

        $scope.userCollections = {};
        $scope.newCollectionName;
        $scope.newRequestName;
        $scope.selectedRequest;

        $scope.selectedCollectionId;

        $scope.menuState = {};
        $scope.saveToolbar = false;

        $scope.toggle = function (collectionId) {
            $scope.menuState[collectionId] = !$scope.menuState[collectionId];
        };


        $scope.toggleSaveToolbar = function () {
            $scope.newCollectionName = null;
            $scope.newRequestName = null;
            $scope.saveToolbar = !$scope.saveToolbar;
            if ($scope.saveToolbar) {
                $window.onclick = function (event) {
                    var isSelf = event.target.classList.contains('toolbar-toggle-group');
                    var isChild = $window.document.querySelector('.toolbar-toggle-group.panel').contains(event.target)
                    if (isSelf || isChild) return;


                    $timeout(function () {
                        $scope.saveToolbar = false;
                        $window.onclick = null;
                    }, 0);//--> trigger digest cycle and make angular aware. 
                };
            } else {
                $window.onclick = null;
            }
        }


        function toggleEdit(id, callBack) {
            let el = document.getElementById(id);
            if (callBack) {
                setTimeout(lodash.bind(function (event, el) {
                    if (el.classList.contains('editing')) {
                        el.classList.remove('editing');
                    }
                    callBack.call($scope, event.target.value, event.target.id);
                }, this, event, el), 500);
                return;
            }
            if (!el.classList.contains('editing')) {
                el.classList.add('editing')
                el.focus();
            } else {
                el.classList.remove('editing');
            }
        }

        function updateRequestName(newName, requestId) {
            let requestBody;
            let collectionId;

            lodash.forEach($scope.userCollections.collections, function (collection) {
                let req = lodash.find(collection.requests, function (request) {
                    return request.collectionRequestId === requestId;
                });
                if (req) {
                    collectionId = collection.collectionId;
                    requestBody = req.request.request;
                }
            });
            //call api
            unitarySimulationService.saveRequestToCollection(collectionId, requestId, newName, { request: requestBody }).then(function (res) {
                console.log(res);
                //getAllCollections();// refreshing collections
            }, function (err) {
                getAllCollections();
                showErrorToast(err)
            })
        }


        function createCollectionPopup(event) {
            //check if limit reached
            if ($scope.userCollections && !($scope.userCollections.collections.length < $scope.maxCollectionLimit)) {
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxCollectionLimit', [$scope.maxCollectionLimit]), event);
                return;
            }
            //show prompt
            showPrompt(CultureService.localize('application.view.wltp.unitarysimulation.newCollection'),
                CultureService.localize('application.view.wltp.unitarysimulation.nameOfCollection'), '', '', event, true, CultureService.localize('application.view.wltp.unitarysimulation.create'), CultureService.localize('application.view.wltp.unitarysimulation.cancel')).then(function (name) {
                    if (!name) {
                        showErrorToast("Collection name cannot be empty");
                        return;
                    }
                    $scope.newCollectionName = name;
                    createCollection();
                }, function () { })
        }

        function createCollectionOnFly(callBack) {
            if ($scope.userCollections && !($scope.userCollections.collections.length < $scope.maxCollectionLimit)) {//check
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxCollectionLimit', [$scope.maxCollectionLimit]), event);
                return;
            }
            createCollection(callBack);
        }

        function loadSelectedRequest(requestId, collectionId) {
            $scope.reset();
            $scope.selectedTab = 0;
            //set SelectedRequest to request from collections
            let selectedCollection = lodash.find($scope.userCollections.collections, function (collection) {
                return collection.collectionId == collectionId;
            });
            $scope.selectedCollectionId = selectedCollection.collectionId;
            $scope.selectedRequest = lodash.find(selectedCollection.requests, function (request) {
                return request.collectionRequestId == requestId;
            });
            mapReqToForm($scope.selectedRequest.request.request)

        }

        function saveOrUpdate(collectionid, isNewRequest) {

            if (!collectionid) {
                collectionid = getCollectionIdofSelectedRequest();
            }
            //check max limit
            if (isNewRequest && $scope.userCollections && !(getSizeOfCollection(collectionid) < $scope.maxRequestLimit)) {//check
                showAlert('Error', CultureService.localize('application.view.wltp.unitarySimulation.maxRequestLimit', [$scope.maxRequestLimit]), event);
                return;
            }
            //get user from scope
            let requestBody;
            let requestId;
            let requestName;
            requestId = isNewRequest ? null : $scope.selectedRequest.collectionRequestId;
            requestBody = lodash.assign({}, $scope.requestObj || $scope.requestFormObj, { conversionData: $scope.conversionData });
            requestName = isNewRequest ? $scope.newRequestName : $scope.selectedRequest.requestName;
            //call api
            unitarySimulationService.saveRequestToCollection(collectionid, requestId, requestName, { request: requestBody }).then(function (res) {
                $scope.newRequestName = null;
                if (isNewRequest) {
                    $scope.selectedRequest = res; //set current request to new request
                    $scope.selectedCollectionId = collectionid; // set current collectionId
                }
                getAllCollections();// refreshing collections
            }, function (err) {
                showErrorToast(err);
            })
        }

        function getCollectionIdofSelectedRequest() {
            let id = '';
            lodash.forEach($scope.userCollections.collections, function (collection) {
                let req = lodash.find(collection.requests, function (request) {
                    return request.collectionRequestId === $scope.selectedRequest.collectionRequestId
                });
                if (req) {
                    id = collection.collectionId
                }
            });
            return id;
        }

        function deleteRequest(collId, reqId) {

            showConfirm(CultureService.localize('application.view.wltp.unitarySimulation.deleteRequest'), CultureService.localize('application.view.wltp.unitarySimulation.confirmRequestDelete'), event, CultureService.localize('application.view.wltp.yes'), CultureService.localize('application.view.wltp.no')).then(function () {
                //optimistic delete
                let index = lodash.findIndex($scope.userCollections.collections, function (collection) {
                    return collection.collectionId == collId;
                })
                if (index > -1) {
                    if ($scope.selectedRequest && $scope.selectedRequest.collectionRequestId === reqId) {
                        $scope.selectedRequest = null;
                    }
                    $scope.userCollections.collections[index].requests = lodash.filter($scope.userCollections.collections[index].requests, function (request) {
                        return request.collectionRequestId !== reqId;
                    });

                }
                //api call
                unitarySimulationService.deleteRequest(reqId).then(function () {
                }).catch(function (err) {
                    getAllCollections();
                    showErrorToast(err);
                })
            }).catch(function (err) {
                getAllCollections();
                console.info(err)
            })
        }

        function getAllCollections() {
            unitarySimulationService.getAllCollections($scope.userId).then(function (result) {
                console.info(result);
                $scope.userCollections = result;
                $scope.maxCollectionLimit = result.maximumCollectionLimit;
                $scope.maxRequestLimit = result.maximumRequestLimit;
            }, function (err) {
                showErrorToast(err);
            }).catch(function (err) {
                console.info(err)
            })


        }

        function createCollection(callback) {
            //call service with name and user
            unitarySimulationService.createCollection({ collectionName: $scope.newCollectionName, userId: $scope.userId }).then(function (res) {
                $scope.newCollectionName = null;
                if (!callback) {
                    getAllCollections();
                } else {
                    if (!typeof callback == 'function') {
                        throw new Error(callback + " is not a function")
                    }
                    callback.call($scope, res.collectionId, true)
                }
            }).catch(function (err) {
                showErrorToast(err);
            })
        }

        function updateCollection(newname, collId) {
            unitarySimulationService.updateCollection({ collectionName: newname, collectionId: collId }).then(function () {
                getAllCollections();
            }).catch(function (err) {
                getAllCollections();
                showErrorToast(err);
            })
        }

        function deleteCollection(collId) {

            showConfirm(CultureService.localize('application.view.wltp.unitarysimulation.deleteCollection'), CultureService.localize('application.view.wltp.unitarySimulation.confirmCollectionDelete'), event, CultureService.localize('application.view.wltp.yes'), CultureService.localize('application.view.wltp.no')).then(function () {
                if ($scope.selectedRequest && getCollectionIdofSelectedRequest() === collId) {
                    $scope.selectedRequest = null;
                }

                //optimistic delete
                $scope.userCollections.collections = lodash.filter($scope.userCollections.collections, function (collection) {
                    return collection.collectionId !== collId;
                });

                unitarySimulationService.deleteCollection(collId).then(function () {
                    //success
                }).catch(function (err) {
                    getAllCollections();
                    showErrorToast(err);
                })
            }).catch(function () { });

        }

        function getSizeOfCollection(collectionId) {
            let collection = lodash.find($scope.userCollections.collections, function (collection) {
                return collection.collectionId === collectionId;
            })

            return collection ? collection.requests.length : 0;
        }

        getAllCollections();




        /*********************************Import export************************************** */

        FileUploader.FileSelect.prototype.isEmptyAfterSelection = function () {
            return true; // true|false
        };

        $scope.uploader = new FileUploader();

        $scope.importExportApi = {
            exportReq: exportReq,
            exportFromForm: exportForm,
            importToForm: importReqFile

        };


        $scope.uploader.onAfterAddingFile = function (item) {
            importReqFile(item._file);
            $scope.uploader.clearQueue();
        }

        function exportForm() {
            let req = lodash.cloneDeep(lodash.assign({}, $scope.requestObj || $scope.requestFormObj, { conversionData: $scope.conversionData }));
            exportReq(req)
        }

        function exportReq(req, reqName) {
            let requestName;
            if (!req) {
                console.log("request empty");
                return;
            }
            req = lodash.assign({}, {
                version16C: "",
                colorExtInt: "",
                gestion5C: "",
                gestion7C: "",
                options5C: "",
                options7C: "",
                extensionDate: "",
                mountingCenter: "",
                requestType: "",
                vin: "",
                ecomDate: "",
                tradingCountry: "",
                extendedTitleAttributes: "",
                tvv: ""
            }, req);
            requestName = reqName ? reqName : $scope.selectedRequest ? $scope.selectedRequest.requestName : 'new';
            let objBlob = new Blob([JSON.stringify(req)], { type: 'application/json' });
            let filename = requestName + '_' + moment().format('DD_MM_YYYY') + '_' + 'export.json';
            if (window.navigator && window.navigator.msSaveOrOpenBlob) { // for IE
                window.navigator.msSaveOrOpenBlob(objBlob, filename);
                return;
            }
            let link = document.createElement('a');
            link.href = URL.createObjectURL(objBlob);
            link.download = filename;
            document.getElementsByTagName('body')[0].appendChild(link);
            link.click();
            if (!('remove' in Element.prototype)) { //for IE
                Element.prototype.remove = function () {
                    if (this.parentNode) {
                        this.parentNode.removeChild(this);
                    }
                };
            }
            link.remove();
        }

        function importReqFile(file) {
            let jsonBlob = new FileReader();
            jsonBlob.readAsText(file);
            jsonBlob.onload = function () {
                try {
                    $scope.reset();
                    let obj = JSON.parse(jsonBlob.result);
                    if (!validateImportObject(obj)) {
                        throw new Error();
                    }
                    $timeout(function () {
                        mapReqToForm(lodash.assign({}, obj));
                    }, 0);
                } catch (err) {
                    showErrorToast(CultureService.localize('application.view.wltp.unitarySimulation.importError'))
                }

            }

        }

        function mapReqToForm(requestObj) {
            $scope.requestFormObj = lodash.assign({}, lodash.omit(requestObj, 'conversionData'));
            mapConversionDataToForm(requestObj.conversionData)
        }

        function validateImportObject(obj) {
            let requiredProperties = [
                "version16C",
                "colorExtInt",
                "gestion5C",
                "gestion7C",
                "options5C",
                "options7C",
                "extensionDate",
                "mountingCenter",
                "requestType",
                "vin",
                "ecomDate",
                "tradingCountry",
                "extendedTitleAttributes",
                "tvv",
            ];
            let objKeys = lodash.keys(obj);

            return lodash.filter(requiredProperties, function (prop) {
                return !lodash.contains(objKeys, prop)
            }).length === 0;

        }


        /*************************************************dialogs and popups*/
        function showPrompt(title, textContent, placeholder, initialValue, ev, required, okayLabel, cancelLabel) {

            var confirm = $mdDialog.prompt()
                .title(title)
                .textContent(textContent)
                .placeholder(placeholder)
                .ariaLabel('popup')
                .initialValue(initialValue)
                .targetEvent(ev)
                .ok(okayLabel || 'OK')
                .cancel(cancelLabel);

            return $mdDialog.show(confirm);
        }

        function showConfirm(title, textContent, ev, okLabel, cancelLabel) {

            var confirm = $mdDialog.confirm()
                .title(title)
                .textContent(textContent)
                .ariaLabel('Confirm Popup')
                .targetEvent(ev)
                .ok(okLabel || 'OK')
                .cancel(cancelLabel);

            return $mdDialog.show(confirm);
        }

        function showAlert(title, textContent, ev, okLabel) {

            $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('body')))
                    .clickOutsideToClose(true)
                    .title(title)
                    .textContent(textContent)
                    .ariaLabel('Alert Dialog')
                    .ok(okLabel || 'OK')
                    .targetEvent(ev)
            );
        }

    }]);


    var codeToLabelMap={};


    function codeToLabel() {
        return function (input) {
            return codeToLabelMap[input] || input;
        }
    }

    return {
        angularModules: ['unitarySimulation']
    };
});