define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{wltp}/services/changeHistoryService',
    '{lodash}/lodash',
    '{wltp}/guards/check_role',
    '{wltp}/modules/angular-daterangepicker',
    'moment/moment'
], function (angular, angularResource, changeHistoryService, lodash, check_role, angular_daterangepicker, moment) {
    'use strict';


    var module = angular.module('changeHistory', ['ngResource', 'ngMaterial', 'i18nitialisation', 'ui.grid', 'ngAnimate', 'daterangepicker']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access
    module.factory('changeHistoryService', changeHistoryService);
    module.controller('ChangeHistoryController', ['$scope', 'CultureService', 'changeHistoryService', 'uiGridConstants', '$mdToast', function ($scope, CultureService, changeHistoryService, uiGridConstants, $mdToast) {
        var filterMap = {};
        var connectionFailureMessage = CultureService.localize('application.view.wltp.family.connection.failure.message');

        var resourceUnavailableHandler = function () {
            $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
        };
        /////initializes grid options  and other properties
        function init() {
            $scope.isOpened = false;
            $scope.dateToggler = function () {
                $scope.isOpened = !$scope.isOpened;
            };
            $scope.datepicker = {
                date: null,
                onKeyPress: function (event) {
                    if (event.keyCode == 8 && event.target.value == '') {
                        $scope.gridApi.grid.getColumn('timeStamp').filters[0] = {
                            term: ''
                        };
                    } else if (moment(event.target.value, ["YYYY-MM-DD", "YYYY/MM/DD"], true).isValid() && event.keyCode == 13) {
                        $scope.gridApi.grid.getColumn('timeStamp').filters[0] = {
                            term: moment(event.target.value)
                        };
                    }

                },
                options: {
                    singleDatePicker: true,
                    showDropdowns: true,
                    locale: {
                        separator: ' - ',
                        format: "YYYY-MM-DD",
                    },
                    // changeCallback: function(startDate, endDate, label){
                    //     console.info(startDate,endDate, label);
                    // }
                },

            }

            $scope.gridOptions = {
                enableSorting: true,
                enableFiltering: true,
                useExternalFiltering: true,
                enableColumnMenus: false,
                paginationPageSizes: [500],
                paginationPageSize: 500,
                enablePaginationControls: false,
                columnDefs: [
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.dataCategory'),
                        field: 'dataCategory',
                        width: '12%',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.dataId'),
                        field: 'dataId',
                        width: '250',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]

                    },
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.oldValue'),
                        field: 'oldValue',
                        enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.newValue'),
                        field: 'newValue',
                        enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.timestamp'),
                        field: 'timeStamp',
                        width: '18%',
                        sort: {
                            direction: uiGridConstants.DESC,
                        },
                        // enableFiltering: false,
                        //cellFilter: 'date: "yyyy-MM-dd HH:mm:ss"',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event)"></div></div>',

                    },
                    {
                        displayName: CultureService.localize('application.view.wltp.changeHistory.table.header.user'),
                        field: 'user',
                        width: '8%',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    }
                ],


                onRegisterApi: function (gridApi) {
                    $scope.gridApi = gridApi;
                    $scope.gridApi.core.on.filterChanged($scope, $scope.filter);
                },
            };

            $scope.getData();

        };

        ///// Fetches data for table in a IIFE
        $scope.getData = (function () {
            return lodash.debounce(function (query) {

                changeHistoryService.getData(query).then(function (data) {
                    var result = data._embedded.changeHistory || data._embedded.changeHistorySearch
                    $scope.totalRecords = result.length;
                    $scope.gridOptions.data = result;
                    $scope.showingFirst500Records = CultureService.localize('application.view.wltp.first500', [$scope.totalRecords])
                    $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.EDIT);
                }, resourceUnavailableHandler);
            }, 300)
        })();
        /////external filtering function
        $scope.filter = function () {
            $scope.gridApi.grid.columns.forEach(function (column) {
                filterMap[column.name] = moment.isMoment(column.filters[0].term) ? moment(column.filters[0].term).format("YYYY-MM-DD") : column.filters[0].term;
            });

            $scope.getData(filterMap);
        }

        $scope.refresh = function () {
            $scope.filter();
        }

        /////clears filters loads data
        $scope.clearFilters = function () {
            // $scope.gridApi.grid.columns.forEach(function (column) {
            //     column.filters[0].term = '';
            // });
            // $scope.filter();
            $scope.gridApi.core.clearAllFilters();
        };





        /////// init called
        init();



    }]);
    return {
        angularModules: ['changeHistory']
    };
});
