define([
    '{lodash}/lodash'
], function(lodash){
    'use strict';

    function factoryFunc($http, $resource){
        var service = {
            getData: getData
        }
        function trimObject(object){
            return lodash.omit(object,function(value){
               return (!value || lodash.isEmpty(value))
            })
        }
        function getData(query){
            return !lodash.isEmpty(trimObject(query))? $resource('/api/changeHistory/changeHistorySearch').get(trimObject(query)).$promise : $resource('/api/changeHistory').get().$promise;
        }

        return service;
    }

    factoryFunc.$inject=['$http','$resource'];

    return factoryFunc;
});
