define([
    '{angular}/angular',
    '{angular-resource}/angular-resource'

], function(angular) {
    'use strict';

	var notfound = angular.module('notfound', ['ngResource', 'i18nitialisation']);
	notfound.controller('NotFoundController', [ '$scope', function($scope) {
	}]);

    var blank = angular.module('blank', ['ngResource']);
	blank.controller('blankController', [ '$scope', function($scope) {
	}]);

    var error = angular.module('error', ['ngResource']);
	error.controller('ErrorController', [ '$scope', function($scope) {
	}]);

	return {
		angularModules : [ 'notfound', 'blank','error' ]
	};
});
