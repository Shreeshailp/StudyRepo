define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-messages}/angular-messages',
    '{wltp}/services/componentRoleCheckService'

], function(angular, angular_resource, angular_messages, ComponentRoleCheckService) {
    'use strict';

    var module = angular.module('destination', ['ngResource', 'ngMessages', 'i18nitialisation']);
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);

    module.controller('DestinationController', ['$scope', '$routeParams', '$filter', '$mdToast', '$mdDialog', '$route', '$location', 'HomeService', 'CultureService', '$mdDateLocale','ComponentRoleCheckService', function($scope, $routeParams, $filter, $mdToast, $mdDialog, $route, $location, homeService, CultureService, $mdDateLocale, componentRoleCheckService) {
        $scope.componentRoleCheckService = componentRoleCheckService;
        $mdDateLocale.formatDate = function(date) {
            return CultureService.format(date, 'd') || '';
        }
        
        $mdDateLocale.parseDate = function(dateString) {
            return CultureService.parseDate(dateString);
        }
        
        var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');
        var dataUpdateSuccessMessage = $filter('localize')('application.view.wltp.destination.data.update.success.message');
        var deleteSuccessMessage = $filter('localize')('application.view.wltp.destination.record.delete.success.message');
        var confirmDialogHeader = $filter('localize')('application.view.wltp.destination.record.delete.confirm.title');
        var confirmButtonText = $filter('localize')('application.view.wltp.destination.button.delete');
        var deleteButtonText = $filter('localize')('application.view.wltp.destination.button.cancel');

        $scope.cyclePhasesLabels = [];
        $scope.parameterDetailsRows = [];

        $scope.countries = homeService('wltp').enter('countries').get();

        $scope.measuretypes = homeService('wltp').enter('measuretypes').get();

        $scope.vehicletypes = homeService('wltp').enter('vehicletypes').get();

        $scope.cyclephases = homeService('wltp').enter('cyclephases').get();

        $scope.countries.$promise.catch($scope.resourceUnavailableHandler);

        $scope.measuretypes.$promise.catch($scope.resourceUnavailableHandler);

        $scope.vehicletypes.$promise.catch($scope.resourceUnavailableHandler);

        $scope.cyclephases.$promise.then(function() {
            angular.forEach($scope.cyclephases.$embedded('cyclephases'), function(phase) {
                $scope.cyclePhasesLabels[phase.sort] = phase;
            });
        }).catch($scope.resourceUnavailableHandler);

        if ($route.current.params.id === 'create') {
            $scope.editable = true;

            $scope.destination = {};

            $scope.cyclephases.$promise.then(function() {
                $scope.measuretypes.$promise.then(function() {
                    $scope.vehicletypes.$promise.then(function() {
                        $scope.buildDefaultParameterDetails();
                    });
                });
            });
        } else {
            $scope.destination = homeService('wltp').enter('destination', {
                'destination': $routeParams.id
            }).get();

            $scope.destination.$promise.then(function() {
                $scope.editable = false;

                $scope.selectedCountries = $scope.destination.$embedded('countries');
                $scope.fromDate = new Date($scope.destination.fromDate);
                $scope.toDate = new Date($scope.destination.toDate);
                $scope.cyclephases.$promise.then(function() {
                    $scope.measuretypes.$promise.then(function() {
                        $scope.vehicletypes.$promise.then(function() {
                            $scope.buildDefaultParameterDetails();
                            $scope.fillParameterDetails();
                        });
                    });
                });
            }).catch($scope.resourceUnavailableHandler);
        }

        $scope.resourceUnavailableHandler = function() {
            $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
        };

        $scope.buildDefaultParameterDetails = function() {
            angular.forEach($scope.measuretypes.$embedded('measuretypes'), function(measureType) {
                angular.forEach(measureType.vehicleTypes, function(measureTypevehicleType) {
                    var cyclePhases = [];
                    angular.forEach($scope.cyclephases.$embedded('cyclephases'), function(cyclePhase) {
                        cyclePhases[cyclePhase.sort] = {
                            concerned: false,
                            cyclePhaseId: cyclePhase.guid
                        };
                    });

                    var parameterDetail = {
                        label: measureType.label,
                        guid: measureType.guid,
                        vehicleType: $scope.vehicletypes.$embedded('vehicletypes').filter(function(type) {
                            return type.guid === measureTypevehicleType;
                        })[0].label,
                        vehicleTypeId: measureTypevehicleType,
                        cyclePhases: cyclePhases,
                        measureTypeSort: measureType.sort
                    };
                    $scope.parameterDetailsRows.push(parameterDetail);
                });
            });
        };

        $scope.fillParameterDetails = function() {
            angular.forEach($scope.destination.parameterDetails, function(parameter) {
                $scope.parameterDetailsRows.filter(function(row) {
                    return row.guid === parameter.measureType && row.vehicleTypeId === parameter.vehicleType;
                })[0].cyclePhases[$scope.cyclephases.$embedded('cyclephases').filter(function(phase) {
                    return phase.guid === parameter.cyclePhase;
                })[0].sort] = {
                    concerned: parameter.concerned,
                    cyclePhaseId: parameter.cyclePhase
                };
            });
        };

        $scope.clearSearchTerm = function() {
            $scope.searchTerm = '';
        };

        $scope.mdSelectOnKeyDownOverride = function(evt) {
            evt.stopPropagation();
        };

        $scope.editDestination = function() {
            $scope.editable = true;
            $scope.fromDateChange($scope.fromDate);
            $scope.toDateChange($scope.toDate);
        };

        $scope.fromDateChange = function(currentFromDate) {
            if (currentFromDate instanceof Date) {
                $scope.minDate = new Date(
                    currentFromDate.getFullYear(),
                    currentFromDate.getMonth(),
                    currentFromDate.getDate() + 1
                );
            }
        };


        $scope.toDateChange = function(currentToDate) {
            if (currentToDate instanceof Date) {
                $scope.maxDate = new Date(
                    currentToDate.getFullYear(),
                    currentToDate.getMonth(),
                    currentToDate.getDate() - 1
                );
            }
        };

        $scope.cancel = function() {
            if ($route.current.params.id === 'create') {
                $location.path('/wltp/destinations');
            } else {
                $route.reload();
            }
        };

        $scope.deleteDestinationConfirmation = function(ev) {

            var confirm = $mdDialog.confirm()
                .title(confirmDialogHeader)
                .targetEvent(ev)
                .ok(confirmButtonText)
                .cancel(deleteButtonText);

            $mdDialog.show(confirm).then(function() {
                $scope.destination.$remove(function() {
                    $mdToast.show($mdToast.simple()
                        .textContent(deleteSuccessMessage)
                        .position('top right')
                        .hideDelay(1000)
                    );
                    $location.path('/wltp/destinations');
                }, function(error) {
                    $mdToast.show($mdToast.simple()
                        .textContent(CultureService.localize('application.view.wltp.destination.record.delete.failure.message', [error.data.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .position('top right')
                        .hideDelay(0)
                    );
                });
            }, function() {
                return false;
            });
        };

        $scope.saveDestination = function() {
            $scope.destination.parameterDetails = [];
            angular.forEach($scope.parameterDetailsRows, function(row) {
                angular.forEach(row.cyclePhases, function(cyclePhase) {
                    var parameterDetail = {
                        concerned: cyclePhase.concerned,
                        cyclePhase: cyclePhase.cyclePhaseId,
                        measureType: row.guid,
                        vehicleType: row.vehicleTypeId
                    };
                    $scope.destination.parameterDetails.push(parameterDetail);
                });
            });

            $scope.destination.fromDate = $filter('date')($scope.fromDate, 'yyyy-MM-dd');
            $scope.destination.toDate = $filter('date')($scope.toDate, 'yyyy-MM-dd');
            $scope.destination.countries = $scope.selectedCountries.map(function(country) {
                return country.guid;
            });

            if ($route.current.params.id === 'create') {
                homeService('wltp').enter('destinations').save($scope.destination, function(response) {
                    $location.path('/wltp/destinations');
                    $route.updateParams({
                        'id': response.guid
                    });
                }, function(response) {
                    $mdToast.show($mdToast.simple()
                        .textContent(CultureService.localize('application.view.wltp.destination.record.create.failure.message', [response.data.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .position('top right')
                        .hideDelay(0)
                    );
                });
            } else {
                $scope.destination.$save(function() {
                    $mdToast.show($mdToast.simple()
                        .textContent(dataUpdateSuccessMessage)
                        .position('top right')
                        .hideDelay(1000)
                    );
                    $route.reload();
                }, function(error) {
                    $mdToast.show($mdToast.simple()
                        .textContent(CultureService.localize('application.view.wltp.destination.record.update.failure.message', [error.data.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .position('top right')
                        .hideDelay(0)
                    );
                });
            }
        };

    }]);

    return {
        angularModules: ['destination']
    };
});