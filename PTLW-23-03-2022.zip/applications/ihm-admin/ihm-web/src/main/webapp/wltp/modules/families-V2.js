define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{lodash}/lodash',
    'moment/moment',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService',
    '{wltp}/services/families-V2Service'

], function (angular, angular_resource, lodash, moment, angularFileUpload, check_role, ComponentRoleCheckService, familiesV2Service) {
    'use strict';

    var module = angular.module('familiesV2', ['ngResource', 'ngMaterial', 'angularFileUpload', 'i18nitialisation', 'ui.grid', 'ui.grid.pinning', 'ngAnimate', 'daterangepicker', 'ui.grid.selection']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access

    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.factory('familiesV2Service', familiesV2Service);
    module.filter('mapStatus', mapStatus);
    module.filter('indexToString', indexToString);
    module.controller('FamiliesV2Controller', ['$scope', '$q', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', '$timeout', 'FileUploader', '$location', 'AuthorizationService', 'ComponentRoleCheckService', 'familiesV2Service', 'uiGridConstants', '$filter', function ($scope, $q, homeService, CultureService, $mdToast, $mdDialog, $timeout, FileUploader, $location, authorizationService, componentRoleCheckService, familiesV2Service, uiGridConstants, $filter) {

        $scope.componentRoleCheckService = componentRoleCheckService;
        $scope.loading = true;
        $scope.selectedIndex = 0;
        var allFamilies;
        var allFamiliesExtended;
        var physicalQuantityCodes = ['F0', 'F1', 'F2', 'MASSE', 'SCX', 'CRR'];

        $scope.uploader = new FileUploader({
            url: homeService('wltp').getDefinition('families').href + '/upload',
            autoUpload: true
        });

        // /************************************Start : Role Wise Access*************************************/
        // if(!authorizationService.hasRole('wltp', 'wltpaccess')){
        //     $mdToast.show($mdToast.simple()
        //             .textContent("You don't have permission for this tab")
        //             .position('top right')
        //             .hideDelay(1000)
        //         );
        //      $location.path('/wltp/wltphome');
        //      return;
        // }
        // /************************************End : Role Wise Access*************************************/

        var successMessage = CultureService.localize('application.view.wltp.family.upload.success');
        var validFileErrorMessage = CultureService.localize('application.view.wltp.family.upload.error');
        var connectionFailureMessage = CultureService.localize('application.view.wltp.family.connection.failure.message');




        $scope.$on('$locationChangeStart', function () {
            $timeout.cancel($scope.loadTimeOut);
        });

        function toastTemplate() {
            return $mdToast.simple().hideDelay(2000).position('top right');
        }

        $scope.openFileInput = function () {
            document.querySelector('#file').click();
        };

        function clearFileUpload() {
            document.querySelector('#file').value = '';
            $scope.uploader.clearQueue();
        }

        $scope.uploader.filters.push({
            name: 'excelFilter',
            fn: function (item) {
                return ['xlsx', 'xls'].some(function (ext) {
                    return new RegExp('\.' + ext + '$').test(item.name);
                });
            }
        });

        $scope.uploader.onSuccessItem = function (item, response) {
            $mdToast.show(toastTemplate().textContent(successMessage));
            clearFileUpload();
            $location.path('/wltp/family/' + response._embedded.families[0].guid);
        };


        $scope.uploader.onErrorItem = function (item, error, status) {
            if (status === 409) {
                var confirm = $mdDialog.confirm()
                    .title(CultureService.localize('application.view.wltp.families.upload.conflict.title1') + error.errorMsg + CultureService.localize('application.view.wltp.families.upload.conflict.title2'))
                    .textContent(CultureService.localize('application.view.wltp.families.upload.conflict.message'))
                    .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                    .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));

                $mdDialog.show(confirm).then(function () {
                    item.formData = [{
                        forceUpdate: true
                    }];
                    item.upload();
                }).catch(function () {
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.cancelled')));
                    clearFileUpload();
                });
            } else {
                let errorMsg = CultureService.localize('application.view.wltp.upload.errorcode.' + error.errorCode.toString(), [], error.errorMsg.toString());
                $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [errorMsg]))
                    .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                    .hideDelay(0));
                clearFileUpload();
            }
        };

        $scope.uploader.onWhenAddingFileFailed = function () {
            $mdToast.show(toastTemplate().textContent(validFileErrorMessage));
            clearFileUpload();
        };


        familiesV2Service.getFamilies().then(function (data) {
            allFamilies = data._embedded.families;
            //$scope.loading = false;
            init();
        }, function () {
            $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
        });



        /********************************************************GET TAB DATA************************************************************************/
        var familiesWithAdditionalData;
        var familiesWithMappedVqtToPqt;
        var familyInfo;

        function getAdditionalDataForAllFamilies(refresh) {
            if (familiesWithAdditionalData && !refresh) {
                return $q.resolve(familiesWithAdditionalData);
            } else {
                let result = lodash.cloneDeep(allFamilies);
                result.forEach(function (family) {
                    family['additionalData'] = family.familyAdditionalData;
                    delete family.familyAdditionalData;
                });
                familiesWithAdditionalData = result;
                return $q.resolve(familiesWithAdditionalData);
            }

        }

        function getMappedVqtForAllFamilies(refresh) {
            if (familiesWithMappedVqtToPqt && !refresh) {
                return $q.resolve(familiesWithMappedVqtToPqt);
            } else {
                let result = lodash.cloneDeep(allFamilies);
                return $q.all([familiesV2Service.getPhysicalQuantities(), familiesV2Service.getAllTestVehicles()]).then(function (data) {
                    let pqts = data[0]._embedded.physicalquantities.filter(function (pqt) {
                        return physicalQuantityCodes.indexOf(pqt.code) != -1;
                    });

                    result.forEach(function (family) {
                        family.vehicles = data[1].allTestVehicles.filter(function (vehicle) {
                            return vehicle.familyId == family.guid;
                        })
                        family['characteristicData'] = {};
                        family.vehicles.forEach(function (vehicle) {
                            family.characteristicData[vehicle._embedded.type.code] = {};
                            vehicle.quantities.filter(function (quantity) {
                                return lodash.findIndex(pqts, function (pqt) {
                                    return pqt.guid == quantity.type;
                                }) != -1;
                            });
                            vehicle.quantities.forEach(function (quantity) {
                                family.characteristicData[vehicle._embedded.type.code][lodash.find(pqts, function (pqt) {
                                    return pqt.guid == quantity.type
                                }).code] = quantity.value;
                            });
                        });
                    });
                    familiesWithMappedVqtToPqt = result;
                    return result;
                });

            }
        }

        function getTableData(selectedIndex, refresh) {
            switch (selectedIndex) {
                case 0: {
                    return getAdditionalDataForAllFamilies(refresh);

                }
                case 1: {
                    return getAdditionalDataForAllFamilies(refresh);
                }

                case 2: {
                    return getMappedVqtForAllFamilies(refresh)
                }

                default:
                    return $q.resolve([]);
            }
        }


        /*******************************************************************************************************************************/
        ////////////////////////////////tab configuration generator function
        function generateConfig(tabIndex) {
            if (tabIndex == 0) {
                return function () {
                    return [{
                        displayName: $filter('localize')('application.view.wltp.maturity.table.header.status'),
                        field: 'status',
                        cellFilter: 'mapStatus',
                        filterCellFiltered: true,
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.blocked'),
                        field: 'blocked',
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]

                    },
                    {
                        displayName: 'T8C',
                        field: 'code',
                        pinnedLeft: true,
                        width: '60',
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'T8D',
                        field: 'index',
                        type: 'number',
                        cellFilter: 'indexToString',
                        filterCellFiltered: true,
                        width: '60',
                        pinnedLeft: true,
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.designation'),
                        field: 'label',
                        width: '200',
                        pinnedLeft: true,
                        // enableFiltering: false,
                        //cellFilter: 'date: "yyyy-MM-dd HH:mm:ss"',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        //filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event)"></div></div>',

                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.vehiclefamily'),
                        field: 'additionalData.vehicleFamilies',
                        width: '150',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.additionaldata.input.MotorB0F'),
                        field: 'additionalData.motorB0F',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.additionaldata.input.GearboxB0G'),
                        field: 'additionalData.gearBox',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.destination.vehicle.type'),
                        field: 'type',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.roadloadtype'),
                        field: 'roadLoad',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },

                    {
                        displayName: 'Pmax',
                        field: 'pmax',
                        type: 'number',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.additionaldata.input.MotorDKC'),
                        field: 'additionalData.motorDkc',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.tab1.table.header.createdBy'),
                        field: 'createdBy',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.maturity.table.header.createdOn'),
                        field: 'createdOn',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.block.header'),
                        field: 'blockingReason',
                        width: '*',
                        minWidth: 150,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    }
                    ];
                }
            }
            if (tabIndex == 1) {
                return function () {
                    return [{
                        displayName: $filter('localize')('application.view.wltp.maturity.table.header.status'),
                        field: 'status',
                        cellFilter: 'mapStatus',
                        filterCellFiltered: true,
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.blocked'),
                        field: 'blocked',
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]

                    },
                    {
                        displayName: 'T8C',
                        field: 'code',
                        pinnedLeft: true,
                        width: '60',
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'T8D',
                        field: 'index',
                        type: 'number',
                        cellFilter: 'indexToString',
                        filterCellFiltered: true,
                        width: '60',
                        pinnedLeft: true,
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.designation'),
                        field: 'label',
                        width: '200',
                        pinnedLeft: true,
                        // enableFiltering: false,
                        //cellFilter: 'date: "yyyy-MM-dd HH:mm:ss"',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],

                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.vehiclefamily'),
                        field: 'additionalData.vehicleFamilies',
                        width: '150',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.additionaldata.input.MotorB0F'),
                        field: 'additionalData.motorB0F',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.family.additionaldata.input.GearboxB0G'),
                        field: 'additionalData.gearBox',
                        width: '100',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'DLD',
                        field: 'additionalData.dldDate',
                        width: '100',
                        filter: {
                            condition: function (searchTerm, cellValue, row, column) {
                                return searchTerm ? moment(searchTerm).isSame(cellValue, 'day') : true;
                            },
                            rawTerm: true,
                        },
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event,col.field)"></div></div>',
                    },
                    {
                        displayName: 'DLF',
                        field: 'additionalData.dllDate',
                        width: '100',
                        filter: {
                            condition: function (searchTerm, cellValue, row, column) {
                                return searchTerm ? moment(searchTerm).isSame(cellValue, 'day') : true;
                            },
                            rawTerm: true
                        },
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event,col.field)"></div></div>',
                    },

                    {
                        displayName: $filter('localize')('application.view.wltp.firstregdate'),
                        field: 'additionalData.firstRegDate',
                        width: '100',
                        filter: {
                            condition: function (searchTerm, cellValue, row, column) {
                                return searchTerm ? moment(searchTerm).isSame(cellValue, 'day') : true;
                            },
                            rawTerm: true
                        },
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event,col.field)"></div></div>',

                    },
                    {
                        displayName: 'RCE',
                        field: 'additionalData.rceDate',
                        width: '100',
                        filter: {
                            condition: function (searchTerm, cellValue, row, column) {
                                return searchTerm ? moment(searchTerm).isSame(cellValue, 'day') : true;
                            },
                            rawTerm: true
                        },
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event,col.field)"></div></div>',

                    },
                    {
                        displayName: 'Window',
                        field: 'additionalData.window',
                        width: '*',
                        minWidth: 150,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    }
                    ];
                }
            }
            if (tabIndex == 2) {
                return function () {
                    return [{
                        displayName: $filter('localize')('application.view.wltp.maturity.table.header.status'),
                        field: 'status',
                        cellFilter: 'mapStatus',
                        filterCellFiltered: true,
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.blocked'),
                        field: 'blocked',
                        width: '80',
                        pinnedLeft: true,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]

                    },
                    {
                        displayName: 'T8C',
                        field: 'code',
                        pinnedLeft: true,
                        width: '60',
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'T8D',
                        field: 'index',
                        cellFilter: 'indexToString',
                        filterCellFiltered: true,
                        type: 'number',
                        width: '60',
                        pinnedLeft: true,
                        sort: {
                            direction: uiGridConstants.ASC,
                        },
                        //enableFiltering: false,
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: $filter('localize')('application.view.wltp.designation'),
                        field: 'label',
                        width: '200',
                        pinnedLeft: true,
                        // enableFiltering: false,
                        //cellFilter: 'date: "yyyy-MM-dd HH:mm:ss"',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC],
                        //filterHeaderTemplate: '<div class="ui-grid-filter-container row"><div ng-repeat="colFilter in col.filters" id="datepickerfilter" style="position: relative;"> <input date-range-picker class="form-control date-picker" style="width:100%; padding: 0; border: 1px solid #d4d4d4;" ng-model="colFilter.term" options="grid.appScope.datepicker.options" ng-keyup="grid.appScope.datepicker.onKeyPress($event)"></div></div>',

                    },
                    {
                        displayName: 'f0 (VLOW)',
                        field: 'characteristicData.VLOW.F0',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f1 (VLOW)',
                        field: 'characteristicData.VLOW.F1',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f2 (VLOW)',
                        field: 'characteristicData.VLOW.F2',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'Testmass (VLOW)',
                        field: 'characteristicData.VLOW.MASSE',
                        width: '150',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'S/SCx (VLOW)',
                        field: 'characteristicData.VLOW.SCX',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'CRR (VLOW)',
                        field: 'characteristicData.VLOW.CRR',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f0 (VHIGH)',
                        field: 'characteristicData.VHIGH.F0',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f1 (VHIGH)',
                        field: 'characteristicData.VHIGH.F1',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f2 (VHIGH)',
                        field: 'characteristicData.VHIGH.F2',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'Testmass (VHIGH)',
                        field: 'characteristicData.VHIGH.MASSE',
                        width: '150',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'S/SCx (VHIGH)',
                        field: 'characteristicData.VHIGH.SCX',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'CRR (VHIGH)',
                        field: 'characteristicData.VHIGH.CRR',
                        width: '10%',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f0 (VREF)',
                        field: 'characteristicData.VREF.F0',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f1 (VREF)',
                        field: 'characteristicData.VREF.F1',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f2 (VREF)',
                        field: 'characteristicData.VREF.F2',
                        width: '10%',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'Testmass (VREF)',
                        field: 'characteristicData.VREF.MASSE',
                        width: '150',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'S/SCx (VREF)',
                        field: 'characteristicData.VREF.SCX',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'CRR (VREF)',
                        field: 'characteristicData.VREF.CRR',
                        width: '10%',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f0 (VMED)',
                        field: 'characteristicData.VMED.F0',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f1 (VMED)',
                        field: 'characteristicData.VMED.F1',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'f2 (VMED)',
                        field: 'characteristicData.VMED.F2',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'Testmass (VMED)',
                        field: 'characteristicData.VMED.MASSE',
                        width: '150',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'S/SCx (VMED)',
                        field: 'characteristicData.VMED.SCX',
                        width: '100',
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    },
                    {
                        displayName: 'CRR (VMED)',
                        field: 'characteristicData.VMED.CRR',
                        width: '*',
                        minWidth: 150,
                        type: 'number',
                        sortDirectionCycle: [uiGridConstants.ASC, uiGridConstants.DESC]
                    }
                    ];
                }
            } else {
                console.error("No config found");
                return undefined;
            }
        }
        var connectionFailureMessage = CultureService.localize('application.view.wltp.family.connection.failure.message');

        var resourceUnavailableHandler = function () {
            $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
        };
        /////////////////////////////////////////////initializes grid options  and other properties
        function init() {
            $scope.isOpened = false;
            $scope.dateToggler = function () {
                $scope.isOpened = !$scope.isOpened;
            };
            $scope.redirect = function (row) {
                $location.path('/wltp/family/' + row.entity.guid);
            }
            $scope.datepicker = {
                date: null,
                onKeyPress: function (event, field) {
                    if (event.keyCode == 8 && event.target.value == '') {
                        $scope.gridApi.grid.getColumn(field).filters[0].term = null;
                    } else if (moment(event.target.value, ["YYYY-MM-DD", "YYYY/MM/DD"], true).isValid() && event.keyCode == 13) {
                        $scope.gridApi.grid.getColumn(field).filters[0].term = moment(event.target.value);
                    }

                },
                options: {
                    singleDatePicker: true,
                    showDropdowns: true,
                    opens: "left",
                    locale: {
                        separator: ' - ',
                        format: "YYYY-MM-DD",
                    },
                },

            }

            $scope.gridOptions = {
                enableSorting: true,
                enableFiltering: true,
                // useExternalFiltering: true,
                enableColumnMenus: false,
                // paginationPageSizes: [500],
                // paginationPageSize: 500,
                // enablePaginationControls: false,
                enableRowSelection: true,
                enableRowHeaderSelection: false,
                multiSelect: false,
                modifierKeysToMultiSelect: false,
                noUnselect: true,

                onRegisterApi: function (gridApi) {
                    $scope.gridApi = gridApi;
                    gridApi.selection.on.rowSelectionChanged($scope, $scope.redirect)
                },
            }

            $scope.loadTableConfig(0);

        };


        $scope.loadTableConfig = function (selectedIndex) {
            let configFunction = generateConfig(selectedIndex)
            let finalConfig = configFunction();
            $scope.gridOptions.columnDefs = lodash.map(finalConfig, function (column) { //adds cell class to each 
                column.cellClass = function (grid, row) {
                    return row.entity.blocked ? 'famliy-blocked' : '';
                };
                return column;
            });
            $scope.getData(selectedIndex);
        }


        $scope.$watch('selectedIndex', function (newVal, oldVal) {
            if (newVal !== oldVal) {
                $scope.loading = true;
                $timeout(function () {
                    $scope.loadTimeOut = $scope.loadTableConfig(newVal);
                }, 350)

            }
        });

        ///// Fetches data for table in a IIFE
        $scope.getData = (function () {
            return lodash.throttle(function (query, refresh) {
                getTableData(query, refresh).then(function (data) {
                    $scope.loading = false;
                    $scope.totalRecords = data.length;
                    $scope.gridOptions.data = data;
                    //$scope.gridApi && $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);

                }, resourceUnavailableHandler);
            }, 300)
        })();

        $scope.refresh = function () {
            $scope.getData($scope.selectedIndex, true);
        }

        /////clears filters loads data
        $scope.clearFilters = function () {
            $scope.gridApi.core.clearAllFilters();
        };



    }]);

    function mapStatus() {
        var statusHash = {
            I: 'Inwork',
            C: 'Checked',
            V: 'Validated'
        };

        return function (input) {
            if (!input) {
                return '';
            } else {
                return statusHash[input];
            }
        };
    }

    function indexToString() {
        return function (input) {
            if (!lodash.isNumber(input)) { return input }
            input = input.toString()
            if (parseInt(input) < 10) {
                return "0".concat(input)
            }
            return input;
        }
    }

    return {
        angularModules: ['familiesV2']
    };
});