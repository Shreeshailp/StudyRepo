define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'
], function (angular, angular_resource, angularFileUpload, check_role, ComponentRoleCheckService) {
    'use strict';

    var module = angular.module('families', ['ngResource', 'ngMaterial', 'angularFileUpload', 'i18nitialisation']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access

    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('FamiliesController', ['$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', 'FileUploader', '$location', 'AuthorizationService', 'ComponentRoleCheckService', function ($scope, homeService, CultureService, $mdToast, $mdDialog, FileUploader, $location, authorizationService, componentRoleCheckService) {

        $scope.componentRoleCheckService = componentRoleCheckService;

        $scope.uploader = new FileUploader({
            url: homeService('wltp').getDefinition('families').href + '/upload',
            autoUpload: true
        });
        
        // /************************************Start : Role Wise Access*************************************/
        // if(!authorizationService.hasRole('wltp', 'wltpaccess')){
        //     $mdToast.show($mdToast.simple()
        //             .textContent("You don't have permission for this tab")
        //             .position('top right')
        //             .hideDelay(1000)
        //         );
        //      $location.path('/wltp/wltphome');
        //      return;
        // }
        // /************************************End : Role Wise Access*************************************/
        
        var successMessage = CultureService.localize('application.view.wltp.family.upload.success');
        var validFileErrorMessage = CultureService.localize('application.view.wltp.family.upload.error');
        var connectionFailureMessage = CultureService.localize('application.view.wltp.family.connection.failure.message');
        
        function toastTemplate() {
            return $mdToast.simple().hideDelay(2000).position('top right');
        }

        $scope.openFileInput = function() {
            document.querySelector('#file').click();
        };

        function clearFileUpload() {
            document.querySelector('#file').value = '';
            $scope.uploader.clearQueue();
        }

        $scope.uploader.filters.push({
            name: 'excelFilter',
            fn: function(item) {
                return ['xlsx', 'xls'].some(function (ext) {
                    return new RegExp('\.'+ext+'$').test(item.name);
                });
            }
        });

        $scope.uploader.onSuccessItem = function(item, response) {
            $mdToast.show(toastTemplate().textContent(successMessage));
            clearFileUpload();
            $location.path('/wltp/family/' + response._embedded.families[0].guid);
        };


        $scope.uploader.onErrorItem = function(item, error, status) {
            if (status === 409) {
                var confirm = $mdDialog.confirm()
                    .title(CultureService.localize('application.view.wltp.families.upload.conflict.title1')+error.errorMsg+CultureService.localize('application.view.wltp.families.upload.conflict.title2'))
                    .textContent(CultureService.localize('application.view.wltp.families.upload.conflict.message'))
                    .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                    .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));

                $mdDialog.show(confirm).then(function() {
                    item.formData = [{
                        forceUpdate: true
                    }];
                    item.upload();
                }).catch(function() {
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.cancelled')));
                    clearFileUpload();
                });
            } else {
                let errorMsg = CultureService.localize('application.view.wltp.upload.errorcode.' + error.errorCode.toString());
                $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [errorMsg]))
                    .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                    .hideDelay(0));
                clearFileUpload();
            }
        };

        $scope.uploader.onWhenAddingFileFailed = function() {
            $mdToast.show(toastTemplate().textContent(validFileErrorMessage));
            clearFileUpload();
        };

        homeService('wltp').enter('families').get(function(res) {
            $scope.families = res.$embedded('families');
        }, function() {
            $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
        });

    }]);

    return {
        angularModules: ['families']
    };
});