/**
 * 
 */

define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'
], function (angular, angular_resource, angularFileUpload, check_role, ComponentRoleCheckService) {
    'use strict';

    var module = angular.module('maturityImport', ['ngResource', 'ngMaterial', 'angularFileUpload', 'i18nitialisation']);


    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('MaturityImportController', ['$scope', 'HomeService', 'CultureService', '$mdToast', '$mdDialog', 'FileUploader', '$location', 'AuthorizationService', '$route', '$window', '$http', 'ComponentRoleCheckService',
        function ($scope, homeService, CultureService, $mdToast, $mdDialog, FileUploader, $location, authorizationService, $route, $window, $http, componentRoleCheckService) {

            // /************************************Start : Role Wise Access*************************************/
            // if(!authorizationService.hasRole('wltp', 'maturity')){
            //        $mdToast.show($mdToast.simple()
            //                .textContent("You don't have permission for this tab")
            //                .position('top right')
            //                .hideDelay(1000)
            //            );
            //         $location.path('/wltp/wltphome');
            //         return;
            //    }
            // /************************************End : Role Wise Access*************************************/


            $scope.componentRoleCheckService = componentRoleCheckService;
            $scope.uploader = new FileUploader({
                url: homeService('wltp').getDefinition('importMaturity').href + '/upload',
                formData: [{
                    forceUpdate: false
                }],
                autoUpload: true
            });

            var successMessage = CultureService.localize('application.view.wltp.family.upload.success');
            var validFileErrorMessage = CultureService.localize('application.view.wltp.maturity.upload.error');
            var connectionFailureMessage = CultureService.localize('application.view.wltp.family.connection.failure.message');

            $scope.displayView = false;

            $scope.totalRecordCount = 0;

            function toastTemplate() {
                return $mdToast.simple().hideDelay(2000).position('top right');
            }

            $scope.openFileInput = function () {
                document.querySelector('#file').click();
            };

            function clearFileUpload() {
                document.querySelector('#file').value = '';
                $scope.uploader.clearQueue();
            }

            $scope.uploader.filters.push({
                name: 'excelFilter',
                fn: function (item) {
                    var fileExt = ['.xlsx', '.xls'];
                    var fileType = item.name;
                    fileType = fileType.substring(fileType.lastIndexOf('.'));
                    return fileExt.indexOf(fileType) >= 0;
                }
            });

            $scope.uploader.onSuccessItem = function (item, response) {
                $mdToast.show(toastTemplate().textContent(successMessage));
                clearFileUpload();
                $route.reload();

            };

            $scope.uploader.onWhenAddingFileFailed = function () {
                $mdToast.show(toastTemplate().textContent(validFileErrorMessage));
                clearFileUpload();
            };

            $scope.uploader.onErrorItem = function (item, error, status) {
                if (status === 409) {
                    var confirm = $mdDialog.confirm()
                        .title(CultureService.localize('application.view.wltp.maturity.upload.conflict.title1') + error.errorMsg + CultureService.localize('application.view.wltp.maturity.upload.conflict.title2'))
                        .textContent(CultureService.localize('application.view.wltp.families.upload.conflict.message'))
                        .ok(CultureService.localize('application.view.wltp.upload.dialog.action.yes'))
                        .cancel(CultureService.localize('application.view.wltp.upload.dialog.action.no'));

                    $mdDialog.show(confirm).then(function () {
                        item.formData = [{
                            forceUpdate: true
                        }];
                        item.upload();
                    }).catch(function () {
                        $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.cancelled')));
                        clearFileUpload();
                    });
                } else {
                    $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                        .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                        .hideDelay(0));
                    clearFileUpload();
                }
            };



            $scope.search = function () {
                $scope.filterFlag = true;
                $scope.patternFilterExport = $scope.pattern;
                $scope.familyFilterExport = $scope.family;
                $scope.bodyFilterExport = $scope.body;
                $scope.motorFilterExport = $scope.motor;
                $scope.gearboxFilterExport = $scope.gearbox;
                $scope.indexFilterExport = $scope.index;
                $scope.statusFilterExport = $scope.status;

                homeService('wltp').enter('maturitySearch', { 'pattern': $scope.pattern, 'family': $scope.family, 'body': $scope.body, 'motor': $scope.motor, 'gearbox': $scope.gearbox, 'index': $scope.index, 'status': $scope.status }).get(function (res) {
                    $scope.maturityImportData = res.$embedded('maturitySearch');
                    if ($scope.maturityImportData != null && $scope.maturityImportData.length === 0) {
                        $scope.displayView = false;
                    }
                    else if ($scope.maturityImportData != null && $scope.maturityImportData.length > 0) {
                        $scope.displayView = true;
                        $scope.totalRecordCount = $scope.maturityImportData.length
                    }

                }, function () {
                    $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                });

            }
            $scope.resetAll = function () {

                $scope.pattern = '';
                $scope.family = '';
                $scope.body = '';
                $scope.motor = '';
                $scope.gearbox = '';
                $scope.index = '';
                $scope.status = '';
                $scope.filterFlag = false;

                homeService('wltp').enter('importMaturity').get(function (res) {
                    $scope.maturityImportData = res.$embedded('importMaturity');
                    if ($scope.maturityImportData != null && $scope.maturityImportData.length === 0) {
                        $scope.displayView = false;
                    }
                    else if ($scope.maturityImportData != null && $scope.maturityImportData.length > 0) {
                        $scope.displayView = true;
                        $scope.totalRecordCount = $scope.maturityImportData.length;

                    }
                }, function () {
                    $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                });
            }
            // column to sort
            $scope.column = 'pattern';

            // sort ordering (Ascending or Descending). Set true for desending
            $scope.reverse = false;

            // called on header click
            $scope.sortColumn = function (col) {
                $scope.column = col;
                if ($scope.reverse) {
                    $scope.reverse = false;
                    $scope.reverseclass = 'arrow-up';
                } else {
                    $scope.reverse = true;
                    $scope.reverseclass = 'arrow-down';
                }
            };

            // remove and change class
            $scope.sortClass = function (col) {
                if ($scope.column == col) {
                    if ($scope.reverse) {
                        return 'arrow-down';
                    } else {
                        return 'arrow-up';
                    }
                } else {
                    return '';
                }
            }

            fetchMaturityDetails();

            function fetchMaturityDetails() {
                $scope.filterFlag = false;
                homeService('wltp').enter('importMaturity').get(function (res) {
                    $scope.maturityImportData = res.$embedded('importMaturity');
                    $scope.maturityImportDataBytes = res.bytes;
                    if ($scope.maturityImportData != null && $scope.maturityImportData.length === 0) {
                        $scope.displayView = false;
                    }
                    else if ($scope.maturityImportData != null && $scope.maturityImportData.length > 0) {
                        $scope.displayView = true;
                        $scope.totalRecordCount = $scope.maturityImportData.length;

                    }
                }, function () {
                    $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                });
            }

            ////////////////////// Export CODE with filtered////////////////
            function yyyymmdd() {
                var now = new Date();
                var y = now.getFullYear();
                var m = now.getMonth() + 1;
                var d = now.getDate();
                var h = now.getHours();
                var m1 = now.getMinutes();
                return '' + y + '_' + (m < 10 ? '0' : '') + m + '_' + (d < 10 ? '0' : '') + d + '_' + h + m1;
            }

            var data;

            $scope.exportData = function () {
                //if($scope.pattern !=null && $scope.pattern != ''||$scope.family !=null && $scope.family != ''||$scope.body !=null && $scope.body != ''||$scope.motor !=null && $scope.motor != ''||$scope.gearbox !=null && $scope.gearbox != ''||$scope.index !=null && $scope.index != ''||$scope.status !=null && $scope.status != '')
                if ($scope.filterFlag) {
                    homeService('wltp').enter('exportFilterMaturity', { 'pattern': $scope.patternFilterExport, 'family': $scope.familyFilterExport, 'body': $scope.bodyFilterExport, 'motor': $scope.motorFilterExport, 'gearbox': $scope.gearboxFilterExport, 'index': $scope.indexFilterExport, 'status': $scope.statusFilterExport }).get(function (res) {
                        data = res.bytes;
                        const arrayBuffer = base64ToArrayBuffer(data);
                        var blob = new Blob([arrayBuffer], {
                            type: 'application/octet-stream'
                        });
                        var fileName = "calculwltp_maturity_".concat(yyyymmdd(), ".xlsx");
                        if (window.navigator.msSaveOrOpenBlob) {
                            // Store Blob in IE
                            window.navigator.msSaveOrOpenBlob(blob, fileName);
                        } else {
                            // Store Blob in others
                            var anchorElement = document.body.appendChild(document.createElement('a'));
                            anchorElement.href = URL.createObjectURL(blob);
                            anchorElement.download = fileName;
                            anchorElement.style.display = 'none';
                            anchorElement.click();
                            anchorElement.parentNode.removeChild(anchorElement);
                        }
                    }, function (error) {// jira-618 fixed
                        if (error.status === 400) {
                            $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.export.error', [error.data.errorMsg]))
                                .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                                .hideDelay(0));
                        }
                        else {
                            $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                        }
                    });
                }
                else {
                    homeService('wltp').enter('exportMaturity').get(function (res) {
                        data = res.bytes;
                        const arrayBuffer = base64ToArrayBuffer(data);
                        var blob = new Blob([arrayBuffer], {
                            type: 'application/octet-stream'
                        });
                        var fileName = "calculwltp_maturity_".concat(yyyymmdd(), ".xlsx");
                        if (window.navigator.msSaveOrOpenBlob) {
                            // Store Blob in IE
                            window.navigator.msSaveOrOpenBlob(blob, fileName);
                        } else {
                            // Store Blob in others
                            var anchorElement = document.body.appendChild(document.createElement('a'));
                            anchorElement.href = URL.createObjectURL(blob);
                            anchorElement.download = fileName;
                            anchorElement.style.display = 'none';
                            anchorElement.click();
                            anchorElement.parentNode.removeChild(anchorElement);
                        }
                    }, function (error) {// jira-618 fixed
                        if (error.status === 400) {
                            $mdToast.show(toastTemplate().textContent(CultureService.localize('application.view.wltp.export.error', [error.data.errorMsg]))
                                .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                                .hideDelay(0));
                        }
                        else {
                            $mdToast.show(toastTemplate().textContent(connectionFailureMessage));
                        }
                    });
                }
            };

            function base64ToArrayBuffer(base64) {
                const binaryString = $window.atob(base64); // Comment this if not using base64
                const bytes = new Uint8Array(binaryString.length);
                for (var i = 0; i < binaryString.length; i++) {
                    bytes[i] = binaryString.charCodeAt(i);
                }
                return bytes;
            }
        }]);

    return {
        angularModules: ['maturityImport']
    };
});