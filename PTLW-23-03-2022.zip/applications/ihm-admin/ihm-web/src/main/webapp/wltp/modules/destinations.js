define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'

], function(angular, angular_resource,check_role, ComponentRoleCheckService) {
    'use strict';

	var module = angular.module('destinations', ['ngResource', 'i18nitialisation']);

	    
    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access

    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
	module.controller('DestinationsController',  [ '$scope', '$filter', '$mdToast', 'HomeService', 'AuthorizationService','ComponentRoleCheckService', function($scope, $filter, $mdToast, homeService, authorizationService, componentRoleCheckService) {
	    

	    // /************************************Start : Role Wise Access*************************************/
        // if(!authorizationService.hasRole('wltp', 'wltpaccess')){
        //     $mdToast.show($mdToast.simple()
        //             .textContent("You don't have permission for this tab")
        //             .position('top right')
        //             .hideDelay(1000)
        //         );
        //      $location.path('/wltp/wltphome');
        //      return;
        // }
        // /************************************End : Role Wise Access*************************************/
        $scope.componentRoleCheckService = componentRoleCheckService;
        var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');
        homeService('wltp').enter('destinations').get(function (res) {
                $scope.destinations = res.$embedded('destinations');
        },function(response){
                $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
            });

        }]);

	return {
		angularModules : [ 'destinations' ]
	};
});
