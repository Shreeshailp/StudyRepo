define([
    '{angular}/angular',
    '{angular-resource}/angular-resource'

], function(angular) {
    'use strict';

	var module = angular.module('cycle-profile', ['ngResource', 'ngMaterial', 'i18nitialisation']);

	module.controller('CycleProfileController', [ '$scope', '$mdToast', '$filter', '$routeParams', 'HomeService', function($scope, $mdToast, $filter, $routeParams, homeService) {

		var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');

		homeService('wltp').enter('cycle', { 'cycle': $routeParams.id }).get(function (res) {
			$scope.cycle = res;
		}, function(response){
                $mdToast.show($mdToast.simple()
                .textContent(connectionFailureMessage)
                .position('top right')
                .hideDelay(1000)
            );
            });
	}]);

	return {
		angularModules : [ 'cycle-profile' ]
	};
});
