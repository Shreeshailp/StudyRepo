define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{angular-file-upload}/angular-file-upload',
    '{wltp}/guards/check_role',
    '{wltp}/services/componentRoleCheckService'
], function (angular, angular_resource, angularFileUpload, check_role, ComponentRoleCheckService) {
    'use strict';


    var module = angular.module('simulationToyota', ['ngResource', 'ngMaterial', 'angularFileUpload', 'i18nitialisation']);

    // role wise access -> key has to be what was declared in check property of route definition.
    module.value("has_role", check_role);
    // end of role wise access
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('ToyotaSimulationController', ['$scope', '$mdToast', '$filter', '$location', 'HomeService', 'CultureService', 'FileUploader', 'AuthorizationService', 'ComponentRoleCheckService', function ($scope, $mdToast, $filter, $location, homeService, CultureService, FileUploader, authorizationService, componentRoleCheckService) {

        $scope.componentRoleCheckService = componentRoleCheckService;
        $scope.uploader = new FileUploader({
            url: homeService('wltp').getDefinition('toyotasimulation').href,
            formData: [{
                forceUpdate: false
            }],
            autoUpload: true
        });

        // /************************************Start : Role Wise Access*************************************/
        // if(!authorizationService.hasRole('wltp', 'toyotasimulation')){
        //     $mdToast.show($mdToast.simple()
        //             .textContent("You don't have permission for this tab")
        //             .position('top right')
        //             .hideDelay(2000)
        //         );
        //      $location.path('/wltp/wltphome');
        //      return;
        // }
        // /************************************End : Role Wise Access*************************************/

        var successMessage = $filter('localize')('application.view.wltp.family.upload.success');
        var validFileErrorMessage = $filter('localize')('application.view.wltp.simulationToyota.upload.error');
        var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');
        var responseMessage = $filter('localize')('application.view.wltp.simulation.response.error.message');
        var fileGuID, fileContent, exportFileName, fileText;

        $scope.toyotaDisplayView = false;

        $scope.openFileInput = function () {
            document.querySelector('#file').click();
        };

        function clearFileUpload() {
            document.querySelector('#file').value = '';
            $scope.uploader.clearQueue();
        }

        $scope.uploader.filters.push({
            name: 'excelFilter',
            fn: function (item) {
                var fileExt = ['.xml'];
                var fileType = item.name;
                fileType = fileType.substring(fileType.lastIndexOf('.'));
                return fileExt.indexOf(fileType) >= 0;
            }
        });

        $scope.uploader.onSuccessItem = function (item, response) {
            fileGuID = response.fileGuid;
            $scope.fileName = (document.querySelector('#file').value).substr((document.querySelector('#file').value).lastIndexOf('\\') + 1);
            $scope.currentDateTime = new Date();
            $mdToast.show($mdToast.simple()
                .textContent(successMessage)
                .position('top right')
                .hideDelay(2000)
            );
            $scope.toyotaDisplayView = true;
            clearFileUpload();
        };

        $scope.getFile = function () {
            homeService('wltp').enter('gettoyotafile', { 'fileGuid': fileGuID }).get(function (res) {
                if (res.fileStatus === "G") {
                    fileContent = res.answerFileContent;
                    exportFileName = fileGuID + ".xml";
                    fileText = new Blob([fileContent]);
                    if (window.navigator.msSaveOrOpenBlob) {
                        // Store Blob in IE
                        window.navigator.msSaveOrOpenBlob(fileText, exportFileName);
                    } else {
                        // Store Blob in others
                        var anchorElement = document.body.appendChild(document.createElement('a'));
                        anchorElement.href = URL.createObjectURL(fileText);
                        anchorElement.download = exportFileName;
                        anchorElement.style.display = 'none';
                        anchorElement.click();
                        anchorElement.parentNode.removeChild(anchorElement);
                    }
                }
                else {
                    $mdToast.show($mdToast.simple()
                        .textContent(responseMessage)
                        .position('top right')
                        .hideDelay(2000)
                    );
                }
            }, function () {
                $mdToast.show($mdToast.simple()
                    .textContent(connectionFailureMessage)
                    .position('top right')
                    .hideDelay(2000)
                );
            });
        };

        $scope.uploader.onErrorItem = function (item, error, status) {
            if (status === 400 && error.errorCode === "ERRT104") {
                $mdToast.show($mdToast.simple()
                    .textContent(CultureService.localize('application.view.wltp.upload.error', [CultureService.localize('application.view.wltp.simulationToyota.upload.error.maxRequests')]))
                    .position('top right')
                    .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                    .hideDelay(0)
                );
                clearFileUpload();
            }
            else if (status === 400) {
                $mdToast.show($mdToast.simple()
                    .textContent(CultureService.localize('application.view.wltp.upload.error', [error.errorMsg]))
                    .position('top right')
                    .action(CultureService.localize('application.view.wltp.toast.action.ok'))
                    .hideDelay(0)
                );
                clearFileUpload();
            }
        };

        $scope.uploader.onWhenAddingFileFailed = function () {
            $mdToast.show($mdToast.simple()
                .textContent(validFileErrorMessage)
                .position('top right')
                .hideDelay(2000)
            );
            clearFileUpload();
        };

    }]);

    return {
        angularModules: ['simulationToyota']
    };

});