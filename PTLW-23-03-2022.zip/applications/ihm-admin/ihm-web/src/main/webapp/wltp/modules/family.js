define([
    '{angular}/angular',
    '{angular-resource}/angular-resource',
    '{lodash}/lodash',
    '{wltp}/controllers/blockDialogController',
    '{wltp}/services/componentRoleCheckService',
    '{wltp}/modules/angular-daterangepicker',
    'moment/moment',
    '{wltp}/services/familyService'
], function (angular, angular_resource, lodash, block_dialog, ComponentRoleCheckService, angular_daterangepicker, moment, familyService) {
    'use strict';

    var module = angular.module('family', ['ngResource', 'ngMaterial', 'ngMessages', 'i18nitialisation', 'daterangepicker']);
    module.factory('ComponentRoleCheckService', ComponentRoleCheckService);
    module.controller('block_dialog', block_dialog);
    module.factory('family_service', familyService);
    module.controller('FamilyController', ['$scope', '$q', '$location', 'HomeService', '$timeout', '$mdToast', '$routeParams', '$filter', '$mdDialog', 'AuthenticationService', 'ComponentRoleCheckService', 'family_service',
        function ($scope, $q, $location, homeService, $timeout, $mdToast, $routeParams, $filter, $mdDialog, authenticationService, componentRoleCheckService, family_service) {

            $scope.componentRoleCheckService = componentRoleCheckService
            var familyRef = null;
            /* **********************************utility functions**************************************************** */
            var connectionFailureMessage = $filter('localize')('application.view.wltp.family.connection.failure.message');
            var physicalQuantityCodes = ['F0', 'F1', 'F2', 'MASSE', 'SCX', 'CRR'];
            var resourceUnavailableHandler = function () {
                $mdToast.show($mdToast.simple()
                    .textContent(connectionFailureMessage)
                    .position('top right')
                    .hideDelay(1000)
                );
            };

            var onErrorToast = function (message) {
                if (message.status === 400) {
                    $mdToast.show($mdToast.simple()
                        .textContent(message.data.errorMsg)
                        .position('top right')
                        .action($filter('localize')('application.view.wltp.toast.action.ok'))
                        .hideDelay(0));


                }
                else {
                    $mdToast.show($mdToast.simple()
                        .textContent(connectionFailureMessage)
                        .position('top right')
                        .hideDelay(1000)
                    );
                }
            };

            var infoToast = function (message) {
                $mdToast.show($mdToast.simple()
                    .textContent(message)
                    .position('top right')
                    .hideDelay(1000)
                );
            }

            var onSuccessToast = function (message) {
                $mdToast.show($mdToast.simple()
                    .textContent(message)
                    .position('top right')
                    .hideDelay(1000)
                );
            };

            var confirmToast = function (title, message, okLabel, cancelLabel) {
                var confirm = $mdDialog.confirm()
                    .title(title)
                    .textContent(message)
                    .ariaLabel('Confirm')
                    .ok(okLabel)
                    .cancel(cancelLabel);
                return $mdDialog.show(confirm);
            }

            function buildDto() {
                return lodash.assign({}, {
                    vehicleFamilies: $scope.formInputs.vehicleFamily.value && $scope.formInputs.vehicleFamily.value.toString() || null,
                    motorB0F: $scope.formInputs.moteurB0F.value && $scope.formInputs.moteurB0F.value.code.toString() || null,
                    motorDkc: $scope.formInputs.moteurDKC.value && $scope.formInputs.moteurDKC.value.toString() || null,
                    gearBox: $scope.formInputs.boite.value && $scope.formInputs.boite.value.code.toString() || null,
                    dldDate: $scope.formInputs.dateFields.dldDate.date && moment($scope.formInputs.dateFields.dldDate.date).format("YYYYMMDD") || null,
                    dllDate: $scope.formInputs.dateFields.dllDate.date && moment($scope.formInputs.dateFields.dllDate.date).format("YYYYMMDD") || null,
                    firstRegDate: $scope.formInputs.dateFields.dateFirstReg.date && moment($scope.formInputs.dateFields.dateFirstReg.date).format("YYYYMMDD") || null,
                    rceDate: $scope.formInputs.dateFields.rceDate.date && moment($scope.formInputs.dateFields.rceDate.date).format("YYYYMMDD") || null,
                    window: $scope.formInputs.window.value && $scope.formInputs.window.value.toString() || null,
                    urlDossier: $scope.formInputs.url1.value && $scope.formInputs.url1.value.toString() || null,
                    urlPv: $scope.formInputs.url2.value && $scope.formInputs.url2.value.toString() || null,
                    urlImportFile: $scope.formInputs.url3.value && $scope.formInputs.url3.value.toString() || null
                })
            }

            var canUserCheck = function () {
                if ($scope.isImportUser && !componentRoleCheckService.isAdmin())
                    return $filter('localize')('application.view.wltp.family.isimportuser.error');
                else return null;
            }

            var onRouteChange = function (event, newUrl) {
                var newPath = $location.path()
                if ($scope.anyDataChanged) {
                    routeChangeOff();
                    confirmToast($filter('localize')('application.view.wltp.family.additionaldata.unsavedchangestitle'), $filter('localize')('application.view.wltp.family.additionaldata.unsavedchangesheader'), $filter('localize')('application.view.wltp.save'), $filter('localize')('application.view.wltp.cancel')).then(function () {
                        family_service.saveAdditionalData(buildDto(), {
                            t8c: familyRef.t8C,
                            t8d: familyRef.t8D
                        }).then(function () {
                            $scope.additionalDataStatus.loading = false;
                            $scope.anyDataChanged = false;
                            $scope.additionalDataStatus.editing = false;
                            $location.path(newPath);
                        });
                    }, function () {

                        $location.path(newPath);
                    });
                    event.preventDefault();
                }
            }


            var insertCheckboxFlag = lodash.once(function () {
                if (($scope.currentStatus == $scope.status.validated || currentStatus == $scope.status.checked) && lodash.isEmpty($scope.checkboxes)) {
                    $scope.checkboxes.REF = false;
                    $scope.checkboxes.CHAR = false;
                    $scope.family['vehicles'].forEach(function (vehicle) {
                        if (vehicle._embedded.type.code != 'VREF')
                            $scope.checkboxes[vehicle._embedded.type.code] = false;
                    });
                    for (let tab in $scope.checkboxes) {
                        $scope.checkboxes[tab] = true;
                        updateTabCheckFlag(tab, true).then(function () {

                        }, function (error) {
                            onErrorToast(error);
                        });
                    }
                }
            });

            var routeChangeOff = $scope.$on('$locationChangeStart', onRouteChange);

            /* *********************************************************end********************************************************** */

            /* ********************************************additional data begin****************************************************/
            $scope.additionalDataInit = lodash.once(function () {
                $scope.additionalDataStatus = {
                    loading: true,
                    saving: false,
                    editing: false
                }
                $scope.anyDataChanged = false;
                $scope.additionalDataArray = null;
                $scope.formInputs = {
                    vehicleFamily: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.vehclefamily'),
                        value: null
                    },
                    moteurB0F: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.MotorB0F'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.moteurB0F) || null,
                        options: [],
                        filters: {
                            codeSearch: '',
                            frLabelSearch: ''
                        },
                        clearSearchTerm: function () {
                            $scope.formInputs.moteurB0F.filters.codeSearch = '';
                            $scope.formInputs.moteurB0F.filters.frLabelSearch = '';
                        }
                    },

                    moteurDKC: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.MotorDKC'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.moteurDKC) || null
                    },
                    boite: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.GearboxB0G'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.boite) || null,
                        options: [],
                        filters: {
                            codeSearch: '',
                            frLabelSearch: ''
                        },
                        clearSearchTerm: function () {
                            $scope.formInputs.boite.filters.codeSearch = '';
                            $scope.formInputs.boite.filters.frLabelSearch = '';
                        }
                    },
                    window: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.window'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.window) || null
                    },
                    url1: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.url1'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.url1) || null
                    },
                    url2: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.url2'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.url2) || null
                    },
                    url3: {
                        field: $filter('localize')('application.view.wltp.family.additionaldata.input.url3'),
                        value: ($scope.additionalDataArray && $scope.additionalDataArray.url3) || null
                    },
                    dateFields: {
                        dldDate: {
                            field: $filter('localize')('application.view.wltp.family.additionaldata.input.dlddate'),
                            value: function () {
                                return moment.isMoment(this.date) ? moment(this.date).format("DD-MM-YYYY") : null;
                            },
                            date: ($scope.additionalDataArray && $scope.additionalDataArray.dldDate) || {}, // put {} for no date or wrap date in moment object before assigning
                            options: {
                                parentEl: '#dld-date',
                            }
                        },
                        dllDate: {
                            field: $filter('localize')('application.view.wltp.family.additionaldata.input.dlldate'),
                            value: function () {
                                return moment.isMoment(this.date) ? moment(this.date).format("DD-MM-YYYY") : null;
                            },
                            date: ($scope.additionalDataArray && $scope.additionalDataArray.dllDate) || {},
                            options: {
                                parentEl: '#dll-date',
                            }
                        },
                        dateFirstReg: {
                            field: $filter('localize')('application.view.wltp.family.additionaldata.input.datefirstreg'),
                            value: function () {
                                return moment.isMoment(this.date) ? moment(this.date).format("DD-MM-YYYY") : null;
                            },
                            date: ($scope.additionalDataArray && $scope.additionalDataArray.dateFirstReg) || {},
                            options: {
                                parentEl: '#firstReg-date',

                            },

                        },

                        rceDate: {
                            field: $filter('localize')('application.view.wltp.family.additionaldata.input.rcedate'),
                            value: function () {
                                return moment.isMoment(this.date) ? moment(this.date).format("DD-MM-YYYY") : null;
                            },
                            date: ($scope.additionalDataArray && $scope.additionalDataArray.rceDate) || {},
                            options: {
                                parentEl: '#rce-date',

                            },

                        }
                    },

                };

                $scope.getDropDownDetails = function () {
                    return $q.all([family_service.getAllMoteurDetails(), family_service.getAllGearBoxDetails()]).then(function (data) {
                        $scope.formInputs.moteurB0F.options = data[0]._embedded.moturesGareBox;
                        $scope.formInputs.boite.options = data[1]._embedded.moturesGareBox;
                        return data;
                    }, function (err) {
                        resourceUnavailableHandler();
                        console.error(err);
                    });
                }

                $scope.saveData = function () {
                    $scope.additionalDataStatus.loading = true;
                    family_service.saveAdditionalData(buildDto(), {
                        t8c: familyRef.t8C,
                        t8d: familyRef.t8D
                    }).then(function () {
                        $scope.additionalDataStatus.loading = false;
                        $scope.anyDataChanged = false;
                        $scope.additionalDataStatus.editing = false;
                    }, function (error) {// jira-618 fixed
                        if (error.status === 400) {
                            $scope.additionalDataStatus.editing = false;
                            $scope.anyDataChanged = false;
                            $scope.additionalDataArray = null;
                            getAdditionalData();
                            onErrorToast(error);
                        }
                    });
                }

                $scope.cancelChanges = function () {
                    $scope.additionalDataStatus.editing = false;
                    $scope.anyDataChanged = false;
                    $scope.additionalDataArray = null;
                    getAdditionalData();
                }

                for (let dateField in $scope.formInputs.dateFields) {
                    $scope.formInputs.dateFields[dateField].options['singleDatePicker'] = true;
                    $scope.formInputs.dateFields[dateField].options['showDropdowns'] = true;
                    $scope.formInputs.dateFields[dateField].options.locale = {
                        separator: ' - ',
                        format: "DD-MM-YYYY",
                    }
                };

                function mapAdditionalData(data) {
                    return lodash.assign(data, {
                        vehicleFamily: data.vehicleFamilies,
                        moteurB0F: lodash.find($scope.formInputs.moteurB0F.options, function (option) {
                            return option.code == data.motorB0F;
                        }),
                        moteurDKC: data.motorDkc,
                        boite: lodash.find($scope.formInputs.boite.options, function (option) {
                            return option.code == data.gearBox;
                        }),
                        dldDate: data.dldDate ? moment(data.dldDate) : null,
                        dllDate: data.dllDate ? moment(data.dllDate) : null,
                        dateFirstReg: data.firstRegDate ? moment(data.firstRegDate) : null,
                        rceDate: data.rceDate ? moment(data.rceDate) : null,
                        window: data.window,
                        url1: data.urlDossier,
                        url2: data.urlPv,
                        url3: data.urlImportFile
                    })
                };


                var getAdditionalData = function () {
                    $scope.additionalDataStatus.loading = true;
                    $scope.getDropDownDetails().then(function (data) {
                        family_service.getAdditionalData({
                            t8c: familyRef.t8C,
                            t8d: familyRef.t8D
                        }).then(function (data) {
                            $scope.additionalDataArray = mapAdditionalData(data);
                            $scope.additionalDataStatus.loading = false;
                        }, resourceUnavailableHandler);

                    })
                };

                $scope.$watch('additionalDataArray', function (NewValue, oldValue) {
                    if (!lodash.isEqual(NewValue, oldValue) && NewValue != null) {
                        $scope.formInputs.vehicleFamily.value = NewValue.vehicleFamily;
                        $scope.formInputs.moteurB0F.value = NewValue.moteurB0F;
                        $scope.formInputs.moteurDKC.value = NewValue.moteurDKC;
                        $scope.formInputs.boite.value = NewValue.boite;
                        $scope.formInputs.dateFields.dldDate.date = NewValue.dldDate;
                        $scope.formInputs.dateFields.dllDate.date = NewValue.dllDate;
                        $scope.formInputs.dateFields.dateFirstReg.date = NewValue.dateFirstReg;
                        $scope.formInputs.dateFields.rceDate.date = NewValue.rceDate;
                        $scope.formInputs.window.value = NewValue.window;
                        $scope.formInputs.url1.value = NewValue.url1;
                        $scope.formInputs.url2.value = NewValue.url2;
                        $scope.formInputs.url3.value = NewValue.url3;
                    }

                }, true);

                $scope.$watchGroup([
                    'formInputs.vehicleFamily.value',
                    'formInputs.moteurB0F.value',
                    'formInputs.moteurDKC.value',
                    'formInputs.boite.value',
                    'formInputs.dateFields.dldDate.value()',
                    'formInputs.dateFields.dllDate.value()',
                    'formInputs.dateFields.dateFirstReg.value()',
                    'formInputs.dateFields.rceDate.value()',
                    'formInputs.window.value',
                    'formInputs.url1.value',
                    'formInputs.url2.value',
                    'formInputs.url3.value'
                ], function (NewValue, oldValue) {
                    if (!lodash.isEqual(oldValue, NewValue) && $scope.additionalDataStatus.editing) { //add another condition for cancel changes
                        $scope.anyDataChanged = true;
                    }
                });

                getAdditionalData() // first time init


            });


            /* ***********************************************************end***************************************************** */


            $scope.status = {
                inWork: 'I',
                checked: 'C',
                validated: 'V'
            };

            $scope.checkedTabs = [];
            $scope.checkTabList = [];

            $scope.alert = '';


            $scope.familyResource = homeService('wltp').enter('family', {
                'family': $routeParams.id
            }).get();

            $scope.familyResource.$promise.then(function (family) {
                for (var cycle in family.cycles)
                    $scope[cycle.toLowerCase()] = family.cycles[cycle];

                $scope.filteredPhysicalQuantityTypes.then(function (physicalQuantities) {
                    angular.forEach(family.vehicles, function (vehicle) {
                        var quantities = [];
                        physicalQuantities.forEach(function (pqt) {
                            if ((family.roadLoad == "MRL") && (pqt.code == "SCX")) {
                                pqt.label = $filter('localize')('application.view.wltp.family.frontalarea');
                            } else if (family.roadLoad == "DRL" && pqt.code == "SCX") {//fix of Jira-494 starts here
                                pqt.label = $filter('localize')('application.view.wltp.tvv.table.header.height');
                            } else if (family.roadLoad == "DRL" && pqt.code == "CRR") {
                                pqt.label = $filter('localize')('application.view.wltp.tvv.table.header.width');
                            }//fix of jira-494 ends here
                            var quantity = vehicle.quantities.filter(function (q) {
                                return q.type == pqt.guid
                            })[0];
                            quantities.push({
                                sort: pqt.sort,
                                value: quantity ? quantity.value : ''
                            });
                        });
                        vehicle.quantities = quantities;
                    });
                    $scope.family = family;
                    familyRef = Object.freeze({
                        t8C: family.code,
                        t8D: family.index
                    });
                    getTabCheckStatus();

                });

            }).catch(resourceUnavailableHandler);

            $scope.filteredPhysicalQuantityTypes = homeService('wltp').enter('physicalquantities').get().$promise.then(function (res) {
                return res.$embedded('physicalquantities');
            }).then(filterPhysicalQuantityTypes);

            function filterPhysicalQuantityTypes(types) {
                return types.filter(function (t) {
                    return physicalQuantityCodes.indexOf(t.code) != -1;
                });
            }


            $scope.cyclephases = homeService('wltp').enter('cyclephases').get();

            $scope.cyclePhases = [];
            $scope.cyclephases.$promise.then(function () {
                angular.forEach($scope.cyclephases.$embedded('cyclephases'), function (phase) {
                    $scope.cyclePhases[phase.sort] = phase;
                });
            }).catch(resourceUnavailableHandler);


            $scope.currentTab = function (vehicle) {
                function currentTab() {
                    $scope.measures = [];
                    vehicle.measures.forEach(function (vehicleMeasure) {
                        var displayedMeasure = $scope.measures.filter(function (m) {
                            return vehicleMeasure.type === m.type;
                        }).shift();
                        if (!displayedMeasure) {
                            $scope.measures.push(displayedMeasure = {
                                type: vehicleMeasure.type,
                                sort: vehicleMeasure._embedded.type.sort,
                                label: vehicleMeasure._embedded.type.label,
                                values: new Array($scope.cyclePhases.length)
                            });
                        }
                        displayedMeasure.values[vehicleMeasure._embedded.phase.sort] = vehicleMeasure.value;
                    });
                }

                $scope.cyclephases.$promise.then(currentTab);
            };

            function getTabCheckStatus() {
                family_service.getFamilyTabCheckStatus({
                    T8C: familyRef.t8C.toString(),
                    T8D: familyRef.t8D.toString()
                }).then(function (data) {
                    initCheckboxes(data._embedded.familyTabCheckFlages);
                }, resourceUnavailableHandler)
            }

            function initCheckboxes(checkboxStatus) {
                $scope.currentStatus = $scope.family.status;
                $scope.blocked = $scope.family.blocked;
                $scope.totalCheckBoxCount = 2 + $scope.family.vehicles.filter(function (vehicle) {
                    return vehicle._embedded.type.code != 'VREF'
                }).length;
                $scope.checkboxes = {};
                checkboxStatus.forEach(function (tab) {
                    $scope.checkboxes[tab.tabId] = tab.checkFlag;
                });
                //insertCheckboxFlag(); //function to insert checkflags in DB if status not in alignment in FAM.
                // $scope.checkboxes.REF = false;
                // $scope.checkboxes.CHAR = false;
                // $scope.family['vehicles'].forEach(function (vehicle) {
                //     $scope.checkboxes[vehicle._embedded.type.code] = false;
                // });
                // //$scope.checkboxes.additionalData = false;


                $scope.checkTabList = lodash.keys($scope.checkboxes);
                $scope.checkedTabs = $scope.checkTabList.filter(function (tab) {
                    return $scope.checkboxes[tab] == true;
                });
                $scope.isImportUser = ($scope.componentRoleCheckService.getCurrentUser() == $scope.family.createdBy) ? true : false;
                $scope.$watch('checkedTabs', function (NewValue, oldValue) {
                    if (!lodash.isEqual(NewValue, oldValue)) {
                        if ($scope.checkedTabs.length == Math.max($scope.checkTabList.length, $scope.totalCheckBoxCount)) {
                            updateStatus($scope.status.checked).then(function () {
                                $scope.currentStatus = $scope.status.checked;
                            }, function (error) {// jira-618 fixed
                                if (error.status === 400) {
                                    onErrorToast(error);
                                }
                                else {
                                    resourceUnavailableHandler();
                                }
                            })
                        } else if (oldValue.length == $scope.checkTabList.length && NewValue.length < oldValue.length) {
                            updateStatus($scope.status.inWork).then(function () {
                                $scope.currentStatus = $scope.status.inWork;
                            }, function (error) {// jira-618 fixed
                                if (error.status === 400) {
                                    onErrorToast(error);
                                }
                                else {
                                    resourceUnavailableHandler();
                                }
                            })
                        }
                    }
                }, true);

            }


            $scope.toggleCheckbox = function (item, list) {
                if (canUserCheck()) {
                    infoToast(canUserCheck());
                    event.preventDefault()
                    $scope.checkboxes[item] = !$scope.checkboxes[item];
                    return;
                }
                var index = list.indexOf(item);
                if (index > -1) {
                    updateTabCheckFlag(item, false).then(function () {
                        list.splice(index, 1);
                    }, function (error) {
                        onErrorToast(error);
                        $scope.checkboxes[item] = !$scope.checkboxes[item];
                    });
                } else {
                    updateTabCheckFlag(item, true).then(function () {
                        list.push(item);
                    }, function (error) {
                        onErrorToast(error);
                        $scope.checkboxes[item] = !$scope.checkboxes[item];
                    });;
                }
            }

            $scope.uncheckAll = function () {
                if (canUserCheck()) {
                    infoToast(canUserCheck());
                    event.preventDefault()
                    return;
                }
                $scope.checkedTabs.forEach(function (tab) {
                    $scope.checkboxes[tab] = false;
                    updateTabCheckFlag(tab, false).then(function () {

                    }, function (error) {
                        $scope.checkboxes[tab] = true; // jira-618 fixed
                    });
                });
                // $scope.checkedTabs = [];
                updateStatus($scope.status.inWork).then(function () {
                    $scope.currentStatus = $scope.status.inWork;
                    $scope.checkedTabs = [];
                }, function (error) {// jira-618 fixed
                    if (error.status === 400) {
                        onErrorToast(error);
                    }
                    else {
                        resourceUnavailableHandler();
                    }
                });
            }

            $scope.statusCheck = function () {
                if ($scope.currentStatus == $scope.status.validated) {
                    return $scope.status.validated;
                }
                if ($scope.checkedTabs.length == Math.max($scope.checkTabList.length, $scope.totalCheckBoxCount)) {
                    return $scope.status.checked;
                } else {
                    return $scope.status.inWork;
                }
            };


            $scope.validate = function () {
                updateStatus($scope.status.validated).then(function () {
                    $scope.currentStatus = $scope.status.validated;
                }, function (error) {// jira-618 fixed
                    if (error.status === 400) {
                        onErrorToast(error);
                    }
                    else {
                        resourceUnavailableHandler();
                    }
                })
            };

            function updateStatus(status) {
                return family_service.changeStatus({
                    code: familyRef.t8C,
                    index: familyRef.t8D,
                    status: status
                });
            }

            function blockToggle(blocked, blockReason) {
                return family_service.toggleBlock({
                    code: familyRef.t8C,
                    index: familyRef.t8D,
                    blocked: blocked,
                    blockingReason: blockReason
                });
            }

            function updateTabCheckFlag(tabID, checked) {
                return family_service.changeTabStatus({
                    t8C: familyRef.t8C,
                    t8D: familyRef.t8D.toString(),
                    tabId: tabID.toString(),
                    checkFlag: checked
                });
            }

            $scope.toggleBlock = function (ev) {
                if (!$scope.blocked) {
                    $mdDialog.show({
                        controller: block_dialog,
                        templateUrl: 'wltp/views/block-dialog.tmpl.html',
                        parent: angular.element(document.body),
                        clickOutsideToClose: false,
                        locals: {
                            reason: ''
                        }
                    })
                        .then(function (blockingForm) {
                            blockFamily(blockingForm);
                        }, function () {

                        });
                } else {

                    blockToggle(false, '').then(function () {
                        $scope.blocked = false;
                        $scope.family.blocked = false;
                        $scope.family.blockingReason = null;
                    }, function (error) {// jira-618 fixed
                        if (error.status === 400) {
                            onErrorToast(error);
                        }
                        else {
                            resourceUnavailableHandler();
                        }
                    })
                }
            };


            var blockFamily = function (blockingForm) {
                //    blockingForm.$setUntouched();
                //    blockingForm.$setPristine();
                blockToggle(true, blockingForm.reason.$viewValue).then(function () {
                    $scope.blocked = true;
                    $scope.family.blocked = true;
                    $scope.family.blockingReason = blockingForm.reason.$viewValue;
                }, function (error) {// jira-618 fixed
                    if (error.status === 400) {
                        onErrorToast(error);
                    }
                    else {
                        resourceUnavailableHandler();
                    }
                })
            };




        }
    ]);

    return {
        angularModules: ['family']
    };
});
