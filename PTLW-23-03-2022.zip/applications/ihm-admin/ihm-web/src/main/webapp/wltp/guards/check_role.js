define([], function () {
    'use strict';

    function checkRole(AuthorizationService, $q, $mdToast, $location,$route) {

        var  allowed_roles = $route.routes[$location.path()].allowed_roles || [];

        return $q(function (resolve, reject) {

            var hasAccess = false;

            if (_.isEmpty(allowed_roles)) {
                hasAccess = false;
            } else {
                hasAccess = allowed_roles.some(function (role) {
                    return AuthorizationService.hasRole('wltp', role);
                });
            }
            if (!hasAccess) {
                $mdToast.show($mdToast.simple()
                    .textContent("You don't have permission for this tab")
                    .position('top right')
                    .hideDelay(1000)
                );
                $location.path('/wltp/wltphome');
            }else{
            resolve();
            }

        });

    }


    checkRole.$inject = ["AuthorizationService", "$q", "$mdToast", "$location","$route"];
    return checkRole;
});

