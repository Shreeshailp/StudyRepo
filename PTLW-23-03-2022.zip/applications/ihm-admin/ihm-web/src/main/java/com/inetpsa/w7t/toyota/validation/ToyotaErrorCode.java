/*
 * Creation : 29 sept. 2017
 */
package com.inetpsa.w7t.toyota.validation;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum ToyotaErrorCode.
 */
public enum ToyotaErrorCode implements ErrorCode {

    WLTP_TIMEOUT_EXCEPTION(614, "WLTP Timeout exception occured", "ERRT101"),

    /** The wltphub timeout exception. */
    WLTPHUB_TIMEOUT_EXCEPTION(702, "Timeout error while calling WLTPHUB", "ERRW702"),

    FILE_PARSING_EXCEPTION(615, "Error in parsing file", "ERRT102"),

    DUPLICATE_FILE_ID(604, "Duplicate file ID", "ERRT100"),

    UNKNOWN_EXCEPTION(616, "Unknown Technical Exception", "ERRT103"),

    MAX_NUMBER_REQUESTS_EXCEPTION(699, "Maximum number of requests is reached. Please cut your request file.", "ERRT104"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new WS request error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    ToyotaErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }

}
