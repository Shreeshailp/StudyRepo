/*
 * Creation : 28 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleErrorCode;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleException;

/**
 * TODO : Description.
 *
 * @author E562493
 */
@Provider
public class GeneratedCycleExceptionMapper implements ExceptionMapper<GeneratedCycleException> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
     */
    @Override
    public Response toResponse(GeneratedCycleException exception) {

        Status status = Response.Status.BAD_REQUEST;

        String ruleCode = ((GeneratedCycleErrorCode) exception.getErrorCode()).getRuleCode();
        if ("RG18".equals(ruleCode))
            status = Response.Status.CONFLICT;

        return Response.status(status).entity(configureError(exception)).build();
    }

    /**
     * Configure error.
     *
     * @param exception the exception
     * @return the WLTP error
     */
    private WLTPError configureError(GeneratedCycleException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    /**
     * The Class WLTPError.
     */
    class WLTPError {

        /** The error code. */
        private String errorCode;

        /** The error msg. */
        private String errorMsg;

        /**
         * Gets the error code.
         *
         * @return the error code
         */
        public String getErrorCode() {
            return errorCode;
        }

        /**
         * Sets the error code.
         *
         * @param errorCode the new error code
         */
        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        /**
         * Gets the error msg.
         *
         * @return the error msg
         */
        public String getErrorMsg() {
            return errorMsg;
        }

        /**
         * Sets the error msg.
         *
         * @param errorMsg the new error msg
         */
        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }

}
