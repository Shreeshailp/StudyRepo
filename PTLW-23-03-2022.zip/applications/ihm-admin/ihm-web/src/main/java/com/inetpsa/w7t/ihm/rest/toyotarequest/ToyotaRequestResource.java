/*
 * Creation : 2 May 2018
 */
package com.inetpsa.w7t.ihm.rest.toyotarequest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.ToyotaRequestBatchRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.ToyotaRequestBatchEntity;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.toyota.service.MarketingService;
import com.inetpsa.w7t.toyota.validation.ToyotaErrorCode;
import com.inetpsa.w7t.toyota.validation.ToyotaException;

/**
 * The ToyotaRequestResource is meant to upload the Toyota Simulation file and to provide the response of the same.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.TOYOTASIMULATION)
public class ToyotaRequestResource {

    /** The toyota in directory. */
    @Configuration("toyotaInputDirectory")
    private File toyotaInDirectory;

    /** The toyota out directory. */
    @Configuration("toyotaOutputDirectory")
    private File toyotaOutDirectory;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The toyota request batch repository. */
    @Inject
    private ToyotaRequestBatchRepository toyotaRequestBatchRepository;

    /** The toyota request batch factory. */
    @Inject
    private Factory<ToyotaRequestBatchEntity> toyotaRequestBatchFactory;

    /** The marketing service. */
    @Inject
    private MarketingService marketingService;

    /** The fs flag file path. */
    @Configuration("fsFlagFilePath")
    private String fsFlagFilePath;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant SUFFIX. */
    @Configuration("marketingSimulationSuffix")
    private String suffix;

    /** The prefix. */
    @Configuration("filePrefix")
    private String prefix;

    /**
     * Upload.
     *
     * @param file            the file
     * @param fileDisposition the file disposition
     * @return the response
     */
    @Rel(value = CatalogRels.TOYOTASIMULATION, home = true)
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") File file, @FormDataParam("file") FormDataContentDisposition fileDisposition) {
        ManualRequestFile mrFile = new ManualRequestFile();
        try {
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new ToyotaException(ToyotaErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            FileHandlingUtility.createFsFlagFile(fsFlagFilePath, indusFlagFilePath, prefix + "_MARKETING", suffix);
            logger.info("Marketing request file upload successful");
            ToyotaRequestBatchEntity newTRB = toyotaRequestBatchFactory.create();
            newTRB.setRequestDate(LocalDateTime.now());
            newTRB.setStatus("R");
            newTRB.setClient("MARKETING");
            toyotaRequestBatchRepository.persist(newTRB);
            logger.info("Marketing Request Batch Entry created:{}", newTRB.getEntityId());
            mrFile.setFileGuid(newTRB.getEntityId().toString());

            StringBuilder newName = new StringBuilder(newTRB.getEntityId().toString()).append("_input").append(".xml");
            StringBuilder destFilePath = new StringBuilder().append(toyotaInDirectory.getAbsolutePath()).append(File.separator).append(newName);
            File inFile = moveFileToToyotaIN(file, destFilePath.toString());
            logger.info("Marketing Request file renamed and moved to path:{}", inFile.getAbsolutePath());
            boolean wltphubFlag = false;
            marketingService.getEmissionResult(inFile.getAbsolutePath(), wltphubFlag);
            FileHandlingUtility.deleteApplicationFsFlagFile(fsFlagFilePath, prefix + "_MARKETING");
        } catch (ToyotaException e) {
            // fixed jira-617
            FileHandlingUtility.deleteApplicationFsFlagFile(fsFlagFilePath, prefix + "_MARKETING");
            logger.error("Error in Marketing request file", e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            // fixed jira-617
            FileHandlingUtility.deleteApplicationFsFlagFile(fsFlagFilePath, prefix + "_MARKETING");
            logger.error("Unknown error processing file or answer", e);
            throw new ToyotaException(ToyotaErrorCode.UNKNOWN_EXCEPTION, null);
        }
        return Response.ok(mrFile).build();

    }

    /**
     * Status check.
     *
     * @param fileGuid the file guid
     * @return the response
     */
    @Path("{" + CatalogRels.FILE_GUID + "}")
    @Rel(value = CatalogRels.TOYOTA_GET_FILE, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response statusCheck(@PathParam("fileGuid") String fileGuid) {
        try {
            StringBuilder xmlString = new StringBuilder();
            AnswerFile fAnswer = new AnswerFile();

            StringBuilder answerFilePath = new StringBuilder(toyotaOutDirectory.getAbsolutePath()).append(File.separator).append(fileGuid)
                    .append("_output").append(".xml");
            ToyotaRequestBatchEntity trbObject = toyotaRequestBatchRepository.load(UUID.fromString(fileGuid));
            logger.info("Marketing answer file has status {}", trbObject.getStatus());

            if (("G").equals(trbObject.getStatus())) {
                try (FileReader fr = new FileReader(answerFilePath.toString())) {
                    try (BufferedReader br = new BufferedReader(fr)) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            xmlString.append(line.trim());
                        }
                        logger.info("Marketing answer file downloaded");
                    } catch (IOException e) {
                        logger.error(e.getMessage(), e);
                        fAnswer.setFileStatus("I");
                        return Response.ok(fAnswer).build();
                    }
                }
            }
            fAnswer.setFileStatus(trbObject.getStatus());
            fAnswer.setAnswerFileContent(xmlString);
            return Response.ok(fAnswer).build();
        } catch (IllegalArgumentException e) {
            logger.error("File name does not contain a UUID", e);
            return Response.status(Response.Status.BAD_REQUEST).entity("").build();
        } catch (Exception e) {
            logger.error("Unexpected error!", e.getMessage(), e);
            return Response.status(Response.Status.BAD_REQUEST).entity("").build();
        }
    }

    /**
     * Move file to toyota IN.
     *
     * @param infile       the infile
     * @param destFilePath the dest file path
     * @return the file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static File moveFileToToyotaIN(File infile, String destFilePath) throws IOException {
        if (infile != null && infile.isFile()) {
            File destfile = new File(destFilePath);
            FileUtils.moveFile(infile, destfile);
            return destfile;
        }
        throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to move file to '/in' folder");
    }

    /**
     * Class to build JSON response for status check method of Marketing Simulation.
     */
    class AnswerFile {

        /** The answer file content. */
        private StringBuilder answerFileContent;

        /** The file status. */
        private String fileStatus;

        /**
         * Gets the answer file content.
         *
         * @return the answer file content
         */
        public StringBuilder getAnswerFileContent() {
            return answerFileContent;
        }

        /**
         * Sets the answer file content.
         *
         * @param answerFileContent the new answer file content
         */
        public void setAnswerFileContent(StringBuilder answerFileContent) {
            this.answerFileContent = answerFileContent;
        }

        /**
         * Gets the file status.
         *
         * @return the file status
         */
        public String getFileStatus() {
            return fileStatus;
        }

        /**
         * Sets the file status.
         *
         * @param fileStatus the new file status
         */
        public void setFileStatus(String fileStatus) {
            this.fileStatus = fileStatus;
        }

    }

    /**
     * Class to build JSON response for upload method of Toyota Simulation.
     */
    class ManualRequestFile {

        /** The file guid. */
        private String fileGuid;

        /**
         * Gets the file guid.
         *
         * @return the file guid
         */
        public String getFileGuid() {
            return fileGuid;
        }

        /**
         * Sets the file guid.
         *
         * @param fileGuid the new file guid
         */
        public void setFileGuid(String fileGuid) {
            this.fileGuid = fileGuid;
        }

    }

}
