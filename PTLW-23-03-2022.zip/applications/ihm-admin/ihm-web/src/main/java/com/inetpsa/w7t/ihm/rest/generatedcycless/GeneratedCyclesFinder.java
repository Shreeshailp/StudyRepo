/*
 * Creation : 9 Apr 2019
 */
package com.inetpsa.w7t.ihm.rest.generatedcycless;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface GeneratedCyclesFinder.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface GeneratedCyclesFinder {

    /**
     * All.
     *
     * @return the collection representation
     */
    CollectionRepresentation all();

    /**
     * Filter.
     *
     * @param filter the filter
     * @return the collection representation
     */
    CollectionRepresentation filter(GeneratedCyclesFilter filter);

}