/*
 * Creation : 11 Jul 2019
 */
package com.inetpsa.w7t.ihm.rest.depol;

import java.util.List;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface DepolFinder {

    CollectionRepresentation all();

    CollectionRepresentation filter(DepolFilter filter);

    List<Depol> allDepols();
}
