/*
 * Creation : 21 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class CollecctionWrapper.
 */
public class CollectionWrapper {

    /** The maximum collection limit. */
    private String maximumCollectionLimit;

    /** The maximum request limit. */
    private String maximumRequestLimit;

    /** The collections. */
    List<CollectionDto> collections = new ArrayList<>();

    /**
     * Gets the maximum collection limit.
     *
     * @return the maximum collection limit
     */
    public String getMaximumCollectionLimit() {
        return maximumCollectionLimit;
    }

    /**
     * Sets the maximum collection limit.
     *
     * @param maximumCollectionLimit the new maximum collection limit
     */
    public void setMaximumCollectionLimit(String maximumCollectionLimit) {
        this.maximumCollectionLimit = maximumCollectionLimit;
    }

    /**
     * Gets the maximum request limit.
     *
     * @return the maximum request limit
     */
    public String getMaximumRequestLimit() {
        return maximumRequestLimit;
    }

    /**
     * Sets the maximum request limit.
     *
     * @param maximumRequestLimit the new maximum request limit
     */
    public void setMaximumRequestLimit(String maximumRequestLimit) {
        this.maximumRequestLimit = maximumRequestLimit;
    }

    /**
     * Gets the collections.
     *
     * @return the collections
     */
    public List<CollectionDto> getCollections() {
        return collections;
    }

    /**
     * Sets the collections.
     *
     * @param collections the new collections
     */
    public void setCollections(List<CollectionDto> collections) {
        this.collections = collections;
    }

    /**
     * Instantiates a new collecction wrapper.
     *
     * @param collections the collections
     */
    public CollectionWrapper(List<CollectionDto> collections) {
        super();
        this.collections = collections;
    }

}
