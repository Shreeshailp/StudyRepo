/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface MeasureTypeFinder. This finder is used to retrieve representations of {@link MeasureType} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface MeasureTypeFinder {

    /**
     * Retrieve a specific {@link MeasureType} representation identified by its {@code code} or its UUID entity id.
     *
     * @param measureType the measure type identifier
     * @return an optional measure type representation
     */
    Optional<MeasureTypeRepresentation> get(String measureType);

    /**
     * Retrieve a specific {@link MeasureType} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return an optional measure type representation
     */
    Optional<MeasureTypeRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link MeasureType} representation identified by its {@code code}.
     *
     * @param code the code
     * @return an optional measure type representation
     */
    Optional<MeasureTypeRepresentation> byCode(@MeasureTypeCode String code);

    /**
     * All.
     *
     * @return the measure types representation
     */
    CollectionRepresentation all();
}
