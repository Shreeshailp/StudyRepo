/*
 * Creation : 29 Jul 2021
 */
package com.inetpsa.w7t.application.utilities;

import java.io.InputStream;

public class FileInputValidator {

    /**
     * Checks if is not null.
     *
     * @param inputStream the input stream
     * @return true, if is not null
     */
    public static boolean isNotNull(InputStream inputStream) {
        boolean result = false;
        if (inputStream != null) {
            result = true;
        }
        return result;
    }

    private FileInputValidator() {
        // do nothing
    }

}
