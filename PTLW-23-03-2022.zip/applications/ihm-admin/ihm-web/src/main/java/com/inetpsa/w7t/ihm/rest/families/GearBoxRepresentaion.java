/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.GearBoxEntity;

/**
 * @author E569186
 */
@DtoOf(GearBoxEntity.class)
public class GearBoxRepresentaion extends AbstractGearBoxRepresentation {

}
