/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.Validation;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.families.model.details.TestVehicleDetails;
import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.domains.references.validation.TestVehicleTypeCode;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.MeasureValueRepresentation;
import com.inetpsa.w7t.ihm.rest.families.PhysicalQuantityValueRepresentation;
import com.inetpsa.w7t.ihm.rest.families.TestVehicleRepresentation;
import com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeRepresentation;

/**
 * The Class TestVehicleTypeJpaFinder. This is the JPA Implementation of the {@link TestVehicleTypeFinder}.
 */
public class TestVehicleTypeJpaFinder implements TestVehicleTypeFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";
    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder#all()
     */
    @Override
    public CollectionRepresentation all() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> q = cb.createQuery(TestVehicleType.class);
        Root<TestVehicleType> root = q.from(TestVehicleType.class);

        TypedQuery<TestVehicleType> query = entityManager.createQuery(q.select(root));

        List<TestVehicleTypeRepresentation> testVehicleTypesList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(TestVehicleTypeRepresentation.class);

        testVehicleTypesList.stream().forEach(testVehicleType -> {
            testVehicleType.setLabel(labelService.value(testVehicleType.getGuid()));
            testVehicleType.self(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).set(CatalogRels.TEST_VEHICLE_TYPE, testVehicleType.getGuid()));
        });

        CollectionRepresentation testVehicleTypes = new CollectionRepresentation(testVehicleTypesList.size(), false);

        testVehicleTypes.self(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPES).templated());
        testVehicleTypes.link("find", relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).templated());
        testVehicleTypes.embedded(CatalogRels.TEST_VEHICLE_TYPES, testVehicleTypesList);

        return testVehicleTypes;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder#get(java.lang.String)
     */
    @Override
    public Optional<TestVehicleTypeRepresentation> get(String testVehicletype) {
        if (Validation.buildDefaultValidatorFactory().getValidator().validateValue(TestVehicleType.class, CODE, testVehicletype).isEmpty())
            return byCode(testVehicletype);
        return byId(testVehicletype);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder#byId(java.lang.String)
     */
    @Override
    public Optional<TestVehicleTypeRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> q = cb.createQuery(TestVehicleType.class);
        Root<TestVehicleType> c = q.from(TestVehicleType.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<TestVehicleType> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        List<TestVehicleType> list = query.getResultList();
        Optional<TestVehicleType> testVehicleTypeObj = Optional.empty();
        if (!list.isEmpty()) {
            testVehicleTypeObj = list.stream().findFirst();
        }

        Optional<TestVehicleTypeRepresentation> testVehicletype = testVehicleTypeObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(TestVehicleTypeRepresentation.class));

        testVehicletype.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).set(CatalogRels.TEST_VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPES).templated());
        });

        return testVehicletype;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder#byCode(java.lang.String)
     */
    @Override
    public Optional<TestVehicleTypeRepresentation> byCode(@TestVehicleTypeCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> q = cb.createQuery(TestVehicleType.class);
        Root<TestVehicleType> c = q.from(TestVehicleType.class);
        q.where(cb.equal(c.get(CODE), cb.lower(cb.parameter(String.class, CODE))));

        TypedQuery<TestVehicleType> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        List<TestVehicleType> list = query.getResultList();
        Optional<TestVehicleType> testVehicleTypeObj = Optional.empty();
        if (!list.isEmpty()) {
            testVehicleTypeObj = list.stream().findFirst();
        }

        Optional<TestVehicleTypeRepresentation> testVehicletype = testVehicleTypeObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(TestVehicleTypeRepresentation.class));

        testVehicletype.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).set(CatalogRels.TEST_VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPES).templated());
        });

        return testVehicletype;
    }

    @SuppressWarnings("unchecked")
    public List<TestVehicleRepresentation> getAllTestVehicles() {
        Query query = entityManager.createNativeQuery("SELECT tvh.* FROM W7TQTTVH tvh RIGHT JOIN W7TQTFAM fam ON fam.ID=tvh.FAMILY_ID",
                TestVehicleDetails.class);

        List<TestVehicleRepresentation> testVehicles = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(TestVehicleRepresentation.class);
        testVehicles.stream().forEach(vehicle -> {
            vehicle.embedded("type", byId(vehicle.getType()).get());
        });
        testVehicles.stream().forEach(testVehicle -> {
            testVehicle.setQuantities(getPhysicalQuantities(testVehicle.getGuid()));
        });
        testVehicles.stream().forEach(testVehicle -> {
            testVehicle.setMeasures(getMeasuredValues(testVehicle.getGuid()));
        });

        return testVehicles;
    }

    /**
     * Gets the measured values.
     *
     * @param uuid the uuid
     * @return the measured values
     */
    @SuppressWarnings("unchecked")
    private List<MeasureValueRepresentation> getMeasuredValues(String uuid) {
        List<MeasureValueRepresentation> measuredValues = new ArrayList<>();
        Query query = entityManager.createNativeQuery("SELECT TYPE, PHASE, VALUE FROM W7TQTMVL WHERE VEHICLE_ID = ?");
        query.setParameter(1, uuid);
        List<Object[]> list = query.getResultList();
        list.stream().forEach(obj -> {
            if (obj != null) {
                MeasureValueRepresentation measuredValue = new MeasureValueRepresentation();
                measuredValue.setType((obj[0].toString()));
                measuredValue.setPhase(obj[1].toString());
                measuredValue.setValue(Double.valueOf(obj[2].toString()));
                measuredValues.add(measuredValue);
            }
        });
        return (measuredValues);
    }

    /**
     * Gets the physical quantities.
     *
     * @param uuid the uuid
     * @return the physical quantities
     */
    @SuppressWarnings("unchecked")
    private List<PhysicalQuantityValueRepresentation> getPhysicalQuantities(String uuid) {
        List<PhysicalQuantityValueRepresentation> quantities = new ArrayList<>();
        Query query = entityManager.createNativeQuery("SELECT TYPE, VALUE FROM W7TQTPQV WHERE VEHICLE_ID = ?");
        query.setParameter(1, uuid);
        List<Object[]> list = query.getResultList();
        list.stream().forEach(obj -> {
            if (obj != null) {
                PhysicalQuantityValueRepresentation pqv = new PhysicalQuantityValueRepresentation();
                pqv.setType((obj[0].toString()));
                pqv.setValue(Double.valueOf(obj[1].toString()));
                quantities.add(pqv);
            }
        });
        return (quantities);
    }

}
