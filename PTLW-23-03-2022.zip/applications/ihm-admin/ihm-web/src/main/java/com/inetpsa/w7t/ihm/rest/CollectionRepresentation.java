/*
 * Creation : 6 juin 2017
 */
package com.inetpsa.w7t.ihm.rest;

import org.seedstack.seed.rest.hal.HalRepresentation;

/**
 * The Class CollectionRepresentation. This representation is used to represent a list of {@link HalRepresentation};
 */
public class CollectionRepresentation extends HalRepresentation {

    /** The count. */
    private int count;

    /** The filtered. */
    private boolean filtered;

    /**
     * Instantiates a new collection representation.
     */
    public CollectionRepresentation() {
        super();
    }

    /**
     * Instantiates a new collection representation.
     *
     * @param count the count
     * @param filtered the filtered
     */
    public CollectionRepresentation(int count, boolean filtered) {
        super();
        this.count = count;
        this.filtered = filtered;
    }

    /**
     * Gets the count.
     *
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * Sets the count.
     *
     * @param count the new count
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * Checks if the collection is filtered.
     *
     * @return true, if it is filtered
     */
    public boolean isFiltered() {
        return filtered;
    }

    /**
     * Sets the filtered state.
     *
     * @param filtered the new filtered state
     */
    public void setFiltered(boolean filtered) {
        this.filtered = filtered;
    }
}
