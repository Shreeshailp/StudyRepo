/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.ihm.rest.maturityrequest;

import javax.ws.rs.QueryParam;

public class MaturityFilter {
    @QueryParam("pattern")
    public String pattern;

    @QueryParam("family")
    public String family;

    @QueryParam("body")
    public String body;

    @QueryParam("motor")
    public String motor;

    @QueryParam("gearbox")
    public String gearbox;

    @QueryParam("index")
    public String index;

    @QueryParam("status")
    public String status;
}
