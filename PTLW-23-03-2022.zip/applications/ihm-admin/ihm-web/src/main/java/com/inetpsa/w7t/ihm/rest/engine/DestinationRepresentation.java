/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.enginesettings.model.Destination;

/**
 * The Class DestinationRepresentation. It represents JSON for Destination summary
 * 
 * @see Destination
 */
@DtoOf(Destination.class)
public class DestinationRepresentation extends AbstractDestinationRepresentation {
}
