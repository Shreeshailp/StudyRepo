/*
 * Creation : 30 May 2018
 */
package com.inetpsa.w7t.toyota.service.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.toyota.validation.ToyotaException;

@Provider
public class ToyotaExceptionMapper implements ExceptionMapper<ToyotaException> {

    @Override
    public Response toResponse(ToyotaException exception) {

        return Response.status(Response.Status.BAD_REQUEST).entity(configureError(exception)).build();
    }

    private WLTPError configureError(ToyotaException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    class WLTPError {
        private String errorCode;
        private String errorMsg;

        public String getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }

}
