/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.MaturityParserService;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityErrorCode;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityException;
import com.inetpsa.w7t.domains.maturity.model.MaturityDto;

/**
 * The Class MaturityParserServiceImpl.
 */
public class MaturityParserServiceImpl implements MaturityParserService {

    /** The Constant SEVEN. */
    private static final int SEVEN = 7;

    /** The Constant ONE. */
    private static final int ONE = 1;

    /** The Constant TWO. */
    private static final int TWO = 2;

    /** The Constant FOUR. */
    private static final int FOUR = 4;

    /** The Constant SIX. */
    private static final int SIX = 6;

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.MaturityParserService#parse(java.io.InputStream)
     */
    @Override
    public List<MaturityDto> parse(InputStream inputStream) throws IOException, MaturityException {
        MaturityDto t = null;
        List<MaturityDto> list = new ArrayList<>();
        XSSFWorkbook myWorkBook = new XSSFWorkbook(inputStream);
        try {

            int rowCount = 0;

            XSSFSheet firstSheet = myWorkBook.getSheetAt(0);
            checkHeaders(firstSheet);
            // Iterator<Row> iterator = firstSheet.iterator();
            // while (iterator.hasNext()) {
            // Row nextRow = iterator.next();
            int phyRowCount = firstSheet.getPhysicalNumberOfRows();
            while (rowCount < phyRowCount) {
                Row nextRow = firstSheet.getRow(rowCount);
                if (nextRow.getFirstCellNum() == 1) {
                    throw new MaturityException(MaturityErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
                }
                // fix jira 237
                if (checkIfRowIsEmpty(nextRow)) {
                    continue;
                }

                if (rowCount > 0) {
                    t = new MaturityDto();
                    int counter = 0;
                    while (counter <= SIX) {
                        Cell cell = nextRow.getCell(counter);
                        readExcelCellsBySwitchCase(t, counter, cell);
                        counter++;
                    }
                }
                if (t != null) {
                    t.setLineNumber(rowCount + 1);
                    validateLine(t, list);
                    list.add(t);
                }
                rowCount++;

            }
            if (rowCount == 1)
                throw new MaturityException(MaturityErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);

            inputStream.close();
        } catch (IOException e1) {
            logger.error("IOException while parsing the excel sheet : {}", e1);
        } catch (Exception ex) {
            logger.error("Exception while parsing the excel sheet : {}", ex);
            throw ex;
        }

        finally {
            myWorkBook.close();
        }

        return list;
    }

    /**
     * Read excel cells by switch case.
     *
     * @param t the t
     * @param counter the counter
     * @param cell the cell
     */
    private void readExcelCellsBySwitchCase(MaturityDto t, int counter, Cell cell) {
        String family;
        String body;
        String motor;
        String gearbox;
        String index;
        String status;
        String e;
        switch (counter) {
        case 0:
            e = getCellData(cell);
            validateFirstColEmpty(e);
            validateLineNotStratsCMD(e);
            break;

        case 1:
            family = getCellData(cell);
            if (family == null || family.isEmpty()) {
                throw new MaturityException(MaturityErrorCode.MISSING_FAMILY, null);
            } else if (family.length() != FOUR || family.contains("*") || family.contains("@") || family.contains("%")) {
                throw new MaturityException(MaturityErrorCode.INVALID_FAMILY, null);
            }
            t.setFamily(family);
            break;
        case 2:
            body = getCellData(cell);
            if (body == null || body.isEmpty()) {
                throw new MaturityException(MaturityErrorCode.MISSING_BODY, null);
            } else if (body.length() != TWO || body.contains("*") || body.contains("@") || body.contains("%")) {
                throw new MaturityException(MaturityErrorCode.INVALID_BODY, null);
            }
            t.setBody(body);
            break;
        case 3:
            motor = getCellData(cell);
            if (motor == null || motor.isEmpty()) {
                throw new MaturityException(MaturityErrorCode.MISSING_MOTOR, null);
            } else if (motor.length() != TWO || motor.contains("*") || motor.contains("@") || motor.contains("%")) {
                throw new MaturityException(MaturityErrorCode.INVALID_MOTOR, null);
            }
            t.setMotor(motor);
            break;
        case 4:
            gearbox = getCellData(cell);
            if (gearbox == null || gearbox.isEmpty()) {
                throw new MaturityException(MaturityErrorCode.MISSING_GEARBOX, null);
            } else if (gearbox.length() != ONE || gearbox.contains("*") || gearbox.contains("@") || gearbox.contains("%")) {
                throw new MaturityException(MaturityErrorCode.INVALID_GEARBOX, null);
            }
            t.setGearbox(gearbox);
            break;
        case 5:
            index = getCellData(cell);
            if (index == null || index.isEmpty()) {
                throw new MaturityException(MaturityErrorCode.MISSING_INDEX, null);
            } else if (index.length() != TWO || index.contains("*") || index.contains("@") || index.contains("%")) {
                throw new MaturityException(MaturityErrorCode.INVALID_INDEX, null);
            }
            t.setIndex(index);
            break;

        case 6:
            status = getCellData(cell);
            t.setStatus(status);
            break;

        default:
            break;
        }
    }

    /**
     * Check if row is empty.
     *
     * @param nextRow the next row
     * @return true, if successful
     */
    private boolean checkIfRowIsEmpty(Row nextRow) {
        boolean isEmpty = false;
        int noOfColumns = SEVEN;
        List<Boolean> emptyCheckList = new ArrayList<>();
        if (nextRow != null) {
            for (int i = 0; i < noOfColumns; i++) {
                if (nextRow.getCell(i) == null || nextRow.getCell(i).getCellTypeEnum() == CellType.BLANK) {
                    emptyCheckList.add(true);
                }
            }
        }
        if (!emptyCheckList.isEmpty() && emptyCheckList.size() == noOfColumns) {
            isEmpty = true;
        }

        return isEmpty;

    }

    /**
     * Gets the cell data.
     *
     * @param cell the cell
     * @return the cell data
     */
    private String getCellData(Cell cell) {
        CellType cellType = cell.getCellTypeEnum();
        switch (cellType) {
        case BOOLEAN:
            return String.valueOf(cell.getBooleanCellValue());

        case NUMERIC:
            String useValue = String.valueOf(cell.getNumericCellValue());
            if (useValue.endsWith(".0"))
                return useValue.split("\\.")[0];
            return useValue;

        case STRING:
            return cell.getStringCellValue();

        case BLANK:
            return "";

        default:
            return new String();
        }
    }

    /**
     * Validate line.
     *
     * @param maturity the maturity
     * @param maturities the maturities
     * @return true, if successful
     * @throws MaturityException the maturity exception
     */
    public static boolean validateLine(MaturityDto maturity, List<MaturityDto> maturities) throws MaturityException {

        for (MaturityDto maturity2 : maturities) {
            if (maturity2.getFamily().equalsIgnoreCase(maturity.getFamily()) && maturity2.getBody().equalsIgnoreCase(maturity.getBody())
                    && maturity2.getMotor().equalsIgnoreCase(maturity.getMotor()) && maturity2.getGearbox().equalsIgnoreCase(maturity.getGearbox())
                    && maturity2.getIndex().equalsIgnoreCase(maturity.getIndex())) {
                String[] repeatMaturity = { maturity.getFamily(), maturity.getBody(), maturity.getMotor(), maturity.getGearbox(),
                        maturity.getIndex() };
                throw new MaturityException(MaturityErrorCode.MATURITY_ENTRY_PRESENT_IN_SHEET, repeatMaturity);
            }
        }

        return false;

    }

    /**
     * Validate first col empty.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws MaturityException the maturity exception
     */
    public static boolean validateFirstColEmpty(String cellValue) throws MaturityException {
        if (cellValue.isEmpty()) {
            throw new MaturityException(MaturityErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
        }
        return false;
    }

    /**
     * Validate line not strats CMD.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws MaturityException the maturity exception
     */
    public static boolean validateLineNotStratsCMD(String cellValue) throws MaturityException {
        if (!("C".equalsIgnoreCase(cellValue)) && !("M".equalsIgnoreCase(cellValue)) && !(cellValue.isEmpty()) || ("T".equalsIgnoreCase(cellValue))) {
            throw new MaturityException(MaturityErrorCode.FIRST_LINE_STARTS_C_M_D_CHECK, null);
        }
        return false;
    }

    /**
     * Check headers.
     *
     * @param firstSheet the first sheet
     * @throws MaturityException the maturity exception
     */
    private void checkHeaders(XSSFSheet firstSheet) throws MaturityException {
        final int totalNumberOfHeaderColumns = 7;
        int noOfColumns = firstSheet.getRow(0).getLastCellNum();
        logger.info("Total Number Of Header Columns Required are :[{}]", totalNumberOfHeaderColumns);
        if (noOfColumns < totalNumberOfHeaderColumns) {
            logger.info("The columns in the excel file are :[{}]", noOfColumns);
            throw new MaturityException(MaturityErrorCode.MATURITY_HEADER_COLUMN_MISSING, null);
        }

    }

}
