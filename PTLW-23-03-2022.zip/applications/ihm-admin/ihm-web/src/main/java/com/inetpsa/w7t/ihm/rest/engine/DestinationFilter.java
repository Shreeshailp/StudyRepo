/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import javax.ws.rs.QueryParam;

/**
 * The Class DestinationFilter. Use it to filter Destination Label
 */
public class DestinationFilter {

    /** The label. */
    @QueryParam("label")
    public String label;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

}
