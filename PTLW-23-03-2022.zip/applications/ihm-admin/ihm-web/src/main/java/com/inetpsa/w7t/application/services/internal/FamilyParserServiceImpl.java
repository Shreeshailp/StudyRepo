/*
 * Creation : 8 mars 2017
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.IntToDoubleFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.inject.Inject;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.time.StopWatch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.FamilyParserService;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.model.CycleProfile;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.families.model.family.FamilyDto;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfile;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.Parameter;

/**
 * The Class FamilyParserServiceImpl.
 */
public class FamilyParserServiceImpl implements FamilyParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The generated cycle repository. */
    @Inject
    private GeneratedCycleRepository generatedCycleRepository;

    /** The cycle repository. */
    @Inject
    private CycleRepository cycleRepository;

    /** The cycle details repository. */
    @Inject
    private CycleDetailsRepository cycleDetailsRepository;

    /** The parameter repository. */
    @Inject
    private ParameterRepository parameterRepository;

    /** The family import work book. */
    XSSFWorkbook familyImportWorkBook;

    /** The family import sheet. */
    XSSFSheet familyImportSheet;

    /** The Constant NUM_ZERO. */
    public static final int NUM_ZERO = 0;

    /** The Constant NUM_ONE. */
    public static final int NUM_ONE = 1;

    /** The Constant NUM_TWO. */
    public static final int NUM_TWO = 2;

    /** The Constant NUM_THREE. */
    public static final int NUM_THREE = 3;

    /** The Constant NUM_FOUR. */
    public static final int NUM_FOUR = 4;

    /** The Constant NUM_FIVE. */
    public static final int NUM_FIVE = 5;

    /** The Constant NUM_SIX. */
    public static final int NUM_SIX = 6;

    /** The Constant NUM_SEVEN. */
    public static final int NUM_SEVEN = 7;

    /** The Constant NUM_EIGHT. */
    public static final int NUM_EIGHT = 8;

    /** The Constant NUM_NINE. */
    public static final int NUM_NINE = 9;

    /** The Constant NUM_TEN. */
    public static final int NUM_TEN = 10;

    /** The Constant NUM_ELEVEN. */
    public static final int NUM_ELEVEN = 11;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_TWELVE = 12;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_SEVENTEEN = 17;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_EIGHTEEN = 18;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_TWENTYTHREE = 23;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_TWENTYFOUR = 24;

    /** The Constant NUM_TWENTY_NINE. */
    public static final int NUM_TWENTY_NINE = 29;

    /** The Constant NUM_THIRTY. */
    public static final int NUM_THIRTY = 30;

    /** The Constant NUM_THIRTY_FIVE. */
    public static final int NUM_THIRTY_FIVE = 35;

    /** The Constant NUM_THIRTY_SIX. */
    public static final int NUM_THIRTY_SIX = 36;

    /** The Constant TEST_VEHICLE_TYPE. */
    private static final String TEST_VEHICLE_TYPE = "testVehicleType";

    /** The Constant CALCULATION_TYPE. */
    private static final String CALCULATION_TYPE = "calculationType";

    /** The Constant CE. */
    private static final String CE = "CE";

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The Constant DOWN_SCALE. */
    public static final String DOWN_SCALE = "_D";

    /** The Constant SPEED_LIMITING. */
    public static final String SPEED_LIMITING = "_V";

    /** The Constant CE_FETCH_DATA_LOG. */
    public static final String CE_FETCH_DATA_LOG = "StopWatch - Cycle energy ({}) - Fetching data took {}ms";

    /** The Constant ZERO. */
    public static final int ZERO = 0;

    /** The i 1. */
    private int i1;

    /** The r 0 downscale. */
    private double r0Downscale;

    /** The a 1 downscale. */
    private double a1Downscale;

    /** The b 1 downscale. */
    private double b1Downscale;

    /** The Constant I1_DOWN_SCALE_PMAX_TIME. */
    private static final String I1_DOWN_SCALE_PMAX_TIME = "i1_downscale_pmax_time";

    /** The Constant A1_DOWN_SCALE. */
    private static final String A1_DOWN_SCALE = "a1_downscale";

    /** The Constant B1_DOWN_SCALE. */
    private static final String B1_DOWN_SCALE = "b1_downscale";

    /** The Constant R0_DOWN_SCALE. */
    private static final String R0_DOWN_SCALE = "r0_downscale";

    /** The Constant MEASURE_VALUES. */
    private static final String MEASURE_VALUES = "measuresValues";

    /** The Constant CYCLE_ENERGY_F0F1_TEST_MASS_LOG. */
    private static final String CYCLE_ENERGY_F0F1_TEST_MASS_LOG = "Cycle Energy - Phase {} - f0({}), f1({}), f2({}), testmass({}), usableMass(testMass * {})({})";

    /** The Constant CYCLE_ENERGY_PROFILE_LOG. */
    private static final String CYCLE_ENERGY_PROFILE_LOG = "Cycle Energy - Phase {} - {} cycle profiles";

    /** The Constant CYCLE_ENERGY_ROUNDING_LOG. */
    private static final String CYCLE_ENERGY_ROUNDING_LOG = "Cycle Energy - Phase {} - CE: {} rounded from {}";

    /** The Constant CYCLE_ENERGY_CALCUL_TIME_LOG. */
    private static final String CYCLE_ENERGY_CALCUL_TIME_LOG = "StopWatch - Cycle energy ({}) - Energy calculation took {}ms";

    /** The df. */
    DataFormatter df = new DataFormatter();

    /** The cycle phase repository. */
    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyParserService#parse(java.io.InputStream)
     */
    @Override
    public List<FamilyDto> parse(InputStream inputStream) throws IOException {

        List<FamilyDto> familyDtos = new ArrayList<>();

        familyImportWorkBook = new XSSFWorkbook(inputStream);
        familyImportSheet = familyImportWorkBook.getSheetAt(0);

        List<Row> familyHeaderRows = searchFamilyHeaders();
        for (Row row : familyHeaderRows) {
            FamilyDto familyDto = new FamilyDto();

            try {
                familyDto.setCode(df.formatCellValue(row.getCell(NUM_ONE)));
                familyDto.setIndex(Integer.valueOf(df.formatCellValue(row.getCell(NUM_TWO))));
                familyDto.setLabel(df.formatCellValue(row.getCell(NUM_THREE)));
                familyDto.setVehicleType(checkBlankCellAndReturnStringValue(NUM_FOUR, row));
                familyDto.setRoadLoad(checkBlankCellAndReturnStringValue(NUM_FIVE, row));
                familyDto.setPmax(checkBlankCellAndReturnFloatValue(NUM_THIRTY_SIX, row));
                familyDto.setCycles(getCycles(row));
                familyDto.setQuantities(getQuantities(row));
                familyDto.setTestVehicles(getTestVehicles(row));
                calculateCEIfCEIsBlankForTestVehicleType(familyDto);

            } catch (FamilyValidationException e) {
                logger.error("family validation error while parsing", e.getMessage(), e);
                throw e;
            } catch (RuntimeException e) {
                logger.warn("Error while parsing", e);
                FamilyValidationException fve = new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS,
                        new Integer[] { row.getRowNum() + 1 });
                fve.initCause(e);
                throw fve;
            }
            familyDto.setLineNumber(row.getRowNum());
            familyDtos.add(familyDto);
        }

        return familyDtos;
    }

    /**
     * Search family headers.
     *
     * @return the list
     */
    private List<Row> searchFamilyHeaders() {
        Iterator<Row> rowIterator = familyImportSheet.rowIterator();
        List<Row> familyHeaderRows = new ArrayList<>();
        int cellValueMcount = 0;

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            // fix jira 237
            if (checkIfRowIsEmpty(row)) {
                continue;
            }
            String firstCellValue = df.formatCellValue(row.getCell(NUM_ZERO));

            rG37x1(firstCellValue, row.getRowNum() + 1);// JIRA Fix - CALCULWLTP-246

            if ("M".equals(firstCellValue)) {
                cellValueMcount += 1;
                familyHeaderRows.add(row);
                rG39x1(row);

            }
            if ("D".equals(firstCellValue)) {
                rG39x2(row, familyHeaderRows);
            }
        } /** Second part of rule RG 37 i.e. if there is no line starting with “M” we respond with error **/
        if (cellValueMcount == 0) {
            throw new FamilyValidationException(FamilyErrorCode.ATLEAST_ONE_METADATA_CHECK, null);
        }

        return familyHeaderRows;

    }

    /**
     * Check if row is empty.
     *
     * @param nextRow the next row
     * @return true, if successful
     */
    private boolean checkIfRowIsEmpty(Row nextRow) {
        boolean isEmpty = false;
        int noOfColumns = NUM_THIRTY_SIX;
        List<Boolean> emptyCheckList = new ArrayList<>();
        if (nextRow != null) {
            for (int i = 0; i < noOfColumns; i++) {
                if (nextRow.getCell(i) == null || nextRow.getCell(i).getCellTypeEnum() == CellType.BLANK) {
                    emptyCheckList.add(true);
                }
            }
        }
        if (!emptyCheckList.isEmpty() && emptyCheckList.size() == noOfColumns) {
            isEmpty = true;
        }

        return isEmpty;

    }

    /**
     * This function is used to implement the second part of rule 39 i.e. For each line starting with “D”, there must be one and only line starting
     * with “M” with the same family code and wltp family index. If there are several lines starting with “M”, the couples wltp_family,
     * wltp_family_index must be different on each line.
     *
     * @param dRow the d row
     * @param familyHeaderRows the family header rows
     */
    private void rG39x2(Row dRow, List<Row> familyHeaderRows) {

        String familyCode = df.formatCellValue(dRow.getCell(NUM_ONE));
        String familyIndex = df.formatCellValue(dRow.getCell(NUM_TWO));

        boolean mdValueExists = false;
        int mdValueMatchCount = 0;
        for (Row headerRow : familyHeaderRows) {

            String familyHeaderCode = df.formatCellValue(headerRow.getCell(NUM_ONE));
            String familyHeaderIndex = df.formatCellValue(headerRow.getCell(NUM_TWO));
            if (familyCode.equals(familyHeaderCode) && familyIndex.equals(familyHeaderIndex)) {
                mdValueExists = true;
                mdValueMatchCount++;
                if (mdValueMatchCount > 1) {
                    Integer errDoubleMatchRow = headerRow.getRowNum() + 1;
                    throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, errDoubleMatchRow.toString().split(" "));
                }
            }
        }
        if (!mdValueExists) {
            Integer errMissMRow = dRow.getRowNum() + 1;
            throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, errMissMRow.toString().split(" "));
        }

    }

    /**
     * This function is used to implement the rule first part of rule 37 i.e. For each row, if the 1st column is empty we respond with error.
     *
     * @param firstCellValue the first cell value
     * @param rowNum the row num
     */
    private void rG37x1(String firstCellValue, Integer rowNum) {

        if (firstCellValue.isEmpty() || firstCellValue.length() != 1 || firstCellValue.contains(" ")) {
            Integer[] rowIndx = { rowNum };
            throw new FamilyValidationException(FamilyErrorCode.FIRST_COLUMN_EMPTY_CHECK, rowIndx);
        }
    }

    /**
     * This function is used to implement the first part of rule 39 i.e. For each line startine with “M”, there must be at least one line starting
     * with “D” with the same couple (wltp family code, wltp family index).
     *
     * @param row the row
     * @return true, if successful
     */
    private boolean rG39x1(Row row) {

        boolean mdValueMatch = false;
        String firstCellValue;

        String mSecondCellValue = df.formatCellValue(row.getCell(NUM_ONE));
        String mThirdCellValue = df.formatCellValue(row.getCell(NUM_TWO));
        String dSecondCellValue;
        String dThirdCellValue;

        Integer startRowIndex = row.getRowNum() + 1;
        for (int rowIndex = startRowIndex; rowIndex < familyImportSheet.getLastRowNum(); rowIndex++) {
            Row mRow = familyImportSheet.getRow(rowIndex);
            firstCellValue = df.formatCellValue(mRow.getCell(NUM_ZERO));
            if ("D".equals(firstCellValue)) {
                dSecondCellValue = df.formatCellValue(mRow.getCell(NUM_ONE));
                dThirdCellValue = df.formatCellValue(mRow.getCell(NUM_TWO));
                if (mSecondCellValue.equals(dSecondCellValue) && mThirdCellValue.equals(dThirdCellValue)) {
                    mdValueMatch = true;
                    break;
                }
            } else if (!"E".equals(firstCellValue)) {
                break;
            }

        }

        if (!mdValueMatch) {
            throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, startRowIndex.toString().split(" "));
        }
        return mdValueMatch;
    }

    /**
     * Gets the quantities.
     *
     * @param familyHeaderRow the family header row
     * @return the quantities
     */
    private MultiMap getQuantities(Row familyHeaderRow) {
        MultiMap multiMap = new MultiValueMap();
        Map<String, Double> lMap = new HashMap<>();
        Map<String, Double> mMap = new HashMap<>();
        Map<String, Double> hMap = new HashMap<>();
        Map<String, Double> rMap = new HashMap<>();

        String[] qt = { "F0", "F1", "F2", "MASSE", "SCX", "CRR" };

        NumberFormat nf = NumberFormat.getInstance();
        String roadLoad = checkBlankCellAndReturnStringValue(NUM_FIVE, familyHeaderRow);
        try {

            for (int i = NUM_TWELVE; i <= NUM_SEVENTEEN; i++) {
                String quantityType = qt[i - NUM_TWELVE];
                /** RG39 **/
                Integer[] lineNumber = { familyHeaderRow.getRowNum() + 1 };
                stringNotAllowedBlankAllowedCell(lineNumber, familyHeaderRow.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum());
                Cell cell = familyHeaderRow.getCell(i, MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell != null)
                    lMap.put(quantityType, nf.parse(df.formatCellValue(cell)).doubleValue());
            }
            multiMap.put("VLOW", lMap);

            for (int i = NUM_EIGHTEEN; i <= NUM_TWENTYTHREE; i++) {
                String quantityType = qt[i - NUM_EIGHTEEN];

                // ** RG39 **//*
                Integer[] lineNumber = { familyHeaderRow.getRowNum() + 1 };
                stringNotAllowedBlankAllowedCell(lineNumber, familyHeaderRow.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum());
                Cell cell = familyHeaderRow.getCell(i, MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell != null)
                    mMap.put(quantityType, nf.parse(df.formatCellValue(cell)).doubleValue());
            }
            multiMap.put("VMED", mMap);

            for (int i = NUM_TWENTYFOUR; i <= NUM_TWENTY_NINE; i++) {
                String quantityType = qt[i - NUM_TWENTYFOUR];

                /** RG39 **/
                Integer[] lineNumber = { familyHeaderRow.getRowNum() + 1 };
                stringNotAllowedBlankAllowedCell(lineNumber, familyHeaderRow.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum());
                Cell cell = familyHeaderRow.getCell(i, MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell != null)
                    hMap.put(quantityType, nf.parse(df.formatCellValue(cell)).doubleValue());
            }
            multiMap.put("VHIGH", hMap);

            for (int i = NUM_THIRTY; i <= NUM_THIRTY_FIVE; i++) {
                String quantityType = qt[i - NUM_THIRTY];

                /** RG39 **/
                Integer[] lineNumber = { familyHeaderRow.getRowNum() + 1 };
                if (roadLoad.equals("MRL")) {
                    stringNotAllowedCell(lineNumber, familyHeaderRow.getCell(i).getCellTypeEnum());
                } else {
                    stringNotAllowedBlankAllowedCell(lineNumber,
                            familyHeaderRow.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum());
                }
                Cell cell = familyHeaderRow.getCell(i, MissingCellPolicy.RETURN_BLANK_AS_NULL);
                if (cell != null)
                    rMap.put(quantityType, nf.parse(df.formatCellValue(cell)).doubleValue());
            }
            if (roadLoad.equals("MRL")) {
                multiMap.put("VREF", rMap);
            }

        } catch (ParseException e) {
            throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, new Object[] { familyHeaderRow.getRowNum() });
        }
        return multiMap;
    }

    /**
     * Gets the cycles.
     *
     * @param familyHeaderRow the family header row
     * @return the cycles
     */
    private Set<String> getCycles(Row familyHeaderRow) {
        Set<String> cycles = new HashSet<>();
        Integer[] mRowIndx = { familyHeaderRow.getRowNum() + 1 };
        for (int i = NUM_SIX; i <= NUM_ELEVEN; i++) {
            String refName = df.formatCellValue(familyHeaderRow.getCell(i));
            if (!refName.isEmpty() && !cycleRepository.exists(refName)) {
                /** RG 45 **/
                throw new FamilyValidationException(FamilyErrorCode.REF_PROFILE_NOT_EXISTS, mRowIndx);
            }
            cycles.add(df.formatCellValue(familyHeaderRow.getCell(i)));
        }
        return cycles;
    }

    /**
     * Gets the test vehicles.
     *
     * @param familyHeaderRow the family header row
     * @return the test vehicles
     */
    private List<Map<String, Object>> getTestVehicles(Row familyHeaderRow) {
        String familyHeaderCode = df.formatCellValue(familyHeaderRow.getCell(NUM_ONE));
        String familyHeaderIndex = df.formatCellValue(familyHeaderRow.getCell(NUM_TWO));

        List<Map<String, Object>> testVehiclesList = new ArrayList<>();

        Iterator<Row> rowIterator = familyImportSheet.iterator();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            String firstCellValue = df.formatCellValue(row.getCell(NUM_ZERO));
            String familyCode = df.formatCellValue(row.getCell(NUM_ONE));
            String familyIndex = df.formatCellValue(row.getCell(NUM_TWO));
            if (familyHeaderCode.equals(familyCode) && familyHeaderIndex.equals(familyIndex) && "D".equals(firstCellValue)) {

                Map<String, Object> testVehicle = new HashMap<>();

                testVehicle.put(TEST_VEHICLE_TYPE, checkBlankCellAndReturnStringValue(NUM_THREE, row));
                testVehicle.put(CALCULATION_TYPE, checkBlankCellAndReturnStringValue(NUM_FOUR, row));
                testVehicle.put(MEASURE_VALUES, getMeasures(row));

                testVehiclesList.add(testVehicle);
            }
        }
        return testVehiclesList;
    }

    /**
     * Calculate CE if CE is blank for test vehicle type.
     *
     * @param familyDto the family dto
     */
    private void calculateCEIfCEIsBlankForTestVehicleType(FamilyDto familyDto) {
        String[] vehicleType = new String[] { "VLOW", "VMED", "VHIGH", "VREF" };
        List<Map<String, Object>> newTestVehList = new ArrayList<>();
        List<Map<String, Object>> measuredVehicleListMap = familyDto.getTestVehicles();
        Map<String, Integer> ceCountMap = new HashMap<>();

        for (String vehType : vehicleType) {
            int counter = 0;
            for (Map<String, Object> map : measuredVehicleListMap) {
                if (map.get(TEST_VEHICLE_TYPE).toString().equalsIgnoreCase(vehType) && map.get(CALCULATION_TYPE).toString().equalsIgnoreCase(CE)) {
                    ceCountMap.put(vehType, ++counter);
                } else if (map.get(TEST_VEHICLE_TYPE).toString().equalsIgnoreCase(vehType)
                        && !map.get(CALCULATION_TYPE).toString().equalsIgnoreCase(CE)) {
                    ceCountMap.put(vehType, counter);
                }
            }
        }
        for (String vehType : vehicleType) {
            if (ceCountMap.containsKey(vehType) && ceCountMap.get(vehType) == 0) {
                logger.info("Cycle energy need to be calculate for VehicleType :{}", vehType);
                if (familyDto.getPmax() == null) {
                    newTestVehList.add(calculateCycleEnergy(familyDto, vehType));
                } else {
                    fDescCalculate(familyDto, vehType);
                }
            }
        }
        if (!newTestVehList.isEmpty()) {
            familyDto.getTestVehicles().addAll(newTestVehList);
        }
    }

    /**
     * Replace reference cycles by generated cycles.
     *
     * @param cycleCode the cycle code
     * @param fDownScale the f down scale
     * @return the generated cycle
     */
    private GeneratedCycle replaceReferenceCyclesByGeneratedCycles(String cycleCode, Float fDownScale) {

        String generatedCode = "";
        StopWatch swMain = new StopWatch();
        swMain.start();

        if (fDownScale != null) {
            generatedCode = cycleCode + DOWN_SCALE + getFdsc(fDownScale);
        }
        Optional<GeneratedCycle> generatedCycle = generatedCycleRepository.byGeneratedCode("", generatedCode);
        GeneratedCycle generatedCycles = null;
        if (generatedCycle.isPresent()) {
            logger.info("Replacing  the reference cycle by generated cycle for the phase code :{},FDownScale:{}, Generated Code:{} ", cycleCode,
                    fDownScale, generatedCycle.get().getGeneratedCode());
            generatedCycles = generatedCycle.get();
        } else {
            Object[] errMsg = { generatedCode };
            logger.info("Generated Code[{}]", generatedCode);
            throw new FamilyValidationException(FamilyErrorCode.CYCLE_NOT_FOUND, errMsg);
        }
        swMain.stop();
        logger.debug("StopWatch - Replacing the reference cycle by generated cycle for the phase code :{} took {}ms", cycleCode, swMain.getTime());
        return generatedCycles;
    }

    /**
     * Gets the fdsc.
     *
     * @param fdsc the fdsc
     * @return the fdsc
     */
    private String getFdsc(Float fdsc) {
        String sFdsc = fdsc + "";
        if (sFdsc.contains(".")) {
            sFdsc = sFdsc.replace(".", "");
        }
        return sFdsc;
    }

    /**
     * Calculate cycle energy.
     *
     * @param familyDto the family dto
     * @param vehType the veh type
     * @return the map
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> calculateCycleEnergy(FamilyDto familyDto, String vehType) {
        try {
            List<String> cycleCodeList = familyDto.getCycles().stream().filter(cycleCode -> !cycleCode.isEmpty()).collect(Collectors.toList());
            Map<String, Object> testVehicleMap = new HashMap<>();
            testVehicleMap.put(TEST_VEHICLE_TYPE, vehType);
            testVehicleMap.put(CALCULATION_TYPE, CE);
            Map<String, Double> measures = new HashMap<>();

            for (int j = 0; j < cycleCodeList.size(); j++) {
                List<Map<String, Double>> quantities = (List<Map<String, Double>>) familyDto.getQuantities().get(vehType);
                StopWatch sw = new StopWatch();
                sw.start();
                double f0 = getPhysicalQuantity(quantities, CalculationConstants.F0_CODE);
                double f1 = getPhysicalQuantity(quantities, CalculationConstants.F1_CODE);
                double f2 = getPhysicalQuantity(quantities, CalculationConstants.F2_CODE);
                Optional<CycleDetails> optCycle = cycleDetailsRepository.byCode(cycleCodeList.get(j));
                if (optCycle.isPresent()) {
                    int testMass = getPhysicalQuantity(quantities, CalculationConstants.MASS_CODE).intValue();
                    double usableMass = CalculationConstants.TEST_MASS_COEFFICIENT * testMass;
                    sw.split();
                    long sortTime = sw.getSplitTime();
                    String measurePhase = optCycle.get().getPhase();
                    logger.debug(CE_FETCH_DATA_LOG, measurePhase, sortTime);
                    sw.unsplit();
                    StopWatch swG = new StopWatch();
                    swG.start();
                    List<CycleProfile> profiles = optCycle.get().getProfiles();

                    IntToDoubleFunction mapper = i -> {
                        CycleProfile currentProfile = profiles.get(i);
                        double avgSpeed = (profiles.get(i - 1).getVelocity() + currentProfile.getVelocity()) / 2;
                        double fi = f0 + f1 * avgSpeed + f2 * avgSpeed * avgSpeed + usableMass * currentProfile.getAcceleration();
                        double ei = 0;
                        if (fi > 0)
                            ei = fi * currentProfile.getDistance();
                        return ei;
                    };

                    double ceInd = IntStream.range(1, profiles.size()).mapToDouble(mapper).filter(i -> i > 0).sum();
                    double ce = BigDecimal.valueOf(ceInd).setScale(CalculationConstants.ROUND_CE, RoundingMode.HALF_UP).doubleValue();
                    sw.stop();

                    logger.debug(CYCLE_ENERGY_F0F1_TEST_MASS_LOG, measurePhase, f0, f1, f2, testMass, CalculationConstants.TEST_MASS_COEFFICIENT,
                            usableMass);
                    logger.debug(CYCLE_ENERGY_PROFILE_LOG, measurePhase, profiles.size());

                    logger.info(CYCLE_ENERGY_ROUNDING_LOG, measurePhase, ce, ceInd);

                    logger.info(CYCLE_ENERGY_CALCUL_TIME_LOG, measurePhase, sw.getTime() - sortTime);

                    measures.put(measurePhase, ce);
                }
            }
            testVehicleMap.put(MEASURE_VALUES, measures);
            return testVehicleMap;
        } catch (Exception e) {
            LogErrorUtility.logTheError(logger, ERRW + WltpEngineCalculatorErrorCode.ENERGY_CALCUL_ERR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.ENERGY_CALCUL_ERR.getDescription());
            throw new FamilyValidationException(FamilyErrorCode.ENERGY_CALCUL_ERR, null);
        }

    }

    /**
     * Gets the measures.
     *
     * @param dRow the d row
     * @return the measures
     */
    private Map<String, Double> getMeasures(Row dRow) {
        Map<String, Double> measures = new HashMap<>();
        String[] ms = { "LOW", "MID", "HIGH", "EHIGH", "CITY", "COMB" };
        /** RG39 **/

        for (int i = NUM_FIVE; i <= NUM_TEN; i++) {
            Integer[] lineNumber = { dRow.getRowNum() + 1 };

            stringNotAllowedBlankAllowedCell(lineNumber, dRow.getCell(i, MissingCellPolicy.CREATE_NULL_AS_BLANK).getCellTypeEnum());
            measures.put(ms[i - NUM_FIVE], getNonBlankMeasureValue(dRow, i));
        }
        return measures;
    }

    /**
     * Gets the non blank measure value.
     *
     * @param dRow the d row
     * @param colNum the col num
     * @return the non blank measure value
     */
    private Double getNonBlankMeasureValue(Row dRow, int colNum) {
        if (!(dRow.getCell(colNum).getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return dRow.getCell(colNum).getNumericCellValue();
    }

    /**
     * Check blank cell and return string value.
     *
     * @param colNum the col num
     * @param mRow the m row
     * @return the string
     */
    private String checkBlankCellAndReturnStringValue(int colNum, Row mRow) {
        String value = df.formatCellValue(mRow.getCell(colNum));
        if (value.isEmpty()) {
            Integer[] mRowIndx = { mRow.getRowNum() + 1 };
            throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, mRowIndx);
        }
        return value;
    }

    /**
     * Check blank cell and return float value.
     *
     * @param colNum the col num
     * @param mRow the m row
     * @return the float
     */
    private Float checkBlankCellAndReturnFloatValue(int colNum, Row mRow) {
        String value = df.formatCellValue(mRow.getCell(colNum));
        if (value.isEmpty()) {
            return null;
        }
        return Float.parseFloat(value);

    }

    /**
     * String not allowed cell.
     *
     * @param lineNumber the line number
     * @param typeOne the type one
     */
    private void stringNotAllowedCell(Integer[] lineNumber, CellType typeOne) {
        if (!typeOne.equals(CellType.BLANK) && !typeOne.equals(CellType.NUMERIC)) {
            throw new FamilyValidationException(FamilyErrorCode.LINE_M_D_COUPLE_EXISTS, lineNumber);
        } else if (typeOne.equals(CellType.BLANK)) {
            throw new FamilyValidationException(FamilyErrorCode.DATA_MISSING, lineNumber);
        }
    }

    /**
     * String not allowed blank allowed cell.
     *
     * @param lineNumber the line number
     * @param typeOne the type one
     */
    private void stringNotAllowedBlankAllowedCell(Integer[] lineNumber, CellType typeOne) {
        if (!typeOne.equals(CellType.BLANK) && !typeOne.equals(CellType.NUMERIC)) {
            throw new FamilyValidationException(FamilyErrorCode.DATA_MISSING, lineNumber);
        }

    }

    /**
     * Gets the physical quantity.
     *
     * @param quantities the quantities
     * @param code the code
     * @return the physical quantity
     */
    private Double getPhysicalQuantity(List<Map<String, Double>> quantities, String code) {
        double value = 0;
        for (Map<String, Double> map : quantities) {
            value = map.get(code);
        }
        return value;
    }

    /**
     * F desc calculate.
     *
     * @param familyDto the family dto
     * @param vehType the veh type
     */
    private void fDescCalculate(FamilyDto familyDto, String vehType) {
        List<String> cycleCodeList = familyDto.getCycles().stream().filter(cycleCode -> !cycleCode.isEmpty()).collect(Collectors.toList());
        List<Map<String, Object>> newTestVehList = new ArrayList<>();
        setParameterValues();

        Map<String, Object> testVehicleMap = new HashMap<>();
        testVehicleMap.put(TEST_VEHICLE_TYPE, vehType);
        testVehicleMap.put(CALCULATION_TYPE, CE);
        Map<String, Double> measures = new HashMap<>();

        for (String cycleCode : cycleCodeList) {
            List<CyclePhase> cyclePhaseOriginalList = cyclePhaseRepository.all();
            Optional<CycleDetails> optCycle = cycleDetailsRepository.byCode(cycleCode);
            CyclePhase cyclePhase = null;
            if (!cyclePhaseOriginalList.isEmpty() && optCycle.isPresent()) {
                cyclePhase = cyclePhaseOriginalList.stream().filter(cp -> cp.getCode().equals(optCycle.get().getPhase())).collect(Collectors.toList())
                        .get(0);
            }
            if (cyclePhase != null) {

                Float f_dsc = null;
                if (cyclePhase.getDownScaleFlag()) {
                    f_dsc = fDownScaleVInd(optCycle.get(), familyDto, cyclePhase, vehType);
                    logger.info("The calculated Downscale coefficient for the phase:{} is : {}", cyclePhase.getCode(), f_dsc);
                    if (f_dsc != null) {
                        measures.put(cyclePhase.getCode(),
                                calculateCycleEnergy(optCycle.get(), replaceReferenceCyclesByGeneratedCycles(cycleCode, f_dsc), familyDto, vehType));

                    } else {
                        measures.put(cyclePhase.getCode(), calculateCycleEnergy(optCycle.get(), familyDto, vehType));
                    }
                } else {
                    measures.put(cyclePhase.getCode(), calculateCycleEnergy(optCycle.get(), familyDto, vehType));
                }
            }
        }
        if (!measures.isEmpty()) {
            testVehicleMap.put(MEASURE_VALUES, measures);
            newTestVehList.add(testVehicleMap);
        }

        if (!newTestVehList.isEmpty()) {
            familyDto.getTestVehicles().addAll(newTestVehList);
        }
    }

    /**
     * Calculate cycle energy.
     *
     * @param cycle the cycle
     * @param familyDto the family dto
     * @param vehType the veh type
     * @return the double
     */
    @SuppressWarnings("unchecked")
    private Double calculateCycleEnergy(CycleDetails cycle, FamilyDto familyDto, String vehType) {
        StopWatch sw = new StopWatch();
        sw.start();
        try {
            List<Map<String, Double>> quantities = (List<Map<String, Double>>) familyDto.getQuantities().get(vehType);

            double f0 = getPhysicalQuantity(quantities, CalculationConstants.F0_CODE);
            double f1 = getPhysicalQuantity(quantities, CalculationConstants.F1_CODE);
            double f2 = getPhysicalQuantity(quantities, CalculationConstants.F2_CODE);

            int testMass = getPhysicalQuantity(quantities, CalculationConstants.MASS_CODE).intValue();
            double usableMass = CalculationConstants.TEST_MASS_COEFFICIENT * testMass;
            sw.split();
            long sortTime = sw.getSplitTime();
            logger.debug(CE_FETCH_DATA_LOG, cycle.getPhase(), sortTime);
            sw.unsplit();
            StopWatch swG = new StopWatch();
            swG.start();
            List<CycleProfile> profiles = cycle.getProfiles();

            IntToDoubleFunction mapper = i -> {
                CycleProfile currentProfile = profiles.get(i);
                double avgSpeed = (profiles.get(i - 1).getVelocity() + currentProfile.getVelocity()) / 2;
                double fi = f0 + f1 * avgSpeed + f2 * avgSpeed * avgSpeed + usableMass * currentProfile.getAcceleration();
                double ei = 0;
                if (fi > 0)
                    ei = fi * currentProfile.getDistance();
                return ei;
            };

            double ceInd = IntStream.range(1, profiles.size()).mapToDouble(mapper).filter(i -> i > 0).sum();
            double ce = BigDecimal.valueOf(ceInd).setScale(CalculationConstants.ROUND_CE, RoundingMode.HALF_UP).doubleValue();

            sw.stop();

            logger.debug(CYCLE_ENERGY_F0F1_TEST_MASS_LOG, cycle.getPhase(), f0, f1, f2, testMass, CalculationConstants.TEST_MASS_COEFFICIENT,
                    usableMass);
            logger.debug(CYCLE_ENERGY_PROFILE_LOG, cycle.getPhase(), profiles.size());
            logger.info(CYCLE_ENERGY_ROUNDING_LOG, cycle.getPhase(), ce, ceInd);

            logger.info(CYCLE_ENERGY_CALCUL_TIME_LOG, cycle.getPhase(), sw.getTime() - sortTime);

            return ce;
        } catch (Exception e) {
            throw new FamilyValidationException(FamilyErrorCode.ENERGY_CALCUL_ERR, null);
        }
    }

    /**
     * Calculate cycle energy.
     *
     * @param cycle the cycle
     * @param generatedCycle the generated cycle
     * @param familyDto the family dto
     * @param vehType the veh type
     * @return the double
     */
    @SuppressWarnings("unchecked")
    private double calculateCycleEnergy(CycleDetails cycle, GeneratedCycle generatedCycle, FamilyDto familyDto, String vehType) {
        StopWatch sw = new StopWatch();
        sw.start();
        try {
            List<Map<String, Double>> quantities = (List<Map<String, Double>>) familyDto.getQuantities().get(vehType);

            double f0 = getPhysicalQuantity(quantities, CalculationConstants.F0_CODE);
            double f1 = getPhysicalQuantity(quantities, CalculationConstants.F1_CODE);
            double f2 = getPhysicalQuantity(quantities, CalculationConstants.F2_CODE);

            int testMass = getPhysicalQuantity(quantities, CalculationConstants.MASS_CODE).intValue();
            double usableMass = CalculationConstants.TEST_MASS_COEFFICIENT * testMass;
            sw.split();
            long sortTime = sw.getSplitTime();
            logger.debug(CE_FETCH_DATA_LOG, cycle.getPhase(), sortTime);
            sw.unsplit();
            StopWatch swG = new StopWatch();
            swG.start();
            List<GeneratedCycleProfile> profiles = generatedCycle.getGenCycleProfiles();
            swG.stop();
            logger.info("Generated Cycle profile points for phase {} took {}ms", generatedCycle.getPhase(), swG.getTime());
            IntToDoubleFunction mapper = i -> {
                GeneratedCycleProfile currentGeneratedCycleProfile = profiles.get(i);
                double avgSpeed = (profiles.get(i - 1).getVelocity() + currentGeneratedCycleProfile.getVelocity()) / 2;

                logger.debug("Cycle Energy - Phase {} - {}", cycle.getPhase(), currentGeneratedCycleProfile);

                double fi = f0 + f1 * avgSpeed + f2 * avgSpeed * avgSpeed + usableMass * currentGeneratedCycleProfile.getAcceleration();
                double ei = 0;
                if (fi > 0)
                    ei = fi * currentGeneratedCycleProfile.getDistance();

                return ei;
            };

            double ceInd = IntStream.range(1, profiles.size()).mapToDouble(mapper).filter(i -> i > 0).sum();
            double ce = BigDecimal.valueOf(ceInd).setScale(CalculationConstants.ROUND_CE, RoundingMode.HALF_UP).doubleValue();

            sw.stop();

            logger.debug(CYCLE_ENERGY_F0F1_TEST_MASS_LOG, cycle.getPhase(), f0, f1, f2, testMass, CalculationConstants.TEST_MASS_COEFFICIENT,
                    usableMass);
            logger.debug(CYCLE_ENERGY_PROFILE_LOG, cycle.getPhase(), profiles.size());
            logger.info(CYCLE_ENERGY_ROUNDING_LOG, cycle.getPhase(), ce, ceInd);

            logger.info(CYCLE_ENERGY_CALCUL_TIME_LOG, cycle.getPhase(), sw.getTime() - sortTime);

            return ce;
        } catch (FamilyValidationException e) {
            throw e;
        }
    }

    /**
     * F down scale V ind.
     *
     * @param c the c
     * @param familyDto the family dto
     * @param cyclePhase the cycle phase
     * @param vehType the veh type
     * @return the float
     */
    @SuppressWarnings("unchecked")
    private Float fDownScaleVInd(CycleDetails c, FamilyDto familyDto, CyclePhase cyclePhase, String vehType) {
        Float fDownScale = null;
        List<Map<String, Double>> quantities = (List<Map<String, Double>>) familyDto.getQuantities().get(vehType);

        Float pMax = familyDto.getPmax();
        if (cyclePhase != null && cyclePhase.getDownScaleFlag() && pMax != null) {
            Double f_dsc = calculateDownscale(c, quantities, pMax);
            if (f_dsc != null && f_dsc > 0.01) {
                fDownScale = Float.valueOf(String.valueOf(f_dsc));
            }

        }
        return fDownScale;
    }

    /**
     * Calculate downscale.
     *
     * @param cycleDetails the cycle details
     * @param quantities the quantities
     * @param pMax the max
     * @return the double
     */
    private Double calculateDownscale(CycleDetails cycleDetails, List<Map<String, Double>> quantities, Float pMax) {

        try {
            double fDownscale = 0;
            StopWatch sw = new StopWatch();
            sw.start();
            double f0_Vind = getPhysicalQuantity(quantities, CalculationConstants.F0_CODE);
            double f1_Vind = getPhysicalQuantity(quantities, CalculationConstants.F1_CODE);
            double f2_Vind = getPhysicalQuantity(quantities, CalculationConstants.F2_CODE);

            int testMass = getPhysicalQuantity(quantities, CalculationConstants.MASS_CODE).intValue();

            double aDsci1 = 0;
            double pReqMaxi = 0;
            double vI = 0;
            double vI1 = 0;

            List<CycleProfile> profiles = cycleDetails.getProfiles();

            if (profiles != null && !profiles.isEmpty()) {
                Optional<CycleProfile> cycleProfileVI = profiles.stream().filter(cp -> cp.getTime() == i1).collect(Collectors.toList()).stream()
                        .findFirst();

                Optional<CycleProfile> cycleProfileVI1 = profiles.stream().filter(cp -> cp.getTime() == i1 + 1).collect(Collectors.toList()).stream()
                        .findFirst();

                if (cycleProfileVI.isPresent())
                    vI = cycleProfileVI.get().getVelocity();
                if (cycleProfileVI1.isPresent())
                    vI1 = cycleProfileVI1.get().getVelocity();
            }

            aDsci1 = (vI1 - vI) / 3.6;

            pReqMaxi = ((f0_Vind * vI) + (f1_Vind * Math.pow(vI, 2)) + (f2_Vind * Math.pow(vI, 3)) + (1.03 * testMass * vI * aDsci1)) / 3600;
            double rMax = 0;
            if (pMax != null && pMax > 0) {
                rMax = pReqMaxi / pMax;
            } else {
                throw new FamilyValidationException(FamilyErrorCode.DOWN_SCALE_ERR, null);
            }
            if (rMax < r0Downscale)
                fDownscale = 0;

            if (rMax >= r0Downscale)
                fDownscale = (a1Downscale * rMax) + b1Downscale;

            fDownscale = BigDecimal.valueOf(fDownscale).setScale(CalculationConstants.ROUND_F3, RoundingMode.HALF_UP).doubleValue();

            logger.info("vI : {}, vI1 : {}, aDsci1 : {}, pReqMaxi : {}, PMAX : {}, rMax : {}, a1Downscale : {}", vI, vI1, aDsci1, pReqMaxi, pMax,
                    rMax, a1Downscale);
            logger.info(" fDownscale : {}", fDownscale);
            if (fDownscale <= 0.010) {
                fDownscale = 0;
            }

            sw.stop();
            logger.info("StopWatch - fDownscale calculation took {}ms", sw.getTime());
            return fDownscale;
        } catch (FamilyValidationException e) {
            throw e;
        }

    }

    /**
     * Sets the parameter values.
     */
    private void setParameterValues() {
        StopWatch sw = new StopWatch();
        sw.start();
        List<Parameter> parametersList = parameterRepository.all();

        Parameter i1_downscale_pmax_time = null;
        Parameter a1_downscale = null;
        Parameter b1_downscale = null;
        Parameter r0_downscale = null;
        if (!parametersList.isEmpty()) {
            i1_downscale_pmax_time = parametersList.stream().filter(p -> p.getCode().equals(I1_DOWN_SCALE_PMAX_TIME)).collect(Collectors.toList())
                    .get(0);
            a1_downscale = parametersList.stream().filter(p -> p.getCode().equals(A1_DOWN_SCALE)).collect(Collectors.toList()).get(0);
            b1_downscale = parametersList.stream().filter(p -> p.getCode().equals(B1_DOWN_SCALE)).collect(Collectors.toList()).get(0);
            r0_downscale = parametersList.stream().filter(p -> p.getCode().equals(R0_DOWN_SCALE)).collect(Collectors.toList()).get(0);
        }

        if (i1_downscale_pmax_time != null)
            i1 = Integer.parseInt(i1_downscale_pmax_time.getValue());

        if (a1_downscale != null)
            a1Downscale = Double.parseDouble(a1_downscale.getValue());

        if (b1_downscale != null)
            b1Downscale = Double.parseDouble(b1_downscale.getValue());

        if (r0_downscale != null)
            r0Downscale = Double.parseDouble(r0_downscale.getValue());

        sw.stop();
        logger.info("StopWatch - Fetching the details from parameter table took {}ms", sw.getTime());
    }

}
