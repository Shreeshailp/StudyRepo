/*
 * Creation : 9 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.VehicleCategory;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface VehicleCategoryFinder. This finder is used to retrieve representations of {@link VehicleCategory} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface VehicleCategoryFinder {

    /**
     * Retrieve the representation of all {@link VehicleCategory} entities.
     *
     * @param filter the filtering category
     * @return a representation of all vehicle categories
     */
    CollectionRepresentation all(String filter);

    /**
     * Retrieve a specific {@link VehicleCategory} representation identified by its {@code code} or its UUID entity id.
     *
     * @param category the vehicle category identifier
     * @return the vehicle category representation
     */
    Optional<VehicleCategoryRepresentation> get(String category);

    /**
     * Retrieve a specific {@link VehicleCategory} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return the vehicle category representation
     */
    Optional<VehicleCategoryRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link VehicleCategory} representation identified by its {@code code}.
     *
     * @param code the code
     * @return the vehicle category representation
     */
    Optional<VehicleCategoryRepresentation> byCode(String code);

}
