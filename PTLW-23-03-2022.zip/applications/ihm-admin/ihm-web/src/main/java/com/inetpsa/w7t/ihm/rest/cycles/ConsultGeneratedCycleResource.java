/*
 * Creation : 8 Apr 2019
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * The Class ConsultGeneratedCycleResource.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.CONSULT_GENERATED_CYCLE)
@Api
public class ConsultGeneratedCycleResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycles finder. */
    @Inject
    CyclesFinder cyclesFinder;

    /**
     * To get the REST representation of a specific cycle details identified by its UUID entity id.
     *
     * @param id the id
     * @return the response
     */
    @Path("{" + CatalogRels.CYCLE + "}")
    @Rel(value = CatalogRels.CONSULT_GENERATED_CYCLE, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response findById(@PathParam(CatalogRels.CYCLE) String id) {
        CollectionRepresentation cycle = cyclesFinder.byGeneratedCycleId(id);

        return Response.ok(cycle).build();
    }

}
