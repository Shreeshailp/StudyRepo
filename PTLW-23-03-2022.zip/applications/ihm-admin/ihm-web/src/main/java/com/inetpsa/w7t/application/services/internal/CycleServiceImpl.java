/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.CycleParserService;
import com.inetpsa.w7t.application.services.CycleService;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.model.CycleDto;
import com.inetpsa.w7t.domains.cycles.model.CycleProfile;
import com.inetpsa.w7t.domains.cycles.shared.CycleErrorCode;
import com.inetpsa.w7t.domains.cycles.shared.CycleReferencesPolicy;
import com.inetpsa.w7t.domains.cycles.shared.CycleValidationException;
import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.cycles.CycleRepresentation;
import com.inetpsa.w7t.ihm.rest.cycles.CyclesFinder;

/**
 * The Class CycleServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class CycleServiceImpl implements CycleService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The User service. */
    @Inject
    UserService userService;

    /** The Cycle Parser Service. */
    @Inject
    private CycleParserService cycleParserService;

    /** The Cycle References Policy. */
    @Inject
    private CycleReferencesPolicy cycleReferencesPolicy;

    /** The Cycle repository. */
    @Inject
    private CycleRepository cycleRepository;

    /** The Cycle Details repository. */
    @Inject
    private CycleDetailsRepository cycleDetailsRepository;

    /** The generic Cycle repository. */
    @Inject
    @Jpa
    private Repository<CycleDetails, UUID> cycleRepo;

    /** The Cycle Details factory. */
    @Inject
    private Factory<CycleDetails> cycleDetailsfactory;

    /** The Cycle Profile factory. */
    @Inject
    private Factory<CycleProfile> cycleProfileFactory;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /** The Cycles finder. */
    @Inject
    CyclesFinder cyclesFinder;

    @Inject
    GeneratedCycleRepository generatedCycleRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.CycleService#upload(java.io.InputStream, java.lang.Boolean)
     */
    @Override
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException {

        List<CycleDto> cycles = cycleParserService.parse(inputStream);

        if (!forceUpdate)
            checkExistence(cycles);

        List<CycleDetails> cycleDetailsList = importCycles(cycles, forceUpdate);

        List<Cycle> cycleList = new ArrayList<>();

        cycleDetailsList.stream().forEach(details -> {
            Optional<Cycle> cycle = cycleRepository.byCode(details.getCode());
            if (cycle.isPresent()) {
                cycleList.add(cycle.get());
            }

        });

        List<CycleRepresentation> cycleRepresentationList = fluentAssembler.assemble(cycleList).with(WltpModelMapper.class)
                .to(CycleRepresentation.class);

        cycleRepresentationList.stream().forEach(cycle -> {
            cycle.self(relRegistry.uri(CatalogRels.CYCLE).templated());
            cycle.link("find", relRegistry.uri(CatalogRels.CYCLE).templated());
            cycle.embedded(CatalogRels.CYCLES, cycleList);
        });

        CollectionRepresentation cyclesList = new CollectionRepresentation(cycleList.size(), false);

        cyclesList.self(relRegistry.uri(CatalogRels.CYCLES).templated());
        cyclesList.link("find", relRegistry.uri(CatalogRels.CYCLES).templated());
        cyclesList.embedded(CatalogRels.CYCLES, cycleList);

        return cyclesList;

    }

    /**
     * Check existence.
     *
     * @param cycles the cycles
     */
    private void checkExistence(List<CycleDto> cycles) {
        cycles.stream().forEach(cycleDto -> {
            Boolean exists = cycleDetailsRepository.exists(cycleDto.getCode());

            /** RG18 **/
            if (exists) {
                // fix for JIRA-439 check generated cycle exists
                GeneratedCycle generatedCycle = generatedCycleRepository.byCycleCode(cycleDto.getCode());
                if (generatedCycle != null)
                    throw new CycleValidationException(CycleErrorCode.CYCLE_PROFILE_EXISTS_WITH_GENERATED_CYCLE);

                throw new CycleValidationException(CycleErrorCode.CYCLE_PROFILE_EXISTS);
            }
        });
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.CycleService#importCycles(java.util.List, java.lang.Boolean)
     */
    @Override
    public List<CycleDetails> importCycles(List<CycleDto> cycles, Boolean forceUpdate) {
        List<CycleDetails> cycleDetailsList = new ArrayList<>();

        for (CycleDto cycleDto : cycles) {

            boolean isValid = false;
            CycleDetails cycleDetails;
            Optional<CycleDetails> optCycle = cycleDetailsRepository.byCode(cycleDto.getCode());
            if (optCycle.isPresent()) {
                cycleDetails = optCycle.get();
                mergeAggregateWithDto(cycleDto, cycleDetails);
            } else {

                cycleDetails = cycleDetailsfactory.create();
                mergeAggregateWithDto(cycleDto, cycleDetails);
            }

            isValid = cycleReferencesPolicy.isValid(cycleDetails);

            if (isValid) {
                int deleted = 0;
                if (forceUpdate) {
                    cycleRepo.save(cycleDetails);
                    // Lot 10 change here delete updated cycle related records from W7TQTCYG table
                    deleted = generatedCycleRepository.deleteByCycleCode(cycleDetails.getCode());
                } else {
                    cycleRepo.persist(cycleDetails);
                }
                cycleDetailsList.add(cycleDetails);

                String userId = userService.getUserId();
                StringBuilder traceLog = new StringBuilder();
                traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString())
                        .append(" Import Cycle Profile Code ").append(cycleDetails.getCode()).toString();
                if (deleted > 0)
                    traceLog.append(" and all the generated cycles deleted.");
                String trace = traceLog.toString();
                logger.info(trace);

            }
        }

        return cycleDetailsList;
    }

    /**
     * Merge aggregate with dto.
     *
     * @param cycleDto the cycle dto
     * @param cycleDetails the cycle details
     */
    private void mergeAggregateWithDto(CycleDto cycleDto, CycleDetails cycleDetails) {

        cycleDetails.setCode(cycleDto.getCode());
        cycleDetails.setPhase(cycleDto.getPhase());
        cycleDetails.setComment(cycleDto.getComment());
        cycleDetails.setProfiles(populateProfiles(cycleDetails.getProfiles(), cycleDto));

        /** Lot 10 Changes */
        Optional<CycleProfile> optCycleProfile = cycleDetails.getProfiles().stream().max(Comparator.comparing(CycleProfile::getVelocity));
        if (optCycleProfile.isPresent()) {
            cycleDetails.setCycleMaxVelocity(optCycleProfile.get().getVelocity());
        }
    }

    /**
     * Populate profiles.
     *
     * @param cycleProfiles the cycle profiles
     * @param cycleDto the cycle dto
     * @return the list
     */
    private List<CycleProfile> populateProfiles(List<CycleProfile> cycleProfiles, CycleDto cycleDto) {

        if (cycleDetailsRepository.exists(cycleDto.getCode())) {
            cycleProfiles.clear();

            cycleDto.getProfiles().stream().forEach(cycleDtoProfile -> {
                CycleProfile cycleProfile = cycleProfileFactory.create();
                cycleProfile.setTime(cycleDtoProfile.getTime());
                cycleProfile.setVelocity(cycleDtoProfile.getVelocity());
                cycleProfile.setDistance(cycleDtoProfile.getDistance());
                cycleProfile.setAcceleration(cycleDtoProfile.getAcceleration());
                cycleProfiles.add(cycleProfile);
            });
            return cycleProfiles;
        }

        List<CycleProfile> cycleProfilesUpdated = new ArrayList<>();

        cycleDto.getProfiles().stream().forEach(cycleDtoProfile -> {
            CycleProfile cycleProfile = cycleProfileFactory.create();
            cycleProfile.setTime(cycleDtoProfile.getTime());
            cycleProfile.setVelocity(cycleDtoProfile.getVelocity());
            cycleProfile.setDistance(cycleDtoProfile.getDistance());
            cycleProfile.setAcceleration(cycleDtoProfile.getAcceleration());
            cycleProfilesUpdated.add(cycleProfile);
        });

        return cycleProfilesUpdated;
    }
}
