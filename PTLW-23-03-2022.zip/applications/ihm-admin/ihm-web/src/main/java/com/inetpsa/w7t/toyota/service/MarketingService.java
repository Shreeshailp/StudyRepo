/*
 * Creation : 15 avr. 2018
 */
package com.inetpsa.w7t.toyota.service;

import org.seedstack.business.Service;

@Service
@FunctionalInterface
public interface MarketingService {

    public void getEmissionResult(String fileLocation, boolean wltphubFlag);

}
