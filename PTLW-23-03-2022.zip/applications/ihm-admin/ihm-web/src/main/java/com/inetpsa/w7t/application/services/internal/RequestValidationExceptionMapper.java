/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.application.services.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.domains.engine.shared.RequestValidationException;

@Provider
public class RequestValidationExceptionMapper implements ExceptionMapper<RequestValidationException> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
     */
    @Override
    public Response toResponse(RequestValidationException exception) {
        Status status = Response.Status.BAD_REQUEST;

        return Response.status(status).entity(configureError(exception)).build();
    }

    private WLTPError configureError(RequestValidationException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    class WLTPError {
        private String errorCode;
        private String errorMsg;

        public String getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }
}
