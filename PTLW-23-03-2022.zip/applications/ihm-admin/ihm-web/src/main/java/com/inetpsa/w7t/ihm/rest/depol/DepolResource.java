/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.ihm.rest.depol;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.DepolService;
import com.inetpsa.w7t.application.services.DepolStatusReportService;
import com.inetpsa.w7t.application.utilities.ConvertExcelDataToBytes;
import com.inetpsa.w7t.application.utilities.ExportUtility;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.depol.exceptions.DepolErrorCode;
import com.inetpsa.w7t.domains.depol.exceptions.DepolException;
import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.domains.depol.model.DepolDto;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.ApiOperation;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.IMPORTDEPOL)
public class DepolResource {
    /** The logger. */
    @Logging
    private Logger logger;

    /** The user service. */
    @Inject
    UserService userService;
    @Inject
    DepolService depolService;
    @Inject
    DepolFinder depolFinder;

    /** The fs flag file path. */
    @Configuration("fsFlagFilePath")
    private String fsFlagFilePath;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant SUFFIX. */
    @Configuration("xlsxSimulationSuffix")
    private String suffix;

    /** The prefix. */
    @Configuration("filePrefix")
    private String prefix;

    @Inject
    DepolStatusReportService depolStatusReportService;

    // fixed jira-523
    private static final String[] depolHeaders = { "E", "CODE_DEPOL", "CODE_SPECIAL", "DEPOL_LABEL", "RCRRTR_MIN", "RCRRTR_MAX", "MROTR_MIN",
            "MROTR_MAX", "STR_MIN", "STR_MAX", "COOLSTR_MIN", "COOLSTR_MAX", "CX_MIN", "CX_MAX" };

    /** The Constant depolImportStatusHeaders. */
    private static final String[] depolImportStatusHeaders = { "CODE_DEPOL", "CODE_SPECIAL", "DEPOL_LABEL", "RCRRTR_MIN", "RCRRTR_MAX", "MROTR_MIN",
            "MROTR_MAX", "STR_MIN", "STR_MAX", "COOLSTR_MIN", "COOLSTR_MAX", "CX_MIN", "CX_MAX", "CHECKING" };

    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })

    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDisposition,
            @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate) {

        try {
            String fileName = fileDisposition.getFileName();
            FileInputValidator.isNotNull(inputStream);
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new DepolException(DepolErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            return Response.ok(depolService.upload(inputStream, forceUpdate, fileName)).build();
        } catch (IOException e) {
            logger.error("IOException while uploading DEPOL details : ", e.getMessage(), e);
            DepolException cve = new DepolException(DepolErrorCode.UNKNOWN_EXCEPTION, null);
            cve.initCause(e);
            throw cve;
        } catch (DepolException e) {
            logger.error("DepolException while uploading DEPOL details : {}", e.getMessage());
            throw e;
        } catch (Exception e) {

            if (e instanceof ConstraintViolationException) {
                Optional<ConstraintViolation<?>> error = ((ConstraintViolationException) e).getConstraintViolations().stream().findFirst();
                if (error.isPresent()) {
                    throw new DepolException(DepolErrorCode.DEPOL_UNKNOWN_EXCEPTION, null);
                }
            }
            logger.error("Exception while uploading DEPOL details : ", e.getMessage(), e);
            Object[] errMsg = { e.getMessage() };
            throw new DepolException(DepolErrorCode.DEPOL_UNKNOWN_ERROR, errMsg);
        }

    }

    @Rel(value = CatalogRels.IMPORTDEPOL, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "fetchData", response = CollectionRepresentation.class)
    public Response getDepols() {
        CollectionRepresentation depols = depolFinder.all();
        return Response.ok(depols).build();
    }

    @Rel(value = CatalogRels.DEPOLSEARCH, home = true)
    @GET
    @Path(CatalogRels.DEPOLSEARCH)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "filter", response = CollectionRepresentation.class)
    public Response depolSearch(@BeanParam DepolFilter filter) {
        CollectionRepresentation depols = depolFinder.filter(filter);
        return Response.ok(depols).build();
    }

    @Rel(value = CatalogRels.DEPOL_EXPORT, home = true)
    @GET
    @Path(CatalogRels.DEPOL_EXPORT)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "export", response = CollectionRepresentation.class)
    public Response depolExport() {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new DepolException(DepolErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        List<Depol> depols = depolFinder.allDepols();
        byte[] bytes = ExportUtility.writeDepolToExcel(depolHeaders, depols, userService.getUserId());
        ConvertExcelDataToBytes dataInBytes = new ConvertExcelDataToBytes();
        dataInBytes.setBytes(bytes);
        return Response.ok(dataInBytes).build();
    }

    @Rel(value = CatalogRels.DEPOL_IMPORT_STATUS, home = true)
    @GET
    @Path(CatalogRels.DEPOL_IMPORT_STATUS)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "export", response = CollectionRepresentation.class)
    public Response depolImportStatusExport(@QueryParam("fileName") String fileName) {
        logger.info("Depol import status file to be exported is :[{}]", fileName);
        ConvertExcelDataToBytes dataInBytes = new ConvertExcelDataToBytes();
        if (StringUtils.isNotEmpty(fileName)) {
            List<DepolDto> depols = depolStatusReportService.getDepolStatusReportByFileName(fileName);
            if (depols != null && !depols.isEmpty()) {
                byte[] bytes = ExportUtility.writeDepolImportStatusToExcel(depolImportStatusHeaders, depols, userService.getUserId());
                dataInBytes = new ConvertExcelDataToBytes();
                dataInBytes.setBytes(bytes);
            } else {
                logger.info("Depol import status data not found!");
                dataInBytes.setBytes(null);
            }
        } else {
            logger.info("Depol import status file name is empty or null");
        }
        return Response.ok(dataInBytes).build();
    }
}
