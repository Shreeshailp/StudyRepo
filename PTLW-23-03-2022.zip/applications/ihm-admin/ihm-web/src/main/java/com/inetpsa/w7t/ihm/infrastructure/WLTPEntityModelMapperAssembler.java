/*
 * Creation : 6 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure;

import java.time.LocalDate;
import java.util.UUID;

import javax.inject.Inject;

import org.modelmapper.AbstractConverter;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration.AccessLevel;
import org.seedstack.business.assembler.modelmapper.ModelMapperAssembler;
import org.seedstack.business.domain.AggregateRoot;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.spi.GenericImplementation;

import com.google.inject.assistedinject.Assisted;
import com.inetpsa.w7t.domains.core.model.WLTPEntity;

/**
 * The Class WLTPEntityModelMapperAssembler.
 *
 * @param <A> any entity extending {@link AggregateRoot}, either directly through {@link BaseAggregateRoot} or {@link WLTPEntity}.
 * @param <D> the identifier type
 */
@WltpModelMapper
@GenericImplementation
public class WLTPEntityModelMapperAssembler<A extends AggregateRoot<?>, D> extends ModelMapperAssembler<A, D> {

    /**
     * Instantiates a new WLTP entity model mapper assembler.
     *
     * @param genericClasses the generic classes
     */
    @SuppressWarnings("unchecked")
    @Inject
    public WLTPEntityModelMapperAssembler(@Assisted Object[] genericClasses) {
        super((Class<D>) genericClasses.clone()[1]);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.assembler.modelmapper.ModelMapperAssembler#configureAssembly(org.modelmapper.ModelMapper)
     */
    @Override
    protected void configureAssembly(ModelMapper modelMapper) {
        // We do not add converters here since LocalDate and UUID display their correct representation via a toString().
        modelMapper.getConfiguration().setFieldMatchingEnabled(true).setFieldAccessLevel(AccessLevel.PRIVATE);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.assembler.modelmapper.ModelMapperAssembler#configureMerge(org.modelmapper.ModelMapper)
     */
    @Override
    protected void configureMerge(ModelMapper modelMapper) {
        modelMapper.addConverter(new AbstractConverter<String, UUID>() {
            @Override
            protected UUID convert(String source) {
                if (source != null)
                    return UUID.fromString(source);
                return null;
            }
        });

        modelMapper.addConverter(new AbstractConverter<String, LocalDate>() {
            @Override
            protected LocalDate convert(String source) {
                if (source != null)
                    return LocalDate.parse(source);
                return null;
            }
        });

    }

}
