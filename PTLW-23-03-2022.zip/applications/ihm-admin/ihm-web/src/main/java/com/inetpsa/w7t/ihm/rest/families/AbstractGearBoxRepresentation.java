/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

/**
 * @author E569186
 */
public class AbstractGearBoxRepresentation extends HalRepresentation {

    /** The guid. */
    private UUID guid;

    /** The code. */
    private String code;

    /** The designation. */
    private String designation;

    /** The characteristic. */
    private String characteristic;

    /**
     * Getter guid
     * 
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid
     * 
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter code
     * 
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter code
     * 
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Getter designation
     * 
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Setter designation
     * 
     * @param designation the designation to set
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * Getter characteristic
     * 
     * @return the characteristic
     */
    public String getCharacteristic() {
        return characteristic;
    }

    /**
     * Setter characteristic
     * 
     * @param characteristic the characteristic to set
     */
    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

}
