/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.ihm.rest.change.history.resource;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.ihm.infrastructure.finders.jpa.ChangeHistoryFinder;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.ApiOperation;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.CHANGE_HISTORY)
public class ChangeHistoryRequestResource {
    /** The logger. */
    @Logging
    private Logger logger;

    @Inject
    ChangeHistoryFinder changeHistoryFinder;

    @Rel(value = CatalogRels.CHANGE_HISTORY, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response getAllChangeHistoryData() {
        CollectionRepresentation changeHistoryData = changeHistoryFinder.all();
        return Response.ok(changeHistoryData).build();
    }

    @Rel(value = CatalogRels.CHANGE_HISTORY_SEARCH, home = true)
    @GET
    @Path(CatalogRels.CHANGE_HISTORY_SEARCH)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response changeHistorySearch(@BeanParam ChangeHistoryFilter filter) {
        CollectionRepresentation changeHistorySearch = changeHistoryFinder.filter(filter);
        return Response.ok(changeHistorySearch).build();
    }
}
