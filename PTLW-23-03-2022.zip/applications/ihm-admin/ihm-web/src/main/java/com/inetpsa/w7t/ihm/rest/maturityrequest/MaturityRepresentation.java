/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.ihm.rest.maturityrequest;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.maturity.model.Maturity;

@DtoOf(Maturity.class)
public class MaturityRepresentation extends AbstractMaturityRepresentation {

}
