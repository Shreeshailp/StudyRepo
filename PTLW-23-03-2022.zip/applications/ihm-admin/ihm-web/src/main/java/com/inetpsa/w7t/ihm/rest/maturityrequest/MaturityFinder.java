/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.ihm.rest.maturityrequest;

import java.util.List;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface MaturityFinder {
    CollectionRepresentation all();

    CollectionRepresentation filter(MaturityFilter filter);

    List<Maturity> allMaturities();

    List<Maturity> filterMaturity(MaturityFilter filter);
}
