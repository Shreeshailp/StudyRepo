/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.inetpsa.w7t.ihm.infrastructure.finders.jpa.MoteurGearBoxFinder;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Class MotoGearBoxResource.
 *
 * @author E569186
 */
@Path("/moteurgearbox")
public class MoteurGearBoxResource {

    @Inject
    private MoteurGearBoxFinder moteurGearBoxFinder;

    /**
     * Gets the moteur details.
     *
     * @return the moteur details
     */
    @POST
    @Path("/getmoteurdetails")
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getMoteurDetails() {
        CollectionRepresentation response = moteurGearBoxFinder.getAllMoteur();
        return Response.ok(response).build();

    }

    /**
     * Gets the gear box details.
     *
     * @return the gear box details
     */
    @POST
    @Path("/getgearboxdetails")
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getGearBoxDetails() {
        CollectionRepresentation response = moteurGearBoxFinder.getAllGearBox();
        return Response.ok(response).build();

    }
}
