/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.application.services.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.domains.depol.exceptions.DepolErrorCode;
import com.inetpsa.w7t.domains.depol.exceptions.DepolException;

@Provider
public class DepolExceptionMapper implements ExceptionMapper<DepolException> {
    @Override
    public Response toResponse(DepolException exception) {

        Status status = Response.Status.BAD_REQUEST;
        String ruleCode = ((DepolErrorCode) exception.getErrorCode()).getRuleCode();
        if ("RG61".equals(ruleCode) || "RG62".equals(ruleCode) || "RG65".equals(ruleCode)) {
            status = Response.Status.PRECONDITION_FAILED;
        } else if ("RG66".equals(ruleCode) || "RG90".equals(ruleCode)) {
            status = Response.Status.CONFLICT;
        }
        return Response.status(status).entity(configureError(exception)).build();
    }

    private WLTPError configureError(DepolException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    /**
     * The Class WLTPError.
     */
    class WLTPError {

        /** The error code. */
        private String errorCode;

        /** The error msg. */
        private String errorMsg;

        /**
         * Gets the error code.
         *
         * @return the error code
         */
        public String getErrorCode() {
            return errorCode;
        }

        /**
         * Sets the error code.
         *
         * @param errorCode the new error code
         */
        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        /**
         * Gets the error msg.
         *
         * @return the error msg
         */
        public String getErrorMsg() {
            return errorMsg;
        }

        /**
         * Sets the error msg.
         *
         * @param errorMsg the new error msg
         */
        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }

}
