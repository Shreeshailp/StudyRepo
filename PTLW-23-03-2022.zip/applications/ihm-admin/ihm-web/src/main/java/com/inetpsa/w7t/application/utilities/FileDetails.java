/*
 * Creation : 8 Jul 2019
 */
package com.inetpsa.w7t.application.utilities;

/**
 * The Class FileDetails.
 */
public class FileDetails {

    /** The file content. */
    private StringBuffer fileContent;

    /**
     * Gets the file content..
     *
     * @return the file content
     */
    public StringBuffer getFileContent() {
        return fileContent;
    }

    /**
     * Sets the file content.
     *
     * @param fileContent the new file content
     */
    public void setFileContent(StringBuffer fileContent) {
        this.fileContent = fileContent;
    }

    /**
     * The Class BillPughSingleton.
     */
    private static class BillPughSingleton {

        /** The Constant INSTANCE. */
        private static final FileDetails INSTANCE = new FileDetails();
    }

    /**
     * Instantiates a new file details.
     *
     * @return single instance of FileDetails
     */
    public static FileDetails getInstance() {

        return BillPughSingleton.INSTANCE;
    }

    /**
     * Instantiates a new file details.
     */
    private FileDetails() {
        // do nothing
    }

}
