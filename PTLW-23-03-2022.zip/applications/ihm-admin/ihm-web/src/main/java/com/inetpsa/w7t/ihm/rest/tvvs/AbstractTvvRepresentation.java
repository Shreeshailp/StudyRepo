/*
 * Creation : 17 May 2018
 */
package com.inetpsa.w7t.ihm.rest.tvvs;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

public class AbstractTvvRepresentation extends HalRepresentation {

    /** The guid. */
    protected UUID guid;

    protected String vehicleFamily;

    protected String t1AValue;

    protected String t1BValue;

    protected String tvvDesignation;

    protected Float tvvHeigth;

    protected Float tvvWidth;

    protected Float tvvAf;

    protected Integer tvvMaxspeed;

    protected Float tvvScxBase;

    protected String tvvVehicleCategory;

    protected String tvvCompleteFlag;

    protected String tvvCodeDepol;

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getVehicleFamily() {
        return vehicleFamily;
    }

    public void setVehicleFamily(String vehicleFamily) {
        this.vehicleFamily = vehicleFamily;
    }

    public String getT1AValue() {
        return t1AValue;
    }

    public void setT1AValue(String t1aValue) {
        t1AValue = t1aValue;
    }

    public String getT1BValue() {
        return t1BValue;
    }

    public void setT1BValue(String t1bValue) {
        t1BValue = t1bValue;
    }

    public String getTvvDesignation() {
        return tvvDesignation;
    }

    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    public Float getTvvHeigth() {
        return tvvHeigth;
    }

    public void setTvvHeigth(Float tvvHeigth) {
        this.tvvHeigth = tvvHeigth;
    }

    public Float getTvvWidth() {
        return tvvWidth;
    }

    public void setTvvWidth(Float tvvWidth) {
        this.tvvWidth = tvvWidth;
    }

    public Float getTvvAf() {
        return tvvAf;
    }

    public void setTvvAf(Float tvvAf) {
        this.tvvAf = tvvAf;
    }

    public Integer getTvvMaxspeed() {
        return tvvMaxspeed;
    }

    public void setTvvMaxspeed(Integer tvvMaxspeed) {
        this.tvvMaxspeed = tvvMaxspeed;
    }

    public Float getTvvScxBase() {
        return tvvScxBase;
    }

    public void setTvvScxBase(Float tvvScxBase) {
        this.tvvScxBase = tvvScxBase;
    }

    public String getTvvVehicleCategory() {
        return tvvVehicleCategory;
    }

    public void setTvvVehicleCategory(String tvvVehicleCategory) {
        this.tvvVehicleCategory = tvvVehicleCategory;
    }

    public String getTvvCompleteFlag() {
        return tvvCompleteFlag;
    }

    public void setTvvCompleteFlag(String tvvCompleteFlag) {
        this.tvvCompleteFlag = tvvCompleteFlag;
    }

    public String getTvvCodeDepol() {
        return tvvCodeDepol;
    }

    public void setTvvCodeDepol(String tvvCodeDepol) {
        this.tvvCodeDepol = tvvCodeDepol;
    }
}
