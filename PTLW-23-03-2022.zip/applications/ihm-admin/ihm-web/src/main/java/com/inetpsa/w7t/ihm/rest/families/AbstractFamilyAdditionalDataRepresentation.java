/*
 * Creation : 13 Jul 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

public abstract class AbstractFamilyAdditionalDataRepresentation extends HalRepresentation {

    private UUID id;

    private String t8c;

    private String t8d;

    private String vehicleFamilies;

    private String motorB0F;

    private String gearboxB0G;

    private String motorDkc;

    private String dldDate;

    private String dllDate;

    private String firstRegDate;

    private String rceDate;

    private String window;

    private String urlDossier;

    private String urlPv;

    private String urlImportFile;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getT8c() {
        return t8c;
    }

    public void setT8c(String t8c) {
        this.t8c = t8c;
    }

    public String getT8d() {
        return t8d;
    }

    public void setT8d(String t8d) {
        this.t8d = t8d;
    }

    public String getVehicleFamilies() {
        return vehicleFamilies;
    }

    public void setVehicleFamilies(String vehicleFamilies) {
        this.vehicleFamilies = vehicleFamilies;
    }

    public String getMotorB0F() {
        return motorB0F;
    }

    public void setMotorB0F(String motorB0F) {
        this.motorB0F = motorB0F;
    }

    public String getGearboxB0G() {
        return gearboxB0G;
    }

    public void setGearboxB0G(String gearboxB0G) {
        this.gearboxB0G = gearboxB0G;
    }

    public String getMotorDkc() {
        return motorDkc;
    }

    public void setMotorDkc(String motorDkc) {
        this.motorDkc = motorDkc;
    }

    public String getDldDate() {
        return dldDate;
    }

    public void setDldDate(String dldDate) {
        this.dldDate = dldDate;
    }

    public String getDllDate() {
        return dllDate;
    }

    public void setDllDate(String dllDate) {
        this.dllDate = dllDate;
    }

    public String getFirstRegDate() {
        return firstRegDate;
    }

    public void setFirstRegDate(String firstRegDate) {
        this.firstRegDate = firstRegDate;
    }

    public String getRceDate() {
        return rceDate;
    }

    public void setRceDate(String rceDate) {
        this.rceDate = rceDate;
    }

    public String getWindow() {
        return window;
    }

    public void setWindow(String window) {
        this.window = window;
    }

    public String getUrlDossier() {
        return urlDossier;
    }

    public void setUrlDossier(String urlDossier) {
        this.urlDossier = urlDossier;
    }

    public String getUrlPv() {
        return urlPv;
    }

    public void setUrlPv(String urlPv) {
        this.urlPv = urlPv;
    }

    public String getUrlImportFile() {
        return urlImportFile;
    }

    public void setUrlImportFile(String urlImportFile) {
        this.urlImportFile = urlImportFile;
    }

}
