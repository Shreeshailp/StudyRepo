/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;

/**
 * The Class PhysicalQuantityTypeRepresentation. This representation is used to represent a specific {@link PhysicalQuantityType}.
 */
@DtoOf(PhysicalQuantityType.class)
public class PhysicalQuantityTypeRepresentation extends ReferenceRepresentation {

    /** The sort. */
    private Integer sort;

    /**
     * Gets the sort.
     *
     * @return the sort
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * Sets the sort.
     *
     * @param sort the new sort
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }
}
