/*
 * Creation : 5 avr. 2017
 */
package com.inetpsa.w7t.ihm.rest.request;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.ManualRequestService;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.toyota.validation.ToyotaErrorCode;
import com.inetpsa.w7t.toyota.validation.ToyotaException;

/**
 * The RequestResource is meant to upload the simulation(manual request) file and to provide the response of the same.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.SIMULATION)
public class RequestResource {

    /** The manual output dir. */
    @Configuration("manualOutputDir")
    private File manualOutputDir;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The Manual Request Service. */
    @Inject
    private ManualRequestService manualRequestService;

    /** The fs flag file path. */
    @Configuration("fsFlagFilePath")
    private String fsFlagFilePath;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant SUFFIX. */
    @Configuration("xlsxSimulationSuffix")
    private String suffix;

    /** The prefix. */
    @Configuration("filePrefix")
    private String prefix;

    /**
     * The upload of the manual request file. If the upload is successful, the file ID of the uploaded file is returned.
     *
     * @param inputStream the input stream
     * @param fileDisposition the file disposition
     * @return the response
     */
    @Rel(value = CatalogRels.SIMULATION, home = true)
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDisposition) {
        String uploadFileId = null;
        ManualRequestFile mrFile = new ManualRequestFile();
        try {
            FileInputValidator.isNotNull(inputStream);
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new ToyotaException(ToyotaErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            FileHandlingUtility.createFsFlagFile(fsFlagFilePath, indusFlagFilePath, prefix + "_manual", suffix);
            uploadFileId = manualRequestService.processManualRequest(inputStream);
            mrFile.setFileId(uploadFileId);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return Response.status(Response.Status.BAD_REQUEST).entity("").build();
        }
        return Response.ok(mrFile).build();

    }

    /**
     * Status check.
     *
     * @param fileId the file id
     * @return the response
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Path("{" + CatalogRels.FILE_ID + "}")
    @Rel(value = CatalogRels.STATUS_CHECK, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response statusCheck(@PathParam("fileId") String fileId) throws IOException {

        StringBuilder xmlString = new StringBuilder();
        CorvetAnswer cAnswer = new CorvetAnswer();
        String uploadFileStatus = "I";
        String uploadFileGuid = "invalid";
        Optional<RequestBatchEntity> fileBatchObject = manualRequestService.getRequestBatchByFileId(fileId);

        if (fileBatchObject.isPresent()) {
            uploadFileStatus = fileBatchObject.get().getStatus();
            uploadFileGuid = fileBatchObject.get().getGuid().toString();
            cAnswer.setFileStatus(uploadFileStatus);
        }
        if ("G".equals(uploadFileStatus)) {
            StringBuilder answerFilePath = new StringBuilder(manualOutputDir.getAbsolutePath()).append(File.separator).append("answer_manual_")
                    .append(uploadFileGuid).append(".xml");

            try (FileReader fr = new FileReader(answerFilePath.toString())) {
                try (BufferedReader br = new BufferedReader(fr)) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        xmlString.append(line.trim());
                    }
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                    cAnswer.setFileStatus("I");
                    return Response.ok(cAnswer).build();
                }
            }

            cAnswer.setAnswerFileContent(xmlString);
            return Response.ok(cAnswer).build();

        }
        cAnswer.setAnswerFileContent(xmlString);
        return Response.ok(cAnswer).build();
    }

    /**
     * Class to build JSON response for status check method of Simulation.
     */
    class CorvetAnswer {

        /** The answer file content. */
        private StringBuilder answerFileContent;

        /** The file status. */
        private String fileStatus;

        /**
         * Gets the answer file content.
         *
         * @return the answer file content
         */
        public StringBuilder getAnswerFileContent() {
            return answerFileContent;
        }

        /**
         * Sets the answer file content.
         *
         * @param answerFileContent the new answer file content
         */
        public void setAnswerFileContent(StringBuilder answerFileContent) {
            this.answerFileContent = answerFileContent;
        }

        /**
         * Gets the file status.
         *
         * @return the file status
         */
        public String getFileStatus() {
            return fileStatus;
        }

        /**
         * Sets the file status.
         *
         * @param fileStatus the new file status
         */
        public void setFileStatus(String fileStatus) {
            this.fileStatus = fileStatus;
        }

    }

    /**
     * Class to build JSON response for upload method of Simulation.
     */
    class ManualRequestFile {

        /** The file id. */
        private String fileId;

        /**
         * Gets the file id.
         *
         * @return the file id
         */
        public String getFileId() {
            return fileId;
        }

        /**
         * Sets the file id.
         *
         * @param fileId the new file id
         */
        public void setFileId(String fileId) {
            this.fileId = fileId;
        }

    }
}
