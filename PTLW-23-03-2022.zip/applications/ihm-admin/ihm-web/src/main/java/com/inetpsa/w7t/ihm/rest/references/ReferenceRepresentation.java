/*
 * Creation : 7 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

/**
 * The Class ReferenceRepresentation. Default representation for all reference representations;
 */
public class ReferenceRepresentation extends HalRepresentation {

    /** The guid. */
    protected UUID guid;

    /** The code. */
    protected String code;

    /** The label. */
    protected String label;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }
}
