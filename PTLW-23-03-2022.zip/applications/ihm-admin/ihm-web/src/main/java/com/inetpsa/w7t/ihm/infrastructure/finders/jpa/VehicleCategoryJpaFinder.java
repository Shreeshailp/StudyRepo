/*
 * Creation : 9 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.Validation;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.slf4j.Logger;

import com.google.common.base.Strings;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.references.model.VehicleCategory;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.references.VehicleCategoryFinder;
import com.inetpsa.w7t.ihm.rest.references.VehicleCategoryRepresentation;

/**
 * The Class VehicleCategoryJpaFinder. This is the JPA Implementation of the {@link VehicleCategoryFinder}.
 */
public class VehicleCategoryJpaFinder implements VehicleCategoryFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    private FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleCategoryFinder#all(java.lang.String)
     */
    @Override
    public CollectionRepresentation all(String filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> q = cb.createQuery(VehicleCategory.class);
        Root<VehicleCategory> root = q.from(VehicleCategory.class);

        if (!Strings.isNullOrEmpty(filter))
            q.where(cb.like(cb.lower(root.get(CODE)), cb.parameter(String.class, CODE)));
        else
            q.select(root);

        TypedQuery<VehicleCategory> query = entityManager.createQuery(q);

        if (!Strings.isNullOrEmpty(filter))
            query.setParameter(CODE, '%' + filter.toLowerCase() + '%');

        List<VehicleCategoryRepresentation> categoryList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(VehicleCategoryRepresentation.class);

        categoryList.stream().forEach(category -> {
            category.setLabel(labelService.value(category.getGuid()));
            category.self(relRegistry.uri(CatalogRels.VEHICLE_CATEGORY).set(CatalogRels.VEHICLE_CATEGORY, category.getGuid()));
        });

        CollectionRepresentation categories = new CollectionRepresentation(categoryList.size(), false);

        categories.self(relRegistry.uri(CatalogRels.VEHICLE_CATEGORIES).templated());
        categories.link("find", relRegistry.uri(CatalogRels.VEHICLE_CATEGORY).templated());
        categories.embedded(CatalogRels.VEHICLE_CATEGORIES, categoryList);

        return categories;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleCategoryFinder#get(java.lang.String)
     */
    @Override
    public Optional<VehicleCategoryRepresentation> get(String category) {
        if (Validation.buildDefaultValidatorFactory().getValidator().validateValue(VehicleCategory.class, CODE, category).isEmpty())
            return byCode(category);
        return byId(category);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleCategoryFinder#byId(java.lang.String)
     */
    @Override
    public Optional<VehicleCategoryRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> q = cb.createQuery(VehicleCategory.class);
        Root<VehicleCategory> c = q.from(VehicleCategory.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<VehicleCategory> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        List<VehicleCategory> list = query.getResultList();
        Optional<VehicleCategory> vehicleCategoryObj = Optional.empty();
        if (!list.isEmpty()) {
            vehicleCategoryObj = list.stream().findFirst();
        }

        Optional<VehicleCategoryRepresentation> vehicleCategory = vehicleCategoryObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(VehicleCategoryRepresentation.class));

        vehicleCategory.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).set(CatalogRels.TEST_VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPES).templated());
        });

        return vehicleCategory;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleCategoryFinder#byCode(java.lang.String)
     */
    @Override
    public Optional<VehicleCategoryRepresentation> byCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> q = cb.createQuery(VehicleCategory.class);
        Root<VehicleCategory> c = q.from(VehicleCategory.class);
        q.where(cb.equal(cb.lower(c.get(CODE)), cb.lower(cb.parameter(String.class, CODE))));

        TypedQuery<VehicleCategory> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        List<VehicleCategory> list = query.getResultList();
        Optional<VehicleCategory> vehicleCategoryObj = Optional.empty();
        if (!list.isEmpty()) {
            vehicleCategoryObj = list.stream().findFirst();
        }

        Optional<VehicleCategoryRepresentation> vehicleCategory = vehicleCategoryObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(VehicleCategoryRepresentation.class));

        vehicleCategory.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPE).set(CatalogRels.TEST_VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.TEST_VEHICLE_TYPES).templated());
        });

        return vehicleCategory;
    }

}
