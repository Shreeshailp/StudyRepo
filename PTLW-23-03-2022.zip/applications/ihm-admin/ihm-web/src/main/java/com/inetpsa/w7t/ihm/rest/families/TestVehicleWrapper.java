/*
 * Creation : 31 Jul 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.List;

public class TestVehicleWrapper {

    /** The test vehicles. */
    private List<TestVehicleRepresentation> allTestVehicles;

    public List<TestVehicleRepresentation> getAllTestVehicles() {
        return allTestVehicles;
    }

    public void setAllTestVehicles(List<TestVehicleRepresentation> allTestVehicles) {
        this.allTestVehicles = allTestVehicles;
    }

}
