/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFilter;
import com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFinder;
import com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityRepresentation;

/**
 * The Class MaturityJpaFinder.
 */
public class MaturityJpaFinder implements MaturityFinder {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The Constant PATTERN. */
    private static final String PATTERN = "pattern";

    /** The Constant FAMILY. */
    private static final String FAMILY = "family";

    /** The Constant BODY. */
    private static final String BODY = "body";

    /** The Constant MOTOR. */
    private static final String MOTOR = "motor";

    /** The Constant GEARBOX. */
    private static final String GEARBOX = "gearbox";

    /** The Constant INDEX. */
    private static final String INDEX = "index";

    /** The Constant STATUS. */
    private static final String STATUS = "status";

    /** The Constant FETCH_LIMIT. */
    private static final int FETCH_LIMIT = 501;

    /** The Constant SIX. */
    private static final int SIX = 6;

    /** The Constant SEVEN. */
    private static final int SEVEN = 7;

    /** The Constant TEN. */
    private static final int TEN = 10;

    /** The Constant ZERO. */
    private static final int ZERO = 0;

    /** The Constant SIXTEEN. */
    private static final int SIXTEEN = 16;

    /** The Constant FOURTEEN. */
    private static final int FOURTEEN = 14;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFinder#all()
     */
    @SuppressWarnings("unchecked")
    @Override
    public CollectionRepresentation all() {
        String sqlQuery = "SELECT * FROM W7TQTPAT order by PATTERN";
        Query query = entityManager.createNativeQuery(sqlQuery, Maturity.class);
        query.setMaxResults(FETCH_LIMIT);

        List<Maturity> list = query.getResultList();

        List<MaturityRepresentation> maturityList = fluentAssembler.assemble(list).with(WltpModelMapper.class).to(MaturityRepresentation.class);

        CollectionRepresentation maturities = new CollectionRepresentation(maturityList.size(), false);
        maturities.self(relRegistry.uri(CatalogRels.MATURITYIMPORT));
        maturities.embedded(CatalogRels.MATURITYIMPORT, maturityList);

        return maturities;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFinder#filter(com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFilter)
     */
    @Override
    public CollectionRepresentation filter(MaturityFilter filter) {
        if (filter.pattern != null && filter.pattern.length() == SIXTEEN && !filter.pattern.contains("*")) {
            String patterneToBefiltered = filter.pattern;
            filter.pattern = patterneToBefiltered.substring(ZERO, SIX) + "*" + patterneToBefiltered.substring(SEVEN, TEN) + "****"
                    + patterneToBefiltered.substring(FOURTEEN, SIXTEEN);
        }
        TypedQuery<Maturity> query = getMaturityFilters(filter);

        List<MaturityRepresentation> maturityList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(MaturityRepresentation.class);

        if (!maturityList.isEmpty()) {
            logger.info("Found total maturity records in database is : [{}] ", maturityList.size());
        }

        CollectionRepresentation maturities = new CollectionRepresentation(maturityList.size(), false);
        maturities.self(relRegistry.uri(CatalogRels.MATURITYSEARCH));
        maturities.embedded(CatalogRels.MATURITYSEARCH, maturityList);
        return maturities;
    }

    /**
     * Gets the maturity filters.
     *
     * @param filter the filter
     * @return the maturity filters
     */
    private TypedQuery<Maturity> getMaturityFilters(MaturityFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Maturity> criteriaQuery = cb.createQuery(Maturity.class);
        Root<Maturity> root = criteriaQuery.from(Maturity.class);

        Optional<String> pattern = Optional.ofNullable(filter.pattern).filter(s -> !s.isEmpty());
        Optional<String> family = Optional.ofNullable(filter.family).filter(s -> !s.isEmpty());
        Optional<String> body = Optional.ofNullable(filter.body).filter(s -> !s.isEmpty());
        Optional<String> motor = Optional.ofNullable(filter.motor).filter(s -> !s.isEmpty());
        Optional<String> gearbox = Optional.ofNullable(filter.gearbox).filter(s -> !s.isEmpty());
        Optional<String> index = Optional.ofNullable(filter.index).filter(s -> !s.isEmpty());
        Optional<String> status = Optional.ofNullable(filter.status).filter(s -> !s.isEmpty());

        List<Predicate> filters = new ArrayList<>();
        pattern.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(PATTERN)), cb.parameter(String.class, PATTERN))));
        family.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(FAMILY)), cb.parameter(String.class, FAMILY))));
        body.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(BODY)), cb.parameter(String.class, BODY))));
        motor.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(MOTOR)), cb.parameter(String.class, MOTOR))));
        gearbox.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(GEARBOX)), cb.parameter(String.class, GEARBOX))));
        index.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(INDEX)), cb.parameter(String.class, INDEX))));
        status.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(STATUS)), cb.parameter(String.class, STATUS))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Maturity> query = entityManager.createQuery(criteriaQuery);
        pattern.ifPresent(c -> query.setParameter(PATTERN, '%' + c.toLowerCase() + '%'));
        family.ifPresent(c -> query.setParameter(FAMILY, '%' + c.toLowerCase() + '%'));
        body.ifPresent(c -> query.setParameter(BODY, '%' + c.toLowerCase() + '%'));
        motor.ifPresent(c -> query.setParameter(MOTOR, '%' + c.toLowerCase() + '%'));
        gearbox.ifPresent(c -> query.setParameter(GEARBOX, '%' + c.toLowerCase() + '%'));
        index.ifPresent(c -> query.setParameter(INDEX, '%' + c.toLowerCase() + '%'));
        status.ifPresent(c -> query.setParameter(STATUS, '%' + c.toLowerCase() + '%'));
        return query;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFinder#filterMaturity(com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFilter)
     */
    @Override
    public List<Maturity> filterMaturity(MaturityFilter filter) {
        if (filter.pattern != null && filter.pattern.length() == SIXTEEN && !filter.pattern.contains("*")) {
            String patterneToBefiltered = filter.pattern;
            filter.pattern = patterneToBefiltered.substring(ZERO, SIX) + "*" + patterneToBefiltered.substring(SEVEN, TEN) + "****"
                    + patterneToBefiltered.substring(FOURTEEN, SIXTEEN);
        }
        TypedQuery<Maturity> query = getMaturityFilters(filter);
        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.MaturityFinder#allMaturities()
     */
    @Override
    public List<Maturity> allMaturities() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Maturity> criteriaQuery = criteriaBuilder.createQuery(Maturity.class);
        Root<Maturity> root = criteriaQuery.from(Maturity.class);
        criteriaQuery.select(root);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(FAMILY)), criteriaBuilder.asc(root.get(BODY)), criteriaBuilder.asc(root.get(MOTOR)),
                criteriaBuilder.asc(root.get(GEARBOX)), criteriaBuilder.asc(root.get(INDEX)));

        TypedQuery<Maturity> query = entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }

}
