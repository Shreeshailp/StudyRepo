/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.depol.exceptions.DepolException;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface DepolService.
 */
@Service
public interface DepolService {

    /**
     * Upload.
     *
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @param fileName the file name
     * @return the collection representation
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws DepolException the depol exception
     */
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate, String fileName) throws IOException, DepolException;
}
