/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.families.model.details.MeasureValue;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;

/**
 * The Class MeasureValueRepresentation. This representation is used to represent the {@link MeasureValue} of a specific {@link TestVehicle}.
 */
public class MeasureValueRepresentation extends HalRepresentation {

    /** The measure type. */
    private String type;

    /** The cycle phase. */
    private String phase;

    /** The value. */
    private Double value;

    /**
     * Gets the measure type.
     *
     * @return the measure type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the measure type.
     *
     * @param type the new measure type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the cycle phase.
     *
     * @return the cycle phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the cycle phase.
     *
     * @param phase the new cycle phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Double getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Double value) {
        this.value = value;
    }
}
