/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.FamilyTabCheckService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlagDto;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.references.model.VehicleType;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;
import com.inetpsa.w7t.domains.references.validation.VehicleTypeCode;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyCheckStatusDto;
import com.inetpsa.w7t.ihm.rest.families.TestVehicleWrapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * The Class ReferencesResource. This resource is used to query every references present in the domains.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path("references")
@Api
public class ReferencesResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /** The country finder. */
    @Inject
    private CountryFinder countryFinder;

    /** The measure type finder. */
    @Inject
    private MeasureTypeFinder measureTypeFinder;

    /** The physical quantity type finder. */
    @Inject
    private PhysicalQuantityTypeFinder physicalQuantityTypeFinder;

    /** The cycle phase finder. */
    @Inject
    private CyclePhaseFinder cyclePhaseFinder;

    /** The test vehicle type finder. */
    @Inject
    private TestVehicleTypeFinder testVehicleTypeFinder;

    /** The vehicle type finder. */
    @Inject
    private VehicleTypeFinder vehicleTypeFinder;

    /** The family tab check service. */
    @Inject
    private FamilyTabCheckService familyTabCheckService;

    /** The Constant PATH_PARAM_T8C. */
    private static final String T8C = "t8C";

    /** The Constant PATH_PARAM_T8D. */
    private static final String T8D = "t8D";

    /** The family tab check flag finder. */
    @Inject
    private FamilyTabCheckFlagFinder familyTabCheckFlagFinder;

    /** The User service. */
    @Inject
    UserService userService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /**
     * Get a list of available references endpoints.
     *
     * @return the available references endpoints
     */
    @Rel(value = CatalogRels.REFERENCES, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response references() {

        HalRepresentation references = new HalRepresentation();

        references.link(CatalogRels.COUNTRIES, relRegistry.uri(CatalogRels.COUNTRIES));
        references.link(CatalogRels.COUNTRY, relRegistry.uri(CatalogRels.COUNTRY).templated());
        references.link(CatalogRels.CYCLE_PHASES, relRegistry.uri(CatalogRels.CYCLE_PHASES));
        references.link(CatalogRels.CYCLE_PHASE, relRegistry.uri(CatalogRels.CYCLE_PHASE).templated());
        references.link(CatalogRels.MEASURE_TYPES, relRegistry.uri(CatalogRels.MEASURE_TYPES));
        references.link(CatalogRels.MEASURE_TYPE, relRegistry.uri(CatalogRels.MEASURE_TYPE).templated());
        references.link(CatalogRels.PHYSICAL_QUANTITIES, relRegistry.uri(CatalogRels.PHYSICAL_QUANTITIES));
        references.link(CatalogRels.PHYSICAL_QUANTITY, relRegistry.uri(CatalogRels.PHYSICAL_QUANTITY).templated());
        /*
         * references.link(CatalogRels.VEHICLE_CATEGORIES, relRegistry.uri(CatalogRels.VEHICLE_CATEGORIES));
         * references.link(CatalogRels.VEHICLE_CATEGORY, relRegistry.uri(CatalogRels.VEHICLE_CATEGORY).templated());
         */
        references.link(CatalogRels.VEHICLE_TYPES, relRegistry.uri(CatalogRels.VEHICLE_TYPES));
        references.link(CatalogRels.VEHICLE_TYPE, relRegistry.uri(CatalogRels.VEHICLE_TYPE).templated());

        references.link(CatalogRels.FAMILYTABCHECKFLAG, relRegistry.uri(CatalogRels.FAMILYTABCHECKFLAG).templated());
        references.link(CatalogRels.FAMILYTABCHECKFLAGES, relRegistry.uri(CatalogRels.FAMILYTABCHECKFLAGES).templated());
        references.link(CatalogRels.FAMILYTABCHECKSTATUS, relRegistry.uri(CatalogRels.FAMILYTABCHECKSTATUS).templated());
        return Response.ok(references).build();
    }

    /**
     * Get the {@link CollectionRepresentation}, which is a list of {@link CountryRepresentation}.
     *
     * @return the list of countries
     */
    @Rel(value = CatalogRels.COUNTRIES, home = true)
    @GET
    @Path(CatalogRels.COUNTRIES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response countries(/* TODO Add query filter */) {
        return Response.ok(countryFinder.all()).build();
    }

    /**
     * Get a specific {@link CountryRepresentation}, defined by a {@code countryIdentifier}, which is either the code of the country in 2 characters
     * as defined in the <a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2">ISO 3166-1 alpha-2 standard</a>; or the UUID of the corresponding
     * {@link Country} entity id.
     *
     * @param countryIdentifier the country identifier
     * @return the specific country
     */
    @Rel(value = CatalogRels.COUNTRY)
    @GET
    @Path(CatalogRels.COUNTRIES + "/{" + CatalogRels.COUNTRY + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response country(@PathParam(CatalogRels.COUNTRY) String countryIdentifier) {
        Optional<CountryRepresentation> country = countryFinder.get(countryIdentifier);

        if (country.isPresent())
            return Response.ok(country.get()).build();
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     * Get the {@link CollectionRepresentation}, which is a list of {@link CyclePhaseRepresentation}.
     *
     * @return the list of cycle phases
     */
    @Rel(value = CatalogRels.CYCLE_PHASES, home = true)
    @GET
    @Path(CatalogRels.CYCLE_PHASES)

    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response cyclePhases(/* TODO Add query filter */) {
        return Response.ok(cyclePhaseFinder.all()).build();
    }

    /**
     * Get a specific {@link CyclePhaseRepresentation}, identified by {@code cyclePhaseIdentifier}, which is either the UUID of the corresponding
     * {@link CyclePhase} entity id, or the {@code code} validated by {@link CyclePhaseCode}.
     *
     * @param cyclePhaseIdentifier the cycle phase identifier
     * @return the specific cycle phase
     */
    @Rel(value = CatalogRels.CYCLE_PHASE)
    @GET
    @Path(CatalogRels.CYCLE_PHASES + "/{" + CatalogRels.CYCLE_PHASE + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response cyclePhase(@PathParam(CatalogRels.CYCLE_PHASE) String cyclePhaseIdentifier) {
        Optional<CyclePhaseRepresentation> cyclePhase = cyclePhaseFinder.get(cyclePhaseIdentifier);

        if (cyclePhase.isPresent())
            return Response.ok(cyclePhase.get()).build();
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     * TODO Create the list representation for measure type <br>
     * Get the {@link CollectionRepresentation}, which is a list of {@link MeasureTypeRepresentation}.
     *
     * @return the list of measure types
     */
    @Rel(value = CatalogRels.MEASURE_TYPES, home = true)
    @GET
    @Path(CatalogRels.MEASURE_TYPES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response measureTypes(/* TODO Add query filter */) {
        return Response.ok(measureTypeFinder.all()).build();
    }

    /**
     * Get a specific {@link MeasureTypeRepresentation}, identified by {@code measureTypeIdentifier}, which is either the UUID of the corresponding
     * {@link MeasureType} entity id, or the {@code code} validated by {@link MeasureTypeCode}.
     *
     * @param measureTypeIdentifier the measure type identifier
     * @return the specific measure type
     */
    @Rel(value = CatalogRels.MEASURE_TYPE, home = true)
    @GET
    @Path(CatalogRels.MEASURE_TYPES + "/{" + CatalogRels.MEASURE_TYPE + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response measureType(@PathParam(CatalogRels.MEASURE_TYPE) String measureTypeIdentifier) {
        Optional<MeasureTypeRepresentation> measureType = measureTypeFinder.get(measureTypeIdentifier);

        if (measureType.isPresent())
            return Response.ok(measureType.get()).build();
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     * TODO Create the correct list representation <br>
     * Get the physical quantities representation, which is a list of {@link PhysicalQuantityTypeRepresentation}.
     *
     * @return the list of physical quantity types
     */
    @Rel(value = CatalogRels.PHYSICAL_QUANTITIES, home = true)
    @GET
    @Path(CatalogRels.PHYSICAL_QUANTITIES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response physicalQuantities() {
        return Response.ok(physicalQuantityTypeFinder.all()).build();
    }

    /**
     * Get a specific {@link PhysicalQuantityTypeRepresentation}, identified by {@code physicalQuantityIdentifier}, which is the UUID of the
     * corresponding {@link PhysicalQuantityType} entity id.
     * 
     * @param physicalQuantityIdentifier the physical quantity identifier
     * @return the specific physical quantity type
     */
    @Rel(value = CatalogRels.PHYSICAL_QUANTITY, home = true)
    @GET
    @Path(CatalogRels.PHYSICAL_QUANTITIES + "/{" + CatalogRels.PHYSICAL_QUANTITY + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response physicalQuantity(@PathParam(CatalogRels.PHYSICAL_QUANTITY) String physicalQuantityIdentifier) {
        return Response.status(Response.Status.NOT_IMPLEMENTED).build();
    }

    /**
     * Get the {@link CollectionRepresentation}, which is a list of {@link TestVehicleTypeRepresentation}.
     *
     * @return the list of test vehicle types
     */
    @Rel(value = CatalogRels.TEST_VEHICLE_TYPES, home = true)
    @GET
    @Path(CatalogRels.TEST_VEHICLE_TYPES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response testVehicletypes() {
        return Response.ok(testVehicleTypeFinder.all()).build();
    }

    /**
     * Get a specific {@link TestVehicleTypeRepresentation}, identified by {@code testVehicletypeIdentifier}, which is the UUID of the corresponding
     * {@link TestVehicleType} entity id.
     *
     * @param testVehicletypeIdentifier the test vehicle type identifier
     * @return the specific test vehicle type
     */
    @Rel(value = CatalogRels.TEST_VEHICLE_TYPE, home = true)
    @GET
    @Path(CatalogRels.TEST_VEHICLE_TYPES + "/{" + CatalogRels.TEST_VEHICLE_TYPE + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response testVehicletype(@PathParam(CatalogRels.TEST_VEHICLE_TYPE) String testVehicletypeIdentifier) {
        Optional<TestVehicleTypeRepresentation> testVehicleType = testVehicleTypeFinder.byId(testVehicletypeIdentifier);

        if (testVehicleType.isPresent())
            return Response.ok(testVehicleType.get()).build();
        return Response.status(Response.Status.NOT_FOUND).build();

    }

    /**
     * Get the {@link CollectionRepresentation}, which is a list of {@link VehicleCategoryRepresentation} filtered by code.
     *
     * @param vehicleTypeIdentifier the vehicle type identifier
     * @return the list of vehicle categories
     */
    /*
     * @Rel(value = CatalogRels.VEHICLE_CATEGORIES, home = true)
     * 
     * @GET
     * 
     * @Path(CatalogRels.VEHICLE_CATEGORIES)
     * 
     * @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" }) public Response vehicleCategories(@QueryParam("filter") String filter) {
     * return Response.ok().entity(vehicleCategoryFinder.all(filter)).build(); }
     */
    /**
     * Get a specific {@link VehicleCategoryRepresentation}, identified by {@code vehicleCategoryIdentifier}, which is either the UUID of the
     * corresponding {@link VehicleCategory} entity id, or the {@code code} validated by {@link VehicleCategoryCode}.
     *
     * @param vehicleCategoryIdentifier the vehicle category identifier
     * @return the specific vehicle category
     */
    /*
     * @Rel(value = CatalogRels.VEHICLE_CATEGORY, home = true)
     * 
     * @GET
     * 
     * @Path(CatalogRels.VEHICLE_CATEGORIES + "/{" + CatalogRels.VEHICLE_CATEGORY + "}")
     * 
     * @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" }) public Response vehicleCategory(@PathParam(CatalogRels.VEHICLE_CATEGORY)
     * String vehicleCategoryIdentifier) { Optional<VehicleCategoryRepresentation> vehicleCategory =
     * vehicleCategoryFinder.get(vehicleCategoryIdentifier);
     * 
     * if (vehicleCategory.isPresent()) return Response.ok(vehicleCategory.get()).build(); return Response.status(Response.Status.NOT_FOUND).build();
     * }
     */

    /**
     * Save a vehicle category providing the same format than the {@link VehicleCategoryRepresentation}.
     *
     * @param vehicleCategoryRepresentation the vehicle category representation
     * @param uriInfo                       the uri info
     * @return the saved vehicle category
     */
    /*
     * @POST
     * 
     * @Path(CatalogRels.VEHICLE_CATEGORIES)
     * 
     * @Consumes(MediaType.APPLICATION_JSON)
     * 
     * @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" }) public Response saveVehicleCategory(VehicleCategoryRepresentation
     * vehicleCategoryRepresentation, @Context UriInfo uriInfo) {
     * 
     * // TODO Clean this method to use generic assemblers
     * 
     * Response result;
     * 
     * // check whether the entity already exists boolean alreadyExists = vehicleCategoryRepository.exists(vehicleCategoryRepresentation.getCode());
     * 
     * if (alreadyExists) { vehicleCategoryRepository.byCode(vehicleCategoryRepresentation.getCode()).ifPresent(cat -> {
     * categoryAssembler.mergeAggregateWithDto(cat, vehicleCategoryRepresentation); genericCategoryRepo.save(cat);
     * categoryAssembler.assembleDtoFromAggregate(vehicleCategoryRepresentation, cat); }); } else { VehicleCategory entity = categoryFactory.create();
     * categoryAssembler.mergeAggregateWithDto(entity, vehicleCategoryRepresentation); genericCategoryRepo.persist(entity);
     * categoryAssembler.assembleDtoFromAggregate(vehicleCategoryRepresentation, entity); }
     * 
     * // load the category referenced in received json VehicleCategory cat = genericCategoryRepo.load(vehicleCategoryRepresentation.getGuid());
     * HalRepresentation halCat = HalBuilder.create(categoryAssembler.assembleDtoFromAggregate(cat))
     * .self(relRegistry.uri(CatalogRels.VEHICLE_CATEGORY).set("category", cat.getGuid())) .link("find",
     * relRegistry.uri(CatalogRels.VEHICLE_CATEGORIES).templated());
     * 
     * if (!alreadyExists) { result = Response .created(relRegistry.uri(CatalogRels.VEHICLE_CATEGORY).set("category",
     * vehicleCategoryRepresentation.getGuid()).getProfile()) .entity(halCat).build(); } else { result = Response.ok().entity(halCat).build(); }
     * return result; }
     * 
     */ /**
         * Get a specific {@link VehicleTypeRepresentation}, identified by {@code vehicleTypeIdentifier}, which is either the UUID of the
         * corresponding {@link VehicleType} entity id, or the {@code code} validated by {@link VehicleTypeCode}.
         *
         * @param vehicleTypeIdentifier the vehicle type identifier
         * @return the specific vehicle type
         */
    @Rel(value = CatalogRels.VEHICLE_TYPE)
    @GET
    @Path(CatalogRels.VEHICLE_TYPES + "/{" + CatalogRels.VEHICLE_TYPE + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response vehicleType(@PathParam(CatalogRels.VEHICLE_TYPE) String vehicleTypeIdentifier) {
        Optional<VehicleTypeRepresentation> vehicleType = vehicleTypeFinder.get(vehicleTypeIdentifier);

        if (vehicleType.isPresent())
            return Response.ok(vehicleType.get()).build();
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     * Get a list of {@link VehicleTypeRepresentation}.
     *
     * @return the list of vehicle types
     */
    @Rel(value = CatalogRels.VEHICLE_TYPES, home = true)
    @GET
    @Path(CatalogRels.VEHICLE_TYPES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response vehicleTypes() {
        return Response.ok(vehicleTypeFinder.all()).build();
    }

    /**
     * Family tab check flag.
     *
     * @param familyTabCheckFlag the family tab check flag
     * @return the response
     */
    @Rel(value = CatalogRels.FAMILYTABCHECKFLAG, home = true)
    @POST
    @Path(CatalogRels.FAMILYTABCHECKFLAG)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response familyTabCheckFlag(FamilyTabCheckFlagDto familyTabCheckFlag) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new FamilyValidationException(FamilyErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            familyTabCheckService.insertFamilyTabCheck(familyTabCheckFlag);
            return Response.ok(null).build();
        } catch (FamilyValidationException e) {
            logger.error(e.getMessage(), e);
            throw e;
        } catch (RuntimeException e) {
            FamilyValidationException fve = new FamilyValidationException(FamilyErrorCode.UNKNOWN_EXCEPTION, null);
            fve.initCause(e);
            logger.error(e.getMessage(), e);
            throw fve;
        }
    }

    /**
     * Family tab check status.
     *
     * @param familyDto the family dto
     * @return the response
     */
    @Rel(value = CatalogRels.FAMILYTABCHECKSTATUS, home = true)
    @POST
    @Path(CatalogRels.FAMILYTABCHECKSTATUS)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response familyTabCheckStatus(@BeanParam FamilyCheckStatusDto familyDto) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new FamilyValidationException(FamilyErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            familyTabCheckService.insertfamilyTabCheckStatus(familyDto);
            return Response.ok(null).build();
        } catch (FamilyValidationException e) {
            logger.error(e.getMessage(), e);
            throw e;
        } catch (RuntimeException e) {
            FamilyValidationException fve = new FamilyValidationException(FamilyErrorCode.UNKNOWN_EXCEPTION, null);
            fve.initCause(e);
            logger.error(e.getMessage(), e);
            throw fve;
        }
    }

    /**
     * Family tab check flags.
     *
     * @param t8C the t 8 C
     * @param t8D the t 8 D
     * @return the response
     */
    @Rel(value = CatalogRels.FAMILYTABCHECKFLAGES, home = true)
    @GET
    @Path(CatalogRels.FAMILYTABCHECKFLAGES + "/{" + T8C + "}/{" + T8D + "}")
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response familyTabCheckFlags(@PathParam(T8C) String t8C, @PathParam(T8D) String t8D) {
        return Response.ok(familyTabCheckFlagFinder.all(t8C, t8D)).build();
    }

    /**
     * Gets the alltest vehicles.
     *
     * @return the alltest vehicles
     */
    @Rel(value = CatalogRels.TEST_VEHICLES, home = true)
    @GET
    @Path(CatalogRels.TEST_VEHICLES)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getAlltestVehicles() {
        TestVehicleWrapper testVehicleWrapper = new TestVehicleWrapper();
        testVehicleWrapper.setAllTestVehicles(testVehicleTypeFinder.getAllTestVehicles());
        return Response.ok(testVehicleWrapper).build();
    }

}
