/*
 * Creation : 11 Sep 2019
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.user.model.User;
import com.inetpsa.w7t.ihm.rest.maturityrequest.UserFinder;

/**
 * The Class UserJpaFinder.
 */
public class UserJpaFinder implements UserFinder {

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.UserFinder#updateStatus(java.lang.Boolean, java.lang.String)
     */
    @Override
    public void updateStatus(Boolean status, String client) {
        Query query = entityManager.createNativeQuery("UPDATE W7TQTIMS SET STATUS =? WHERE CLIENT=?", User.class);
        query.setParameter(1, status);
        query.setParameter(2, client);
        query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.maturityrequest.UserFinder#getUser(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public User getUser(String client) {
        User user = null;
        Query query = entityManager.createNativeQuery("SELECT * FROM W7TQTIMS WHERE CLIENT=?", User.class);
        query.setParameter(1, client);
        List<User> list = query.getResultList();
        if (list != null && !list.isEmpty()) {
            user = list.get(0);
        }
        return user;
    }
}
