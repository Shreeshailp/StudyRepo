/*
 * Creation : 12 Feb 2020
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.change.history.resource.ChangeHistoryFilter;

@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface ChangeHistoryFinder {

    CollectionRepresentation all();

    CollectionRepresentation filter(ChangeHistoryFilter filter);

}
