/*
 * Creation : 29 Mar 2019
 */
package com.inetpsa.w7t.application.services.internal;

/**
 * The Class GeneratedCycleConstants.
 */
public final class GeneratedCycleConstants {

    /** The Constant DOWN_SCALE. */
    public static final String DOWN_SCALE = "_D";

    /** The Constant SPEED_LIMITING. */
    public static final String SPEED_LIMITING = "_V";

    /**
     * Instantiates a new generated cycle constants.
     */
    private GeneratedCycleConstants() {

    }
}
