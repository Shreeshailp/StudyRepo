/*
 * Creation : 10 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import javax.ws.rs.QueryParam;

import com.inetpsa.w7t.domains.families.model.family.Family;

/**
 * The Class FamilyFilter. The filter is used to filter a list of {@link Family}.
 */
public class FamilyFilter {

    /** The family code. */
    @QueryParam("code")
    public String code;

    /** The vehicle RoadLoad. */
    @QueryParam("roadLoad")
    public String roadLoad;

    /** The vehicle Pmax. */
    @QueryParam("pmax")
    public String pmax;

}
