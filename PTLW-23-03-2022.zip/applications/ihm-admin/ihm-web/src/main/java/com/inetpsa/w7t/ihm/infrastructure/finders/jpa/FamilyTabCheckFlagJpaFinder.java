/*
 * Creation : 26 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlag;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyTabCheckFlagRepresentation;
import com.inetpsa.w7t.ihm.rest.references.FamilyTabCheckFlagFinder;

/**
 * The Class FamilyTabCheckFlagJpaFinder.
 *
 * @author E562493
 */
public class FamilyTabCheckFlagJpaFinder implements FamilyTabCheckFlagFinder {

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.FamilyTabCheckFlagFinder#all(java.lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public CollectionRepresentation all(String t8C, String t8D) {
        String sqlQuery = "SELECT * FROM W7TQTCHK WHERE T8C = ? AND T8D = ?";
        Query query = entityManager.createNativeQuery(sqlQuery, FamilyTabCheckFlag.class);
        query.setParameter(1, t8C);
        query.setParameter(2, t8D);
        List<FamilyTabCheckFlag> list = query.getResultList();

        List<FamilyTabCheckFlagRepresentation> familyTabCheckFlagList = fluentAssembler.assemble(list).with(WltpModelMapper.class)
                .to(FamilyTabCheckFlagRepresentation.class);

        CollectionRepresentation familyTabCheckFlages = new CollectionRepresentation(familyTabCheckFlagList.size(), false);
        familyTabCheckFlages.self(relRegistry.uri(CatalogRels.FAMILYTABCHECKFLAGES));
        familyTabCheckFlages.embedded(CatalogRels.FAMILYTABCHECKFLAGES, familyTabCheckFlagList);

        return familyTabCheckFlages;
    }

}
