package com.inetpsa.w7t.application.constants;

/**
 * The Class FsFlagFilePrefixConstants.
 */
public final class FsFlagFilePrefixConstants {

    /** The Constant TVV_EXPORT. */
    public static final String TVV_EXPORT = "_tvv_export";

    /** The Constant TVV_IMPORT. */
    public static final String TVV_IMPORT = "_tvv_import";

    /** The Constant DEPOL_EXPORT. */
    public static final String DEPOL_EXPORT = "_depol_export";

    /** The Constant DEPOL_IMPORT. */
    public static final String DEPOL_IMPORT = "_depol_import";

    /** The Constant MATURITY_EXPORT. */
    public static final String MATURITY_EXPORT = "_maturity_export";

    /** The Constant MATURITY_IMPORT. */
    public static final String MATURITY_IMPORT = "_maturity_import";

    /** The Constant FILTER_MATURITY_EXPORT. */
    public static final String FILTER_MATURITY_EXPORT = "_filter_maturity_export";

    /** The Constant MATURITY_IMPORT. */
    public static final String FAMILY_IMPORT = "_family_import";

    /** The Constant GENERATED_CYCLES_IMPORT. */
    public static final String GENERATED_CYCLES_IMPORT = "_generated_cycles_import";

    /** The Constant CYCLES_IMPORT. */
    public static final String CYCLES_IMPORT = "_cycles_import";

    /**
     * Instantiates a new fs flag file prefix constants.
     */
    private FsFlagFilePrefixConstants() {
        // do nothing
    }

}
