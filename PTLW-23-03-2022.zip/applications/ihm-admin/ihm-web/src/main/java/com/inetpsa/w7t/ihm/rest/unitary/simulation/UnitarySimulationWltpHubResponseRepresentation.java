/*
 * Creation : 2 Sep 2021
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

import java.util.List;

import com.inetpsa.w7t.toyota.model.answer.WSAnswer;
import com.inetpsa.w7t.toyota.model.answer.WSPhase;
import com.inetpsa.w7t.toyota.model.answer.WSPhysicalResult;
import com.inetpsa.w7t.toyota.model.answer.WSWltpData;

/**
 * The Class UnitarySimulationWltpHubResponseRepresentation.
 */
public class UnitarySimulationWltpHubResponseRepresentation extends UnitarySimulationWltpHubRequestRepresentation {

    /** The answer. */
    private WSAnswer answer;

    /** The wltp data. */
    private WSWltpData wltpData;

    /** The phys result. */
    private List<WSPhysicalResult> physResult;

    /** The phase. */
    private List<WSPhase> phase;

    /**
     * Instantiates a new unitary simulation wltp hub response representation.
     */
    public UnitarySimulationWltpHubResponseRepresentation() {
// Nothing to do it here
    }

    /**
     * Gets the answer.
     *
     * @return the answer
     */
    public WSAnswer getAnswer() {
        return answer;
    }

    /**
     * Sets the answer.
     *
     * @param answer the new answer
     */
    public void setAnswer(WSAnswer answer) {
        this.answer = answer;
    }

    /**
     * Gets the wltp data.
     *
     * @return the wltp data
     */
    public WSWltpData getWltpData() {
        return wltpData;
    }

    /**
     * Sets the wltp data.
     *
     * @param wltpData the new wltp data
     */
    public void setWltpData(WSWltpData wltpData) {
        this.wltpData = wltpData;
    }

    /**
     * Gets the phys result.
     *
     * @return the phys result
     */
    public List<WSPhysicalResult> getPhysResult() {
        return physResult;
    }

    /**
     * Sets the phys result.
     *
     * @param physResult the new phys result
     */
    public void setPhysResult(List<WSPhysicalResult> physResult) {
        this.physResult = physResult;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public List<WSPhase> getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(List<WSPhase> phase) {
        this.phase = phase;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UnitarySimulationWltpHubResponseRepresentation [answer=" + answer + ", wltpData=" + wltpData + ", physResult=" + physResult
                + ", phase=" + phase + "]";
    }

}
