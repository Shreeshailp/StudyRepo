/*
 * Creation : 21 Feb 2020
 */
package com.inetpsa.w7t.application.services.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.application.services.FamilyTabCheckService;
import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryDto;
import com.inetpsa.w7t.domains.change.history.services.ChangeHistoryService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyTabCheckFlagRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlag;
import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlagDto;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.FamilyStatusRepository;
import com.inetpsa.w7t.ihm.rest.families.FamilyCheckStatusDto;

/**
 * The Class FamilyTabCheckServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class FamilyTabCheckServiceImpl implements FamilyTabCheckService {

    /** The Constant FAMILY. */
    private static final String FAMILY = "FAMILY";

    /** The Constant CHECKFLAG. */
    private static final String CHECKFLAG = "CHECKFLAG";

    /** The family tab check flag repository. */
    @Inject
    private FamilyTabCheckFlagRepository familyTabCheckFlagRepository;

    /** The family tab check flag factory. */
    @Inject
    private Factory<FamilyTabCheckFlag> familyTabCheckFlagFactory;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The family repo. */
    @Inject
    @Jpa
    private Repository<FamilyDetails, UUID> familyRepo;

    /** The family status repository. */
    @Inject
    private FamilyStatusRepository familyStatusRepository;

    /** The change history service. */
    @Inject
    ChangeHistoryService changeHistoryService;

    /** The User service. */
    @Inject
    UserService userService;

    /** The Constant T8C. */
    private static final String T8C = "T8C";

    /** The Constant T8D. */
    private static final String T8D = "T8D";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyTabCheckService#insertFamilyTabCheck(com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlagDto)
     */
    @Override
    public void insertFamilyTabCheck(FamilyTabCheckFlagDto dto) {
        FamilyTabCheckFlag familyTabCheckFlag = null;
        if (!familyTabCheckFlagRepository.exists(dto.getT8C(), dto.getT8D(), dto.getTabId())) {
            familyTabCheckFlag = familyTabCheckFlagFactory.create();
            List<ChangeHistoryDto> dtoList = saveToChangeHistory(familyTabCheckFlag, dto);
            changeHistoryService.saveListOfChangeHistoryEntities(dtoList);
            familyTabCheckFlagRepository.save(mapDtoToEntity(familyTabCheckFlag, dto));
        } else {
            Optional<FamilyTabCheckFlag> optFamily = familyTabCheckFlagRepository.byCodeAndIndexDetails(dto.getT8C(), dto.getT8D(), dto.getTabId());
            if (optFamily.isPresent()) {
                familyTabCheckFlag = optFamily.get();
                if (dto.getTabId().equalsIgnoreCase(familyTabCheckFlag.getTabId()) && dto.getCheckFlag() != familyTabCheckFlag.getCheckFlag()) {
                    List<ChangeHistoryDto> dtoList = saveToChangeHistory(familyTabCheckFlag, dto);
                    changeHistoryService.saveListOfChangeHistoryEntities(dtoList);
                }
                familyTabCheckFlagRepository.save(mapDtoToEntity(familyTabCheckFlag, dto));
            }
        }

    }

    /**
     * Save to change history.
     *
     * @param familyTabCheckFlag the family tab check flag
     * @param dto the dto
     * @return the list
     */
    private List<ChangeHistoryDto> saveToChangeHistory(FamilyTabCheckFlag familyTabCheckFlag, FamilyTabCheckFlagDto dto) {
        List<ChangeHistoryDto> dtoList = new ArrayList<>();
        ChangeHistoryDto changeHistoryDto = new ChangeHistoryDto();
        changeHistoryDto.setDataCategory(FAMILY);
        changeHistoryDto.setDataId(T8C + dto.getT8C() + "-" + T8D + dto.getT8D() + "-" + dto.getTabId() + "-" + CHECKFLAG);
        changeHistoryDto.setOldValue(String.valueOf(familyTabCheckFlag.getCheckFlag()));
        changeHistoryDto.setNewValue(String.valueOf(dto.getCheckFlag()));
        changeHistoryDto.setUser(userService.getUserId());
        dtoList.add(changeHistoryDto);
        return dtoList;
    }

    /**
     * Map dto to entity.
     *
     * @param familyTabCheckFlag the family tab check flag
     * @param dto the dto
     * @return the family tab check flag
     */
    private FamilyTabCheckFlag mapDtoToEntity(FamilyTabCheckFlag familyTabCheckFlag, FamilyTabCheckFlagDto dto) {

        Optional<FamilyDetails> optFamily = familyRepository.byCodeAndIndexDetails(dto.getT8C(), Integer.valueOf(dto.getT8D()));
        if (optFamily.isPresent()) {
            familyTabCheckFlag.setFamilyDetails(familyRepo.load(optFamily.get().getGuid()));
        }
        familyTabCheckFlag.setT8C(dto.getT8C());
        familyTabCheckFlag.setT8D(dto.getT8D());
        familyTabCheckFlag.setTabId(dto.getTabId());
        familyTabCheckFlag.setCheckFlag(dto.getCheckFlag());
        return familyTabCheckFlag;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyTabCheckService#insertfamilyTabCheckStatus(com.inetpsa.w7t.ihm.rest.families.FamilyCheckStatusDto)
     */
    @Override
    public void insertfamilyTabCheckStatus(FamilyCheckStatusDto dto) {
        FamilyDetails family = null;
        if (familyRepository.exists(dto.getCode(), dto.getIndex())) {
            Optional<FamilyDetails> optFamily = familyRepository.byCodeAndIndexDetails(dto.getCode(), dto.getIndex());
            if (optFamily.isPresent()) {
                family = optFamily.get();
                familyRepo.save(mapDtoToEntity(family, dto));
                saveToChangeHistory(dto);
            }
        }
    }

    /**
     * Save to change history.
     *
     * @param dto the dto
     */
    private void saveToChangeHistory(FamilyCheckStatusDto dto) {
        ChangeHistoryDto changeHistoryDto = new ChangeHistoryDto();
        changeHistoryDto.setDataCategory(FAMILY);
        changeHistoryDto.setDataId(T8C + dto.getCode() + "-" + T8D + dto.getIndex());
        changeHistoryDto.setUser(userService.getUserId());
        List<String> propertyNameList = changeHistoryService.getDeclaredFieldsOfAnObject(FamilyCheckStatusDto.class);
        List<String> parametersTobeRemoved = Arrays.asList("code", "index");
        propertyNameList.removeAll(parametersTobeRemoved);
        changeHistoryService.saveChangeHistoryEntity(changeHistoryDto, dto, propertyNameList);
    }

    /**
     * Map dto to entity.
     *
     * @param family the family
     * @param dto the dto
     * @return the family details
     */
    private FamilyDetails mapDtoToEntity(FamilyDetails family, FamilyCheckStatusDto dto) {
        if (dto.getBlocked() != null) {
            family.setBlocked(dto.getBlocked());
        }
        if (dto.getBlockingReason() != null && !dto.getBlockingReason().isEmpty()) {
            family.setBlockingReason(dto.getBlockingReason());
        }
        if (dto.getStatus() != null && !dto.getStatus().isEmpty() && familyStatusRepository.exists(dto.getStatus())) {
            family.setStatus(dto.getStatus());
        } 
        return family;
    }

}
