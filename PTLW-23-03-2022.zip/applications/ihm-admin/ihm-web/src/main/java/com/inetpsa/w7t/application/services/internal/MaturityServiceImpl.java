/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.MaturityParserService;
import com.inetpsa.w7t.application.services.MaturityService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityErrorCode;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityException;
import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.domains.maturity.model.MaturityDto;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityStatusRepository;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MaturityServiceImpl implements MaturityService {

    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    @Inject
    private Factory<Maturity> maturityFactory;

    @Inject
    UserService userService;

    @Inject
    private MaturityParserService maturityParserService;

    @Inject
    private MaturityRepository maturityRepository;

    @Inject
    MaturityStatusRepository maturityStatusRepository;

    @Override
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException, MaturityException {
        List<MaturityDto> maturityDtos = maturityParserService.parse(inputStream);
        boolean isMaturityExists = false;
        int maturityCount = 0;
        if (!forceUpdate) {
            for (MaturityDto maturityDto : maturityDtos) {
                isMaturityExists = checkMaturityExistence(maturityDto);
                if (isMaturityExists) {
                    maturityCount++;
                }

            }
            if (maturityCount > 0) {
                logger.info("There are total of {} maturity records found for modification ", maturityCount);
                String[] repeatMaturity = { String.valueOf(maturityCount) };
                throw new MaturityException(MaturityErrorCode.MATURITY_ALREADY_EXISTS, repeatMaturity);
            }
        }

        List<Maturity> maturityList = importMaturity(maturityDtos);

        CollectionRepresentation maturityCollection = new CollectionRepresentation(maturityList.size(), false);

        maturityCollection.self(relRegistry.uri(CatalogRels.MATURITYIMPORT).templated());
        maturityCollection.link("find", relRegistry.uri(CatalogRels.MATURITYIMPORT).templated());
        maturityCollection.embedded(CatalogRels.MATURITYIMPORT, maturityList);

        return maturityCollection;
    }

    private List<Maturity> importMaturity(List<MaturityDto> maturityDtos) {
        List<Maturity> maturityList = new ArrayList<>();
        for (MaturityDto maturityDto : maturityDtos) {
            Maturity maturity = new Maturity();
            if (!maturityRepository.exists(maturityDto.getFamily(), maturityDto.getBody(), maturityDto.getMotor(), maturityDto.getGearbox(),
                    maturityDto.getIndex())) {
                maturity = maturityFactory.create();
                maturity.setPattern(maturityDto.getFamily() + maturityDto.getBody() + "*" + maturityDto.getMotor() + maturityDto.getGearbox() + "****"
                        + maturityDto.getIndex());
                maturity = mergeAggregateWithDto(maturityDto, maturity);
                maturity.setCreatedBy(userService.getUserId());
                maturity.setCreatedOn(getTodayDateAsString());
                maturity.setStatusUpdatedBy(userService.getUserId());
                maturity.setStatusUpdatedOn(getTodayDateAsString());
                maturity = maturityRepository.save(maturity);
            } else {
                List<Maturity> list = maturityRepository.maturityByUniqueFields(maturityDto.getFamily(), maturityDto.getBody(),
                        maturityDto.getMotor(), maturityDto.getGearbox(), maturityDto.getIndex());
                Optional<Maturity> optMaturity = list.stream().findFirst();
                if (optMaturity.isPresent()) {
                    maturity = optMaturity.get();
                    if (!maturity.getStatus().equalsIgnoreCase(maturityDto.getStatus())) {
                        maturity.setStatusUpdatedBy(userService.getUserId());
                        maturity.setStatusUpdatedOn(getTodayDateAsString());
                    }
                    maturity = mergeAggregateWithDto(maturityDto, maturity);
                    maturity = maturityRepository.save(maturity);
                }
            }
            maturityList.add(maturity);
            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (maturity != null) {
                traceLog.append(" Import MATURITY ").append(maturity).toString();
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }

        return maturityList;
    }

    private Maturity mergeAggregateWithDto(MaturityDto maturityDto, Maturity maturity) {
        maturity.setFamily(maturityDto.getFamily());
        maturity.setBody(maturityDto.getBody());
        maturity.setMotor(maturityDto.getMotor());
        maturity.setGearbox(maturityDto.getGearbox());
        maturity.setIndex(maturityDto.getIndex());
        if (maturityDto.getStatus() != null) {
            checkValidMaturityStatusExists(maturityDto.getStatus());
            maturity.setStatus(maturityDto.getStatus());
        }

        return maturity;

    }

    private Boolean checkMaturityExistence(MaturityDto maturityDto) {
        return maturityRepository.exists(maturityDto.getFamily(), maturityDto.getBody(), maturityDto.getMotor(), maturityDto.getGearbox(),
                maturityDto.getIndex());

    }

    private boolean checkValidMaturityStatusExists(String status) {
        if (!maturityStatusRepository.exists(status)) {
            throw new MaturityException(MaturityErrorCode.INVALID_MATURITY_STATUS, null);
        }
        return true;
    }

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static String getTodayDateAsString() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }
}
