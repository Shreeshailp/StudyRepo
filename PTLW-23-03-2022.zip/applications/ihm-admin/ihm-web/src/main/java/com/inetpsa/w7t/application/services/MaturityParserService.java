/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.maturity.exceptions.MaturityException;
import com.inetpsa.w7t.domains.maturity.model.MaturityDto;

@Service
@FunctionalInterface
public interface MaturityParserService {
    List<MaturityDto> parse(InputStream inputStream) throws IOException, MaturityException;

}
