/*
 * Creation : 3 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.VehicleType;

/**
 * The Class VehicleTypeRepresentation. This representation is used to represent a specific {@link VehicleType}.
 */
@DtoOf(VehicleType.class)
public class VehicleTypeRepresentation extends ReferenceRepresentation {

    /** The measure types. */
    private List<String> measureTypes;

    /**
     * Gets the measure types.
     *
     * @return the measure types
     */
    public List<String> getMeasureTypes() {
        return measureTypes;
    }

    /**
     * Sets the measure types.
     *
     * @param measureTypes the new measure types
     */
    public void setMeasureTypes(List<String> measureTypes) {
        this.measureTypes = measureTypes;
    }
}
