/*
 * Creation : 21 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

/**
 * The Class CollectionRequestDto.
 */
public class CollectionRequestDto {

    /** The collection request id. */
    private String collectionRequestId;

    /** The request name. */
    private String requestName;

    /** The request. */
    private UnitarySimulationRequestRepresentation request;

    /**
     * Gets the collection request id.
     *
     * @return the collection request id
     */
    public String getCollectionRequestId() {
        return collectionRequestId;
    }

    /**
     * Sets the collection request id.
     *
     * @param collectionRequestId the new collection request id
     */
    public void setCollectionRequestId(String collectionRequestId) {
        this.collectionRequestId = collectionRequestId;
    }

    /**
     * Gets the request name.
     *
     * @return the request name
     */
    public String getRequestName() {
        return requestName;
    }

    /**
     * Sets the request name.
     *
     * @param requestName the new request name
     */
    public void setRequestName(String requestName) {
        this.requestName = requestName;
    }

    /**
     * Gets the request.
     *
     * @return the request
     */
    public UnitarySimulationRequestRepresentation getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(UnitarySimulationRequestRepresentation request) {
        this.request = request;
    }

}
