/*
 * Creation : 14 Jul 2021
 */
package com.inetpsa.w7t.application.utilities;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.inetpsa.w7t.domains.depol.model.DepolDto;

/**
 * The Class ImportStatusAnswerCollectionUtility.
 */
public class ImportStatusAnswerCollectionUtility {

    /** The import depol status map. */
    protected static Map<String, List<DepolDto>> importDepolStatusMap = new ConcurrentHashMap<>();

    /**
     * Getter importDepolStatusMap.
     *
     * @param fileName the file name
     * @return the importDepolStatusMap
     */
    public static List<DepolDto> getImportDepolStatusMap(String fileName) {
        return importDepolStatusMap.get(fileName);
    }

    /**
     * Setter importDepolStatusMap.
     *
     * @param fileName the file name
     * @param importDepolStatusList the import depol status list
     */
    public static void setImportDepolStatusMap(String fileName, List<DepolDto> importDepolStatusList) {
        ImportStatusAnswerCollectionUtility.importDepolStatusMap.put(fileName, importDepolStatusList);
    }

    /**
     * Instantiates a new import status answer collection utility.
     */
    private ImportStatusAnswerCollectionUtility() {
        // do nothing
    }
}
