/*
 * Creation : 26 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.references;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface FamilyTabCheckFlagFinder.
 *
 * @author E562493
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyTabCheckFlagFinder {

    /**
     * All.
     *
     * @param t8C the t 8 C
     * @param t8D the t 8 D
     * @return the collection representation
     */
    CollectionRepresentation all(String t8C, String t8D);

}
