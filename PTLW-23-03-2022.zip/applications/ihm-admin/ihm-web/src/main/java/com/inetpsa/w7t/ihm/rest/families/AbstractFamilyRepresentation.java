/*
 * Creation : 13 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;

/**
 * The Class AbstractFamilyRepresentation. This class represents the common parts between {@link Family} and {@link FamilyDetails}.
 */
public abstract class AbstractFamilyRepresentation extends HalRepresentation {

    /** The guid. */
    protected UUID guid;

    /** The family code. */
    protected String code;

    /** The label. */
    protected String label;

    /** The index. */
    protected Integer index;

    /** The vehicle type. */
    protected String type;

    /** The vehicle roadLoad. */
    protected String roadLoad;

    /** The vehicle Pmax. */
    protected String pmax;

    /** The status. */
    protected String status;

    /** The blocked. */
    protected Boolean blocked;

    /** The blocking reason. */
    protected String blockingReason;

    /** The created by. */
    protected String createdBy;

    /** The created on. */
    protected String createdOn;

    /** The family additional data. */
    protected FamilyAdditionalDataDto familyAdditionalData;

    /**
     * Getter guid.
     * 
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid.
     *
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter code.
     *
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Getter label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Setter label.
     *
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Getter index.
     *
     * @return the index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Setter index.
     *
     * @param index the index to set
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * Getter type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Setter type.
     *
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    public String getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the road load.
     *
     * @param roadLoad the new road load
     */
    public void setRoadLoad(String roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Gets the pmax.
     *
     * @return the pmax
     */
    public String getPmax() {
        return pmax;
    }

    /**
     * Sets the pmax.
     *
     * @param pmax the new pmax
     */
    public void setPmax(String pmax) {
        this.pmax = pmax;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the blocked.
     *
     * @return the blocked
     */
    public Boolean getBlocked() {
        return blocked;
    }

    /**
     * Sets the blocked.
     *
     * @param blocked the new blocked
     */
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    /**
     * Gets the blocking reason.
     *
     * @return the blocking reason
     */
    public String getBlockingReason() {
        return blockingReason;
    }

    /**
     * Sets the blocking reason.
     *
     * @param blockingReason the new blocking reason
     */
    public void setBlockingReason(String blockingReason) {
        this.blockingReason = blockingReason;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Getter createdOn.
     *
     * @return the createdOn
     */
    public String getCreatedOn() {
        return createdOn;
    }

    /**
     * Setter createdOn.
     *
     * @param createdOn the createdOn to set
     */
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * Gets the family additional data.
     *
     * @return the family additional data
     */
    public FamilyAdditionalDataDto getFamilyAdditionalData() {
        return familyAdditionalData;
    }

    /**
     * Sets the family additional data.
     *
     * @param familyAdditionalData the new family additional data
     */
    public void setFamilyAdditionalData(FamilyAdditionalDataDto familyAdditionalData) {
        this.familyAdditionalData = familyAdditionalData;
    }

}
