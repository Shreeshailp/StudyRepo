/*
 * Creation : 9 août 2017
 */
package com.inetpsa.w7t.toyota.interfaces.rest;

/**
 * The Class RequestRepresentation.
 */
public class RequestRepresentation {

    /** The request. */
    private WltpRequestRepresentation request;

    public RequestRepresentation() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Gets the request.
     *
     * @return the request
     */
    public WltpRequestRepresentation getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(WltpRequestRepresentation request) {
        this.request = request;
    }

    @Override
    public String toString() {
        return "RequestRepresentation [request=" + request + "]";
    }

}
