/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfile;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.cycles.CycleDetailsRepresentation;
import com.inetpsa.w7t.ihm.rest.cycles.CycleFilter;
import com.inetpsa.w7t.ihm.rest.cycles.CycleRepresentation;
import com.inetpsa.w7t.ihm.rest.cycles.CyclesFinder;
import com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder;

/**
 * The Class CyclesJpaFinder. This is the JPA Implementation of the {@link CyclesFinder}.
 * 
 * @see CyclesFinder
 */
public class CyclesJpaFinder implements CyclesFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant PHASE. */
    private static final String PHASE = "phase";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /** The cycle phase finder. */
    @Inject
    CyclePhaseFinder cyclePhaseFinder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.cycles.CyclesFinder#all(com.inetpsa.w7t.ihm.rest.cycles.CycleFilter)
     */
    @Override
    public CollectionRepresentation all(CycleFilter filter) {
        List<CycleRepresentation> cyclesList = getCycles(filter);
        return convertToCyclesRepresentation(cyclesList);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.cycles.CyclesFinder#byId(java.lang.String)
     */
    @Override
    public Optional<CycleDetailsRepresentation> byId(String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CycleDetails> q = cb.createQuery(CycleDetails.class);
        Root<CycleDetails> root = q.from(CycleDetails.class);
        q.where(cb.equal(root.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<CycleDetails> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        Optional<CycleDetailsRepresentation> cycle = query.getResultList().stream().findFirst()
                .map(cd -> fluentAssembler.assemble(cd).with(WltpModelMapper.class).to(CycleDetailsRepresentation.class));

        cycle.ifPresent(cd -> {
            cd.getProfiles().sort((p1, p2) -> Integer.compare(p1.getTime(), p2.getTime()));

            cd.self(relRegistry.uri(CatalogRels.CYCLE).set(CatalogRels.CYCLE, cd.getGuid()));
            cd.link("find", relRegistry.uri(CatalogRels.CYCLES).templated());
            cd.embedded(PHASE, cyclePhaseFinder.byCode(cd.getPhase()).get());
        });

        return cycle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.cycles.CyclesFinder#byGeneratedCycleId(java.lang.String)
     */
    @Override
    public CollectionRepresentation byGeneratedCycleId(String id) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> cq = cb.createQuery(GeneratedCycle.class);
        Root<GeneratedCycle> cRoot = cq.from(GeneratedCycle.class);

        cq.where(cb.equal(cRoot.get(GUID), UUID.fromString(id)));
        List<GeneratedCycle> resultList = entityManager.createQuery(cq).getResultList();

        List<GeneratedCycle> generatedCycleData = new ArrayList<>();
        List<GeneratedCycleProfile> cycleProfileList = new ArrayList<>();
        List<CycleDetails> cycleDetailsList = new ArrayList<>();

        if (!resultList.isEmpty()) {
            generatedCycleData.add(resultList.get(0));

            GeneratedCycle generatedCycleItem = resultList.get(0);
            List<GeneratedCycleProfile> profileList = generatedCycleItem.getGenCycleProfiles();

            for (int j = 0; j < profileList.size(); j++) {
                GeneratedCycleProfile profileItem = profileList.get(j);
                cycleProfileList.add(profileItem);
            }
            CriteriaBuilder cycleDetailsCriteriaBuilder = entityManager.getCriteriaBuilder();
            CriteriaQuery<CycleDetails> cycleDetailsQ = cycleDetailsCriteriaBuilder.createQuery(CycleDetails.class);
            Root<CycleDetails> cycleDetailsRoot = cycleDetailsQ.from(CycleDetails.class);
            cycleDetailsQ.select(cycleDetailsRoot).where(cycleDetailsCriteriaBuilder.equal(cycleDetailsRoot.get(GUID), UUID.fromString(id)));

            TypedQuery<CycleDetails> cycleDetailsQuery = entityManager.createQuery(cycleDetailsQ);
            cycleDetailsList = cycleDetailsQuery.getResultList();

        }

        CollectionRepresentation cycle = new CollectionRepresentation(generatedCycleData.size() + cycleProfileList.size() + cycleDetailsList.size(),
                false);

        cycle.self(relRegistry.uri(CatalogRels.CONSULT_GENERATED_CYCLE));
        cycle.embedded(CatalogRels.IMPORTGENERATEDCYCLES, generatedCycleData);
        cycle.embedded(CatalogRels.CONSULT_GENERATED_CYCLE, cycleProfileList);
        cycle.embedded(CatalogRels.CYCLE, cycleDetailsList);
        return cycle;
    }

    /**
     * Gets the cycles.
     *
     * @param filter the filter
     * @return the cycles
     */
    private List<CycleRepresentation> getCycles(CycleFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cycle> q = cb.createQuery(Cycle.class);
        Root<Cycle> root = q.from(Cycle.class);

        List<Predicate> filters = new ArrayList<>();
        if (filter.getCode() != null)
            filters.add(cb.like(cb.lower(root.get(CODE)), cb.parameter(String.class, CODE)));
        if (filter.getPhase() != null)
            filters.add(cb.like(cb.lower(root.get(PHASE)), cb.parameter(String.class, PHASE)));

        q.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Cycle> query = entityManager.createQuery(q);
        if (filter.getCode() != null)
            query.setParameter(CODE, '%' + filter.getCode().toLowerCase() + '%');
        if (filter.getPhase() != null)
            query.setParameter(PHASE, '%' + filter.getPhase().toLowerCase() + '%');

        List<Cycle> cycles = query.getResultList();
        return fluentAssembler.assemble(cycles).with(WltpModelMapper.class).to(CycleRepresentation.class);
    }

    /**
     * Convert List of cycle representation to cycles representation.
     *
     * @param cyclesList the cycles list
     * @return the cycles representation
     */
    private CollectionRepresentation convertToCyclesRepresentation(List<CycleRepresentation> cyclesList) {
        CollectionRepresentation cycles = new CollectionRepresentation(cyclesList.size(), false);

        cyclesList.stream().forEach(cycle -> {
            cycle.embedded(PHASE, cyclePhaseFinder.byCode(cycle.getPhase()).get());
            cycle.self(relRegistry.uri(CatalogRels.CYCLE).set(CatalogRels.CYCLE, cycle.getGuid()));
        });
        cycles.self(relRegistry.uri(CatalogRels.CYCLES).templated());
        cycles.link("find", relRegistry.uri(CatalogRels.CYCLE).templated());
        cycles.embedded(CatalogRels.CYCLES, cyclesList);
        return cycles;
    }
}
