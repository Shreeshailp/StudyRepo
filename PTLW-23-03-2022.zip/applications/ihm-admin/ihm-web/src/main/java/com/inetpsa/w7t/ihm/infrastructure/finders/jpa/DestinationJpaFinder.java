/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.enginesettings.model.Destination;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.engine.DestinationDetailsRepresentation;
import com.inetpsa.w7t.ihm.rest.engine.DestinationFilter;
import com.inetpsa.w7t.ihm.rest.engine.DestinationFinder;
import com.inetpsa.w7t.ihm.rest.engine.DestinationRepresentation;
import com.inetpsa.w7t.ihm.rest.references.CountryFinder;
import com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder;
import com.inetpsa.w7t.ihm.rest.references.MeasureTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder;

/**
 * The Class DestinationJpaFinder. This read only class provides representations for Destination and DestinationDetails.
 * 
 * @see DestinationDetails
 */
public class DestinationJpaFinder implements DestinationFinder {

    private static final String GUID = "guid";

    /** The Constant LABEL. */
    private static final String LABEL = "label";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    @Inject
    RelRegistry relRegistry;

    @Inject
    LabelService labelService;

    @Inject
    CountryFinder countryFinder;

    @Inject
    CyclePhaseFinder cyclePhaseFinder;

    @Inject
    MeasureTypeFinder measureTypeFinder;

    @Inject
    VehicleTypeFinder vehicleTypeFinder;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.engine.DestinationFinder#all(com.inetpsa.w7t.ihm.rest.engine.DestinationFilter)
     */
    @Override
    public CollectionRepresentation all(DestinationFilter filter) {
        List<DestinationRepresentation> destinationList = getDestinations(filter);
        CollectionRepresentation destinations = new CollectionRepresentation(destinationList.size(), false);

        destinations.self(relRegistry.uri(CatalogRels.DESTINATIONS).templated());
        destinations.link("find", relRegistry.uri(CatalogRels.DESTINATION).templated());
        destinations.embedded(CatalogRels.DESTINATIONS, destinationList);

        return destinations;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.engine.DestinationFinder#byId(java.lang.String)
     */
    @Override
    public Optional<DestinationDetailsRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DestinationDetails> q = cb.createQuery(DestinationDetails.class);
        Root<DestinationDetails> root = q.from(DestinationDetails.class);
        q.where(cb.equal(root.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<DestinationDetails> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        Optional<DestinationDetailsRepresentation> destination = query.getResultList().stream().findFirst()
                .map(details -> fluentAssembler.assemble(details).with(WltpModelMapper.class).to(DestinationDetailsRepresentation.class));

        destination.ifPresent(details -> {
            details.embedded(CatalogRels.COUNTRIES, details.getCountries().stream().map(countryFinder::byId).filter(Optional::isPresent)
                    .map(Optional::get).collect(Collectors.toList()));
            details.self(relRegistry.uri(CatalogRels.DESTINATION).set(CatalogRels.DESTINATION, details.getGuid()));
        });

        return destination;
    }

    /**
     * @param filter
     * @return
     */
    private List<DestinationRepresentation> getDestinations(DestinationFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Destination> q = cb.createQuery(Destination.class);
        Root<Destination> root = q.from(Destination.class);

        Optional<String> label = Optional.ofNullable(filter.label);

        label.ifPresent(l -> q.where(cb.like(cb.lower(root.get(LABEL)), cb.parameter(String.class, LABEL))));

        TypedQuery<Destination> query = entityManager.createQuery(q);
        label.ifPresent(l -> query.setParameter(LABEL, '%' + l.toLowerCase() + '%'));

        List<DestinationRepresentation> destinations = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(DestinationRepresentation.class);

        destinations.forEach(destination -> {
            destination.embedded(CatalogRels.COUNTRIES, destination.getCountries().stream().map(countryFinder::byId).filter(Optional::isPresent)
                    .map(Optional::get).collect(Collectors.toList()));
            destination.self(relRegistry.uri(CatalogRels.DESTINATION).set(CatalogRels.DESTINATION, destination.getGuid()));
        });

        return destinations;
    }
}
