/*
 * Creation : 11 Jul 2019
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.depol.DepolFilter;
import com.inetpsa.w7t.ihm.rest.depol.DepolFinder;
import com.inetpsa.w7t.ihm.rest.depol.DepolRepresentation;

/**
 * The Class DepolJpaFinder.
 */
public class DepolJpaFinder implements DepolFinder {

    /** The Constant DESIGNATION. */
    private static final String DESIGNATION = "designation";

    /** The Constant SPECIAL_FLAG. */
    private static final String SPECIAL_FLAG = "specialFlag";

    /** The Constant CODE_DEPOL. */
    private static final String CODE_DEPOL = "codeDepol";

    /** The Constant FETCH_LIMIT. */
    private static final int FETCH_LIMIT = 501;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.depol.DepolFinder#all()
     */
    @Override
    public CollectionRepresentation all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Depol> criteriaQuery = criteriaBuilder.createQuery(Depol.class);
        Root<Depol> root = criteriaQuery.from(Depol.class);
        criteriaQuery.select(root);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(CODE_DEPOL)), criteriaBuilder.asc(root.get(SPECIAL_FLAG)));

        TypedQuery<Depol> query = entityManager.createQuery(criteriaQuery);
        query.setMaxResults(FETCH_LIMIT);

        List<DepolRepresentation> depolList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(DepolRepresentation.class);

        CollectionRepresentation depols = new CollectionRepresentation(depolList.size(), false);
        depols.self(relRegistry.uri(CatalogRels.IMPORTDEPOL));
        depols.embedded(CatalogRels.IMPORTDEPOL, depolList);
        return depols;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.depol.DepolFinder#filter(com.inetpsa.w7t.ihm.rest.depol.DepolFilter)
     */
    @Override
    public CollectionRepresentation filter(DepolFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Depol> criteriaQuery = cb.createQuery(Depol.class);
        Root<Depol> root = criteriaQuery.from(Depol.class);

        Optional<String> codeDepol = Optional.ofNullable(filter.codeDepol).filter(s -> !s.isEmpty());
        Optional<String> specialFlag = Optional.ofNullable(filter.specialFlag).filter(s -> !s.isEmpty());
        Optional<String> designation = Optional.ofNullable(filter.designation).filter(s -> !s.isEmpty());

        List<Predicate> filters = new ArrayList<>();
        codeDepol.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(CODE_DEPOL)), cb.parameter(String.class, CODE_DEPOL))));
        specialFlag.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(SPECIAL_FLAG)), cb.parameter(String.class, SPECIAL_FLAG))));
        designation.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(DESIGNATION)), cb.parameter(String.class, DESIGNATION))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Depol> query = entityManager.createQuery(criteriaQuery);
        codeDepol.ifPresent(c -> query.setParameter(CODE_DEPOL, '%' + c.toLowerCase() + '%'));
        specialFlag.ifPresent(c -> query.setParameter(SPECIAL_FLAG, '%' + c.toLowerCase() + '%'));
        designation.ifPresent(c -> query.setParameter(DESIGNATION, '%' + c.toLowerCase() + '%'));

        List<DepolRepresentation> depolList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(DepolRepresentation.class);

        if (!depolList.isEmpty()) {
            logger.info("Found total depol records in database is : [{}] ", depolList.size());
        }

        CollectionRepresentation depols = new CollectionRepresentation(depolList.size(), false);
        depols.self(relRegistry.uri(CatalogRels.DEPOLSEARCH));
        depols.embedded(CatalogRels.DEPOLSEARCH, depolList);
        return depols;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.depol.DepolFinder#allDepols()
     */
    @Override
    public List<Depol> allDepols() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Depol> criteriaQuery = criteriaBuilder.createQuery(Depol.class);
        Root<Depol> root = criteriaQuery.from(Depol.class);
        criteriaQuery.select(root);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(CODE_DEPOL)), criteriaBuilder.asc(root.get(SPECIAL_FLAG)));

        TypedQuery<Depol> query = entityManager.createQuery(criteriaQuery);

        return query.getResultList();
    }

}
