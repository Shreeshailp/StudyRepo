/*
 * Creation : 4 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.families.model.family.Family;

/**
 * The Class FamilyRepresentation. This representation is used to represent a {@link Family}.
 */
@DtoOf(Family.class)
public class FamilyRepresentation extends AbstractFamilyRepresentation {

}
