/*
 * Creation : 12 Feb 2020
 */
package com.inetpsa.w7t.ihm.rest.change.history.resource;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryEntity;

@DtoOf(ChangeHistoryEntity.class)
public class ChangeHistoryRepresentation extends AbstractChangeHistoryRepresentation {

}
