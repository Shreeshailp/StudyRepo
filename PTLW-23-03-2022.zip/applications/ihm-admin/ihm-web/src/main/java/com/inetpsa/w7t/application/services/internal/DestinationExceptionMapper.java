package com.inetpsa.w7t.application.services.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.domains.destination.exceptions.DestinationException;

@Provider
public class DestinationExceptionMapper implements ExceptionMapper<DestinationException> {
    @Override
    public Response toResponse(DestinationException exception) {
        Status status = Response.Status.BAD_REQUEST;
//        String ruleCode = ((DestinationErrorCode) exception.getErrorCode()).getRuleCode();
//        if ("RG37".equals(ruleCode)) {
//            status = Response.Status.PRECONDITION_FAILED;
//        } else if ("RG38".equals(ruleCode)) {
//            status = Response.Status.PRECONDITION_FAILED;
//        } else if ("RG39".equals(ruleCode)) {
//            status = Response.Status.CONFLICT;
//        } else if ("RG40".equals(ruleCode)) {
//            status = Response.Status.PRECONDITION_FAILED;
//        }

        return Response.status(status).entity(configureError(exception)).build();
    }

    private WLTPError configureError(DestinationException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    class WLTPError {
        private String errorCode;
        private String errorMsg;

        public String getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }

}
