/*
 * Creation : 14 Aug 2019
 */
package com.inetpsa.w7t.ihm.rest.maturityrequest;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.MaturityService;
import com.inetpsa.w7t.application.utilities.ConvertExcelDataToBytes;
import com.inetpsa.w7t.application.utilities.ExportUtility;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityErrorCode;
import com.inetpsa.w7t.domains.maturity.exceptions.MaturityException;
import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.ApiOperation;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.MATURITYIMPORT)
public class MaturityRequestResource {

    /** The Constant MATURITY. */
    private static final String MATURITY = "MATURITY";

    /** The logger. */
    @Logging
    private Logger logger;

    @Inject
    UserService userService;

    @Inject
    MaturityService maturityService;

    @Inject
    MaturityFinder maturityFinder;

    @Inject
    UserFinder userFinder;

    /** The fs flag file path. */
    @Configuration("fsFlagFilePath")
    private String fsFlagFilePath;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant SUFFIX. */
    @Configuration("xlsxSimulationSuffix")
    private String suffix;

    /** The prefix. */
    @Configuration("filePrefix")
    private String prefix;

    private static String[] maturityHeaders = { "E", "FAMILY", "BODY", "MOTOR", "GEARBOX", "INDEX", "STATUS" };

    @Rel(value = CatalogRels.MATURITYIMPORT, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response maturities() {
        CollectionRepresentation maturities = maturityFinder.all();
        return Response.ok(maturities).build();
    }

    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate,
            @FormDataParam("file") final FormDataBodyPart body) {
        String mimeType = body.getMediaType().toString();

        if (!mimeType.contains("sheet") && !mimeType.contains("excel")) {
            logger.info("MIME of uploaded file : {}", mimeType);
            return Response.status(Status.NOT_ACCEPTABLE).build();
        }
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new MaturityException(MaturityErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            if (isFileUploadInProcess()) {
                Object[] errMsg = { "k" };
                throw new MaturityException(MaturityErrorCode.SOMEONE_IMPORTING_DATA, errMsg);
            }

            userFinder.updateStatus(true, MATURITY);
            CollectionRepresentation maturity = maturityService.upload(inputStream, forceUpdate);
            userFinder.updateStatus(false, MATURITY);
            return Response.ok(maturity).build();

        } catch (IOException e) {
            userFinder.updateStatus(false, MATURITY);
            logger.error("IOException while uploading Maturity details : ", e.getMessage(), e);
            MaturityException maturity = new MaturityException(MaturityErrorCode.UNKNOWN_EXCEPTION, null);
            maturity.initCause(e);
            logger.error(e.getMessage(), e);
            throw maturity;
        } catch (MaturityException e) {
            if (e.getErrorCode() instanceof MaturityErrorCode) {
                MaturityErrorCode fec = (MaturityErrorCode) e.getErrorCode();
                if (fec.getDescription().contains(MaturityErrorCode.INDUS_MAINTAINANCE_ERROR.getDescription())) {
                    logger.error("MaturityException while uploading Maturity details : {} ", e.getMessage());
                    throw e;
                }
            }
            userFinder.updateStatus(false, MATURITY);
            logger.error("MaturityException while uploading Maturity details : {} ", e.getMessage());
            throw e;
        } catch (Exception e) {
            userFinder.updateStatus(false, MATURITY);
            if (e instanceof ConstraintViolationException) {
                Optional<ConstraintViolation<?>> error = ((ConstraintViolationException) e).getConstraintViolations().stream().findFirst();
                if (error.isPresent()) {
                    throw new MaturityException(MaturityErrorCode.MATURITY_UNKNOWN_EXCEPTION, null);
                }
            }
            logger.error("Exception while uploading Maturity details : ", e.getMessage(), e);
            Object[] errMsg = { e.getMessage() };
            throw new MaturityException(MaturityErrorCode.MATURITY_UNKNOWN_ERROR, errMsg);
        }

    }

    private boolean isFileUploadInProcess() {
        return userFinder.getUser(MATURITY).getStatus();
    }

    @Rel(value = CatalogRels.MATURITYSEARCH, home = true)
    @GET
    @Path(CatalogRels.MATURITYSEARCH)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response maturitySearch(@BeanParam MaturityFilter filter) {
        CollectionRepresentation maturities = maturityFinder.filter(filter);
        return Response.ok(maturities).build();
    }

    @Rel(value = CatalogRels.MATURITY_EXPORT, home = true)
    @GET
    @Path(CatalogRels.MATURITY_EXPORT)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response maturityExport() {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new MaturityException(MaturityErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        ConvertExcelDataToBytes byteData = new ConvertExcelDataToBytes();
        List<Maturity> maturities = maturityFinder.allMaturities();
        byte[] bytes = ExportUtility.writeMaturityToExcel(maturityHeaders, maturities, userService.getUserId());
        byteData.setBytes(bytes);
        return Response.ok(byteData).build();
    }

    @Rel(value = CatalogRels.FILTER_MATURITY_EXPORT, home = true)
    @GET
    @Path(CatalogRels.FILTER_MATURITY_EXPORT)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response filterMaturityExport(@BeanParam MaturityFilter filter) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new MaturityException(MaturityErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        ConvertExcelDataToBytes byteData = new ConvertExcelDataToBytes();
        List<Maturity> maturities = maturityFinder.filterMaturity(filter);
        byte[] bytes = ExportUtility.writeMaturityToExcel(maturityHeaders, maturities, userService.getUserId());
        byteData.setBytes(bytes);
        return Response.ok(byteData).build();
    }

}
