/*
 * Creation : 26 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlag;

/**
 * The Class FamilyTabCheckFlagRepresentation.
 *
 * @author E562493
 */
@DtoOf(FamilyTabCheckFlag.class)
public class FamilyTabCheckFlagRepresentation extends HalRepresentation {

    /** The t 8 C. */
    private String t8C;

    /** The t 8 D. */
    private String t8D;

    /** The tab id. */
    private String tabId;

    /** The Check flag. */
    private boolean CheckFlag;

    /**
     * Gets the t8c.
     *
     * @return the t8c
     */
    public String getT8C() {
        return t8C;
    }

    /**
     * Sets the t8c.
     *
     * @param t8c the new t8c
     */
    public void setT8C(String t8c) {
        t8C = t8c;
    }

    /**
     * Gets the t8d.
     *
     * @return the t8d
     */
    public String getT8D() {
        return t8D;
    }

    /**
     * Sets the t8d.
     *
     * @param t8d the new t8d
     */
    public void setT8D(String t8d) {
        t8D = t8d;
    }

    /**
     * Gets the tab id.
     *
     * @return the tab id
     */
    public String getTabId() {
        return tabId;
    }

    /**
     * Sets the tab id.
     *
     * @param tabId the new tab id
     */
    public void setTabId(String tabId) {
        this.tabId = tabId;
    }

    /**
     * Checks if is check flag.
     *
     * @return true, if is check flag
     */
    public boolean isCheckFlag() {
        return CheckFlag;
    }

    /**
     * Sets the check flag.
     *
     * @param checkFlag the new check flag
     */
    public void setCheckFlag(boolean checkFlag) {
        CheckFlag = checkFlag;
    }

}
