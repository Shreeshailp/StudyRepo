/*
 * Creation : 4 Apr 2019
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFilter;
import com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFinder;
import com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesRepresentation;

/**
 * The Class GeneratedCyclesJpaFinder.
 */
public class GeneratedCyclesJpaFinder implements GeneratedCyclesFinder {

    /** The Constant GENERATED_CODE. */
    private static final String GENERATED_CODE = "generatedCode";

    /** The Constant CYCLE_CODE. */
    private static final String CYCLE_CODE = "cycleCode";

    /** The Constant DOWN_SCALE_FLAG. */
    private static final String DOWN_SCALE_FLAG = "downscaleFlag";

    /** The Constant F_DSC. */
    private static final String F_DSC = "fdsc";

    /** The Constant SPEED_LIMIT_FLAG. */
    private static final String SPEED_LIMIT_FLAG = "speedLimitFlag";

    /** The Constant V_MAX. */
    private static final String V_MAX = "vMax";

    /** The Constant PHASE. */
    private static final String PHASE = "phase";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The limit. */
    @Configuration("generatedcyclessearch.limit")
    Integer limit;

    /** The downscale flag. */
    Optional<Boolean> downscaleFlag = Optional.empty();

    /** The speed limit flag. */
    Optional<Boolean> speedLimitFlag = Optional.empty();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFinder#all()
     */
    @Override
    public CollectionRepresentation all() {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> criteriaQuery = criteriaBuilder.createQuery(GeneratedCycle.class);
        Root<GeneratedCycle> root = criteriaQuery.from(GeneratedCycle.class);
        criteriaQuery.select(root);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get("generatedCode")), criteriaBuilder.asc(root.get("cycleCode")));

        TypedQuery<GeneratedCycle> query = entityManager.createQuery(criteriaQuery);
        List<GeneratedCyclesRepresentation> generatedCyclesList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(GeneratedCyclesRepresentation.class);
        if (!generatedCyclesList.isEmpty()) {
            logger.info("Found total generated cycles records in database is : [{}] ", generatedCyclesList.size());
        }
        CollectionRepresentation generatedcycles = new CollectionRepresentation(generatedCyclesList.size(), false);
        generatedcycles.self(relRegistry.uri(CatalogRels.IMPORTGENERATEDCYCLES));
        generatedcycles.embedded(CatalogRels.IMPORTGENERATEDCYCLES, generatedCyclesList);

        return generatedcycles;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFinder#filter(com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFilter)
     */

    @Override
    public CollectionRepresentation filter(GeneratedCyclesFilter filter) {

        Boolean downscale = null;
        Boolean speedLimit = null;
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> criteriaQuery = cb.createQuery(GeneratedCycle.class);
        Root<GeneratedCycle> root = criteriaQuery.from(GeneratedCycle.class);
        Optional<String> generatedCode = Optional.ofNullable(filter.generatedCode).filter(s -> !s.isEmpty());
        Optional<String> cycleCode = Optional.ofNullable(filter.cycleCode).filter(s -> !s.isEmpty());
        Optional<String> phase = Optional.ofNullable(filter.phase).filter(s -> !s.isEmpty());
        if (filter.downscaleFlag != null && !filter.downscaleFlag.isEmpty()) {
            downscale = filter.downscaleFlag.equalsIgnoreCase("y") ? true : false;
        }

        if (downscale != null)
            downscaleFlag = Optional.ofNullable(downscale).filter(s -> s.equals(true) || s.equals(false));

        if (filter.fdsc != null) {
            filter.fdsc = filter.fdsc.contains(",") ? filter.fdsc.replace(",", ".") : filter.fdsc;
        }
        Optional<String> fdsc = Optional.ofNullable(filter.fdsc).filter(s -> !s.isEmpty());

        if (filter.speedLimitFlag != null && !filter.speedLimitFlag.isEmpty()) {
            speedLimit = filter.speedLimitFlag.equalsIgnoreCase("y") ? true : false;
        }

        if (speedLimit != null)
            speedLimitFlag = Optional.ofNullable(speedLimit).filter(s -> s.equals(true) || s.equals(false));

        if (filter.vMax != null) {
            filter.vMax = filter.vMax.contains(",") ? filter.vMax.replace(",", ".") : filter.vMax;
        }
        Optional<String> vMax = Optional.ofNullable(filter.vMax).filter(s -> !s.isEmpty());

        List<Predicate> filters = new ArrayList<>();
        generatedCode.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(GENERATED_CODE)), cb.parameter(String.class, GENERATED_CODE))));
        cycleCode.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(CYCLE_CODE)), cb.parameter(String.class, CYCLE_CODE))));
        phase.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(PHASE)), cb.parameter(String.class, PHASE))));

        if (downscaleFlag.isPresent())
            downscaleFlag.ifPresent(c -> filters.add(cb.equal((root.get(DOWN_SCALE_FLAG)), cb.parameter(Boolean.class, DOWN_SCALE_FLAG))));
        fdsc.ifPresent(c -> filters.add(cb.like(cb.trim((root.get(F_DSC))), cb.parameter(String.class, F_DSC))));

        if (speedLimitFlag.isPresent())
            speedLimitFlag.ifPresent(c -> filters.add(cb.equal((root.get(SPEED_LIMIT_FLAG)), cb.parameter(Boolean.class, SPEED_LIMIT_FLAG))));

        vMax.ifPresent(c -> filters.add(cb.like(cb.trim((root.get(V_MAX))), cb.parameter(String.class, V_MAX))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<GeneratedCycle> query = entityManager.createQuery(criteriaQuery);
        generatedCode.ifPresent(c -> query.setParameter(GENERATED_CODE, '%' + c.toLowerCase() + '%'));
        cycleCode.ifPresent(c -> query.setParameter(CYCLE_CODE, '%' + c.toLowerCase() + '%'));
        phase.ifPresent(c -> query.setParameter(PHASE, '%' + c.toLowerCase() + '%'));
        if (downscaleFlag.isPresent())
            downscaleFlag.ifPresent(c -> query.setParameter(DOWN_SCALE_FLAG, downscaleFlag.get()));
        fdsc.ifPresent(c -> query.setParameter(F_DSC, '%' + c.toLowerCase() + '%'));

        if (speedLimitFlag.isPresent())
            speedLimitFlag.ifPresent(c -> query.setParameter(SPEED_LIMIT_FLAG, speedLimitFlag.get()));

        vMax.ifPresent(c -> query.setParameter(V_MAX, '%' + c.toLowerCase() + '%'));

        List<GeneratedCyclesRepresentation> generatedCyclesList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(GeneratedCyclesRepresentation.class);

        if (!generatedCyclesList.isEmpty()) {
            logger.info("Found total generated cycles records in database is : [{}] ", generatedCyclesList.size());
        }
        CollectionRepresentation generatedcycles = new CollectionRepresentation(generatedCyclesList.size(), false);
        generatedcycles.self(relRegistry.uri(CatalogRels.GENERATEDCYCLESSEARCH));
        generatedcycles.embedded(CatalogRels.GENERATEDCYCLESSEARCH, generatedCyclesList);
        return generatedcycles;

    }

}
