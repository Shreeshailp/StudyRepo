/*
 * Creation : 24 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.HttpStatus;
import org.seedstack.seed.Configuration;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.FamilyService;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalDataDto;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Class FamilyAdditionalDataResource.
 *
 * @author E569186
 */
@Path("/additionalFamily")
public class FamilyAdditionalDataResource {

    /** The family service. */
    @Inject
    private FamilyService familyService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant NULL. */
    private static final String NULL = "null";

    /**
     * Save update family additional data.
     *
     * @param t8c                     the t8c
     * @param t8d                     the t8d
     * @param familyAdditionalDataDto the family additional data dto
     * @return the response
     */
    @POST
    @Path("/saveupdatefamilyadditionaldata")
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response saveUpdateFamilyAdditionalData(@QueryParam(CatalogRels.T8C) String t8c, @QueryParam(CatalogRels.T8D) String t8d,
            FamilyAdditionalDataDto familyAdditionalDataDto) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new FamilyValidationException(FamilyErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        return saveUpdateFamilyData(t8c, t8d, familyAdditionalDataDto);
    }

    /**
     * Save update family data.
     *
     * @param t8c                     the t 8 c
     * @param t8d                     the t 8 d
     * @param familyAdditionalDataDto the family additional data dto
     * @return the response
     */
    private Response saveUpdateFamilyData(String t8c, String t8d, FamilyAdditionalDataDto familyAdditionalDataDto) {
        CollectionRepresentation familyAdditionalData = null;
        if (familyAdditionalDataDto != null && !t8c.equals(NULL) && !t8c.equals("") && !t8d.equals(NULL) && !t8d.equals("")) {
            familyAdditionalData = familyService.saveUpdateFamilyAdditionalData(t8c, t8d, familyAdditionalDataDto);

        } else {
            return Response.status(HttpStatus.SC_BAD_REQUEST).entity("").type(MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(familyAdditionalData).build();
    }

    /**
     * Gets the family additional data.
     *
     * @param t8c the t 8 c
     * @param t8d the t 8 d
     * @return the family additional data
     */
    @POST
    @Path("/getfamilyadditionaldata")
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getFamilyAdditionalData(@QueryParam(CatalogRels.T8C) String t8c, @QueryParam(CatalogRels.T8D) String t8d) {
        return getFamilyData(t8c, t8d);

    }

    /**
     * Gets the family data.
     *
     * @param t8c the t 8 c
     * @param t8d the t 8 d
     * @return the family data
     */
    private Response getFamilyData(String t8c, String t8d) {
        FamilyAdditionalData response = null;
        if (!t8c.equals(NULL) && !t8c.equals("") && !t8d.equals(NULL) && !t8d.equals("")) {
            try {
                response = familyService.getAllFamilyAdditionalData(t8c, t8d);
                if (response != null) {
                    response.setFamily(null);
                }
            } catch (Exception e) {
                return Response.status(HttpStatus.SC_BAD_REQUEST).entity(e.getMessage()).type(MediaType.APPLICATION_JSON).build();
            }
        } else {
            return Response.status(HttpStatus.SC_BAD_REQUEST).entity("").type(MediaType.APPLICATION_JSON).build();
        }
        return Response.ok(response).build();
    }
}
