/*
 * Creation : 3 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.VehicleType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface VehicleTypeFinder. This finder is used to retrieve representations of {@link VehicleType} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface VehicleTypeFinder {

    /**
     * Retrieve the representation of all {@link VehicleType} entities.
     *
     * @return a representation of all vehicle types
     */
    CollectionRepresentation all();

    /**
     * Retrieve a specific {@link VehicleType} representation identified by its {@code code} or its UUID entity id.
     *
     * @param vehicletype the vehicle type identifier
     * @return an optional vehicle type representation
     */
    Optional<VehicleTypeRepresentation> get(String vehicletype);

    /**
     * Retrieve a specific {@link VehicleType} representation identified by its {@code code}.
     *
     * @param code the code
     * @return the vehicle type representation
     */
    Optional<VehicleTypeRepresentation> byCode(String code);

    /**
     * By id.
     *
     * @param id the id
     * @return the vehicle type representation
     */
    Optional<VehicleTypeRepresentation> byId(@IsUUID String id);
}
