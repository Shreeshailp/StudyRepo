/*
 * Creation : 3 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface CountryFinder. This finder is used to retrieve representations of {@link Country} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface CountryFinder {

    /**
     * Retrieve the representation of all {@link Country} entities.
     *
     * @return a representation of all countries
     */
    CollectionRepresentation all();

    /**
     * Retrieve a specific {@link Country} representation identified by its {@code code} or its UUID entity id.
     *
     * @param country the country identifier
     * @return an optional country representation
     */
    Optional<CountryRepresentation> get(String country);

    /**
     * Retrieve a specific {@link Country} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return an optional country representation
     */
    Optional<CountryRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link Country} representation identified by its {@code code}.
     *
     * @param code the code
     * @return an optional country representation
     */
    Optional<CountryRepresentation> byCode(String code);
}
