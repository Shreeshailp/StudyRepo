/*
 * Creation : 1 avr. 2017
 */
package com.inetpsa.w7t.application.services.internal;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.inetpsa.w7t.domains.cycles.shared.CycleErrorCode;
import com.inetpsa.w7t.domains.cycles.shared.CycleValidationException;

@Provider
public class CycleValidationExceptionMapper implements ExceptionMapper<CycleValidationException> {

    @Override
    public Response toResponse(CycleValidationException exception) {

        Status status = Response.Status.BAD_REQUEST;

        String ruleCode = ((CycleErrorCode) exception.getErrorCode()).getRuleCode();
        if ("RG18".equals(ruleCode))
            status = Response.Status.CONFLICT;

        return Response.status(status).entity(configureError(exception)).build();
    }

    private WLTPError configureError(CycleValidationException exception) {
        WLTPError error = new WLTPError();
        error.setErrorCode(exception.getContextErrorCode());
        error.setErrorMsg(exception.getContextMesage());
        return error;
    }

    class WLTPError {
        private String errorCode;
        private String errorMsg;

        public String getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }
    }
}
