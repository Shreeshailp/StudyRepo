/*
 * Creation : 13 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.assembler.MatchingEntityId;
import org.seedstack.business.assembler.MatchingFactoryParameter;
import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.enginesettings.model.Destination;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Class AbstractDestinationRepresentation. This class represents the common parts betwwen {@link Destination} and {@link DestinationDetails}.
 */
public abstract class AbstractDestinationRepresentation extends HalRepresentation {
    /** The guid. */
    protected UUID guid;

    /** The label. */
    protected String label;

    /** The from date. */
    protected String fromDate;

    /** The to date. */
    protected String toDate;

    /** The countries. */
    protected List<String> countries;

    /**
     * Getter guid
     * 
     * @return the guid
     */
    @MatchingEntityId
    @MatchingFactoryParameter(index = 0)
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid
     * 
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter label
     * 
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Setter label
     * 
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Getter fromDate
     * 
     * @return the fromDate
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * Setter fromDate
     * 
     * @param fromDate the fromDate to set
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * Getter toDate
     * 
     * @return the toDate
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * Setter toDate
     * 
     * @param toDate the toDate to set
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    /**
     * Getter countries
     * 
     * @return the countries
     */
    public List<String> getCountries() {
        return countries;
    }

    /**
     * Setter countries
     * 
     * @param countries the countries to set
     */
    public void setCountries(List<String> countries) {
        this.countries = countries;
    }
}
