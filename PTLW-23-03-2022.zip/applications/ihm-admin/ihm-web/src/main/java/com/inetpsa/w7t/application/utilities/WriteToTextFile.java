/*
 * Creation : 10 Apr 2019
 */
package com.inetpsa.w7t.application.utilities;

/**
 * The Class WriteToTextFile.
 */
public final class WriteToTextFile {

    /** The content. */
    static StringBuffer content = new StringBuffer();

    /**
     * Clean up.
     */
    public static void cleanUp() {
        content.delete(0, content.length());
    }

    /**
     * Write to file.
     *
     * @param data the data
     */
    public static void writeToFile(String data) {

        if (data != null) {
            content.append(data + "\r\n");
        }

    }

    /**
     * Read file.
     *
     * @return the string buffer
     */
    public static StringBuffer readFile() {
        return content;
    }

    /**
     * Instantiates a new write to text file.
     */
    private WriteToTextFile() {

    }
}
