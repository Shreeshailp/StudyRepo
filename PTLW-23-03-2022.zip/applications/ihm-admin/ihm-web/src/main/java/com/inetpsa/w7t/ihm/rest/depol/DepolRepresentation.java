/*
 * Creation : 11 Jul 2019
 */
package com.inetpsa.w7t.ihm.rest.depol;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.depol.model.Depol;

@DtoOf(Depol.class)
public class DepolRepresentation extends AbstractDepolRepresentation {

}
