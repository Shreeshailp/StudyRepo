/*
 * Creation : 1 Aug 2019
 */
package com.inetpsa.w7t.application.utilities;

public class ConvertExcelDataToBytes {

    byte[] bytes;

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

}
