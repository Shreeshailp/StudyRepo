/*
 * Creation : 12 Feb 2020
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryEntity;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.change.history.resource.ChangeHistoryFilter;
import com.inetpsa.w7t.ihm.rest.change.history.resource.ChangeHistoryRepresentation;

/**
 * The Class ChangeHistoryJpaFinder.
 */
public class ChangeHistoryJpaFinder implements ChangeHistoryFinder {

    /** The Constant DATA_CATEGORY. */
    private static final String DATA_CATEGORY = "dataCategory";

    /** The Constant DATA_ID. */
    private static final String DATA_ID = "dataId";

    /** The Constant TIME_STAMP. */
    private static final String TIME_STAMP = "timeStamp";

    /** The Constant USER. */
    private static final String USER = "user";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The Constant LIMIT. */
    private static final Integer LIMIT = 501;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.infrastructure.finders.jpa.ChangeHistoryFinder#all()
     */
    @SuppressWarnings("unchecked")
    @Override
    public CollectionRepresentation all() {
        String sqlQuery = "select *from W7TQTCHG ORDER BY TIME_STAMP desc";

        Query query = entityManager.createNativeQuery(sqlQuery, ChangeHistoryEntity.class);
        query.setMaxResults(LIMIT);
        List<ChangeHistoryEntity> list = query.getResultList();

        List<ChangeHistoryRepresentation> changeHistoryList = fluentAssembler.assemble(list).with(WltpModelMapper.class)
                .to(ChangeHistoryRepresentation.class);

        CollectionRepresentation changeHistory = new CollectionRepresentation(changeHistoryList.size(), false);
        changeHistory.self(relRegistry.uri(CatalogRels.CHANGE_HISTORY));
        changeHistory.embedded(CatalogRels.CHANGE_HISTORY, changeHistoryList);
        return changeHistory;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.infrastructure.finders.jpa.ChangeHistoryFinder#filter(com.inetpsa.w7t.ihm.rest.change.history.resource.ChangeHistoryFilter)
     */
    @Override
    public CollectionRepresentation filter(ChangeHistoryFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<ChangeHistoryEntity> criteriaQuery = cb.createQuery(ChangeHistoryEntity.class);
        Root<ChangeHistoryEntity> root = criteriaQuery.from(ChangeHistoryEntity.class);

        Optional<String> dataCategory = Optional.ofNullable(filter.dataCategory).filter(s -> !s.isEmpty());
        Optional<String> dataId = Optional.ofNullable(filter.dataId).filter(s -> !s.isEmpty());
        Optional<String> timeStamp = Optional.ofNullable(filter.timeStamp).filter(s -> !s.isEmpty());
        Optional<String> user = Optional.ofNullable(filter.user).filter(s -> !s.isEmpty());

        List<Predicate> filters = new ArrayList<>();
        dataCategory.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(DATA_CATEGORY)), cb.parameter(String.class, DATA_CATEGORY))));
        dataId.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(DATA_ID)), cb.parameter(String.class, DATA_ID))));
        timeStamp.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(TIME_STAMP)), cb.parameter(String.class, TIME_STAMP))));
        user.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(USER)), cb.parameter(String.class, USER))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<ChangeHistoryEntity> query = entityManager.createQuery(criteriaQuery);
        dataCategory.ifPresent(c -> query.setParameter(DATA_CATEGORY, '%' + c.toLowerCase() + '%'));
        dataId.ifPresent(c -> query.setParameter(DATA_ID, '%' + c.toLowerCase() + '%'));
        timeStamp.ifPresent(c -> query.setParameter(TIME_STAMP, '%' + c.toLowerCase() + '%'));
        user.ifPresent(c -> query.setParameter(USER, '%' + c.toLowerCase() + '%'));

        List<ChangeHistoryRepresentation> changeHistorySearchList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(ChangeHistoryRepresentation.class);

        CollectionRepresentation changeHistorySearch = new CollectionRepresentation(changeHistorySearchList.size(), false);
        changeHistorySearch.self(relRegistry.uri(CatalogRels.CHANGE_HISTORY_SEARCH));
        changeHistorySearch.embedded(CatalogRels.CHANGE_HISTORY_SEARCH, changeHistorySearchList);
        return changeHistorySearch;
    }

}
