/*
* Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalDataDto;
import com.inetpsa.w7t.domains.families.model.family.FamilyDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface FamilyService.
 */
@Service
public interface FamilyService {

    /**
     * The Upload method which handles the complete upload of a Family.
     *
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @return the families representation
     * @throws IOException Signals that an I/O exception has occurred.
     */
    CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException;

    /**
     * This method handles the insertion or updation of the families data in the database
     *
     * @param families the families
     * @param forceUpdate the force update
     * @return the list
     */
    List<FamilyDetails> importFamilies(List<FamilyDto> families, Boolean forceUpdate);

    /**
     * Save update family additional data.
     *
     * @param t8c the t 8 c
     * @param t8d the t 8 d
     * @param familyAdditionalDataDto the family additional data dto
     * @return the collection representation
     */
    CollectionRepresentation saveUpdateFamilyAdditionalData(String t8c, String t8d, FamilyAdditionalDataDto familyAdditionalDataDto);

    /**
     * Gets the all family additional data.
     *
     * @param t8c the t 8 c
     * @param t8d the t 8 d
     * @return the all family additional data
     * @throws SQLException the SQL exception
     */
    FamilyAdditionalData getAllFamilyAdditionalData(String t8c, String t8d) throws SQLException;

}
