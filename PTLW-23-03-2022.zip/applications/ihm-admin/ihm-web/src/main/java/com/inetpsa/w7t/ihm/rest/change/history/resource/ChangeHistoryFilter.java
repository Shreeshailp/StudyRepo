/*
 * Creation : 12 Feb 2020
 */
package com.inetpsa.w7t.ihm.rest.change.history.resource;

import javax.ws.rs.QueryParam;

public class ChangeHistoryFilter {
    @QueryParam("dataCategory")
    public String dataCategory;

    @QueryParam("dataId")
    public String dataId;

    @QueryParam("timeStamp")
    public String timeStamp;

    @QueryParam("user")
    public String user;
}
