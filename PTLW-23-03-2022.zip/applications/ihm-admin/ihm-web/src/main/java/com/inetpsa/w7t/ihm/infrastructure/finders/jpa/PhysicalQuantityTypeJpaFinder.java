/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.references.PhysicalQuantityTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.PhysicalQuantityTypeRepresentation;

/**
 * The Class PhysicalQuantityTypeJpaFinder. This is the JPA Implementation of the {@link PhysicalQuantityTypeFinder}.
 */
public class PhysicalQuantityTypeJpaFinder implements PhysicalQuantityTypeFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.PhysicalQuantityTypeFinder#all()
     */
    @Override
    public CollectionRepresentation all() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PhysicalQuantityType> q = cb.createQuery(PhysicalQuantityType.class);
        q.select(q.from(PhysicalQuantityType.class));
        TypedQuery<PhysicalQuantityType> query = entityManager.createQuery(q);

        List<PhysicalQuantityTypeRepresentation> physicalQuantityTypeList = fluentAssembler.assemble(query.getResultList())
                .with(WltpModelMapper.class).to(PhysicalQuantityTypeRepresentation.class).stream().peek(pqt -> {
                    pqt.setLabel(labelService.value(pqt.getGuid()));
                    pqt.self(relRegistry.uri(CatalogRels.PHYSICAL_QUANTITY).set(CatalogRels.PHYSICAL_QUANTITY, pqt.getGuid()));
                }).collect(toList());

        CollectionRepresentation physicalQuantityTypes = new CollectionRepresentation(physicalQuantityTypeList.size(), false);

        physicalQuantityTypes.self(relRegistry.uri(CatalogRels.PHYSICAL_QUANTITIES));
        physicalQuantityTypes.embedded(CatalogRels.PHYSICAL_QUANTITIES, physicalQuantityTypeList);

        return physicalQuantityTypes;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.PhysicalQuantityTypeFinder#byId(java.lang.String)
     */
    @Override
    public Optional<PhysicalQuantityTypeRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PhysicalQuantityType> q = cb.createQuery(PhysicalQuantityType.class);
        Root<PhysicalQuantityType> c = q.from(PhysicalQuantityType.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<PhysicalQuantityType> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        List<PhysicalQuantityType> list = query.getResultList();
        Optional<PhysicalQuantityType> physicalQuantityTypeObj = Optional.empty();
        if (!list.isEmpty()) {
            physicalQuantityTypeObj = list.stream().findFirst();
        }

        Optional<PhysicalQuantityTypeRepresentation> physicalQuantityType = physicalQuantityTypeObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(PhysicalQuantityTypeRepresentation.class));

        physicalQuantityType.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.PHYSICAL_QUANTITY).set(CatalogRels.PHYSICAL_QUANTITY, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.PHYSICAL_QUANTITIES).templated());
        });

        return physicalQuantityType;
    }
}
