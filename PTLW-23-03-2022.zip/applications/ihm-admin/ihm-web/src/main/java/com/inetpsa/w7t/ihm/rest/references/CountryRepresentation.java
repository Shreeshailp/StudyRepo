/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.Country;

/**
 * The Class CountryRepresentation. This representation is used to represent a specific {@link Country}.
 */
@DtoOf(Country.class)
public class CountryRepresentation extends ReferenceRepresentation {

    private String characteristic;

    public String getCharacteristic() {
        return characteristic;
    }

    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

}
