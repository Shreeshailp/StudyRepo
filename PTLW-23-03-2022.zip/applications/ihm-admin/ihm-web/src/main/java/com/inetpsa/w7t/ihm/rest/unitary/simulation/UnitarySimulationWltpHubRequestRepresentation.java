/*
 * Creation : 2 Sep 2021
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

public class UnitarySimulationWltpHubRequestRepresentation {

    private UnitarySimulationWltpHubRequest request;

    public UnitarySimulationWltpHubRequest getRequest() {
        return request;
    }

    public void setRequest(UnitarySimulationWltpHubRequest request) {
        this.request = request;
    }

    @Override
    public String toString() {
        return "UnitarySimulationWltpHubRequestRepresentation [request=" + request + "]";
    }

}
