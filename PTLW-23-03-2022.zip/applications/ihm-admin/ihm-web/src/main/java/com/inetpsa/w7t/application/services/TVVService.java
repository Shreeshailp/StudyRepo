/*
 * Creation : 29 May 2018
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.tvv.exceptions.TVVException;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface TVVService.
 */
@Service
public interface TVVService {

    /**
     * Upload.
     *
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @return the collection representation
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws TVVException the TVV exception
     */
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException, TVVException;

}
