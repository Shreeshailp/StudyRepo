/*
 * Creation : 6 Jan 2022
 */
package com.inetpsa.w7t.application.services.internal;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Propagation;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.DepolStatusReportService;
import com.inetpsa.w7t.domains.depol.model.DepolDto;
import com.inetpsa.w7t.domains.depol.model.DepolStatusReport;
import com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolStatusReportRepository;

/**
 * The Class DepolStatusReportServiceImpl.
 */
@JpaUnit("wltp-domain-jpa-unit")
public class DepolStatusReportServiceImpl implements DepolStatusReportService {

    /** The date time formatter. */
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** The logger. */
    @Logging
    private Logger logger;

    /** The depol status report repository. */
    @Inject
    private DepolStatusReportRepository depolStatusReportRepository;

    /** The depol status report factory. */
    @Inject
    private Factory<DepolStatusReport> depolStatusReportFactory;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.DepolStatusReportService#getDepolStatusReportByFileName(java.lang.String)
     */
    @Transactional
    @Override
    public List<DepolDto> getDepolStatusReportByFileName(String fileName) {
        List<DepolDto> depolDtosList = new ArrayList<>();
        List<DepolStatusReport> depolStatusReports = depolStatusReportRepository.getDepolStatusReportByFileName(fileName);
        for (DepolStatusReport depolStatusReport : depolStatusReports) {
            DepolDto depolDto = new DepolDto();
            depolDto.setCodeDepol(depolStatusReport.getCodeDepol());
            depolDto.setSpecialFlag(depolStatusReport.getCodeSpecial());
            depolDto.setDesignation(depolStatusReport.getDepolLabel());
            depolDto.setCrrMin(depolStatusReport.getCrrMin());
            depolDto.setCrrMax(depolStatusReport.getCrrMax());
            depolDto.setMroMin(depolStatusReport.getMroMin());
            depolDto.setMroMax(depolStatusReport.getMroMax());
            depolDto.setFrontalAreaMin(depolStatusReport.getStrMin());
            depolDto.setFrontalAreaMax(depolStatusReport.getStrMax());
            depolDto.setCoolingSurfaceMin(depolStatusReport.getCoolstrMin());
            depolDto.setCoolingSurfaceMax(depolStatusReport.getCoolStrMax());
            depolDto.setCxMin(depolStatusReport.getCxMin());
            depolDto.setCxMax(depolStatusReport.getCxMax());
            depolDto.setStatus(depolStatusReport.getChecking());
            depolDtosList.add(depolDto);
        }
        return depolDtosList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.DepolStatusReportService#saveDepolStatusReport(java.lang.String, java.util.List)
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void saveDepolStatusReport(String fileName, List<DepolDto> dtoList) {
        try {
            if (org.apache.commons.lang.StringUtils.isNotEmpty(fileName) && (dtoList != null && !dtoList.isEmpty())) {
                List<DepolStatusReport> depolStatusReports = depolStatusReportRepository.getDepolStatusReportByFileName(fileName);
                if (depolStatusReports != null && !depolStatusReports.isEmpty()) {
                    for (DepolStatusReport depolStatusReport : depolStatusReports) {
                        depolStatusReportRepository.delete(depolStatusReport);
                    }

                }
                for (DepolDto depolDto : dtoList) {
                    DepolStatusReport dsrAggregate = depolStatusReportFactory.create();
                    dsrAggregate.setGuid(UUID.randomUUID());
                    dsrAggregate.setFileName(fileName);
                    dsrAggregate.setCodeDepol(depolDto.getCodeDepol());
                    dsrAggregate.setCodeSpecial(depolDto.getSpecialFlag());
                    dsrAggregate.setDepolLabel(depolDto.getDesignation());
                    dsrAggregate.setCrrMin(depolDto.getCrrMin());
                    dsrAggregate.setCrrMax(depolDto.getCrrMax());
                    dsrAggregate.setMroMin(depolDto.getMroMin());
                    dsrAggregate.setMroMax(depolDto.getMroMax());
                    dsrAggregate.setStrMin(depolDto.getFrontalAreaMin());
                    dsrAggregate.setStrMax(depolDto.getFrontalAreaMax());
                    dsrAggregate.setCoolstrMin(depolDto.getCoolingSurfaceMin());
                    dsrAggregate.setCoolStrMax(depolDto.getCoolingSurfaceMax());
                    dsrAggregate.setCxMin(depolDto.getCxMin());
                    dsrAggregate.setCxMax(depolDto.getCxMax());
                    if (StringUtils.isNotEmpty(depolDto.getStatus())) {
                        dsrAggregate.setChecking(depolDto.getStatus());
                    } else {
                        dsrAggregate.setChecking("OK");
                    }

                    dsrAggregate.setCreatedDate(getTodaysDate());
                    DepolStatusReport savedDSR = depolStatusReportRepository.save(dsrAggregate);
                    logger.info("Saved record into database:[{}]", savedDSR);

                }

            }
        } catch (Exception e) {
            logger.error("Exception while storing data into database :[{}]", e);
        }

    }

    /**
     * Gets the todays date.
     *
     * @return the todays date
     */
    private String getTodaysDate() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

}
