/*
 * Creation : 20 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.application;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.seedstack.seed.Application;
import org.seedstack.seed.rest.Rel;

import com.inetpsa.w7t.ihm.rest.CatalogRels;

import io.swagger.annotations.Api;

/**
 * The Class ApplicationResource. Returns applications for info purpose.
 */
@Path(CatalogRels.APPLICATION)
@Api
public class ApplicationResource {

    @Inject
    private Application application;

    /**
     * Return the current application.
     *
     * @return the current application
     */
    @Rel(value = CatalogRels.APPLICATION)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response version() {
        return Response.ok(new ApplicationRepresentation(application.getName(), application.getId(), application.getVersion())).build();
    }
}
