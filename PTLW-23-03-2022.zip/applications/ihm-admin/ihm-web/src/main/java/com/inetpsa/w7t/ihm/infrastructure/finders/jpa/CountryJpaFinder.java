/*
 * Creation : 3 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.Validation;
import javax.validation.Validator;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.references.CountryFinder;
import com.inetpsa.w7t.ihm.rest.references.CountryRepresentation;

/**
 * The Class CountryJpaFinder. This is the JPA Implementation of the {@link CountryFinder}.
 */
public class CountryJpaFinder implements CountryFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    private EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    private FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CountryFinder#all()
     */
    @Override
    public CollectionRepresentation all() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> q = cb.createQuery(Country.class);
        q.select(q.from(Country.class));
        TypedQuery<Country> query = entityManager.createQuery(q);

        List<CountryRepresentation> countryList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(CountryRepresentation.class);

        countryList.stream().forEach(country -> {
            country.setLabel(labelService.value(country.getGuid()));
            country.self(relRegistry.uri(CatalogRels.COUNTRY).set(CatalogRels.COUNTRY, country.getGuid()));
        });

        CollectionRepresentation countries = new CollectionRepresentation(countryList.size(), false);

        countries.self(relRegistry.uri(CatalogRels.COUNTRIES).templated());
        countries.link("find", relRegistry.uri(CatalogRels.COUNTRY).templated());
        countries.embedded(CatalogRels.COUNTRIES, countryList);

        return countries;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CountryFinder#get(java.lang.String)
     */
    @Override
    public Optional<CountryRepresentation> get(String country) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        if (validator.validateValue(Country.class, CODE, country).isEmpty())
            return this.byCode(country);
        return this.byId(country);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CountryFinder#byId(java.lang.String)
     */
    @Override
    public Optional<CountryRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> q = cb.createQuery(Country.class);
        Root<Country> c = q.from(Country.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<Country> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        Optional<CountryRepresentation> country = query.getResultList().stream().findFirst()
                .map(cty -> fluentAssembler.assemble(cty).with(WltpModelMapper.class).to(CountryRepresentation.class));

        country.ifPresent(cty -> {
            cty.setLabel(labelService.value(cty.getGuid()));
            cty.self(relRegistry.uri(CatalogRels.COUNTRY).set(CatalogRels.COUNTRY, cty.getGuid()));
            cty.link("find", relRegistry.uri(CatalogRels.COUNTRIES).templated());
        });

        return country;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CountryFinder#byCode(java.lang.String)
     */
    @Override
    public Optional<CountryRepresentation> byCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> q = cb.createQuery(Country.class);
        Root<Country> c = q.from(Country.class);
        q.where(cb.equal(cb.lower(c.get(CODE)), cb.lower(cb.parameter(String.class, CODE))));

        TypedQuery<Country> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        Optional<CountryRepresentation> country = query.getResultList().stream().findFirst()
                .map(cty -> fluentAssembler.assemble(cty).with(WltpModelMapper.class).to(CountryRepresentation.class));

        country.ifPresent(cty -> {
            cty.setLabel(labelService.value(cty.getGuid()));
            cty.self(relRegistry.uri(CatalogRels.COUNTRY).set(CatalogRels.COUNTRY, cty.getGuid()));
            cty.link("find", relRegistry.uri(CatalogRels.COUNTRIES).templated());
        });

        return country;
    }

}
