package com.inetpsa.w7t.application.services.internal;

public final class TVVConstants {

    public static final String FIRST_COL_ERROR_MSG = "FIRST_COL_ERROR_MSG";
    public static final String FIRST_LINE_STARTS_C_M_D = "FIRST_LINE_STARTS_C_M_D ";
    public static final String TWO_LINES_STARTS_WITH_CMD = "TWO_LINES_STARTS_WITH_CMD_SAME_KYES";
    public static final String VALIDATELINESTARTSWITHC = "VALIDATELINESTARTSWITHC";
    public static final String VALIDATELINESTARTSWITHD = "VALIDATELINESTARTSWITHD";
    public static final String VALIDATELINESTARTSWITHM = "VALIDATELINESTARTSWITHM";

    private TVVConstants() {

    }

}
