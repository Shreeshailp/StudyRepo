/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

public class ParameterDetailsRepresentation {
    private boolean concerned;
    private String vehicleType;
    private String measureType;
    private String cyclePhase;

    public boolean isConcerned() {
        return concerned;
    }

    public void setConcerned(boolean concerned) {
        this.concerned = concerned;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getMeasureType() {
        return measureType;
    }

    public void setMeasureType(String measureType) {
        this.measureType = measureType;
    }

    public String getCyclePhase() {
        return cyclePhase;
    }

    public void setCyclePhase(String cyclePhase) {
        this.cyclePhase = cyclePhase;
    }
}
