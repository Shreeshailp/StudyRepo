/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface FamilyFinder. This finder is used to retrieve representations of {@link Family} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyFinder {

    /**
     * Retrieve the representation of all {@link Family} entities.
     *
     * @param filter the family filter
     * @return a representation of all countries a representation of all families
     */
    CollectionRepresentation all(FamilyFilter filter);

    /**
     * Retrieve a specific {@link Family} representation identified by its UUID entity id.
     *
     * @param id the family id
     * @return the family details representation
     */
    Optional<FamilyDetailsRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link FamilyDetails} representation identified by its code and index.
     *
     * @param code the family code
     * @param index the family index
     * @return the family details representation
     */
    Optional<FamilyDetailsRepresentation> byCodeAndIndex(@FamilyCode String code, Integer index);

    /**
     * Fetch all family details.
     *
     * @param filter the filter
     * @return the collection representation
     */
    CollectionRepresentation fetchAllFamilyDetails(FamilyFilter filter);

    /**
     * Gets the all families.
     *
     * @return the all families
     */
    CollectionRepresentation getAllFamilies();
}
