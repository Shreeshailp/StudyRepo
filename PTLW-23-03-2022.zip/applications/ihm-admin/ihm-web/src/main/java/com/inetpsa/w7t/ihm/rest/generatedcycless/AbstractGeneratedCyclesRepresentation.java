/*
 * Creation : 17 May 2018
 */
package com.inetpsa.w7t.ihm.rest.generatedcycless;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

/**
 * The Class AbstractGeneratedCyclesRepresentation.
 */
public class AbstractGeneratedCyclesRepresentation extends HalRepresentation {

    /** The guid. */
    protected UUID guid;

    /** The generated code. */
    protected String generatedCode;

    /** The cycle code. */
    protected String cycleCode;

    /** The phase. */
    protected String phase;

    /** The speed limit. */
    protected int speedLimit;

    /** The fdsc. */
    protected Float fdsc;

    /** The total distance. */
    protected Float totalDistance;

    /** The v max. */
    protected Float vMax;

    /** The downscale flag. */
    protected boolean downscaleFlag;

    /** The speed limit flag. */
    protected boolean speedLimitFlag;

    /** The created by. */
    protected String createdBy;

    /** The created date. */
    protected String createdDate;

    /** The updated by. */
    protected String updatedBy;

    /** The updated date. */
    protected String updatedDate;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the generated code.
     *
     * @return the generated code
     */
    public String getGeneratedCode() {
        return generatedCode;
    }

    /**
     * Sets the generated code.
     *
     * @param generatedCode the new generated code
     */
    public void setGeneratedCode(String generatedCode) {
        this.generatedCode = generatedCode;
    }

    /**
     * Gets the cycle code.
     *
     * @return the cycle code
     */
    public String getCycleCode() {
        return cycleCode;
    }

    /**
     * Sets the cycle code.
     *
     * @param cycleCode the new cycle code
     */
    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the speed limit.
     *
     * @return the speed limit
     */
    public int getSpeedLimit() {
        return speedLimit;
    }

    /**
     * Sets the speed limit.
     *
     * @param speedLimit the new speed limit
     */
    public void setSpeedLimit(int speedLimit) {
        this.speedLimit = speedLimit;
    }

    /**
     * Gets the total distance.
     *
     * @return the total distance
     */
    public Float getTotalDistance() {
        return totalDistance;
    }

    /**
     * Sets the total distance.
     *
     * @param totalDistance the new total distance
     */
    public void setTotalDistance(Float totalDistance) {
        this.totalDistance = totalDistance;
    }

    /**
     * Gets the v max.
     *
     * @return the v max
     */
    public Float getvMax() {
        return vMax;
    }

    /**
     * Sets the v max.
     *
     * @param vMax the new v max
     */
    public void setvMax(Float vMax) {
        this.vMax = vMax;
    }

    /**
     * Checks if is downscale flag.
     *
     * @return true, if is downscale flag
     */
    public boolean isDownscaleFlag() {
        return downscaleFlag;
    }

    /**
     * Sets the downscale flag.
     *
     * @param downscaleFlag the new downscale flag
     */
    public void setDownscaleFlag(boolean downscaleFlag) {
        this.downscaleFlag = downscaleFlag;
    }

    /**
     * Checks if is speed limit flag.
     *
     * @return true, if is speed limit flag
     */
    public boolean isSpeedLimitFlag() {
        return speedLimitFlag;
    }

    /**
     * Sets the speed limit flag.
     *
     * @param speedLimitFlag the new speed limit flag
     */
    public void setSpeedLimitFlag(boolean speedLimitFlag) {
        this.speedLimitFlag = speedLimitFlag;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the updated by.
     *
     * @return the updated by
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the updated by.
     *
     * @param updatedBy the new updated by
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate the new updated date
     */
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the fdsc.
     *
     * @return the fdsc
     */
    public Float getFdsc() {
        return fdsc;
    }

    /**
     * Sets the fdsc.
     *
     * @param fdsc the new fdsc
     */
    public void setFdsc(Float fdsc) {
        this.fdsc = fdsc;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AbstractGeneratedCyclesRepresentation [guid=" + guid + ", generatedCode=" + generatedCode + ", cycleCode=" + cycleCode + ", phase="
                + phase + ", speedLimit=" + speedLimit + ", fdsc=" + fdsc + ", totalDistance=" + totalDistance + ", vMax=" + vMax + ", downscaleFlag="
                + downscaleFlag + ", speedLimitFlag=" + speedLimitFlag + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy="
                + updatedBy + ", updatedDate=" + updatedDate + "]";
    }

}
