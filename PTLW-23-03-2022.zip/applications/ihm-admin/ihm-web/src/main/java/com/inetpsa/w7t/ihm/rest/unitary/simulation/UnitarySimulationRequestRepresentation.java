/*
 * Creation : 7 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

/**
 * The Class UnitarySimulationRequestRepresentation.
 */
public class UnitarySimulationRequestRepresentation {

    /** The request. */
    private UnitarySimulationWltpRequest request;

    /**
     * Gets the request.
     *
     * @return the request
     */
    public UnitarySimulationWltpRequest getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(UnitarySimulationWltpRequest request) {
        this.request = request;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UnitarySimulationRequestRepresentation [request=" + request + "]";
    }

}
