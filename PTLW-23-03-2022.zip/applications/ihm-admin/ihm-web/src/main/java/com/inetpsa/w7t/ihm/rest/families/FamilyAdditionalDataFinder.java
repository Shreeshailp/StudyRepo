/*
 * Creation : 13 Jul 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.List;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.validation.IsUUID;

@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyAdditionalDataFinder {
    List<FamilyAdditionalDataRepresentation> getFamilyAdditionalDataByFamilyId(@IsUUID String familyId);
}
