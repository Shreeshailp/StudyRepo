/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.application.services.internal;

import static java.util.stream.Collectors.toList;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.StreamSupport;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.CycleParserService;
import com.inetpsa.w7t.domains.cycles.model.CycleDto;
import com.inetpsa.w7t.domains.cycles.model.CycleProfileDto;
import com.inetpsa.w7t.domains.cycles.shared.CycleErrorCode;
import com.inetpsa.w7t.domains.cycles.shared.CycleValidationException;

/**
 * The Class CycleParserServiceImpl.
 */
public class CycleParserServiceImpl implements CycleParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycle import work book. */
    XSSFWorkbook cycleImportWorkBook;

    /** The cycle import sheet. */
    XSSFSheet cycleImportSheet;

    /** The Constant ZERO. */
    public static final int ZERO = 0;

    /** The Constant ONE. */
    public static final int ONE = 1;

    /** The Constant TWO. */
    public static final int TWO = 2;

    /** The Constant THREE. */
    public static final int THREE = 3;

    /** The Constant FOUR. */
    public static final int FOUR = 4;

    /** The Constant FIVE. */
    public static final int FIVE = 5;

    /** The Constant TWENTY. */
    public static final int TWENTY = 20;

    /** The Constant FIFTY. */
    public static final int FIFTY = 50;

    /** The Constant ROW_TYPE. */
    public static final int ROW_TYPE = 0;

    /** The Constant TIME. */
    public static final int TIME = 1;

    /** The Constant VELOCITY. */
    public static final int VELOCITY = 2;

    /** The Constant DISTANCE. */
    public static final int DISTANCE = 3;

    /** The Constant ACCELERATION. */
    public static final int ACCELERATION = 4;

    /** The Constant MINIMUM_CYCLE_PROFILES. */
    public static final int MINIMUM_CYCLE_PROFILES = 2;

    /** The Data formatter. */
    DataFormatter df = new DataFormatter();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.CycleParserService#parse(java.io.InputStream)
     */
    @Override
    public List<CycleDto> parse(InputStream inputStream) throws IOException {

        List<CycleDto> cycleDtos = new ArrayList<>();

        cycleImportWorkBook = new XSSFWorkbook(inputStream);

        cycleImportSheet = cycleImportWorkBook.getSheetAt(ZERO);

        List<Row> cycleHeaderRows = searchCycleHeaders();
        if (cycleHeaderRows.isEmpty()) {
            throw new CycleValidationException(CycleErrorCode.ONLY_ONE_METADATA_CHECK);
        }
        Row mRow = cycleHeaderRows.get(ZERO);
        CycleDto cycleDto = new CycleDto();

        cycleDto.setCode(df.formatCellValue(mRow.getCell(ONE)));
        cycleDto.setPhase(df.formatCellValue(mRow.getCell(TWO)));
        cycleDto.setComment(df.formatCellValue(mRow.getCell(THREE)));
        cycleDto.setProfiles(getCycleProfiles());

        cycleDtos.add(cycleDto);

        return cycleDtos;

    }

    /**
     * Gets the cycle profiles.
     *
     * @return the cycle profiles
     */
    private List<CycleProfileDto> getCycleProfiles() {

        Function<Cell, Double> throwingGetter = cell -> {
            if (cell.getCellTypeEnum().equals(CellType.NUMERIC))
                return cell.getNumericCellValue();
            throw new CycleValidationException(CycleErrorCode.LINE_D_OUT_OF_FORMAT);
        };

        List<CycleProfileDto> cycleProfilesList = StreamSupport.stream(cycleImportSheet.spliterator(), false)
                .filter(r -> "D".equals(df.formatCellValue(r.getCell(ROW_TYPE)))).map(row -> {
                    CycleProfileDto cpd = new CycleProfileDto();
                    cpd.setTime(throwingGetter.apply(row.getCell(TIME)).intValue());
                    cpd.setVelocity(throwingGetter.apply(row.getCell(VELOCITY)));
                    cpd.setDistance(throwingGetter.apply(row.getCell(DISTANCE)));
                    cpd.setAcceleration(throwingGetter.apply(row.getCell(ACCELERATION)));
                    return cpd;
                }).collect(toList());

        if (cycleProfilesList.size() < MINIMUM_CYCLE_PROFILES)
            throw new CycleValidationException(CycleErrorCode.NOT_ENOUGH_DATA);

        return cycleProfilesList;

    }

    /**
     * Search cycle headers.
     *
     * @return the list
     */
    private List<Row> searchCycleHeaders() {
        Iterator<Row> rowIterator = cycleImportSheet.iterator();
        List<Row> cycleHeaderRows = new ArrayList<>();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            String firstCellValue = df.formatCellValue(row.getCell(ZERO));

            /** RG12 **/
            if (firstCellValue.isEmpty() || firstCellValue.length() != 1 || firstCellValue.contains(" "))
                throw new CycleValidationException(CycleErrorCode.FIRST_COLUMN_EMPTY_CHECK);

            if ("M".equals(firstCellValue)) {
                cycleHeaderRows.add(row);
                /** RG14 **/
                if (cycleHeaderRows.size() != ONE) {
                    throw new CycleValidationException(CycleErrorCode.ONLY_ONE_METADATA_CHECK);
                }
                /** RG15 **/
                if (!headerValidFormat(row)) {
                    throw new CycleValidationException(CycleErrorCode.LINE_M_OUT_OF_FORMAT);
                }

            }

        }

        return cycleHeaderRows;
    }

    /**
     * Header valid format.
     *
     * @param row the row
     * @return true, if header format is valid
     */
    private boolean headerValidFormat(Row row) {
        String code = df.formatCellValue(row.getCell(ONE));
        boolean codeCheck = !(code.isEmpty() || code.length() > TWENTY);

        String phase = df.formatCellValue(row.getCell(TWO));
        boolean phaseCheck = !(phase.isEmpty() || phase.length() > FIVE);

        String comment = df.formatCellValue(row.getCell(THREE));
        boolean commentCheck = comment.length() <= FIFTY;

        return codeCheck && phaseCheck && commentCheck;

    }
}
