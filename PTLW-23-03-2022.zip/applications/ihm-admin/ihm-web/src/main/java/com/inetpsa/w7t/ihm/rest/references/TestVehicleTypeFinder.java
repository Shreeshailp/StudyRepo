/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.domains.references.validation.TestVehicleTypeCode;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.TestVehicleRepresentation;

/**
 * The Interface TestVehicleTypeFinder. This finder is used to retrieve representations of {@link TestVehicleType} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface TestVehicleTypeFinder {

    /**
     * Retrieve the representation of all {@link TestVehicleType} entities.
     *
     * @return a representation of all test vehicle types
     */
    CollectionRepresentation all();

    /**
     * Retrieve a specific {@link TestVehicleType} representation identified by its {@code code} or its UUID entity id.
     *
     * @param testVehicletype the test vehicle type identifier
     * @return an optional test vehicle type representation
     */
    Optional<TestVehicleTypeRepresentation> get(String testVehicletype);

    /**
     * Retrieve a specific {@link TestVehicleType} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return an optional test vehicle type representation
     */
    Optional<TestVehicleTypeRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link TestVehicleType} representation identified by its {@code code}.
     *
     * @param code the code
     * @return an optional test vehicle type representation
     */
    Optional<TestVehicleTypeRepresentation> byCode(@TestVehicleTypeCode String code);

    /**
     * Gets the all test vehicles.
     *
     * @return the all test vehicles
     */
    List<TestVehicleRepresentation> getAllTestVehicles();
}
