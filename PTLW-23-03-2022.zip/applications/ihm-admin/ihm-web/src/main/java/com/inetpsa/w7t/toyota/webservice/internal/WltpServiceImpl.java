/*
 * Creation : 24 août 2017
 */
package com.inetpsa.w7t.toyota.webservice.internal;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Base64;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.inetpsa.w7t.toyota.interfaces.rest.RequestRepresentation;
import com.inetpsa.w7t.toyota.interfaces.rest.WltpResponseRepresentation;
import com.inetpsa.w7t.toyota.webservice.WltpService;

/**
 * The Class BCVServiceImpl.
 */
public class WltpServiceImpl implements WltpService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The url. */
    @Configuration("webService.url")
    private static String url;

    /** The username. */
    @Configuration("webService.credentials.wltp.username")
    private static String username;

    /** The password. */
    @Configuration("webService.credentials.wltp.password")
    private static String code;

    @Configuration("webService.timeout")
    private static int timeout;

    /** The creds bas e64. */
    private String credsBASE64;

    @Override
    public WltpResponseRepresentation getEmissions(RequestRepresentation wsRequestObject) throws Exception {
        if (this.credsBASE64 == null)
            credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());

        HttpClient httpClient = HttpClientBuilder.create().build();

        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
        logger.info("Calling WLTP WebService on URL - {}", url);
        logger.info("Request Sent To Wltp Webservice is:[{}]", wsRequestObject);
        HttpPost postRequest = new HttpPost(url);
        postRequest.setConfig(requestConfig);
        postRequest.addHeader("Content-Type", "application/json");
        postRequest.addHeader("Authorization", "Basic " + credsBASE64);
        postRequest.setEntity(new StringEntity(new Gson().toJson(wsRequestObject)));

        HttpResponse response = httpClient.execute(postRequest);

        BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
        String output;
        StringBuilder answer = new StringBuilder();
        while ((output = br.readLine()) != null) {
            answer.append(output);
        }
        return new Gson().fromJson(answer.toString(), WltpResponseRepresentation.class);
    }

}
