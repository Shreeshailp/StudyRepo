/*
 * Creation : 13 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Class AbstractCycleRepresentation. This class represents the common part between {@link Cycle} and {@link CycleDetails}.
 */
public abstract class AbstractCycleRepresentation extends HalRepresentation {

    /** The guid. */
    protected UUID guid;

    /** The code. */
    protected String code;

    /** The phase. */
    protected String phase;

    /** The comment. */
    protected String comment;

    protected Double cycleMaxVelocity;

    public Double getCycleMaxVelocity() {
        return cycleMaxVelocity;
    }

    public void setCycleMaxVelocity(Double cycleMaxVelocity) {
        this.cycleMaxVelocity = cycleMaxVelocity;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the comment.
     *
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     *
     * @param comment the new comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
}
