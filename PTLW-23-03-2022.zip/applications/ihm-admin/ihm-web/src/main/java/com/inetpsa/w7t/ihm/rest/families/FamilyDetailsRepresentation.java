/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.List;
import java.util.Map;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

/**
 * The Class FamilyDetailsRepresentation. This representation is used to represent a {@link FamilyDetails}.
 */
@DtoOf(FamilyDetails.class)
public class FamilyDetailsRepresentation extends AbstractFamilyRepresentation {

    /** The cycles. */
    private Map<String, String> cycles;

    /** The test vehicles. */
    private List<TestVehicleRepresentation> vehicles;

    /**
     * Gets the cycles.
     *
     * @return the cycles
     */
    public Map<String, String> getCycles() {
        return cycles;
    }

    /**
     * Sets the cycles.
     *
     * @param cycles the new cycles
     */
    public void setCycles(Map<String, String> cycles) {
        this.cycles = cycles;
    }

    /**
     * Gets the test vehicles.
     *
     * @return the test vehicles
     */
    public List<TestVehicleRepresentation> getVehicles() {
        return vehicles;
    }

    /**
     * Sets the test vehicles.
     *
     * @param vehicles the new test vehicles
     */
    public void setVehicles(List<TestVehicleRepresentation> vehicles) {
        this.vehicles = vehicles;
    }
}
