/*
 * Creation : 9 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.VehicleCategory;

/**
 * The Class VehicleCategoryRepresentation. This representation is used to represent a specific {@link VehicleCategory}.
 */
@DtoOf(VehicleCategory.class)
public class VehicleCategoryRepresentation extends ReferenceRepresentation {

}
