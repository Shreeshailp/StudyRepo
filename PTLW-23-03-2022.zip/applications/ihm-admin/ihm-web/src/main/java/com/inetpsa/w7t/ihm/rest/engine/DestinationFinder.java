/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.finders.jpa.DestinationJpaFinder;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface DestinationFinder. Used to fetch Destination and DestinationDetailsRepresentation
 * 
 * @see DestinationJpaFinder
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface DestinationFinder {

    /**
     * All.
     *
     * @param filter the filter
     * @return the destinations representation
     */
    CollectionRepresentation all(DestinationFilter filter);

    /**
     * By id.
     *
     * @param id the id
     * @return the destination representation
     */
    Optional<DestinationDetailsRepresentation> byId(@IsUUID String id);
}
