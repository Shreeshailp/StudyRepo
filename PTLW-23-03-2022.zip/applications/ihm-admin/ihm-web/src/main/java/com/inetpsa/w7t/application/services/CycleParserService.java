/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.cycles.model.CycleDto;

/**
 * The Class CycleParserService.
 */
@Service
@FunctionalInterface
public interface CycleParserService {

    /**
     * Parses the inputstream to a list of CycleDto.
     *
     * @param inputStream the input stream
     * @return the list
     * @throws IOException Signals that an I/O exception has occurred.
     */
    List<CycleDto> parse(InputStream inputStream) throws IOException;
}
