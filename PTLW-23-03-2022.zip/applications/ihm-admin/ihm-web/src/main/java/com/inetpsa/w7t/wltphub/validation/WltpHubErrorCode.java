/*
 * Creation : 29 sept. 2017
 */
package com.inetpsa.w7t.wltphub.validation;

import org.seedstack.shed.exception.ErrorCode;

/**
 * WltpHubError Code
 */
public enum WltpHubErrorCode implements ErrorCode {

    WLTPHUB_TIMEOUT_EXCEPTION(614, "WLTP Hub Timeout exception occured", "ERRT101"),

    FILE_PARSING_EXCEPTION(615, "Error in parsing file", "ERRT102"),

    DUPLICATE_FILE_ID(604, "Duplicate file ID", "ERRT100"),

    UNKNOWN_EXCEPTION(616, "Unknown Technical Exception", "ERRT103"),

    MAX_NUMBER_REQUESTS_EXCEPTION(699, "Maximum number of requests is reached. Please cut your request file.", "ERRT104"),

    FILE_ID_MISSING_EXCEPTION(621, "File ID blank or missing.", "ERRW100"),

    REQUEST_NUMBER_MISSING_EXCEPTION(623, "Request number missing or incorrect.", "ERRW101"),

    VERSION_MISSING_EXCEPTION(624, "Version 16C missing or incorrect", "ERRW601"),

    COLOR_EXT_INT_MISSING_EXCEPTION(625, "Color exterior and interior missing or incorrect", "ERRW602"),

    OPTIONS_MISSING_EXCEPTION(625, "Options7C incorrect", "ERRW605"),

    EXTENSION_DATE_MISSING_EXCEPTION(625, "Incorrect extension date", "ERRW606"),

    REQUEST_TYPE_MISSING_EXCEPTION(626, "unknown request type", "ERRW103"),

    COUNTRY_MISSING_EXCEPTION(627, "Incorrect trading country.", "ERRW610"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new WS request error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    WltpHubErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }

}
