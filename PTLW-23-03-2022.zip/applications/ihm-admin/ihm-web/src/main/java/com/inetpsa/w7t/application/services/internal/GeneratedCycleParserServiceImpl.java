/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services.internal;

import static java.util.stream.Collectors.toList;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.StreamSupport;

import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.GeneratedCycleParserService;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleErrorCode;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleException;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfileDto;

/**
 * The Class GeneratedCycleParserServiceImpl.
 */
public class GeneratedCycleParserServiceImpl implements GeneratedCycleParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycle repo. */
    @Inject
    private CycleRepository cycleRepo;

    /** The cycle import work book. */
    XSSFWorkbook generatedCycleImportWorkBook;

    /** The cycle import sheet. */
    XSSFSheet generatedCycleImportSheet;

    /** The Constant ZERO. */
    public static final int ZERO = 0;

    /** The Constant ONE. */
    public static final int ONE = 1;

    /** The Constant TWO. */
    public static final int TWO = 2;

    /** The Constant THREE. */
    public static final int THREE = 3;

    /** The Constant ROW_TYPE. */
    public static final int ROW_TYPE = 0;

    /** The Constant TIME. */
    public static final int TIME = 1;

    /** The Constant VELOCITY. */
    public static final int VELOCITY = 2;

    /** The Constant DISTANCE. */
    public static final int DISTANCE = 3;

    /** The Constant ACCELERATION. */
    public static final int ACCELERATION = 4;

    /** The Constant MINIMUM_CYCLE_PROFILES. */
    public static final int MINIMUM_CYCLE_PROFILES = 2;

    /** The Constant TWENTY. */
    private static final int TWENTY = 20;

    /** The Constant HIGH_PHASE. */
    private static final String HIGH_PHASE = "HIGH";

    /** The Constant EHIGH_PHASE. */
    private static final String EHIGH_PHASE = "EHIGH";

    /** The Constant COMBO_PHASE. */
    private static final String COMBO_PHASE = "COMB";

    /** The Constant MIX. */
    private static final String MIX = "MIX";

    /** The Constant URB. */
    private static final String URB = "URB";

    /** The Constant EURB. */
    private static final String EURB = "EURB";

    /** The Constant CITY. */
    private static final String CITY = "CITY";

    /** The Constant MID. */
    private static final String MID = "MID";

    /** The Constant LOW. */
    private static final String LOW = "LOW";

    /** The Data formatter. */
    DataFormatter df = new DataFormatter();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.GeneratedCycleParserService#parse(java.io.InputStream)
     */
    @Override
    public List<GeneratedCycleDto> parse(InputStream inputStream) throws IOException {

        List<GeneratedCycleDto> gcDtos = new ArrayList<>();
        generatedCycleImportWorkBook = new XSSFWorkbook(inputStream);
        int sheetCount = generatedCycleImportWorkBook.getActiveSheetIndex();
        generatedCycleImportSheet = generatedCycleImportWorkBook.getSheetAt(ZERO);
        if (sheetCount != 0) {
            throw new GeneratedCycleException(GeneratedCycleErrorCode.FIRST_COLUMN_EMPTY_CHECK);
        }

        List<Row> cycleHeaderRows = searchCycleHeaders();
        if (cycleHeaderRows.isEmpty()) {
            throw new GeneratedCycleException(GeneratedCycleErrorCode.ONLY_ONE_METADATA_CHECK);
        }
        Row mRow = cycleHeaderRows.get(ZERO);
        GeneratedCycleDto genCycleDto = new com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto();

        String cycleCode = df.formatCellValue(mRow.getCell(ONE));
        genCycleDto.setCycleCode(cycleCode);

        Float fdsc = getNonBlankNumericValue(mRow.getCell(TWO));

        // fixed jira 459
        Integer speedLimit = getNonBlankIntegerValue(mRow.getCell(THREE));

        Optional<Cycle> optCycle = cycleRepo.byCode(cycleCode);
        Cycle cycle = null;
        if (optCycle.isPresent())
            cycle = optCycle.get();
        String phase = null;
        if (cycle != null)
            phase = cycle.getPhase();
        genCycleDto.setPhase(phase);
        if (fdsc != null && phase != null && phase.equalsIgnoreCase(HIGH_PHASE)) {
            throw new GeneratedCycleException(GeneratedCycleErrorCode.UNKNOWN_TECHNICAL_EXCEPTION);
        }

        if (fdsc != null && phase != null && (phase.equalsIgnoreCase(LOW) || phase.equalsIgnoreCase(MID) || phase.equalsIgnoreCase(CITY)
                || phase.equalsIgnoreCase(EURB) || phase.equalsIgnoreCase(URB) || phase.equalsIgnoreCase(MIX))) {
            genCycleDto.setFdsc(fdsc);
            genCycleDto.setGeneratedCode(cycleCode + GeneratedCycleConstants.DOWN_SCALE + getFdsc(fdsc));
            genCycleDto.setDownscaleFlag(false);
            genCycleDto.setSpeedLimitFlag(false);
        }

        if (speedLimit != null && phase != null && (phase.equalsIgnoreCase(LOW) || phase.equalsIgnoreCase(MID) || phase.equalsIgnoreCase(CITY)
                || phase.equalsIgnoreCase(EURB) || phase.equalsIgnoreCase(URB) || phase.equalsIgnoreCase(MIX))) {
            String speed = speedLimit + "";
            if (speed.length() < 3) {
                speed = ZERO + speed;
            }
            genCycleDto.setGeneratedCode(cycleCode + GeneratedCycleConstants.SPEED_LIMITING + speed);
            genCycleDto.setSpeedLimitFlag(false);
            genCycleDto.setDownscaleFlag(false);
        }

        if (fdsc != null && (fdsc > 0 && fdsc <= 1) && phase != null
                && (phase.equalsIgnoreCase(EHIGH_PHASE) || phase.equalsIgnoreCase(COMBO_PHASE))) {
            genCycleDto.setFdsc(fdsc);
            genCycleDto.setGeneratedCode(cycleCode + GeneratedCycleConstants.DOWN_SCALE + getFdsc(fdsc));
            genCycleDto.setDownscaleFlag(true);
            genCycleDto.setSpeedLimitFlag(false);

        }

        if ((speedLimit != null) && phase != null
                && (phase.equalsIgnoreCase(EHIGH_PHASE) || phase.equalsIgnoreCase(COMBO_PHASE) || phase.equalsIgnoreCase(HIGH_PHASE))) {
            genCycleDto.setSpeedLimit(speedLimit);
            String speed = speedLimit + "";
            if (speed.length() < 3) {
                speed = ZERO + speed;
            }
            genCycleDto.setGeneratedCode(cycleCode + GeneratedCycleConstants.SPEED_LIMITING + speed);
            genCycleDto.setSpeedLimitFlag(true);
            genCycleDto.setDownscaleFlag(false);

        }
        if (fdsc != null && speedLimit != null && phase != null && (phase.equalsIgnoreCase(EHIGH_PHASE) || phase.equalsIgnoreCase(COMBO_PHASE))) {
            genCycleDto.setFdsc(fdsc);
            genCycleDto.setSpeedLimit(speedLimit);
            genCycleDto.setSpeedLimitFlag(true);
            genCycleDto.setDownscaleFlag(true);

            String speed = speedLimit + "";
            if (speed.length() < 3) {
                speed = ZERO + speed;
            }
            genCycleDto.setGeneratedCode(
                    cycleCode + GeneratedCycleConstants.DOWN_SCALE + getFdsc(fdsc) + GeneratedCycleConstants.SPEED_LIMITING + speed);
        }

        List<GeneratedCycleProfileDto> genCycleProfileList = getCycleProfiles();

        GeneratedCycleProfileDto gcDto = Collections.max(genCycleProfileList, Comparator.comparing(GeneratedCycleProfileDto::getVelocity));
        Double vMax = gcDto.getVelocity();
        String vm = String.valueOf(vMax).trim();
        genCycleDto.setvMax(Float.parseFloat(vm));

        genCycleDto.setProfiles(genCycleProfileList);
        gcDtos.add(genCycleDto);

        return gcDtos;

    }

    private Integer getNonBlankIntegerValue(Cell cell) {
        if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return (int) Math.round(cell.getNumericCellValue());
    }

    /**
     * Gets the fdsc.
     *
     * @param fdsc the fdsc
     * @return the fdsc
     */
    private String getFdsc(Float fdsc) {
        String sFdsc = fdsc + "";
        if (sFdsc.contains(".")) {
            sFdsc = sFdsc.replace(".", "");
        }
        return sFdsc;
    }

    /**
     * Search cycle headers.
     *
     * @return the list
     */
    private List<Row> searchCycleHeaders() {
        Iterator<Row> rowIterator = generatedCycleImportSheet.iterator();
        List<Row> cycleHeaderRows = new ArrayList<>();

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            String firstCellValue = df.formatCellValue(row.getCell(ZERO));

            /** RG12 **/
            if (firstCellValue.isEmpty() || firstCellValue.length() != 1 || firstCellValue.contains(" "))
                throw new GeneratedCycleException(GeneratedCycleErrorCode.FIRST_COLUMN_EMPTY_CHECK);

            if ("M".equals(firstCellValue)) {
                cycleHeaderRows.add(row);

                /** RG14 **/
                if (cycleHeaderRows.size() != ONE) {
                    throw new GeneratedCycleException(GeneratedCycleErrorCode.ONLY_ONE_METADATA_CHECK);
                }
                /** RG15 **/
                if (isHeaderValidFormat(row)) {
                    throw new GeneratedCycleException(GeneratedCycleErrorCode.LINE_M_OUT_OF_FORMAT);
                }

                if (isSpeedLimitAndfDscBlank(row)) {
                    throw new GeneratedCycleException(GeneratedCycleErrorCode.SPEEDLIMIT_FDSC_EMPTY);
                }

                if (!validReferenceCycleCode(row)) {
                    throw new GeneratedCycleException(GeneratedCycleErrorCode.UNKNOWN_REFERENCE_CODE);
                }

            }

        }

        return cycleHeaderRows;
    }

    /**
     * Valid reference cycle code.
     *
     * @param row the row
     * @return true, if successful
     */
    private boolean validReferenceCycleCode(Row row) {
        String cycleReference = df.formatCellValue(row.getCell(ONE));
        java.util.Optional<Cycle> optCycle = cycleRepo.byCode(cycleReference);

        return (optCycle.isPresent());
    }

    /**
     * Checks if is speed limit andf dsc blank.
     *
     * @param row the row
     * @return true, if is speed limit andf dsc blank
     */
    private boolean isSpeedLimitAndfDscBlank(Row row) {
        String fdsc = df.formatCellValue(row.getCell(TWO));
        String speedLimit = df.formatCellValue(row.getCell(THREE));
        if (!((fdsc.isEmpty() || fdsc.contains(" ")) && (speedLimit.isEmpty() || speedLimit.contains(" ")))) {
            return false;
        }

        return true;

    }

    /**
     * Checks if is header valid format.
     *
     * @param row the row
     * @return true, if is header valid format
     */
    private boolean isHeaderValidFormat(Row row) {
        String cycleReference = df.formatCellValue(row.getCell(ONE));

        boolean codeCheck = (cycleReference.isEmpty() || cycleReference.length() > TWENTY);
        String fdsc = df.formatCellValue(row.getCell(TWO));

        String subfd = fdsc.substring(fdsc.indexOf('.') + 1, fdsc.length());
        boolean fDscCheck = (fdsc.isEmpty() || subfd.length() > 3);

        String speedLimit = df.formatCellValue(row.getCell(THREE));

        boolean speedLimitCheck = (speedLimit.isEmpty() || speedLimit.length() > THREE);

        return codeCheck && fDscCheck && speedLimitCheck;

    }

    /**
     * Gets the cycle profiles.
     *
     * @return the cycle profiles
     */
    private List<GeneratedCycleProfileDto> getCycleProfiles() {

        Function<Cell, Double> throwingGetter = cell -> {
            if (cell.getCellTypeEnum().equals(CellType.NUMERIC))
                return cell.getNumericCellValue();
            throw new GeneratedCycleException(GeneratedCycleErrorCode.LINE_D_OUT_OF_FORMAT);
        };

        List<GeneratedCycleProfileDto> cycleProfilesList = StreamSupport.stream(generatedCycleImportSheet.spliterator(), false)

                .filter(r -> "D".equals(df.formatCellValue(r.getCell(ROW_TYPE)))).map(row -> {
                    GeneratedCycleProfileDto cpd = new GeneratedCycleProfileDto();

                    cpd.setTime(throwingGetter.apply(row.getCell(TIME)).intValue());
                    cpd.setVelocity(throwingGetter.apply(row.getCell(VELOCITY)));
                    cpd.setDistance(throwingGetter.apply(row.getCell(DISTANCE)));
                    cpd.setAcceleration(throwingGetter.apply(row.getCell(ACCELERATION)));
                    return cpd;
                }).collect(toList());

        if (cycleProfilesList.size() < MINIMUM_CYCLE_PROFILES)
            throw new GeneratedCycleException(GeneratedCycleErrorCode.NOT_ENOUGH_DATA);
        // validated as per check-marx report
        if (CollectionUtils.isNotEmpty(cycleProfilesList)) {
            for (int i = 0; i < cycleProfilesList.size() - 1; i++) {
                for (int j = 0; j < cycleProfilesList.size() - i - 1; j++) {
                    if (cycleProfilesList.get(j).getTime() == cycleProfilesList.get(j + 1).getTime()) {
                        throw new GeneratedCycleException(GeneratedCycleErrorCode.TIME_VALUE_REPEATED);
                    }
                }

            }
        }

        return cycleProfilesList;

    }

    /**
     * Gets the non blank numeric value.
     *
     * @param cell the cell
     * @return the non blank numeric value
     */
    private Float getNonBlankNumericValue(Cell cell) {
        if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        Double fdsc = cell.getNumericCellValue();
        String fd = String.valueOf(fdsc).trim();
        return Float.parseFloat(fd);
    }

}
