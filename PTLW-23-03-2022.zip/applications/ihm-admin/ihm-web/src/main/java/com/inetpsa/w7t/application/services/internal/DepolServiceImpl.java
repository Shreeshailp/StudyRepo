/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.DepolParserService;
import com.inetpsa.w7t.application.services.DepolService;
import com.inetpsa.w7t.application.services.DepolStatusReportService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.depol.exceptions.DepolErrorCode;
import com.inetpsa.w7t.domains.depol.exceptions.DepolException;
import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.domains.depol.model.DepolDto;
import com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.SpecialFlagRepository;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Class DepolServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class DepolServiceImpl implements DepolService {

    /** The depol parser service. */
    @Inject
    private DepolParserService depolParserService;

    /** The user service. */
    @Inject
    UserService userService;

    /** The depol repository. */
    @Inject
    private DepolRepository depolRepository;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The depol factory. */
    @Inject
    private Factory<Depol> depolFactory;

    /** The special flag repository. */
    @Inject
    SpecialFlagRepository specialFlagRepository;

    /** The depol status report service. */
    @Inject
    DepolStatusReportService depolStatusReportService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.DepolService#upload(java.io.InputStream, java.lang.Boolean, java.lang.String)
     */
    @Override
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate, String fileName) throws IOException, DepolException {

        List<DepolDto> depolDtos = depolParserService.parse(inputStream);
        boolean proceed = isValidDtoList(depolDtos);
        if (proceed) {
            List<DepolDto> dtoList = compareDtoWithDepolTable(depolDtos);
            if (CollectionUtils.isNotEmpty(dtoList)) {
                proceed = isValidDtoList(dtoList);
                if (Boolean.FALSE.equals(proceed)) {
                    depolStatusReportService.saveDepolStatusReport(fileName, dtoList);
                    throw new DepolException(DepolErrorCode.DEPOL_IMPORT_FILE_FUNCTIONAL_ERROR, null);
                }
                if (Boolean.TRUE.equals(proceed)) {
                    depolStatusReportService.saveDepolStatusReport(fileName, depolDtos);
                }
            }
        } else {
            depolStatusReportService.saveDepolStatusReport(fileName, depolDtos);
            throw new DepolException(DepolErrorCode.DEPOL_IMPORT_FILE_FUNCTIONAL_ERROR, null);
        }
        boolean isDepolExists = false;
        int depolCount = 0;
        int depolDeleteCount = 0;

        if (!forceUpdate && proceed) {
            for (DepolDto depolDto : depolDtos) {
                // fixed jira-766
                if (StringUtils.isNoneBlank(depolDto.getStatus())
                        && (depolDto.getStatus().equalsIgnoreCase("S") || depolDto.getStatus().equalsIgnoreCase("M"))) {
                    isDepolExists = checkDepolExistence(depolDto);
                    if (isDepolExists) {
                        depolCount++;
                    }
                    if (StringUtils.isNoneBlank(depolDto.getStatus()) && depolDto.getStatus().equalsIgnoreCase("S")) {
                        depolDeleteCount++;
                    }

                }
            }
            if (depolCount > 0) {
                logger.info("There are total of {} depol records found for modification ", depolCount);
                if (depolDeleteCount > 0) {
                    String[] repeatDepol = { String.valueOf(depolDeleteCount) };
                    throw new DepolException(DepolErrorCode.DEPOL_DELETION_RECORDS, repeatDepol);
                }
                String[] repeatDepol = { String.valueOf(depolCount) };
                throw new DepolException(DepolErrorCode.DEPOL_ALREADY_EXISTS, repeatDepol);
            }
        }
        CollectionRepresentation depolCollection = null;
        if (proceed) {
            List<Depol> depolList = importDepol(depolDtos);
            depolCollection = new CollectionRepresentation(depolList.size(), false);

            depolCollection.self(relRegistry.uri(CatalogRels.IMPORTDEPOL).templated());
            depolCollection.link("find", relRegistry.uri(CatalogRels.IMPORTDEPOL).templated());
            depolCollection.embedded(CatalogRels.IMPORTDEPOL, depolList);
        }
        return depolCollection;
    }

    /**
     * Checks if is valid dto list.
     *
     * @param depolDtos the depol dtos
     * @return true, if is valid dto list
     */
    private boolean isValidDtoList(List<DepolDto> depolDtos) {
        boolean proceed = true;
        for (DepolDto depolDto : depolDtos) {
            if (StringUtils.isNotBlank(depolDto.getStatus()) && !depolDto.getStatus().equalsIgnoreCase("M")
                    && !depolDto.getStatus().equalsIgnoreCase("S")) {
                proceed = false;
                break;
            }
        }
        return proceed;
    }

    /**
     * Import depol.
     *
     * @param depolDtos the depol dtos
     * @return the list
     */
    private List<Depol> importDepol(List<DepolDto> depolDtos) {
        List<Depol> depolList = new ArrayList<>();
        for (DepolDto depolDto : depolDtos) {
            Depol depol = new Depol();
            // fixed jira-766
            if (StringUtils.isBlank(depolDto.getStatus())
                    || !depolRepository.exists(depolDto.getCodeDepol(), depolDto.getSpecialFlag(), depolDto.getCrrMin(), depolDto.getCrrMax())) {
                depol = depolFactory.create();
                mergeAggregateWithDto(depolDto, depol);
                depol = depolRepository.save(depol);
            } else {
                // part of jira-771 fix
                Optional<Depol> optDepol = depolRepository.depolByUniqueFields(depolDto.getCodeDepol(), depolDto.getSpecialFlag(),
                        depolDto.getCrrMin(), depolDto.getCrrMax(), depolDto.getCxMin(), depolDto.getCxMax());
                if (optDepol.isPresent()) {
                    depol = optDepol.get();
                    mergeAggregateWithDto(depolDto, depol);
                    // fixed jira-764 and 765
                    if (StringUtils.isNotBlank(depolDto.getStatus()) && depolDto.getStatus().equalsIgnoreCase("S")) {
                        depolRepository.delete(depol);
                        logger.info("The depol line [{}] has been deleted from database", depol);
                    } else
                        depol = depolRepository.save(depol);
                }
            }
            depolList.add(depol);
            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (depol != null) {
                traceLog.append(" Import DEPOL ").append(depol).toString();
            }
            String trace = traceLog.toString();
            if (StringUtils.isBlank(depolDto.getStatus())
                    || StringUtils.isNotBlank(depolDto.getStatus()) && !depolDto.getStatus().equalsIgnoreCase("S"))
                logger.info(trace);
        }
        return depolList;

    }

    /**
     * Compare dto with depol table.
     *
     * @param depolDtos the depol dtos
     * @return the list
     */
    private List<DepolDto> compareDtoWithDepolTable(List<DepolDto> depolDtos) {
        List<DepolDto> dtoList = new ArrayList<>();
        for (DepolDto dto : depolDtos) {
            List<Depol> listDepol = depolRepository.getAllDepolsByUniqueFields(dto.getCodeDepol(), dto.getSpecialFlag(), dto.getCrrMin(),
                    dto.getCrrMax());
            if (!listDepol.isEmpty()) {
                for (Depol depol : listDepol) {
                    if (dto.getStatus() == null && depol.getCxMin() != null && depol.getCxMax() != null
                            && Float.compare(depol.getCxMin(), depol.getCxMax()) == 0) {
                        dto.setStatus(DepolErrorCode.CX_MIN_CX_MAX_EQUAL.getDescription());
                    }
                    if (dto.getStatus() == null && depol.getCxMin() != null && depol.getCxMax() != null
                            && dto.getCodeDepol().equalsIgnoreCase(depol.getCodeDepol())
                            && dto.getSpecialFlag().equalsIgnoreCase(depol.getSpecialFlag())
                            && dto.getCrrMin().toString().equalsIgnoreCase(depol.getCrrMin().toString())
                            && dto.getCrrMax().toString().equalsIgnoreCase(depol.getCrrMax().toString())
                            && dto.getCxMin().toString().equalsIgnoreCase(depol.getCxMin().toString())
                            && dto.getCxMax().toString().equalsIgnoreCase(depol.getCxMax().toString())) {
                        String[] repeatDepol = { depol.getCodeDepol(), depol.getSpecialFlag(), depol.getCrrMin().toString(),
                                depol.getCrrMax().toString(), depol.getCxMin().toString(), depol.getCxMax().toString() };
                        DepolException e = new DepolException(DepolErrorCode.DEPOL_ENTRY_PRESENT_IN_SHEET, repeatDepol);
                        dto.setStatus(e.getContextMesage());
                    } else if (dto.getStatus() == null && dto.getCodeDepol().equalsIgnoreCase(depol.getCodeDepol())
                            && dto.getSpecialFlag().equalsIgnoreCase(depol.getSpecialFlag())
                            && dto.getCrrMin().toString().equalsIgnoreCase(depol.getCrrMin().toString())
                            && dto.getCrrMax().toString().equalsIgnoreCase(depol.getCrrMax().toString())) {
                        if (dto.getStatus() == null && depol.getCxMin() != null && depol.getCxMax() != null
                                && Float.compare(depol.getCxMin(), dto.getCxMax()) != 0
                                && ((dto.getCxMin() >= depol.getCxMin() && dto.getCxMin() <= depol.getCxMax())
                                        || (dto.getCxMax() >= depol.getCxMin() && dto.getCxMax() <= depol.getCxMax()))) {
                            dto.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT_IN_ANOTHER_LINE.getDescription());
                        } else {
                            if (dto.getStatus() == null && depol.getCxMin() != null && depol.getCxMax() != null
                                    && Float.compare(depol.getCxMin(), dto.getCxMin()) == 0
                                    && Float.compare(depol.getCxMin(), Float.valueOf(CalculationConstants.CX_MIN_LIMIT)) == 0
                                    && Float.compare(dto.getCxMin(), Float.valueOf(CalculationConstants.CX_MIN_LIMIT)) == 0
                                    && Float.compare(depol.getCxMax(), Float.valueOf(CalculationConstants.CX_MAX_LIMIT)) == 0
                                    && Float.compare(dto.getCxMax(), Float.valueOf(CalculationConstants.CX_MAX_LIMIT)) == -1) {
                                dto.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT.getDescription());
                            }
                            // JIRA-771 fix by below lines
                            Depol depolMin = Collections.min(listDepol, Comparator.comparing(Depol::getCxMin));
                            Depol depolMax = Collections.max(listDepol, Comparator.comparing(Depol::getCxMax));
                            if (dto.getStatus() == null && dto.getCxMin() < depolMin.getCxMin() && dto.getCxMax() > depolMax.getCxMax()) {
                                dto.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT_IN_ANOTHER_LINE.getDescription());
                            }
                        }
                    }
                }
            }
            dtoList.add(dto);
        }
        return dtoList;
    }

    /**
     * Merge aggregate with dto.
     *
     * @param depolDto the depol dto
     * @param depol    the depol
     * @return the depol
     */
    private Depol mergeAggregateWithDto(DepolDto depolDto, Depol depol) {
        depol.setDesignation(depolDto.getDesignation());
        depol.setMroMin(depolDto.getMroMin());
        depol.setMroMax(depolDto.getMroMax());
        depol.setFrontalAreaMin(depolDto.getFrontalAreaMin());
        depol.setFrontalAreaMax(depolDto.getFrontalAreaMax());
        depol.setCoolingSurfaceMin(depolDto.getCoolingSurfaceMin());
        depol.setCoolingSurfaceMax(depolDto.getCoolingSurfaceMax());
        // fixed jira-771
        if (depolDto.getStatus() == null || !depolDto.getStatus().equalsIgnoreCase("M")) {
            depol.setCodeDepol(depolDto.getCodeDepol());
            if (depolDto.getSpecialFlag() != null) {
                checkValidSpecialFlagExists(depolDto.getSpecialFlag());
                depol.setSpecialFlag(depolDto.getSpecialFlag());
            }
            depol.setCrrMin(depolDto.getCrrMin());
            depol.setCrrMax(depolDto.getCrrMax());
            depol.setCxMin(depolDto.getCxMin());
            depol.setCxMax(depolDto.getCxMax());
        }
        return depol;

    }

    /**
     * Check depol existence.
     *
     * @param depol the depol
     * @return the boolean
     */
    private Boolean checkDepolExistence(DepolDto depol) {
        return depolRepository.exists(depol.getCodeDepol(), depol.getSpecialFlag(), depol.getCrrMin(), depol.getCrrMax());

    }

    /**
     * Check valid special flag exists.
     *
     * @param specialFlagCode the special flag code
     * @return true, if successful
     */
    private boolean checkValidSpecialFlagExists(String specialFlagCode) {
        if (!specialFlagRepository.exists(specialFlagCode)) {
            throw new DepolException(DepolErrorCode.INVALID_SPECIAL_FLAG, null);
        }
        return true;
    }

}
