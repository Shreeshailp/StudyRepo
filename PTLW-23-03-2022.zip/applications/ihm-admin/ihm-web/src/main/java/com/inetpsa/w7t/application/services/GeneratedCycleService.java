/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface GeneratedCycleService.
 */
@Service
public interface GeneratedCycleService {

    /**
     * Upload.
     *
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @return the collection representation
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException;

    /**
     * This method handles the insertion or updation of the generated cycle data in the database.
     *
     * @param genCycles the generated cycles
     * @param forceUpdate the force update
     * @return the list
     */
    List<GeneratedCycle> importCycles(List<GeneratedCycleDto> genCycles, Boolean forceUpdate);
}
