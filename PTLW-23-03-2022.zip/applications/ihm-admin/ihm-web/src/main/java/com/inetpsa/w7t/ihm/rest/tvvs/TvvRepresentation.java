/*
 * Creation : 17 May 2018
 */
package com.inetpsa.w7t.ihm.rest.tvvs;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

/**
 * The Class TvvRepresentation. This representation is used to represent a {@link TVV}.
 */
@DtoOf(TVV.class)
public class TvvRepresentation extends AbstractTvvRepresentation {

}
