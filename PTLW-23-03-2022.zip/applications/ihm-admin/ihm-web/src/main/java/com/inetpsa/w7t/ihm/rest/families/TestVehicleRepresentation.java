/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;
import com.inetpsa.w7t.domains.families.model.details.TestVehicleDetails;

/**
 * The Class TestVehicleRepresentation. This representation is used to represent a {@link TestVehicle} of a specific {@link FamilyDetails}.
 */
@DtoOf(TestVehicleDetails.class)
public class TestVehicleRepresentation extends HalRepresentation {

    /** The guid. */
    private String guid;
    /** The test vehicle type. */
    private String type;

    private String familyId;

    /** The physical quantities. */
    private List<PhysicalQuantityValueRepresentation> quantities;

    /** The measures. */
    private List<MeasureValueRepresentation> measures;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public String getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * Gets the test vehicle type.
     *
     * @return the test vehicle type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the test vehicle type.
     *
     * @param type the new test vehicle type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<PhysicalQuantityValueRepresentation> getQuantities() {
        return quantities;
    }

    /**
     * Sets the physical quantities.
     *
     * @param quantities the new physical quantities
     */
    public void setQuantities(List<PhysicalQuantityValueRepresentation> quantities) {
        this.quantities = quantities;
    }

    /**
     * Gets the measures.
     *
     * @return the measures
     */
    public List<MeasureValueRepresentation> getMeasures() {
        return measures;
    }

    /**
     * Sets the measures.
     *
     * @param measures the new measures
     */
    public void setMeasures(List<MeasureValueRepresentation> measures) {
        this.measures = measures;
    }

    public String getFamilyId() {
        return familyId;
    }

    public void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

}
