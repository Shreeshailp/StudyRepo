/*
 * Creation : 16 May 2018
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.tvvs.TvvFilter;
import com.inetpsa.w7t.ihm.rest.tvvs.TvvFinder;
import com.inetpsa.w7t.ihm.rest.tvvs.TvvRepresentation;

public class TvvJpaFinder implements TvvFinder {

    /** The Constant VEHICLE_FAMILY. */
    private static final String VEHICLE_FAMILY = "vehicleFamily";

    /** The Constant T1AVALUE. */
    private static final String T1AVALUE = "t1AValue";

    /** The Constant T1BVALUE. */
    private static final String T1BVALUE = "t1BValue";

    /** The Constant TVV_DESIGNATION. */
    private static final String TVV_DESIGNATION = "tvvDesignation";

    /** The Constant VEHICLE_CATEGORY. */
    private static final String VEHICLE_CATEGORY = "tvvVehicleCategory";

    private static final String TVV_COMPLETE_FLAG = "tvvCompleteFlag";

    private static final String TVV_CODE_DEPOL = "tvvCodeDepol";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    @Configuration("tvvsearch.limit")
    Integer limit;

    @SuppressWarnings("unchecked")
    @Override
    public CollectionRepresentation all() {
        String sqlQuery = "select *from W7TQTTVV order by VEHICLE_FAMILY,T1A_VALUE,T1B_VALUE";

        Query query = entityManager.createNativeQuery(sqlQuery, TVV.class);
        query.setMaxResults(limit + 1);

        List<TVV> list = query.getResultList();

        List<TvvRepresentation> tvvList = fluentAssembler.assemble(list).with(WltpModelMapper.class).to(TvvRepresentation.class);

        CollectionRepresentation tvvs = new CollectionRepresentation(tvvList.size(), false);
        tvvs.self(relRegistry.uri(CatalogRels.IMPORTTVV));
        tvvs.embedded(CatalogRels.IMPORTTVV, tvvList);

        return tvvs;
    }

    @Override
    public CollectionRepresentation filter(TvvFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TVV> criteriaQuery = cb.createQuery(TVV.class);
        Root<TVV> root = criteriaQuery.from(TVV.class);

        Optional<String> vehicleFamily = Optional.ofNullable(filter.vehicleFamily).filter(s -> !s.isEmpty());
        Optional<String> t1AValue = Optional.ofNullable(filter.t1AValue).filter(s -> !s.isEmpty());
        Optional<String> t1BValue = Optional.ofNullable(filter.t1BValue).filter(s -> !s.isEmpty());
        Optional<String> tvvDesignation = Optional.ofNullable(filter.tvvDesignation).filter(s -> !s.isEmpty());
        Optional<String> vehicleCategory = Optional.ofNullable(filter.tvvVehicleCategory).filter(s -> !s.isEmpty());
        Optional<String> tvvCompleteFlag = Optional.ofNullable(filter.completeFlag).filter(s -> !s.isEmpty());
        Optional<String> tvvCodeDepol = Optional.ofNullable(filter.tvvCodeDepol).filter(s -> !s.isEmpty());

        List<Predicate> filters = new ArrayList<>();
        vehicleFamily.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(VEHICLE_FAMILY)), cb.parameter(String.class, VEHICLE_FAMILY))));
        t1AValue.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(T1AVALUE)), cb.parameter(String.class, T1AVALUE))));
        t1BValue.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(T1BVALUE)), cb.parameter(String.class, T1BVALUE))));
        tvvDesignation.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(TVV_DESIGNATION)), cb.parameter(String.class, TVV_DESIGNATION))));
        vehicleCategory.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(VEHICLE_CATEGORY)), cb.parameter(String.class, VEHICLE_CATEGORY))));
        tvvCompleteFlag.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(TVV_COMPLETE_FLAG)), cb.parameter(String.class, TVV_COMPLETE_FLAG))));
        tvvCodeDepol.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(TVV_CODE_DEPOL)), cb.parameter(String.class, TVV_CODE_DEPOL))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<TVV> query = entityManager.createQuery(criteriaQuery);
        vehicleFamily.ifPresent(c -> query.setParameter(VEHICLE_FAMILY, '%' + c.toLowerCase() + '%'));
        t1AValue.ifPresent(c -> query.setParameter(T1AVALUE, '%' + c.toLowerCase() + '%'));
        t1BValue.ifPresent(c -> query.setParameter(T1BVALUE, '%' + c.toLowerCase() + '%'));
        tvvDesignation.ifPresent(c -> query.setParameter(TVV_DESIGNATION, '%' + c.toLowerCase() + '%'));
        vehicleCategory.ifPresent(c -> query.setParameter(VEHICLE_CATEGORY, '%' + c.toLowerCase() + '%'));
        tvvCompleteFlag.ifPresent(c -> query.setParameter(TVV_COMPLETE_FLAG, '%' + c.toLowerCase() + '%'));
        tvvCodeDepol.ifPresent(c -> query.setParameter(TVV_CODE_DEPOL, '%' + c.toLowerCase() + '%'));

        List<TvvRepresentation> tvvList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class).to(TvvRepresentation.class);

        CollectionRepresentation tvvs = new CollectionRepresentation(tvvList.size(), false);
        tvvs.self(relRegistry.uri(CatalogRels.TVVSEARCH));
        tvvs.embedded(CatalogRels.TVVSEARCH, tvvList);
        return tvvs;

    }

    @Override
    public List<TVV> allTVVs() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<TVV> criteriaQuery = criteriaBuilder.createQuery(TVV.class);
        Root<TVV> root = criteriaQuery.from(TVV.class);
        criteriaQuery.select(root);
        criteriaQuery.orderBy(criteriaBuilder.asc(root.get(VEHICLE_FAMILY)), criteriaBuilder.asc(root.get(T1AVALUE)),
                criteriaBuilder.asc(root.get(T1BVALUE)));

        TypedQuery<TVV> query = entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }
}
