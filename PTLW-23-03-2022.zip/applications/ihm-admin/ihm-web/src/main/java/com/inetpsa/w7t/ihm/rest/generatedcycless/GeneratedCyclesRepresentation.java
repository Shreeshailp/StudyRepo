/*
 * Creation : 17 May 2018
 */
package com.inetpsa.w7t.ihm.rest.generatedcycless;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;

/**
 * The Class GeneratedCyclesRepresentation.
 */
@DtoOf(GeneratedCycle.class)
public class GeneratedCyclesRepresentation extends AbstractGeneratedCyclesRepresentation {

}
