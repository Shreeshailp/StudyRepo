/*
 * Creation : 6 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface CyclePhaseFinder. This finder is used to retrieve representations of {@link CyclePhase} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface CyclePhaseFinder {

    /**
     * Retrieve a specific {@link CyclePhase} representation identified by its {@code code} or its UUID entity id.
     *
     * @param cyclePhase the cycle phase identifier
     * @return the cycle phase representation
     */
    Optional<CyclePhaseRepresentation> get(String cyclePhase);

    /**
     * Retrieve a specific {@link CyclePhase} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return the cycle phase representation
     */
    Optional<CyclePhaseRepresentation> byId(@IsUUID String id);

    /**
     * Retrieve a specific {@link CyclePhase} representation identified by its {@code code}.
     *
     * @param code the code
     * @return the cycle phase representation
     */
    Optional<CyclePhaseRepresentation> byCode(String code);

    /**
     * Retrieve the representation of all {@link CyclePhase} entities.
     *
     * @return a representation of all cycle phases
     */
    CollectionRepresentation all();
}
