/*
 * Creation : 3 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.Validation;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.references.model.VehicleType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.VehicleTypeRepresentation;

/**
 * The Class VehicleTypeJpaFinder. This is the JPA Implementation of the {@link VehicleTypeFinder}.
 */
public class VehicleTypeJpaFinder implements VehicleTypeFinder {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder#all()
     */
    @Override
    public CollectionRepresentation all() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> q = cb.createQuery(VehicleType.class);
        Root<VehicleType> root = q.from(VehicleType.class);

        TypedQuery<VehicleType> query = entityManager.createQuery(q.select(root));

        List<VehicleTypeRepresentation> vehicleTypesList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(VehicleTypeRepresentation.class);

        vehicleTypesList.stream().forEach(vehicleType -> {
            vehicleType.setLabel(labelService.value(vehicleType.getGuid()));
            vehicleType.self(relRegistry.uri(CatalogRels.VEHICLE_TYPE).set(CatalogRels.VEHICLE_TYPE, vehicleType.getGuid()));
        });

        CollectionRepresentation vehicleTypes = new CollectionRepresentation(vehicleTypesList.size(), false);

        vehicleTypes.self(relRegistry.uri(CatalogRels.VEHICLE_TYPES).templated());
        vehicleTypes.link("find", relRegistry.uri(CatalogRels.VEHICLE_TYPE).templated());
        vehicleTypes.embedded(CatalogRels.VEHICLE_TYPES, vehicleTypesList);

        return vehicleTypes;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder#get(java.lang.String)
     */
    @Override
    public Optional<VehicleTypeRepresentation> get(String vehicletype) {
        if (Validation.buildDefaultValidatorFactory().getValidator().validateValue(VehicleType.class, CODE, vehicletype).isEmpty())
            return byCode(vehicletype);
        return byId(vehicletype);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder#byCode(java.lang.String)
     */
    @Override
    public Optional<VehicleTypeRepresentation> byCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> q = cb.createQuery(VehicleType.class);
        Root<VehicleType> c = q.from(VehicleType.class);
        q.where(cb.equal(cb.lower(c.get(CODE)), cb.lower(cb.parameter(String.class, CODE))));

        TypedQuery<VehicleType> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        List<VehicleType> list = query.getResultList();
        Optional<VehicleType> vehicleTypeObj = Optional.empty();
        if (!list.isEmpty()) {
            vehicleTypeObj = list.stream().findFirst();
        }

        Optional<VehicleTypeRepresentation> vehicleType = vehicleTypeObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(VehicleTypeRepresentation.class));

        vehicleType.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.VEHICLE_TYPE).set(CatalogRels.VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.VEHICLE_TYPES).templated());
        });

        return vehicleType;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder#byId(java.lang.String)
     */
    @Override
    public Optional<VehicleTypeRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> q = cb.createQuery(VehicleType.class);
        Root<VehicleType> c = q.from(VehicleType.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<VehicleType> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        List<VehicleType> list = query.getResultList();
        Optional<VehicleType> vehicleTypeObj = Optional.empty();
        if (!list.isEmpty()) {
            vehicleTypeObj = list.stream().findFirst();
        }

        Optional<VehicleTypeRepresentation> vehicleType = vehicleTypeObj
                .map(type -> fluentAssembler.assemble(type).with(WltpModelMapper.class).to(VehicleTypeRepresentation.class));

        vehicleType.ifPresent(type -> {
            type.setLabel(labelService.value(type.getGuid()));
            type.self(new Link(relRegistry.uri(CatalogRels.VEHICLE_TYPE).set(CatalogRels.VEHICLE_TYPE, type.getGuid())));
            type.link("find", relRegistry.uri(CatalogRels.VEHICLE_TYPES).templated());
        });

        return vehicleType;
    }

}
