/*
 * Creation : 13 Jul 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;

public class FamilyAdditionalDataJpaFinder implements FamilyAdditionalDataFinder {
    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    @SuppressWarnings("unchecked")
    @Override
    public List<FamilyAdditionalDataRepresentation> getFamilyAdditionalDataByFamilyId(@IsUUID String familyId) {
        String sqlQuery = "SELECT *FROM W7TQTFAD WHERE FAM_ID=?";

        Query query = entityManager.createNativeQuery(sqlQuery, FamilyAdditionalData.class);
        query.setParameter(1, familyId);

        List<FamilyAdditionalData> list = query.getResultList();

        return fluentAssembler.assemble(list).with(WltpModelMapper.class).to(FamilyAdditionalDataRepresentation.class);

    }

}
