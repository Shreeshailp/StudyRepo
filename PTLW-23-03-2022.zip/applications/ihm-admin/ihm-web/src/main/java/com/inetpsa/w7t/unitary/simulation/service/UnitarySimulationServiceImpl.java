/*
 * Creation : 7 Aug 2020
 */
package com.inetpsa.w7t.unitary.simulation.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.sql.rowset.serial.SerialBlob;
import javax.ws.rs.NotFoundException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.inetpsa.w7t.domains.references.model.CollectionEntity;
import com.inetpsa.w7t.domains.references.model.CollectionRequestEntity;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationErrorCode;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationException;
import com.inetpsa.w7t.domains.unitary.simulation.repository.CollectionRepository;
import com.inetpsa.w7t.domains.unitary.simulation.repository.CollectionRequestRepository;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.CollectionDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.CollectionRequestDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionRequestDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationRequestRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationResponseRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubRequestRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubResponseRepresentation;

/**
 * The Class UnitarySimulationServiceImpl.
 */
public class UnitarySimulationServiceImpl implements UnitarySimulationService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The url. */
    @Configuration("webService.url")
    private static String url;

    /** The username. */
    @Configuration("webService.credentials.wltp.username")
    private static String username;

    /** The password. */
    @Configuration("webService.credentials.wltp.password")
    private static String code;

    /** The timeout. */
    @Configuration("webService.timeout")
    private static int timeout;

    /** The WLTPHUB url. */
    @Configuration("wltphubWebService.url")
    private static String wltphubUrl;

    /** The WLTPHUB username. */
    @Configuration("wltphubWebService.credentials.wltphub.username")
    private static String wltphubUsername;

    /** The WLTPHUB password. */
    @Configuration("wltphubWebService.credentials.wltphub.password")
    private static String wltphubCode;

    /** The WLTPHUB timeout. */
    @Configuration("wltphubWebService.timeout")
    private static int wltphubTimeout;

    /** The creds BASE 64. */
    private String credsBASE64;

    /** The collection repository. */
    @Inject
    private CollectionRepository collectionRepository;

    /** The collection request repository. */
    @Inject
    private CollectionRequestRepository collectionRequestRepository;

    /** The collection entity factory. */
    @Inject
    private Factory<CollectionEntity> collectionEntityFactory;

    /** The collection request entity factory. */
    @Inject
    private Factory<CollectionRequestEntity> collectionRequestEntityFactory;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#callWltpWebService(com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationRequestRepresentation)
     */
    @Override
    public UnitarySimulationResponseRepresentation callWltpWebService(UnitarySimulationRequestRepresentation unitarySimulationRequestRepresentation)
            throws Exception {

        if (this.credsBASE64 == null)
            credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());

        HttpClient httpClient = HttpClientBuilder.create().build();

        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
        logger.info("Calling WLTP WebService on URL - {}", url);
        logger.info("Request Sent To Wltp Webservice is:[{}]", unitarySimulationRequestRepresentation);
        HttpPost postRequest = new HttpPost(url);
        postRequest.setConfig(requestConfig);
        postRequest.addHeader("Content-Type", "application/json");
        postRequest.addHeader("Authorization", "Basic " + credsBASE64);
        postRequest.setEntity(new StringEntity(new Gson().toJson(unitarySimulationRequestRepresentation)));

        HttpResponse response = httpClient.execute(postRequest);

        BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
        String output;
        StringBuilder answer = new StringBuilder();
        while ((output = br.readLine()) != null) {
            answer.append(output);
        }
        return new Gson().fromJson(answer.toString(), UnitarySimulationResponseRepresentation.class);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#callWltphubWebService(com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubRequestRepresentation)
     */
    @Override
    public UnitarySimulationWltpHubResponseRepresentation callWltphubWebService(UnitarySimulationWltpHubRequestRepresentation requestRepresentation)
            throws Exception {
        if (this.credsBASE64 == null)
            credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", wltphubUsername, wltphubCode).getBytes());

        HttpClient httpClient = HttpClientBuilder.create().build();

        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(wltphubTimeout).build();
        logger.info("Calling WLTPHUB WebService on URL - {}", wltphubUrl);
        logger.info("Request Sent To WltpHub is:[{}]", requestRepresentation);
        HttpPost postRequest = new HttpPost(wltphubUrl);
        postRequest.setConfig(requestConfig);
        postRequest.addHeader("Content-Type", "application/json");
        postRequest.addHeader("Authorization", "Basic " + credsBASE64);
        postRequest.setEntity(new StringEntity(new Gson().toJson(requestRepresentation)));

        HttpResponse response = httpClient.execute(postRequest);
        int statusCode = 0;
        if (response != null) {
            logger.info("WLTPHUB HTTP Response code :[{}] and Reason:[{}]", response.getStatusLine().getStatusCode(),
                    response.getStatusLine().getReasonPhrase());
            statusCode = response.getStatusLine().getStatusCode();
        }
        if (response.getStatusLine().getStatusCode() == 503) {
            throw new UnitarySimulationException(UnitarySimulationErrorCode.SERVICE_UNAVAILABLE_ERROR, null);
        } else if (statusCode != 200 && statusCode != 400 && statusCode != 429) {
            throw new UnitarySimulationException(UnitarySimulationErrorCode.UNKNOWN_TECHNICAL_EXCEPTION, null);
        }

        BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
        String output;
        StringBuilder answer = new StringBuilder();
        while ((output = br.readLine()) != null) {
            answer.append(output);
        }
        return new Gson().fromJson(answer.toString(), UnitarySimulationWltpHubResponseRepresentation.class);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#createCollection(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public CollectionEntity createCollection(String collectionName, String userId, String type) {
        CollectionEntity newCollection = collectionEntityFactory.create();
        newCollection.setCollectionName(collectionName);
        newCollection.setUserId(userId);
        newCollection.setType(type);
        return collectionRepository.save(newCollection);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#updateCollection(java.lang.String, java.lang.String)
     */
    @Override
    public void updateCollection(String collectionName, String collectionId) {
        CollectionEntity updateCollection = null;

        try {
            updateCollection = collectionRepository.load(UUID.fromString(collectionId));
            if (updateCollection == null) {
                throw new NotFoundException("Collection with ID + " + collectionId + " Not Found");
            } else if (collectionId != null && collectionName != null && !collectionName.equals(updateCollection.getCollectionName())) {
                updateCollection.setCollectionName(collectionName);
                collectionRepository.save(updateCollection);
            }
        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#deleteCollection(java.lang.String)
     */
    @Override
    public void deleteCollection(String collectionId) {
        CollectionEntity deleteCollection = null;
        try {
            deleteCollection = collectionRepository.load(UUID.fromString(collectionId));
            if (deleteCollection == null) {
                throw new NotFoundException("Collection with ID + " + collectionId + " Not Found");
            }
        } catch (Exception e) {
            throw e;
        }
        collectionRepository.delete(UUID.fromString(collectionId));

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#deleteRequest(java.lang.String)
     */
    @Override
    public void deleteRequest(String requestId) {
        CollectionRequestEntity deleteRequest = null;
        try {
            deleteRequest = collectionRequestRepository.load(UUID.fromString(requestId));
            if (deleteRequest == null) {
                throw new NotFoundException("Request with ID + " + requestId + " Not Found");
            }
        } catch (Exception e) {
            throw e;
        }
        collectionRequestRepository.delete(UUID.fromString(requestId));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#saveOrUpdateRequestToCollection(java.lang.String, java.lang.String,
     *      java.lang.String, com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationRequestRepresentation)
     */
    @Override
    public CollectionRequestDto saveOrUpdateRequestToCollection(String collectionId, String requestId, String requestName,
            UnitarySimulationRequestRepresentation requestRepresentation) {
        CollectionEntity collection = null;
        CollectionRequestDto requestDto = null;
        try {
            collection = collectionRepository.load(UUID.fromString(collectionId));
            if (collection == null) {
                throw new NotFoundException("Collection with ID + " + collectionId + " Not Found");
            }
        } catch (Exception e) {
            throw e;
        }
        if (requestId == null || requestId.isEmpty()) {
            CollectionRequestEntity requestEntity = collectionRequestEntityFactory.create();
            requestEntity.setRequestName(requestName);
            Blob requestBlob = getBlob(new Gson().toJson(requestRepresentation));
            requestEntity.setRequestBlob(requestBlob);
            collection.addRequest(requestEntity);
            collectionRepository.save(collection);
            requestDto = new CollectionRequestDto();
            requestDto.setCollectionRequestId(requestEntity.getCollectionRequestId().toString());
            requestDto.setRequestName(requestName);
            requestDto.setRequest(requestRepresentation);
            return requestDto;
        }
        CollectionRequestEntity requestEntity = collectionRequestRepository.load(UUID.fromString(requestId));
        if (requestName != null && !requestName.isEmpty() && !requestName.equalsIgnoreCase(requestEntity.getRequestName())) {
            requestEntity.setRequestName(requestName);
        }
        Blob requestBlob = getBlob(new Gson().toJson(requestRepresentation));
        requestEntity.setRequestBlob(requestBlob);
        collection.addRequest(requestEntity);
        collectionRequestRepository.updateCollectionRequest(requestEntity);
        return null;

    }

    /**
     * Gets the blob.
     *
     * @param object the object
     * @return the blob
     */
    private Blob getBlob(Object object) {
        String json = "{}";
        Blob blobRequest = null;
        try {
            if (object != null) {
                json = new ObjectMapper().writeValueAsString(object);
                blobRequest = new SerialBlob(json.getBytes());
            }
        } catch (Exception e) {
            logger.error("Error while converting Json object to blob {}", e);
        }
        return blobRequest;
    }

    /**
     * Handle blob.
     *
     * @param blob the blob
     * @return the byte[]
     * @throws SQLException the SQL exception
     */
    private byte[] handleBlob(Blob blob) throws SQLException {
        byte[] emptyArray = new byte[0];
        if (blob == null)
            return emptyArray;

        InputStream is = null;
        try {
            is = blob.getBinaryStream();
            if (is == null)
                return emptyArray;
            byte[] data = new byte[(int) blob.length()];
            if (data.length == 0)
                return emptyArray;
            is.read(data);
            return data;
        } catch (IOException e) {
            logger.error("{}", e);
            return emptyArray;
        } finally {
            if (is != null)
                try {
                    is.close();
                } catch (IOException e) {
                    logger.error("{}", e);
                }
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#getAllCollections(java.lang.String, java.lang.String)
     */
    @Override
    public List<CollectionDto> getAllCollections(String userId, String type) {
        List<CollectionEntity> collectionList = collectionRepository.getAllCollections(userId, type);
        List<CollectionRequestEntity> collectionRequests = null;
        CollectionRequestDto requestDto = null;
        CollectionDto collectionDto = null;
        List<CollectionDto> collections = new ArrayList<>();
        UnitarySimulationRequestRepresentation requestRepresentation = null;
        byte[] collectionReqByteArray = null;
        for (CollectionEntity collectionEntity : collectionList) {
            collectionRequests = collectionEntity.getCollectionRequests();
            collectionDto = new CollectionDto();
            collectionDto.setCollectionId(collectionEntity.getCollectionId().toString());
            collectionDto.setCollectionName(collectionEntity.getCollectionName());
            collectionDto.setUserId(collectionEntity.getUserId());
            for (CollectionRequestEntity collectionRequestEntity : collectionRequests) {
                try {
                    requestDto = new CollectionRequestDto();
                    collectionReqByteArray = handleBlob(collectionRequestEntity.getRequestBlob());
                    String jsonStr = convertBytestoString(collectionReqByteArray);
                    requestRepresentation = convertToResponseObject(jsonStr);
                    requestDto.setCollectionRequestId(collectionRequestEntity.getCollectionRequestId().toString());
                    requestDto.setRequestName(collectionRequestEntity.getRequestName());
                    requestDto.setRequest(requestRepresentation);
                    collectionDto.addRequests(requestDto);
                } catch (SQLException e) {
                    logger.error("{}", e);
                }
            }
            collections.add(collectionDto);
        }
        return collections;
    }

    /**
     * Convert bytesto string.
     *
     * @param collectionReqByteArray the collection req byte array
     * @return the string
     */
    private String convertBytestoString(byte[] collectionReqByteArray) {
        String byteArrayString = null;
        if (collectionReqByteArray != null) {
            byteArrayString = new String(collectionReqByteArray, StandardCharsets.UTF_8);
        }
        return byteArrayString;
    }

    /**
     * Convert to response object.
     *
     * @param jsonStr the json str
     * @return the unitary simulation request representation
     */
    private UnitarySimulationRequestRepresentation convertToResponseObject(String jsonStr) {
        UnitarySimulationRequestRepresentation requestRepresentation = null;
        String json = "{}";
        if (jsonStr != null) {

            try {

                json = jsonStr.substring(1, jsonStr.length() - 1);

                json = json.replaceAll("\\\\\"", "\"");

            } catch (Exception e) {
                logger.error("Error while converting Json string {}", e);
            }

            requestRepresentation = new Gson().fromJson(json, UnitarySimulationRequestRepresentation.class);

        }
        return requestRepresentation;

    }

    @Override
    public UWCCollectionRequestDto saveOrUpdateUWCRequestToCollection(String collectionId, String requestId, String requestName,
            UnitarySimulationWltpHubRequestRepresentation unitarySimulationWltpHubRequestRepresentation) {
        CollectionEntity collection = null;
        UWCCollectionRequestDto requestDto = null;
        try {
            collection = collectionRepository.load(UUID.fromString(collectionId));
            if (collection == null) {
                throw new NotFoundException("Collection with ID + " + collectionId + " Not Found");
            }
        } catch (Exception e) {
            throw e;
        }
        if (requestId == null || requestId.isEmpty()) {
            CollectionRequestEntity requestEntity = collectionRequestEntityFactory.create();
            requestEntity.setRequestName(requestName);
            Blob requestBlob = getBlob(new Gson().toJson(unitarySimulationWltpHubRequestRepresentation));
            requestEntity.setRequestBlob(requestBlob);
            collection.addRequest(requestEntity);
            collectionRepository.save(collection);
            requestDto = new UWCCollectionRequestDto();
            requestDto.setCollectionRequestId(requestEntity.getCollectionRequestId().toString());
            requestDto.setRequestName(requestName);
            requestDto.setRequest(unitarySimulationWltpHubRequestRepresentation);
            return requestDto;
        }
        CollectionRequestEntity requestEntity = collectionRequestRepository.load(UUID.fromString(requestId));
        if (requestName != null && !requestName.isEmpty() && !requestName.equalsIgnoreCase(requestEntity.getRequestName())) {
            requestEntity.setRequestName(requestName);
        }
        Blob requestBlob = getBlob(new Gson().toJson(unitarySimulationWltpHubRequestRepresentation));
        requestEntity.setRequestBlob(requestBlob);
        collection.addRequest(requestEntity);
        collectionRequestRepository.updateCollectionRequest(requestEntity);
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService#getAllCollectionsOfUWC(java.lang.String, java.lang.String)
     */
    @Override
    public List<UWCCollectionDto> getAllCollectionsOfUWC(String userId, String type) {
        List<CollectionEntity> collectionList = collectionRepository.getAllCollections(userId, type);
        List<CollectionRequestEntity> collectionRequests = null;
        UWCCollectionRequestDto requestDto = null;
        UWCCollectionDto collectionDto = null;
        List<UWCCollectionDto> collections = new ArrayList<>();
        UnitarySimulationWltpHubRequestRepresentation requestRepresentation = null;
        byte[] collectionReqByteArray = null;
        for (CollectionEntity collectionEntity : collectionList) {
            collectionRequests = collectionEntity.getCollectionRequests();
            collectionDto = new UWCCollectionDto();
            collectionDto.setCollectionId(collectionEntity.getCollectionId().toString());
            collectionDto.setCollectionName(collectionEntity.getCollectionName());
            collectionDto.setUserId(collectionEntity.getUserId());
            for (CollectionRequestEntity collectionRequestEntity : collectionRequests) {
                try {
                    requestDto = new UWCCollectionRequestDto();
                    collectionReqByteArray = handleBlob(collectionRequestEntity.getRequestBlob());
                    String jsonStr = convertBytestoString(collectionReqByteArray);
                    requestRepresentation = convertToResponseObjectOfUWC(jsonStr);
                    requestDto.setCollectionRequestId(collectionRequestEntity.getCollectionRequestId().toString());
                    requestDto.setRequestName(collectionRequestEntity.getRequestName());
                    requestDto.setRequest(requestRepresentation);
                    collectionDto.addRequests(requestDto);
                } catch (SQLException e) {
                    logger.error("{}", e);
                }
            }
            collections.add(collectionDto);
        }
        return collections;
    }

    /**
     * Convert to response object of UWC.
     *
     * @param jsonStr the json str
     * @return the unitary simulation wltp hub request representation
     */
    private UnitarySimulationWltpHubRequestRepresentation convertToResponseObjectOfUWC(String jsonStr) {
        UnitarySimulationWltpHubRequestRepresentation requestRepresentation = null;
        String json = "{}";
        if (jsonStr != null) {

            try {

                json = jsonStr.substring(1, jsonStr.length() - 1);

                json = json.replaceAll("\\\\\"", "\"");

            } catch (Exception e) {
                logger.error("Error while converting Json string {}", e);
            }

            requestRepresentation = new Gson().fromJson(json, UnitarySimulationWltpHubRequestRepresentation.class);

        }
        return requestRepresentation;
    }

}
