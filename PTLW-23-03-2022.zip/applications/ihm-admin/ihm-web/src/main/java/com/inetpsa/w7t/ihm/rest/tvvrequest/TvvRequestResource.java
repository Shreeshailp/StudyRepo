/*
 * Creation : 15 May 2018
 */
package com.inetpsa.w7t.ihm.rest.tvvrequest;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.TVVService;
import com.inetpsa.w7t.application.utilities.ConvertExcelDataToBytes;
import com.inetpsa.w7t.application.utilities.ExportUtility;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVErrorCode;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVException;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyRepresentation;
import com.inetpsa.w7t.ihm.rest.tvvs.TvvFilter;
import com.inetpsa.w7t.ihm.rest.tvvs.TvvFinder;

import io.swagger.annotations.ApiOperation;

/**
 * The TvvRequestResource is meant to upload the TVV file and to provide the response of the same.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.IMPORTTVV)
public class TvvRequestResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The tvv finder. */
    @Inject
    TvvFinder tvvFinder;

    /** The t VV service. */
    @Inject
    TVVService tVVService;

    /** The user service. */
    @Inject
    UserService userService;

    /** The fs flag file path. */
    @Configuration("fsFlagFilePath")
    private String fsFlagFilePath;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The Constant SUFFIX. */
    @Configuration("xlsxSimulationSuffix")
    private String suffix;

    /** The prefix. */
    @Configuration("filePrefix")
    private String prefix;

    /** The Constant tvvHeaders. */
    private static final String[] tvvHeaders = { "E", "VEHICLE_FAMILY", "T1A_VALUE", "T1B_VALUE", "TVV_DESIGNATION", "TVV_VEHICLE_CATEGORY", "TVV_AF",
            "TVV_HEIGTH", "TVV_WIDTH", "TVV_MAX_SPEED", "TVV_SCX_BASE", "TVV_COMPLETE", "TVV_CODE_DEPOL" };

    /**
     * Respond with a {@link CollectionRepresentation}, a list of {@link FamilyRepresentation}.
     * 
     * @return the list of TVVS
     */
    @Rel(value = CatalogRels.IMPORTTVV, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response tvvs() {

        CollectionRepresentation tvvs = tvvFinder.all();
        return Response.ok(tvvs).build();
    }

    /**
     * Tvv search.
     *
     * @param filter the filter
     * @return the response
     */
    @Rel(value = CatalogRels.TVVSEARCH, home = true)
    @GET
    @Path(CatalogRels.TVVSEARCH)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response tvvSearch(@BeanParam TvvFilter filter) {
        CollectionRepresentation tvvs = tvvFinder.filter(filter);
        return Response.ok(tvvs).build();
    }

    /**
     * Upload.
     * 
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @param body the body
     * @return the response
     */
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate,
            @FormDataParam("file") final FormDataBodyPart body) {
        FileInputValidator.isNotNull(inputStream);
        String mimeType = body.getMediaType().toString();

        if (!mimeType.contains("sheet") && !mimeType.contains("excel")) {
            logger.info("MIME of uploaded file : {}", mimeType);
            return Response.status(Status.NOT_ACCEPTABLE).build();
        }

        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new TVVException(TVVErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            return Response.ok(tVVService.upload(inputStream, forceUpdate)).build();
        } catch (IOException e) {
            logger.error("IOException while uploading TVV details : ", e.getMessage(), e);
            TVVException tvv = new TVVException(TVVErrorCode.UNKNOWN_EXCEPTION, null);
            tvv.initCause(e);
            logger.error(e.getMessage(), e);
            throw tvv;
        } catch (TVVException e) {
            logger.error("TVVException while uploading TVV details : {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            if (e instanceof ConstraintViolationException) {
                Optional<ConstraintViolation<?>> error = ((ConstraintViolationException) e).getConstraintViolations().stream().findFirst();
                if (error.isPresent()) {
                    throw new TVVException(TVVErrorCode.TVV_UNKNOWN_EXCEPTION, null);
                }
            }
            logger.error("Exception while uploading TVV details : ", e.getMessage(), e);
            Object[] errMsg = { e.getMessage() };
            throw new TVVException(TVVErrorCode.TVV_UNKNOWN_ERROR, errMsg);

        }

    }

    /**
     * Tvv export.
     *
     * @return the response
     */
    @Rel(value = CatalogRels.TVV_EXPORT, home = true)
    @GET
    @Path(CatalogRels.TVV_EXPORT)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response tvvExport() {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new TVVException(TVVErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        ConvertExcelDataToBytes byteData = new ConvertExcelDataToBytes();
        List<TVV> tvvs = tvvFinder.allTVVs();
        byte[] bytes = ExportUtility.writeTVVToExcel(tvvHeaders, tvvs, userService.getUserId());
        byteData.setBytes(bytes);
        return Response.ok(byteData).build();
    }
}
