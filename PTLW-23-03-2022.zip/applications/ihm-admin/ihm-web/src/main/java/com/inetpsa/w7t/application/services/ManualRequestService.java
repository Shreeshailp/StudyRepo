/*
 * Creation : 5 avr. 2017
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;

/**
 * The interface ManualRequestService.
 */
@Service
public interface ManualRequestService {

    /**
     * Parses the inputstream to a list of RequestDto and process manual requests.
     *
     * @param inputStream the input stream
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    String processManualRequest(InputStream inputStream) throws IOException;

    /**
     * Gets the request batch by file id.
     *
     * @param fileId the file id
     * @return the request batch by file id
     */
    Optional<RequestBatchEntity> getRequestBatchByFileId(String fileId);

}
