/*
 * Creation : 7 Aug 2020
 */
package com.inetpsa.w7t.unitary.simulation.service;

import java.util.List;

import org.seedstack.business.Service;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CollectionEntity;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.CollectionDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.CollectionRequestDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionRequestDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationRequestRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationResponseRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubRequestRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubResponseRepresentation;

/**
 * The Interface UnitarySimulationService.
 */
@Service
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface UnitarySimulationService {

    /**
     * Call wltp web service.
     *
     * @param unitarySimulationRequestRepresentation the unitary simulation request representation
     * @return the unitary simulation response representation
     * @throws Exception the exception
     */
    public UnitarySimulationResponseRepresentation callWltpWebService(UnitarySimulationRequestRepresentation unitarySimulationRequestRepresentation)
            throws Exception;

    /**
     * Call wltphub web service.
     *
     * @param unitarySimulationWltpHubRequestRepresentation the unitary simulation wltp hub request representation
     * @return the unitary simulation wltp hub response representation
     * @throws Exception the exception
     */
    public UnitarySimulationWltpHubResponseRepresentation callWltphubWebService(
            UnitarySimulationWltpHubRequestRepresentation unitarySimulationWltpHubRequestRepresentation) throws Exception;

    /**
     * Creates the collection.
     *
     * @param name   the name
     * @param userId the user id
     * @param type   the type
     * @return the collection entity
     */
    public CollectionEntity createCollection(String name, String userId, String type);

    /**
     * Update collection.
     *
     * @param name         the name
     * @param collectionId the collection id
     */
    public void updateCollection(String name, String collectionId);

    /**
     * Delete collection.
     *
     * @param collectionId the collection id
     */
    public void deleteCollection(String collectionId);

    /**
     * Delete request.
     *
     * @param requestId the request id
     */
    public void deleteRequest(String requestId);

    /**
     * Save or update request to collection.
     *
     * @param collectionId          the collection id
     * @param requestId             the request id
     * @param requestName           the request name
     * @param requestRepresentation the request representation
     * @return the collection request dto
     */
    public CollectionRequestDto saveOrUpdateRequestToCollection(String collectionId, String requestId, String requestName,
            UnitarySimulationRequestRepresentation requestRepresentation);

    /**
     * Gets the all collections.
     *
     * @param userId the user id
     * @param type   the type
     * @return the all collections
     */
    public List<CollectionDto> getAllCollections(String userId, String type);

    /**
     * Save or update UWC request to collection.
     *
     * @param collectionId                                  the collection id
     * @param requestId                                     the request id
     * @param requestName                                   the request name
     * @param unitarySimulationWltpHubRequestRepresentation the unitary simulation wltp hub request representation
     * @return the collection request dto
     */
    public UWCCollectionRequestDto saveOrUpdateUWCRequestToCollection(String collectionId, String requestId, String requestName,
            UnitarySimulationWltpHubRequestRepresentation unitarySimulationWltpHubRequestRepresentation);

    /**
     * Gets the all collections of UWC.
     *
     * @param userId the user id
     * @param type   the type
     * @return the all collections of UWC
     */
    public List<UWCCollectionDto> getAllCollectionsOfUWC(String userId, String type);
}
