/*
 * Creation : 15 May 2018
 */
package com.inetpsa.w7t.ihm.rest.generatedcyclesrequest;

import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.GeneratedCycleService;
import com.inetpsa.w7t.application.utilities.FileDetails;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.application.utilities.WriteToTextFile;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleErrorCode;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleException;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFilter;
import com.inetpsa.w7t.ihm.rest.generatedcycless.GeneratedCyclesFinder;

import io.swagger.annotations.ApiOperation;

/**
 * The GeneratedCyclesRequestResource is meant to upload the GeneratedCycle file and to provide the response of the same.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.IMPORTGENERATEDCYCLES)
public class GeneratedCyclesRequestResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The user service. */
    @Inject
    UserService userService;

    /** The generated cycles finder. */
    @Inject
    GeneratedCyclesFinder generatedCyclesFinder;

    /** The gen cycle service. */
    @Inject
    GeneratedCycleService genCycleService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /**
     * Upload.
     *
     * @param inputStream the input stream
     * @param fileDisposition the file disposition
     * @param forceUpdate the force update
     * @return the response
     */
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDisposition,
            @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate) {
        FileInputValidator.isNotNull(inputStream);
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new GeneratedCycleException(GeneratedCycleErrorCode.INDUS_MAINTAINANCE_ERROR);
        }
        // jira-618 fixed end
        WriteToTextFile.writeToFile(userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString() + " : "
                + fileDisposition.getFileName());
        CollectionRepresentation list = null;

        try {
            // validated as per check-marx report
            if (null != inputStream) {
                list = genCycleService.upload(inputStream, forceUpdate);
                if (list != null) {
                    WriteToTextFile.writeToFile(userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString()
                            + " : File upload done successfully");
                }
            }
            return Response.ok(list).build();

        } catch (GeneratedCycleException e) {
            logger.error(e.getMessage(), e);
            WriteToTextFile
                    .writeToFile(userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString() + " " + e.toString());
            throw e;
        } catch (RuntimeException | IOException e) {
            if (e instanceof SocketTimeoutException) {
                GeneratedCycleException timeOutException = new GeneratedCycleException(GeneratedCycleErrorCode.TIMEOUT_EXCEPTION);
                timeOutException.initCause(e);
                throw timeOutException;
            }
            logger.error(e.getMessage(), e);
            GeneratedCycleException cve = new GeneratedCycleException(GeneratedCycleErrorCode.UNKNOWN_TECHNICAL_EXCEPTION);
            cve.initCause(e);
            WriteToTextFile.writeToFile(
                    userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString() + " : " + e.toString());
            throw cve;
        }

    }

    /**
     * Generatedcycles.
     *
     * @return the response
     */
    @Rel(value = CatalogRels.IMPORTGENERATEDCYCLES, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response generatedcycles() {
        CollectionRepresentation generatedcycles = generatedCyclesFinder.all();
        return Response.ok(generatedcycles).build();
    }

    /**
     * Generatedcycles search.
     *
     * @param filter the filter
     * @return the response
     */
    @Rel(value = CatalogRels.GENERATEDCYCLESSEARCH, home = true)
    @GET
    @Path(CatalogRels.GENERATEDCYCLESSEARCH)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response generatedcyclesSearch(@BeanParam GeneratedCyclesFilter filter) {
        CollectionRepresentation generatedcycles = generatedCyclesFinder.filter(filter);
        return Response.ok(generatedcycles).build();
    }

    /**
     * Gets the log data.
     *
     * @return the log data
     */
    @Rel(value = CatalogRels.DOWNLOAD, home = true)
    @GET
    @Path(CatalogRels.DOWNLOAD)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getLogData() {

        StringBuffer content = WriteToTextFile.readFile();
        FileDetails fileDetails = FileDetails.getInstance();
        fileDetails.setFileContent(content);
        return Response.ok(fileDetails).build();

    }

}
