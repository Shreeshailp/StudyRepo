/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.references.model.GearBoxEntity;
import com.inetpsa.w7t.domains.references.model.MoteurEntity;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.GearBoxRepresentaion;
import com.inetpsa.w7t.ihm.rest.families.MoteurRepresentation;

/**
 * The Class MoteurGearBoxJpaFinder.
 *
 * @author E569186
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MoteurGearBoxJpaFinder implements MoteurGearBoxFinder {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.infrastructure.finders.jpa.MoteurGearBoxFinder#getAllMoteur()
     */
    @Override
    public CollectionRepresentation getAllMoteur() {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MoteurEntity> criteria = cb.createQuery(MoteurEntity.class);
        Root<MoteurEntity> root = criteria.from(MoteurEntity.class);
        criteria.select(root);
        criteria.orderBy(cb.asc(root.get(CODE)));
        TypedQuery<MoteurEntity> query = entityManager.createQuery(criteria);

        List<MoteurRepresentation> motureList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(MoteurRepresentation.class);
        CollectionRepresentation motureDetails = new CollectionRepresentation(motureList.size(), false);

        motureDetails.embedded(CatalogRels.MOTURESANDGEARBOX, motureList);
        return motureDetails;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.infrastructure.finders.jpa.MoteurGearBoxFinder#getAllGearBox()
     */
    @Override
    public CollectionRepresentation getAllGearBox() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GearBoxEntity> criteria = cb.createQuery(GearBoxEntity.class);
        Root<GearBoxEntity> root = criteria.from(GearBoxEntity.class);
        criteria.select(root);
        criteria.orderBy(cb.asc(root.get(CODE)));
        TypedQuery<GearBoxEntity> query = entityManager.createQuery(criteria);
        List<GearBoxRepresentaion> gearBoxList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(GearBoxRepresentaion.class);
        CollectionRepresentation gearBoxDetails = new CollectionRepresentation(gearBoxList.size(), false);
        gearBoxDetails.embedded(CatalogRels.MOTURESANDGEARBOX, gearBoxList);
        return gearBoxDetails;
    }

}
