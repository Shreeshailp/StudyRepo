/*
 * Creation : 24 Feb 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import javax.ws.rs.QueryParam;

/**
 * The Class FamilyCheckStatusDto.
 */
public class FamilyCheckStatusDto {
    /** The family code. */
    @QueryParam("code")
    private String code;

    /** The index. */
    @QueryParam("index")
    private Integer index;

    /** The status. */
    @QueryParam("status")
    private String status;

    /** The blocked. */
    @QueryParam("blocked")
    private Boolean blocked;

    /** The blocking reason. */
    @QueryParam("blockingReason")
    private String blockingReason;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the index.
     *
     * @return the index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Sets the index.
     *
     * @param index the new index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the blocking reason.
     *
     * @return the blocking reason
     */
    public String getBlockingReason() {
        return blockingReason;
    }

    /**
     * Sets the blocking reason.
     *
     * @param blockingReason the new blocking reason
     */
    public void setBlockingReason(String blockingReason) {
        this.blockingReason = blockingReason;
    }

    /**
     * Gets the blocked.
     *
     * @return the blocked
     */
    public Boolean getBlocked() {
        return blocked;
    }

    /**
     * Sets the blocked.
     *
     * @param blocked the new blocked
     */
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "FamilyCheckStatusDto [code=" + code + ", index=" + index + ", status=" + status + ", blockingReason=" + blockingReason + ", blocked="
                + blocked + "]";
    }

}
