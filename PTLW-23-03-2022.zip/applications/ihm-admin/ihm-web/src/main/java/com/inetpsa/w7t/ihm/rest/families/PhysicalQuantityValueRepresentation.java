/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.families.model.details.PhysicalQuantityValue;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;

/**
 * The Class PhysicalQuantityValueRepresentation. This representation is used to represent a {@link PhysicalQuantityValue} of a specific
 * {@link TestVehicle}.
 */
public class PhysicalQuantityValueRepresentation extends HalRepresentation {

    /** The physical quantity type. */
    private String type;

    /** The value. */
    private Double value;

    /**
     * Gets the physical quantity type.
     *
     * @return the physical quantity type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the physical quantity type.
     *
     * @param type the new physical quantity type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Double getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Double value) {
        this.value = value;
    }
}
