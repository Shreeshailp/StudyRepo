/*
 * Creation : 20 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Class DestinationDetailsRepresentation. This representation is used to represent a {@link DestinationDetails}.
 */
@DtoOf(DestinationDetails.class)
public class DestinationDetailsRepresentation extends AbstractDestinationRepresentation {

    /** The parameter details. */
    private List<ParameterDetailsRepresentation> parameterDetails;

    /**
     * Gets the parameter details.
     *
     * @return the parameter details
     */
    public List<ParameterDetailsRepresentation> getParameterDetails() {
        return parameterDetails;
    }

    /**
     * Sets the parameter details.
     *
     * @param parameterDetails the new parameter details
     */
    public void setParameterDetails(List<ParameterDetailsRepresentation> parameterDetails) {
        this.parameterDetails = parameterDetails;
    }
}
