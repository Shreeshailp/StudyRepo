/*
 * Creation : 21 Feb 2020
 */
package com.inetpsa.w7t.application.services;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlagDto;
import com.inetpsa.w7t.ihm.rest.families.FamilyCheckStatusDto;

/**
 * The Interface FamilyTabCheckService.
 */
@Service
public interface FamilyTabCheckService {

    /**
     * Insert family tab check.
     *
     * @param familyTabCheckFlag the dto
     */
    void insertFamilyTabCheck(FamilyTabCheckFlagDto familyTabCheckFlag);

    /**
     * Insertfamily tab check status.
     *
     * @param familyDto the family tab check flag
     */
    void insertfamilyTabCheckStatus(FamilyCheckStatusDto familyDto);

}
