/*
 * Creation : 11 Jul 2019
 */
package com.inetpsa.w7t.ihm.rest.depol;

import javax.ws.rs.QueryParam;

public class DepolFilter {
    @QueryParam("codeDepol")
    public String codeDepol;

    @QueryParam("specialFlag")
    public String specialFlag;

    @QueryParam("designation")
    public String designation;

}
