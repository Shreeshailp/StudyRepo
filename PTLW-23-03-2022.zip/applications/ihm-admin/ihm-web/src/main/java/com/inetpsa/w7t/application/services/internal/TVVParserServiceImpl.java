/*
 * Creation : 29 May 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.TVVParserService;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVErrorCode;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVException;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TvvDto;

/**
 * The Class TVVParserServiceImpl.
 */
public class TVVParserServiceImpl implements TVVParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.TVVParserService#parse(java.io.InputStream)
     */
    @Override
    public List<TvvDto> parse(InputStream inputStream) throws IOException, TVVException {
        TvvDto t = null;
        List<TvvDto> list = new ArrayList<>();
        XSSFWorkbook myWorkBook = new XSSFWorkbook(inputStream);
        try {
            int rowCount = 0;
            XSSFSheet firstSheet = myWorkBook.getSheetAt(0);
            checkHeaders(firstSheet);
            // Iterator<Row> iterator = firstSheet.iterator();
            // while (iterator.hasNext()) {
            // Row nextRow = iterator.next();
            int phyRowCount = firstSheet.getPhysicalNumberOfRows();
            while (rowCount < phyRowCount) {
                Row nextRow = firstSheet.getRow(rowCount);
                if (nextRow.getFirstCellNum() == 1) {
                    throw new TVVException(TVVErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
                }
                if (checkIfRowIsEmpty(nextRow)) {
                    continue;
                }
                if (rowCount > 0) {
                    t = new TvvDto();
                    int counter = 0;
                    while (counter <= 12) {
                        Cell cell = nextRow.getCell(counter);
                        readExcelCellsBySwitchCase(t, rowCount, counter, cell);
                        counter++;
                    }
                }
                if (t != null) {
                    t.setLineNumber(rowCount + 1);
                    validateLine(t, list);
                    list.add(t);
                }
                rowCount++;

            }
            if (rowCount == 1)
                throw new TVVException(TVVErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);

            inputStream.close();
        } catch (TVVException tvvException) {
            throw tvvException;
        } catch (IOException e1) {
            logger.error("IOException while parsing the excel sheet : ", e1.getMessage(), e1);
        } catch (Exception ex) {
            logger.error("Exception while parsing the excel sheet : {}", ex.getMessage());
            throw ex;
        }

        finally {
            myWorkBook.close();
        }

        return list;
    }

    /**
     * Read excel cells by switch case.
     *
     * @param t the t
     * @param rowCount the row count
     * @param counter the counter
     * @param cell the cell
     */
    private void readExcelCellsBySwitchCase(TvvDto t, int rowCount, int counter, Cell cell) {
        String vehicleFamily;
        String t1A;
        String t1B;
        String tVV;
        String e;
        String category;
        String tvvCompleteFlag;
        String codeDepol;
        switch (counter) {
        case 0:
            e = getCellData(cell);
            validateFirstColEmpty(e);
            validateLineNotStratsCMD(e);
            break;
        case 1:
            vehicleFamily = getCellData(cell);
            t.setVehicleFamily(removeWhiteSpacefromString(vehicleFamily, 4));
            break;
        case 2:
            t1A = getCellData(cell);
            t.setT1AValue(removeWhiteSpacefromString(t1A, 2));
            break;
        case 3:
            t1B = getCellData(cell);
            t.setT1BValue(removeWhiteSpacefromString(t1B, 2));
            break;
        case 4:
            tVV = getCellData(cell);
            // fixed-jira-506
            t.setTvvDesignation(checkTVVDesign(tVV, rowCount));
            break;
        case 5:
            category = getCellData(cell);
            t.setTvvVehicleCategory(removeWhiteSpacefromString(category, 2));
            break;
        case 6:
            t.setTvvAf(getNonBlankNumericValue(cell));
            break;
        case 7:
            t.setTvvHeigth(getNonBlankNumericValue(cell));
            break;
        case 8:
            t.setTvvWidth(getNonBlankNumericValue(cell));
            break;
        case 9:
            t.setTvvMaxspeed(getNonBlankIntegerValue(cell));
            break;
        case 10:
            t.setTvvScxBase(getNonBlankNumericValue(cell));
            break;

        case 11:
            tvvCompleteFlag = cell.getStringCellValue();
            t.setTvvCompleteFlag(tvvCompleteFlag);
            break;

        case 12:
            if (cell != null) {
                codeDepol = getCellData(cell);
                if (!codeDepol.isEmpty())
                    t.setTvvCodeDepol(codeDepol);
            }
            break;

        default:
            break;
        }
    }

    /**
     * Check if row is empty.
     *
     * @param nextRow the next row
     * @return true, if successful
     */
    private boolean checkIfRowIsEmpty(Row nextRow) {
        boolean isEmpty = false;
        if (nextRow.getCell(1).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(2).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(3).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(4).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(5).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(6).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(7).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(8).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(9).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(10).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(11).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(12).getCellTypeEnum() == CellType.BLANK) {
            isEmpty = true;
        }

        return isEmpty;

    }

    /**
     * Check TVV design.
     *
     * @param tVV the t VV
     * @param rowCount the row count
     * @return the string
     */
    private String checkTVVDesign(String tVV, int rowCount) {

        if (tVV.length() > 40) {
            Integer[] lineNum = { rowCount };
            throw new TVVException(TVVErrorCode.TVV_DESIGNATION_EXCEEDED_LENGTH, lineNum);
        }
        return tVV;
    }

    /**
     * Check headers.
     *
     * @param firstSheet the first sheet
     * @throws TVVException the TVV exception
     */
    private void checkHeaders(XSSFSheet firstSheet) throws TVVException {
        final int totalNumberOfHeaderColumns = 13;
        int noOfColumns = firstSheet.getRow(0).getLastCellNum();
        logger.info("Total Number Of Header Columns Required are :[{}]", totalNumberOfHeaderColumns);
        if (noOfColumns < totalNumberOfHeaderColumns) {
            logger.info("The columns in the excel file are :[{}]", noOfColumns);
            throw new TVVException(TVVErrorCode.TVV_HEADER_COLUMN_MISSING, null);
        }

    }

    /**
     * Validate first col empty.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws TVVException the TVV exception
     */
    public static boolean validateFirstColEmpty(String cellValue) throws TVVException {
        if (cellValue.isEmpty()) {
            throw new TVVException(TVVErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
        }
        return false;
    }

    /**
     * Validate line not strats CMD.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws TVVException the TVV exception
     */
    public static boolean validateLineNotStratsCMD(String cellValue) throws TVVException {
        if (!("C".equalsIgnoreCase(cellValue)) && !("D".equalsIgnoreCase(cellValue)) && !("M".equalsIgnoreCase(cellValue))) {
            throw new TVVException(TVVErrorCode.FIRST_LINE_STARTS_C_M_D_CHECK, null);
        }
        return false;
    }

    /**
     * Validate line.
     *
     * @param tvv the tvv
     * @param tvvies the tvvies
     * @return true, if successful
     * @throws TVVException the TVV exception
     */
    public static boolean validateLine(TvvDto tvv, List<TvvDto> tvvies) throws TVVException {

        for (TvvDto tvv2 : tvvies) {
            if (tvv2.getT1AValue().equalsIgnoreCase(tvv.getT1AValue()) && tvv2.getT1BValue().equalsIgnoreCase(tvv.getT1BValue())
                    && tvv2.getVehicleFamily().equalsIgnoreCase(tvv.getVehicleFamily())) {
                String[] repeatTvv = { tvv.getVehicleFamily(), tvv.getT1AValue(), tvv.getT1BValue(), tvv.getTvvDesignation() };
                throw new TVVException(TVVErrorCode.TVV_ENTRY_PRESENT_IN_SHEET, repeatTvv);
            }
        }

        return false;

    }

    /**
     * Removes the white spacefrom string.
     *
     * @param str the str
     * @param length the length
     * @return the string
     */
    private String removeWhiteSpacefromString(String str, int length) {
        String tempStr = null;
        if (!str.isEmpty()) {
            if (str.length() > length) {
                tempStr = str.substring(0, length);
            } else {
                tempStr = str;
            }
        }
        return tempStr;
    }

    /**
     * Gets the cell data.
     *
     * @param cell the cell
     * @return the cell data
     */
    private String getCellData(Cell cell) {
        CellType cellType = cell.getCellTypeEnum();
        switch (cellType) {
        case BOOLEAN:
            return String.valueOf(cell.getBooleanCellValue());

        case NUMERIC:
            String useValue = String.valueOf(cell.getNumericCellValue());
            if (useValue.endsWith(".0"))
                return useValue.split("\\.")[0];
            return useValue;

        case STRING:
            return cell.getStringCellValue();

        case BLANK:
            return "";

        default:
            return new String();
        }
    }

    /**
     * Gets the non blank numeric value.
     *
     * @param cell the cell
     * @return the non blank numeric value
     */
    private Float getNonBlankNumericValue(Cell cell) {
        if (cell != null && (cell.getCellTypeEnum()).equals(CellType.STRING)) {
            String value = cell.getStringCellValue();
            if (value.isEmpty()) {
                return null;
            } else if (value.contains(",")) {
                return Float.valueOf(value.replace(",", "."));
            }
            return Float.valueOf(value);
        } else if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return (float) cell.getNumericCellValue();
    }

    /**
     * Gets the non blank integer value.
     *
     * @param cell the cell
     * @return the non blank integer value
     */
    private Integer getNonBlankIntegerValue(Cell cell) {
        if (cell != null && (cell.getCellTypeEnum()).equals(CellType.STRING)) {
            String value = cell.getStringCellValue();
            if (value.isEmpty()) {
                return null;
            }
            return Math.round(Integer.valueOf(value));
        } else if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return (int) Math.round(cell.getNumericCellValue());
    }

}
