/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.model.CycleDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface CycleService.
 */
@Service
public interface CycleService {

    /**
     * The Upload method which handles the complete upload of a cycle.
     *
     * @param inputStream the input stream
     * @param forceUpdate the force update
     * @return the cycles representation
     * @throws IOException Signals that an I/O exception has occurred.
     */
    CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException;

    /**
     * This method handles the insertion or updation of the cycle data in the database.
     *
     * @param cycles the cycles
     * @param forceUpdate the force update
     * @return the list
     */
    List<CycleDetails> importCycles(List<CycleDto> cycles, Boolean forceUpdate);
}
