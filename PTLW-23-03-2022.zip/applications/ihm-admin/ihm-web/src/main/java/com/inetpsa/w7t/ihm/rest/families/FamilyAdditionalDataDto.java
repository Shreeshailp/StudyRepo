/*
 * Creation : 4 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.io.Serializable;
import java.util.UUID;

/**
 * The Class FamilyAdditionalDataDto.
 */
public class FamilyAdditionalDataDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The id. */
    private UUID id;

    /** The t 8 c. */
    private String t8c;

    /** The t 8 d. */
    private String t8d;

    /** The vehicle families. */
    private String vehicleFamilies;

    /** The motor B 0 F. */
    private String motorB0F;

    /** The motor dkc. */
    private String motorDkc;

    /** The dld date. */
    private String dldDate;

    /** The dll date. */
    private String dllDate;

    /** The first reg date. */
    private String firstRegDate;

    /** The rce date. */
    private String rceDate;

    /** The window. */
    private String window;

    /** The url dossier. */
    private String urlDossier;

    /** The url pv. */
    private String urlPv;

    /** The url import file. */
    private String urlImportFile;

    /** The gear box. */
    private String gearBox;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public UUID getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Gets the t 8 c.
     *
     * @return the t 8 c
     */
    public String getT8c() {
        return t8c;
    }

    /**
     * Sets the t 8 c.
     *
     * @param t8c the new t 8 c
     */
    public void setT8c(String t8c) {
        this.t8c = t8c;
    }

    /**
     * Gets the t 8 d.
     *
     * @return the t 8 d
     */
    public String getT8d() {
        return t8d;
    }

    /**
     * Sets the t 8 d.
     *
     * @param t8d the new t 8 d
     */
    public void setT8d(String t8d) {
        this.t8d = t8d;
    }

    /**
     * Gets the vehicle families.
     *
     * @return the vehicle families
     */
    public String getVehicleFamilies() {
        return vehicleFamilies;
    }

    /**
     * Sets the vehicle families.
     *
     * @param vehicleFamilies the new vehicle families
     */
    public void setVehicleFamilies(String vehicleFamilies) {
        this.vehicleFamilies = vehicleFamilies;
    }

    /**
     * Gets the motor B 0 F.
     *
     * @return the motor B 0 F
     */
    public String getMotorB0F() {
        return motorB0F;
    }

    /**
     * Sets the motor B 0 F.
     *
     * @param motorB0F the new motor B 0 F
     */
    public void setMotorB0F(String motorB0F) {
        this.motorB0F = motorB0F;
    }

    /**
     * Gets the motor dkc.
     *
     * @return the motor dkc
     */
    public String getMotorDkc() {
        return motorDkc;
    }

    /**
     * Sets the motor dkc.
     *
     * @param motorDkc the new motor dkc
     */
    public void setMotorDkc(String motorDkc) {
        this.motorDkc = motorDkc;
    }

    /**
     * Gets the dld date.
     *
     * @return the dld date
     */
    public String getDldDate() {
        return dldDate;
    }

    /**
     * Sets the dld date.
     *
     * @param dldDate the new dld date
     */
    public void setDldDate(String dldDate) {
        this.dldDate = dldDate;
    }

    /**
     * Gets the dll date.
     *
     * @return the dll date
     */
    public String getDllDate() {
        return dllDate;
    }

    /**
     * Sets the dll date.
     *
     * @param dllDate the new dll date
     */
    public void setDllDate(String dllDate) {
        this.dllDate = dllDate;
    }

    /**
     * Gets the first reg date.
     *
     * @return the first reg date
     */
    public String getFirstRegDate() {
        return firstRegDate;
    }

    /**
     * Sets the first reg date.
     *
     * @param firstRegDate the new first reg date
     */
    public void setFirstRegDate(String firstRegDate) {
        this.firstRegDate = firstRegDate;
    }

    /**
     * Gets the rce date.
     *
     * @return the rce date
     */
    public String getRceDate() {
        return rceDate;
    }

    /**
     * Sets the rce date.
     *
     * @param rceDate the new rce date
     */
    public void setRceDate(String rceDate) {
        this.rceDate = rceDate;
    }

    /**
     * Gets the window.
     *
     * @return the window
     */
    public String getWindow() {
        return window;
    }

    /**
     * Sets the window.
     *
     * @param window the new window
     */
    public void setWindow(String window) {
        this.window = window;
    }

    /**
     * Gets the url dossier.
     *
     * @return the url dossier
     */
    public String getUrlDossier() {
        return urlDossier;
    }

    /**
     * Sets the url dossier.
     *
     * @param urlDossier the new url dossier
     */
    public void setUrlDossier(String urlDossier) {
        this.urlDossier = urlDossier;
    }

    /**
     * Gets the url pv.
     *
     * @return the url pv
     */
    public String getUrlPv() {
        return urlPv;
    }

    /**
     * Sets the url pv.
     *
     * @param urlPv the new url pv
     */
    public void setUrlPv(String urlPv) {
        this.urlPv = urlPv;
    }

    /**
     * Gets the url import file.
     *
     * @return the url import file
     */
    public String getUrlImportFile() {
        return urlImportFile;
    }

    /**
     * Sets the url import file.
     *
     * @param urlImportFile the new url import file
     */
    public void setUrlImportFile(String urlImportFile) {
        this.urlImportFile = urlImportFile;
    }

    /**
     * Gets the gear box.
     *
     * @return the gear box
     */
    public String getGearBox() {
        return gearBox;
    }

    /**
     * Sets the gear box.
     *
     * @param gearBox the new gear box
     */
    public void setGearBox(String gearBox) {
        this.gearBox = gearBox;
    }

}
