/*
 * Creation : 5 avr. 2017
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.ManualRequestService;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.services.RequestService;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.RequestValidationException;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;

/**
 * The Class ManualRequestServiceImpl.
 */
public class ManualRequestServiceImpl implements ManualRequestService {

    /** The Request service. */
    @Inject
    private RequestService requestService;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Data formatter. */
    DataFormatter df = new DataFormatter();

    /** The number 0. */
    public static final int NUM_ZERO = 0;
    /** The number 1. */
    public static final int NUM_ONE = 1;
    /** The number 2. */
    public static final int NUM_TWO = 2;
    /** The number 3. */
    public static final int NUM_THREE = 3;
    /** The number 4. */
    public static final int NUM_FOUR = 4;
    /** The number 5. */
    public static final int NUM_FIVE = 5;
    /** The number 6. */
    public static final int NUM_SIX = 6;
    /** The number 7. */
    public static final int NUM_SEVEN = 7;
    /** The number 8. */
    public static final int NUM_EIGHT = 8;
    /** The number 9. */
    public static final int NUM_NINE = 9;
    /** The number 10. */
    public static final int NUM_TEN = 10;

    /** The Constant ELEVEN. */
    private static final int ELEVEN = 11;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.ManualRequestService#processManualRequest(java.io.InputStream)
     */
    @Override
    public String processManualRequest(InputStream inputStream) throws IOException {

        String manualFileId = null;
        List<Request> requestsList = parseAndValidate(inputStream);
        if (requestsList != null && !requestsList.isEmpty()) {
            manualFileId = requestService.importRequest(requestsList);
        }
        return manualFileId;
    }

    /**
     * Parses the and validate.
     *
     * @param inputStream the input stream
     * @return the list
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public List<Request> parseAndValidate(InputStream inputStream) throws IOException {

        List<Request> requestsList = new ArrayList<>();

        XSSFWorkbook requestImportWorkBook = new XSSFWorkbook(inputStream);
        XSSFSheet requestImportSheet = requestImportWorkBook.getSheetAt(NUM_ZERO);
        Iterator<Row> rowIterator = requestImportSheet.iterator();
        rowIterator.next();
        while (rowIterator.hasNext()) {

            Row rRow = rowIterator.next();
            // fix jira 538
            if (checkIfRowIsEmpty(rRow)) {
                continue;
            }
            Request request = new Request();
            Date date;
            LocalDate localDate;

            request.setStatus(RequestStatus.REQUEST_RECEIVED);

            getRequestInfo(rRow, request);

            try {
                date = rRow.getCell(NUM_TWO).getDateCellValue();
                if (date == null) {
                    requestImportWorkBook.close();
                    LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(),
                            RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
                    throw new RequestValidationException(RequestErrorCode.ECOM_DATE_INCORRECT);
                }
            } catch (IllegalStateException | NumberFormatException | NullPointerException | DateTimeParseException e) {
                LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(),
                        RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
                logger.debug("The exception handled is - " + e.getMessage(), e);
                requestImportWorkBook.close();
                throw new RequestValidationException(RequestErrorCode.ECOM_DATE_INCORRECT);
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            localDate = LocalDate.parse(sdf.format(date));
            request.setEcomDate(localDate);

            getMassData(rRow, request);

            getPhysicalData(rRow, request);

            request.setManualRequest(true);
            requestsList.add(request);
        }
        requestImportWorkBook.close();
        return requestsList;

    }

    /**
     * Check if row is empty.
     *
     * @param nextRow the next row
     * @return true, if successful
     */
    private boolean checkIfRowIsEmpty(Row nextRow) {
        boolean isEmpty = false;
        int noOfColumns = ELEVEN;
        List<Boolean> emptyCheckList = new ArrayList<>();
        if (nextRow != null) {
            for (int i = 0; i < noOfColumns; i++) {
                if (nextRow.getCell(i) == null || nextRow.getCell(i).getCellTypeEnum() == CellType.BLANK) {
                    emptyCheckList.add(true);
                }
            }
        }
        if (!emptyCheckList.isEmpty() && emptyCheckList.size() == noOfColumns) {
            isEmpty = true;
        }

        return isEmpty;

    }

    /**
     * Gets the mass data.
     *
     * @param rRow the r row
     * @param request the request
     * @return the mass data
     */
    private void getMassData(Row rRow, Request request) {
        Double unladenMass = rRow.getCell(NUM_THREE, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_THREE).getNumericCellValue()
                : null;
        if (unladenMass == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }

        Double equipmentMass = rRow.getCell(NUM_FOUR, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_FOUR).getNumericCellValue()
                : null;
        if (equipmentMass == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }

        Double vehicleMass = rRow.getCell(NUM_FIVE, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_FIVE).getNumericCellValue()
                : null;
        if (vehicleMass == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }
        request.setUnladenMass(unladenMass);
        request.setEquipmentMass(equipmentMass);
        request.setVehicleMass(vehicleMass);

    }

    /**
     * Gets the request info.
     *
     * @param rRow the r row
     * @param request the request
     * @return the request info
     */
    private void getRequestInfo(Row rRow, Request request) {
        String vin = df.formatCellValue(rRow.getCell(NUM_ZERO));
        if (vin.isEmpty() || vin.length() != 17) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.VIN_INCORRECT.getRuleCode(),
                    RequestErrorCode.VIN_INCORRECT.getDescription());
            throw new RequestValidationException(RequestErrorCode.VIN_INCORRECT);
        }

        String requestType = df.formatCellValue(rRow.getCell(NUM_ONE));
        if (requestType.isEmpty() || !eNumContains(requestType)) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.UNKNOWN_REQUEST_TYPE.getRuleCode(),
                    RequestErrorCode.UNKNOWN_REQUEST_TYPE.getDescription());
            throw new RequestValidationException(RequestErrorCode.UNKNOWN_REQUEST_TYPE);
        }

        String extendedTitle = df.formatCellValue(rRow.getCell(NUM_TEN));
        if (extendedTitle.isEmpty() || !extendedTitle.matches(".{24}(?:.{7})*")) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                    RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            throw new RequestValidationException(RequestErrorCode.EXTENDED_TITLE_INCORRECT);
        }
        request.setVin(vin);
        request.setRequestType(RequestType.valueOf(requestType));
        request.setExtendedTitle(extendedTitle);

    }

    /**
     * Gets the physical data.
     *
     * @param rRow the r row
     * @param request the request
     * @return the physical data
     */
    private void getPhysicalData(Row rRow, Request request) {
        Double unladenSCX = rRow.getCell(NUM_SIX, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_SIX).getNumericCellValue()
                : null;
        if (unladenSCX == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }
        Double equipmentSCX = rRow.getCell(NUM_SEVEN, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_SEVEN).getNumericCellValue()
                : null;
        if (equipmentSCX == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }
        Double vehicleSCX = rRow.getCell(NUM_EIGHT, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_EIGHT).getNumericCellValue()
                : null;
        if (vehicleSCX == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }

        request.setUnladenSCX(unladenSCX);
        request.setEquipmentSCX(equipmentSCX);
        request.setVehicleSCX(vehicleSCX);

        getVehicleCrr(rRow, request);
    }

    /**
     * Gets the vehicle crr.
     *
     * @param rRow the r row
     * @param request the request
     * @return the vehicle crr
     */
    private void getVehicleCrr(Row rRow, Request request) {
        Double cRR = rRow.getCell(NUM_NINE, MissingCellPolicy.RETURN_BLANK_AS_NULL) != null ? rRow.getCell(NUM_NINE).getNumericCellValue() : null;
        if (cRR == null) {
            LogErrorUtility.logTheError(logger, request.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING.getRuleCode(),
                    RequestErrorCode.PHYSICAL_DATA_MISSING.getDescription());
            throw new RequestValidationException(RequestErrorCode.PHYSICAL_DATA_MISSING);
        }
        request.setVehicleCRR(cRR);
    }

    /**
     * E num contains.
     *
     * @param requestType the request type
     * @return true, if successful
     */
    public static boolean eNumContains(String requestType) {

        for (RequestType r : RequestType.values()) {
            if (r.name().equals(requestType)) {
                return true;
            }
        }

        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.ManualRequestService#getRequestBatchByFileId(java.lang.String)
     */
    @Override
    public Optional<RequestBatchEntity> getRequestBatchByFileId(String fileId) {

        return requestService.batchByFileId(fileId);
    }

}
