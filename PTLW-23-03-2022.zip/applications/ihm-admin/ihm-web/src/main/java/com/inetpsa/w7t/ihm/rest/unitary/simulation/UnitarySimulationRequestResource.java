/*
 * Creation : 6 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationErrorCode;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationException;
import com.inetpsa.w7t.domains.wltphub.parameter.repository.WltpHubParameterRepository;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService;

/**
 * The Class UnitarySimulationRequestResource.
 */
@Path(CatalogRels.UNITARY_SIMULATION)
public class UnitarySimulationRequestResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The unitary simulation service. */
    @Inject
    private UnitarySimulationService unitarySimulationService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The maximum collection limit. */
    @Configuration("maximumCollectionLimit")
    private String maximumCollectionLimit;

    /** The maximum request limit. */
    @Configuration("maximumRequestLimit")
    private String maximumRequestLimit;

    /** The Constant DB_ERROR_MSG. */
    private static final String DB_ERROR_MSG = "Error loading aggregate from database :{}";

    /** The Constant WEB_SERVICE_ERROR_MSG. */
    private static final String WEB_SERVICE_ERROR_MSG = "Exception while calling wltp web service : {}";

    /** The Constant UNIT_SIMULATION. */
    private static final String UNIT_SIMULATION = "UNIT SIMULATION";

    /** The wltp hub parameter repository. */
    @Inject
    private WltpHubParameterRepository wltpHubParameterRepository;

    private static final String CLIENT = "USM";

    /**
     * Call wltp web service.
     *
     * @param appName                                the app name
     * @param unitarySimulationRequestRepresentation the unitary simulation request representation
     * @return the response
     */
    @Rel(value = CatalogRels.UNITARY_SIMULATION, home = true)
    @Path(CatalogRels.CALL_WLTP_WS)
    @POST
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response callWltpWebService(@QueryParam(CatalogRels.APP_NAME) String appName,
            UnitarySimulationRequestRepresentation unitarySimulationRequestRepresentation) {
        UnitarySimulationResponseRepresentation responseRepresentation = null;
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            if (appName != null && !appName.isEmpty() && "CALCULWLTP".equalsIgnoreCase(appName)) {
                logger.info("App Name[{}]", appName);
                // CAP-26709 - LOT24 Changes- Added below client name as part of it
                unitarySimulationRequestRepresentation.getRequest().setClientName(CLIENT);
                responseRepresentation = unitarySimulationService.callWltpWebService(unitarySimulationRequestRepresentation);
            }
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            return Response.status(Response.Status.BAD_REQUEST).build();
        }
        return Response.ok(responseRepresentation).build();
    }

    /**
     * Creates the collection.
     *
     * @param collectionName the collection name
     * @param userId         the user id
     * @return the response
     */
    @POST
    @Path(CatalogRels.CREATE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response createCollection(@QueryParam(CatalogRels.COL_NAME) String collectionName, @QueryParam(CatalogRels.USER_ID) String userId) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        String code = wltpHubParameterRepository.getCodeByClient(UNIT_SIMULATION);
        return Response.ok(unitarySimulationService.createCollection(collectionName, userId, code)).build();
    }

    /**
     * Update collection.
     *
     * @param collectionName the collection name
     * @param collectionId   the collection id
     * @return the response
     */
    @POST
    @Path(CatalogRels.UPDATE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response updateCollection(@QueryParam(CatalogRels.COL_NAME) String collectionName, @QueryParam(CatalogRels.COL_ID) String collectionId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.updateCollection(collectionName, collectionId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        return Response.ok(Status.OK).build();
    }

    /**
     * Delete collection.
     *
     * @param collectionId the collection id
     * @return the response
     */
    @POST
    @Path(CatalogRels.DELETE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response deleteCollection(@QueryParam(CatalogRels.COL_ID) String collectionId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.deleteCollection(collectionId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        return Response.ok(Status.OK).build();
    }

    /**
     * Save or update request to collection.
     *
     * @param collectionId                           the collection id
     * @param requestId                              the request id
     * @param requestName                            the request name
     * @param unitarySimulationRequestRepresentation the unitary simulation request representation
     * @return the response
     */
    @POST
    @Path(CatalogRels.SAVE_REQUEST_TO_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response saveOrUpdateRequestToCollection(@QueryParam(CatalogRels.COL_ID) String collectionId,
            @QueryParam(CatalogRels.REQ_ID) String requestId, @QueryParam(CatalogRels.REQ_NAME) String requestName,
            UnitarySimulationRequestRepresentation unitarySimulationRequestRepresentation) {
        CollectionRequestDto collectionRequestDto = null;
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            collectionRequestDto = unitarySimulationService.saveOrUpdateRequestToCollection(collectionId, requestId, requestName,
                    unitarySimulationRequestRepresentation);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        if (requestId == null || requestId.isEmpty()) {
            return Response.ok(collectionRequestDto).build();
        }
        return Response.ok(Status.OK).build();
    }

    /**
     * Delete request.
     *
     * @param requestId the request id
     * @return the response
     */
    @POST
    @Path(CatalogRels.DELETE_REQUEST)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response deleteRequest(@QueryParam(CatalogRels.REQ_ID) String requestId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.deleteRequest(requestId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        return Response.ok(Status.OK).build();
    }

    /**
     * Gets the all collections.
     *
     * @param userId the user id
     * @return the all collections
     */
    @GET
    @Path(CatalogRels.ALL_COLLECTIONS)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getAllCollections(@QueryParam(CatalogRels.USER_ID) String userId) {
        String type = wltpHubParameterRepository.getCodeByClient(UNIT_SIMULATION);
        List<CollectionDto> collections = unitarySimulationService.getAllCollections(userId, type);
        CollectionWrapper collecctionWrapper = new CollectionWrapper(collections);
        collecctionWrapper.setMaximumCollectionLimit(maximumCollectionLimit);
        collecctionWrapper.setMaximumRequestLimit(maximumRequestLimit);
        return Response.ok(collecctionWrapper).build();
    }

}
