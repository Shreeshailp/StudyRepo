/*
 * Creation : 6 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation.wltphubrequest;

import java.util.List;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationErrorCode;
import com.inetpsa.w7t.domains.unitary.simulation.exceptions.UnitarySimulationException;
import com.inetpsa.w7t.domains.wltphub.parameter.repository.WltpHubParameterRepository;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionRequestDto;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UWCCollectionWrapper;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubRequestRepresentation;
import com.inetpsa.w7t.ihm.rest.unitary.simulation.UnitarySimulationWltpHubResponseRepresentation;
import com.inetpsa.w7t.unitary.simulation.service.UnitarySimulationService;

/**
 * The Class UnitarySimulationRequestResource.
 */
@Path(CatalogRels.WLTPHUB_UNITARY_SIMULATION)
public class UnitarySimulationWltpHubRequestResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The unitary simulation service. */
    @Inject
    private UnitarySimulationService unitarySimulationService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /** The maximum collection limit. */
    @Configuration("maximumCollectionLimit")
    private String maximumCollectionLimit;

    /** The maximum request limit. */
    @Configuration("maximumRequestLimit")
    private String maximumRequestLimit;

    /** The Constant DB_ERROR_MSG. */
    private static final String DB_ERROR_MSG = "Error loading aggregate from database :{}";

    /** The Constant WEB_SERVICE_ERROR_MSG. */
    private static final String WEB_SERVICE_ERROR_MSG = "Exception while calling wltphub web service : {}";

    /** The Constant UNITARY_WLTPHUB_CONSULTATION. */
    private static final String UNITARY_WLTPHUB_CONSULTATION = "UNITARY WLTPHUB CONSULTATION";

    /** The wltp hub parameter repository. */
    @Inject
    private WltpHubParameterRepository wltpHubParameterRepository;

    /**
     * Call wltp web service.
     *
     * @param appName               the app name
     * @param requestRepresentation the request representation
     * @return the response
     */
    @Rel(value = CatalogRels.WLTPHUB_UNITARY_SIMULATION, home = true)
    @Path(CatalogRels.CALL_WLTPHUB_WS)
    @POST
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response callWltpWebService(@QueryParam(CatalogRels.APP_NAME) String appName,
            UnitarySimulationWltpHubRequestRepresentation requestRepresentation) {
        UnitarySimulationWltpHubResponseRepresentation responseRepresentation = null;
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            if (appName != null && !appName.isEmpty() && "WLTPHUB".equalsIgnoreCase(appName)) {
                logger.info("App Name[{}]", appName);
                UUID uuid = UUID.randomUUID();
                String uuidAsString = uuid.toString();
                String code = wltpHubParameterRepository.getCodeByClient(UNITARY_WLTPHUB_CONSULTATION);
                String generatedRequestId = code + "-" + uuidAsString;
                requestRepresentation.getRequest().setRequestID(generatedRequestId);
                logger.info("Generated Request ID[{}] for the UNITARY WLTPHUB CONSULTATION", generatedRequestId);
                responseRepresentation = unitarySimulationService.callWltphubWebService(requestRepresentation);
                if (StringUtils.isNotBlank(responseRepresentation.getRequest().getRequestID())) {
                    logger.info("Request ID[{}]: Hub Web Service response : {}", responseRepresentation.getRequest().getRequestID(),
                            responseRepresentation);
                } else {
                    logger.info("Hub Web Service response : {}", responseRepresentation);
                }
                if (null != responseRepresentation.getRequest() && StringUtils.isNotBlank(responseRepresentation.getRequest().getRequestID())
                        && StringUtils.isNotBlank(responseRepresentation.getRequest().getExtendedTitleAttributes())) {
                    logger.info("Request ID[{}]: ExtendedTitle : {}", responseRepresentation.getRequest().getRequestID(),
                            responseRepresentation.getRequest().getVersion16C() + responseRepresentation.getRequest().getColorExtInt()
                                    + responseRepresentation.getRequest().getExtendedTitleAttributes());
                } else {
                    logger.info("ExtendedTitle : {}",
                            responseRepresentation.getRequest().getVersion16C() + responseRepresentation.getRequest().getColorExtInt()
                                    + responseRepresentation.getRequest().getExtendedTitleAttributes());
                }
            }
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            return Response.status(Response.Status.BAD_REQUEST).build();

        }
        return Response.ok(responseRepresentation).build();
    }

    /**
     * Creates the collection.
     *
     * @param collectionName the collection name
     * @param userId         the user id
     * @return the response
     */
    @POST
    @Path(CatalogRels.CREATE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response createCollection(@QueryParam(CatalogRels.COL_NAME) String collectionName, @QueryParam(CatalogRels.USER_ID) String userId) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end

        String code = wltpHubParameterRepository.getCodeByClient(UNITARY_WLTPHUB_CONSULTATION);
        logger.info("The following collection [{}] has been created successfully", collectionName);
        return Response.ok(unitarySimulationService.createCollection(collectionName, userId, code)).build();
    }

    /**
     * Update collection.
     *
     * @param collectionName the collection name
     * @param collectionId   the collection id
     * @return the response
     */
    @POST
    @Path(CatalogRels.UPDATE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response updateCollection(@QueryParam(CatalogRels.COL_NAME) String collectionName, @QueryParam(CatalogRels.COL_ID) String collectionId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.updateCollection(collectionName, collectionId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        logger.info("The following collection [{}] has been updated successfully", collectionName);
        return Response.ok(Status.OK).build();
    }

    /**
     * Delete collection.
     *
     * @param collectionId the collection id
     * @return the response
     */
    @POST
    @Path(CatalogRels.DELETE_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response deleteCollection(@QueryParam(CatalogRels.COL_ID) String collectionId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.deleteCollection(collectionId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        logger.info("The collection has been deleted successfully");
        return Response.ok(Status.OK).build();
    }

    /**
     * Save or update request to collection.
     *
     * @param collectionId                                  the collection id
     * @param requestId                                     the request id
     * @param requestName                                   the request name
     * @param unitarySimulationWltpHubRequestRepresentation the unitary simulation wltp hub request representation
     * @return the response
     */
    @POST
    @Path(CatalogRels.SAVE_REQUEST_TO_COLLECTION)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response saveOrUpdateRequestToCollection(@QueryParam(CatalogRels.COL_ID) String collectionId,
            @QueryParam(CatalogRels.REQ_ID) String requestId, @QueryParam(CatalogRels.REQ_NAME) String requestName,
            UnitarySimulationWltpHubRequestRepresentation unitarySimulationWltpHubRequestRepresentation) {
        UWCCollectionRequestDto collectionRequestDto = null;
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            collectionRequestDto = unitarySimulationService.saveOrUpdateUWCRequestToCollection(collectionId, requestId, requestName,
                    unitarySimulationWltpHubRequestRepresentation);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        if (requestId == null || requestId.isEmpty()) {
            return Response.ok(collectionRequestDto).build();
        }
        logger.info("The following request [{}] has been created/updated successfully", requestName);
        return Response.ok(Status.OK).build();
    }

    /**
     * Delete request.
     *
     * @param requestId the request id
     * @return the response
     */
    @POST
    @Path(CatalogRels.DELETE_REQUEST)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response deleteRequest(@QueryParam(CatalogRels.REQ_ID) String requestId) {
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new UnitarySimulationException(UnitarySimulationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            unitarySimulationService.deleteRequest(requestId);
        } catch (UnitarySimulationException e) {
            logger.error(WEB_SERVICE_ERROR_MSG, e);
            throw e;
        } catch (Exception e) {
            logger.error(DB_ERROR_MSG, e);
            return Response.serverError().build();
        }
        return Response.ok(Status.OK).build();
    }

    /**
     * Gets the all collections.
     *
     * @param userId the user id
     * @return the all collections
     */
    @GET
    @Path(CatalogRels.ALL_COLLECTIONS)
    @Consumes({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response getAllCollections(@QueryParam(CatalogRels.USER_ID) String userId) {
        String type = wltpHubParameterRepository.getCodeByClient(UNITARY_WLTPHUB_CONSULTATION);
        List<UWCCollectionDto> collections = unitarySimulationService.getAllCollectionsOfUWC(userId, type);
        UWCCollectionWrapper collecctionWrapper = new UWCCollectionWrapper(collections);
        collecctionWrapper.setMaximumCollectionLimit(maximumCollectionLimit);
        collecctionWrapper.setMaximumRequestLimit(maximumRequestLimit);
        return Response.ok(collecctionWrapper).build();
    }

}
