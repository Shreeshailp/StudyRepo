/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.families;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.MoteurEntity;

/**
 * The Class MoteurRepresentation.
 *
 * @author E569186
 */
@DtoOf(MoteurEntity.class)
public class MoteurRepresentation extends AbstractMoteurRepresentation {

}
