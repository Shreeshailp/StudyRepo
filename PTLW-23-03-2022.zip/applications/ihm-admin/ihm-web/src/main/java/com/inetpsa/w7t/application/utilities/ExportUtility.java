/*
 * Creation : 16 Jul 2019
 */
package com.inetpsa.w7t.application.utilities;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.domains.depol.model.DepolDto;
import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

public class ExportUtility {

    private static Logger logger = LoggerFactory.getLogger(ExportUtility.class);

    // TVV export issue fix
    static {
        System.setProperty("java.awt.headless", "true");
    }

    public static byte[] writeTVVToExcel(String[] headers, List<TVV> list, String userId) {

        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("tvv");

        byte[] xls = new byte[1024];
        // Iterate over data and write to sheet
        int rownum = 0;

        if (rownum == 0) {
            Row row = sheet.createRow(rownum++);
            writeHeaders(row, headers, workbook);
        }
        for (TVV tvv : list) {
            Row row = sheet.createRow(rownum);
            int cellnum = 0;
            // this line creates a cell in the next column of that row
            while (cellnum <= headers.length - 1) {
                switch (cellnum) {
                case 0:
                    Cell cell = row.createCell(cellnum);
                    cell.setCellValue("C");
                    break;
                case 1:
                    Cell cell1 = row.createCell(cellnum);
                    cell1.setCellValue(tvv.getVehicleFamily());
                    break;
                case 2:
                    Cell cell2 = row.createCell(cellnum);
                    cell2.setCellValue(tvv.getT1AValue());
                    break;
                case 3:
                    Cell cell3 = row.createCell(cellnum);
                    cell3.setCellValue(tvv.getT1BValue());
                    break;
                case 4:
                    Cell cell4 = row.createCell(cellnum);
                    cell4.setCellValue(tvv.getTvvDesignation());
                    break;
                case 5:
                    Cell cell5 = row.createCell(cellnum);
                    cell5.setCellValue(tvv.getTvvVehicleCategory());
                    break;
                case 6:
                    Cell cell6 = row.createCell(cellnum);
                    if (tvv.getTvvAf() == null) {
                        cell6.setCellValue("");
                    } else {
                        String frontalArea = tvv.getTvvAf().toString().replace(".", ",");
                        cell6.setCellValue(frontalArea);
                    }
                    break;
                case 7:
                    Cell cell7 = row.createCell(cellnum);
                    if (tvv.getTvvHeigth() == null) {
                        cell7.setCellValue("");
                    } else {
                        String tvvHeight = tvv.getTvvHeigth().toString().replace(".", ",");
                        cell7.setCellValue(tvvHeight);
                    }
                    break;
                case 8:
                    Cell cell8 = row.createCell(cellnum);
                    if (tvv.getTvvWidth() == null) {
                        cell8.setCellValue("");
                    } else {
                        String tvvWidth = tvv.getTvvWidth().toString().replace(".", ",");
                        cell8.setCellValue(tvvWidth);
                    }
                    break;
                case 9:
                    Cell cell9 = row.createCell(cellnum);
                    if (tvv.getTvvMaxspeed() == null) {
                        cell9.setCellValue("");
                    } else {
                        cell9.setCellValue(tvv.getTvvMaxspeed().toString());
                    }
                    break;
                case 10:
                    Cell cell10 = row.createCell(cellnum);
                    if (tvv.getTvvScxBase() == null) {
                        cell10.setCellValue("");
                    } else {
                        String tvvScxBase = tvv.getTvvScxBase().toString().replace(".", ",");
                        cell10.setCellValue(tvvScxBase);
                    }
                    break;
                case 11:
                    Cell cell11 = row.createCell(cellnum);
                    cell11.setCellValue(tvv.getTvvCompleteFlag());
                    break;
                case 12:
                    Cell cell12 = row.createCell(cellnum);
                    cell12.setCellValue(tvv.getTvvCodeDepol());
                    break;
                default:
                    break;
                }
                cellnum++;
            }
            rownum++;

            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (tvv != null) {
                traceLog.append(" export ").append(tvv);
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            workbook.write(baos);
            xls = baos.toByteArray();
            return xls;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        return xls;
    }

    public static String getTodayDateAsString() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy_MM_dd_HHmm");
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    private static void writeHeaders(Row row, String[] headers, XSSFWorkbook workbook) {
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 10);

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        for (int i = 0; i < headers.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerCellStyle);
        }
    }

    public static byte[] writeDepolToExcel(String[] headers, List<Depol> list, String userId) {

        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("depol");

        byte[] xls = new byte[1024];
        // Iterate over data and write to sheet
        int rownum = 0;

        if (rownum == 0) {
            Row row = sheet.createRow(rownum++);
            writeHeaders(row, headers, workbook);
        }

        for (Depol depol : list) {
            Row row = sheet.createRow(rownum);
            int cellnum = 0;
            // this line creates a cell in the next column of that row
            while (cellnum <= headers.length - 1) {
                switch (cellnum) {
                case 0:
                    Cell cell = row.createCell(cellnum);
                    cell.setCellValue("C");
                    break;
                case 1:
                    Cell cell1 = row.createCell(cellnum);
                    cell1.setCellValue(depol.getCodeDepol());
                    break;
                case 2:
                    Cell cell2 = row.createCell(cellnum);
                    cell2.setCellValue(depol.getSpecialFlag());
                    break;
                case 3:
                    Cell cell3 = row.createCell(cellnum);
                    cell3.setCellValue(depol.getDesignation());
                    break;
                case 4:
                    Cell cell10 = row.createCell(cellnum);
                    String crrMin = depol.getCrrMin().toString().replace(".", ",");
                    cell10.setCellValue(crrMin);
                    break;
                case 5:
                    Cell cell11 = row.createCell(cellnum);
                    String crrMax = depol.getCrrMax().toString().replace(".", ",");
                    cell11.setCellValue(crrMax);
                    break;
                case 6:
                    Cell cell4 = row.createCell(cellnum);
                    cell4.setCellValue(depol.getMroMin().toString());
                    break;
                case 7:
                    Cell cell5 = row.createCell(cellnum);
                    cell5.setCellValue(depol.getMroMax().toString());
                    break;
                case 8:
                    Cell cell6 = row.createCell(cellnum);
                    String frontalAreaMin = depol.getFrontalAreaMin().toString().replace(".", ",");
                    cell6.setCellValue(frontalAreaMin);
                    break;
                case 9:
                    Cell cell7 = row.createCell(cellnum);
                    String frontalAreaMax = depol.getFrontalAreaMax().toString().replace(".", ",");
                    cell7.setCellValue(frontalAreaMax);
                    break;
                case 10:
                    Cell cell8 = row.createCell(cellnum);
                    String coolingSurfMin = depol.getCoolingSurfaceMin().toString().replace(".", ",");
                    cell8.setCellValue(coolingSurfMin);
                    break;
                case 11:
                    Cell cell9 = row.createCell(cellnum);
                    String coolingSurfMax = depol.getCoolingSurfaceMax().toString().replace(".", ",");
                    cell9.setCellValue(coolingSurfMax);
                    break;
                case 12:
                    Cell cell12 = row.createCell(cellnum);
                    if (depol.getCxMin() != null) {
                        String cxMin = depol.getCxMin().toString().replace(".", ",");
                        cell12.setCellValue(cxMin);
                    }
                    break;
                case 13:
                    Cell cell13 = row.createCell(cellnum);
                    if (depol.getCxMax() != null) {
                        String cxMax = depol.getCxMax().toString().replace(".", ",");
                        cell13.setCellValue(cxMax);
                    }
                    break;
                default:
                    break;
                }
                cellnum++;
            }
            rownum++;

            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (depol != null) {
                traceLog.append(" export DEPOL ").append(depol);
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            workbook.write(baos);
            xls = baos.toByteArray();
            return xls;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        return xls;
    }

    public static byte[] writeMaturityToExcel(String[] headers, List<Maturity> list, String userId) {
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("maturity");

        byte[] xls = new byte[1024];
        // Iterate over data and write to sheet
        int rownum = 0;

        if (rownum == 0) {
            Row row = sheet.createRow(rownum++);
            writeHeaders(row, headers, workbook);
        }

        for (Maturity maturity : list) {
            Row row = sheet.createRow(rownum);
            int cellnum = 0;
            // this line creates a cell in the next column of that row
            while (cellnum <= headers.length - 1) {
                switch (cellnum) {
                case 0:
                    Cell cell = row.createCell(cellnum);
                    cell.setCellValue("C");
                    break;
                case 1:
                    Cell cell1 = row.createCell(cellnum);
                    cell1.setCellValue(maturity.getFamily());
                    break;
                case 2:
                    Cell cell2 = row.createCell(cellnum);
                    cell2.setCellValue(maturity.getBody());
                    break;
                case 3:
                    Cell cell3 = row.createCell(cellnum);
                    cell3.setCellValue(maturity.getMotor());
                    break;
                case 4:
                    Cell cell4 = row.createCell(cellnum);
                    cell4.setCellValue(maturity.getGearbox());
                    break;
                case 5:
                    Cell cell5 = row.createCell(cellnum);
                    cell5.setCellValue(maturity.getIndex());
                    break;
                case 6:
                    Cell cell6 = row.createCell(cellnum);
                    cell6.setCellValue(maturity.getStatus());
                    break;

                default:
                    break;
                }
                cellnum++;
            }
            rownum++;

            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (maturity != null) {
                traceLog.append(" export MATURITY ").append(maturity);
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            workbook.write(baos);
            xls = baos.toByteArray();
            return xls;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        return xls;
    }

    public static byte[] writeDepolImportStatusToExcel(String[] headers, List<DepolDto> list, String userId) {

        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a blank sheet
        XSSFSheet sheet = workbook.createSheet("depol_import_status");

        byte[] xls = new byte[1024];
        // Iterate over data and write to sheet
        int rownum = 0;

        if (rownum == 0) {
            Row row = sheet.createRow(rownum++);
            writeHeaders(row, headers, workbook);
        }
        if (!list.isEmpty()) {
            for (DepolDto depol : list) {
                Row row = sheet.createRow(rownum);
                int cellnum = 0;
                // this line creates a cell in the next column of that row
                while (cellnum <= headers.length - 1) {
                    switch (cellnum) {
                    case 0:
                        Cell cell = row.createCell(cellnum);
                        if (depol.getCodeDepol() != null) {
                            cell.setCellValue(depol.getCodeDepol());
                        }
                        break;
                    case 1:
                        Cell cell1 = row.createCell(cellnum);
                        if (depol.getSpecialFlag() != null) {
                            cell1.setCellValue(depol.getSpecialFlag());
                        }
                        break;
                    case 2:
                        Cell cell2 = row.createCell(cellnum);
                        if (depol.getDesignation() != null) {
                            cell2.setCellValue(depol.getDesignation());
                        }
                        break;
                    case 3:
                        Cell cell3 = row.createCell(cellnum);
                        if (depol.getCrrMin() != null) {
                            String crrMin = depol.getCrrMin().toString();
                            cell3.setCellValue(crrMin);
                        }
                        break;
                    case 4:
                        Cell cell10 = row.createCell(cellnum);
                        if (depol.getCrrMax() != null) {
                            String crrMax = depol.getCrrMax().toString();
                            cell10.setCellValue(crrMax);
                        }
                        break;
                    case 5:
                        Cell cell11 = row.createCell(cellnum);
                        if (depol.getMroMin() != null) {
                            cell11.setCellValue(depol.getMroMin().toString());
                        }
                        break;
                    case 6:
                        Cell cell4 = row.createCell(cellnum);
                        if (depol.getMroMax() != null) {
                            cell4.setCellValue(depol.getMroMax().toString());
                        }
                        break;
                    case 7:
                        Cell cell5 = row.createCell(cellnum);
                        if (depol.getFrontalAreaMin() != null) {
                            String frontalAreaMin = depol.getFrontalAreaMin().toString();
                            cell5.setCellValue(frontalAreaMin);
                        }
                        break;
                    case 8:
                        Cell cell6 = row.createCell(cellnum);
                        if (depol.getFrontalAreaMax() != null) {
                            String frontalAreaMax = depol.getFrontalAreaMax().toString();
                            cell6.setCellValue(frontalAreaMax);
                        }
                        break;
                    case 9:
                        Cell cell7 = row.createCell(cellnum);
                        if (depol.getCoolingSurfaceMin() != null) {
                            String coolingSurfMin = depol.getCoolingSurfaceMin().toString();
                            cell7.setCellValue(coolingSurfMin);
                        }
                        break;
                    case 10:
                        Cell cell8 = row.createCell(cellnum);
                        if (depol.getCoolingSurfaceMax() != null) {
                            String coolingSurfMax = depol.getCoolingSurfaceMax().toString();
                            cell8.setCellValue(coolingSurfMax);
                        }
                        break;
                    case 11:
                        Cell cell9 = row.createCell(cellnum);
                        if (depol.getCxMin() != null) {
                            String cxMin = depol.getCxMin().toString();
                            cell9.setCellValue(cxMin);
                        }
                        break;
                    case 12:
                        Cell cell12 = row.createCell(cellnum);
                        if (depol.getCxMax() != null) {
                            String cxMax = depol.getCxMax().toString();
                            cell12.setCellValue(cxMax);
                        }
                        break;
                    case 13:
                        Cell cell13 = row.createCell(cellnum);
                        if (depol.getStatus() == null) {
                            cell13.setCellValue("OK");
                        } else
                            cell13.setCellValue(depol.getStatus());
                        break;
                    default:
                        break;
                    }
                    cellnum++;
                }
                rownum++;

                StringBuilder traceLog = new StringBuilder();
                traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
                if (depol != null) {
                    traceLog.append(" DEPOL IMPORT Status ").append(depol);
                }
                String trace = traceLog.toString();
                logger.info(trace);
            }
        }
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            workbook.write(baos);
            xls = baos.toByteArray();
            return xls;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        return xls;
    }

    private ExportUtility() {

    }

}
