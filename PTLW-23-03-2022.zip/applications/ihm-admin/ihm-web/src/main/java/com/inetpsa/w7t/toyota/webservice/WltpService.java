/*
 * Creation : 23 août 2017
 */
package com.inetpsa.w7t.toyota.webservice;

import org.seedstack.business.Service;

import com.inetpsa.w7t.toyota.interfaces.rest.RequestRepresentation;
import com.inetpsa.w7t.toyota.interfaces.rest.WltpResponseRepresentation;

@Service
@FunctionalInterface
public interface WltpService {

    WltpResponseRepresentation getEmissions(RequestRepresentation wsRequestObject) throws Exception;

}
