/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Class CycleDetailsRepresentation. It defines the REST Representation of the aggregate cycle details.
 */
@DtoOf(CycleDetails.class)
public class CycleDetailsRepresentation extends AbstractCycleRepresentation {

    /** The profiles. */
    List<CycleProfileRepresentation> profiles;

    /**
     * Gets the profiles.
     *
     * @return the profiles
     */
    public List<CycleProfileRepresentation> getProfiles() {
        return profiles;
    }

    /**
     * Sets the profiles.
     *
     * @param profiles the new profiles
     */
    public void setProfiles(List<CycleProfileRepresentation> profiles) {
        this.profiles = profiles;
    }

}
