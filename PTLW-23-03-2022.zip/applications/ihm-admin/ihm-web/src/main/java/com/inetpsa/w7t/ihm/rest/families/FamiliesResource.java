/*
 * Creation : 4 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.families;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.FamilyService;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.maturityrequest.UserFinder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * The Class FamiliesResource. As the family aggregate is simple enough, we just inject domain repository, without creating a specific Finder. Meaning
 * that the Representation objects are quite identical to entities, on this simple functionality (familyRepresentation is made of Family entity, not
 * combining many aggregates in one complex interface object)
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.FAMILIES)
@Api
public class FamiliesResource {

    /** The Constant PATH_PARAM_CODE. */
    private static final String PATH_PARAM_CODE = "code";

    /** The Constant PATH_PARAM_INDEX. */
    private static final String PATH_PARAM_INDEX = "index";

    /** The Constant FAMILY. */
    private static final String FAMILY = "FAMILY";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The family finder. */
    @Inject
    FamilyFinder familyFinder;

    /** The family service. */
    @Inject
    FamilyService familyService;

    /** The user finder. */
    @Inject
    UserFinder userFinder;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /**
     * Respond with a {@link CollectionRepresentation}, a list of {@link FamilyRepresentation}, filtered by the {@link FamilyFilter} by family code or
     * vehicle category.
     *
     * @param filter the filter to filter the list by family code or vehicle category
     * @return the list of families
     */
    @Rel(value = CatalogRels.FAMILIES, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    @ApiOperation(value = "test", response = CollectionRepresentation.class)
    public Response families(@BeanParam FamilyFilter filter) {
        return Response.ok(familyFinder.getAllFamilies()).build();
    }

    /**
     * Respond with a {@link FamilyDetailsRepresentation} of the specified id, or 404 is not found.
     *
     * @param id the family id
     * @return the family details if present, or else HTTP 404
     */
    @Path("{" + CatalogRels.FAMILY + "}")
    @Rel(value = CatalogRels.FAMILY, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response findById(@PathParam(CatalogRels.FAMILY) String id) {
        Optional<FamilyDetailsRepresentation> familyDetails = familyFinder.byId(id);

        if (familyDetails.isPresent())
            return Response.ok(familyDetails.get()).build();
        return Response.status(Response.Status.NOT_FOUND).entity("").build();
    }

    /**
     * Respond with a {@link FamilyDetailsRepresentation} of the specified family code and index, or 404 is not found.
     *
     * @param code the family code
     * @param index the family index
     * @return the family details if present, or else HTTP 404
     */
    @Path("{" + PATH_PARAM_CODE + "}/{" + PATH_PARAM_INDEX + "}")
    @Rel(value = CatalogRels.FAMILY_CODE_INDEX, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response findByCodeAndIndex(@PathParam(PATH_PARAM_CODE) String code, @PathParam(PATH_PARAM_INDEX) Integer index) {
        Optional<FamilyDetailsRepresentation> familyDetails = familyFinder.byCodeAndIndex(code, index);

        if (familyDetails.isPresent())
            return Response.ok(familyDetails.get()).build();
        return Response.status(Response.Status.NOT_FOUND).entity("").build();
    }

    /**
     * Family import.
     *
     * @param inputStream the input stream
     * @param fileDisposition the file disposition
     * @param forceUpdate the force update
     * @return the response
     */
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDisposition,
            @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate) {
        try {
            FileInputValidator.isNotNull(inputStream);
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new FamilyValidationException(FamilyErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end

            if (isFileUploadInProcess()) {
                Object[] errMsg = { "k" };
                throw new FamilyValidationException(FamilyErrorCode.SOMEONE_IMPORTING_DATA, errMsg);
            }
            userFinder.updateStatus(true, FAMILY);
            CollectionRepresentation families = familyService.upload(inputStream, forceUpdate);
            userFinder.updateStatus(false, FAMILY);
            return Response.ok(families).build();
        } catch (FamilyValidationException e) {
            if (e.getErrorCode() instanceof FamilyErrorCode) {
                FamilyErrorCode fec = (FamilyErrorCode) e.getErrorCode();
                if (fec.getDescription().contains(FamilyErrorCode.INDUS_MAINTAINANCE_ERROR.getDescription())) {
                    logger.error(e.getMessage(), e);
                    throw e;
                }
            }
            userFinder.updateStatus(false, FAMILY);
            logger.error(e.getMessage(), e);
            throw e;
        } catch (RuntimeException | IOException e) {
            userFinder.updateStatus(false, FAMILY);
            FamilyValidationException fve = new FamilyValidationException(FamilyErrorCode.UNKNOWN_EXCEPTION, null);
            fve.initCause(e);
            logger.error(e.getMessage(), e);
            throw fve;
        }
    }

    /**
     * Checks if is file upload in process.
     *
     * @return true, if is file upload in process
     */
    private boolean isFileUploadInProcess() {
        return userFinder.getUser(FAMILY).getStatus();
    }

}
