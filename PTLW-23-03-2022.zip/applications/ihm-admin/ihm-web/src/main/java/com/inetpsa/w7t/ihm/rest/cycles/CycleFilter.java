/*
 * Creation : 10 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import javax.ws.rs.QueryParam;

/**
 * The Class CycleFilter. It defines the parameters a filter consists.
 */
public class CycleFilter {

    /** The code. */
    @QueryParam("code")
    private String code;

    /** The phase. */
    @QueryParam("phase")
    private String phase;

    /** The exact. */
    private boolean exact;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Checks if is exact.
     *
     * @return true, if is exact
     */
    public boolean isExact() {
        return exact;
    }

    /**
     * Sets the exact.
     *
     * @param exact the new exact
     */
    public void setExact(boolean exact) {
        this.exact = exact;
    }
}
