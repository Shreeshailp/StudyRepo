/*
 * Creation : 21 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class CollectionDto.
 */
public class CollectionDto {

    /** The collection id. */
    private String collectionId;

    /** The collection name. */
    private String collectionName;

    /** The user id. */
    private String userId;

    /** The requests. */
    private List<CollectionRequestDto> requests = new ArrayList<>();

    /**
     * Gets the collection id.
     *
     * @return the collection id
     */
    public String getCollectionId() {
        return collectionId;
    }

    /**
     * Sets the collection id.
     *
     * @param collectionId the new collection id
     */
    public void setCollectionId(String collectionId) {
        this.collectionId = collectionId;
    }

    /**
     * Gets the collection name.
     *
     * @return the collection name
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * Sets the collection name.
     *
     * @param collectionName the new collection name
     */
    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Adds the requests.
     *
     * @param requestDto the request dto
     */
    public void addRequests(CollectionRequestDto requestDto) {
        requests.add(requestDto);
    }

    /**
     * Gets the requests.
     *
     * @return the requests
     */
    public List<CollectionRequestDto> getRequests() {
        return requests;
    }

    /**
     * Sets the requests.
     *
     * @param requests the new requests
     */
    public void setRequests(List<CollectionRequestDto> requests) {
        this.requests = requests;
    }

}
