/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface CyclesFinder. This finder is used for efficient retrieval of data specific to our REST interfaces (i.e.
 * {@link CollectionRepresentation} and {@link CycleDetailsRepresentation})
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface CyclesFinder {

    /**
     * To retrieve the representation of all {@link Cycle} entities.
     *
     * @param filter the filter
     * @return the cycles representation
     */
    CollectionRepresentation all(CycleFilter filter);

    /**
     * To retrieve a specific {@link CycleDetails} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return the cycle details representation
     */
    Optional<CycleDetailsRepresentation> byId(@IsUUID String id);

    /**
     * By generated cycle id.
     *
     * @param generatedCycleid the generated cycleid
     * @return the collection representation
     */
    CollectionRepresentation byGeneratedCycleId(@IsUUID String generatedCycleid);
}
