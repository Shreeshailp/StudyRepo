/*
 * Creation : 3 Sep 2021
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

public class UWCCollectionRequestDto {

    private String collectionRequestId;

    private String requestName;

    private UnitarySimulationWltpHubRequestRepresentation request;

    public String getCollectionRequestId() {
        return collectionRequestId;
    }

    public void setCollectionRequestId(String collectionRequestId) {
        this.collectionRequestId = collectionRequestId;
    }

    public String getRequestName() {
        return requestName;
    }

    public void setRequestName(String requestName) {
        this.requestName = requestName;
    }

    public UnitarySimulationWltpHubRequestRepresentation getRequest() {
        return request;
    }

    public void setRequest(UnitarySimulationWltpHubRequestRepresentation request) {
        this.request = request;
    }

}
