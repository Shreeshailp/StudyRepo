package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.TVVParserService;
import com.inetpsa.w7t.application.services.TVVService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CompleteFlagRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVErrorCode;
import com.inetpsa.w7t.domains.tvv.exceptions.TVVException;
import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TvvDto;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class TVVServiceImpl implements TVVService {

    @Inject
    private TVVParserService tvvParserService;

    @Inject
    private TVVRepository tVVRepository;

    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    @Inject
    private Factory<TVV> tvvFactory;

    @Inject
    private CompleteFlagRepository completeFlagRepository;

    @Inject
    private VehicleCategoryRepository vehicleCategoryRepository;

    @Inject
    DepolRepository depolRepository;

    @Inject
    UserService userService;

    @Override
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException, TVVException {

        List<TvvDto> tvvDtos = tvvParserService.parse(inputStream);
        boolean isTvvExists = false;
        int tvvCount = 0;
        if (!forceUpdate) {
            for (TvvDto tvvDto : tvvDtos) {
                isTvvExists = checkTVVExistence(tvvDto);
                if (isTvvExists) {
                    tvvCount++;
                }

            }
            if (tvvCount > 0) {
                logger.info("There are total of " + tvvCount + " TVV records found for modification ");
                String[] repeatTvv = { String.valueOf(tvvCount) };
                throw new TVVException(TVVErrorCode.TVV_ALREADY_EXISTS, repeatTvv);
            }
        }

        List<TVV> tvvList = importTvv(tvvDtos);

        CollectionRepresentation tvvCollection = new CollectionRepresentation(tvvList.size(), false);

        tvvCollection.self(relRegistry.uri(CatalogRels.IMPORTTVV).templated());
        tvvCollection.link("find", relRegistry.uri(CatalogRels.IMPORTTVV).templated());
        tvvCollection.embedded(CatalogRels.IMPORTTVV, tvvList);

        return tvvCollection;
    }

    private List<TVV> importTvv(List<TvvDto> tvvDtos) {
        List<TVV> tvvList = new ArrayList<>();
        for (TvvDto tvvDto : tvvDtos) {
            // Lot 10 changes for tvv import validation check for condition with vmax < tvv_max_speed_bottom_value

            if (tvvDto.getTvvMaxspeed() != null && !tVVRepository.existsAboveBottomValue(tvvDto.getTvvMaxspeed())) {
                // display error message
                logger.error("erreur (vehicle family {}, T1A {}, T1B {}, TVV {}): max_speed trop faible, l'import n'a pas été effectué",
                        tvvDto.getVehicleFamily(), tvvDto.getT1AValue(), tvvDto.getT1BValue(), tvvDto.getTvvDesignation());
                String[] repeatTvv = { tvvDto.getVehicleFamily(), tvvDto.getT1AValue(), tvvDto.getT1BValue(), tvvDto.getTvvDesignation() };
                throw new TVVException(TVVErrorCode.TVV_MAX_SPEED_ERROR, repeatTvv);
            }

            TVV tvv = new TVV();
            if (!tVVRepository.exists(tvvDto.getVehicleFamily(), tvvDto.getT1AValue(), tvvDto.getT1BValue())) {
                tvv = tvvFactory.create();
                tvv = mergeAggregateWithDto(tvvDto, tvv);
                tvv = tVVRepository.save(tvv);
            } else {
                List<TVV> list = tVVRepository.tvvByUniqueFields(tvvDto.getVehicleFamily(), tvvDto.getT1AValue(), tvvDto.getT1BValue());
                Optional<TVV> optTvv = list.stream().findFirst();
                if (optTvv.isPresent()) {
                    tvv = optTvv.get();
                    tvv = mergeAggregateWithDto(tvvDto, tvv);
                    tvv = tVVRepository.save(tvv);
                }
            }
            tvvList.add(tvv);
            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (tvv != null) {
                traceLog.append(" Import TVV ").append(tvv).toString();
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }

        return tvvList;
    }

    private TVV mergeAggregateWithDto(TvvDto tvvDto, TVV tvv) {
        tvv.setVehicleFamily(tvvDto.getVehicleFamily());
        tvv.setT1AValue(tvvDto.getT1AValue());
        tvv.setT1BValue(tvvDto.getT1BValue());
        tvv.setTvvDesignation(tvvDto.getTvvDesignation());
        tvv.setTvvAf(tvvDto.getTvvAf());
        tvv.setTvvHeigth(tvvDto.getTvvHeigth());
        tvv.setTvvWidth(tvvDto.getTvvWidth());
        tvv.setTvvMaxspeed(tvvDto.getTvvMaxspeed());
        tvv.setTvvScxBase(tvvDto.getTvvScxBase());
        if (tvvDto.getTvvCompleteFlag() != null) {
            checkValidCompleteFlagExists(tvvDto.getTvvCompleteFlag(), tvvDto.getLineNumber());
            tvv.setTvvCompleteFlag(tvvDto.getTvvCompleteFlag());
        }
        if (tvvDto.getTvvVehicleCategory() != null) {
            checkValidCategoryExists(tvvDto.getTvvVehicleCategory(), tvvDto.getLineNumber());
            tvv.setTvvVehicleCategory(tvvDto.getTvvVehicleCategory());
        }

        if (tvvDto.getTvvCodeDepol() != null) {
            checkValidCodeDepolExists(tvvDto.getTvvCodeDepol(), tvvDto.getLineNumber());
            tvv.setTvvCodeDepol(tvvDto.getTvvCodeDepol());
        } else {
            tvv.setTvvCodeDepol(null);
        }

        return tvv;

    }

    private Boolean checkTVVExistence(TvvDto tvv) {
        return tVVRepository.exists(tvv.getVehicleFamily(), tvv.getT1AValue(), tvv.getT1BValue());

    }

    private boolean checkValidCompleteFlagExists(String completeFlagCode, int lineNumber) {
        if (!completeFlagRepository.exists(completeFlagCode)) {
            Integer[] lineNum = { lineNumber };
            throw new TVVException(TVVErrorCode.TVV_INVALID_COMPLETE_FLAG, lineNum);
        }
        return true;
    }

    private boolean checkValidCategoryExists(String categoryCode, int lineNumber) {
        if (!vehicleCategoryRepository.exists(categoryCode)) {
            Integer[] lineNum = { lineNumber };
            throw new TVVException(TVVErrorCode.TVV_INVALID_CATEGORY, lineNum);
        }
        return true;
    }

    private boolean checkValidCodeDepolExists(String codeDepol, int lineNumber) {
        if (!depolRepository.exists(codeDepol)) {
            Integer[] lineNum = { lineNumber };
            throw new TVVException(TVVErrorCode.TVV_INVALID_CODE_DEPOL, lineNum);
        }
        return true;
    }
}
