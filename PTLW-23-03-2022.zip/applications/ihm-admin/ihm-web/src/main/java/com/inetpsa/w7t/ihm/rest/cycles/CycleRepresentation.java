/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.cycles.model.Cycle;

/**
 * The Class CycleRepresentation. It defines the REST Representation of the entity cycle.
 */
@DtoOf(Cycle.class)
public class CycleRepresentation extends AbstractCycleRepresentation {
}
