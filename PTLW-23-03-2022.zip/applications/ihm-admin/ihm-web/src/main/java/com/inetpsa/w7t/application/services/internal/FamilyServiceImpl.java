/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.application.services.internal;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

import javax.cache.Cache;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.MultiMap;
import org.javatuples.KeyValue;
import org.javatuples.Pair;
import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.FamilyParserService;
import com.inetpsa.w7t.application.services.FamilyService;
import com.inetpsa.w7t.application.services.FamilyTabCheckService;
import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryDto;
import com.inetpsa.w7t.domains.change.history.services.ChangeHistoryService;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.TestVehicleRepository;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyAdditionalDataRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlagDto;
import com.inetpsa.w7t.domains.families.model.details.MeasureValue;
import com.inetpsa.w7t.domains.families.model.details.PhysicalQuantityValue;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;
import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalDataDto;
import com.inetpsa.w7t.domains.families.model.family.FamilyDto;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyReferencesPolicy;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyFinder;
import com.inetpsa.w7t.ihm.rest.families.FamilyRepresentation;
import com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder;

/**
 * The Class FamilyServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class FamilyServiceImpl implements FamilyService {

    /** The Constant LINE_NUMBER. */
    private static final String LINE_NUMBER = "lineNumber";

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The User service. */
    @Inject
    UserService userService;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The factory. */
    @Inject
    private Factory<FamilyDetails> familyFactory;

    /** The test vehicle factory. */
    @Inject
    private Factory<TestVehicle> testVehicleFactory;

    /** The generic family repo. */
    @Inject
    @Jpa
    private Repository<FamilyDetails, UUID> familyRepo;

    /** The test vehicle repo. */
    @Inject
    private TestVehicleRepository testVehicleRepo;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The cycle repository. */
    @Inject
    private CycleRepository cycleRepository;

    /** The test vehicle type repository. */
    @Inject
    private TestVehicleTypeRepository testVehicleTypeRepository;

    /** The physical quantity type repository. */
    @Inject
    private PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The cycle phase repository. */
    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    /** The family parser service. */
    @Inject
    private FamilyParserService familyParserService;

    /** The family references policy. */
    @Inject
    private FamilyReferencesPolicy familyReferencesPolicy;

    /** The family finder. */
    @Inject
    FamilyFinder familyFinder;

    /** The vehicle type finder. */
    @Inject
    VehicleTypeFinder vehicleTypeFinder;

    /** The vehicle boundaries pair cache. */
    @SuppressWarnings("rawtypes")
    @Inject
    @Named("vehicleBoundariesPairCache")
    private Cache vehicleBoundariesPairCache;

    /** The vehicle boundaries list cache. */
    @SuppressWarnings("rawtypes")
    @Inject
    @Named("vehicleBoundariesListCache")
    private Cache vehicleBoundariesListCache;

    /** The change history service. */
    @Inject
    private ChangeHistoryService changeHistoryService;

    /** The generic family repo. */
    @Inject
    @Jpa
    private Repository<FamilyAdditionalData, UUID> familyAdditionalDataRepo;

    /** The factory. */
    @Inject
    private Factory<FamilyAdditionalData> familyAdditionalDataFactory;

    /** The family additional data repository. */
    @Inject
    private FamilyAdditionalDataRepository familyAdditionalDataRepository;

    /** The family tab check service. */
    @Inject
    private FamilyTabCheckService familyTabCheckService;

    /** The Constant TEST_VEHICLE_TYPE. */
    private static final String TEST_VEHICLE_TYPE = "testVehicleType";

    /** The Constant VALIDATED. */
    private static final String VALIDATED = "V";

    /** The Constant CALCULATION_TYPE. */
    private static final String CALCULATION_TYPE = "calculationType";

    /** The Constant FAMILY. */
    private static final String FAMILY = "FAMILY";

    /** The Constant T8C. */
    private static final String T8C = "T8C";

    /** The Constant T8D. */
    private static final String T8D = "T8D";

    /** The Constant STATUS. */
    private static final String STATUS = "I";

    /** The Constant BLOCKED. */
    private static final Boolean BLOCKED = false;

    /** The Constant VMED. */
    private static final String VMED = "VMED";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyService#upload(java.io.InputStream, java.lang.Boolean)
     */
    @Override
    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException {

        List<FamilyDto> families = familyParserService.parse(inputStream);

        if (!forceUpdate)
            families.forEach(fam -> checkExistence(fam));

        vehicleBoundariesPairCache.removeAll();
        vehicleBoundariesListCache.removeAll();

        List<FamilyDetails> familyEntities = importFamilies(families, forceUpdate);

        List<Family> familyList = new ArrayList<>();

        for (FamilyDetails details : familyEntities) {
            Optional<Family> family = familyRepository.byCodeAndIndex(details.getCode(), details.getIndex());
            if (family.isPresent()) {
                familyList.add(family.get());
            }
        }

        List<FamilyRepresentation> familyRepresentaionList = fluentAssembler.assemble(familyList).with(WltpModelMapper.class)
                .to(FamilyRepresentation.class);

        familyRepresentaionList.stream().forEach(family -> {
            family.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, family.getGuid()));
            family.link(CatalogRels.FAMILIES, relRegistry.uri(CatalogRels.FAMILIES).set(CatalogRels.FAMILIES, family.getRoadLoad()));
        });

        familyRepresentaionList.stream().forEach(family -> {
            family.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, family.getGuid()));
        });
        CollectionRepresentation familiesList = new CollectionRepresentation(familyList.size(), false);

        familiesList.self(relRegistry.uri(CatalogRels.FAMILIES).templated());
        familiesList.link("find", relRegistry.uri(CatalogRels.FAMILY).templated());
        familiesList.embedded(CatalogRels.FAMILIES, familyList);

        return familiesList;

    }

    /**
     * Check existence.
     *
     * @param fam the fam
     */
    private void checkExistence(FamilyDto fam) {
        if (familyRepository.exists(fam.getCode(), fam.getIndex())) {
            String index = String.valueOf(fam.getIndex());
            if (index != null && !index.isEmpty() && index.length() == 1) {
                index = "0" + index;
            }
            String[] repeatFam = { fam.getCode(), index };
            throw new FamilyValidationException(FamilyErrorCode.FAMILY_INDEX_ALREADY_EXISTS, repeatFam);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyService#importFamilies(java.util.List, java.lang.Boolean)
     */
    @Override
    @Transactional
    public List<FamilyDetails> importFamilies(List<FamilyDto> families, Boolean forceUpdate) {

        List<FamilyDetails> familyDetailsList = new ArrayList<>();
        for (FamilyDto familyDto : families) {
            FamilyDetails familyDetails = new FamilyDetails();
            if (!familyRepository.exists(familyDto.getCode(), familyDto.getIndex())) {
                familyDetails = familyFactory.create();
                familyDetails.setCreatedBy(userService.getUserId());
                familyDetails.setCreatedOn(getDate());
                familyDetails.setStatus(STATUS);
                familyDetails.setBlocked(BLOCKED);
                familyDto.setStatus(STATUS);
                familyDto.setBlocked(BLOCKED);
                familyDetails = mergeAggregateWithDto(familyDto, familyDetails, forceUpdate);
                if (familyDetails != null) {
                    insertIntoCheckFlag(familyDto);
                }
                saveToChangeHistory(familyDto);
            } else {
                Optional<FamilyDetails> optFamily = familyRepository.byCodeAndIndexDetails(familyDto.getCode(), familyDto.getIndex());
                if (optFamily.isPresent()) {
                    familyDetails = optFamily.get();
                    isFamilyBlocked(familyDetails.getBlocked());
                    checkFamilyStatus(familyDetails.getStatus());
                    familyDetails = mergeAggregateWithDto(familyDto, familyDetails, forceUpdate);
                    saveToChangeHistory(familyDto);
                }
            }
            familyDetailsList.add(familyDetails);

            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();

            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (familyDetails != null) {
                traceLog.append(" Import Family Code ").append(familyDetails.getCode()).append(" Index ").append(familyDetails.getIndex()).toString();
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }

        return familyDetailsList;
    }

    /**
     * Insert into check flag.
     *
     * @param familyDto the family dto
     */
    private void insertIntoCheckFlag(FamilyDto familyDto) {
        String[] tabs = new String[] { "REF", "CHAR", "VLOW", "VHIGH" };
        for (String tab : tabs) {
            FamilyTabCheckFlagDto familyTabCheckFlagDto = new FamilyTabCheckFlagDto();
            familyTabCheckFlagDto.setT8C(familyDto.getCode());
            familyTabCheckFlagDto.setT8D(familyDto.getIndex().toString());
            familyTabCheckFlagDto.setTabId(tab);
            familyTabCheckFlagDto.setCheckFlag(false);
            familyTabCheckService.insertFamilyTabCheck(familyTabCheckFlagDto);
        }
        for (Map<String, Object> vehicle : familyDto.getTestVehicles()) {
            if (vehicle.get(TEST_VEHICLE_TYPE).toString().equalsIgnoreCase(VMED)) {
                FamilyTabCheckFlagDto familyTabCheckFlagDto = new FamilyTabCheckFlagDto();
                familyTabCheckFlagDto.setT8C(familyDto.getCode());
                familyTabCheckFlagDto.setT8D(familyDto.getIndex().toString());
                familyTabCheckFlagDto.setTabId(VMED);
                familyTabCheckFlagDto.setCheckFlag(false);
                familyTabCheckService.insertFamilyTabCheck(familyTabCheckFlagDto);
                break;
            }
        }
    }

    /**
     * Save to change history.
     *
     * @param forceUpdate the force update
     * @param familyDto the family dto
     */
    @SuppressWarnings("unchecked")
    private void saveToChangeHistory(FamilyDto familyDto) {
        ChangeHistoryDto changeHistoryDto = new ChangeHistoryDto();
        changeHistoryDto.setDataCategory(FAMILY);
        changeHistoryDto.setDataId(T8C + familyDto.getCode() + "-" + T8D + familyDto.getIndex());
        changeHistoryDto.setUser(userService.getUserId());
        List<String> propertyNameList = changeHistoryService.getDeclaredFieldsOfAnObject(FamilyDto.class);
        List<String> parametersTobeRemoved = Arrays.asList("code", "index", "quantities", "cycles", "testVehicles", "createdBy", "createdOn",
                LINE_NUMBER);
        propertyNameList.removeAll(parametersTobeRemoved);
        changeHistoryService.saveChangeHistoryEntity(changeHistoryDto, familyDto, propertyNameList);
        List<String> characteristicsKeySet = new ArrayList<>();
        characteristicsKeySet.addAll(familyDto.getQuantities().keySet());
        List<ChangeHistoryDto> dtoList = new ArrayList<>();
        getCharacteristicsData(familyDto, characteristicsKeySet, dtoList);
        getMeasuredVehicleResults(familyDto, dtoList);
        changeHistoryService.saveListOfChangeHistoryEntities(dtoList);
    }

    /**
     * Gets the characteristics data.
     *
     * @param familyDto the family dto
     * @param characteristicsKeySet the characteristics key set
     * @param dtoList the dto list
     * @return the characteristics data
     */
    @SuppressWarnings("unchecked")
    private void getCharacteristicsData(FamilyDto familyDto, List<String> characteristicsKeySet, List<ChangeHistoryDto> dtoList) {
        for (String key : characteristicsKeySet) {
            List<Map<String, Double>> list = (List<Map<String, Double>>) familyDto.getQuantities().get(key);
            Map<String, Double> map = list.get(0);
            Set<String> mapKey = map.keySet();
            for (String key1 : mapKey) {
                ChangeHistoryDto historyDto = new ChangeHistoryDto();
                historyDto.setDataCategory(FAMILY);
                historyDto.setDataId(T8C + familyDto.getCode() + "-" + T8D + familyDto.getIndex() + "-" + key + "-" + key1);
                historyDto.setUser(userService.getUserId());
                historyDto.setNewValue(String.valueOf(map.get(key1)));
                dtoList.add(historyDto);

            }

        }
    }

    /**
     * Gets the measured vehicle results.
     *
     * @param familyDto the family dto
     * @param dtoList the dto list
     * @return the measured vehicle results
     */
    @SuppressWarnings("unchecked")
    private void getMeasuredVehicleResults(FamilyDto familyDto, List<ChangeHistoryDto> dtoList) {
        List<Map<String, Object>> measuredVehicleListMap = familyDto.getTestVehicles();

        for (Map<String, Object> map : measuredVehicleListMap) {
            List<String> measuredVehicleKeySet = new ArrayList<>();
            measuredVehicleKeySet.addAll(map.keySet());
            for (String measuredVehicleKey : measuredVehicleKeySet) {
                Object obj = map.get(measuredVehicleKey);
                if (obj instanceof Map) {
                    Map<String, Object> measuredValueMap = (Map<String, Object>) map.get(measuredVehicleKey);
                    List<String> measuredValueKeySet = new ArrayList<>();
                    measuredValueKeySet.addAll(measuredValueMap.keySet());
                    for (String key : measuredValueKeySet) {
                        ChangeHistoryDto historyDto = new ChangeHistoryDto();
                        historyDto.setDataCategory(FAMILY);
                        historyDto.setDataId(T8C + familyDto.getCode() + "-" + T8D + familyDto.getIndex() + "-" + map.get(TEST_VEHICLE_TYPE) + "-"
                                + key + "-" + map.get(CALCULATION_TYPE));
                        historyDto.setUser(userService.getUserId());
                        historyDto.setNewValue(String.valueOf(measuredValueMap.get(key)));
                        dtoList.add(historyDto);
                    }
                }
            }
        }
    }

    /**
     * Checks if is family blocked.
     *
     * @param blocked the blocked
     */
    private void isFamilyBlocked(Boolean blocked) {
        if (blocked != null && blocked.equals(true)) {
            throw new FamilyValidationException(FamilyErrorCode.FAMILY_BLOCKED_ERROR, null);
        }
    }

    /**
     * Check family status.
     *
     * @param status the status
     */
    private void checkFamilyStatus(String status) {
        if (status != null && !status.isEmpty() && status.equalsIgnoreCase(VALIDATED)) {
            throw new FamilyValidationException(FamilyErrorCode.FAMILY_VALIDATED_ERROR, null);
        }

    }

    /**
     * Merge aggregate with dto.
     *
     * @param familyDto the family dto
     * @param family the family
     * @param forceUpdate the force update
     * @return the family details
     */
    private FamilyDetails mergeAggregateWithDto(FamilyDto familyDto, FamilyDetails family, Boolean forceUpdate) {
        family.setCode(familyDto.getCode());
        family.setRoadLoad(familyDto.getRoadLoad());
        family.setPmax(familyDto.getPmax());
        family.setCycles(getCycles(familyDto));
        family.setIndex(familyDto.getIndex());
        family.setLabel(familyDto.getLabel());
        family.setType(familyDto.getVehicleType());
        family.setLineNumber(familyDto.getLineNumber());

        boolean isValid = familyReferencesPolicy.isValid(family);

        if (isValid) {
            FamilyDetails savedfamily = familyRepo.save(family);
            getTestvehicles(familyDto, savedfamily, forceUpdate);

            return savedfamily;
        }
        return null;
    }

    /**
     * Gets the cycles.
     *
     * @param familyDto the family dto
     * @return the cycles
     */
    private List<UUID> getCycles(FamilyDto familyDto) {
        return familyDto.getCycles().stream().map(cycleRepository::byCode).filter(Optional::isPresent).map(Optional::get).map(Cycle::getGuid)
                .collect(toList());
    }

    /**
     * Gets the testvehicles.
     *
     * @param familyDto the family dto
     * @param family the family
     * @param forceUpdate the force update
     * @return the testvehicles
     */
    private void getTestvehicles(FamilyDto familyDto, FamilyDetails family, Boolean forceUpdate) {
        List<TestVehicle> testVehicles = new ArrayList<>();
        Map<UUID, Set<PhysicalQuantityValue>> physicalQty = new HashMap<>();
        Map<UUID, List<MeasureValue>> measureValues = new HashMap<>();
        Set<UUID> vehicleTypes = new HashSet<>();

        if (forceUpdate) {
            family.getVehicles().forEach(testVehicleRepo::delete);
        }

        /**
         * Vref issue Fix need to change
         */
        if (familyDto.getQuantities().containsKey("VREF")) {
            Map<String, Object> vrefMap = new HashMap<>();
            vrefMap.put(CALCULATION_TYPE, "");
            vrefMap.put("measuresValues", "");
            vrefMap.put(TEST_VEHICLE_TYPE, "VREF");
            familyDto.getTestVehicles().add(vrefMap);
        }

        for (Map<String, Object> testVehicle : familyDto.getTestVehicles()) {
            Integer lineNo = 0;
            if (testVehicle.get(LINE_NUMBER) != null)
                lineNo = (Integer) testVehicle.get(LINE_NUMBER);

            Optional<TestVehicleType> testVehicleType = testVehicleTypeRepository.byCode(testVehicle.get(TEST_VEHICLE_TYPE).toString());
            if (testVehicleType.isPresent()) {
                UUID typeKey = testVehicleType.get().getGuid();
                vehicleTypes.add(typeKey);

                if (physicalQty.containsKey(typeKey)) {
                    physicalQty.get(typeKey).addAll(getQuantityValues(familyDto, testVehicle));
                } else {
                    physicalQty.put(typeKey, getQuantityValues(familyDto, testVehicle));
                }

                if (!testVehicle.get(TEST_VEHICLE_TYPE).equals("VREF")) { // Vref issue Fix need to change
                    if (measureValues.containsKey(typeKey)) {
                        measureValues.get(typeKey).addAll(getMeasures(testVehicle));
                    } else {
                        measureValues.put(typeKey, getMeasures(testVehicle));
                    }
                }
            } else {
                /** RG43 The test vehicle type must exist in the database. If not, the system will stop the process **/
                Integer[] lineNumber = { lineNo };
                throw new FamilyValidationException(FamilyErrorCode.VEHICLE_TYPE_ESS_NOT_EXISTS, lineNumber);
            }
        }

        for (UUID type : vehicleTypes) {
            TestVehicle vehicle = testVehicleFactory.create();
            vehicle.setType(type);
            if (forceUpdate && testVehicles.contains(vehicle))
                vehicle = testVehicles.get(testVehicles.indexOf(vehicle));
            vehicle.setQuantities(new ArrayList<>(physicalQty.get(type)));
            vehicle.setMeasures(measureValues.get(type));
            if (!forceUpdate || vehicle.getFamilyDetails() == null)
                vehicle.setFamilyDetails(familyRepo.load(family.getGuid()));
            testVehicles.add(vehicle);
        }
        testVehicles.forEach(testVehicleRepo::save);
    }

    /**
     * Gets the quantity values.
     *
     * @param familyDto the family dto
     * @param testVehicle the test vehicle
     * @return the quantity values
     */
    private Set<PhysicalQuantityValue> getQuantityValues(FamilyDto familyDto, Map<String, Object> testVehicle) {
        MultiMap map = familyDto.getQuantities();

        Function<Pair<Double, PhysicalQuantityType>, PhysicalQuantityValue> builder = p -> {
            PhysicalQuantityValue pqv = new PhysicalQuantityValue();
            pqv.setType(p.getValue1().getGuid());
            pqv.setValue(p.getValue0());
            return pqv;
        };

        return ((Collection<?>) map.get(testVehicle.get(TEST_VEHICLE_TYPE).toString())).stream().map(o -> (Map<?, ?>) o).map(Map::entrySet)
                .map(Set::stream).flatMap(Function.identity())
                .map(e -> Pair.<Double, PhysicalQuantityType>with((Double) e.getValue(),
                        physicalQuantityTypeRepository.byCode((String) e.getKey()).orElse(null)))
                .filter(t -> t.getValue1() != null).map(builder).collect(toSet());
    }

    /**
     * Gets the measures.
     *
     * @param testVehicle the test vehicle
     * @return the measures
     */
    private List<MeasureValue> getMeasures(Map<String, Object> testVehicle) {

        UUID measureTypeId = measureTypeRepository.byCode((String) testVehicle.get(CALCULATION_TYPE))
                .orElseThrow(() -> new FamilyValidationException(FamilyErrorCode.CALC_TYPE_NOT_EXISTS,
                        new Integer[] { Optional.ofNullable((Integer) testVehicle.get(LINE_NUMBER)).orElse(0) }))
                .getGuid();

        return ((Map<?, ?>) testVehicle.get("measuresValues")).entrySet().stream()
                .map(e -> KeyValue.<String, Double>with((String) e.getKey(), (Double) e.getValue())).filter(kv -> kv.getValue() != null)
                .map(kv -> KeyValue.<CyclePhase, Double>with(cyclePhaseRepository.byCode(kv.getKey()).orElse(null), kv.getValue()))
                .filter(kv -> kv.getKey() != null).map(kv -> {
                    MeasureValue mv = new MeasureValue();
                    mv.setGuid(UUID.randomUUID());
                    mv.setPhase(kv.getKey().getGuid());
                    mv.setType(measureTypeId);
                    mv.setValue(kv.getValue());
                    return mv;
                }).collect(toList());
    }

    /**
     * Gets the date.
     *
     * @return the date
     */
    private String getDate() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    /**
     * Convert to date.
     *
     * @param date the date
     * @return the java.sql. date
     * @throws ParseException the parse exception
     */
    // date convert
    public static java.sql.Date convertToDate(String date) throws ParseException {
        if (date != null && !date.isEmpty()) {
            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
            java.util.Date parsed = format.parse(date);
            return new java.sql.Date(parsed.getTime());
        }
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyService#saveUpdateFamilyAdditionalData(java.lang.String, java.lang.String,
     *      com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalDataDto)
     */
    @Override
    public CollectionRepresentation saveUpdateFamilyAdditionalData(String t8c, String t8d, FamilyAdditionalDataDto familyAdditionalDataDto) {
        FamilyAdditionalData familyAdditionalData = null;
        try {
            familyAdditionalDataDto.setT8c(t8c);
            familyAdditionalDataDto.setT8d(t8d);
            Optional<Family> familyData = familyRepository.byCodeAndIndex(t8c, Integer.parseInt(t8d));
            if (familyData.isPresent()) {
                familyAdditionalDataDto.setFamily(familyData.get());
            }
            if (!familyAdditionalDataRepository.exists(familyAdditionalDataDto.getT8c(), familyAdditionalDataDto.getT8d())) {
                familyAdditionalData = familyAdditionalDataFactory.create();
                familyAdditionalData = convertFamilyAdditionalDataDtoToEntity(familyAdditionalData, familyAdditionalDataDto);
                familyAdditionalDataRepo.persist(familyAdditionalData);
                logger.info("Created the family additional data with T8C[{}], T8D[{}] and FAM_ID[{}]", t8c, t8d,
                        familyAdditionalData.getFamily().getGuid());
            } else {
                Optional<FamilyAdditionalData> optFamily = familyAdditionalDataRepository.byCodeAndIndexDetails(familyAdditionalDataDto.getT8c(),
                        familyAdditionalDataDto.getT8d());
                if (optFamily.isPresent()) {
                    familyAdditionalData = optFamily.get();
                    familyAdditionalData = convertFamilyAdditionalDataDtoToEntity(familyAdditionalData, familyAdditionalDataDto);
                    familyAdditionalDataRepository.updateByT8cT8DAndFamilyId(t8c, t8d, familyAdditionalData);

                    logger.info("Updated the family additional data by T8C[{}], T8D[{}] and FAM_ID[{}]", t8c, t8d,
                            familyAdditionalData.getFamily().getGuid());

                }
            }
        } catch (Exception e) {
            logger.error("Exception occure saveUpdateFamilyAdditionalData :: {}", e);
        }
        return null;
    }

    /**
     * Convert family additional data dto to entity.
     *
     * @param familyAdditionalData the family additional data
     * @param familyAdditionalDataDto the family additional data dto
     * @return the family additional data
     * @throws ParseException the parse exception
     */
    private FamilyAdditionalData convertFamilyAdditionalDataDtoToEntity(FamilyAdditionalData familyAdditionalData,
            FamilyAdditionalDataDto familyAdditionalDataDto) throws ParseException {
        familyAdditionalData.setT8c(familyAdditionalDataDto.getT8c());
        familyAdditionalData.setT8d(familyAdditionalDataDto.getT8d());
        familyAdditionalData.setDldDate(convertToDate(familyAdditionalDataDto.getDldDate()));
        familyAdditionalData.setDllDate(convertToDate(familyAdditionalDataDto.getDllDate()));
        familyAdditionalData.setFirstRegDate(convertToDate(familyAdditionalDataDto.getFirstRegDate()));
        familyAdditionalData.setGearBox(familyAdditionalDataDto.getGearBox());
        familyAdditionalData.setMotorB0F(familyAdditionalDataDto.getMotorB0F());
        familyAdditionalData.setMotorDkc(familyAdditionalDataDto.getMotorDkc());
        familyAdditionalData.setRceDate(convertToDate(familyAdditionalDataDto.getRceDate()));
        familyAdditionalData.setWindow(familyAdditionalDataDto.getWindow());
        familyAdditionalData.setUrlDossier(familyAdditionalDataDto.getUrlDossier());
        familyAdditionalData.setUrlImportFile(familyAdditionalDataDto.getUrlImportFile());
        familyAdditionalData.setUrlPv(familyAdditionalDataDto.getUrlPv());
        familyAdditionalData.setVehicleFamilies(familyAdditionalDataDto.getVehicleFamilies());
        familyAdditionalData.setFamily(familyAdditionalDataDto.getFamily());
        return familyAdditionalData;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.FamilyService#getAllFamilyAdditionalData(java.lang.String, java.lang.String)
     */
    @Override
    public FamilyAdditionalData getAllFamilyAdditionalData(String t8c, String t8d) throws SQLException {

        return familyAdditionalDataRepository.getFamilyAdditionalData(t8c, t8d);
    }

}
