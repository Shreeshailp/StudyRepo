/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.GeneratedCycleParserService;
import com.inetpsa.w7t.application.services.GeneratedCycleService;
import com.inetpsa.w7t.application.utilities.WriteToTextFile;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleErrorCode;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleException;
import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfile;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfileDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Class GeneratedCycleServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class GeneratedCycleServiceImpl implements GeneratedCycleService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The User service. */
    @Inject
    UserService userService;

    /** The Cycle Parser Service. */
    @Inject
    private GeneratedCycleParserService cycleParserService;

    /** The Cycle repository. */
    @Inject
    private GeneratedCycleRepository genCycleRepository;

    /** The generic Cycle repository. */
    @Inject
    @Jpa
    private Repository<GeneratedCycle, UUID> genCycleRepo;

    /** The cycle profile repo. */
    @Inject
    @Jpa
    private Repository<GeneratedCycleProfile, UUID> cycleProfileRepo;

    /** The Cycle Details factory. */
    @Inject
    private Factory<GeneratedCycle> genCyclefactory;

    /** The Cycle Profile factory. */
    @Inject
    private Factory<GeneratedCycleProfile> cycleProfileFactory;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The label service. */
    @Inject
    LabelService labelService;

    /** The file path. */
    @Configuration("generatedreport.filePath")
    static String filePath;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.GeneratedCycleService#upload(java.io.InputStream, java.lang.Boolean)
     */

    public CollectionRepresentation upload(InputStream inputStream, Boolean forceUpdate) throws IOException {

        List<GeneratedCycleDto> cycles = cycleParserService.parse(inputStream);
        boolean isGeneratedCycleExists = false;
        int generatedCycleCount = 0;
        if (!forceUpdate) {
            for (GeneratedCycleDto genCycleDto : cycles) {
                isGeneratedCycleExists = checkExistence(genCycleDto.getGeneratedCode());
                if (isGeneratedCycleExists) {
                    generatedCycleCount++;
                }

            }
            if (generatedCycleCount > 0) {
                throw new GeneratedCycleException(GeneratedCycleErrorCode.GENERATED_CYCLE_PROFILE_EXISTS);
            }
        }

        List<GeneratedCycle> cycleDetailsList = importCycles(cycles, forceUpdate);
        CollectionRepresentation genCycleCollection = new CollectionRepresentation(cycleDetailsList.size(), false);
        return genCycleCollection;

    }

    /**
     * Check existence.
     *
     * @param generatedCode the generated code
     * @return true, if successful
     */
    private boolean checkExistence(String generatedCode) {

        return genCycleRepository.exists(generatedCode);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.GeneratedCycleService#importCycles(java.util.List, java.lang.Boolean)
     */
    public List<GeneratedCycle> importCycles(List<GeneratedCycleDto> genCycles, Boolean forceUpdate) {
        List<GeneratedCycle> cycleDetailsList = new ArrayList<>();

        for (GeneratedCycleDto cycleDto : genCycles) {

            GeneratedCycle cycleDetails = null;

            String requestId = "";
            Optional<GeneratedCycle> optCycle = genCycleRepository.byGeneratedCode(requestId, cycleDto.getGeneratedCode());

            if (!optCycle.isPresent()) {

                cycleDetails = genCyclefactory.create();
                cycleDetails.setGeneratedCode(cycleDto.getGeneratedCode());
                cycleDetails.setPhase(cycleDto.getPhase());
                cycleDetails.setFdsc(cycleDto.getFdsc());
                cycleDetails.setSpeedLimit(cycleDto.getSpeedLimit());
                cycleDetails.setSpeedLimitFlag(cycleDto.getSpeedLimitFlag());
                cycleDetails.setDownscaleFlag(cycleDto.getDownscaleFlag());
                cycleDetails.setCreatedBy(userService.getUserId());

                cycleDetails.setCreatedDate(getDate());
                mergeAggregateWithDto(cycleDto, cycleDetails);

                cycleDetails = genCycleRepo.save(cycleDetails);
                logger.info("Created : {}", cycleDetails);

                WriteToTextFile.writeToFile(userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString()
                        + " : Generated cycle created : " + cycleDetails);

            } else {

                cycleDetails = optCycle.get();
                cycleDetails.setUpdatedBy(userService.getUserId());

                cycleDetails.setUpdatedDate(getDate());
                mergeAggregateWithDto(cycleDto, cycleDetails);
                genCycleRepo.save(cycleDetails);
                logger.info("Updated : {}", cycleDetails);

                WriteToTextFile.writeToFile(userService.getUserId() + " " + LocalDate.now().toString() + " " + LocalTime.now().toString()
                        + " :Generated cycle updated : " + cycleDetails);
            }

            cycleDetailsList.add(cycleDetails);
            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString());
            if (cycleDetails != null) {
                traceLog.append(" Import Generated Cycle Code ").append(cycleDetails.getCycleCode()).toString();
            }
            String trace = traceLog.toString();
            logger.info(trace);
        }

        return cycleDetailsList;

    }

    /**
     * Merge aggregate with dto.
     *
     * @param cycleDto the cycle dto
     * @param cycleDetails the cycle details
     */
    private void mergeAggregateWithDto(GeneratedCycleDto cycleDto, GeneratedCycle cycleDetails) {

        cycleDetails.setCycleCode(cycleDto.getCycleCode());
        cycleDetails.setvMax(cycleDto.getvMax());
        if (cycleDetails.getGenCycleProfiles() != null) {
            cycleDetails.getGenCycleProfiles().clear();
            cycleDetails.getGenCycleProfiles().addAll(populateProfiles(cycleDetails.getGenCycleProfiles(), cycleDto));
        } else {
            cycleDetails.setGenCycleProfiles(populateProfiles(cycleDetails.getGenCycleProfiles(), cycleDto));
        }

        Double totalDist = cycleDto.getProfiles().stream().collect(Collectors.summingDouble(GeneratedCycleProfileDto::getDistance));
        cycleDetails.setTotalDistance(totalDist.floatValue());

    }

    /**
     * Populate profiles.
     *
     * @param list the list
     * @param cycleDto the cycle dto
     * @return the list
     */
    private List<GeneratedCycleProfile> populateProfiles(List<GeneratedCycleProfile> list, GeneratedCycleDto cycleDto) {
        if (genCycleRepository.exists(cycleDto.getGeneratedCode())) {

            list.clear();
            cycleDto.getProfiles().stream().forEach(cycleDtoProfile -> {
                GeneratedCycleProfile cycleProfile = cycleProfileFactory.create();
                cycleProfile.setTime(cycleDtoProfile.getTime());
                cycleProfile.setVelocity(cycleDtoProfile.getVelocity());
                cycleProfile.setDistance(cycleDtoProfile.getDistance());
                cycleProfile.setAcceleration(cycleDtoProfile.getAcceleration());
                list.add(cycleProfile);
            });
            return list;
        }

        List<GeneratedCycleProfile> generatedCycleProfilesUpdated = new ArrayList<>();

        cycleDto.getProfiles().stream().forEach(cycleDtoProfile -> {
            GeneratedCycleProfile cycleProfile = cycleProfileFactory.create();
            cycleProfile.setTime(cycleDtoProfile.getTime());
            cycleProfile.setVelocity(cycleDtoProfile.getVelocity());
            cycleProfile.setDistance(cycleDtoProfile.getDistance());
            cycleProfile.setAcceleration(cycleDtoProfile.getAcceleration());
            generatedCycleProfilesUpdated.add(cycleProfile);
        });

        return generatedCycleProfilesUpdated;
    }

    /**
     * Gets the date.
     *
     * @return the date
     */
    private String getDate() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }
}
