/*
 * Creation : 16 Mar 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import org.seedstack.business.finder.Finder;

import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface MoteurGearBoxFinder.
 *
 * @author E569186
 */
@Finder
public interface MoteurGearBoxFinder {

    /**
     * Gets the all moteur.
     *
     * @return the all moteur
     */
    CollectionRepresentation getAllMoteur();

    /**
     * Gets the all gear box.
     *
     * @return the all gear box
     */
    CollectionRepresentation getAllGearBox();
}
