/*
 * Creation : 16 Sep 2019
 */
package com.inetpsa.w7t.ihm.rest.maturityrequest;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Propagation;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.user.model.User;

/**
 * The Interface UserFinder.
 */
@Finder
// @Transactional(readOnly = true)
@Transactional()
@JpaUnit("wltp-domain-jpa-unit")
public interface UserFinder {

    /**
     * Update status.
     *
     * @param status the status
     * @param client the client
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    void updateStatus(Boolean status, String client);

    /**
     * Gets the user.
     *
     * @param client the client
     * @return the user
     */
    User getUser(String client);
}