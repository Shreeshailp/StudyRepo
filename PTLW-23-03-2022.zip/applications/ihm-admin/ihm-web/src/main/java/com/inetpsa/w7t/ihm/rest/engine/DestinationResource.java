/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import java.net.URI;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;
import java.util.UUID;

import javax.ws.rs.BeanParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.assembler.dsl.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.domain.identity.IdentityService;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.destination.exceptions.DestinationErrorCode;
import com.inetpsa.w7t.domains.destination.exceptions.DestinationException;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.enginesettings.validation.DestinationValidationService;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.Api;

/**
 * The Class DestinationResource. This resource is used to handle the requests defined under the {@link CatalogRels#DESTINATIONS} path.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.DESTINATIONS)
@Api
public class DestinationResource {

    /** The User service. */
    @Inject
    UserService userService;

    @Inject
    private IdentityService identityService;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The destination finder. */
    @Inject
    DestinationFinder destinationFinder;

    @Inject
    FluentAssembler fluentAssembler;

    @Inject
    Repository<DestinationDetails, UUID> destinationDetailsRepo;

    @Inject
    DestinationValidationService validationService;

    @Context
    UriInfo uriInfo;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /**
     * Respond with a {@link CollectionRepresentation}, a list of {@link DestinationRepresentation}, filtered by the {@link DestinationFilter} by
     * destination label.
     * 
     * @param filter the filter by a destination label
     * @return the list of destinations
     */
    @Rel(value = CatalogRels.DESTINATIONS, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response destinations(@BeanParam DestinationFilter filter) {
        return Response.ok(destinationFinder.all(filter)).build();
    }

    /**
     * Respond with a {@link DestinationDetailsRepresentation} of the specified id, or 404 is not found.
     *
     * @param id the destination id
     * @return the destination details if present, or else HTTP 404
     */
    @Path("{" + CatalogRels.DESTINATION + "}")
    @Rel(value = CatalogRels.DESTINATION, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response findById(@PathParam(CatalogRels.DESTINATION) String id) {
        Optional<DestinationDetailsRepresentation> destinationDetails = destinationFinder.byId(id);

        if (destinationDetails.isPresent())
            return Response.ok(destinationDetails.get()).build();
        return Response.status(Response.Status.NOT_FOUND).entity("").build();
    }

    @Path("{" + CatalogRels.DESTINATION + "}")
    @Rel(value = CatalogRels.DESTINATION)
    @POST
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response updateDestination(@PathParam(CatalogRels.DESTINATION) String id,
            DestinationDetailsRepresentation destinationDetailsRepresentation) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new DestinationException(DestinationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        DestinationDetails destinationDetails;
        if (!destinationDetailsRepresentation.getGuid().equals(UUID.fromString(id))) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        try {
            destinationDetails = fluentAssembler.merge(destinationDetailsRepresentation).with(WltpModelMapper.class).into(DestinationDetails.class)
                    .fromRepository().orFail();
        } catch (AggregateNotFoundException e) {
            logger.error("Not aggregate found in the database", e);
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        validationService.validate(destinationDetails);

        destinationDetails = destinationDetailsRepo.save(destinationDetails);

        if (destinationDetails != null) {

            String userId = userService.getUserId();
            StringBuilder traceLog = new StringBuilder();
            traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString())
                    .append(" Modification destination Label ").append(destinationDetails.getLabel()).toString();
            String trace = traceLog.toString();
            logger.info(trace);

            return Response.ok(fluentAssembler.assemble(destinationDetails).with(WltpModelMapper.class).to(DestinationDetailsRepresentation.class))
                    .build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @Path("{" + CatalogRels.DESTINATION + "}")
    @Rel(value = CatalogRels.DESTINATION)
    @DELETE
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response deleteDestination(@PathParam(CatalogRels.DESTINATION) String id) {
        DestinationDetails destinationDetails = null;
        try {
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new DestinationException(DestinationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
            }
            // jira-618 fixed end
            destinationDetails = destinationDetailsRepo.load(UUID.fromString(id));
            if (destinationDetails == null) {
                throw new NotFoundException("Destination with ID + " + id + " Not Found");
            }
        } catch (DestinationException e) {
            logger.error(e.getMessage(), e);
            throw e;
//            return Response.status(Response.Status.BAD_REQUEST).entity("").build();
        } catch (Exception e) {
            logger.error("Error loading aggregate from database", e);
            return Response.serverError().build();
        }

        destinationDetailsRepo.delete(UUID.fromString(id));

        String userId = userService.getUserId();
        StringBuilder traceLog = new StringBuilder();
        traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString())
                .append(" Suppression destination Label ").append(destinationDetails.getLabel()).toString();
        String trace = traceLog.toString();
        logger.info(trace);

        return Response.ok(Status.OK).build();
    }

    @POST
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response createDestination(DestinationDetailsRepresentation destinationDetailsRepresentation) {
        // jira-618 fixed start
        if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
            throw new DestinationException(DestinationErrorCode.INDUS_MAINTAINANCE_ERROR, null);
        }
        // jira-618 fixed end
        DestinationDetails destinationDetails = fluentAssembler.merge(destinationDetailsRepresentation).with(WltpModelMapper.class)
                .into(DestinationDetails.class).fromFactory();
        identityService.identify(destinationDetails);

        validationService.validate(destinationDetails);

        destinationDetailsRepo.save(destinationDetails);

        String userId = userService.getUserId();
        StringBuilder traceLog = new StringBuilder();
        traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString())
                .append(" Creation destination Label ").append(destinationDetails.getLabel()).toString();
        String trace = traceLog.toString();
        logger.info(trace);

        return Response.created(URI.create(this.uriInfo.getRequestUri().toString() + "/" + destinationDetails.getGuid()))
                .entity(fluentAssembler.assemble(destinationDetails).with(WltpModelMapper.class).to(DestinationDetailsRepresentation.class)).build();
    }

}
