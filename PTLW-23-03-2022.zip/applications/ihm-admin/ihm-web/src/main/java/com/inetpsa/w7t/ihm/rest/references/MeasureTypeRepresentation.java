/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.MeasureType;

/**
 * The Class MeasureTypeRepresentation. This representation is used to represent a specific {@link MeasureType}.
 */
@DtoOf(MeasureType.class)
public class MeasureTypeRepresentation extends ReferenceRepresentation {

    /** The sort. */
    private Integer sort;

    /** The rounding digits. */
    private Integer roundingDigits;

    /** The vehicle types. */
    private List<String> vehicleTypes;

    /**
     * Gets the sort.
     *
     * @return the sort
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * Sets the sort.
     *
     * @param sort the new sort
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * Gets the rounding digits.
     *
     * @return the rounding digits
     */
    public Integer getRoundingDigits() {
        return roundingDigits;
    }

    /**
     * Sets the rounding digits.
     *
     * @param roundingDigits the new rounding digits
     */
    public void setRoundingDigits(Integer roundingDigits) {
        this.roundingDigits = roundingDigits;
    }

    /**
     * Gets the vehicle types.
     *
     * @return the vehicle types
     */
    public List<String> getVehicleTypes() {
        return vehicleTypes;
    }

    /**
     * Sets the vehicle types.
     *
     * @param vehicleTypes the new vehicle types
     */
    public void setVehicleTypes(List<String> vehicleTypes) {
        this.vehicleTypes = vehicleTypes;
    }

}
