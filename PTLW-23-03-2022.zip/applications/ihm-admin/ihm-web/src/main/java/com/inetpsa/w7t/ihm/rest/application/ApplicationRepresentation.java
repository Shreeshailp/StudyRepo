/*
 * Creation : 20 juin 2017
 */
package com.inetpsa.w7t.ihm.rest.application;

/**
 * The Class ApplicationRepresentation.
 */
public class ApplicationRepresentation {

    /** The name. */
    private String name;

    /** The id. */
    private String id;

    /** The version. */
    private String version;

    /**
     * Instantiates a new application representation.
     *
     * @param name the name
     * @param id the id
     * @param version the version
     */
    public ApplicationRepresentation(String name, String id, String version) {
        super();
        this.name = name;
        this.id = id;
        this.version = version;
    }

    /**
     * Getter name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter name.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Setter id.
     *
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Getter version.
     *
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * Setter version.
     *
     * @param version the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }
}
