/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import java.util.Optional;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface PhysicalQuantityTypeFinder. This finder is used to retrieve representations of {@link PhysicalQuantityType} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface PhysicalQuantityTypeFinder {

    /**
     * All the physical quantity types.
     *
     * @return the physical quantity types representation
     */
    CollectionRepresentation all();

    /**
     * Retrieve a specific {@link PhysicalQuantityType} representation identified by its UUID entity id.
     *
     * @param id the id
     * @return an optional physical quantity type representation
     */
    Optional<PhysicalQuantityTypeRepresentation> byId(@IsUUID String id);
}
