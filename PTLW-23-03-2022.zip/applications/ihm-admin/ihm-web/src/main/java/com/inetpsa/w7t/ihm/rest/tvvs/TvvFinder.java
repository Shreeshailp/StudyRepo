/*
 * Creation : 16 May 2018
 */
package com.inetpsa.w7t.ihm.rest.tvvs;

import java.util.List;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

/**
 * The Interface TvvFinder. This finder is used to retrieve representations of {@link TVV} entities.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface TvvFinder {

    /**
     * Retrieve the representation of all {@link TVV} entities.
     *
     * @return a representation of all tvvs
     */
    CollectionRepresentation all();

    CollectionRepresentation filter(TvvFilter filter);

    List<TVV> allTVVs();
}
