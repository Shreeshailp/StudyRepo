/*
 * Creation : 6 Jan 2022
 */
package com.inetpsa.w7t.application.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.depol.model.DepolDto;

/**
 * The Interface DepolStatusReportService.
 */
@Service
public interface DepolStatusReportService {

    /**
     * Gets the depol status report by file name.
     *
     * @param fileName the file name
     * @return the depol status report by file name
     */
    public List<DepolDto> getDepolStatusReportByFileName(String fileName);

    /**
     * Save depol status report.
     *
     * @param fileName the file name
     * @param dtoList  the dto list
     */
    public void saveDepolStatusReport(String fileName, List<DepolDto> dtoList);
}
