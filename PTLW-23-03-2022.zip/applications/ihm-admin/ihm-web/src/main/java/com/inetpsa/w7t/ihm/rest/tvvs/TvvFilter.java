/*
 * Creation : 31 May 2018
 */
package com.inetpsa.w7t.ihm.rest.tvvs;

import javax.ws.rs.QueryParam;

public class TvvFilter {
    @QueryParam("vehicleFamily")
    public String vehicleFamily;

    @QueryParam("t1AValue")
    public String t1AValue;

    @QueryParam("t1BValue")
    public String t1BValue;

    @QueryParam("tvvDesignation")
    public String tvvDesignation;

    @QueryParam("tvvVehicleCategory")
    public String tvvVehicleCategory;

    @QueryParam("completeFlag")
    public String completeFlag;

    @QueryParam("depolCode")
    public String tvvCodeDepol;

}
