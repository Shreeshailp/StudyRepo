/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.seedstack.business.Service;

/**
 * The Interface GeneratedCycleParserService.
 */
@Service
@FunctionalInterface
public interface GeneratedCycleParserService {
    /**
     * Parses the inputstream to a list of GeneratedCycleDto.
     *
     * @param inputStream the input stream
     * @return the list
     * @throws IOException Signals that an I/O exception has occurred.
     */
    List<com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto> parse(InputStream inputStream) throws IOException;
}
