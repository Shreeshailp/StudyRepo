/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.toyota.model.answer;

/**
 * The Class WSWltpData.
 */
public class WSWltpData {

    /** The veh type. */
    private String vehType;

    /** The category. */
    private String category;

    /** The destination. */
    private String destination;

    public WSWltpData() {
    }

    /**
     * Gets the veh type.
     *
     * @return the veh type
     */
    public String getVehType() {
        return vehType;
    }

    /**
     * Sets the veh type.
     *
     * @param vehType the new veh type
     */
    public void setVehType(String vehType) {
        this.vehType = vehType;
    }

    /**
     * Gets the category.
     *
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the category.
     *
     * @param category the new category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the destination.
     *
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination.
     *
     * @param destination the new destination
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WSWltpData [vehType=" + vehType + ", category=" + category + ", destination=" + destination + "]";
    }

}
