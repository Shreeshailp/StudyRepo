/*
 * Creation : 14 avr. 2018
 */
package com.inetpsa.w7t.toyota.service.internal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.r3pi.transcolcdv.TranscoManager75;
import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.ToyotaRequestBatchRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.ToyotaRequestBatchEntity;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.model.Parameter;
import com.inetpsa.w7t.domains.wltphub.parameter.repository.WltpHubParameterRepository;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.toyota.interfaces.rest.RequestRepresentation;
import com.inetpsa.w7t.toyota.interfaces.rest.WltpRequestRepresentation;
import com.inetpsa.w7t.toyota.interfaces.rest.WltpResponseRepresentation;
import com.inetpsa.w7t.toyota.model.RequestToyota;
import com.inetpsa.w7t.toyota.model.WltpMarketingToyota;
import com.inetpsa.w7t.toyota.model.answer.Attribute;
import com.inetpsa.w7t.toyota.model.answer.PhaseToyota;
import com.inetpsa.w7t.toyota.model.answer.PhysResultToyota;
import com.inetpsa.w7t.toyota.model.answer.RequestAnswerToyota;
import com.inetpsa.w7t.toyota.model.answer.Result;
import com.inetpsa.w7t.toyota.model.answer.ResultToyota;
import com.inetpsa.w7t.toyota.model.answer.WSPhase;
import com.inetpsa.w7t.toyota.model.answer.WSPhysicalResult;
import com.inetpsa.w7t.toyota.model.answer.WltpMarketingAnswerToyota;
import com.inetpsa.w7t.toyota.service.MarketingService;
import com.inetpsa.w7t.toyota.validation.ToyotaErrorCode;
import com.inetpsa.w7t.toyota.validation.ToyotaException;
import com.inetpsa.w7t.toyota.webservice.WltpService;
import com.inetpsa.w7t.wltphub.validation.WltpHubErrorCode;
import com.inetpsa.w7t.wltphub.validation.WltpHubException;
import com.inetpsa.w7t.wltphub.webservice.internal.WltpHubService;

/**
 * The Class MarketingServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MarketingServiceImpl implements MarketingService {

    /** The logger. */
    @Logging
    private static Logger logger;

    /** The wltp service. */
    @Inject
    private WltpService wltpService;

    /** The wltp hub service. */
    @Inject
    private WltpHubService wltpHubService;

    /** The toyota request batch repository. */
    @Inject
    private ToyotaRequestBatchRepository toyotaRequestBatchRepository;

    /** The toyota out directory. */
    @Configuration("toyotaOutputDirectory")
    public File toyotaOutDirectory;

    /** The wltphub out directory. */
    @Configuration("wltphubOutputDirectory")
    private File wltphubOutDirectory;

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /** The physical quantity type repository. */
    @Inject
    PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The parameter repository. */
    @Inject
    private ParameterRepository parameterRepository;

    /** The wltp hub parameter repository. */
    @Inject
    private WltpHubParameterRepository wltpHubParameterRepository;

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /** The request answer list. */
    List<RequestAnswerToyota> requestAnswerList = new CopyOnWriteArrayList<>();

    /** The Constant CLIENT. */
    private static final String CLIENT = "WS";

    /** The Constant MARKETING_SIMULATION_MAX_REQUESTS_VALUE. */
    private static final String MARKETING_SIMULATION_MAX_REQUESTS_VALUE = "marketing_simulation_max_requests_value";

    /** The Constant SEVEN. */
    private static final int SEVEN = 7;

    /** The Constant CLIENT_NAME. */
    private static final String CLIENT_NAME = "XMLSM";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.toyota.service.MarketingService#getEmissionResult(java.lang.String, boolean)
     */
    @Override
    public void getEmissionResult(String fileLocation, boolean wltphubFlag) {

        File file = new File(fileLocation);
        String fileName = file.getName();
        logger.info("File [{}] received for WLTP calculation", fileName);
        String fileGuid = "";
        boolean manualFile = false;
        if (fileName.length() > 42 && fileName.contains("_input")) {
            fileGuid = fileName.substring(0, 36);
            manualFile = true;
        }

        WltpMarketingAnswerToyota wltpMarketingAnswer = new WltpMarketingAnswerToyota();

        WltpMarketingToyota wltpMarketing = unmarshalRequestFile(file);
        DateTimeFormatter answerDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
        wltpMarketingAnswer.setFileId(wltpMarketing.getFileId());
        wltpMarketingAnswer.setRequestDate(wltpMarketing.getRequestDate());
        wltpMarketingAnswer.setAnswerDate(answerDateFormat.format(LocalDateTime.now()));

        List<RequestToyota> requestList = wltpMarketing.getRequest();
        // fixed jira-621 -- start
        // check the size of requestList
        int requestListSize = requestList.size();
        // get max request value from prm table
        Optional<Parameter> size = parameterRepository.byId(MARKETING_SIMULATION_MAX_REQUESTS_VALUE);
        if (size.isPresent()) {
            String parameterSize = size.get().getValue();

            if (requestListSize > Integer.valueOf(parameterSize) && !wltphubFlag) {

                throw new ToyotaException(ToyotaErrorCode.MAX_NUMBER_REQUESTS_EXCEPTION, null);

            }

            if (requestListSize > Integer.valueOf(parameterSize) && wltphubFlag) {

                throw new WltpHubException(WltpHubErrorCode.MAX_NUMBER_REQUESTS_EXCEPTION, null);

            }
        }
        // fixed jira-621 -- end

        if (wltpMarketing.getFileId().isEmpty() && wltphubFlag) {
            throw new WltpHubException(WltpHubErrorCode.FILE_ID_MISSING_EXCEPTION, null);
        }
        boolean proceed = true;

        for (RequestToyota req : requestList) {
            proceed = true;
            try {
                if (wltphubFlag) {
                    proceed = vaildateWltpHubXmlRequest(req, proceed);
                }
                String versionAndColor = "";
                String version16C = "";
                String colorExtInt = "";
                if (proceed && StringUtils.isNotBlank(req.getVersionAndColor()) && req.getVersionAndColor().length() == 24) {
                    versionAndColor = req.getVersionAndColor();
                    version16C = versionAndColor.substring(0, 16);
                    colorExtInt = versionAndColor.substring(16, 24);
                }

                RequestRepresentation request = new RequestRepresentation();
                WltpRequestRepresentation wltpRequest = new WltpRequestRepresentation();
                String options7c = getOption7c(req);
                if (proceed && wltphubFlag && StringUtils.isNotBlank(options7c)) {
                    // CR-723 to add transcodify()
                    // String option5c = transcodify7CTo5C(options7c, req.getNumber());
                    wltpRequest.setNbOptions(String.valueOf(options7c.length() / 7));
                    wltpRequest.setOptions7C(options7c);
                } else {
                    wltpRequest.setNbOptions(String.valueOf(options7c.length() / 7));
                    wltpRequest.setOptions7C(options7c);
                }

                wltpRequest.setRequestID(req.getNumber());
                wltpRequest.setVersion16C(version16C);
                wltpRequest.setColorExtInt(colorExtInt);

                wltpRequest.setRequestType(req.getRequestType());
                wltpRequest.setTradingCountry(req.getCountry());
                wltpRequest.setExtensionDate(req.getExtensionDate());
                wltpRequest.setEcomDate("");
                wltpRequest.setNbGestion("");
                wltpRequest.setGestion5C("");
                wltpRequest.setGestion7C("");
                wltpRequest.setMountingCenter("");
                wltpRequest.setVin("");
                wltpRequest.setExtendedTitleAttributes(req.getExtendedAttributes());
                String lcdv24 = req.getVersionAndColor();
                wltpRequest.setTvv("");
                if (!wltphubFlag) {
                    // CAP-26709 - LOT24 Changes- Added below client name as part of it
                    wltpRequest.setClientName(CLIENT_NAME);
                }
                WltpResponseRepresentation responseObject = null;
                String errorCode = "";
                String errorDesig = "";
                boolean maturityErrorFlag = false;
                String maturity = "";
                try {
                    if (proceed && !wltphubFlag) {
                        maturity = maturityCheck(wltpRequest, req.getNumber(), maturityRepository, clientMaturityRepository);
                    }
                    request.setRequest(wltpRequest);
                    if (!wltphubFlag) {
                        responseObject = wltpService.getEmissions(request);
                        logger.info("CALCUL webservice response = [{}] for request number:[{}]", responseObject, req.getNumber());

                    } else if (wltphubFlag && proceed) {
                        StopWatch sw = new StopWatch();
                        sw.start();
                        responseObject = wltpHubService.getEmissions(request);
                        logger.info("CALCUL WLTPHUB webservice response = [{}] for request number:[{}]", responseObject, req.getNumber());
                        sw.stop();
                        logger.info("RequestID [{}] Time took to call WLTP HUB web service {}ms", req.getNumber(), sw.getTime());
                    }
                } catch (SeedException se) {
                    maturityErrorFlag = true;
                    if (se.getErrorCode() instanceof WltpErrorCode) {
                        WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                        errorCode = "ERRW" + ec.getRuleCode();
                        errorDesig = ec.getDescription();
                    } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                        WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                        errorCode = "ERRW" + ec.getRuleCode();
                        errorDesig = ec.getDescription();
                    }

                }
                // CAP-26709-Mass Control-Newton and Homologated masses consistency- Below If condition is added as part of LOT24 changes
                if ((responseObject != null && responseObject.getAnswer() != null)
                        && ("ERRW671".contains(responseObject.getAnswer().getCode()) || "ERRW672".contains(responseObject.getAnswer().getCode())))
                    requestAnswerList.add(buildErrorAnswer(req, responseObject.getAnswer().getCode(), responseObject.getAnswer().getDesignation(),
                            responseObject.getRequest().getExtendedTitleAttributes(), responseObject.getRequest().getMountingCenter(),
                            responseObject.getRequest().getExtensionDate(), responseObject.getPhysResult()));
                else if (responseObject != null && !responseObject.getAnswer().getCode().startsWith("OK"))
                    requestAnswerList.add(buildErrorAnswer(req, responseObject.getAnswer().getCode(), responseObject.getAnswer().getDesignation(),
                            responseObject.getRequest().getExtendedTitleAttributes(), responseObject.getRequest().getMountingCenter(),
                            responseObject.getRequest().getExtensionDate()));
                else if (responseObject != null)
                    requestAnswerList.add(buildRequestAnswer(req.getNumber(), responseObject, maturity, lcdv24));
                else if (maturityErrorFlag)
                    requestAnswerList.add(buildErrorAnswer(req, errorCode, errorDesig));
            } catch (TranscoNotFoundException e) {
                requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getRuleCode(),
                        WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getDescription()));
                LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getRuleCode(),
                        WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getDescription());
            } catch (Exception e) {
                String errorCode = "Error from WLTP WS";
                String errorDesig = "Check WLTP WS logs";
                if (wltphubFlag) {
                    if (e.getCause() instanceof java.net.SocketTimeoutException) {
                        LogErrorUtility.logTheError(logger, req.getNumber(), ToyotaErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode(),
                                ToyotaErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription());
                        requestAnswerList.add(buildErrorAnswer(req, ToyotaErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode(),
                                ToyotaErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription()));
                        continue;
                    }
                    errorCode = "Error from WLTP HUB web service";
                    errorDesig = "Check WLTP HUB web service logs";
                    logger.error("Error from WLTPHUB web service : {}", e);

                } else {
                    if (e.getCause() instanceof java.net.SocketTimeoutException) {
                        LogErrorUtility.logTheError(logger, req.getNumber(), ToyotaErrorCode.WLTP_TIMEOUT_EXCEPTION.getRuleCode(),
                                ToyotaErrorCode.WLTP_TIMEOUT_EXCEPTION.getDescription());
                        requestAnswerList.add(buildErrorAnswer(req, ToyotaErrorCode.WLTP_TIMEOUT_EXCEPTION.getRuleCode(),
                                ToyotaErrorCode.WLTP_TIMEOUT_EXCEPTION.getDescription()));
                        continue;
                    }
                    LogErrorUtility.logTheError(logger, req.getNumber(), ToyotaErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
                            ToyotaErrorCode.UNKNOWN_EXCEPTION.getDescription());

                }

                requestAnswerList.add(buildErrorAnswer(req, errorCode, errorDesig));
            }
        }

        wltpMarketingAnswer.setRequest(requestAnswerList);

        if (manualFile) {
            try {
                if (wltphubFlag) {
                    serializeWltphubResponse(wltpMarketingAnswer, fileGuid);
                } else {
                    serialize(wltpMarketingAnswer, fileGuid);
                }
                ToyotaRequestBatchEntity t = toyotaRequestBatchRepository.load(UUID.fromString(fileGuid));
                t.setStatus("G");
                t.setFileId(wltpMarketingAnswer.getFileId());
                toyotaRequestBatchRepository.save(t);
            } catch (IllegalArgumentException e) {
                logger.error("File name does not contain a UUID.", e);
            }
        } else if (wltphubFlag) {
            serializeWltphubResponse(wltpMarketingAnswer, fileGuid);
        } else {
            serialize(wltpMarketingAnswer, fileGuid);
        }

    }

    /**
     * Builds the error answer.
     *
     * @param req            the req
     * @param errorCode      the error code
     * @param errorDesig     the error desig
     * @param extendedTitle  the extended title
     * @param mountingCenter the mounting center
     * @param extensionDate  the extension date
     * @param physResult     the phys result
     * @return the request answer toyota
     */
    private RequestAnswerToyota buildErrorAnswer(RequestToyota req, String errorCode, String errorDesig, String extendedTitle, String mountingCenter,
            String extensionDate, List<WSPhysicalResult> physResult) {
        RequestAnswerToyota requestAnswer = new RequestAnswerToyota();
        requestAnswer.setNumber(req.getNumber());
        if (req.getVersionAndColor() != null && !req.getVersionAndColor().isEmpty()) {
            requestAnswer.setLcdv24(req.getVersionAndColor());
        }
        if (getOption7c(req) != null && !getOption7c(req).isEmpty()) {
            requestAnswer.setOption7c(getOption7c(req));
        }
        if (req.getExtendedAttributes() != null && !req.getExtendedAttributes().isEmpty()) {
            requestAnswer.setExtendedAttribute(req.getExtendedAttributes());
        } else {
            requestAnswer.setExtendedAttribute(extendedTitle);
        }
        if (req.getExtensionDate() != null && !req.getExtensionDate().isEmpty()) {
            requestAnswer.setExtensionDate(req.getExtensionDate());
        }
        if (mountingCenter != null && !mountingCenter.isEmpty()) {
            requestAnswer.setMountingCenter(mountingCenter);
        }
        if (extensionDate != null && !extensionDate.isEmpty()) {
            requestAnswer.setExtensionDate(extensionDate);
        }
        requestAnswer.setStatus(errorCode);
        requestAnswer.setDesignation(errorDesig);
        List<PhysResultToyota> physResultList = new ArrayList<>();
        for (WSPhysicalResult wsphysresult : physResult) {
            PhysResultToyota toyotaPhysResult = new PhysResultToyota();
            toyotaPhysResult.setCode(wsphysresult.getCode());
            toyotaPhysResult.setValue(wsphysresult.getValue());
            physResultList.add(toyotaPhysResult);
        }
        requestAnswer.setPhysResult(physResultList);
        return requestAnswer;
    }

    /**
     * Vaildate wltp hub xml request.
     *
     * @param req     the req
     * @param proceed the proceed
     * @return true, if successful
     */
    private boolean vaildateWltpHubXmlRequest(RequestToyota req, boolean proceed) {
        String version16C = "";
        String colorIntExt = "";
        String option7c = getOption7c(req);

        if (StringUtils.isNotBlank(req.getVersionAndColor()) && req.getVersionAndColor().length() == 24) {
            version16C = req.getVersionAndColor().substring(0, 16);
            colorIntExt = req.getVersionAndColor().substring(16, 24);
        } else if (StringUtils.isNotBlank(req.getVersionAndColor()) && req.getVersionAndColor().length() == 16) {
            version16C = req.getVersionAndColor().substring(0, 16);
        } else if (StringUtils.isNotBlank(req.getVersionAndColor()) && req.getVersionAndColor().length() == 8) {
            colorIntExt = req.getVersionAndColor().substring(0, 8);
        }

        if (req.getNumber().isEmpty()
                || !req.getNumber().startsWith(wltpHubParameterRepository.getCodeByClient(CatalogRels.XML_WLTPHUB_CONSULTATION))) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.REQUEST_NUMBER_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.REQUEST_NUMBER_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.REQUEST_NUMBER_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.REQUEST_NUMBER_MISSING_EXCEPTION.getDescription());

        } else if (proceed && StringUtils.isBlank(version16C) || version16C.length() != 16) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.VERSION_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.VERSION_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.VERSION_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.VERSION_MISSING_EXCEPTION.getDescription());

        } else if (proceed && StringUtils.isBlank(colorIntExt) || colorIntExt.length() != 8) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.COLOR_EXT_INT_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.COLOR_EXT_INT_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.COLOR_EXT_INT_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.COLOR_EXT_INT_MISSING_EXCEPTION.getDescription());

        } else if (proceed && StringUtils.isNotBlank(option7c) && option7c.length() % 7 != 0) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.OPTIONS_MISSING_EXCEPTION.getDescription());
        } else if (proceed && StringUtils.isNotBlank(req.getExtensionDate())
                && !req.getExtensionDate().matches("^\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$")) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.EXTENSION_DATE_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.EXTENSION_DATE_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.EXTENSION_DATE_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.EXTENSION_DATE_MISSING_EXCEPTION.getDescription());
        } else if (proceed && !req.getRequestType().equalsIgnoreCase("FULL") && !req.getRequestType().equalsIgnoreCase("COMB")) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.REQUEST_TYPE_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.REQUEST_TYPE_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.REQUEST_TYPE_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.REQUEST_TYPE_MISSING_EXCEPTION.getDescription());
        } else if (proceed && (StringUtils.isBlank(req.getCountry()) || req.getCountry().length() != 2
                || req.getCountry().length() == 2 && !countryRepository.byCode(req.getCountry()).isPresent())) {
            proceed = false;
            requestAnswerList.add(buildErrorAnswer(req, WltpHubErrorCode.COUNTRY_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.COUNTRY_MISSING_EXCEPTION.getDescription()));
            LogErrorUtility.logTheError(logger, req.getNumber(), WltpHubErrorCode.COUNTRY_MISSING_EXCEPTION.getRuleCode(),
                    WltpHubErrorCode.COUNTRY_MISSING_EXCEPTION.getDescription());
        }

        return proceed;
    }

    /**
     * Unmarshal request file.
     *
     * @param file the file
     * @return the wltp marketing toyota
     */
    private WltpMarketingToyota unmarshalRequestFile(File file) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(WltpMarketingToyota.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            return (WltpMarketingToyota) jaxbUnmarshaller.unmarshal(file);
        } catch (JAXBException e) {
            logger.error("Error in parsing the file! " + e.getMessage(), e);
            throw new ToyotaException(ToyotaErrorCode.FILE_PARSING_EXCEPTION, null);
        }
    }

    /**
     * Maturity check.
     *
     * @param wltpRequest              the wltp request
     * @param requestId                the request id
     * @param maturityRepository       the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @return the string
     */
    private String maturityCheck(WltpRequestRepresentation wltpRequest, String requestId, MaturityRepository maturityRepository,
            ClientMaturityRepository clientMaturityRepository) {
        String maturity = null;
        String version16 = wltpRequest.getVersion16C();
        try {
            maturity = MaturityCheckUtility.determineMaturityCheckForMarketingSimulation(requestId, version16, wltpRequest.getRequestType(),
                    maturityRepository, clientMaturityRepository, logger, CLIENT);
        } catch (SeedException se) {
            throw se;
        }

        return maturity;
    }

    /**
     * Builds the error answer.
     *
     * @param req            the req
     * @param errorCode      the error code
     * @param errorDesig     the error desig
     * @param extendedTitle  the extended title
     * @param mountingCenter the mounting center
     * @param extensionDate  the extension date
     * @return the request answer toyota
     */
    // fix jira-545 starts here
    private RequestAnswerToyota buildErrorAnswer(RequestToyota req, String errorCode, String errorDesig, String extendedTitle, String mountingCenter,
            String extensionDate) {
        RequestAnswerToyota requestAnswer = new RequestAnswerToyota();
        requestAnswer.setNumber(req.getNumber());
        if (req.getVersionAndColor() != null && !req.getVersionAndColor().isEmpty()) {
            requestAnswer.setLcdv24(req.getVersionAndColor());
        }
        if (getOption7c(req) != null && !getOption7c(req).isEmpty()) {
            requestAnswer.setOption7c(getOption7c(req));
        }
        if (req.getExtendedAttributes() != null && !req.getExtendedAttributes().isEmpty()) {
            requestAnswer.setExtendedAttribute(req.getExtendedAttributes());
        } else {
            requestAnswer.setExtendedAttribute(extendedTitle);
        }
        if (req.getExtensionDate() != null && !req.getExtensionDate().isEmpty()) {
            requestAnswer.setExtensionDate(req.getExtensionDate());
        }
        if (mountingCenter != null && !mountingCenter.isEmpty()) {
            requestAnswer.setMountingCenter(mountingCenter);
        }
        if (extensionDate != null && !extensionDate.isEmpty()) {
            requestAnswer.setExtensionDate(extensionDate);
        }
        requestAnswer.setStatus(errorCode);
        requestAnswer.setDesignation(errorDesig);
        return requestAnswer;
    }// fix jira-545 ends here

    /**
     * Builds the error answer.
     *
     * @param req        the req
     * @param errorCode  the error code
     * @param errorDesig the error desig
     * @return the request answer toyota
     */
    private RequestAnswerToyota buildErrorAnswer(RequestToyota req, String errorCode, String errorDesig) {
        RequestAnswerToyota requestAnswer = new RequestAnswerToyota();
        requestAnswer.setNumber(req.getNumber());
        if (req.getVersionAndColor() != null && !req.getVersionAndColor().isEmpty()) {
            requestAnswer.setLcdv24(req.getVersionAndColor());
        }
        if (getOption7c(req) != null && !getOption7c(req).isEmpty()) {
            requestAnswer.setOption7c(getOption7c(req));
        }
        if (req.getExtendedAttributes() != null && !req.getExtendedAttributes().isEmpty()) {
            requestAnswer.setExtendedAttribute(req.getExtendedAttributes());
        }
        if (req.getExtensionDate() != null && !req.getExtensionDate().isEmpty()) {
            requestAnswer.setExtensionDate(req.getExtensionDate());
        }
        requestAnswer.setStatus(errorCode);
        requestAnswer.setDesignation(errorDesig);
        return requestAnswer;
    }

    /**
     * Builds the request answer.
     *
     * @param reqNo          the req no
     * @param responseObject the response object
     * @param maturity       the maturity
     * @param lcdv24         the lcdv 24
     * @return the request answer toyota
     */
    private RequestAnswerToyota buildRequestAnswer(String reqNo, WltpResponseRepresentation responseObject, String maturity, String lcdv24) {

        RequestAnswerToyota requestAnswer = new RequestAnswerToyota();
        requestAnswer.setNumber(reqNo);
        requestAnswer.setCategory(responseObject.getWltpData().getCategory());
        requestAnswer.setVehType(responseObject.getWltpData().getVehType());
        requestAnswer.setStatus("OKW00001");
        requestAnswer.setDesignation("WLTP calculation successful");
        requestAnswer.setTvv(responseObject.getRequest().getTvv());
        requestAnswer.setExtendedAttribute(responseObject.getRequest().getExtendedTitleAttributes());
        requestAnswer.setLcdv24(lcdv24);
        // fixed jira-543
        requestAnswer.setOption7c(responseObject.getRequest().getOptions7C());
        requestAnswer.setExtensionDate(responseObject.getRequest().getExtensionDate());
        requestAnswer.setMountingCenter(responseObject.getRequest().getMountingCenter());
        String familyCode = getFamilyCode(responseObject.getRequest().getExtendedTitleAttributes());
        String familyIndex = getFamilyIndex(responseObject.getRequest().getExtendedTitleAttributes());

        List<Attribute> attributeList = new ArrayList<>();
        Attribute attributeFamCode = new Attribute();
        attributeFamCode.setCode("FAMILLE_WLTP");
        attributeFamCode.setValue(familyCode);
        attributeList.add(attributeFamCode);
        Attribute attributeFamIndex = new Attribute();
        attributeFamIndex.setCode("INDICE_FAMILLE_WLTP");
        attributeFamIndex.setValue(familyIndex);
        attributeList.add(attributeFamIndex);
        requestAnswer.setAttribute(attributeList);

        List<PhysResultToyota> physResultList = new ArrayList<>();
        for (WSPhysicalResult wsphysresult : responseObject.getPhysResult()) {
            PhysResultToyota physResult = new PhysResultToyota();
            physResult.setCode(wsphysresult.getCode());
            physResult.setValue(wsphysresult.getValue());
            physResultList.add(physResult);
        }

        requestAnswer.setPhysResult(physResultList);

        List<PhaseToyota> phaseList = new ArrayList<>();
        for (WSPhase wsphase : responseObject.getPhase()) {
            PhaseToyota phase = new PhaseToyota();
            phase.setCode(wsphase.getCode());

            List<ResultToyota> resultList = new ArrayList<>();
            for (Result wsResult : wsphase.getResult()) {
                // if (!"CE".equals(wsResult.getCode())) {
                ResultToyota res = new ResultToyota();
                res.setCode(wsResult.getCode());
                res.setValue(wsResult.getValue());
                resultList.add(res);
                // }
            }
            phase.setResult(resultList);
            phaseList.add(phase);
        }
        setEmptyPhases();
        requestAnswer.setPhase(phaseList);

        return requestAnswer;
    }

    /**
     * Sets the empty phases.
     */
    private void setEmptyPhases() {

        List<ResultToyota> resultList = new ArrayList<>();
        ResultToyota fc = new ResultToyota();
        fc.setCode("FC");
        fc.setValue("");
        resultList.add(fc);
        ResultToyota co2 = new ResultToyota();
        co2.setCode("CO2");
        co2.setValue("");
        resultList.add(co2);

    }

    /**
     * Gets the family code.
     *
     * @param extendedTitle the extended title
     * @return the family code
     */
    public String getFamilyCode(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile("(?:.{7})*(?:T8C(?<code>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("code");
        return "";
    }

    /**
     * Gets the family index.
     *
     * @param extendedTitle the extended title
     * @return the family index
     */
    public String getFamilyIndex(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile("(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("index");
        return "";
    }

    /**
     * Serialize.
     *
     * @param wltpMarketingAnswer the wltp marketing answer
     * @param fileIdentifier      the file identifier
     */
    private void serialize(WltpMarketingAnswerToyota wltpMarketingAnswer, String fileIdentifier) {
        logger.debug("Entering File Writer Serializer... ");
        try {
            JAXBContext contextObj = JAXBContext.newInstance(WltpMarketingAnswerToyota.class);

            Marshaller marshallerObj = contextObj.createMarshaller();
            // marshallerObj.setProperty(JAXB_XML_DEC_PROP, Boolean.FALSE);
            // marshallerObj.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);

            StringBuilder tempFilePath = new StringBuilder(toyotaOutDirectory.getAbsolutePath()).append(File.separator).append(fileIdentifier)
                    .append("_").append("output").append(".xml");

            try (FileOutputStream fos = new FileOutputStream(new File(tempFilePath.toString()), true)) {
                marshallerObj.marshal(wltpMarketingAnswer, fos);
            }
            logger.info("WLTP answer written to file [{}]", tempFilePath.toString());
        } catch (JAXBException | IOException e) {
            logger.error("Error Marshalling {} answer: ", e);
        }
    }

    /**
     * Serialize wltphub response.
     *
     * @param wltpMarketingAnswer the wltp marketing answer
     * @param fileIdentifier      the file identifier
     */
    private void serializeWltphubResponse(WltpMarketingAnswerToyota wltpMarketingAnswer, String fileIdentifier) {
        logger.debug("Entering File Writer Serializer... ");
        try {
            JAXBContext contextObj = JAXBContext.newInstance(WltpMarketingAnswerToyota.class);

            Marshaller marshallerObj = contextObj.createMarshaller();
            // marshallerObj.setProperty(JAXB_XML_DEC_PROP, Boolean.FALSE);
            // marshallerObj.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);

            StringBuilder tempFilePath = new StringBuilder(wltphubOutDirectory.getAbsolutePath()).append(File.separator).append(fileIdentifier)
                    .append("_").append("output").append(".xml");

            try (FileOutputStream fos = new FileOutputStream(new File(tempFilePath.toString()), true)) {
                marshallerObj.marshal(wltpMarketingAnswer, fos);
            }
            logger.info("WLTP answer written to file [{}]", tempFilePath.toString());
        } catch (JAXBException | IOException e) {
            logger.error("Error Marshalling {} answer: ", e);
        }
    }

    /**
     * Gets the option 7 c.
     *
     * @param req the req
     * @return the option 7 c
     */
    private String getOption7c(RequestToyota req) {
        StringBuilder options7c = new StringBuilder();
        options7c.append(req.getPatt1());
        options7c.append(req.getPatt2());
        options7c.append(req.getPatt3());
        options7c.append(req.getPatt4());
        options7c.append(req.getPatt5());
        options7c.append(req.getPatt6());
        options7c.append(req.getPatt7());
        options7c.append(req.getPatt8());
        options7c.append(req.getPatt9());
        options7c.append(req.getPatt10());

        options7c.append(req.getPatt11());
        options7c.append(req.getPatt12());
        options7c.append(req.getPatt13());
        options7c.append(req.getPatt14());
        options7c.append(req.getPatt15());
        options7c.append(req.getPatt16());
        options7c.append(req.getPatt17());
        options7c.append(req.getPatt18());
        options7c.append(req.getPatt19());
        options7c.append(req.getPatt20());

        options7c.append(req.getPatt21());
        options7c.append(req.getPatt22());
        options7c.append(req.getPatt23());
        options7c.append(req.getPatt24());
        options7c.append(req.getPatt25());
        options7c.append(req.getPatt26());
        options7c.append(req.getPatt27());
        options7c.append(req.getPatt28());
        options7c.append(req.getPatt29());
        options7c.append(req.getPatt30());

        options7c.append(req.getPatt31());
        options7c.append(req.getPatt32());
        options7c.append(req.getPatt33());
        options7c.append(req.getPatt34());
        options7c.append(req.getPatt35());
        options7c.append(req.getPatt36());
        options7c.append(req.getPatt37());
        options7c.append(req.getPatt38());
        options7c.append(req.getPatt39());
        options7c.append(req.getPatt40());

        return options7c.toString();
    }

    /**
     * Transcodify 7 C to 5 C.
     *
     * @param option7C  the option 7 C
     * @param requestId the request id
     * @return the string
     * @throws TranscoNotFoundException the transco not found exception
     */
    public static String transcodify7CTo5C(String option7C, String requestId) throws TranscoNotFoundException {
        StopWatch sw = new StopWatch();
        sw.start();
        TranscoManager75 tm75 = TranscoManager75.getInstance();
        StringBuilder persValue = new StringBuilder();

        List<String> lcdvList = new ArrayList<>();
        int index = 0;
        while (index < option7C.length()) {
            lcdvList.add(" " + option7C.substring(index, index + SEVEN));
            index += SEVEN;
        }
        logger.info("REQUEST ID [{}] ,Transcodification module request = [{}]", requestId, option7C);
        try {
            for (String lcdv : lcdvList)
                persValue.append(tm75.transco(lcdv));
        } catch (TranscoNotFoundException e) {
            throw e;
        }
        logger.info("REQUEST ID [{}] ,Transcodification module response = [{}]", requestId, persValue);

        return persValue.toString();
    }

}
