/*
 * Creation : 26 avr. 2018
 */
package com.inetpsa.w7t.toyota.model.answer;

/**
 * The Class Result.
 */
public class Result {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Instantiates a new result.
     */

    public Result() {

    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Result [code=" + code + ", value=" + value + "]";
    }
}
