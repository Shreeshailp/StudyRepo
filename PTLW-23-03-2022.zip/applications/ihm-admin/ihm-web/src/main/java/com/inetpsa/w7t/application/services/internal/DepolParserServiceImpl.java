/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.application.services.internal;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.services.DepolParserService;
import com.inetpsa.w7t.domains.depol.exceptions.DepolErrorCode;
import com.inetpsa.w7t.domains.depol.exceptions.DepolException;
import com.inetpsa.w7t.domains.depol.model.DepolDto;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;

/**
 * The Class DepolParserServiceImpl.
 */
public class DepolParserServiceImpl implements DepolParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.services.DepolParserService#parse(java.io.InputStream)
     */
    @Override
    public List<DepolDto> parse(InputStream inputStream) throws IOException, DepolException {
        DepolDto t = null;
        List<DepolDto> list = new ArrayList<>();
        XSSFWorkbook myWorkBook = new XSSFWorkbook(inputStream);
        try {

            int rowCount = 0;

            XSSFSheet firstSheet = myWorkBook.getSheetAt(0);
            checkHeaders(firstSheet);
            // Iterator<Row> iterator = firstSheet.iterator();
            int phyRowCount = firstSheet.getPhysicalNumberOfRows();
            while (rowCount < phyRowCount) {
                // iterator.hasNext()
                // Row nextRow = iterator.next();
                Row nextRow = firstSheet.getRow(rowCount);
                if (nextRow.getFirstCellNum() == 1) {
                    throw new DepolException(DepolErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
                }
                // Below if condition has been added to fix JIRA-771
                if (isRowEmpty(nextRow)) {
                    break;
                }
                if (checkIfRowIsEmpty(nextRow)) {
                    continue;
                }
                if (rowCount > 0) {
                    t = new DepolDto();
                    int counter = 0;
                    while (counter <= 13) {
                        Cell cell = nextRow.getCell(counter);
                        readExcelCellsBySwitchCase(t, counter, cell);
                        counter++;
                    }
                }
                if (t != null && t.getStatus() == null) {
                    validateLine(t, list);
                    list.add(t);
                } else if (t != null)
                    list.add(t);
                rowCount++;

            }
            if (rowCount == 1)
                throw new DepolException(DepolErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);

            inputStream.close();
        } catch (IOException e1) {
            logger.error("IOException while parsing the excel sheet : ", e1.getMessage(), e1);
        } catch (Exception ex) {
            logger.error("Exception while parsing the excel sheet : {}", ex.getMessage());
            throw ex;
        }

        finally {
            myWorkBook.close();
        }

        return list;
    }

    /**
     * Read excel cells by switch case.
     *
     * @param t       the t
     * @param counter the counter
     * @param cell    the cell
     */
    private void readExcelCellsBySwitchCase(DepolDto t, int counter, Cell cell) {
        String codeDepol;
        String specialFlag;
        String designation;
        Integer mroMin;
        Integer mroMax;
        Float frontalAreaMin;
        Float frontalAreaMax;
        Float coolingSurfaceMin;
        Float coolingSurfaceMax;
        Float crrMin;
        Float crrMax;
        Float cxMin;
        Float cxMax;
        String e;
        switch (counter) {
        case 0:
            e = getCellData(cell);
            validateFirstColEmpty(e);
            validateLineNotStratsCM(e);
            // fixed jira-764 and 765
            if (e.equalsIgnoreCase("M")) {
                t.setStatus("M");
            } else if (e.equalsIgnoreCase("S")) {
                t.setStatus("S");
            }
            break;
        case 1:
            codeDepol = getCellData(cell);
            if (codeDepol == null || codeDepol.isEmpty()) {
                throw new DepolException(DepolErrorCode.BLANK_DEPOL_CODE, null);
            } else if (codeDepol.length() > 25) {
                throw new DepolException(DepolErrorCode.INVALID_DEPOL_CODE, null);
            }
            t.setCodeDepol(codeDepol);
            break;
        case 2:
            specialFlag = getCellData(cell);
            if (specialFlag == null || specialFlag.isEmpty()) {
                throw new DepolException(DepolErrorCode.BLANK_SPECIAL_FLAG, null);
            } else if (specialFlag.equalsIgnoreCase("T")) {
                throw new DepolException(DepolErrorCode.INVALID_SPECIAL_FLAG, null);
            }
            t.setSpecialFlag(specialFlag);
            break;
        case 3:
            designation = getCellData(cell);
            if (designation == null || designation.isEmpty()) {
                throw new DepolException(DepolErrorCode.BLANK_DESIGNATON, null);
            } else if (designation.length() > 50) {
                throw new DepolException(DepolErrorCode.INVALID_DESIGNATON, null);
            }
            t.setDesignation(designation);
            break;
        case 4:
            crrMin = getNonBlankNumericValue(cell);
            if (crrMin == null || crrMin == 0) {
                throw new DepolException(DepolErrorCode.BLANK_CRR_MIN, null);
            }
            t.setCrrMin(crrMin);
            break;
        case 5:
            crrMax = getNonBlankNumericValue(cell);
            if (crrMax == null || crrMax == 0) {
                throw new DepolException(DepolErrorCode.BLANK_CRR_MAX, null);
            }
            t.setCrrMax(crrMax);
            break;
        case 6:
            mroMin = getNonBlankIntegerValue(cell);
            if (mroMin == null || mroMin == 0) {
                throw new DepolException(DepolErrorCode.BLANK_MRO_MIN, null);
            }
            t.setMroMin(mroMin);
            break;
        case 7:
            mroMax = getNonBlankIntegerValue(cell);
            if (mroMax == null || mroMax == 0) {
                throw new DepolException(DepolErrorCode.BLANK_MRO_MAX, null);
            }
            t.setMroMax(mroMax);
            break;
        case 8:
            frontalAreaMin = getNonBlankNumericValue(cell);
            if (frontalAreaMin == null || frontalAreaMin == 0) {
                throw new DepolException(DepolErrorCode.BLANK_FRONTAL_AREA_MIN, null);
            }
            t.setFrontalAreaMin(frontalAreaMin);
            break;
        case 9:
            frontalAreaMax = getNonBlankNumericValue(cell);
            if (frontalAreaMax == null || frontalAreaMax == 0) {
                throw new DepolException(DepolErrorCode.BLANK_FRONTAL_AREA_MAX, null);
            }
            t.setFrontalAreaMax(frontalAreaMax);
            break;
        case 10:
            coolingSurfaceMin = getNonBlankNumericValue(cell);
            if (coolingSurfaceMin == null || coolingSurfaceMin == 0) {
                throw new DepolException(DepolErrorCode.BLANK_COOLING_SURFACE_MIN, null);
            }
            t.setCoolingSurfaceMin(coolingSurfaceMin);
            break;

        case 11:
            coolingSurfaceMax = getNonBlankNumericValue(cell);
            if (coolingSurfaceMax == null || coolingSurfaceMax == 0) {
                throw new DepolException(DepolErrorCode.BLANK_COOLING_SURFACE_MAX, null);
            }
            t.setCoolingSurfaceMax(coolingSurfaceMax);
            break;

        case 12:
            cxMin = getNonBlankNumericValue(cell);
            if (cxMin == null) {
                t.setStatus(DepolErrorCode.BLANK_CX_MIN.getDescription());
            } else
                t.setCxMin(cxMin);
            break;
        case 13:
            cxMax = getNonBlankNumericValue(cell);
            if (cxMax == null && t.getStatus() == null) {
                t.setStatus(DepolErrorCode.BLANK_CX_MAX.getDescription());
            } else
                t.setCxMax(cxMax);
            break;
        default:
            break;
        }
    }

    /**
     * Check if row is empty.
     *
     * @param nextRow the n ext row
     * @return true, if successful
     */
    private boolean checkIfRowIsEmpty(Row nextRow) {
        boolean isEmpty = false;
        if (nextRow.getCell(1).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(2).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(3).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(4).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(5).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(6).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(7).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(8).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(9).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(10).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(11).getCellTypeEnum() == CellType.BLANK && nextRow.getCell(12).getCellTypeEnum() == CellType.BLANK
                && nextRow.getCell(13).getCellTypeEnum() == CellType.BLANK) {
            isEmpty = true;
        }

        return isEmpty;

    }

    private boolean isRowEmpty(Row row) {
        boolean isEmpty = true;
        DataFormatter dataFormatter = new DataFormatter();

        if (row != null) {
            for (Cell cell : row) {
                if (dataFormatter.formatCellValue(cell).trim().length() > 0) {
                    isEmpty = false;
                    break;
                }
            }
        }

        return isEmpty;
    }

    /**
     * Check headers.
     *
     * @param firstSheet the first sheet
     * @throws DepolException the depol exception
     */
    private void checkHeaders(XSSFSheet firstSheet) throws DepolException {
        final int totalNumberOfHeaderColumns = 14;
        int noOfColumns = firstSheet.getRow(0).getLastCellNum();
        logger.info("Total Number Of Header Columns Required are :[{}]", totalNumberOfHeaderColumns);
        if (noOfColumns < totalNumberOfHeaderColumns) {
            logger.info("The columns in the excel file are :[{}]", noOfColumns);
            throw new DepolException(DepolErrorCode.DEPOL_HEADER_COLUMN_MISSING, null);
        }

    }

    /**
     * Validate first col empty.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws DepolException the depol exception
     */
    public static boolean validateFirstColEmpty(String cellValue) throws DepolException {
        if (cellValue.isEmpty()) {
            throw new DepolException(DepolErrorCode.FIRST_COLUMN_EMPTY_CHECK, null);
        }
        return false;
    }

    /**
     * Validate line not strats CM.
     *
     * @param cellValue the cell value
     * @return true, if successful
     * @throws DepolException the depol exception
     */
    public static boolean validateLineNotStratsCM(String cellValue) throws DepolException {
        if (!("C".equalsIgnoreCase(cellValue)) && !("M".equalsIgnoreCase(cellValue)) && !("S".equalsIgnoreCase(cellValue))
                || ("T".equalsIgnoreCase(cellValue))) {
            throw new DepolException(DepolErrorCode.FIRST_LINE_STARTS_C_M_CHECK, null);
        }
        return false;
    }

    /**
     * Validate line.
     *
     * @param depol  the depol
     * @param depols the depols
     * @return the depol dto
     * @throws DepolException the depol exception
     */
    public static DepolDto validateLine(DepolDto depol, List<DepolDto> depols) throws DepolException {
        // rule no.2 : If the CX MIN value = CX MAX value then send an error “ CX MIN = CX MAX”
        if (depol.getStatus() == null && Float.compare(depol.getCxMin(), depol.getCxMax()) == 0) {
            depol.setStatus(DepolErrorCode.CX_MIN_CX_MAX_EQUAL.getDescription());
        }
        for (DepolDto depol2 : depols) {
            // rule for duplicate line:
            // If two lines starting with "C" "M" have the same key (CODE_DEPOL, flag_special, crr_min, crr_max, CX MIN, CX
            // MAX), then the system will stop the process for that line only and display the message " Au moins un doublon trouvé (CODE_DEPOL xx,
            // flag_special yy, crr_min a, crr_maxb,CX MIN, CX MAX), l'import n'a pas été effectué"
            if (depol.getStatus() == null && depol2.getStatus() == null && depol2.getCodeDepol().equalsIgnoreCase(depol.getCodeDepol())
                    && depol2.getSpecialFlag().equalsIgnoreCase(depol.getSpecialFlag())
                    && depol2.getCrrMin().toString().equalsIgnoreCase(depol.getCrrMin().toString())
                    && depol2.getCrrMax().toString().equalsIgnoreCase(depol.getCrrMax().toString())
                    && depol2.getCxMin().toString().equalsIgnoreCase(depol.getCxMin().toString())
                    && depol2.getCxMax().toString().equalsIgnoreCase(depol.getCxMax().toString())) {
                String[] repeatDepol = { depol.getCodeDepol(), depol.getSpecialFlag(), depol.getCrrMin().toString(), depol.getCrrMax().toString(),
                        depol.getCxMin().toString(), depol.getCxMax().toString() };
                DepolException e = new DepolException(DepolErrorCode.DEPOL_ENTRY_PRESENT_IN_SHEET, repeatDepol);
                depol.setStatus(e.getContextMesage());
            } else if (depol.getStatus() == null && depol2.getStatus() == null && depol2.getCodeDepol().equalsIgnoreCase(depol.getCodeDepol())
                    && depol2.getSpecialFlag().equalsIgnoreCase(depol.getSpecialFlag())
                    && depol2.getCrrMin().toString().equalsIgnoreCase(depol.getCrrMin().toString())
                    && depol2.getCrrMax().toString().equalsIgnoreCase(depol.getCrrMax().toString())) {
                // rule no.1: If we have a line with CX MIN=’0’ and CX MAX=’99’ and another line with another values then send an error
                if (depol.getStatus() == null && depol2.getStatus() == null && Float.compare(depol.getCxMin(), depol2.getCxMin()) == 0
                        && Float.compare(depol.getCxMin(), Float.valueOf(CalculationConstants.CX_MIN_LIMIT)) == 0
                        && Float.compare(depol2.getCxMin(), Float.valueOf(CalculationConstants.CX_MIN_LIMIT)) == 0
                        && Float.compare(depol.getCxMax(), Float.valueOf(CalculationConstants.CX_MAX_LIMIT)) == 0
                        && Float.compare(depol2.getCxMax(), Float.valueOf(CalculationConstants.CX_MAX_LIMIT)) == -1) {
                    depol.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT.getDescription());
                    depol2.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT.getDescription());
                }
                // rule no.3. If we have a line with a CX MIN value and CX MAX value and another one with CX MAX value between the CX MIN value and CX
                // MAX value of the previous line then send an error “chevauchement de borne”
                // 4. If we have a line with a CX MIN value and CX MAX value and another one with CX MIN value between the CX MIN value and CX MAX
                // value of the previous line then send an error “chevauchement de borne”

                if (depol.getStatus() == null && depol2.getStatus() == null && Float.compare(depol.getCxMin(), depol2.getCxMax()) != 0
                        && ((depol.getCxMin() >= depol2.getCxMin() && depol.getCxMin() <= depol2.getCxMax())
                                || (depol.getCxMax() >= depol2.getCxMin() && depol.getCxMax() <= depol2.getCxMax()))) {
                    depol.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT_IN_ANOTHER_LINE.getDescription());
                }
                // JIRA-771 fix by below lines
                DepolDto depolMin = Collections.min(depols, Comparator.comparing(DepolDto::getCxMin));
                DepolDto depolMax = Collections.max(depols, Comparator.comparing(DepolDto::getCxMax));
                if (depol.getStatus() == null && depol.getCxMin() < depolMin.getCxMin() && depol.getCxMax() > depolMax.getCxMax()) {
                    depol.setStatus(DepolErrorCode.CX_MIN_CX_MAX_PRESENT_IN_ANOTHER_LINE.getDescription());
                }
            }
        }
        return depol;

    }

    /**
     * Gets the cell data.
     *
     * @param cell the cell
     * @return the cell data
     */
    private String getCellData(Cell cell) {
        CellType cellType = cell.getCellTypeEnum();
        switch (cellType) {
        case BOOLEAN:
            return String.valueOf(cell.getBooleanCellValue());

        case NUMERIC:
            String useValue = String.valueOf(cell.getNumericCellValue());
            if (useValue.endsWith(".0"))
                return useValue.split("\\.")[0];
            return useValue;

        case STRING:
            return cell.getStringCellValue();

        case BLANK:
            return "";

        default:
            return new String("");
        }
    }

    /**
     * Gets the non blank numeric value.
     *
     * @param cell the cell
     * @return the non blank numeric value
     */
    private Float getNonBlankNumericValue(Cell cell) {
        if (cell != null && (cell.getCellTypeEnum()).equals(CellType.STRING)) {
            String value = cell.getStringCellValue();
            if (value.isEmpty()) {
                return null;
            } else if (value.contains(",")) {
                return Float.valueOf(value.replace(",", "."));
            }
            return Float.valueOf(value);
        } else if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return (float) cell.getNumericCellValue();
    }

    /**
     * Gets the non blank integer value.
     *
     * @param cell the cell
     * @return the non blank integer value
     */
    private Integer getNonBlankIntegerValue(Cell cell) {
        if (cell != null && (cell.getCellTypeEnum()).equals(CellType.STRING)) {
            String value = cell.getStringCellValue();
            if (value.isEmpty()) {
                return null;
            }
            return Math.round(Integer.valueOf(value));
        } else if (cell == null || !(cell.getCellTypeEnum()).equals(CellType.NUMERIC)) {
            return null;
        }
        return (int) Math.round(cell.getNumericCellValue());
    }

}
