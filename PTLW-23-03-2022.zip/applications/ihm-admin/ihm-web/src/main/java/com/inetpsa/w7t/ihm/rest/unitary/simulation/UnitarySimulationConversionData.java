/*
 * Creation : 7 Aug 2020
 */
package com.inetpsa.w7t.ihm.rest.unitary.simulation;

/**
 * The Class UnitarySimulationConversionDataObjects.
 */
public class UnitarySimulationConversionData {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UnitarySimulationConversionDataObjects [code=" + code + ", value=" + value + "]";
    }

}
