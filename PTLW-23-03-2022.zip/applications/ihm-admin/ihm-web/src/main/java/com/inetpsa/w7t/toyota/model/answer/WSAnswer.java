/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.toyota.model.answer;

/**
 * The Class WSAnswer.
 */
public class WSAnswer {

    /** The code. */
    private String code;

    /** The designation. */
    private String designation;

    /**
     * Instantiates a new WS answer.
     */
    public WSAnswer() {
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the designation.
     *
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Sets the designation.
     *
     * @param designation the new designation
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Answer [code=" + code + ", designation=" + designation + "]";
    }

}
