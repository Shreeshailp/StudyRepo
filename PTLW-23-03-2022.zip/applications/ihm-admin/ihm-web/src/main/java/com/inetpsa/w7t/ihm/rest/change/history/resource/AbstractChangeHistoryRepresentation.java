/*
 * Creation : 12 Feb 2020
 */
package com.inetpsa.w7t.ihm.rest.change.history.resource;

import java.util.UUID;

import org.seedstack.seed.rest.hal.HalRepresentation;

public class AbstractChangeHistoryRepresentation extends HalRepresentation {
    protected UUID guid;
    protected String dataCategory;
    protected String dataId;
    protected String oldValue;
    protected String newValue;
    protected String timeStamp;
    protected String user;

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getDataCategory() {
        return dataCategory;
    }

    public void setDataCategory(String dataCategory) {
        this.dataCategory = dataCategory;
    }

    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public String getOldValue() {
        return oldValue;
    }

    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

}
