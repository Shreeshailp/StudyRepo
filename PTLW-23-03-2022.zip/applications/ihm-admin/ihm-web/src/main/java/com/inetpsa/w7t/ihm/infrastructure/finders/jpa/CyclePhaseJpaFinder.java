/*
 * Creation : 6 févr. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.validation.Validation;
import javax.validation.Validator;

import org.seedstack.business.assembler.AssemblerTypes;
import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.rest.RelRegistry;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder;
import com.inetpsa.w7t.ihm.rest.references.CyclePhaseRepresentation;

/**
 * The Class CyclePhaseJpaFinder. This is the JPA Implementation of the {@link CyclePhaseFinder}.
 */
public class CyclePhaseJpaFinder implements CyclePhaseFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The label service. */
    @Inject
    LabelService labelService;

    /** The rel registry. */
    @Inject
    private RelRegistry relRegistry;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder#get(java.lang.String)
     */
    @Override
    public Optional<CyclePhaseRepresentation> get(String cyclePhase) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        if (validator.validateValue(CyclePhase.class, CODE, cyclePhase).isEmpty())
            return this.byCode(cyclePhase);
        return this.byId(cyclePhase);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder#byId(java.lang.String)
     */
    @Override
    public Optional<CyclePhaseRepresentation> byId(String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> q = cb.createQuery(CyclePhase.class);
        Root<CyclePhase> c = q.from(CyclePhase.class);
        q.where(cb.equal(c.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<CyclePhase> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        Optional<CyclePhaseRepresentation> phase = query.getResultList().stream().findFirst()
                .map(ph -> fluentAssembler.assemble(ph).with(AssemblerTypes.MODEL_MAPPER).to(CyclePhaseRepresentation.class));

        phase.ifPresent(ph -> {
            ph.setLabel(labelService.value(ph.getGuid()));
            ph.self(relRegistry.uri(CatalogRels.CYCLE_PHASE).set(CatalogRels.CYCLE_PHASE, ph.getGuid()));
            ph.link("find", relRegistry.uri(CatalogRels.CYCLE_PHASES).templated());
        });

        return phase;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder#byCode(java.lang.String)
     */
    @Override
    public Optional<CyclePhaseRepresentation> byCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> q = cb.createQuery(CyclePhase.class);
        Root<CyclePhase> c = q.from(CyclePhase.class);
        q.where(cb.equal(c.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<CyclePhase> query = entityManager.createQuery(q);
        query.setParameter(CODE, code.toUpperCase());

        Optional<CyclePhaseRepresentation> phase = query.getResultList().stream().findFirst()
                .map(ph -> fluentAssembler.assemble(ph).with(AssemblerTypes.MODEL_MAPPER).to(CyclePhaseRepresentation.class));

        phase.ifPresent(ph -> {
            ph.setLabel(labelService.value(ph.getGuid()));
            ph.self(relRegistry.uri(CatalogRels.CYCLE_PHASE).set(CatalogRels.CYCLE_PHASE, ph.getGuid()));
            ph.link("find", relRegistry.uri(CatalogRels.CYCLE_PHASES).templated());
        });

        return phase;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder#all()
     */
    @Override
    public CollectionRepresentation all() {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> q = cb.createQuery(CyclePhase.class);
        q.select(q.from(CyclePhase.class));
        TypedQuery<CyclePhase> query = entityManager.createQuery(q);

        List<CyclePhaseRepresentation> cyclePhaseList = fluentAssembler.assemble(query.getResultList()).with(AssemblerTypes.MODEL_MAPPER)
                .to(CyclePhaseRepresentation.class);

        cyclePhaseList.stream().forEach(cyclePhase -> {
            cyclePhase.setLabel(labelService.value(cyclePhase.getGuid()));
            cyclePhase.self(relRegistry.uri(CatalogRels.CYCLE_PHASE).set(CatalogRels.CYCLE_PHASE, cyclePhase.getGuid()));
        });

        CollectionRepresentation cyclePhasesList = new CollectionRepresentation(cyclePhaseList.size(), false);

        cyclePhasesList.self(relRegistry.uri(CatalogRels.CYCLE_PHASES).templated());
        cyclePhasesList.embedded(CatalogRels.CYCLE_PHASES, cyclePhaseList);

        return cyclePhasesList;
    }

}
