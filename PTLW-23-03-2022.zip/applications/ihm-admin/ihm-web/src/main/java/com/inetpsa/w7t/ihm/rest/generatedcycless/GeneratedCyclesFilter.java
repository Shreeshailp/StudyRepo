/*
 * Creation : 31 May 2018
 */
package com.inetpsa.w7t.ihm.rest.generatedcycless;

import javax.ws.rs.QueryParam;

/**
 * The Class GeneratedCyclesFilter.
 */
public class GeneratedCyclesFilter {

    /** The generated code. */
    @QueryParam("generatedCode")
    public String generatedCode;

    /** The cycle code. */
    @QueryParam("cycleCode")
    public String cycleCode;

    /** The phase. */
    @QueryParam("phase")
    public String phase;

    /** The downscale flag. */
    @QueryParam("downscaleFlag")
    public String downscaleFlag;

    /** The fdsc. */
    @QueryParam("fdsc")
    public String fdsc;

    /** The speed limit flag. */
    @QueryParam("speedLimitFlag")
    public String speedLimitFlag;

    /** The v max. */
    @QueryParam("vMax")
    public String vMax;

}
