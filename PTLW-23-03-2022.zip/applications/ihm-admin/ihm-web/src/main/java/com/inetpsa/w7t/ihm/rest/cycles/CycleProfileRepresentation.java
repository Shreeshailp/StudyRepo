/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import com.inetpsa.w7t.domains.cycles.model.CycleProfile;

/**
 * The Class CycleProfileRepresentation. It defines the REST Representation of the entity cycle profile.
 */
@DtoOf(CycleProfile.class)
public class CycleProfileRepresentation extends HalRepresentation {

    /** The guid. */
    private String guid;

    /** The acceleration. */
    private Float acceleration;

    /** The velocity. */
    private Float velocity;

    /** The distance. */
    private double distance;

    /** The time. */
    private Integer time;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public String getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(String guid) {
        this.guid = guid;
    }

    /**
     * Gets the acceleration.
     *
     * @return the acceleration
     */
    public Float getAcceleration() {
        return acceleration;
    }

    /**
     * Sets the acceleration.
     *
     * @param acceleration the new acceleration
     */
    public void setAcceleration(Float acceleration) {
        this.acceleration = acceleration;
    }

    /**
     * Gets the velocity.
     *
     * @return the velocity
     */
    public Float getVelocity() {
        return velocity;
    }

    /**
     * Sets the velocity.
     *
     * @param velocity the new velocity
     */
    public void setVelocity(Float velocity) {
        this.velocity = velocity;
    }

    /**
     * Gets the distance.
     *
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Sets the distance.
     *
     * @param distance the new distance
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }

    /**
     * Gets the time.
     *
     * @return the time
     */
    public Integer getTime() {
        return time;
    }

    /**
     * Sets the time.
     *
     * @param time the new time
     */
    public void setTime(Integer time) {
        this.time = time;
    }
}
