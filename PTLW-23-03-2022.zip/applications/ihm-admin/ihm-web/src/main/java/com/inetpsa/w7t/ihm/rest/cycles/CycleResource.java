/*
 * Creation : 4 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest.cycles;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.application.services.CycleService;
import com.inetpsa.w7t.application.utilities.FileInputValidator;
import com.inetpsa.w7t.domains.cycles.shared.CycleErrorCode;
import com.inetpsa.w7t.domains.cycles.shared.CycleValidationException;
import com.inetpsa.w7t.domains.engine.utilities.FileHandlingUtility;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

import io.swagger.annotations.Api;

/**
 * The Class CyclesResource. As the cycle aggregate is simple enough, we just inject domain repository, without creating a specific Finder. Meaning
 * that the Representation objects are quite identical to entities, on this simple functionality (cycleRepresentation is made of Cycle entity, not
 * combining many aggregates in one complex interface object)
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
@Path(CatalogRels.CYCLES)
@Api
public class CycleResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The cycles finder. */
    @Inject
    CyclesFinder cyclesFinder;

    /** The cycles service. */
    @Inject
    CycleService cycleService;

    /** The indus flag file path. */
    @Configuration("indusFlagFilePath")
    private String indusFlagFilePath;

    /**
     * To get the REST representation of all the cycles
     *
     * @param filter the filter
     * @return the response
     */
    @Rel(value = CatalogRels.CYCLES, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response cycles(@BeanParam CycleFilter filter) {
        CollectionRepresentation cycles = cyclesFinder.all(filter);

        return Response.ok(cycles).build();
    }

    /**
     * To get the REST representation of a specific cycle details identified by its UUID entity id
     *
     * @param id the id
     * @return the response
     */
    @Path("{" + CatalogRels.CYCLE + "}")
    @Rel(value = CatalogRels.CYCLE, home = true)
    @GET
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response findById(@PathParam(CatalogRels.CYCLE) String id) {
        Optional<CycleDetailsRepresentation> cycle = cyclesFinder.byId(id);

        if (cycle.isPresent())
            return Response.ok(cycle.get()).build();
        return Response.status(Response.Status.NOT_FOUND).entity("").build();
    }

    /**
     * Cycle import.
     *
     * @param inputStream the input stream
     * @param fileDisposition the file disposition
     * @param forceUpdate the force update
     * @return the response
     */
    @Path(CatalogRels.UPLOAD)
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces({ MediaType.APPLICATION_JSON, "application/hal+json" })
    public Response upload(@FormDataParam("file") InputStream inputStream, @FormDataParam("file") FormDataContentDisposition fileDisposition,
            @FormDataParam("forceUpdate") @DefaultValue("false") Boolean forceUpdate) {

        try {
            FileInputValidator.isNotNull(inputStream);
            // jira-618 fixed start
            if (FileHandlingUtility.isIndusFlagFilePresent(indusFlagFilePath)) {
                throw new CycleValidationException(CycleErrorCode.INDUS_MAINTAINANCE_ERROR);
            }
            // jira-618 fixed end
            return Response.ok(cycleService.upload(inputStream, forceUpdate)).build();
        } catch (CycleValidationException e) {
            logger.error(e.getMessage(), e);
            throw e;
        } catch (RuntimeException | IOException e) {
            CycleValidationException cve = new CycleValidationException(CycleErrorCode.UNKNOWN_TECHNICAL_EXCEPTION);
            cve.initCause(e);
            logger.error(e.getMessage(), e);
            throw cve;
        }

    }

}
