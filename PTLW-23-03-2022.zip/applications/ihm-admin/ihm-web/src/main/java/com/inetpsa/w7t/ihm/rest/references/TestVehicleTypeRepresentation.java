/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.references.model.TestVehicleType;

/**
 * The Class TestVehicleTypeRepresentation. This representation is used to represent a specific {@link TestVehicleType}.
 */
@DtoOf(TestVehicleType.class)
public class TestVehicleTypeRepresentation extends ReferenceRepresentation {

    /** The sort. */
    private Integer sort;

    /**
     * Gets the sort index.
     * 
     * @return the sort index
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * Sets the sort index
     * 
     * @param sort the new sort index
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }
}
