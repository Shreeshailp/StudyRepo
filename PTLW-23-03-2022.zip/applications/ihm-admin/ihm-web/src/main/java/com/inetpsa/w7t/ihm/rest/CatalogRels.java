/*
 * Creation : 4 janv. 2017
 */
package com.inetpsa.w7t.ihm.rest;

/**
 * The Class CatalogRels. This class is used to reference the HAL relations in the REST API.
 */
public final class CatalogRels {

    /** The Constant APPLICATION. */
    public static final String APPLICATION = "application";

    /** The Constant FAMILY. */
    public static final String FAMILY = "family";

    /** The Constant FAMILIES. */
    public static final String FAMILIES = "families";

    /** The Constant FAMILY_CODE_INDEX. */
    public static final String FAMILY_CODE_INDEX = "familycodeindex";

    /** The Constant CYCLE. */
    public static final String CYCLE = "cycle";

    /** The Constant GENERATED_CYCLE. */
    public static final String GENERATED_CYCLE = "generatedcycle";

    /** The Constant CYCLES. */
    public static final String CYCLES = "cycles";

    /** The Constant CONSULT_GENERATED_CYCLE. */
    public static final String CONSULT_GENERATED_CYCLE = "consultGeneratedCycle";

    /** The Constant GENERATED_CYCLES. */
    public static final String GENERATED_CYCLES = "generatedcycles";

    /** The Constant CYCLE_PHASE. */
    public static final String CYCLE_PHASE = "cyclephase";

    /** The Constant CYCLE_PHASES. */
    public static final String CYCLE_PHASES = "cyclephases";

    /** The Constant CYCLE_CODE_INDEX. */
    public static final String CYCLE_CODE_INDEX = "cyclecodeindex";

    /** The Constant DESTINATION. */
    public static final String DESTINATION = "destination";

    /** The Constant DESTINATIONS. */
    public static final String DESTINATIONS = "destinations";

    /** The Constant REFERENCES. */
    public static final String REFERENCES = "references";

    /** The Constant COUNTRY. */
    public static final String COUNTRY = "country";

    /** The Constant COUNTRIES. */
    public static final String COUNTRIES = "countries";

    /** The Constant MEASURE_TYPE. */
    public static final String MEASURE_TYPE = "measuretype";

    /** The Constant MEASURE_TYPES. */
    public static final String MEASURE_TYPES = "measuretypes";

    /** The Constant PHYSICAL_QUANTITY. */
    public static final String PHYSICAL_QUANTITY = "physicalquantity";

    /** The Constant PHYSICAL_QUANTITIES. */
    public static final String PHYSICAL_QUANTITIES = "physicalquantities";

    /** The Constant TEST_VEHICLE_TYPE. */
    public static final String TEST_VEHICLE_TYPE = "testvehicletype";

    /** The Constant TEST_VEHICLE_TYPES. */
    public static final String TEST_VEHICLE_TYPES = "testvehicletypes";

    /** The Constant VEHICLE_VEHICLE_ROADLOADS. */
    public static final String VEHICLE_ROADLOADS = "roadloads";

    /** The Constant VEHICLE_ROADLOAD. */
    public static final String VEHICLE_ROADLOAD = "roadload";

    /** The Constant VEHICLE_PMAX. */
    public static final String VEHICLE_PMAX = "pmax";

    /** The Constant VEHICLE_TYPE. */
    public static final String VEHICLE_TYPE = "vehicletype";

    /** The Constant VEHICLE_TYPES. */
    public static final String VEHICLE_TYPES = "vehicletypes";

    /** The Constant UPLOAD. */
    public static final String UPLOAD = "upload";

    /** The Constant SIMULATION. */
    public static final String SIMULATION = "simulation";

    /** The Constant STATUS CHECK. */
    public static final String STATUS_CHECK = "statuscheck";

    /** The Constant FILE_ID. */
    public static final String FILE_ID = "fileId";

    /** The Constant FILE_GUID. */
    public static final String FILE_GUID = "fileGuid";

    /** The Constant toyota SIMULATION. */
    public static final String TOYOTASIMULATION = "toyotasimulation";

    /** The Constant Toyota STATUS CHECK. */
    public static final String TOYOTA_GET_FILE = "gettoyotafile";

    /** The Constant tvv import. */
    public static final String IMPORTTVV = "importTVV";

    /** The Constant generated cycles import. */
    public static final String IMPORTGENERATEDCYCLES = "importGeneratedCycles";

    /** The Constant Toyota STATUS CHECK. */
    public static final String TVV_GET_FILE = "gettvvfile";

    /** The Constant TVVSEARCH. */
    public static final String TVVSEARCH = "tvvSearch";

    /** The Constant GENERATEDCYCLESSEARCH. */
    public static final String GENERATEDCYCLESSEARCH = "generatedCycleSearch";

    /** The Constant CYCLESEARCH. */
    public static final String CYCLESEARCH = "cycleSearch";

    /** The Constant VEHICLE_CATEGORY. */
    public static final String VEHICLE_CATEGORY = "vehicleCategory";

    /** The Constant VEHICLE_CATEGORIES. */
    public static final String VEHICLE_CATEGORIES = "vehicleCategories";

    /** The Constant DOWNLOAD. */
    public static final String DOWNLOAD = "download";

    /** The Constant IMPORTDEPOL. */
    public static final String IMPORTDEPOL = "importDepol";

    /** The Constant DEPOLSEARCH. */
    public static final String DEPOLSEARCH = "depolSearch";

    /** The Constant TVV_EXPORT. */
    public static final String TVV_EXPORT = "exportTVV";

    /** The Constant DEPOL_EXPORT. */
    public static final String DEPOL_EXPORT = "exportDepol";

    /** The Constant maturity import. */
    public static final String MATURITYIMPORT = "importMaturity";

    /** The Constant MATURITYSEARCH. */
    public static final String MATURITYSEARCH = "maturitySearch";

    /** The Constant MATURITY_EXPORT. */
    public static final String MATURITY_EXPORT = "exportMaturity";

    /** The Constant MATURITY_EXPORT. */
    public static final String FILTER_MATURITY_EXPORT = "exportFilterMaturity";

    /** The Constant CHANGE_HISTORY. */
    public static final String CHANGE_HISTORY = "changeHistory";

    /** The Constant CHANGE_HISTORY_SEARCH. */
    public static final String CHANGE_HISTORY_SEARCH = "changeHistorySearch";

    /** The Constant FAMILYTABCHECKFLAG. */
    public static final String FAMILYTABCHECKFLAG = "familyTabCheckFlag";

    /** The Constant FAMILYTABCHECKSTATUS. */
    public static final String FAMILYTABCHECKSTATUS = "familyTabCheckStatus";

    /** The Constant T8C. */
    public static final String T8C = "t8c";

    /** The Constant T8D. */
    public static final String T8D = "t8d";

    /** The Constant FAMILYTABCHECKFLAGES. */
    public static final String FAMILYTABCHECKFLAGES = "familyTabCheckFlages";

    /** The Constant MOTURESANDGEARBOX. */
    public static final String MOTURESANDGEARBOX = "moturesGareBox";

    /** The Constant TEST_VEHICLES. */
    public static final String TEST_VEHICLES = "allTestVehicles";

    /** The Constant UNITARY_SIMULATION. */
    public static final String UNITARY_SIMULATION = "unitarySimulation";

    /** The Constant CALL_WLTP_WS. */
    public static final String CALL_WLTP_WS = "callWltpWS";

    /** The Constant CREATE_COLLECTION. */
    public static final String CREATE_COLLECTION = "createCollection";

    /** The Constant UPDATE_COLLECTION. */
    public static final String UPDATE_COLLECTION = "updateCollection";

    /** The Constant DELETE_COLLECTION. */
    public static final String DELETE_COLLECTION = "deleteCollection";

    /** The Constant COL_NAME. */
    public static final String COL_NAME = "collectionName";

    /** The Constant USER_ID. */
    public static final String USER_ID = "userId";

    /** The Constant COL_ID. */
    public static final String COL_ID = "collectionId";

    /** The Constant REQ_NAME. */
    public static final String REQ_NAME = "requestName";

    /** The Constant REQ_ID. */
    public static final String REQ_ID = "requestId";

    /** The Constant SAVE_REQUEST_TO_COLLECTION. */
    public static final String SAVE_REQUEST_TO_COLLECTION = "saveOrUpdateRequestToCollection";

    /** The Constant ALL_COLLECTIONS. */
    public static final String ALL_COLLECTIONS = "allCollections";

    /** The Constant DELETE_REQUEST. */
    public static final String DELETE_REQUEST = "deleteRequest";

    /** The Constant DELETE_COL_REQUESTS. */
    public static final String DELETE_COL_REQUESTS = "deleteCollectionsRequests";

    /** The Constant APP_NAME. */
    public static final String APP_NAME = "appName";

    /** The Constant MARKETING. */
    public static final String MARKETING = "_MARKETING";

    /** The Constant WLTPHUB_XML_SIMULATION. */
    public static final String WLTPHUB_XML_SIMULATION = "wltphubxmlsimulation";

    /** The Constant Toyota STATUS CHECK WLTPHUB. */
    public static final String TOYOTA_GET_FILE_WLTPHUB = "gettoyotafilesmrtch";

    /** The Constant XML_WLTPHUB_CONSULTATION. */
    public static final String XML_WLTPHUB_CONSULTATION = "XML WLTPHUB CONSULTATION";

    /** The Constant WLTPHUB_UNITARY_SIMULATION. */
    public static final String WLTPHUB_UNITARY_SIMULATION = "wltphubUnitarySimulation";

    /** The Constant CALL_WLTPHUB_WS. */
    public static final String CALL_WLTPHUB_WS = "callWltphubWS";

    /** The Constant DEPOL_IMPORT_STATUS. */
    public static final String DEPOL_IMPORT_STATUS = "importDepolStatus";

    /**
     * Private constructor to disable instantiation.
     */
    private CatalogRels() {

    }
}
