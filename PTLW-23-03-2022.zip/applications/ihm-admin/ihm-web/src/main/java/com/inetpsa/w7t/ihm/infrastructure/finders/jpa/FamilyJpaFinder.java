/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.ihm.infrastructure.finders.jpa;

import static java.util.stream.Collectors.toMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.RelRegistry;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.LabelService;
import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.Cycle;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.references.validation.IsUUID;
import com.inetpsa.w7t.ihm.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.ihm.rest.CatalogRels;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyDetailsRepresentation;
import com.inetpsa.w7t.ihm.rest.families.FamilyFilter;
import com.inetpsa.w7t.ihm.rest.families.FamilyFinder;
import com.inetpsa.w7t.ihm.rest.families.FamilyRepresentation;
import com.inetpsa.w7t.ihm.rest.references.CyclePhaseFinder;
import com.inetpsa.w7t.ihm.rest.references.MeasureTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.PhysicalQuantityTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.TestVehicleTypeFinder;
import com.inetpsa.w7t.ihm.rest.references.VehicleTypeFinder;

/**
 * The Class FamilyJpaFinder. JPA Implementation of the {@link FamilyFinder}.
 */
public class FamilyJpaFinder implements FamilyFinder {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant VEHICLE_ROADLOAD. */
    private static final String ROADLOAD = "roadload";

    /** The Constant INDEX. */
    private static final String INDEX = "index";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The entity manager. */
    @Inject
    EntityManager entityManager;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The rel registry. */
    @Inject
    RelRegistry relRegistry;

    /** The vehicle type finder. */
    @Inject
    VehicleTypeFinder vehicleTypeFinder;

    /** The cycle repository. */
    @Inject
    private CycleRepository cycleRepository;

    /** The cycle phase finder. */
    @Inject
    CyclePhaseFinder cyclePhaseFinder;

    /** The test vehicle type finder. */
    @Inject
    TestVehicleTypeFinder testVehicleTypeFinder;

    /** The physical quantity type finder. */
    @Inject
    PhysicalQuantityTypeFinder physicalQuantityTypeFinder;

    /** The measure type finder. */
    @Inject
    MeasureTypeFinder measureTypeFinder;

    /** The label service. */
    @Inject
    LabelService labelService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.families.FamilyFinder#all(com.inetpsa.w7t.ihm.rest.families.FamilyFilter)
     */
    @Override
    public CollectionRepresentation all(FamilyFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Family> q = cb.createQuery(Family.class);
        Root<Family> root = q.from(Family.class);
        Optional<String> code = Optional.ofNullable(filter.code);
        Optional<String> roadLoad = Optional.ofNullable(filter.roadLoad);

        List<Predicate> filters = new ArrayList<>();
        code.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(CODE)), cb.parameter(String.class, CODE))));
        roadLoad.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(ROADLOAD)), cb.parameter(String.class, ROADLOAD))));

        q.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Family> query = entityManager.createQuery(q);
        code.ifPresent(c -> query.setParameter(CODE, '%' + c.toLowerCase() + '%'));
        roadLoad.ifPresent(c -> query.setParameter(ROADLOAD, '%' + c.toLowerCase() + '%'));
        List<FamilyRepresentation> familyList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(FamilyRepresentation.class);

        familyList.stream().forEach(family -> {
            family.embedded("type", vehicleTypeFinder.byCode(family.getType()).get());
            family.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, family.getGuid()));
            family.link(CatalogRels.FAMILIES, relRegistry.uri(CatalogRels.FAMILIES).set(CatalogRels.FAMILIES, family.getRoadLoad()));
        });
        CollectionRepresentation families = new CollectionRepresentation(familyList.size(), code.isPresent() || roadLoad.isPresent());

        families.self(relRegistry.uri(CatalogRels.FAMILIES).templated());
        families.link("find", relRegistry.uri(CatalogRels.FAMILY).templated());
        families.embedded(CatalogRels.FAMILIES, familyList.stream().collect(Collectors.toList()));

        return families;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.families.FamilyFinder#fetchAllFamilyDetails(com.inetpsa.w7t.ihm.rest.families.FamilyFilter)
     */
    @Override
    public CollectionRepresentation fetchAllFamilyDetails(FamilyFilter filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyDetails> q = cb.createQuery(FamilyDetails.class);
        Root<FamilyDetails> root = q.from(FamilyDetails.class);
        Optional<String> code = Optional.ofNullable(filter.code);
        Optional<String> roadLoad = Optional.ofNullable(filter.roadLoad);

        List<Predicate> filters = new ArrayList<>();
        code.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(CODE)), cb.parameter(String.class, CODE))));
        roadLoad.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(ROADLOAD)), cb.parameter(String.class, ROADLOAD))));

        q.where(filters.toArray(new Predicate[] {}));

        TypedQuery<FamilyDetails> query = entityManager.createQuery(q);
        code.ifPresent(c -> query.setParameter(CODE, '%' + c.toLowerCase() + '%'));
        roadLoad.ifPresent(c -> query.setParameter(ROADLOAD, '%' + c.toLowerCase() + '%'));
        List<FamilyDetailsRepresentation> familyList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(FamilyDetailsRepresentation.class);

        familyList.stream().forEach(family -> {
            family.getVehicles().stream().forEach(vehicle -> {
                vehicle.embedded("type", testVehicleTypeFinder.byId(vehicle.getType()).get());
            });
            family.embedded("type", vehicleTypeFinder.byCode(family.getType()).get());
            family.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, family.getGuid()));
            family.link(CatalogRels.FAMILIES, relRegistry.uri(CatalogRels.FAMILIES).set(CatalogRels.FAMILIES, family.getRoadLoad()));
        });
        CollectionRepresentation families = new CollectionRepresentation(familyList.size(), code.isPresent() || roadLoad.isPresent());

        families.self(relRegistry.uri(CatalogRels.FAMILIES).templated());
        families.link("find", relRegistry.uri(CatalogRels.FAMILY).templated());
        families.embedded(CatalogRels.FAMILIES, familyList.stream().collect(Collectors.toList()));

        return families;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.families.FamilyFinder#byId(java.lang.String)
     */
    @Override
    public Optional<FamilyDetailsRepresentation> byId(@IsUUID String id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyDetails> q = cb.createQuery(FamilyDetails.class);
        Root<FamilyDetails> root = q.from(FamilyDetails.class);
        q.where(cb.equal(root.get(GUID), cb.parameter(UUID.class, GUID)));

        TypedQuery<FamilyDetails> query = entityManager.createQuery(q);
        query.setParameter(GUID, UUID.fromString(id));

        Optional<FamilyDetailsRepresentation> familyDetails = query.getResultList().stream().findFirst().map(fd -> {
            FamilyDetailsRepresentation fdr = fluentAssembler.assemble(fd).with(WltpModelMapper.class).to(FamilyDetailsRepresentation.class);

            fdr.setCycles(fd.getCycles().stream().map(cycleId -> cycleRepository.load(cycleId)).collect(toMap(Cycle::getPhase, Cycle::getCode)));

            return fdr;
        });

        return familyDetails.map(this::populate);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.families.FamilyFinder#byCodeAndIndex(java.lang.String, java.lang.Integer)
     */
    @Override
    public Optional<FamilyDetailsRepresentation> byCodeAndIndex(@FamilyCode String code, Integer index) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyDetails> q = cb.createQuery(FamilyDetails.class);
        Root<FamilyDetails> root = q.from(FamilyDetails.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)), cb.equal(root.get(INDEX), cb.parameter(Integer.class, INDEX)));

        TypedQuery<FamilyDetails> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        query.setParameter(INDEX, index);

        Optional<FamilyDetailsRepresentation> familyDetails = query.getResultList().stream().findFirst().map(fd -> {
            FamilyDetailsRepresentation fdr = fluentAssembler.assemble(fd).with(WltpModelMapper.class).to(FamilyDetailsRepresentation.class);

            fdr.setCycles(fd.getCycles().stream().map(id -> cycleRepository.load(id)).collect(toMap(Cycle::getPhase, Cycle::getCode)));

            return fdr;
        });

        return familyDetails.map(this::populate);
    }

    /**
     * Populate.
     *
     * @param familyDetails the family details
     * @return the family details representation
     */
    private FamilyDetailsRepresentation populate(FamilyDetailsRepresentation familyDetails) {
        vehicleTypeFinder.byCode(familyDetails.getType()).ifPresent(type -> familyDetails.embedded("type", type));

        familyDetails.getVehicles().stream().forEach(vehicle -> {
            vehicle.embedded("type", testVehicleTypeFinder.byId(vehicle.getType()).get());

            vehicle.getQuantities().stream()
                    .forEach(quantity -> quantity.embedded("type", physicalQuantityTypeFinder.byId(quantity.getType()).get()));

            vehicle.getMeasures().stream().forEach(measure -> {
                measure.embedded("type", measureTypeFinder.byId(measure.getType()).get());
                measure.embedded("phase", cyclePhaseFinder.byId(measure.getPhase()).get());
            });
        });

        familyDetails.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, familyDetails.getGuid()));
        familyDetails.link("list", relRegistry.uri(CatalogRels.FAMILIES).templated().title("Filter by code or category"));
        familyDetails.link("find", relRegistry.uri(CatalogRels.FAMILY).templated().title("Find by family id"));
        familyDetails.link("cycle", relRegistry.uri(CatalogRels.CYCLE).templated().title("Get the cycle by id"));

        return familyDetails;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.ihm.rest.families.FamilyFinder#getAllFamilies()
     */
    @SuppressWarnings("unchecked")
    @Override
    public CollectionRepresentation getAllFamilies() {
        Query query = entityManager.createNativeQuery("SELECT fam.*FROM W7TQTFAM fam ORDER BY fam.CODE ASC", Family.class);

        List<FamilyRepresentation> familyList = fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class)
                .to(FamilyRepresentation.class);

        familyList.stream().forEach(family -> {

            family.embedded("type", vehicleTypeFinder.byCode(family.getType()).get());
            family.self(relRegistry.uri(CatalogRels.FAMILY).set(CatalogRels.FAMILY, family.getGuid()));
            family.link(CatalogRels.FAMILIES, relRegistry.uri(CatalogRels.FAMILIES).set(CatalogRels.FAMILIES, family.getRoadLoad()));
        });
        CollectionRepresentation families = new CollectionRepresentation(familyList.size(), false);

        families.self(relRegistry.uri(CatalogRels.FAMILIES).templated());
        families.link("find", relRegistry.uri(CatalogRels.FAMILY).templated());
        families.embedded(CatalogRels.FAMILIES, familyList.stream().collect(Collectors.toList()));
        return families;
    }

}
