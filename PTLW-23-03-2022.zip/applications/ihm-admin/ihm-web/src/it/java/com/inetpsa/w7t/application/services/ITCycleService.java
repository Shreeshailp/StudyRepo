/*
 * Creation : 24 mars 2017
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.model.CycleDto;
import com.inetpsa.w7t.domains.cycles.model.CycleProfileDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@RunWith(SeedITRunner.class)
public class ITCycleService {

    /** The cycle service. */
    @Inject
    private CycleService cycleService;

    /** The logger. */
    @Logging
    private Logger logger;

    @Test
    public void testThatUploadMethodRunsSuccessfully() throws IOException {
        InputStream inputStream = getClass().getResourceAsStream("/Format_Cycle_Import_step_1.xlsx");
        CollectionRepresentation cycles = cycleService.upload(inputStream, true);
        assertThat(cycles).isNotNull();

    }

    @Test
    public void testThatImportMethodRunsSuccessfully() {
        Boolean forceUpdate = true;

        List<CycleDto> cycles = new ArrayList<>();
        CycleDto cycleDto1 = new CycleDto();
        cycleDto1.setCode("STD01CITY");
        cycleDto1.setComment("Test Comment");
        cycleDto1.setPhase("CITY");

        List<CycleProfileDto> profiles = new ArrayList<>();

        CycleProfileDto cycleProfile1 = new CycleProfileDto();
        cycleProfile1.setTime(7);
        cycleProfile1.setDistance(77);
        cycleProfile1.setVelocity((float) 77.7);
        cycleProfile1.setAcceleration((float) 7.7);
        profiles.add(cycleProfile1);

        cycleDto1.setProfiles(profiles);

        cycles.add(cycleDto1);
        List<CycleDetails> cycledetails = cycleService.importCycles(cycles, forceUpdate);
        assertThat(cycledetails).isNotEmpty();
        assertThat(cycledetails.size()).isEqualTo(1);
    }
}
