/*
 * Creation : 28 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto;

@RunWith(SeedITRunner.class)
public class ITGeneratedCycleParserService {
    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycle parser service. */
    @Inject
    private GeneratedCycleParserService genCycleParserService;

    @Test
    public void testThatParseMethodParsesXlsxContentSuccessfully() {
        List<GeneratedCycleDto> genCycleDtos = new ArrayList<>();
        InputStream inputStream = getClass().getResourceAsStream("/import_cycle_genere.xlsx");
        try {
            genCycleDtos = genCycleParserService.parse(inputStream);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        assertThat(genCycleDtos).isNotNull().isNotEmpty();
        assertThat(genCycleDtos.size()).isEqualTo(1);

    }
}
