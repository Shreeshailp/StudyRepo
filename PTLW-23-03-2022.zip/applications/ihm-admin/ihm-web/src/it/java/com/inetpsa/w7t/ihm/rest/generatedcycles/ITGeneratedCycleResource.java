/*
 * Creation : 1 Apr 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.ihm.rest.generatedcycles;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;

import java.io.InputStream;
import java.net.URL;
import java.util.List;

import javax.ws.rs.core.Response;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

/**
 * Description
 * 
 * @author E562493
 */
@RunWith(Arquillian.class)
public class ITGeneratedCycleResource {
    @Logging
    private Logger logger;

    @ArquillianResource
    private URL baseURL;

    @Configuration("auth.username")
    private String username;

    @Configuration("auth.password")
    private String password;

    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap.create(WebArchive.class);
    }

    @Test
    @RunAsClient
    public void generatedCyclesList() {
        // Get the '/api/cycles' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/generatedcycles")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the count property is equal to the number of elements in the _embedded.families array
                .body("count", response -> equalTo(response.<List<Object>>path("_embedded.cycles").size())).extract().response();

    }

    @Test
    @RunAsClient
    public void cycleUsingExistingId() {
        // Given the parameter 'cycle' with the value '9b70f213-44b8-42c5-a30c-e6bb279cbb60' in the path '/api/cycles/{cycle}'
        given().auth().basic(username, password).pathParam("generatedcycle", "9b70f213-44b8-42c5-a30c-e6bb279cbb60").when()
                .get(baseURL.toString() + "api/generatedcycles/{generatedcycle}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the guid is "55c177eb-3977-441d-92c8-139650b54a43"
                .body("guid", equalToIgnoringCase("9b70f213-44b8-42c5-a30c-e6bb279cbb60"))
                // Assert that the code is "STD01LOW"
                .body("code", equalToIgnoringCase("STDLOW01"))
                // Assert that the category is "low"
                .body("phase", equalToIgnoringCase("low"));
    }

    @Test
    @RunAsClient
    public void generatedCycleUsingNonExistingId() {
        // Given the parameter 'cycle' with the value 'dd0b2e44-e6a0-4523-991d-12b047aafbe1' in the path '/api/cycles/{cycle}'
        given().auth().basic(username, password).pathParam("generatedcycle", "dd0b2e44-e6a0-4523-991d-12b047aafbe1").when()
                .get(baseURL.toString() + "api/generatedcycles/{generatedcycle}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    @Test
    @RunAsClient
    public void generatedCycleUpload() {
        InputStream inputStream = getClass().getResourceAsStream("/import_cycle_genere.xlsx");

        given().auth().basic(username, password).contentType("multipart/form-data").multiPart("file", "import_cycle_genere.xlsx", inputStream)
                .formParam("forceUpdate", true).when().post(baseURL.toString() + "api/generatedcycles/upload").then().assertThat()
                .statusCode(Response.Status.OK.getStatusCode()).assertThat().contentType("application/json")
                .body("count", response -> equalTo(response.<List<Object>>path("_embedded.cycles").size())).extract().response();
    }
}
