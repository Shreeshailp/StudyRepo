/*
 * Creation : 2 mars 2017
 */
package com.inetpsa.w7t.ihm.rest.references;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;

import java.net.URL;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.core.services.LabelService;

/**
 * The Class ITReferenceResource.
 */
@RunWith(Arquillian.class)
public class ITReferenceResource {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The base url. */
    @ArquillianResource
    private URL baseURL;

    @Configuration("auth.username")
    private String username;

    @Configuration("auth.password")
    private String password;

    @Inject
    private LabelService labelService;

    /**
     * Creates the deployment.
     *
     * @return the web archive
     */
    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap.create(WebArchive.class);
    }

    /**
     * Countries list.
     */
    @Test
    @RunAsClient
    public void countriesList() {
        // Get the '/api/references/countries' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/countries")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the count property is equal to the number of elements in the _embedded.families array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.countries").size())).extract().response();

    }

    /**
     * Country using existing id.
     */
    @Test
    @RunAsClient
    public void countryUsingExistingId() {
        // Given the parameter 'country' with the value '42c1b487-7760-444f-bbd0-b27947306106' in the path 'api/references/countries/{country}'
        given().auth().basic(username, password).pathParam("country", "42c1b487-7760-444f-bbd0-b27947306106").when()
                .get(baseURL.toString() + "api/references/countries/{country}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code value is be
                .body("code", equalToIgnoringCase("00"))
                // Assert that the label value is Belgique
                .body("label", equalToIgnoringCase("SANS"));
    }

    /**
     * Country using existing code.
     */
    @Test
    @RunAsClient
    public void countryUsingExistingCode() {
        // Given the parameter 'country' with the value 'fr' in the path 'api/references/countries/{country}'
        given().auth().basic(username, password).pathParam("country", "19").when().get(baseURL.toString() + "api/references/countries/{country}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code value is 6f8910b8-107f-467a-acdc-70bbd39d0a85
                .body("guid", equalToIgnoringCase("f6dad620-5440-4044-993b-12582008cc09"))
                // Assert that the label value is France
                .body("label", equalToIgnoringCase("France"));
    }

    /**
     * Country using non existing id.
     */
    @Test
    @RunAsClient
    public void countryUsingNonExistingId() {
        // Given the parameter 'country' with the value '1e1e57a3-eb23-4c95-a954-4862a6aae6b6' in the path 'api/references/countries/{country}'
        given().auth().basic(username, password).pathParam("country", "1e1e57a3-eb23-4c95-a954-4862a6aae6b6").when()
                .get(baseURL.toString() + "api/references/countries/{country}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());

    }

    /**
     * Country using non existing code.
     */
    @Test
    @RunAsClient
    public void countryUsingNonExistingCode() {
        // Given the parameter 'country' with the value 'fb' in the path 'api/references/countries/{country}'
        given().auth().basic(username, password).pathParam("country", "fb").when().get(baseURL.toString() + "api/references/countries/{country}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());

    }

    /**
     * Cycle phases list.
     */
    @Test
    @RunAsClient
    public void cyclePhasesList() {
        // Get the '/api/references/cyclephases' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/cyclephases")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the number property is equal to the number of elements in the _embedded.cyclephases array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.cyclephases").size())).extract().response();

    }

    /**
     * Cycle phase using existing id.
     */
    @Test
    @RunAsClient
    public void cyclePhaseUsingExistingId() {
        // Given the parameter 'cyclephase' with the value '823c9793-62c1-412f-a87f-f3f88e4137db' in the path
        // 'api/references/cyclephases/{cyclephase}'
        given().auth().basic(username, password).pathParam("cyclephase", "553e90eb-0375-4ea8-8c38-98fc20518c4a").when()
                .get(baseURL.toString() + "api/references/cyclephases/{cyclephase}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code value is city
                .body("code", equalToIgnoringCase("city"))
                // Assert that the label value is city
                .body("label", equalToIgnoringCase("Ville"))
                // Assert that the sort value is 4
                .body("sort", equalTo(4));
    }

    /**
     * Cycle phase using existing code.
     */
    @Test
    @RunAsClient
    public void cyclePhaseUsingExistingCode() {
        given().auth().basic(username, password).pathParam("cyclephase", "ehigh").when()
                .get(baseURL.toString() + "api/references/cyclephases/{cyclephase}").then().assertThat()
                .statusCode(Response.Status.OK.getStatusCode()).body("guid", equalToIgnoringCase("3eb99a95-f14b-4034-8d16-8568b8682e7c"))
                .body("label", equalToIgnoringCase(labelService.value(UUID.fromString("3eb99a95-f14b-4034-8d16-8568b8682e7c"))))
                .body("sort", equalTo(3));
    }

    /**
     * Cycle phase using non existing id.
     */
    @Test
    @RunAsClient
    public void cyclePhaseUsingNonExistingId() {
        // Given the parameter 'cyclephase' with the value '3e1e57a3-eb23-4c95-a954-4862a6aae6b6' in the path
        // 'api/references/cyclephases/{cyclephase}'
        given().auth().basic(username, password).pathParam("cyclephase", "3e1e57a3-eb23-4c95-a954-4862a6aae6b6").when()
                .get(baseURL.toString() + "api/references/cyclephases/{cyclephase}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Cycle phase using non existing code.
     */
    @Test
    @RunAsClient
    public void cyclePhaseUsingNonExistingCode() {
        // Given the parameter 'cyclephase' with the value 'hilow' in the path
        // 'api/references/cyclephases/{cyclephase}'
        given().auth().basic(username, password).pathParam("cyclephase", "hilow").when()
                .get(baseURL.toString() + "api/references/cyclephases/{cyclephase}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Measure types list.
     */
    @Test
    @RunAsClient
    public void measureTypesList() {
        // Get the '/api/references/cyclephases' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/measuretypes")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the number property is equal to the number of elements in the _embedded.measuretypes array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.measuretypes").size()));

    }

    /**
     * Measure types using existing id.
     */
    @Test
    @RunAsClient
    public void measureTypesUsingExistingId() {
        // Given the parameter 'measuretype' with the value '14f5e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/measuretypes/{measuretype}'
        given().auth().basic(username, password).pathParam("measuretype", "d2493a4a-ef77-4292-a744-b01d663539e5").when()
                .get(baseURL.toString() + "api/references/measuretypes/{measuretype}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code value is CO2CD
                .body("code", equalToIgnoringCase("CO2CD"))
                // Assert that the sort value is 8
                .body("sort", equalTo(12));

    }

    /**
     * Measure types using existing code.
     */
    @Test
    @RunAsClient
    public void measureTypesUsingExistingCode() {
        // Given the parameter 'measuretype' with the value 'FCCS' in the path
        // 'api/references/measuretypes/{measuretype}'
        given().auth().basic(username, password).pathParam("measuretype", "FCCS").when()
                .get(baseURL.toString() + "api/references/measuretypes/{measuretype}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the guid value is 1c79f3d5-4b0f-4f4e-bcb6-8c740e567333
                .body("guid", equalToIgnoringCase("96fcbfb6-fb4e-4043-8533-6701c8b79276"))
                // Assert that the sort value is 5
                .body("sort", equalTo(9));
    }

    /**
     * Measure types using non existing id.
     */
    @Test
    @RunAsClient
    public void measureTypesUsingNonExistingId() {
        // Given the parameter 'measuretype' with the value '24f5e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/measuretypes/{measuretype}'
        given().auth().basic(username, password).pathParam("measuretype", "24f5e3f0-567a-43c7-89ea-b1a3188ac233").when()
                .get(baseURL.toString() + "api/references/measuretypes/{measuretype}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Measure types using non existing code.
     */
    @Test
    @RunAsClient
    public void measureTypesUsingNonExistingCode() {
        // Given the parameter 'measuretype' with the value 'CO3CF' in the path
        // 'api/references/measuretypes/{measuretype}'
        given().auth().basic(username, password).pathParam("measuretype", "CO3CF").when()
                .get(baseURL.toString() + "api/references/measuretypes/{measuretype}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Physical quantities list.
     */
    @Test
    @RunAsClient
    public void physicalQuantitiesList() {
        // Get the '/api/references/physicalquantities' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/physicalquantities")
                // Assert that the status code is 501 (as currently not implemented)
                .then().assertThat().statusCode(Response.Status.NOT_IMPLEMENTED.getStatusCode());

    }

    /**
     * Physical quantity using existing id.
     */
    @Test
    @RunAsClient
    public void physicalQuantityUsingExistingId() {
        // Given the parameter 'physicalquantity' with the value '14f5e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/physicalquantities/{physicalquantity}'
        given().auth().basic(username, password).pathParam("physicalquantity", "0c5991fd-9ec9-4cd2-a813-5624409936c1").when()
                .get(baseURL.toString() + "api/references/physicalquantities/{physicalquantity}")
                // Assert that the status code is 501 (as currently not implemented)
                .then().assertThat().statusCode(Response.Status.NOT_IMPLEMENTED.getStatusCode());

    }

    /**
     * Physical quantity using non existing id.
     */
    @Test
    @RunAsClient
    public void physicalQuantityUsingNonExistingId() {
        // Given the parameter 'physicalquantity' with the value '24f5e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/physicalquantities/{physicalquantity}'
        given().auth().basic(username, password).pathParam("physicalquantity", "24f5e3f0-567a-43c7-89ea-b1a3188ac233").when()
                .get(baseURL.toString() + "api/references/physicalquantities/{physicalquantity}")
                // Assert that the status code is 501 (as currently not implemented)
                .then().assertThat().statusCode(Response.Status.NOT_IMPLEMENTED.getStatusCode());

    }

    /**
     * Test vehicle types list.
     */
    @Test
    @RunAsClient
    public void testVehicleTypesList() {
        // Get the '/api/references/testvehicletypes' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/testvehicletypes")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the count property is equal to the number of elements in the _embedded.testvehicletypes array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.testvehicletypes").size())).extract().response();

    }

    /**
     * Test vehicle type using existing id.
     */
    @Test
    @RunAsClient
    public void testVehicleTypeUsingExistingId() {
        given().auth().basic(username, password).pathParam("testvehicletype", "227513f7-2b0a-47f4-9480-4729be0b3277").when()
                .get(baseURL.toString() + "api/references/testvehicletypes/{testvehicletype}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code is "VLOW"
                .body("code", equalToIgnoringCase("VLOW"))
                // Assert that the label is "Vlow"
                .body("label", equalToIgnoringCase("Vlow"));

    }

    /**
     * Test vehicle type using non existing id.
     */
    @Test
    @RunAsClient
    public void testVehicleTypeUsingNonExistingId() {
        // Given the parameter 'testvehicletype' with the value '4d26ff51-41fe-4efc-852f-155417b6449d' in the path
        // 'api/references/testvehicletypes/{testvehicletype}'
        given().auth().basic(username, password).pathParam("testvehicletype", "4d26ff51-41fe-4efc-852f-155417b6449d").when()
                .get(baseURL.toString() + "api/references/testvehicletypes/{testvehicletype}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());

    }

    /**
     * Vehicle categories list.
     */
    @Test
    @RunAsClient
    public void vehicleCategoriesList() {
        // Get the '/api/references/categories' REST endpoint
        given().auth().basic(username, password).queryParam("filter", "").when().get(baseURL.toString() + "api/references/categories")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the count property is equal to the number of elements in the _embedded.categories array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.categories").size())).extract().response();

    }

    /**
     * Vehicle category using existing id.
     */
    @Test
    @RunAsClient
    public void vehicleCategoryUsingExistingId() {
        // Given the parameter 'category' with the value 'e57eb125-dc4e-40b4-9b27-cfa4e5aacd31' in the path
        // 'api/references/categories/{category}'
        given().auth().basic(username, password).pathParam("category", "342faa5b-8cb3-4a5f-a474-ef80d15b2334").when()
                .get(baseURL.toString() + "api/references/categories/{category}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the code is "e5"
                .body("code", equalToIgnoringCase("n1"));
    }

    /**
     * Vehicle category using existing code.
     */
    @Test
    @RunAsClient
    public void vehicleCategoryUsingExistingCode() {
        // Given the parameter 'category' with the value 'e5' in the path
        // 'api/references/categories/{category}'
        given().auth().basic(username, password).pathParam("category", "n2").when().get(baseURL.toString() + "api/references/categories/{category}")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the guid is "e57eb125-dc4e-40b4-9b27-cfa4e5aacd31"
                .body("guid", equalToIgnoringCase("57e7f16b-6e38-45d8-b4b3-9e5f5013c795"));
    }

    /**
     * Vehicle category using non existing id.
     */
    @Test
    @RunAsClient
    public void vehicleCategoryUsingNonExistingId() {
        // Given the parameter 'category' with the value '1235e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/categories/{category}'
        given().auth().basic(username, password).pathParam("category", "24f5e3f0-567a-43c7-89ea-b1a3188ac233").when()
                .get(baseURL.toString() + "api/references/categories/{category}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Vehicle category non existing code.
     */
    @Test
    @RunAsClient
    public void vehicleCategoryNonExistingCode() {
        // Given the parameter 'category' with the value 'z2' in the path
        // 'api/references/categories/{category}'
        given().auth().basic(username, password).pathParam("category", "z2").when().get(baseURL.toString() + "api/references/categories/{category}")
                // Assert that the status code is 404
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

    /**
     * Vehicle type list.
     */
    @Test
    @RunAsClient
    public void vehicleTypeList() {
        // Get the '/api/references/vehicletypes' REST endpoint
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/references/vehicletypes")
                // Assert that the status code is 200
                .then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                // Assert that the response is not filtered
                .body("filtered", equalTo(false))
                // Assert that the count property is equal to the number of elements in the _embedded.vehicletypes array
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.vehicletypes").size()));

    }

    /**
     * Vehicle type using existing id.
     */
    @Test
    @RunAsClient
    public void vehicleTypeUsingExistingId() {
        given().auth().basic(username, password).pathParam("vehicletype", "918a7b1a-9b76-4446-8219-906c5b70d51b").when()
                .get(baseURL.toString() + "api/references/vehicletypes/{vehicletype}").then().assertThat()
                .statusCode(Response.Status.OK.getStatusCode()).body("guid", equalTo("918a7b1a-9b76-4446-8219-906c5b70d51b"))
                .body("code", equalTo("CONV")).body("measureTypes", containsInAnyOrder("595d3f8a-48d2-4139-982e-0a22c7b61ad8",
                        "7a543403-868d-48ca-b163-0bfd3292bcb2", "ef3da5d9-7a10-45a9-82ff-89077e013920"));
    }

    /**
     * Vehicle type using existing code.
     */
    @Test
    @RunAsClient
    public void vehicleTypeUsingExistingCode() {
        given().auth().basic(username, password).pathParam("vehicletype", "CONV").when()
                .get(baseURL.toString() + "api/references/vehicletypes/{vehicletype}").then().assertThat()
                .statusCode(Response.Status.OK.getStatusCode()).body("guid", equalTo("918a7b1a-9b76-4446-8219-906c5b70d51b"))
                .body("code", equalTo("CONV")).body("measureTypes", containsInAnyOrder("595d3f8a-48d2-4139-982e-0a22c7b61ad8",
                        "7a543403-868d-48ca-b163-0bfd3292bcb2", "ef3da5d9-7a10-45a9-82ff-89077e013920"));
    }

    /**
     * Vehicle type using non existing id.
     */
    @Test
    @RunAsClient
    public void vehicleTypeUsingNonExistingId() {
        // Given the parameter 'vehicletype' with the value '64f5e3f0-567a-43c7-89ea-b1a3188ac233' in the path
        // 'api/references/vehicletypes/{vehicletype}'
        given().auth().basic(username, password).pathParam("vehicletype", "64f6e3f0-567a-43c7-89ea-b1a3188ac233").when()
                .get(baseURL.toString() + "api/references/vehicletypes/{vehicletype}").then().assertThat()
                .statusCode(Response.Status.NOT_FOUND.getStatusCode());

    }

    /**
     * Vehicle type non existing code.
     */
    @Test
    @RunAsClient
    public void vehicleTypeNonExistingCode() {
        // Given the parameter 'vehicletype' with the value 'EXEC' in the path
        // 'api/references/vehicletypes/{vehicletype}'
        given().auth().basic(username, password).pathParam("vehicletype", "EXEC").when()
                .get(baseURL.toString() + "api/references/vehicletypes/{vehicletype}")
                // Assert that the status code is 501 (as currently not implemented)
                .then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }
}
