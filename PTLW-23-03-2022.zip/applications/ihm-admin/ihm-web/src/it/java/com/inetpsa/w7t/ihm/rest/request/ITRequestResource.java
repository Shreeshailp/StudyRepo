/*
 * Creation : 7 avr. 2017
 */
package com.inetpsa.w7t.ihm.rest.request;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalToIgnoringCase;

import java.io.InputStream;
import java.net.URL;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

@RunWith(Arquillian.class)
public class ITRequestResource {

    @Logging
    private Logger logger;

    @ArquillianResource
    private URL baseURL;

    @Configuration("auth.username")
    private String username;

    @Configuration("auth.password")
    private String password;

    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap.create(WebArchive.class);
    }

    @Test
    @RunAsClient
    public void testThatRequestUploadIsSuccessful() {

        InputStream inputStream = getClass().getResourceAsStream("/Format_Manual_Request.xlsx");

        given().auth().basic(username, password).contentType("multipart/form-data").multiPart("file", "Format_Manual_Request.xlsx", inputStream)
                .when().post(baseURL.toString() + "api/simulation/upload").then().assertThat().statusCode(200);

    }

    @Test
    @RunAsClient
    public void testThatRequestStatusCheckAndResponseIsSuccessful() {

        given().auth().basic(username, password).pathParam("fileId", "W7T3382335619").when().get(baseURL.toString() + "api/simulation/{fileId}")
                .then().assertThat().statusCode(200).body("fileStatus", equalToIgnoringCase("R"));

    }
}
