/*
 * Creation : 1 mars 2017
 */
package com.inetpsa.w7t.ihm.rest.engine;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.equalToIgnoringCase;

import java.net.URL;
import java.util.List;

import javax.ws.rs.core.Response;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

@RunWith(Arquillian.class)
public class ITDestinationResource {

    @Logging
    private Logger logger;

    @ArquillianResource
    private URL baseURL;

    @Configuration("auth.username")
    private String username;

    @Configuration("auth.password")
    private String password;

    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap.create(WebArchive.class);
    }

    @Test
    @RunAsClient
    public void destinationsList() {
        given().auth().basic(username, password).when().get(baseURL.toString() + "api/destinations").then().assertThat()
                .statusCode(Response.Status.OK.getStatusCode()).body("filtered", equalTo(false))
                .body("count", response -> equalTo(response.<List<Object>> path("_embedded.destinations").size()));
    }

    @Test
    @RunAsClient
    public void destinationUsingExistingId() {
        given().auth().basic(username, password).pathParam("destination", "7b522085-9a89-4a2e-bf7e-8e895950f24f").when()
                .get(baseURL.toString() + "api/destinations/{destination}").then().assertThat().statusCode(Response.Status.OK.getStatusCode())
                .body("guid", equalToIgnoringCase("7b522085-9a89-4a2e-bf7e-8e895950f24f")).body("label", equalToIgnoringCase("Test Destination"))
                .body("fromDate", equalToIgnoringCase("2017-06-01")).body("toDate", equalToIgnoringCase("2017-06-30"));
    }

    @Test
    @RunAsClient
    public void destinationUsingNonExistingId() {
        given().auth().basic(username, password).pathParam("destination", "dd0b2e44-e6a0-4523-991d-12b047aafbe1").when()
                .get(baseURL.toString() + "api/destinations/{destination}").then().assertThat().statusCode(Response.Status.NOT_FOUND.getStatusCode());
    }

}
