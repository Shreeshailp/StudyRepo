/*
 * Creation : 28 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleDto;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfileDto;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@RunWith(SeedITRunner.class)
public class ITGeneratedCycleService {
    /** The cycle service. */
    @Inject
    private GeneratedCycleService genCycleService;

    /** The logger. */
    @Logging
    private Logger logger;

    @Test
    public void testThatUploadMethodRunsSuccessfully() throws IOException {
        InputStream inputStream = getClass().getResourceAsStream("/import_cycle_genere.xlsx");
        CollectionRepresentation genCycles = genCycleService.upload(inputStream, true);
        assertThat(genCycles).isNotNull();

    }

    @Test
    public void testThatImportMethodRunsSuccessfully() {
        Boolean forceUpdate = true;

        List<GeneratedCycleDto> genCycles = new ArrayList<>();
        GeneratedCycleDto genCycleDto1 = new GeneratedCycleDto();
        genCycleDto1.setCycleCode("STD01CITY");
        genCycleDto1.setFdsc(0.103F);
        genCycleDto1.setSpeedLimit(90);

        List<GeneratedCycleProfileDto> profiles = new ArrayList<>();

        GeneratedCycleProfileDto cycleProfile1 = new GeneratedCycleProfileDto();
        cycleProfile1.setTime(7);
        cycleProfile1.setDistance(77);
        cycleProfile1.setVelocity((float) 77.7);
        cycleProfile1.setAcceleration((float) 7.7);
        profiles.add(cycleProfile1);

        genCycleDto1.setProfiles(profiles);

        genCycles.add(genCycleDto1);
        List<GeneratedCycle> cycledetails = genCycleService.importCycles(genCycles, forceUpdate);
        assertThat(cycledetails).isNotEmpty();
        assertThat(cycledetails.size()).isEqualTo(1);
    }
}
