/*
 * Creation : 8 mars 2017
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.model.family.FamilyDto;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.ihm.rest.CollectionRepresentation;

@RunWith(SeedITRunner.class)
public class ITFamilyService {

    @Logging
    private Logger logger;

    @Inject
    private FamilyService familyService;

    @Inject
    private FamilyRepository familyRepository;

    @Test
    @Transactional
    public void testThatUploadMethodRunsSuccessfully() throws IOException {
        InputStream inputStream = getClass().getResourceAsStream("/family-import-test-nominal.xlsx");

        CollectionRepresentation families = familyService.upload(inputStream, false);
        assertThat(families).isNotNull();

        deleteFamilies(families);
    }

    @Test
    @Transactional
    public void uploadFileWithEmptyRows() throws IOException {
        InputStream is = getClass().getResourceAsStream("/family-import-test-with-empty-rows.xlsx");

        CollectionRepresentation families = null;
        try {
            families = familyService.upload(is, false);
            assertThat(families).isNotNull();
            deleteFamilies(families);
        } catch (FamilyValidationException e) {
            fail("Uploading a file with empty lines should not raise an exception.", e);
        }
    }

    @Test
    public void testThatImportMethodRunsSuccessfully() {
        Boolean forceUpdate = true;
        Set<String> cycles = new HashSet<>();
        cycles.add("STDLOW01");
        cycles.add("STD01MID");
        cycles.add("STD01HIGH");
        cycles.add("STD01EHIGH");

        List<FamilyDto> familiesdto = new ArrayList<>();
        FamilyDto fam1 = new FamilyDto();

        fam1.setCode("AC");
        fam1.setIndex(1);
        // fam1.setCategory("N1");
        fam1.setVehicleType("CONV");
        fam1.setCycles(cycles);
        familiesdto.add(fam1);

        FamilyDto fam2 = new FamilyDto();
        fam2.setCode("03");
        fam2.setIndex(5);
        // fam2.setCategory("M1");
        fam2.setVehicleType("CONV");
        fam2.setCycles(cycles);
        familiesdto.add(fam2);

        List<FamilyDetails> families = familyService.importFamilies(familiesdto, forceUpdate);
        assertThat(families).isNotNull().isNotEmpty();
        assertThat(families.size()).isEqualTo(2);
    }

    private void deleteFamilies(CollectionRepresentation families) {
        Object familyListObject = families.getEmbedded().get("families");
        if (familyListObject instanceof List<?>) {
            List<?> familyList = (List<?>) familyListObject;
            familyList.stream().filter(Family.class::isInstance).map(o -> (Family) o).map(Family::getGuid).forEach(familyRepository::delete);
        }
    }
}
