/*
 * Creation : 24 mars 2017
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.cycles.model.CycleDto;

@RunWith(SeedITRunner.class)
public class ITCycleParserService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycle parser service. */
    @Inject
    private CycleParserService cycleParserService;

    @Test
    public void testThatParseMethodParsesXlsxContentSuccessfully() {
        List<CycleDto> cycleDtos = new ArrayList<>();
        InputStream inputStream = getClass().getResourceAsStream("/Format_Cycle_Import_step_1.xlsx");
        try {
            cycleDtos = cycleParserService.parse(inputStream);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        assertThat(cycleDtos).isNotNull().isNotEmpty();
        assertThat(cycleDtos.size()).isEqualTo(1);

    }

}
