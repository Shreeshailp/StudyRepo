/*
 * Creation : 8 mars 2017
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.families.model.family.FamilyDto;

@RunWith(SeedITRunner.class)
public class ITFamilyParserService {

    @Logging
    private Logger logger;

    @Inject
    private FamilyParserService familyParserService;

    @Test
    public void testThatParseMethodParsesXlsxContentSuccessfully() throws IOException {
        InputStream inputStream = getClass().getResourceAsStream("/Format_import_WLTP_family.xlsx");

        List<FamilyDto> families = familyParserService.parse(inputStream);

        assertThat(families).isNotNull().isNotEmpty();
        assertThat(families.size()).isEqualTo(1);

    }

}
