/*
 * Creation : 7 avr. 2017
 */
package com.inetpsa.w7t.application.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

@RunWith(SeedITRunner.class)
public class ITManualRequestService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The cycle parser service. */
    @Inject
    private ManualRequestService manualRequestService;

    @Test
    public void testThatParseMethodParsesXlsxContentSuccessfully() {

        String manualFileSuccess = null;
        InputStream inputStream = getClass().getResourceAsStream("/Format_Manual_Request.xlsx");

        try {
            manualFileSuccess = manualRequestService.processManualRequest(inputStream);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        assertThat(manualFileSuccess).isNotEmpty();
    }

}
