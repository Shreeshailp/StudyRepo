printf "Launching WLTP engine daemon..."


CLASSPATH=/usersdev2/w7t/data/engine-daemon/config:/usersdev2/w7t/java/${pom.artifactId}-${pom.version}.jar:${engine-daemon.generatedClasspath}

/usr/java/jdk1.8.0_77/bin/java -Xms256m -Xmx10G -Xdebug -agentlib:jdwp=transport=dt_socket,address=1043,server=y,suspend=n -Dcom.sun.management.jmxremote.port=1042 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -cp ${CLASSPATH} org.seedstack.seed.core.SeedMain wltp-engine-daemon

