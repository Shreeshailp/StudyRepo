#!/bin/ksh



if [[ $(echo $1 | grep 'dev' | wc -l) == 1 ]]
    then
        cd /usersdev2/w7t

        PIDS=$( ps aux | grep engine-daemon | grep java | awk '{print $2}' )
        
        echo killing $PIDS
        kill -15 $PIDS
        while kill -0 $PIDS 2> /dev/null; do sleep 1; done;

        #rm -rf ./delivery/*
        rm -rf ./lib/*
        rm -rf ./data/engine-daemon/*
        rm -rf ./data/wltp-sql/*
        rm -rf ./sql/*
        
        tar -xf /usersdev2/w7t/w7t00etuind/$1

        cd data/engine-daemon
        mkdir clients
        mkdir providers
        cd clients
        mkdir corvet
        mkdir manual
        cd corvet
        mkdir in
        mkdir out
        cd ../manual
        mkdir out
        cd ../../providers
        mkdir newton
        mkdir genome
        cd newton
        mkdir out
        mkdir in
        cd ../genome
        mkdir backup
        mkdir in
        cd ../../
        chmod 777 -R clients providers
        
        /usersdev2/w7t/data/wltp-sql/flyway/w7t-flyway-migration.sh

        echo Launching Daemon
        nohup /usersdev2/w7t/delivery/wltp-engine-daemon.sh  > /usersdev2/w7t/log/engine-daemon.log 2>&1 &
        echo Launched Daemon
    else
        printf "No deployment for this release (deploy only for *dev.tar)"
fi
