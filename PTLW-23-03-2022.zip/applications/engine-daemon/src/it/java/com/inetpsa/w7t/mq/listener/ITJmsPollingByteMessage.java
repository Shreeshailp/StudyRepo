/*
 * Creation : 17 août 2017
 */
package com.inetpsa.w7t.mq.listener;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.jms.JMSException;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

@RunWith(SeedITRunner.class)
public class ITJmsPollingByteMessage {

    @Inject
    ITMQByteMessageListener testSender;

    public static CountDownLatch count = new CountDownLatch(1);
    public static String jmsMessageID = null;

    @Test
    public void message_polling_is_working() throws JMSException, IOException {

        String msgId = testSender.send();

        try {
            count.await(5, TimeUnit.SECONDS);
            Assertions.assertThat(jmsMessageID).isEqualTo(msgId);
        } catch (InterruptedException e) {
            fail("Thread interrupted");
        }
    }
}
