/*
 * Creation : 17 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.dictionary.listener.model.CARACTERISTIQUESFAMILLEType;
import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREFAMILLEType;
import com.inetpsa.w7t.dictionary.listener.model.TEXTEType;
import com.inetpsa.w7t.dictionary.listener.model.VALEURCARACTERISTIQUEFAMILLEType;

@RunWith(SeedITRunner.class)
public class ITFamilyDictionaryService {

	@Inject
	private FamilyDictionaryService gs;

	@Test
	public void testGVMService() {

		DICTIONNAIREFAMILLEType dft = new DICTIONNAIREFAMILLEType();

		CARACTERISTIQUESFAMILLEType car1 = setUpCharacteristic("T3N", "07", "1130");
		CARACTERISTIQUESFAMILLEType car2 = setUpCharacteristic("T3S", "07", "120");
		CARACTERISTIQUESFAMILLEType car3 = setUpCharacteristic("T3M", "07", "920");

		dft.getCARACTERISTIQUES().add(car1);
		dft.getCARACTERISTIQUES().add(car2);
		dft.getCARACTERISTIQUES().add(car3);

		dft.setCLASSEDIFFUSEE("TEST");

		int[] noOfItems = gs.mtacUpdate(dft);
		assertThat(noOfItems[0]).isEqualTo(1);
		assertThat(noOfItems[1]).isEqualTo(1);
		assertThat(noOfItems[2]).isEqualTo(1);
	}

	private CARACTERISTIQUESFAMILLEType setUpCharacteristic(String characteristic, String code, String value) {
		CARACTERISTIQUESFAMILLEType car = new CARACTERISTIQUESFAMILLEType();
		car.setNOMCARACTERISTIQUE(characteristic);

		VALEURCARACTERISTIQUEFAMILLEType valcar1 = new VALEURCARACTERISTIQUEFAMILLEType();
		valcar1.setNOMVALEUR(code);

		TEXTEType t1 = new TEXTEType();
		t1.setLANGUE("FR");
		t1.setDESIGNATION(value);
		valcar1.getTEXTE().add(t1);

		car.getVALEURCARACTERISTIQUE().add(valcar1);

		return car;
	}
}
