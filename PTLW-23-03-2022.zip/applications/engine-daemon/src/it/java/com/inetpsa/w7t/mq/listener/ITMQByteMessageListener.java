/*
 * Creation : 16 août 2017
 */
package com.inetpsa.w7t.mq.listener;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;
import javax.jms.BytesMessage;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.commons.io.FileUtils;
import org.seedstack.jms.JmsConnection;
import org.seedstack.seed.it.ITBind;
import org.seedstack.seed.transaction.Transactional;

@ITBind
public class ITMQByteMessageListener {

    @Inject
    private Session session;

    @Transactional
    @JmsConnection("wltpJmsConnection")
    public String send() throws JMSException, IOException {

        Destination queue = session.createQueue("R3P.TO.W7T.01");

        /** Byte Message **/
        ClassLoader classLoader = getClass().getClassLoader();
        byte[] buf = FileUtils.readFileToByteArray(new File(classLoader.getResource("genome_mqMessage.zip").getFile()));
        BytesMessage message = session.createBytesMessage();
        message.writeBytes(buf);

        MessageProducer producer = session.createProducer(queue);
        producer.send(message);
        return message.getJMSMessageID();
    }
}
