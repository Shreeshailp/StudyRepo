/*
 * Creation : 5 mai 2017
 */
package com.inetpsa.w7t.batch;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.batch.model.ClientRequest;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;

public class ITClientRequestItemProcessor {

    private String nominalRequestNumber = "W7T1";
    private String nominalExtendedTitle = "1CXAxxxxxxxxxxxxxxxxxxxxGG802A T3N01H T8C06G T8D02G T8E01G ";

    @Mock
    private ClientRequest clientRequest;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private ClientRequestItemProcessor clientRequestItemProcessor = new ClientRequestItemProcessor();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        when(jdbcTemplate.queryForList(eq("SELECT * FROM W7TQTFAM AS f where f.CODE= ? AND f.IND= ?"), anyString(), anyString()))
                .then(new Answer<List<Map<String, Object>>>() {
                    @Override
                    public List<Map<String, Object>> answer(InvocationOnMock invocation) throws Throwable {
                        String code = (String) invocation.getArgument(1);
                        String index = (String) invocation.getArgument(2);

                        if (code.equals("06") && index.equals("02")) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("", new Object());
                            return Collections.singletonList(map);
                        }
                        return Collections.emptyList();
                    }
                });

        when(jdbcTemplate.queryForList(eq("SELECT * FROM W7TQTCTY where CODE= ? AND CHARACTERISTIC= ?"), anyString(), anyString()))
                .then(new Answer<List<Map<String, Object>>>() {
                    @Override
                    public List<Map<String, Object>> answer(InvocationOnMock invocation) throws Throwable {
                        String country = (String) invocation.getArgument(1);
                        String characteristic = (String) invocation.getArgument(2);

                        if (country.equals("02") && characteristic.equals("GG8")) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("", new Object());
                            return Collections.singletonList(map);
                        }
                        return Collections.emptyList();
                    }
                });

        when(jdbcTemplate.queryForList(eq("SELECT * FROM W7TQTGVM where CODE= ? AND FAMILY= ?"), anyString(), anyString()))
                .then(new Answer<List<Map<String, Object>>>() {
                    @Override
                    public List<Map<String, Object>> answer(InvocationOnMock invocation) throws Throwable {
                        String code = (String) invocation.getArgument(1);
                        String family = (String) invocation.getArgument(2);

                        if (code.equals("01") && family.equals("1CXA")) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("VALUE", "1234");
                            return Collections.singletonList(map);
                        }
                        return Collections.emptyList();
                    }
                });

    }

    @Test
    public void testAnnotationValidationsClientRequest() {

        boolean error = false;
        ClientRequest item = new ClientRequest();
        item.setFileId("AS3A456");
        item.setVin("VF3LDOSIM0000000");
        item.setExtendedTitle("1dscdyt23r571934612368");
        item.setRequestNumber("rifs1213");

        List<String> errorNamesList = item.validate();
        if (errorNamesList != null && !errorNamesList.isEmpty()) {
            boolean isInvalidFile = false;
            boolean isInvalidRequest = false;
            boolean isInvalidVin = false;
            boolean isInvalidExtTtl = false;
            for (String errorName : errorNamesList) {
                RequestErrorCode valError = RequestErrorCode.valueOf(errorName);
                switch (valError) {
                case FILE_ID_INCORRECT:
                    isInvalidFile = true;
                    break;
                case REQUEST_NUMBER_INCORRECT:
                    isInvalidRequest = true;
                    break;
                case VIN_INCORRECT:
                    isInvalidVin = true;
                    break;
                case EXTENDED_TITLE_INCORRECT:
                    isInvalidExtTtl = true;
                    break;
                default:
                    break;
                }
            }
            item.setStatus(RequestStatus.REQUEST_REJECTED);
            if (!error) {
                if (isInvalidFile) {
                    item.setAnswerCode(RequestErrorCode.FILE_ID_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.FILE_ID_INCORRECT.getDescription());
                } else if (isInvalidRequest) {
                    item.setAnswerCode(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
                } else if (isInvalidVin) {
                    item.setAnswerCode(RequestErrorCode.VIN_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.VIN_INCORRECT.getDescription());
                } else if (isInvalidExtTtl) {
                    item.setAnswerCode(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
                }
            }
            error = true;
        }
        assertThat(item.getAnswerCode()).isEqualTo(RequestErrorCode.FILE_ID_INCORRECT.getRuleCode());
    }

    @Test
    public void testOfClientRequest() throws Exception {
        ClientRequest item = new ClientRequest();

        ClientRequestItemProcessor c = new ClientRequestItemProcessor();
        c.process(item);
        assertThat(item.getStatus()).isEqualTo(RequestStatus.REQUEST_REJECTED);
    }

    @Test
    public void testTitleIsValidWithNominalTitle() {

        when(clientRequest.getRequestNumber()).thenReturn(nominalRequestNumber);
        when(clientRequest.getExtendedTitle()).thenReturn(nominalExtendedTitle);

        assertThat(clientRequestItemProcessor.titleIsValid(clientRequest)).isTrue();

    }

    @Test
    public void testTitleIsValidWithNominalTitleContainingConfusingInfo() {

        when(clientRequest.getRequestNumber()).thenReturn(nominalRequestNumber);
        when(clientRequest.getExtendedTitle()).thenReturn("1CXAxxT8CGG8xT8DT3NxxxxxGG802A T3N01H T8C06G T8D02G T8E01G ");

        assertThat(clientRequestItemProcessor.titleIsValid(clientRequest)).isTrue();

    }
}
