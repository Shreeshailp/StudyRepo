/*
 * Creation : 12 avr. 2017
 */
package com.inetpsa.w7t.provider.batch;

import java.util.Date;

import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.provider.model.NewtonRequestResponse;
import com.inetpsa.w7t.provider.model.NewtonRequestResponseDTO;

/**
 * The Class NewtonRequestItemProcessor.
 */
public class NewtonRequestItemProcessor implements ItemProcessor<NewtonRequestResponse, NewtonRequestResponseDTO> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public NewtonRequestResponseDTO process(NewtonRequestResponse item) throws Exception {
        NewtonRequestResponseDTO newtonRequestResponseDTO = new NewtonRequestResponseDTO();
        newtonRequestResponseDTO.setRequestNo("W7T" + item.getRequestNo());
        newtonRequestResponseDTO.setRequestDate(BatchUtils.getFileFormatDate(new Date()));
        newtonRequestResponseDTO.setExtendedTitle(item.getExtendedTitle());
        newtonRequestResponseDTO.setReqId(item.getReqId());
        return newtonRequestResponseDTO;
    }

}
