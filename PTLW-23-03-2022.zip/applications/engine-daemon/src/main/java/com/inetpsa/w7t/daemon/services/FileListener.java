/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.Producible;
import org.seedstack.business.Service;
import org.seedstack.business.domain.DomainObject;

/**
 * The listener interface for receiving file events. The class that is interested in processing a file event implements this interface, and the object
 * created with that class is registered with a component using the component's <code>addFileListener<code> method. When the file event occurs, that
 * object's appropriate method is invoked.
 *
 * @see FileEvent
 */

@Service
@FunctionalInterface
public interface FileListener extends Runnable, DomainObject, Producible {
}
