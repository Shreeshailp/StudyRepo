/*
 * Creation : 12 juin 2017
 */
package com.inetpsa.w7t.daemon.services.misc;

/**
 * The Class DaemonServiceConstants.
 */
public final class DaemonServiceConstants {

    /** The Constant CLIENT_REQ_JOB_NAM defined in spring-context.xml */
    public static final String CLIENT_REQ_JOB_NAM = "corvetRequestJob";

    /** The Constant PROVIDER_REQ_JOB_NAM defined in spring-context.xml */
    public static final String PROVIDER_REQ_JOB_NAM = "newtonRequestJob";

    /** The Constant PROVIDER_ANSWER_JOB_NAM defined in spring-context.xml */
    public static final String PROVIDER_ANSWER_JOB_NAM = "newtonAnswerJob";

    /** The Constant CORVET_ANSWER_JOB_NAM defined in spring-context.xml */
    public static final String CORVET_ANSWER_JOB_NAM = "corvetAnswerJob";

    /** The Constant COMPTOOL_ANSWER_JOB_NAM. */
    public static final String COMPTOOL_ANSWER_JOB_NAM = "compToolAnswerJob";

    /**
     * Instantiation not allowed.
     */
    private DaemonServiceConstants() {
    }
}
