/*
 * Creation : 18 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import org.seedstack.business.Service;

import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREGENERALType;

/**
 * The Interface GeneralDictionaryService.
 */
@Service
public interface GeneralDictionaryService {

    /**
     * Country update.
     *
     * @param dg the dg
     * @return the int[]
     */
    int[] countryUpdate(DICTIONNAIREGENERALType dg);

}
