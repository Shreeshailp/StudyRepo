/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.COMPTOOL_ANSWER_JOB_NAM;
import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.CORVET_ANSWER_JOB_NAM;
import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.PROVIDER_ANSWER_JOB_NAM;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.BatchJobEntry;
import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.cli.EngineDaemonCommandLineHandler;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonProviderConfig;
import com.inetpsa.w7t.daemon.services.util.DaemonServiceUtils;
import com.inetpsa.w7t.dictionary.listener.service.DictionaryParserService;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;

/**
 */
@Named("provider")
public class ProviderFileListener extends DefaultFileListener {

    @Logging
    private Logger logger;

    @Inject
    private BatchJobEntry batchJobEntry;

    @Inject
    private DictionaryParserService dictionaryParserService;

    @Configuration("daemon.providers.genome.processInterval")
    private long genomeProcessInterval;

    /** The corvet answer process interval. */
    @Configuration("daemon.providers.corvet.processInterval")
    private long corvetAnswerProcessInterval;

    /** The newton out dir. */
    @Configuration("daemon.providers.corvet.outputDirectory")
    private String corvetOutDir;

    @Configuration("daemon.providers.comptool.outputDirectory")
    private String compToolOutDir;

    @Inject
    private RequestRepository requestRepository;

    public ProviderFileListener() {
        super();
    }

    public ProviderFileListener(String name, DaemonProviderConfig config, Integer refreshInterval) {
        super(name, config.getInputDirectory(), config.getOutputDirectory(), config.getFilenamePattern(), refreshInterval);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.FileListener#run()
     */
    @Override
    public void run() {
        Thread.currentThread().setName("provider-listener-".concat(name));
        logger.info("Provider listener {} started", this.name);
        Integer fileFoundCount = 0;
        Integer refreshIntSec = refreshInterval / 1000;
        Instant corvetAnswerInterval = Instant.now().minus(corvetAnswerProcessInterval + 1, ChronoUnit.SECONDS);
        while (!EngineDaemonCommandLineHandler.isSigintRequested()) {
            long start = System.currentTimeMillis();
            logger.debug("Provider Listener {} loop started", this.name);

            try {
                if (("genome").equalsIgnoreCase(this.name)) {
                    if (retrieveFile().isPresent()) {
                        fileFoundCount += refreshIntSec;
                    }
                    if (fileFoundCount > genomeProcessInterval) {
                        this.retrieveFile().ifPresent(this::parseFile);
                        fileFoundCount = 0;
                    }
                } else if (("corvet").equalsIgnoreCase(this.name)) {
                    if (corvetAnswerInterval.until(Instant.now(), ChronoUnit.SECONDS) > corvetAnswerProcessInterval) {
                        logger.info("Executing the [{}]", CORVET_ANSWER_JOB_NAM);
                        batchJobEntry.runJob(CORVET_ANSWER_JOB_NAM, corvetOutDir, "");
                        corvetAnswerInterval = Instant.now();
                    }
                } else if (("comptool").equalsIgnoreCase(this.name)) {
                    if (corvetAnswerInterval.until(Instant.now(), ChronoUnit.SECONDS) > corvetAnswerProcessInterval) {
                        String newtonResponseMachineName = DaemonConfig.getBcvResMachine();
                        logger.info("Fetching the comptool data count ");
                        Object[] objArray = requestRepository.fetchComptoolDataCount(newtonResponseMachineName);
                        if (objArray != null && objArray.length > 0) {
                            String internalFileId = (String) objArray[0];
                            BigInteger recordCount = (BigInteger) objArray[1];

                            logger.info("Initial record count [{}] for the internal file id[{}] when the query fires from the xml ", recordCount,
                                    internalFileId);

                            int totalRecordsFromDatabase = requestRepository.getAllRequestsCountFromDatabase(internalFileId);
                            logger.info("Total records from the database are [{}] for the internal file id [{}]", totalRecordsFromDatabase,
                                    internalFileId);
                            if (recordCount.intValue() == totalRecordsFromDatabase) {
                                logger.info("Executing the [{}]", COMPTOOL_ANSWER_JOB_NAM);
                                batchJobEntry.runJob(COMPTOOL_ANSWER_JOB_NAM, compToolOutDir, "");
                                logger.info("After the run job [{}]", COMPTOOL_ANSWER_JOB_NAM);
                            }
                        }

                        requestRepository.clearSession();
                        corvetAnswerInterval = Instant.now();
                    }
                } else {
                    this.retrieveFile().ifPresent(this::parseFile);
                }
            } catch (RuntimeException e) {
                logger.error(String.format("Client file listener '%s' error !", this.name), e);
            }

            long end = System.currentTimeMillis();
            long delta = end - start;
            try {
                TimeUnit.MILLISECONDS.sleep(Math.max(refreshInterval - delta, 0));
            } catch (InterruptedException e) {
                logger.error(String.format("Provider file listener '%s' interrupted !", this.name), e);
                Thread.currentThread().interrupt();
            }
            logger.debug("Provider Listener {} loop ended", this.name);
        }
        logger.info("Provider Listener {} stopped", this.name);
    }

    @Override
    protected Optional<File> retrieveFile() {
        return Optional.ofNullable(DaemonServiceUtils.getTheOldestFile(inputDirectory, filenamePattern));
    }

    @Override
    protected void parseFile(File file) {
        try {
            if (("newton").equalsIgnoreCase(this.name)) {
                batchJobEntry.runJob(PROVIDER_ANSWER_JOB_NAM, BatchUtils.moveFileForProcessing(file).getAbsolutePath(), "");
            } else if (("genome").equalsIgnoreCase(this.name)) {
                dictionaryParserService.parse(BatchUtils.moveFileToHistory(file).getAbsolutePath());
            }
        } catch (IOException e) {
            logger.error("Cound not parse file ", e);
        }
    }
}
