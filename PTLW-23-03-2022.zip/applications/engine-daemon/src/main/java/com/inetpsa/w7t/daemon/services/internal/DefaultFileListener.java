/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.io.File;
import java.util.Optional;

import com.inetpsa.w7t.daemon.services.FileListener;

public abstract class DefaultFileListener implements FileListener {

    protected String name;
    protected File inputDirectory;
    protected File outputDirectory;
    protected String filenamePattern;
    protected Integer refreshInterval;

    public DefaultFileListener() {
    }

    DefaultFileListener(String name, File inputDirectory, File outputDirectory, String filenamePattern, Integer refreshInterval) {
        super();
        this.name = name;
        this.inputDirectory = inputDirectory;
        this.outputDirectory = outputDirectory;
        this.filenamePattern = filenamePattern;
        this.refreshInterval = refreshInterval;
    }

    protected abstract Optional<File> retrieveFile();

    protected abstract void parseFile(File file);
}
