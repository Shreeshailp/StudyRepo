package com.inetpsa.w7t.batch.mapxml;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class ClientServiceRequest.
 */
@XmlRootElement(name = "wltp_service")
@XmlAccessorType(XmlAccessType.FIELD)
public class ClientServiceRequest {

    public ClientServiceRequest() {
        // For jaxb
    }

    @XmlAttribute(name = "file_id")
    private String fileId;

    @XmlAttribute(name = "request_date")
    private Date requestDate;

    @XmlElement(name = "request")
    private List<ClientResponse> clientResponse;

    /**
     * Instantiates a new client service request.
     *
     * @param fileId the file id
     * @param requestDate the request date
     * @param clientResponse the client response
     */
    public ClientServiceRequest(String fileId, Date requestDate, List<ClientResponse> clientResponse) {
        super();
        this.fileId = fileId;
        this.requestDate = requestDate;
        this.clientResponse = clientResponse;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public List<ClientResponse> getCorvetRequests() {
        return clientResponse;
    }

    public void setCorvetRequests(List<ClientResponse> corvetRequests) {
        this.clientResponse = corvetRequests;
    }

}
