/*
 * Creation : 8 juin 2017
 */
package com.inetpsa.w7t.batch;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * The Class SpringContextUtil.
 */
public class SpringContextUtil implements ApplicationContextAware {

    /** The application context. */
    private static ApplicationContext applicationContext;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        setContext(applicationContext);
    }

    /**
     * Gets the application context.
     *
     * @return the application context
     */
    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    /**
     * Sets the context.
     *
     * @param appContext the app context
     * @return the application context
     */
    private static ApplicationContext setContext(ApplicationContext appContext) {
        applicationContext = appContext;
        return applicationContext;
    }

    /**
     * Instantiates a new spring context util.
     */
    private SpringContextUtil() {

    }
}
