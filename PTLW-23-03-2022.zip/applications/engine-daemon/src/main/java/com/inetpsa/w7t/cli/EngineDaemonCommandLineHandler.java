package com.inetpsa.w7t.cli;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.seedstack.seed.Logging;
import org.seedstack.seed.cli.CliCommand;
import org.seedstack.seed.cli.CommandLineHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.daemon.services.EngineDaemonService;

/**
 * The Class EngineDaemonCommandLineHandler.
 */
@CliCommand("wltp-engine-daemon")
public class EngineDaemonCommandLineHandler implements CommandLineHandler {

    @Logging
    private Logger logger;

    @Inject
    private EngineDaemonService engineDaemonService;

    private static Boolean sigintRequested = false;

    public static Boolean isSigintRequested() {
        return sigintRequested;
    }

    private static void setSigintRequested(Boolean state) {
        sigintRequested = state;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.util.concurrent.Callable#call()
     */
    @Override
    public Integer call() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                Logger log = LoggerFactory.getLogger(this.getClass());
                log.info("Daemon shutdown requested, stopping file listeners and lifecycle service...");
                setSigintRequested(true);

                Integer running;
                while ((running = engineDaemonService.getRunningThreads()) != 0) {
                    try {
                        log.info("Waiting for application to shutdown... {}/{} workers remaining", running, engineDaemonService.getTotalThreads());
                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException e) {
                        log.error("Error ocurred during application shutdown", e);
                        Thread.currentThread().interrupt();
                    }
                }
                log.info("Application shutdown successful");
            }
        });

        engineDaemonService.run();

        while (engineDaemonService.isRunning()) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                logger.error("Engine daemon command line handler interrupted !", e);
                Thread.currentThread().interrupt();
            }
        }

        return 0;
    }
}
