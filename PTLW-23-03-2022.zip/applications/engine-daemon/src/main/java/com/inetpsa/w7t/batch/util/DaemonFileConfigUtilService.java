/*
 * Creation : 13 Jan 2020
 */
package com.inetpsa.w7t.batch.util;

import org.seedstack.business.Service;

/**
 * The Interface DaemonFileConfigUtilService.
 */
@Service
public interface DaemonFileConfigUtilService {

    /**
     * Gets the indus fs flag path.
     *
     * @return the indus fs flag path
     */
    String getIndusFsFlagPath();

    /**
     * Gets the fs flag path.
     *
     * @return the fs flag path
     */
    String getFsFlagPath();

    /**
     * Gets the file prefix.
     *
     * @return the file prefix
     */
    String getFilePrefix();

    /**
     * Gets the file suffix.
     *
     * @return the file suffix
     */
    String getFileSuffix();

    /**
     * Gets the req mac name.
     *
     * @return the req mac name
     */
    String getReqMacName();

    /**
     * Gets the res mac name.
     *
     * @return the res mac name
     */
    String getResMacName();

    /**
     * Gets the comp tool time out.
     *
     * @return the comp tool time out
     */
    int getCompToolTimeOut();

}
