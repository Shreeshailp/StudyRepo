/*
 * Creation : 17 Jan 2020
 */
package com.inetpsa.w7t.provider.batch;

import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.domains.engine.model.request.Request;

/**
 * The Class CorvetAnswerItemProcessor.
 */
public class CorvetAnswerItemProcessor implements ItemProcessor<Request, Request> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public Request process(Request request) throws Exception {
        return request;
    }

}
