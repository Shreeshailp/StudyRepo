/*
 * Creation : 19 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import org.seedstack.business.Service;

import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREFAMILLEType;

/**
 * The Interface FamilyDictionaryService.
 */
@Service
public interface FamilyDictionaryService {

    /**
     * Mtac update.
     *
     * @param dft the dft
     * @return the int[]
     */
    int[] mtacUpdate(DICTIONNAIREFAMILLEType dft);

}
