/*
 * Creation : 21 Jan 2020
 */
package com.inetpsa.w7t.provider.batch;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.ThreadPoolMasterRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.NewtonEntity;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedDataFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.shared.NewtonAnswerErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.wltphub.answer.services.WltpHubAnswerService;
import com.inetpsa.w7t.provider.batch.services.CorvetAnswerFileWriterService;
import com.inetpsa.w7t.wltphub.ws.WSPhysicalResult;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class CorvetAnswerFileWriter.
 */
public class CorvetAnswerFileWriter implements ItemWriter<Request> {
    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(CorvetAnswerFileWriter.class);

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "corvetAnswerJob";

    /** The newton jpa repository. */
    @Inject
    private NewtonRepository newtonJpaRepository;

    /** The engine calculator service. */
    @Inject
    private EngineCalculatorService engineCalculatorService;

    /** The request repository. */
    @Inject
    private RequestRepository requestRepository;

    /** The corvet answer file writer service. */
    @Inject
    private CorvetAnswerFileWriterService corvetAnswerFileWriterService;

    /** The resource. */
    private CorvetAnswerFileResource resource;

    /** The chunk size. */
    private static final int CHUNK_SIZE = 500;

    /** The final list to write in file. */
    private CopyOnWriteArrayList<Request> finalListToWriteInFile = new CopyOnWriteArrayList<>();

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The daemon file config util service. */
    @Inject
    private DaemonFileConfigUtilService daemonFileConfigUtilService;

    /** The request batch repository. */
    @Inject
    private RequestBatchRepository requestBatchRepository;

    /** The fs flag file service. */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The wltp hub answer service. */
    @Inject
    private WltpHubAnswerService wltpHubAnswerService;

    /** The calculated data factory. */
    @Inject
    private CalculatedDataFactory calculatedDataFactory;

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The Constant ADDITIONAL_MASS. */
    private static final double ADDITIONAL_MASS = 75.0;

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public CorvetAnswerFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(CorvetAnswerFileResource resource) {
        this.resource = resource;
    }

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends Request> requestsList) throws Exception {
        // List<Request> requestsList = new ArrayList<>(items);// Commented this line of code as part of memory leak issue
        boolean isNewtonOKListEmpty = false;
        boolean isNewtonKOListEmpty = false;
        boolean isWltpHubOKListEmpty = false;
        if (!requestsList.isEmpty()) {
            Map<String, Long> counting = requestsList.stream().collect(Collectors.groupingBy(Request::getInternalFileId, Collectors.counting()));
            String internalFileId = requestsList.get(0).getInternalFileId();
            logger.info("Original list size [{}] for the internal file id [{}]", counting.get(internalFileId), internalFileId);
            Optional<List<Request>> newList = requestRepository.getAllRequests(internalFileId);
            List<WltpHubResponseRepresentation> hubOkList = wltpHubAnswerService.getAllWltpHubAnswers(internalFileId,
                    WltpHubResponseRepresentation.class); // HUB Lot2 changes
            int totalRecordsFromDatabase = 0;

            if (newList.isPresent()) {
                logger.info("Total records from the database are [{}] for the internal file id [{}]", newList.get().size(), internalFileId);
                totalRecordsFromDatabase = newList.get().size();
            }
            if (counting.get(internalFileId) == totalRecordsFromDatabase) {
                List<Request> newtonOKList = null;
                List<Request> wltpHubOKList = null;
                List<Request> newtonKOList = null;
                List<Request> rejectedRequestList = null;
                if (newList.isPresent()) {
                    wltpHubOKList = newList.get().stream()
                            .filter(request -> RequestStatus.CALCULATION_OK.getStatusCode() == request.getStatus().getStatusCode())
                            .collect(Collectors.toList());// HUB Lot2 changes
                    newtonOKList = newList.get().stream()
                            .filter(request -> RequestStatus.NEWTON_OK.getStatusCode() == request.getStatus().getStatusCode())
                            .collect(Collectors.toList());
                    newtonKOList = newList.get().stream()
                            .filter(request -> RequestStatus.NEWTON_KO.getStatusCode() == request.getStatus().getStatusCode())
                            .collect(Collectors.toList());

                    rejectedRequestList = newList.get().stream()
                            .filter(request -> RequestStatus.REQUEST_REJECTED.getStatusCode() == request.getStatus().getStatusCode())
                            .collect(Collectors.toList());
                    if (wltpHubOKList != null && !wltpHubOKList.isEmpty()) {// HUB Lot2 changes
                        List<Request> hubOkRequestList = mapHubResponseToRequest(wltpHubOKList, hubOkList);
                        if (hubOkRequestList != null && !hubOkRequestList.isEmpty()) {
                            logger.info("Wltp Hub Calculation OK list has been added to final list");
                            finalListToWriteInFile.addAll(hubOkRequestList);
                        }

                    } else {
                        isWltpHubOKListEmpty = true;
                    }
                    if (newtonOKList != null && newtonOKList.isEmpty()) {
                        isNewtonOKListEmpty = true;
                    }
                    if (newtonKOList != null && newtonKOList.isEmpty()) {
                        isNewtonKOListEmpty = true;
                    }
                    int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
                    logger.debug("corvetAnswerJob thread pool size : [{}]", threadPoolSize);
                    ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
                    if (newtonOKList != null && !newtonOKList.isEmpty()) {
                        try {
                            logger.info("Parallel Processing Starts Here ...");
                            List<CompletableFuture<Integer>> futuresList = new CopyOnWriteArrayList<>();
                            List<List<Request>> splitedList = ListUtils.partition(newtonOKList, CHUNK_SIZE);
                            if (splitedList != null && !splitedList.isEmpty()) {
                                splitedList.forEach(list -> {
                                    CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {
                                        return processParallelList(list);
                                    }, executorService);
                                    futuresList.add(future);
                                });

//                                splitedList.forEach(list -> {
//                                    Future<Integer> future = executorService.submit(() -> processParallelList(list));
//                                    futuresList.add(future);
//                                });

                            }
                            CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[futuresList.size()])).join();
                            for (CompletableFuture<Integer> future : futuresList) {
                                future.get();

                            }

                        } catch (Exception e) {
                            logger.error("Error when executing parallel request processing for calcualtion : {}", e);
                        } finally {

                            executorService.shutdown();
                        }
                        logger.info("Parallel Processing Ends Here ...");
                        // updateCalculationStatusInREQ();
                    }
                    if (newtonKOList != null && !newtonKOList.isEmpty()) {
                        logger.info("newton KO list has been added to final list");
                        finalListToWriteInFile.addAll(newtonKOList);
                    }
                    if (rejectedRequestList != null && !rejectedRequestList.isEmpty()) {
                        logger.info("rejected record list has been added to final list");
                        finalListToWriteInFile.addAll(rejectedRequestList);
                    }
                    if (!finalListToWriteInFile.isEmpty()) {
                        logger.info("The records has been started to writing in file...");
                        RequestBatch requestBatch = requestBatchRepository.getRequestBatchByInternalFileId(internalFileId);
                        String client = requestBatch.getClient();
                        boolean isOnlyRejectedListFound = false;
                        if (rejectedRequestList != null && !rejectedRequestList.isEmpty() && isWltpHubOKListEmpty && isNewtonOKListEmpty
                                && isNewtonKOListEmpty) {
                            if (requestBatch.getBcvResMacName() == null) {
                                requestBatch.setBcvResMacName(daemonFileConfigUtilService.getResMacName());
                                int result = requestBatchRepository.updateResMacNameAsRecMacName(requestBatch);
                                isOnlyRejectedListFound = true;
                                if (result > 0) {
                                    logger.info(
                                            "Updated the response machine name:[{}], as we have found only rejected requests for the file id:[{}] and internal file id:[{}]",
                                            requestBatch.getBcvResMacName(), requestBatch.getFileId(), requestBatch.getInternalFileId());
                                    writeRecordsIntoFile(requestBatch);
                                }

                            }

                        }
                        if (!isOnlyRejectedListFound) {
                            writeRecordsIntoFile(requestBatch);
                        }

                        String fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(requestBatch.getInternalFileId());
                        if ("corvet".equalsIgnoreCase(client)) {

                            deleteFsFlagFile(fsFlagFileName);
                            int result = fsFlagFileService.deleteFsFlagFileByFileId(requestBatch.getInternalFileId());
                            if (result > 0) {
                                logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                            }
                        } else {
                            deleteFsFlagFile(fsFlagFileName);
                            int result = fsFlagFileService.deleteFsFlagFileByFileId(requestBatch.getInternalFileId());
                            if (result > 0) {
                                logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                            }
                        }
                    }

                }
            }
        }

    }

    /**
     * Map hub response to request.
     *
     * @param wltpHubOKList the wltp hub OK list
     * @param hubOkList     the hub ok list
     * @return the list
     */
    private List<Request> mapHubResponseToRequest(List<Request> wltpHubOKList, List<WltpHubResponseRepresentation> hubOkList) {
        List<Request> hubOKList = new ArrayList<>();
        if (wltpHubOKList.size() == hubOkList.size()) {
            for (WltpHubResponseRepresentation wltpHubResponseRepresentation : hubOkList) {
                for (Request request : wltpHubOKList) {
                    if (request.getRequestId().equalsIgnoreCase(wltpHubResponseRepresentation.getRequest().getRequestID())) {
                        // request.setExtendedTitle(wltpHubResponseRepresentation.getRequest().getVersion16C()
                        // + wltpHubResponseRepresentation.getRequest().getColorExtInt()
                        // + wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
                        hubOKList.add(mapResponseToCalculatedData(request, wltpHubResponseRepresentation));
                    }
                }
            }
        }
        return hubOKList;
    }

    /**
     * Map response to calculated data.
     *
     * @param request                       the request
     * @param wltpHubResponseRepresentation the wltp hub response representation
     * @return the request
     */
    private Request mapResponseToCalculatedData(Request request, WltpHubResponseRepresentation wltpHubResponseRepresentation) {
        CalculatedData cd = calculatedDataFactory.withTestMass(getTestMass(wltpHubResponseRepresentation));
        List<EnginePhysicalQuantity> roadLoad = new ArrayList<>();
        List<EnginePhysicalQuantity> phyResults = new ArrayList<>();
        wltpHubResponseRepresentation.getPhysResult().forEach(ph -> {
            if (ph.getCode().equalsIgnoreCase(CalculationConstants.F0_CODE) || ph.getCode().equalsIgnoreCase(CalculationConstants.F1_CODE)
                    || ph.getCode().equalsIgnoreCase(CalculationConstants.F2_CODE)) {
                roadLoad.add(new EnginePhysicalQuantity(ph.getCode(), Double.valueOf(ph.getValue())));
            } else if (ph.getCode().equalsIgnoreCase(CalculationConstants.FDSC)) {
                cd.setfDownScale(Double.valueOf(ph.getValue()));
            } else if (ph.getCode().equalsIgnoreCase(CalculationConstants.SPEEDLIMIT)) {
                cd.setSpeedLimitFlag(ph.getValue());
            } else if (ph.getCode().equalsIgnoreCase(CalculationConstants.VMAX)) {
                cd.setvMax(ph.getValue());
            } else if (org.apache.commons.lang3.StringUtils.isNoneBlank(ph.getValue()) && NumberUtils.isParsable(ph.getValue())) {
                if (ph.getCode().equalsIgnoreCase(CalculationConstants.MASS_CODE)) {// Added this IF & Else block as part of JIRA-[CALCULWLTP-781]
                    phyResults.add(new EnginePhysicalQuantity(ph.getCode(), Double.valueOf(ph.getValue()) - ADDITIONAL_MASS));
                } else {
                    phyResults.add(new EnginePhysicalQuantity(ph.getCode(), Double.valueOf(ph.getValue())));
                }

            }
        });
        request.updatePhysicalQuantities(phyResults);
        cd.setRoadLoad(roadLoad);

        List<CalculatedPhase> calPhases = new ArrayList<>();
        wltpHubResponseRepresentation.getPhase().forEach(phase -> {
            CalculatedPhase calPh = new CalculatedPhase(phase.getCode());
            phase.getResult().forEach(res -> {
                Optional<MeasureType> measureType = measureTypeRepository.byCode(res.getCode());
                if (measureType.isPresent()) {
                    calPh.addEmission(measureType.get(), Double.parseDouble(res.getValue()));
                }
            });
            calPhases.add(calPh);
        });
        cd.setCalculatedPhases(calPhases);
        request.setCalculatedValues(cd);
        return request;
    }

    /**
     * Gets the test mass.
     *
     * @param wltpHubResponseRepresentation the wltp hub response representation
     * @return the test mass
     */
    private int getTestMass(WltpHubResponseRepresentation wltpHubResponseRepresentation) {
        int testMass = 0;
        if (!wltpHubResponseRepresentation.getPhysResult().isEmpty()) {
            WSPhysicalResult phyResult = wltpHubResponseRepresentation.getPhysResult().stream()
                    .filter(ph -> ph.getCode().equalsIgnoreCase(CalculationConstants.TMASS_CODE)).findAny().orElse(null);
            if (phyResult != null && StringUtils.isNotBlank(phyResult.getValue())) {
                testMass = BigDecimal.valueOf(Double.valueOf(phyResult.getValue())).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
            }
        }
        return testMass;
    }

    /**
     * Delete fs flag file.
     *
     * @param fsFlagFileName the fs flag file name
     */
    private void deleteFsFlagFile(String fsFlagFileName) {
        if (daemonFileConfigUtilService != null) {
            String fsFlagPath = daemonFileConfigUtilService.getFsFlagPath();
            File dir = new File(fsFlagPath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                for (File file : dirContents) {
                    try {
                        if (file.getName().contains(fsFlagFileName)) {
                            FileUtils.forceDelete(file);
                            logger.info("Fs Flag File [{}] has been deleted from the location {}", fsFlagFileName, fsFlagPath);
                            break;
                        }
                    } catch (IOException e) {
                        logger.error("Exception while deleting the file : {}", e);
                    }
                }
            }
        }
    }

//    /**
//     * Update calculation status.
//     *
//     * @param updateStatusList the update status list
//     * @return the int
//     */
//    private void updateCalculationStatus(List<Request> updateStatusList) {
//        for (Request request : updateStatusList) {
//            int updatedStatus = requestRepository.updateCalculationStatus(request.getStatus().getStatusCode(), request.getAnswerCode(),
//                    request.getAnswerDesignation(), request.getRequestId(), request.getInternalFileId());
//            if (updatedStatus > 0) {
//                logger.info("REQUEST_ID = [{}] UPDATED STATUS=[{}]", request.getRequestId(), request.getStatus().getStatusCode());
//            }
//        }
//
//    }

    /**
     * Process parallel list.
     *
     * @param requestsList the requests list
     * @return the int
     */
    private int processParallelList(List<Request> requestsList) {
        for (Request request : requestsList) {
            String requestNo = request.getRequestId();
            logger.debug("Request ID[{}]: To be calculated", requestNo);
            try {

                // HUB Lot2 changes
                // Check the status if 70 then don't call the calculator
                // get the response from the new table
                if (!request.getStatus().equals(RequestStatus.CALCULATION_OK)) {
                    NewtonEntity newtonEntity = newtonJpaRepository.getNewtonEntity(request).orElse(null);// Added the fix
                    request.updatePhysicalQuantities(getNewtonPhysicalQuantity(newtonEntity, true));
                    Calculation calculation = engineCalculatorService.calculate(request);
                    request.updatePhysicalQuantities(getNewtonPhysicalQuantity(newtonEntity, false));// Added the fix as
                                                                                                     // part of JIRA-630
                    request.update(calculation.getCalculatedData());
                    request.setStatus(RequestStatus.CALCULATION_OK);
                    request.useAnswer(LocalDateTime.now(), NewtonAnswerErrorCode.CALCULATION_SUCCESS.getRuleCode(),
                            NewtonAnswerErrorCode.CALCULATION_SUCCESS.getDescription());
                    finalListToWriteInFile.add(request);
                }
            } catch (SeedException se) {
                // JIRA-445 Fix Starts Here
                if (se.getErrorCode() instanceof WltpErrorCode) {
                    WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                    request.setStatus(RequestStatus.CALCULATION_KO);
                    finalListToWriteInFile.add(request);
                } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                    WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                    request.setStatus(RequestStatus.CALCULATION_KO);
                    finalListToWriteInFile.add(request);
                }
                // JIRA-445 Fix Ends Here
            } catch (RuntimeException e) {
                LogErrorUtility.logTheError(logger, requestNo, "ERRW400", "Illegal calculation state error, check engine logs");
                request.useAnswer(LocalDateTime.now(), "ERRW400", "Illegal calculation state error, check engine logs");
                finalListToWriteInFile.add(request);
            }
        }

        return 1;
    }

    /**
     * Gets the newton physical quantity.
     *
     * @param newtonEntity   the newton entity
     * @param forCalculation the for calculation
     * @return the newton physical quantity
     */
    private List<EnginePhysicalQuantity> getNewtonPhysicalQuantity(NewtonEntity newtonEntity, boolean forCalculation) {
        List<EnginePhysicalQuantity> enginePhysicalQuantityList = new ArrayList<>();

        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.MASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleMass())));
        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.SCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleSCx())));
        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleCRR())));
        if (!forCalculation) {
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.UMASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getUnladenMass())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.EMASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getEquipmentMass())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.ESCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getEquipmentSCx())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.USCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getUnladenSCx())));
        }
        return enginePhysicalQuantityList;
    }

    /**
     * Gets the primitive type for NULL.
     *
     * @param value the value
     * @return the primitive type for NULL
     */
    private double getPrimitiveTypeForNULL(Double value) {
        if (value == null)
            return 0.0;
        return value.doubleValue();
    }

//    /**
//     * Update calculation status in REQ.
//     */
//    private void updateCalculationStatusInREQ() {
//        if (!finalListToWriteInFile.isEmpty()) {
//            updateCalculationStatus(finalListToWriteInFile);
//        }
//
//    }

    /**
     * Write records into file.
     *
     * @param requestBatch the request batch
     */
    private void writeRecordsIntoFile(RequestBatch requestBatch) {
        if (!finalListToWriteInFile.isEmpty()) {
            String internalFileId = finalListToWriteInFile.get(0).getInternalFileId();
            for (Request request : finalListToWriteInFile) {
                if (corvetAnswerFileWriterService != null) {
                    corvetAnswerFileWriterService.writeCorvetAnswer(request, requestBatch);
                    int updatedStatus = requestRepository.updateCalculationStatus(RequestStatus.ANSWER_SENT.getStatusCode(), request.getAnswerCode(),
                            request.getAnswerDesignation(), request.getRequestId(), request.getInternalFileId());
                    if (updatedStatus > 0) {
                        logger.info("Updated the answer sent STATUS=[{}] for the internal File Id [{}]", RequestStatus.ANSWER_SENT.getStatusCode(),
                                internalFileId);
                    }
                }
            }

            if (corvetAnswerFileWriterService != null) {
                corvetAnswerFileWriterService.convertToxmlFile(getResource().getFile(), internalFileId);
            }
        }

    }
}
