/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.io.FileUtils;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.mapxml.ClientAnswer;
import com.inetpsa.w7t.batch.mapxml.ClientResponse;
import com.inetpsa.w7t.batch.mapxml.PhaseResult;
import com.inetpsa.w7t.batch.mapxml.PhaseResultDto;
import com.inetpsa.w7t.batch.mapxml.Phases;
import com.inetpsa.w7t.batch.mapxml.PhysicalResult;
import com.inetpsa.w7t.batch.mapxml.WltpData;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonClientConfig;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase.CalculatedMeasure;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;
import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.references.cache.WltpCacheManager;
import com.inetpsa.w7t.domains.references.common.EmissionConstants;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

/**
 * The Class ClientFileWriter.
 */
@Named("client")
public class ClientFileWriter extends DefaultFileWriter {

    /** The Constant DATE_FILE_FORMAT. */
    private static final String DATE_FILE_FORMAT = "yyyy-MM-dd-HH-mm-ss";

    /** The Constant JAXB XML declaration property. */
    // private static final String JAXB_XML_DEC_PROP = "com.sun.xml.internal.bind.xmlDeclaration";

    /**
     * Commented above code as part of OPEN JDK11 changes
     */
    private static final String JAXB_XML_DEC_PROP = "jaxb.fragment";

    /** The Constant ADDITIONAL_MASS. */
    private static final double ADDITIONAL_MASS = 75.0;

    /** The logger. */
    @Logging
    private static Logger logger;

    /** The request batch repository. */
    @Inject
    private RequestBatchRepository requestBatchRepository;

    @Inject
    private FamilyRepository familyRepository;

    @Inject
    private DestinationDetailsRepository destinationDetailsRepository;

    @Inject
    private MeasureTypeRepository measureTypeRepository;

    @Inject
    private TVVRepository tvvRepository;

    /** The physical quantity type repository. */
    @Inject
    PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    @Configuration("daemon.bcvResMacName")
    private static String bcvResMacName;

    public static final String LOW = "LOW";
    public static final String MID = "MID";
    public static final String HIGH = "HIGH";
    public static final String EHIGH = "EHIGH";
    public static final String COMB = "COMB";

    private boolean isCodeSPresent = false;
    private boolean isCodeHPresent = false;
    private boolean isCodeLPresent = false;

    /** The Constant MARKETING_ANSWER_SENT_LOG. */
    private static final String ANSWER_SENT_LOG = "Request=[{}], AnswerCode=[{}], AnswerDesignation=[{}]";

    private static final String CITY = "CITY";

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Instantiates a new client file writer.
     */
    public ClientFileWriter() {
        super();
    }

    /**
     * Instantiates a new client file writer.
     *
     * @param name the name
     * @param config the config
     */
    public ClientFileWriter(String name, DaemonClientConfig config) {
        super(name, config.getOutputDirectory(), config.getFilenamePattern());
    }

    /**
     * Gets the jaxb xml dec prop.
     *
     * @return the jaxb xml dec prop
     */
    public static String getJaxbXmlDecProp() {
        return JAXB_XML_DEC_PROP;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.FileWriter#serialize(com.inetpsa.w7t.domains.engine.model.request.Request)
     */
    @Override
    public synchronized void serialize(Request request) {
        logger.debug("Entering Client File Writer Serialize for client ({}) request ({})", name, request.getGuid());
        try {
            JAXBContext contextObj = JAXBContext.newInstance(ClientResponse.class);

            Marshaller marshallerObj = contextObj.createMarshaller();
            // marshallerObj.setProperty(JAXB_XML_DEC_PROP, Boolean.FALSE);
            marshallerObj.setProperty(JAXB_XML_DEC_PROP, Boolean.TRUE);

            StringBuilder temFilePath = new StringBuilder(tempDirectory.getAbsolutePath()).append(File.separator).append("answer_")
                    .append(filenamePattern).append("_").append(request.getRequestBatchId()).append(".tmp");

            try (FileOutputStream fos = new FileOutputStream(new File(temFilePath.toString()), true)) {
                marshallerObj.marshal(getResponseObj(request), fos);
                logger.info(ANSWER_SENT_LOG, request.getRequestId(), request.getAnswerCode(), request.getAnswerDesignation());
            }
        } catch (JAXBException | IOException e) {
            logger.error("Error Marshalling {} answer: ", name, e);
        }
    }

    /**
     * Gets the response obj.
     *
     * @param request the request
     * @return the response obj
     */
    private ClientResponse getResponseObj(Request request) {
        isCodeSPresent = false;
        isCodeHPresent = false;
        isCodeLPresent = false;
        ClientResponse clientResponse = new ClientResponse();
        clientResponse.setRequestNumber(request.getRequestId());
        clientResponse.setVin(request.getVin());

        ClientAnswer clientAnswer = new ClientAnswer();

        request.answerCode().ifPresent(clientAnswer::setCode);
        request.answerDesignation().ifPresent(clientAnswer::setDesignation);

        if (request.getStatus().isSuccessStatus()) {

            WltpData wltpData = new WltpData();
            Optional<FamilyDetails> family = getFamilyDetails(request.getWltpFamily(request.getRequestId()),
                    Integer.parseInt(request.getWltpIndex(request.getRequestId())));
            family.map(FamilyDetails::getType).ifPresent(wltpData::setVehType);

            destinationDetailsRepository.byCountryAndDate(request.getProgramCountry(), "GG8", request.getEcomDate()).map(DestinationDetails::getLabel)
                    .ifPresent(wltpData::setDestination);
            clientAnswer.setWltpData(wltpData);
            if (request.getCalculatedValues() != null) {
                List<PhysicalResult> physResultList = new ArrayList<>();

                request.getCalculatedValues().getRoadLoad().map(List::stream).orElseGet(Stream::empty).map(pq -> {
                    PhysicalResult physResult = new PhysicalResult();
                    physResult.setCode(pq.getCode());
                    physResult.setValue(getNumericAnswerInFormat(pq.getCode(), pq.getValue()));
                    return physResult;
                }).forEach(physResultList::add);

                Optional<List<EnginePhysicalQuantity>> enginePhysicalQuantities = request.physicalQuantities();
                if (enginePhysicalQuantities.isPresent()) {
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.MASS_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            eq.setValue(eq.getValue() + ADDITIONAL_MASS);
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }

                    });
                }
                request.getCalculatedValues().getTestMass().map(tm -> {
                    PhysicalResult physResult = new PhysicalResult();
                    physResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.TMASS_CODE));
                    physResult.setValue(tm.toString());
                    return physResult;
                }).ifPresent(physResultList::add);

                if (enginePhysicalQuantities.isPresent()) {
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.EMASS_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }

                    });
                }
                if (enginePhysicalQuantities.isPresent()) {
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.UMASS_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }

                    });
                }

                if (enginePhysicalQuantities.isPresent()) {
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.SCX_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }
                    });

                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.ESCX_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }
                    });
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.USCX_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }
                    });
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.CRR_CODE.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                        }

                    });
                }

                List<TVV> tvv = getTVVDetails(request.getVehicleFamily(request.getRequestId()), request.getTvvT1A(), request.getTvvT1B(),
                        request.getTvv());
                // JIRA-CALCULWLTP-253 Fix Starts here
                String tempSValue = "";
                String tempHValue = "";
                String tempLValue = "";
                String tempCompleteFlag = "";
                String vMax = "";
                Optional<TVV> tvvOptional = tvv.stream().findFirst();
                if (tvvOptional.isPresent()) {
                    TVV tvv1 = tvvOptional.get();
                    if (tvv1 != null) {
                        wltpData.setCategory(tvv1.getTvvVehicleCategory());
                        if (tvv1.getTvvAf() != null) {
                            String sValue = String.valueOf(tvv1.getTvvAf());
                            tempSValue = sValue.replace(".", ",");
                        }
                        if (tvv1.getTvvHeigth() != null) {
                            String hValue = String.valueOf(tvv1.getTvvHeigth());
                            tempHValue = hValue.replace(".", ",");
                        }
                        if (tvv1.getTvvWidth() != null) {
                            String lValue = String.valueOf(tvv1.getTvvWidth());
                            tempLValue = lValue.replace(".", ",");
                        }
                        if (tvv1.getTvvCompleteFlag() != null) {
                            tempCompleteFlag = tvv1.getTvvCompleteFlag();
                        }
                        if (tvv1.getTvvMaxspeed() != null) {
                            vMax = String.valueOf(tvv1.getTvvMaxspeed());
                        }
                    }

                }
                // The below lines has been commented as part of JIRA-603 Fix
                // request.getCalculatedValues().getCrrEfficiency().map(ee -> {
                // PhysicalResult physResult = new PhysicalResult();
                // physResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.CRREC_CODE));
                // physResult.setValue(ee);
                // return physResult;
                // }).ifPresent(physResultList::add);

                // JIRA-CALCULWLTP-480 Fix Starts here
                if (enginePhysicalQuantities.isPresent()) {
                    enginePhysicalQuantities.get().stream().forEach(eq -> {
                        PhysicalResult physResult = new PhysicalResult();
                        if (CalculationConstants.S.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                            isCodeSPresent = true;
                        }
                        if (CalculationConstants.H.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                            isCodeHPresent = true;
                        }
                        if (CalculationConstants.L.equals(eq.getCode())) {
                            physResult.setCode(eq.getCode());
                            physResult.setValue(getNumericAnswerInFormat(eq.getCode(), eq.getValue()));
                            physResultList.add(physResult);
                            isCodeLPresent = true;
                        }

                    });
                }

                // JIRA-CALCULWLTP-480 Fix Ends here

                if (!isCodeSPresent && !tempSValue.isEmpty()) {
                    PhysicalResult sPhysicalResult = new PhysicalResult();
                    sPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.S));
                    sPhysicalResult.setValue(tempSValue);
                    physResultList.add(sPhysicalResult);
                    isCodeSPresent = false;

                }

                if (!isCodeHPresent && !tempHValue.isEmpty()) {
                    PhysicalResult hPhysicalResult = new PhysicalResult();
                    hPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.H));
                    hPhysicalResult.setValue(tempHValue);
                    physResultList.add(hPhysicalResult);
                    isCodeHPresent = false;

                }

                if (!isCodeLPresent && !tempLValue.isEmpty()) {
                    PhysicalResult lPhysicalResult = new PhysicalResult();
                    lPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.L));
                    lPhysicalResult.setValue(tempLValue);
                    physResultList.add(lPhysicalResult);
                    isCodeLPresent = false;
                }

                if (family.isPresent()) {
                    PhysicalResult physResult = new PhysicalResult();
                    physResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.ROADLOAD_TYPE));
                    physResult.setValue(family.get().getRoadLoad());
                    physResultList.add(physResult);
                }

                if (!tempCompleteFlag.isEmpty()) {
                    PhysicalResult cfPhysicalResult = new PhysicalResult();
                    cfPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.COMPL));
                    cfPhysicalResult.setValue(tempCompleteFlag);
                    physResultList.add(cfPhysicalResult);

                }

                if (request.getCalculatedValues().getSpeedLimitFlag() != null && !request.getCalculatedValues().getSpeedLimitFlag().isEmpty()) {
                    PhysicalResult speedLimit = new PhysicalResult();
                    speedLimit.setCode(getPhysicalQuantityTypeCode(CalculationConstants.SPEEDLIMIT));
                    speedLimit.setValue(request.getCalculatedValues().getSpeedLimitFlag());
                    physResultList.add(speedLimit);
                }

                if (request.getCalculatedValues().getfDownScale() != null) {
                    String fDownscale = String.valueOf(request.getCalculatedValues().getfDownScale());
                    fDownscale = fDownscale.replace(".", ",");
                    PhysicalResult fdsc = new PhysicalResult();
                    fdsc.setCode(getPhysicalQuantityTypeCode(CalculationConstants.FDSC));
                    fdsc.setValue(fDownscale);
                    physResultList.add(fdsc);
                }

                if (!vMax.isEmpty()) {
                    PhysicalResult vmax = new PhysicalResult();
                    vmax.setCode(getPhysicalQuantityTypeCode(CalculationConstants.VMAX));
                    vmax.setValue(vMax);
                    physResultList.add(vmax);
                }

                if (request.getMaturity() != null && !request.getMaturity().isEmpty()) {
                    PhysicalResult maturity = new PhysicalResult();
                    maturity.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MATURITY));
                    maturity.setValue(request.getMaturity());
                    physResultList.add(maturity);
                }
                // JIRA-CALCULWLTP-253 Fix Ends here

                clientAnswer.setPhysResultList(physResultList);

                List<Phases> phasesList = new ArrayList<>();
                request.getCalculatedValues().getCalculatedPhases().map(List::stream).orElseGet(Stream::empty).map(p -> {
                    Phases phases = new Phases();
                    phases.setCode(p.getPhaseCode());
                    phases.setPhaseResultList(getPhaseResults(p.emissions()));
                    return phases;
                }).forEach(phasesList::add);

                List<Phases> sortedPhasesList = new ArrayList<>(6);
                sortedPhasesList.addAll(phasesList);
                if (!phasesList.isEmpty() && phasesList.size() == 1) {
                    sortedPhasesList.set(0, phasesList.get(0));
                } else if (!phasesList.isEmpty() && phasesList.size() <= 2) {
                    for (Phases phases : phasesList) {
                        if (phases.getCode().equalsIgnoreCase(CITY)) {
                            sortedPhasesList.set(0, phases);
                        } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                            sortedPhasesList.set(1, phases);
                        }
                    }
                } else if (!phasesList.isEmpty() && phasesList.size() <= 5) {
                    for (Phases phases : phasesList) {
                        if (phases.getCode().equalsIgnoreCase(LOW)) {
                            sortedPhasesList.set(0, phases);
                        } else if (phases.getCode().equalsIgnoreCase(MID)) {
                            sortedPhasesList.set(1, phases);
                        } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                            sortedPhasesList.set(2, phases);
                        } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                            sortedPhasesList.set(3, phases);
                        } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                            sortedPhasesList.set(4, phases);
                        }
                    }

                } else if (!phasesList.isEmpty() && phasesList.size() <= 6) {
                    for (Phases phases : phasesList) {
                        if (phases.getCode().equalsIgnoreCase(LOW)) {
                            sortedPhasesList.set(0, phases);
                        } else if (phases.getCode().equalsIgnoreCase(MID)) {
                            sortedPhasesList.set(1, phases);
                        } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                            sortedPhasesList.set(2, phases);
                        } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                            sortedPhasesList.set(3, phases);
                        } else if (phases.getCode().equalsIgnoreCase(CITY)) {
                            sortedPhasesList.set(4, phases);
                        } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                            sortedPhasesList.set(5, phases);
                        }
                    }

                }
                clientAnswer.setPhasesList(sortedPhasesList);
            }
        }
        clientResponse.setClientAnswer(clientAnswer);

        return clientResponse;
    }

    /**
     * Gets the numeric answer in required format which is decimal separating comma and non scientific representation of the number rounded according
     * to pattern defined for the param code provided. The RoundingMode used is HALF_UP.
     *
     * @param string the value
     * @param d
     * @return the numeric answer in format
     */
    private String getNumericAnswerInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.FRANCE);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = 0;
        if (pattern.length() < 2)
            scale = 0;
        else
            scale = pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * Gets the numeric answer in required format which is decimal separating comma and non scientific representation of the number rounded according
     * to the param roundingDigit provided. This function supports rounding upto 5 decimals. The RoundingMode used is HALF_UP.
     *
     * @param roundingDigit the rounding digit
     * @param value the value
     * @return the numeric answer in format
     */
    private String getNumericAnswerInFormat(int roundingDigit, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.FRANCE);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the family details.
     *
     * @param familyCode the family code
     * @param familyIndex the family index
     * @return the family details
     */
    private Optional<FamilyDetails> getFamilyDetails(String familyCode, int familyIndex) {
        return familyRepository.byCodeAndIndexDetails(familyCode, familyIndex);
    }

    /**
     * Gets the phase results.
     *
     * @param emissions the emissions
     * @return the phase results
     */
    private List<PhaseResult> getPhaseResults(List<CalculatedMeasure> emissions) {
        List<PhaseResult> phaseResultList = new ArrayList<>();
        Set<PhaseResultDto> emissionSet = new TreeSet<>();
        emissions.forEach(e -> {
            getSortedEmissions(e, emissionSet);

        });
        List<PhaseResultDto> resultList = new ArrayList<>(emissionSet);
        resultList.stream().forEach(r -> {
            PhaseResult phaseResult = new PhaseResult();
            phaseResult.setCode(r.getCode());

            int roundingDigits = measureTypeRepository.roundingDigitByCode(r.getCode());
            phaseResult.setValue(getNumericAnswerInFormat(roundingDigits, Double.valueOf(r.getValue())));

            phaseResultList.add(phaseResult);
        });

        return phaseResultList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.FileWriter#publish(com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch)
     */
    @Override
    public void publish(RequestBatch requestBatch) {

        File dest;
        String guId = requestBatch.getGuid().toString();

        try {
            File[] files = tempDirectory.listFiles((dir1, name) -> name.contains(guId) && name.endsWith(".tmp"));

            if (files != null && files.length > 0) {
                File sourceFile = files[0];
                File answerXml = appendRootTag(sourceFile, requestBatch);
                StringBuilder path = new StringBuilder(publishDirectory.getAbsolutePath()).append(File.separator).append(answerXml.getName());
                dest = new File(path.toString());
                FileUtils.moveFile(answerXml, dest);
                logger.debug("Answer file published for client ({}) to location ({})", name, dest);
                if (sourceFile.exists()) {
                    FileUtils.forceDelete(sourceFile);
                }
                requestBatch.setStatus("G");// File Generated
                // requestBatch.setBcvResMacName(bcvResMacName);
                requestBatch.setUpdatedDate(getTodaysDate());
                requestBatchRepository.updateReqBatch(requestBatch);
            }

        } catch (IOException e) {
            logger.error("Exception while publishing file to client directory", e);
        }
    }

    /**
     * Append root tag.
     *
     * @param sourceFile the source file
     * @param requestBatch the request batch
     * @return the file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private File appendRootTag(File sourceFile, RequestBatch requestBatch) throws IOException {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FILE_FORMAT);
        // get new name
        String xmlFile = sourceFile.getName().replace(".tmp", ".xml");
        // Create new Xml File
        File answerXML = new File(sourceFile.getParent().concat(File.separator).concat(xmlFile));
        try (FileWriter answerWriter = new FileWriter(answerXML, true)) {
            // append xml declaration and start tag
            answerWriter.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            answerWriter.append("<wltp_service file_id=\"" + requestBatch.getFileId() + "\" request_date=\""
                    + requestBatch.getRequestDate().format(formatter) + "\" answer_date=\"" + LocalDateTime.now().format(formatter) + "\">");

            // append from tmp file
            try (FileReader reader = new FileReader(sourceFile); BufferedReader tmpFileBr = new BufferedReader(reader)) {
                String currentLine;
                while ((currentLine = tmpFileBr.readLine()) != null) {
                    answerWriter.append(currentLine);
                }
            }
            answerWriter.append("</wltp_service>");
        }

        return answerXML;
    }

    private List<TVV> getTVVDetails(String vehicleFamily, String t1a, String t1b, String tvv) {
        List<TVV> tvvList = new ArrayList<>();
        if (!tvv.isEmpty() && !vehicleFamily.isEmpty() && !t1a.isEmpty() && !t1b.isEmpty()) {
            tvvList = tvvRepository.tvvByFamilyTvvDesigT1AT1B(vehicleFamily, tvv, t1a, t1b);// jira-744, 745, 755 fix ends here
        } else if (!tvv.isEmpty() && !vehicleFamily.isEmpty()) {
            tvvList = tvvRepository.tvvByUniqueFields(vehicleFamily, tvv);
        } else if (!t1a.isEmpty() && !t1b.isEmpty() && !vehicleFamily.isEmpty()) {
            tvvList = tvvRepository.tvvByUniqueFields(vehicleFamily, t1a, t1b);
        }
        return tvvList;
    }

    private String getPhysicalQuantityTypeCode(String code) {
        String pqtCode = null;
        WltpCacheManager<PhysicalQuantityType> wltpCacheManager = WltpCacheManager.getInstance(PhysicalQuantityType.class);
        String key = "PQT";
        List<PhysicalQuantityType> pqtsList = wltpCacheManager.getListItem(key);
        if (pqtsList != null && !pqtsList.isEmpty()) {
            pqtCode = pqtsList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
            return pqtCode;
        }
        List<PhysicalQuantityType> pqtList = physicalQuantityTypeRepository.all();
        wltpCacheManager.putListItem(key, pqtList);
        if (pqtList != null && !pqtList.isEmpty()) {
            pqtCode = pqtList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
        }
        if (pqtCode == null) {
            logger.warn("Physical Quantity Type code '{}' is missing. Please verify the database", code);
        }
        return pqtCode;
    }

    private void getSortedEmissions(CalculatedMeasure emission, Set<PhaseResultDto> emissionSet) {

        if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CE)) {
            PhaseResultDto resultCE = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 0);
            emissionSet.add(resultCE);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FC)) {
            PhaseResultDto resultFC = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 1);
            emissionSet.add(resultFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCB)) {
            PhaseResultDto resultFCB = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 2);
            emissionSet.add(resultFCB);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCG)) {
            PhaseResultDto resultFCG = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 3);
            emissionSet.add(resultFCG);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2)) {
            PhaseResultDto resultCO2 = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 4);
            emissionSet.add(resultCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2B)) {
            PhaseResultDto resultCO2B = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 5);
            emissionSet.add(resultCO2B);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2G)) {
            PhaseResultDto resultCO2G = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 6);
            emissionSet.add(resultCO2G);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EC)) {
            PhaseResultDto resultEC = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 7);
            emissionSet.add(resultEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.PER)) {
            PhaseResultDto resultPER = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 8);
            emissionSet.add(resultPER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCS)) {
            PhaseResultDto resultFCCS = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 9);
            emissionSet.add(resultFCCS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CS)) {
            PhaseResultDto resultCO2CS = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 10);
            emissionSet.add(resultCO2CS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCD)) {
            PhaseResultDto resultFCCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 11);
            emissionSet.add(resultFCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CD)) {
            PhaseResultDto resultCO2CD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 12);
            emissionSet.add(resultCO2CD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECCD)) {
            PhaseResultDto resultECCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 13);
            emissionSet.add(resultECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFECCD)) {
            PhaseResultDto resultUFECCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 14);
            emissionSet.add(resultUFECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCFC)) {
            PhaseResultDto resultWCFC = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 15);
            emissionSet.add(resultWCFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCCO2)) {
            PhaseResultDto resultWCCO2 = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 16);
            emissionSet.add(resultWCCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFEC)) {
            PhaseResultDto resultUFEC = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 17);
            emissionSet.add(resultUFEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AER)) {
            PhaseResultDto resultAER = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 18);
            emissionSet.add(resultAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EAER)) {
            PhaseResultDto resultEAER = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 19);
            emissionSet.add(resultEAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AERCD)) {
            PhaseResultDto resultAERCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 20);
            emissionSet.add(resultAERCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CRCD)) {
            PhaseResultDto resultCRCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 21);
            emissionSet.add(resultCRCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDCCD)) {
            PhaseResultDto resultECDCCD = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 22);
            emissionSet.add(resultECDCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDC)) {
            PhaseResultDto resultECDC = new PhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 23);
            emissionSet.add(resultECDC);
        }
    }

    public static String getTodaysDate() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }
}