/*
 * Creation : 23 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

public class Calculation {

    private CalculatedData calculatedData;

    public Calculation() {
        // Nothing to initialise
    }

    public CalculatedData getCalculatedData() {
        if (calculatedData == null)
            throw new UnsupportedOperationException("The calculated data is not available, call Calculation.setCalculatedData()");
        return calculatedData;
    }

    public Calculation setCalculatedData(CalculatedData calculatedData) {
        this.calculatedData = calculatedData;
        return this;
    }
}
