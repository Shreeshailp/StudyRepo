/*
 * Creation : 5 Feb 2021
 */
package com.inetpsa.w7t.provider.batch.services;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.model.ClientRequest;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Interface EngineDaemonWltpHubService.
 */
@Service
public interface EngineDaemonWltpHubService {

    /**
     * Call wltp hub web service.
     *
     * @param item the Client Request
     * @return the wltp hub response representation
     */
    WltpHubResponseRepresentation callWltpHubWebService(ClientRequest item);
}
