/*
 * Creation : 17 avr. 2017
 */
package com.inetpsa.w7t.provider.batch;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.shared.NewtonAnswerErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.provider.model.NewtonRequestResponse;
import com.inetpsa.w7t.provider.model.NewtonRequestResponseDTO;

/**
 * The Class NewtonAnswerItemProcessor.
 */
public class NewtonAnswerItemProcessor implements ItemProcessor<NewtonRequestResponseDTO, NewtonRequestResponse> {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(NewtonAnswerItemProcessor.class);

    /** The Constant LINE. */
    public static final String LINE = "Line-";

    /** The line number. */
    private int lineNumber;

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /**
     * Instantiates a new newton answer item processor.
     */
    public NewtonAnswerItemProcessor() {
        // For Spring
    }

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @SuppressWarnings("unchecked")
    @Override
    public NewtonRequestResponse process(NewtonRequestResponseDTO item) {

        lineNumber++;
        try {
            if (item.getReqId().isEmpty()) {
                LogErrorUtility.logTheError(logger, item.getReqId(), NewtonAnswerErrorCode.REQUEST_NO_MISSING.getRuleCode(),
                        NewtonAnswerErrorCode.REQUEST_NO_MISSING.getDescription());
                return null;
            }

            String reqId = item.getReqId().trim();

            Date answerDate = new Date();

            if (!item.getAnswerDate().isEmpty()) {
                answerDate = BatchUtils.getDateFromFile(item.getAnswerDate());
            }

            List<NewtonRequestResponse> newtonEntityList = jdbcTemplate.query("select * from W7TQTNEW where REQ_ID= ? order by REQ_DATE desc",
                    new Object[] { reqId }, new NewtonResponseRowMapper());

            NewtonRequestResponse newtonEntity = new NewtonRequestResponse();
            if (!newtonEntityList.isEmpty())
                newtonEntity = newtonEntityList.get(0);

            if (newtonEntity != null) {

                String oldStatus = newtonEntity.getStatus();

                if (newtonEntity.getAnswerDate() != null) {
                    LogErrorUtility.logTheError(logger, item.getRequestNo(), NewtonAnswerErrorCode.REQUEST_NO_ALREADY_PROCESSED.getRuleCode(),
                            NewtonAnswerErrorCode.REQUEST_NO_ALREADY_PROCESSED.getDescription());
                    return null;
                }

                if (item.getAnswerCode().isEmpty()) {
                    newtonEntity.setStatus(String.valueOf(RequestStatus.NEWTON_KO.getStatusCode()));
                    LogErrorUtility.logTheError(logger, item.getRequestNo(), NewtonAnswerErrorCode.ANSWER_CODE_MISSING.getRuleCode(),
                            NewtonAnswerErrorCode.ANSWER_CODE_MISSING.getDescription());
                    item.setAnswerCode(NewtonAnswerErrorCode.ANSWER_CODE_MISSING.getRuleCode());
                    item.setAnswerDesignation(LINE + lineNumber + NewtonAnswerErrorCode.ANSWER_CODE_MISSING.getDescription());
                } else if (newtonEntity.getStatus().equals(String.valueOf(RequestStatus.REQUEST_SENT.getStatusCode()))) {
                    if (item.getAnswerCode().startsWith("OK")) {
                        newtonEntity.setStatus(String.valueOf(RequestStatus.NEWTON_OK.getStatusCode()));
                    }
                    if (!item.getAnswerCode().startsWith("OK")) {
                        newtonEntity.setStatus(String.valueOf(RequestStatus.NEWTON_KO.getStatusCode()));
                    }
                } else if (newtonEntity.getStatus().equals(String.valueOf(RequestStatus.ANSWER_SENT.getStatusCode()))) {
                    return null;
                }
                newtonEntity.setReqId(reqId);
                newtonEntity.setRequestDate(newtonEntity.getRequestDate());
                newtonEntity.setAnswerCode(item.getAnswerCode());
                newtonEntity.setAnswerDate(answerDate);
                newtonEntity.setAnswerDesignation(item.getAnswerDesignation());
                newtonEntity.setUnladenMass(BatchUtils.getDecimalFormat(item.getUnladenMass()));
                newtonEntity.setEquipmentMass(BatchUtils.getDecimalFormat(item.getEquipmentMass()));
                newtonEntity.setVehicleMass(BatchUtils.getDecimalFormat(item.getVehicleMass()));
                newtonEntity.setUnladenSCx(BatchUtils.getDecimalFormat(item.getUnladenSCx()));
                newtonEntity.setEquipmentSCx(BatchUtils.getDecimalFormat(item.getEquipmentSCx()));
                newtonEntity.setVehicleSCx(BatchUtils.getDecimalFormat(item.getVehicleSCx()));
                newtonEntity.setVehicleCRR(BatchUtils.getDecimalFormat(item.getVehicleCRR()));
                newtonEntity.setRequestSent(true);

                // fix for JIRA - 397
                int result = jdbcTemplate.update("UPDATE W7TQTNEW set status = ? where REQ_ID = ?", newtonEntity.getStatus(), reqId);

                if (result > 0)
                    logger.info("Request No [{}] : Old Status [{}], New Status [{}]", reqId, oldStatus, newtonEntity.getStatus());

                return newtonEntity;
            }

        } catch (EmptyResultDataAccessException e) {
            logger.error("ERRW302 - Unknown Newton Request at line {} . Failed record from file: {} ", lineNumber, item, e);

        } catch (Exception e) {
            logger.error("Exception parsing at line {}. Failed record from file: {} ", lineNumber, item, e);
        }

        return null;
    }

}

class NewtonResponseRowMapper implements RowMapper {
    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(NewtonResponseRowMapper.class);

    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        NewtonRequestResponse newtonResponse = new NewtonRequestResponse();
        newtonResponse.setFileId(rs.getString("FILE_ID"));
        newtonResponse.setRequestNo(rs.getString("REQ_NO"));
        newtonResponse.setExtendedTitle(rs.getString("EXTENDED_TITLE"));
        newtonResponse.setStatus(rs.getString("STATUS"));
        newtonResponse.setRequestSent(rs.getBoolean("IS_REQUEST_SENT"));
        newtonResponse.setReqId(rs.getString("REQ_ID"));
        try {
            String strDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                    .format(Date.from(rs.getTimestamp("REQ_DATE").toLocalDateTime().atZone(ZoneId.systemDefault()).toInstant()));
            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = ft.parse(strDate);
            newtonResponse.setRequestDate(date);
        } catch (ParseException e) {
            logger.error("error while parsing date : {}", e);
        }

        return newtonResponse;
    }

}
