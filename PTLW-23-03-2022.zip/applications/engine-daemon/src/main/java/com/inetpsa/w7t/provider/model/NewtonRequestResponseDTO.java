/*
 * Creation : 13 avr. 2017
 */
package com.inetpsa.w7t.provider.model;

/**
 * The Class NewtonRequestResponseDTO.
 */
public class NewtonRequestResponseDTO {

    /** The request no. */
    private String requestNo;

    /** The request date. */
    private String requestDate;

    /** The answer date. */
    private String answerDate;

    /** The answer code. */
    private String answerCode;

    /** The answer designation. */
    private String answerDesignation;

    /** The unladen mass. */
    private String unladenMass;

    /** The equipment mass. */
    private String equipmentMass;

    /** The vehicle mass. */
    private String vehicleMass;

    /** The unladen s cx. */
    private String unladenSCx;

    /** The equipment s cx. */
    private String equipmentSCx;

    /** The vehicle s cx. */
    private String vehicleSCx;

    /** The vehicle crr. */
    private String vehicleCRR;

    /** The extended title. */
    private String extendedTitle;

    /** The req id. */
    private String reqId;

    /**
     * Gets the req id.
     *
     * @return the req id
     */
    public String getReqId() {
        return reqId;
    }

    /**
     * Sets the req id.
     *
     * @param reqId the new req id
     */
    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    /**
     * Gets the request no.
     *
     * @return the request no
     */
    public String getRequestNo() {
        return requestNo;
    }

    /**
     * Sets the request no.
     *
     * @param requestNo the new request no
     */
    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the answer date.
     *
     * @return the answer date
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the answer date.
     *
     * @param answerDate the new answer date
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the unladen mass.
     *
     * @return the unladen mass
     */
    public String getUnladenMass() {
        return unladenMass;
    }

    /**
     * Sets the unladen mass.
     *
     * @param unladenMass the new unladen mass
     */
    public void setUnladenMass(String unladenMass) {
        this.unladenMass = unladenMass;
    }

    /**
     * Gets the equipment mass.
     *
     * @return the equipment mass
     */
    public String getEquipmentMass() {
        return equipmentMass;
    }

    /**
     * Sets the equipment mass.
     *
     * @param equipmentMass the new equipment mass
     */
    public void setEquipmentMass(String equipmentMass) {
        this.equipmentMass = equipmentMass;
    }

    /**
     * Gets the vehicle mass.
     *
     * @return the vehicle mass
     */
    public String getVehicleMass() {
        return vehicleMass;
    }

    /**
     * Sets the vehicle mass.
     *
     * @param vehicleMass the new vehicle mass
     */
    public void setVehicleMass(String vehicleMass) {
        this.vehicleMass = vehicleMass;
    }

    /**
     * Gets the unladen s cx.
     *
     * @return the unladen s cx
     */
    public String getUnladenSCx() {
        return unladenSCx;
    }

    /**
     * Sets the unladen s cx.
     *
     * @param unladenSCx the new unladen s cx
     */
    public void setUnladenSCx(String unladenSCx) {
        this.unladenSCx = unladenSCx;
    }

    /**
     * Gets the equipment s cx.
     *
     * @return the equipment s cx
     */
    public String getEquipmentSCx() {
        return equipmentSCx;
    }

    /**
     * Sets the equipment s cx.
     *
     * @param equipmentSCx the new equipment s cx
     */
    public void setEquipmentSCx(String equipmentSCx) {
        this.equipmentSCx = equipmentSCx;
    }

    /**
     * Gets the vehicle s cx.
     *
     * @return the vehicle s cx
     */
    public String getVehicleSCx() {
        return vehicleSCx;
    }

    /**
     * Sets the vehicle s cx.
     *
     * @param vehicleSCx the new vehicle s cx
     */
    public void setVehicleSCx(String vehicleSCx) {
        this.vehicleSCx = vehicleSCx;
    }

    /**
     * Gets the vehicle crr.
     *
     * @return the vehicle crr
     */
    public String getVehicleCRR() {
        return vehicleCRR;
    }

    /**
     * Sets the vehicle crr.
     *
     * @param vehicleCRR the new vehicle crr
     */
    public void setVehicleCRR(String vehicleCRR) {
        this.vehicleCRR = vehicleCRR;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("NewtonRequestResponseDTO [requestNo=");
        builder.append(requestNo);
        builder.append(", requestDate=");
        builder.append(requestDate);
        builder.append(", answerDate=");
        builder.append(answerDate);
        builder.append(", answerCode=");
        builder.append(answerCode);
        builder.append(", answerDesignation=");
        builder.append(answerDesignation);
        builder.append(", unladenMass=");
        builder.append(unladenMass);
        builder.append(", equipmentMass=");
        builder.append(equipmentMass);
        builder.append(", vehicleMass=");
        builder.append(vehicleMass);
        builder.append(", unladenSCx=");
        builder.append(unladenSCx);
        builder.append(", equipmentSCx=");
        builder.append(equipmentSCx);
        builder.append(", vehicleSCx=");
        builder.append(vehicleSCx);
        builder.append(", vehicleCRR=");
        builder.append(vehicleCRR);
        builder.append(", extendedTitle=");
        builder.append(extendedTitle);
        builder.append(", reqId=");
        builder.append(reqId);
        builder.append("]");
        return builder.toString();
    }
}
