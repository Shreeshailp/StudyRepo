/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.batch;

import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.batch.model.ClientServiceRequest;

/**
 * The Class ClientBatchItemWriter.
 */
public class ClientBatchItemWriter extends JdbcBatchItemWriter<ClientServiceRequest> {

    /** The step execution. */
    private StepExecution stepExecution;

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(ClientBatchItemWriter.class);

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Save step execution.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void saveStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JdbcBatchItemWriter#write(java.util.List)
     */
    @Override
    public void write(final List<? extends ClientServiceRequest> items) throws Exception {

        String batchId = UUID.randomUUID().toString();
        this.stepExecution.getExecutionContext().put("BATCH_ID", batchId);
        this.stepExecution.getExecutionContext().put("FILE_ID", items.get(0).getFileId());

        String sqlSelect = "SELECT INTERNAL_FILE_ID FROM W7TQTRQB where FILE_ID LIKE '%" + items.get(0).getFileId()
                + "%' ORDER BY CREATED_DATE DESC LIMIT 1";
        String internalFileId = items.get(0).getFileId();
        try {
            internalFileId = jdbcTemplate.queryForObject(sqlSelect, new Object[] {}, String.class);
        } catch (EmptyResultDataAccessException e) {
            logger.info("INTERNAL_FILE_ID is null");
        }

        if (internalFileId != null) {
            if (internalFileId.contains("-")) {
                String[] args = internalFileId.split("-");
                int prevFileNo = Integer.parseInt(args[1]);
                internalFileId = args[0] + "-" + (prevFileNo + 1);
            } else
                internalFileId = internalFileId + "-" + 1;
        } else
            internalFileId = items.get(0).getFileId() + "-" + 1;

        for (ClientServiceRequest req : items) {
            req.setBatchId(batchId);
            req.setFileId(req.getFileId());
            req.setInternalFileId(internalFileId);
        }
        this.stepExecution.getExecutionContext().put("INTERNAL_FILE_ID", internalFileId);
        super.write(items);

    }
}
