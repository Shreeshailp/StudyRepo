/*
 * Creation : 3 mai 2017
 */
package com.inetpsa.w7t.listener;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

import com.inetpsa.w7t.batch.util.BatchUtils;

/**
 * The Class StepListenerForFileMove.
 */
public class StepListenerForFileMove implements StepExecutionListener {

    /** The filepath. */
    private String filepath;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Instantiates a new step listener for file move.
     *
     * @param path the path
     */
    public StepListenerForFileMove(String path) {
        this.filepath = path;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#beforeStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public void beforeStep(StepExecution stepExecution) {
        // Auto-generated method stub

    }

    /**
     * Copy completed file to processed folder {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#afterStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        try {

            BatchUtils.moveProcessedFile(filepath);

        } catch (IOException e) {
            logger.error("Failed to copy file to processed dir ", e);
            return ExitStatus.FAILED;
        }

        return ExitStatus.COMPLETED;
    }

}
