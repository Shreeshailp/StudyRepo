/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.batch.mapxml;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * The Class WltpData.
 */
public class WltpData {

    /** The veh type. */
    private String vehType;

    /** The category. */
    private String category;

    /** The destination. */
    private String destination;

    /** The road load. */
    /* private String roadLoad; */

    /**
     * Gets the veh type.
     *
     * @return the veh type
     */
    @XmlAttribute(name = "veh_type")
    public String getVehType() {
        return vehType;
    }

    /**
     * Sets the veh type.
     *
     * @param vehType the new veh type
     */
    public void setVehType(String vehType) {
        this.vehType = vehType;
    }

    /**
     * Gets the category.
     *
     * @return the category
     */
    @XmlAttribute
    public String getCategory() {
        return category;
    }

    /**
     * Sets the category.
     *
     * @param category the new category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the destination.
     *
     * @return the destination
     */
    @XmlAttribute
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination.
     *
     * @param destination the new destination
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    /*
     * @XmlAttribute(name = "roadload") public String getRoadLoad() { return roadLoad; }
     */

    /**
     * Sets the road load.
     *
     * @param roadLoad the new road load
     */
    /*
     * public void setRoadLoad(String roadLoad) { this.roadLoad = roadLoad; }
     */

}
