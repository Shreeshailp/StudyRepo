/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.CLIENT_REQ_JOB_NAM;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.BatchJobEntry;
import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService;
import com.inetpsa.w7t.cli.EngineDaemonCommandLineHandler;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonClientConfig;
import com.inetpsa.w7t.daemon.services.util.DaemonServiceUtils;

/**
 * The listener interface for receiving clientFile events. The class that is interested in processing a clientFile event implements this interface,
 * and the object created with that class is registered with a component using the component's <code>addClientFileListener<code> method. When the
 * clientFile event occurs, that object's appropriate method is invoked.
 *
 * @see ClientFileEvent
 */
@Named("client")
public class ClientFileListener extends DefaultFileListener {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The daemon config. */
    @Configuration
    private DaemonConfig daemonConfig;

    /** The daemon file config util service. */
    @Inject
    private DaemonFileConfigUtilService daemonFileConfigUtilService;

    /**
     * Instantiates a new client file listener.
     */
    public ClientFileListener() {
        super();
    }

    /**
     * Instantiates a new client file listener.
     *
     * @param name            the name
     * @param config          the config
     * @param refreshInterval the refresh interval
     */
    public ClientFileListener(String name, DaemonClientConfig config, Integer refreshInterval) {
        super(name, config.getInputDirectory(), config.getOutputDirectory(), config.getFilenamePattern(), refreshInterval);
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        Thread.currentThread().setName("client-listener-".concat(name));
        logger.info("Client listener {} started", this.name);
        while (!EngineDaemonCommandLineHandler.isSigintRequested()) {
            long start = System.currentTimeMillis();
            logger.debug("Client Listener {} loop started", this.name);

            try {
                if (daemonConfig != null) {
                    String indusFlagPath = daemonConfig.getIndusFsFlagPath();
                    if (indusFlagPath != null && !indusFlagPath.isEmpty()) {
                        File dir = new File(indusFlagPath);
                        File[] dirContents = dir.listFiles();
                        if (dirContents != null && dirContents.length > 0) {
                            logger.info("Indus FS Flag File Path: {}", indusFlagPath);
                            logger.info("Some Database cleanup operations are running, stopping the current job...");
                        } else {
                            this.retrieveFile().ifPresent(this::parseFile);
                        }
                    }
                }

            } catch (RuntimeException e) {
                logger.error(String.format("Client file listener '%s' error !", this.name), e);
            }

            long end = System.currentTimeMillis();
            long delta = end - start;
            try {
                TimeUnit.MILLISECONDS.sleep(Math.max(refreshInterval - delta, 0));
            } catch (InterruptedException e) {
                logger.error(String.format("Client file listener '%s' interrupted !", this.name), e);
                Thread.currentThread().interrupt();
            }
            logger.debug("Client Listener {} loop ended", this.name);
        }
        logger.info("Client Listener {} stopped", this.name);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.internal.DefaultFileListener#retrieveFile()
     */
    @Override
    protected Optional<File> retrieveFile() {
        return Optional.ofNullable(DaemonServiceUtils.getTheOldestFile(inputDirectory, filenamePattern));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.internal.DefaultFileListener#parseFile(java.io.File)
     */
    @Override
    protected void parseFile(File file) {
        try {
            String fsFlagFileName = createFsFlag();
            batchJobEntry.runJob(CLIENT_REQ_JOB_NAM, BatchUtils.moveFileForProcessing(file).getAbsolutePath(), fsFlagFileName);
        } catch (IOException e) {
            logger.error("Cound not parse file ", e);
        }
    }

    /**
     * Creates the fs flag.
     * 
     * @return
     */
    private String createFsFlag() {
        String fsFlagFileName = null;
        if (daemonFileConfigUtilService.getFsFlagPath() != null && !daemonFileConfigUtilService.getFsFlagPath().isEmpty()) {
            if (daemonFileConfigUtilService.getFilePrefix() != null && !daemonFileConfigUtilService.getFilePrefix().isEmpty()
                    && daemonFileConfigUtilService.getFileSuffix() != null && !daemonFileConfigUtilService.getFileSuffix().isEmpty()) {
                try {
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS");
                    LocalDateTime now = LocalDateTime.now();
                    String dateStr = now.format(dateTimeFormatter);
                    String fileName = daemonFileConfigUtilService.getFilePrefix() + "_" + this.name + "_" + dateStr + "_"
                            + daemonFileConfigUtilService.getFileSuffix();
                    BatchUtils.createNewFile(daemonFileConfigUtilService.getFsFlagPath(), fileName);
                    fsFlagFileName = fileName + ".txt";
                    logger.info("FS Flag File [{}] has been created successfully!", fsFlagFileName);
                } catch (IOException e) {
                    logger.error("Failed to create a file in {} : {}", daemonFileConfigUtilService.getFsFlagPath(), e);
                }

            }
        }
        return fsFlagFileName;
    }

}
