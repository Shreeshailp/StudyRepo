/*
 * Creation : 8 juin 2017
 */
package com.inetpsa.w7t.batch;

import org.seedstack.business.Service;

/**
 * The Interface BatchJobEntry.
 */
@Service
@FunctionalInterface
public interface BatchJobEntry {

    /**
     * Run job.
     *
     * @param jobName        the job name
     * @param fileLoc        the file loc
     * @param fsFlagFileName the fs flag file name
     */
    void runJob(String jobName, String fileLoc, String fsFlagFileName);

}
