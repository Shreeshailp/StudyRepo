/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.Service;

/**
 * The Interface RequestLifecycleService.
 */
@Service
@FunctionalInterface
public interface RequestLifecycleService {

    /**
     * Run.
     */
    void run();
}
