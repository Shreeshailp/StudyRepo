/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;

import com.google.inject.Injector;
import com.inetpsa.w7t.daemon.services.FileWriter;
import com.inetpsa.w7t.daemon.services.FileWriterFactory;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonProviderConfig;

public class FileWriterFactoryImpl extends BaseFactory<FileWriter> implements FileWriterFactory {

    @Inject
    private Injector injector;

    @Override
    public FileWriter createClientFileWriter(String name, DaemonClientConfig config) {
        ClientFileWriter client = new ClientFileWriter(name, config);
        injector.injectMembers(client);
        return client;
    }

    @Override
    public FileWriter createProviderFileWriter(String name, DaemonProviderConfig config) {
        ProviderFileWriter provider = new ProviderFileWriter(name, config);
        injector.injectMembers(provider);
        return provider;
    }

}
