/*
 * Creation : 19 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREGENERALType;
import com.inetpsa.w7t.dictionary.listener.model.DictionaryConstants;
import com.inetpsa.w7t.dictionary.listener.service.GeneralDictionaryService;
import com.inetpsa.w7t.domains.core.infrastructure.persistence.LabelRepository;
import com.inetpsa.w7t.domains.core.model.Label;
import com.inetpsa.w7t.domains.core.model.LabelKey;
import com.inetpsa.w7t.domains.moteur.gearbox.services.MoteurGearBoxService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.model.MoteurGearBoxDto;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class GeneralDictionaryServiceImpl implements GeneralDictionaryService {

    @Inject
    Factory<Country> countryfactory;

    @Inject
    private CountryRepository countryRepository;

    @Inject
    private LabelRepository labelRepository;

    Logger genomeLogger = LoggerFactory.getLogger("com.inetpsa.genome");

    private String localeFR = DictionaryConstants.LANGUAGE_TO_READ;

    @Inject
    private MoteurGearBoxService moteurGearBoxService;

    @Override
    public int[] countryUpdate(DICTIONNAIREGENERALType generalDictionnaire) {

        int[] charCount = new int[DictionaryConstants.CHARACTERISTICS_TO_READ.size()];
        genomeLogger.info("General dictionary processing started");
        try {
            generalDictionnaire.getCARACTERISTIQUES().forEach(car -> {
                int charPosition = DictionaryConstants.CHARACTERISTICS_TO_READ.indexOf(car.getNOMCARACTERISTIQUE());
                if (charPosition > -1) {
                    car.getVALEURCARACTERISTIQUE().forEach(valcar -> {
                        valcar.getTEXTE().stream().filter(x -> x.getLANGUE().equalsIgnoreCase(localeFR)).forEach(text -> {
                            if ("B0F".equalsIgnoreCase(car.getNOMCARACTERISTIQUE())) {// Lot17-Family Status Changes
                                moterUpdate(valcar.getNOMVALEUR(), text.getDESIGNATION(), car.getNOMCARACTERISTIQUE());
                            } else if ("B0G".equalsIgnoreCase(car.getNOMCARACTERISTIQUE())) {// Lot17-Family Status Changes
                                gearBoxUpdate(valcar.getNOMVALEUR(), text.getDESIGNATION(), car.getNOMCARACTERISTIQUE());
                            } else {// Lot17-Family Status Changes
                                ctyUpdate(valcar.getNOMVALEUR(), text.getDESIGNATION(), car.getNOMCARACTERISTIQUE());
                            }
                        });
                    });
                    charCount[charPosition]++;
                }
            });
            genomeLogger.info("General dictionary processing completed");
        } catch (RuntimeException e) {
            genomeLogger.error("Error in reading contents of file after parsing! ", e);
        }
        return charCount;
    }

    private void gearBoxUpdate(String code, String designation, String characteristic) {// Lot17-Family Status Changes
        MoteurGearBoxDto moteurGearBoxDto = new MoteurGearBoxDto();
        moteurGearBoxDto.setCode(code);
        moteurGearBoxDto.setDesignation(designation);
        moteurGearBoxDto.setCharacteristic(characteristic);
        moteurGearBoxService.saveGearBoxEntity(moteurGearBoxDto);
    }

    private void moterUpdate(String code, String designation, String characteristic) {// Lot17-Family Status Changes
        MoteurGearBoxDto moteurGearBoxDto = new MoteurGearBoxDto();
        moteurGearBoxDto.setCode(code);
        moteurGearBoxDto.setDesignation(designation);
        moteurGearBoxDto.setCharacteristic(characteristic);
        moteurGearBoxService.saveMoteurEntity(moteurGearBoxDto);
    }

    private void ctyUpdate(String code, String value, String characteristic) {
        try {
            boolean codeFlag = code.length() != 2;
            boolean valFlag = value.length() > 250;
            if (codeFlag || valFlag) {
                List<String> errorsList = new ArrayList<>();
                if (codeFlag)
                    errorsList.add("Code size should be 2");
                if (valFlag)
                    errorsList.add("Value size should be less than or equal to 250");

                genomeLogger.info("Country not created/updated for Code[{}] and Value[{}] as {}", code, value, errorsList);
                return;
            }

            Country country = countryRepository.byCodeAndCharacteristic(code, characteristic);
            Optional<Country> existingCountry = Optional.ofNullable(country);
            if (!existingCountry.isPresent()) {
                Country newCountry = countryfactory.create();
                Label label = new Label();
                LabelKey labelKey = new LabelKey();

                newCountry.setCharacteristic(characteristic);
                newCountry.setCode(code);
                countryRepository.persist(newCountry);

                labelKey.setKey(newCountry.getGuid());
                labelKey.setLocale(localeFR.toLowerCase() + "-" + localeFR);
                label.setKey(labelKey);
                label.setValue(value);
                labelRepository.persist(label);

                genomeLogger.info("Country created {} [{}] FR [{}]", characteristic, code, value);
            } else {

                Optional<Label> ctryLabel = labelRepository.byKeyAndLocale(existingCountry.get().getGuid(), localeFR);

                if (!ctryLabel.isPresent()) {
                    Label label = new Label();
                    LabelKey labelKey = new LabelKey();

                    labelKey.setKey(existingCountry.get().getGuid());
                    labelKey.setLocale(localeFR.toLowerCase() + "-" + localeFR);
                    label.setKey(labelKey);
                    label.setValue(value);
                    labelRepository.save(label);

                    genomeLogger.info("Country label created {} [{}] FR [{}]", characteristic, code, value);

                } else if (ctryLabel.isPresent() && !ctryLabel.get().getValue().equals(value)) {
                    ctryLabel.get().setValue(value);
                    labelRepository.save(ctryLabel.get());

                    genomeLogger.info("Country label updated {} [{}] FR [{}]", characteristic, code, value);
                }
            }
        } catch (RuntimeException e) {
            genomeLogger.error("Error in persistence operations! ", e);
        }
    }
}
