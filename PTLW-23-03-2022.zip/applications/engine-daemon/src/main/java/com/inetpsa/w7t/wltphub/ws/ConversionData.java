/*
 * Creation : 2 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

/**
 * The Class ConversionData.
 */
public class ConversionData {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Instantiates a new conversion data.
     */
    public ConversionData() {

    }

    /**
     * Instantiates a new conversion data.
     *
     * @param code the code
     * @param value the value
     */
    public ConversionData(String code, String value) {
        super();
        this.code = code;
        this.value = value;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
