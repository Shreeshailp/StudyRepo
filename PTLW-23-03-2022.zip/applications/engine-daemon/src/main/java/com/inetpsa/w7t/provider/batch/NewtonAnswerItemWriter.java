/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.provider.batch;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;
import com.inetpsa.w7t.provider.model.NewtonRequestResponse;

public class NewtonAnswerItemWriter extends JpaItemWriter<NewtonRequestResponse> {

    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void doWrite(EntityManager entityManager, List<? extends NewtonRequestResponse> items) {
        List<NewtonRequestResponse> responseToWrite = ((List<NewtonRequestResponse>) items);
        if (responseToWrite.get(0).getFileId() != null)
            jdbcTemplate.update("update W7TQTRQB set to_machine_name = ? where file_id = ?", DaemonConfig.getBcvResMachine(),
                    responseToWrite.get(0).getFileId());

        super.doWrite(entityManager, responseToWrite);

    }

}