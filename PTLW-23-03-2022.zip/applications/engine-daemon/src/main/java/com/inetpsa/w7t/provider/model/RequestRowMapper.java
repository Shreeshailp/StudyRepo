/*
 * Creation : 3 mai 2017
 */
package com.inetpsa.w7t.provider.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.inetpsa.w7t.domains.engine.model.request.RequestType;

/**
 * The Class RequestRowMapper.
 */
@Entity
@Table(name = "W7TQTREQ")
public class RequestRowMapper {

    /** The request id. */
    @Id
    @Column(name = "REQUEST_ID")
    private String requestId;

    /** The request type. */
    @Enumerated(EnumType.STRING)
    @Column(name = "REQUEST_TYPE")
    private RequestType requestType;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /** The extended title. */
    @Column(name = "EXTENDED_TITLE")
    private String extendedTitle;

    /** The file id. */
    @Column(name = "FILE_ID")
    private String fileId;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /** The extended title. */
    @Column(name = "TVV_DESIGNATION")
    private String tvvDesignation;

    @Column(name = "INTERNAL_FILE_ID")
    private String internalFileId;

    public String getInternalFileId() {
        return internalFileId;
    }

    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public RequestType getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return
     */
    public String getTvvDesignation() {
        return tvvDesignation;
    }

    /**
     * @param tvvDesignation
     */
    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

}
