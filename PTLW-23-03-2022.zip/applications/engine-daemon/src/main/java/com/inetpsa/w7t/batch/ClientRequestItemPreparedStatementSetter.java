package com.inetpsa.w7t.batch;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.inetpsa.w7t.batch.model.ClientRequest;

/**
 * The Class ClientRequestItemPreparedStatementSetter.
 */
public class ClientRequestItemPreparedStatementSetter implements ItemPreparedStatementSetter<ClientRequest> {

    /** The Constant NUM_ONE. */
    public static final int NUM_ONE = 1;

    /** The Constant NUM_TWO. */
    public static final int NUM_TWO = 2;

    /** The Constant NUM_THREE. */
    public static final int NUM_THREE = 3;

    /** The Constant NUM_FOUR. */
    public static final int NUM_FOUR = 4;

    /** The Constant NUM_FIVE. */
    public static final int NUM_FIVE = 5;

    /** The Constant NUM_SIX. */
    public static final int NUM_SIX = 6;

    /** The Constant NUM_SEVEN. */
    public static final int NUM_SEVEN = 7;

    /** The Constant NUM_EIGHT. */
    public static final int NUM_EIGHT = 8;

    /** The Constant NUM_NINE. */
    public static final int NUM_NINE = 9;

    /** The Constant NUM_TEN. */
    public static final int NUM_TEN = 10;

    /** The Constant NUM_ELEVEN. */
    public static final int NUM_ELEVEN = 11;

    /** The Constant NUM_TWELVE. */
    public static final int NUM_TWELVE = 12;

    /** The Constant NUM_THIRTEEN. */
    public static final int NUM_THIRTEEN = 13;

    public static final int NUM_FOURTEEN = 14;

    public static final int NUM_FIFTEEN = 15;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.ItemPreparedStatementSetter#setValues(java.lang.Object, java.sql.PreparedStatement)
     */
    @Override
    public void setValues(ClientRequest corvetReq, PreparedStatement ps) throws SQLException {
        ps.setString(NUM_ONE, UUID.randomUUID().toString());
        ps.setString(NUM_TWO, corvetReq.getRequestNumber());
        ps.setString(NUM_THREE, corvetReq.getRequestType());
        ps.setString(NUM_FOUR, corvetReq.getVin());
        if (corvetReq.getEcomDate() == null) {
            ps.setDate(NUM_FIVE, null);
        } else {
            ps.setDate(NUM_FIVE, Date.valueOf(corvetReq.getEcomDate()));
        }
        ps.setString(NUM_SIX, corvetReq.getExtendedTitle());
        ps.setString(NUM_SEVEN, corvetReq.getFileId());
        if (corvetReq.getStatus() == null) {
            ps.setString(NUM_EIGHT, null);
        } else {
            ps.setString(NUM_EIGHT, String.valueOf(corvetReq.getStatus().getStatusCode()));
        }
        ps.setString(NUM_NINE, corvetReq.getBatchid());
        ps.setTimestamp(NUM_TEN, Timestamp.valueOf(LocalDateTime.now()));
        ps.setString(NUM_ELEVEN, corvetReq.getAnswerCode());
        ps.setString(NUM_TWELVE, corvetReq.getAnswerDesignation());
        // fixed jira-587 starts here
        if (corvetReq.getTvvDesignation() != null && corvetReq.getTvvDesignation().length() > 40) {
            ps.setString(NUM_THIRTEEN, corvetReq.getTvvDesignation().substring(0, 40));
        } else {
            ps.setString(NUM_THIRTEEN, corvetReq.getTvvDesignation());
        } // fixed jira-587 ends here
        ps.setString(NUM_FOURTEEN, corvetReq.getInternalFileId());
        ps.setString(NUM_FIFTEEN, corvetReq.getMaturity());

    }

}