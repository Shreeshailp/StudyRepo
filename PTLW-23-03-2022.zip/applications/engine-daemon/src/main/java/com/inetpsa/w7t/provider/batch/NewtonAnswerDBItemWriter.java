/*
 * Creation : 30 May 2019
 */

package com.inetpsa.w7t.provider.batch;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;
import com.inetpsa.w7t.provider.model.NewtonRequestResponse;

/**
 * The Class NewtonAnswerDBItemWriter.
 *
 * @author E534811
 */
public class NewtonAnswerDBItemWriter extends JpaItemWriter<NewtonRequestResponse> {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(NewtonAnswerDBItemWriter.class);

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The Constant UPDATE_TO_MACHINE. */
    private static final String UPDATE_TO_MACHINE = "UPDATE W7TQTRQB SET BCV_RES_MAC_NAME=? WHERE INTERNAL_FILE_ID=? AND STATUS ='C' ORDER BY CREATED_DATE DESC LIMIT 1";

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends NewtonRequestResponse> items) {
        try {
            // fixed jira-556/526/562
            for (NewtonRequestResponse newtonEntity : items) {
                int result = jdbcTemplate.update(
                        "UPDATE W7TQTNEW set ANSWER_DATE=?, ANSWER_CODE=?, ANSWER_DESIG=?, UNLADEN_MASS=?, EQUIPMENT_MASS=? ,VEHICLE_MASS=?,"
                                + " UNLADEN_SCX=?, EQUIPMENT_SCX=?, VEHICLE_SCX=?, VEHICLE_CRR=?, IS_REQUEST_SENT=? where REQ_ID=? AND STATUS !='80'",
                        newtonEntity.getAnswerDate(), newtonEntity.getAnswerCode(), newtonEntity.getAnswerDesignation(),
                        newtonEntity.getUnladenMass(), newtonEntity.getEquipmentMass(), newtonEntity.getVehicleMass(), newtonEntity.getUnladenSCx(),
                        newtonEntity.getEquipmentSCx(), newtonEntity.getVehicleSCx(), newtonEntity.getVehicleCRR(), newtonEntity.isRequestSent(),
                        newtonEntity.getReqId());
                if (result > 0) {
                    logger.info("[{}] updated successfully", newtonEntity);
                }
                jdbcTemplate.update(
                        "UPDATE W7TQTREQ SET STATUS=?, ANSWER_CODE=?, ANSWER_DESIGNATION=? WHERE REQUEST_ID=? and INTERNAL_FILE_ID=? and STATUS=?",
                        newtonEntity.getStatus(), newtonEntity.getAnswerCode(), newtonEntity.getAnswerDesignation(), newtonEntity.getReqId(),
                        newtonEntity.getFileId(), "30");
                logger.info(
                        "Updated the REQ table with STATUS[{}], ANSWER_CODE[{}], ANSWER_DESIGNATION[{}] for the REQUEST_ID[{}] and INTERNAL_FILE_ID[{}]",
                        newtonEntity.getStatus(), newtonEntity.getAnswerCode(), newtonEntity.getAnswerDesignation(), newtonEntity.getReqId(),
                        newtonEntity.getFileId());

            }
            String fileId = "";
            if (!items.isEmpty())
                fileId = items.get(0).getFileId();
            else {
                logger.error("File id is empty");
            }
            int i = jdbcTemplate.update(UPDATE_TO_MACHINE, new Object[] { DaemonConfig.getBcvResMachine(), fileId });
            if (i > 0) {
                logger.info("The machine name [{}] has been updated successfully for the FileID : [{}]", DaemonConfig.getBcvResMachine(), fileId);
            }
        } catch (Exception e) {
            logger.error("Error while updating bcvResMacName {}", e);
        }
    }

}
