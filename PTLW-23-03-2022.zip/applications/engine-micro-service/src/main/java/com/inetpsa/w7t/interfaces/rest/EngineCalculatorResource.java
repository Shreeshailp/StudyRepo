/*
 * Creation : 28 sept. 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import java.net.UnknownHostException;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.EngineMircoService;
import com.inetpsa.w7t.domain.model.WSAnswer;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCode;
import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;

/**
 * The Class EngineCalculatorResource.
 */
@Path("v1/emissions")
@Api(value = "v1-emissions")
public class EngineCalculatorResource {

    /** The logger. */
    @Logging
    private static Logger logger;

    /** The mirco service. */
    @Inject
    private EngineMircoService mircoService;

    /** The User service. */
    @Inject
    private UserService userService;

    @Configuration("web.server.port")
    private static String port;

    /**
     * Calculate.
     *
     * @param requestObject the request object
     * @return the response
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Finds ", notes = "Multiple status ", response = WSResponseRepresentation.class, responseContainer = "List")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Functional error", responseHeaders = @ResponseHeader(name = "X-Rack-Cache", description = "Explains whether or not a cache was used", response = WSResponseRepresentation.class)),
            @ApiResponse(code = 404, message = "Not found"), @ApiResponse(code = 503, message = "Service not available") })
    public Response calculate(RequestRepresentation requestObject, @Context HttpServletRequest request) {

        String requestId = null;
        WSRequestRepresentation wsRequest = null;
        if (null != requestObject.getRequest() && StringUtils.isNotBlank(requestObject.getRequest().getRequestID())) {
            requestId = requestObject.getRequest().getRequestID();
        } else {
            requestId = UUID.randomUUID().toString();
        }

        Host host = null;
        try {
            // fixed jira-553
            String clientIp = request.getRemoteAddr();
            logger.info("Request ID[{}]: Client IP Address = [{}]", requestId, clientIp);
            host = new Host();
            logger.info("Request ID[{}]: Server HostName = [{}]", requestId, host.getHostname());
            logger.info("Request ID[{}]: Server Port  = [{}]", requestId, port);
            logger.info("Request ID[{}]: Server IP Address = [{}]", requestId, host.getIp());
        } catch (UnknownHostException e) {
            logger.error("Request ID[{}]: Exception : {} ", requestId, e);
            // fix Jira 452
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                    WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
        }

        try {
            wsRequest = requestObject.getRequest();
            String userId = userService.getUserId();
            logger.info("Request ID[{}]: CALCULATION  webservice request = [USER={} {}] : ", requestId, userId, wsRequest);
            Optional<WSResponseRepresentation> responseObject = mircoService.processRequest(wsRequest, requestId);
            logger.info("Request ID[{}]: CALCULATION  webservice response = [USER={} {}] :", requestId, userId, responseObject);
            if (responseObject.isPresent())
                return Response.ok(responseObject.get()).build();
            return Response.status(Response.Status.BAD_REQUEST).build();

        } catch (SeedException | ConstraintViolationException e) {
            return buildErrorResponse(wsRequest, e, requestId);
        } catch (RuntimeException re) {
            logger.error("Request ID[{}]: Unexpected exception : {}", requestId, re);
            // fix Jira 452
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                    WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
            return buildErrorResponse(wsRequest, re, requestId);
        }

    }

    /**
     * Builds the error response.
     *
     * @param wsRequest the ws request
     * @param e the e
     * @param requestId
     * @return the response
     */
    private Response buildErrorResponse(WSRequestRepresentation wsRequest, Exception e, String requestId) {
        WSAnswer answer = new WSAnswer();
        try {
            if (e instanceof WSWltpException) {
                answer.setCode(((WSWltpException) e).getContextErrorCode());
                answer.setDesignation(((WSWltpException) e).getContextMesage());
            } else if (e instanceof ConstraintViolationException) {
                Optional<ConstraintViolation<?>> error = ((ConstraintViolationException) e).getConstraintViolations().stream().findFirst();
                if (error.isPresent()) {
                    String[] errorMsg = error.get().getMessage().split(":");
                    answer.setCode(errorMsg[0]);
                    answer.setDesignation(errorMsg.length > 1 ? errorMsg[1] : "");
                }
            } else if (e instanceof SeedException) {// JIRA-535 Starts Here
                SeedException seedException = (SeedException) e;
                if (seedException.getErrorCode() instanceof WltpErrorCode) {
                    WltpErrorCode ec = (WltpErrorCode) seedException.getErrorCode();
                    if (ec.getStrRuleCode() != null) {
                        answer.setCode(ec.getStrRuleCode());
                    } else {
                        answer.setCode(String.valueOf(ec.getRuleCode()));
                    }
                    answer.setDesignation(ec.getDescription());
                } else if (seedException instanceof WSWltpException) {
                    answer.setCode(((WSWltpException) seedException).getContextErrorCode());
                    answer.setDesignation(((WSWltpException) seedException).getContextMesage());
                } // JIRA-535 Ends Here

            } else {
                answer.setCode(WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode());
                answer.setDesignation(WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
            }
            WSResponseRepresentation responseErrObj = new WSResponseRepresentation();
            responseErrObj.setRequest(wsRequest);
            responseErrObj.setAnswer(answer);
            // JIRA 420 fix
            if (answer.getCode().equalsIgnoreCase("ERRW103")) {
                LogErrorUtility.logTheError(logger, requestId, answer.getCode(), answer.getDesignation());
            }
            logger.info("Request ID[{}]: CALCULATION webservice response = [{}]", requestId, responseErrObj);
            return Response.status(Response.Status.BAD_REQUEST).entity(responseErrObj).build();
        } catch (Exception e1) {
            logger.error("Request ID[{}]: Unexpected exception : {}", requestId, e1);
            // fix Jira 452
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                    WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
            throw new WSWltpException(WSRequestErrorCode.WEB_SERVICE_EXCEPTION);
        }
    }
}
