/*
 * Creation : 10 août 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.seedstack.seed.rest.hal.HalRepresentation;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.w7t.domain.model.ConversionDataObjects;
import com.inetpsa.w7t.domain.validation.WSDateFormat;
import com.inetpsa.w7t.domain.validation.WSEnumCheck;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCodeConstant;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class WSRequestRepresentation.
 */
@ApiModel
public class WSRequestRepresentation extends HalRepresentation implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2543347433982476574L;

    /** The request ID. */
    @ApiModelProperty(example = "GVN04900000000000600", value = "It can be blank. If not empty, consider this requestID during request treatment")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String requestID;

    /** The version16 c. */
    @NotNull(message = WSRequestErrorCodeConstant.VERSION_16C_INCORRECT)
    @Size(min = 16, max = 16, message = WSRequestErrorCodeConstant.VERSION_16C_INCORRECT)
    @ApiModelProperty(example = "1PT9A5LMAKB0A0C2", value = "Mandatory. This is the version 16 characters code from the LCDV")
    private String version16C;

    /** The color ext int. */
    @NotNull(message = WSRequestErrorCodeConstant.COLOR_EXT_INT_INCORRECT)
    @Size(min = 8, max = 8, message = WSRequestErrorCodeConstant.COLOR_EXT_INT_INCORRECT)
    @ApiModelProperty(example = "P0WP67FX", value = "Mandatory. 8 characters for color and interior code")
    private String colorExtInt;

    /** The nb options. */
    @NotNull(message = WSRequestErrorCodeConstant.NB_OPTIONS_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0,2})$)[0-9]*", message = WSRequestErrorCodeConstant.NB_OPTIONS_INCORRECT)
    @ApiModelProperty(example = "02", value = "Optional. Number of option codes if options5C or options7C are non blank. Maximum value for BCV = 40")
    private String nbOptions;

    /** The options5 c. */
    @NotNull(message = WSRequestErrorCodeConstant.OPTIONS_5C_INCORRECT)
    @Pattern(regexp = "(?:.{5})*", message = WSRequestErrorCodeConstant.OPTIONS_5C_INCORRECT)
    @ApiModelProperty(example = "PZH2KPZV47", value = "Optional. Concatenated option codes on 5 characters. No pack code, no local version code. This field will not be read if options7C is not blank. These codes will be transcoded into 7 characters codes by calcuwltp.")
    private String options5C = "";

    /** The options7 c. */
    @NotNull(message = WSRequestErrorCodeConstant.OPTIONS_7C_INCORRECT)
    @Pattern(regexp = "(?:.{7})*", message = WSRequestErrorCodeConstant.OPTIONS_7C_INCORRECT)
    @ApiModelProperty(example = "DZH2KCPDZV47CP", value = "Optional. Concatenated gestion codes on 7 characters. No pack code, no local version code.")
    private String options7C = "";

    /** The nb gestion. */
    @NotNull(message = WSRequestErrorCodeConstant.NB_GESTION_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0,2})$)[0-9]*", message = WSRequestErrorCodeConstant.NB_GESTION_INCORRECT)
    @ApiModelProperty(example = "01", value = "Optional. Number of gestion codes if gestion5C or gestion7C are non blank. Maximum value for BCV = 50")
    private String nbGestion;

    /** The gestion5 c. */
    @NotNull(message = WSRequestErrorCodeConstant.GESTION_5C_INCORRECT)
    @Pattern(regexp = "(?:.{5})*", message = WSRequestErrorCodeConstant.GESTION_5C_INCORRECT)
    @ApiModelProperty(example = "GC100", value = "Optional. Concatenated gestion codes on 5 characters. This field will not be read if gestion7C is not blank. These codes will be transcoded into 7 characters codes by calcuwltp.")
    private String gestion5C = "";

    /** The gestion7 c. */
    @NotNull(message = WSRequestErrorCodeConstant.GESTION_7C_INCORRECT)
    @Pattern(regexp = "(?:.{7})*", message = WSRequestErrorCodeConstant.GESTION_7C_INCORRECT)
    @ApiModelProperty(example = "GC100AA", value = "Optional. Concatenated gestion codes on 7 characters. No pack code, no local version code.")
    private String gestion7C = "";

    /** The extension date. */
    @WSDateFormat(message = WSRequestErrorCodeConstant.EXTENSION_DATE_INCORRECT)
    @ApiModelProperty(example = "2017-12-04", value = "Optional. Date for BCV title extention. To be filled if the title can not be extended at the date of the day. format YYYY-MM-DD")
    private String extensionDate = "";

    /** The mounting center. */
    @NotNull(message = WSRequestErrorCodeConstant.MOUNTING_CENTER_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0}|.{2})$)[0-9A-Z]*", message = WSRequestErrorCodeConstant.MOUNTING_CENTER_INCORRECT)
    @ApiModelProperty(example = "89", value = "Optional. Mounting center for the title extension. If blank BCV will take the first mounting center found.")
    private String mountingCenter = "";

    /** The request type. */
    @NotNull(message = WSRequestErrorCodeConstant.REQUEST_TYPE_INCORRECT)
    @WSEnumCheck(enumClass = RequestType.class, message = WSRequestErrorCodeConstant.REQUEST_TYPE_INCORRECT)
    @ApiModelProperty(example = "FULL", value = "Mandatory. FULL = computation of all cycle phases (low, mid, high, extra-high, combined...). COMB = computation of only combined cycle phase.")
    private String requestType;

    /** The vin. */
    @NotNull(message = WSRequestErrorCodeConstant.VIN_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0}|.{17})$)[0-9a-zA-Z]*", message = WSRequestErrorCodeConstant.VIN_INCORRECT)
    @ApiModelProperty(example = "VF3ABCDE12345678", value = "Optional. vehicle identification number of the individual vehicle. Must be on 17 characters.")
    private String vin = "";

    /** The ecom date. */
    @WSDateFormat(message = WSRequestErrorCodeConstant.ECOM_DATE_INCORRECT)
    @ApiModelProperty(example = "2017-12-04", value = "Optional. ECOM date of the vehicle. If blank calculwltp will compute the emissions for ECOM date = date of the day. format YYYY-MM-DD")
    private String ecomDate = "";

    /** The trading country. */
    @NotNull(message = WSRequestErrorCodeConstant.TRADING_COUNTRY_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0}|.{2})$)[0-9A-Z]*", message = WSRequestErrorCodeConstant.TRADING_COUNTRY_INCORRECT)
    @ApiModelProperty(example = "IT", value = "Optional. Distribution country of the vehicle. Referential data = GA1 GENOME country list. Can remain blank only if the extendedTitleAttributes contains GG8 attribute.")
    private String tradingCountry = "";

    /**
     * The tvv.
     */
    private String tvv = "";

    /** The extended title attributes. */
    @NotNull(message = WSRequestErrorCodeConstant.EXTENDED_TITLE_ATTRIBUTES_INCORRECT)
    @Pattern(regexp = "(?:.{7})*", message = WSRequestErrorCodeConstant.EXTENDED_TITLE_ATTRIBUTES_INCORRECT)
    @ApiModelProperty(example = "DAB00CDDAD01CPDAE20CDDAG81CD...GG819A T8C01G T8D01G T3N14H ...", value = "Optional. To be filled with all the 7 characters attributes concatened if the request is for an extended title. If it is filled it has to contain the GG8, T8C, T8D, and T3N attributes. Otherwise the extended title attributes will be filled in the answer")
    private String extendedTitleAttributes = "";

    /** The conversion data. */
    @ApiModelProperty(value = "Optional. Converted car data")
    private List<ConversionDataObjects> conversionData;

    /** The client name. */
    private String clientName;

    /**
     * Instantiates a new WS request representation.
     */
    public WSRequestRepresentation() { // NOSONAR No validation on empty
                                       // constructor
    }

    /**
     * Instantiates a new WS request representation.
     *
     * @param version16c              the version16c
     * @param colorExtInt             the color ext int
     * @param nbOptions               the nb options
     * @param options5c               the options5c
     * @param options7c               the options7c
     * @param nbGestion               the nb gestion
     * @param gestion5c               the gestion5c
     * @param gestion7c               the gestion7c
     * @param extensionDate           the extension date
     * @param mountingCenter          the mounting center
     * @param requestType             the request type
     * @param vin                     the vin
     * @param ecomDate                the ecom date
     * @param tradingCountry          the trading country
     * @param extendedTitleAttributes the extended title attributes
     */
    @Valid
    public WSRequestRepresentation(String version16c, String colorExtInt, String nbOptions, String options5c, String options7c, String nbGestion,
            String gestion5c, String gestion7c, String extensionDate, String mountingCenter, String requestType, String vin, String ecomDate,
            String tradingCountry, String extendedTitleAttributes) {
        super();
        version16C = version16c;
        this.colorExtInt = colorExtInt;
        this.nbOptions = nbOptions;
        options5C = options5c;
        options7C = options7c;
        this.nbGestion = nbGestion;
        gestion5C = gestion5c;
        gestion7C = gestion7c;
        this.extensionDate = extensionDate;
        this.mountingCenter = mountingCenter;
        this.requestType = requestType;
        this.vin = vin;
        this.ecomDate = ecomDate;
        this.tradingCountry = tradingCountry;
        this.extendedTitleAttributes = extendedTitleAttributes;
    }

    /**
     * Getter requestID.
     *
     * @return the requestID
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Setter requestID.
     *
     * @param requestID the requestID to set
     */
    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    /**
     * Gets the nb gestion.
     *
     * @return the nb gestion
     */
    public String getNbGestion() {
        return nbGestion;
    }

    /**
     * Sets the nb gestion.
     *
     * @param nbGestion the new nb gestion
     */
    public void setNbGestion(String nbGestion) {
        this.nbGestion = nbGestion;
    }

    /**
     * Gets the gestion5 c.
     *
     * @return the gestion5 c
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion5 c.
     *
     * @param gestion5c the new gestion5 c
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion7 c.
     *
     * @return the gestion7 c
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion7 c.
     *
     * @param gestion7c the new gestion7 c
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the version16 c.
     *
     * @return the version16 c
     */
    public String getVersion16C() {
        return version16C;
    }

    /**
     * Sets the version16 c.
     *
     * @param version16c the new version16 c
     */
    public void setVersion16C(String version16c) {
        version16C = version16c;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the nb options.
     *
     * @return the nb options
     */
    public String getNbOptions() {
        return nbOptions;
    }

    /**
     * Sets the nb options.
     *
     * @param nbOptions the new nb options
     */
    public void setNbOptions(String nbOptions) {
        this.nbOptions = nbOptions;
    }

    /**
     * Gets the options5 c.
     *
     * @return the options5 c
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options5 c.
     *
     * @param options5c the new options5 c
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options7 c.
     *
     * @return the options7 c
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options7 c.
     *
     * @param options7c the new options7 c
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the extended title attributes.
     *
     * @return the extended title attributes
     */
    public String getExtendedTitleAttributes() {
        return extendedTitleAttributes;
    }

    /**
     * Sets the extended title attributes.
     *
     * @param extendedTitleAttributes the new extended title attributes
     */
    public void setExtendedTitleAttributes(String extendedTitleAttributes) {
        this.extendedTitleAttributes = extendedTitleAttributes;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WSRequestRepresentation [version16C=" + version16C + ", colorExtInt=" + colorExtInt + ", nbOptions=" + nbOptions + ", options5C="
                + options5C + ", options7C=" + options7C + ", nbGestion=" + nbGestion + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C
                + ", extensionDate=" + extensionDate + ", mountingCenter=" + mountingCenter + ", requestType=" + requestType + ", vin=" + vin
                + ", ecomDate=" + ecomDate + ", tradingCountry=" + tradingCountry + ", tvv=" + tvv + ", extendedTitleAttributes="
                + extendedTitleAttributes + ", conversionData=" + conversionData + "]";
    }

    /**
     * Gets the mounting center.
     *
     * @return the mounting center
     */
    public String getMountingCenter() {
        return mountingCenter;
    }

    /**
     * Sets the mounting center.
     *
     * @param mountingCenter the new mounting center
     */
    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the conversion data.
     *
     * @return the conversion data
     */
    public List<ConversionDataObjects> getConversionData() {
        return conversionData;
    }

    /**
     * Sets the conversion data.
     *
     * @param conversionData the new conversion data
     */
    public void setConversionData(List<ConversionDataObjects> conversionData) {
        this.conversionData = conversionData;
    }

    /**
     * Gets the client name.
     *
     * @return the client name
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the client name.
     *
     * @param clientName the new client name
     */
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

}