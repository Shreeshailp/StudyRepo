/*
 * Creation : 15 sept. 2017
 */
package com.inetpsa.w7t.domain.services.internal;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.lang3.math.NumberUtils;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domain.model.ConversionDataObjects;
import com.inetpsa.w7t.domain.services.EngineMicroValidationPolicy;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCode;
import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.engine.shared.ConversionDataCodes;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ConversionDataTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.SpecialFlagRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Class EngineMicroValidationPolicyImpl.
 */
public class EngineMicroValidationPolicyImpl implements EngineMicroValidationPolicy {

    private static final String CD_ERROR = "Request ID[{}]: Car convertor conversion data value incorrect for code [{}] and value[{}]";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    @Inject
    private VehicleCategoryRepository vehicleCategoryRepository;

    @Inject
    private ConversionDataTypeRepository conversionDataTypeRepository;

    private boolean depolFlag = false;

    /** The special flag repository. */
    @Inject
    private SpecialFlagRepository specialFlagRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domain.services.EngineMicroValidationPolicy#isWSRequestValid(java.lang.String)
     */
    @Override
    public void isWSRequestValid(WSRequestRepresentation requestObject, String requestId) {
        // fixed JIRA 458 starts here
        String extendedAttr = requestObject.getExtendedTitleAttributes();
        String gg8Country = null;
        Country country = null;
        String[] extAttr = extendedAttr.split("\\s+");
        for (String string : extAttr) {
            if (string.contains("GG8")) {
                gg8Country = string.substring(string.indexOf('8') + 1, string.length());
                break;
            }

        }
        if (gg8Country != null && requestObject.getTradingCountry().isEmpty()) {
            country = countryRepository.byCodeAndCharacteristic(gg8Country, "GG8");
        } else if (!requestObject.getTradingCountry().isEmpty()) {
            country = countryRepository.byCodeAndCharacteristic(requestObject.getTradingCountry(), "GA1");
        }
        // fixed JIRA 458 ends here

        Optional<Country> optionalCountry = Optional.ofNullable(country);
        if (requestObject.getTradingCountry().isEmpty() && !optionalCountry.isPresent()) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_TRADE_COUNTRY.getRuleCode(),
                    WSRequestErrorCode.INCORRECT_TRADE_COUNTRY.getDescription());
            throw new WSWltpException(WSRequestErrorCode.INCORRECT_TRADE_COUNTRY);
        }
        try {
            if (requestObject.getConversionData() != null && !requestObject.getConversionData().isEmpty()) {
                boolean crrFlag = false;

                String depolCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.DEPOL.name()).orElse(null);
                if (depolCode == null) {
                    LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_DEPOL.getRuleCode(),
                            WSRequestErrorCode.MISSING_DEPOL.getDescription());
                    throw new WSWltpException(WSRequestErrorCode.MISSING_DEPOL);
                }

                logger.info("Request ID[{}]: Car convertor conversion is data present in request", requestId);
                for (ConversionDataObjects cd : requestObject.getConversionData()) {
                    if (!conversionDataTypeRepository.exists(cd.getCode())) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getRuleCode(),
                                WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.INCORRECT_CONVERSION_DATA);
                    }
                    if (ConversionDataCodes.CRRTR.name().equals(cd.getCode()))
                        crrFlag = true;

                    cd.setValue(cd.getValue().replace(',', '.'));
                    checkRulesForValues(cd, requestId);
                }

                if (depolFlag) {
                    String specialCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.SPECIAL.name()).orElse(null);
                    // String coolSTRCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.COOLSTR.name()).orElse(null);
                    String realCRRCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.RCRRTR.name()).orElse(null);
                    // String strCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.STR.name()).orElse(null);
                    String mrotrCode = getCarConvertorCode(requestObject.getConversionData(), ConversionDataCodes.MROTR.name()).orElse(null);

                    String specialCodeValue = getCarConvertorValue(requestObject.getConversionData(), ConversionDataCodes.SPECIAL.name())
                            .orElse(null);
                    String coolSTRCodeValue = getCarConvertorValue(requestObject.getConversionData(), ConversionDataCodes.COOLSTR.name())
                            .orElse(null);
                    String realCRRCodeValue = getCarConvertorValue(requestObject.getConversionData(), ConversionDataCodes.RCRRTR.name()).orElse(null);
                    String strCodeValue = getCarConvertorValue(requestObject.getConversionData(), ConversionDataCodes.STR.name()).orElse(null);

                    String mrotrCodeValue = getCarConvertorValue(requestObject.getConversionData(), ConversionDataCodes.MROTR.name()).orElse(null);

                    if (specialCode == null) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_SPECIAL.getRuleCode(),
                                WSRequestErrorCode.MISSING_SPECIAL.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_SPECIAL);
                    }
                    if (specialCodeValue == null || specialCodeValue.isEmpty() || !specialFlagRepository.exists(specialCodeValue)) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_SPECIAL.getRuleCode(),
                                WSRequestErrorCode.MISSING_SPECIAL.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_SPECIAL);
                    }

                    if (mrotrCode == null) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getRuleCode(),
                                WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER);
                    }

                    if (mrotrCodeValue == null || mrotrCodeValue.isEmpty()) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getRuleCode(),
                                WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER);
                    }
                    if (!NumberUtils.isParsable(mrotrCodeValue) || Integer.parseInt(mrotrCodeValue) <= 0) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getRuleCode(),
                                WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_MASS_IN_RUNNING_ORDER);
                    }

                    // if (coolSTRCode == null) {
                    // LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_COOL_STR.getRuleCode(),
                    // WSRequestErrorCode.MISSING_COOL_STR.getDescription());
                    // throw new WSWltpException(WSRequestErrorCode.MISSING_COOL_STR);
                    // }

                    // if (coolSTRCodeValue == null || coolSTRCodeValue.isEmpty()) {
                    // LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_COOL_STR.getRuleCode(),
                    // WSRequestErrorCode.INCORRECT_COOL_STR.getDescription());
                    // throw new WSWltpException(WSRequestErrorCode.INCORRECT_COOL_STR);
                    // }

                    if ((coolSTRCodeValue != null && !coolSTRCodeValue.isEmpty())
                            && (!NumberUtils.isParsable(coolSTRCodeValue) || Double.parseDouble(coolSTRCodeValue) <= 0)) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_COOL_STR.getRuleCode(),
                                WSRequestErrorCode.INCORRECT_COOL_STR.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.INCORRECT_COOL_STR);
                    }

                    if (realCRRCode == null) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_REAL_CRR.getRuleCode(),
                                WSRequestErrorCode.MISSING_REAL_CRR.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_REAL_CRR);
                    }

                    if (realCRRCodeValue == null || realCRRCodeValue.isEmpty()) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_REAL_CRR.getRuleCode(),
                                WSRequestErrorCode.MISSING_REAL_CRR.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_REAL_CRR);
                    }
                    if (!NumberUtils.isParsable(realCRRCodeValue) || Double.parseDouble(realCRRCodeValue) <= 0) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_REAL_CRR.getRuleCode(),
                                WSRequestErrorCode.MISSING_REAL_CRR.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.MISSING_REAL_CRR);
                    }

                    // if (strCode == null) {
                    // LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_STR.getRuleCode(),
                    // WSRequestErrorCode.MISSING_STR.getDescription());
                    // throw new WSWltpException(WSRequestErrorCode.MISSING_STR);
                    // }

                    // if (strCodeValue == null) {
                    // LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_STR.getRuleCode(),
                    // WSRequestErrorCode.MISSING_STR.getDescription());
                    // throw new WSWltpException(WSRequestErrorCode.MISSING_STR);
                    // }
                    if ((strCodeValue != null && !strCodeValue.isEmpty())
                            && (!NumberUtils.isParsable(strCodeValue) || Double.parseDouble(strCodeValue) <= 0)) {
                        LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_STR.getRuleCode(),
                                WSRequestErrorCode.INCORRECT_STR.getDescription());
                        throw new WSWltpException(WSRequestErrorCode.INCORRECT_STR);
                    }

                }

                if (!crrFlag) {
                    LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_CRRTR_CC.getRuleCode(),
                            WSRequestErrorCode.MISSING_CRRTR_CC.getDescription());
                    throw new WSWltpException(WSRequestErrorCode.MISSING_CRRTR_CC);
                }
            }
        } catch (WSWltpException wse) {
            WSRequestErrorCode wsError = (WSRequestErrorCode) wse.getErrorCode();
            LogErrorUtility.logTheError(logger, requestId, wsError.getRuleCode(), wsError.getDescription());
            throw wse;
        } catch (Exception e) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getRuleCode(),
                    WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getDescription());
            throw new WSWltpException(WSRequestErrorCode.INCORRECT_CONVERSION_DATA);
        }

    }

    private void checkRulesForValues(ConversionDataObjects cd, String requestId) {
        String dataValue = cd.getValue();
        switch (ConversionDataCodes.valueOf(cd.getCode())) {
        case CATTR:
            if (dataValue.isEmpty() || !vehicleCategoryRepository.exists(dataValue)) {
                logger.error(CD_ERROR, requestId, cd.getCode(), cd.getValue());
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_CATTR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_CATTR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_CATTR_CC);
            }
            break;
        case MTACTR:
            if (!NumberUtils.isParsable(dataValue) || Double.parseDouble(dataValue) <= 0) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MTACTR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_MTACTR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_MTACTR_CC);
            }
            break;
        case MOPTTR:
            if (!NumberUtils.isParsable(dataValue)) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MOPTTR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_MOPTTR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_MOPTTR_CC);
            }
            break;
        case MCOR:
            if (!NumberUtils.isParsable(dataValue) || Double.parseDouble(dataValue) <= 0) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_MCOR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_MCOR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_MCOR_CC);
            }
            break;
        case DMTR:
            if (!NumberUtils.isParsable(dataValue)) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_DMTR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_DMTR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_DMTR_CC);
            }
            break;
        case CRRTR:
            if (!NumberUtils.isParsable(dataValue)) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_CRRTR_CC.getRuleCode(),
                        WSRequestErrorCode.MISSING_CRRTR_CC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_CRRTR_CC);
            }
            break;
        case DEPOL:
            if (dataValue != null) {
                if ("Y".equalsIgnoreCase(dataValue)) {
                    depolFlag = true;
                } else if ("N".equalsIgnoreCase(dataValue)) {
                    depolFlag = false;
                } else {
                    LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_DEPOL.getRuleCode(),
                            WSRequestErrorCode.MISSING_DEPOL.getDescription());
                    throw new WSWltpException(WSRequestErrorCode.MISSING_DEPOL);
                }

            } else {
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MISSING_DEPOL.getRuleCode(),
                        WSRequestErrorCode.MISSING_DEPOL.getDescription());
                throw new WSWltpException(WSRequestErrorCode.MISSING_DEPOL);
            }
            break;
        case SPECIAL:
            doNothingSpecial();
            break;
        case COOLSTR:
            doNothingCoolStr();
            break;
        case RCRRTR:
            doNothingRcrrTr();
            break;
        case STR:
            doNothingStr();
            break;
        case MROTR:
            doNothingMrotr();
            break;
        case CXTR:
            doNothingStr();
            break;

        default:
            // Checking SCX, S, H and L values
            if (dataValue != null && !dataValue.isEmpty() && !NumberUtils.isParsable(dataValue)) {
                logger.error(CD_ERROR, requestId, cd.getCode(), dataValue);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getRuleCode(),
                        WSRequestErrorCode.INCORRECT_CONVERSION_DATA.getDescription());
                throw new WSWltpException(WSRequestErrorCode.INCORRECT_CONVERSION_DATA);
            }
            break;
        }
    }

    private void doNothingMrotr() {
        // Nothing do here

    }

    private void doNothingStr() {
        // Nothing do here

    }

    private void doNothingCoolStr() {
        // Nothing do here

    }

    private void doNothingSpecial() {
        // Nothing do here

    }

    private void doNothingRcrrTr() {
        // Nothing do here

    }

    private Optional<String> getCarConvertorCode(List<ConversionDataObjects> conversionDataObjects, String conversionCode) {
        return conversionDataObjects.stream().filter(cd -> cd.getCode().equals(conversionCode)).findFirst().map(ConversionDataObjects::getCode);
    }

    private Optional<String> getCarConvertorValue(List<ConversionDataObjects> conversionDataObjects, String conversionCode) {
        return conversionDataObjects.stream().filter(cd -> cd.getCode().equals(conversionCode)).findFirst().map(ConversionDataObjects::getValue);
    }

}
