/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.domain.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class WSWltpData.
 */
@ApiModel
public class WSWltpData {

    /** The veh type. */
    @ApiModelProperty(example = "HYRE", value = "Type of vehicle")
    private String vehType;

    /** The category. */
    @ApiModelProperty(example = "M1", value = "Category of vehicle")
    private String category;

    /** The destination. */
    @ApiModelProperty(example = "EURO6.2-MKTG", value = "Destination of vehicle")
    private String destination;

    /**
     * Gets the veh type.
     *
     * @return the veh type
     */
    public String getVehType() {
        return vehType;
    }

    /**
     * Sets the veh type.
     *
     * @param vehType the new veh type
     */
    public void setVehType(String vehType) {
        this.vehType = vehType;
    }

    /**
     * Gets the destination.
     *
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination.
     *
     * @param destination the new destination
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "WSWltpData [vehType=" + vehType + ", category=" + category + ", destination=" + destination + "]";
    }

}
