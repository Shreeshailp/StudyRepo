/*
 * Creation : 2 juin 2016
 */
package com.inetpsa.w7t.interfaces.rest;

/**
 * The Class TitleRepresentation.
 */
public class TitleRepresentation {

    /** The identity. */
    private String identity;

    /** The cm. */
    private String cm;

    /** The version16. */
    private String version16;

    /** The habill. */
    private String habill;

    /** The situ. */
    private String situ;

    /** The nb pers. */
    private String nbPers;

    /** The nb gest. */
    private String nbGest;

    /** The pers. */
    private String pers;

    /** The gest. */
    private String gest;

    /** The date ext. */
    private String dateExt;

    /**
     * Gets the identity.
     *
     * @return the identity
     */
    public String getIdentity() {
        return identity;
    }

    /**
     * Sets the identity.
     *
     * @param identity the new identity
     */
    public void setIdentity(String identity) {
        this.identity = identity;
    }

    /**
     * Gets the cm.
     *
     * @return the cm
     */
    public String getCm() {
        return cm;
    }

    /**
     * Sets the cm.
     *
     * @param cm the new cm
     */
    public void setCm(String cm) {
        this.cm = cm;
    }

    /**
     * Gets the version16.
     *
     * @return the version16
     */
    public String getVersion16() {
        return version16;
    }

    /**
     * Sets the version16.
     *
     * @param version16 the new version16
     */
    public void setVersion16(String version16) {
        this.version16 = version16;
    }

    /**
     * Gets the habill.
     *
     * @return the habill
     */
    public String getHabill() {
        return habill;
    }

    /**
     * Sets the habill.
     *
     * @param habill the new habill
     */
    public void setHabill(String habill) {
        this.habill = habill;
    }

    /**
     * Gets the situ.
     *
     * @return the situ
     */
    public String getSitu() {
        return situ;
    }

    /**
     * Sets the situ.
     *
     * @param situ the new situ
     */
    public void setSitu(String situ) {
        this.situ = situ;
    }

    /**
     * Gets the nb pers.
     *
     * @return the nb pers
     */
    public String getNbPers() {
        return nbPers;
    }

    /**
     * Sets the nb pers.
     *
     * @param nbPers the new nb pers
     */
    public void setNbPers(String nbPers) {
        this.nbPers = nbPers;
    }

    /**
     * Gets the nb gest.
     *
     * @return the nb gest
     */
    public String getNbGest() {
        return nbGest;
    }

    /**
     * Sets the nb gest.
     *
     * @param nbGest the new nb gest
     */
    public void setNbGest(String nbGest) {
        this.nbGest = nbGest;
    }

    /**
     * Gets the pers.
     *
     * @return the pers
     */
    public String getPers() {
        return pers;
    }

    /**
     * Sets the pers.
     *
     * @param pers the new pers
     */
    public void setPers(String pers) {
        this.pers = pers;
    }

    /**
     * Gets the gest.
     *
     * @return the gest
     */
    public String getGest() {
        return gest;
    }

    /**
     * Sets the gest.
     *
     * @param gest the new gest
     */
    public void setGest(String gest) {
        this.gest = gest;
    }

    /**
     * Gets the date ext.
     *
     * @return the date ext
     */
    public String getDateExt() {
        return dateExt;
    }

    /**
     * Sets the date ext.
     *
     * @param extensionDates the new date ext
     */
    public void setDateExt(String extensionDates) {
        this.dateExt = extensionDates;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "TitleRepresentation [identity=" + identity + ", cm=" + cm + ", version16=" + version16 + ", habill=" + habill + ", situ=" + situ
                + ", nbPers=" + nbPers + ", nbGest=" + nbGest + ", pers=" + pers + ", gest=" + gest + ", dateExt=" + dateExt + "]";
    }

}
