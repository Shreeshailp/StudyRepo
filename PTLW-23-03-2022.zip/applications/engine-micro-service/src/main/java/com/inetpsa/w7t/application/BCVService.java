/*
 * Creation : 23 août 2017
 */
package com.inetpsa.w7t.application;

import org.seedstack.business.Service;

import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Interface BCVService.
 */
@Service
public interface BCVService {

    /**
     * Gets the complete extended title.
     *
     * @param wsRequestObject the ws request object
     * @param requestId the request id
     * @return the complete extended title
     */
    String getCompleteExtendedTitle(WSRequestRepresentation wsRequestObject, String requestId);

    /**
     * Gets the 7c value.
     *
     * @param value5c the value5c
     * @param value7c the value7c
     * @param requestId the request id
     * @return the 7c value
     */
    String get7cValue(String value5c, String value7c, String requestId);
}
