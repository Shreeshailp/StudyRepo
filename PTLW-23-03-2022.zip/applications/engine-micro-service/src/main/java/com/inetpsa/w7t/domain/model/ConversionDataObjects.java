/*
 * Creation : 24 oct. 2017
 */
package com.inetpsa.w7t.domain.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class ConversionDataObjects.
 */
@ApiModel
public class ConversionDataObjects {

    /** The code. */
    @ApiModelProperty(example = "MTACTR, MOPTTR, MCOR, DMTR, CATTR, SCXTR, STR, CRRTR, HTR, LTR, DEPOL, SPECIAL, RCRRTR, COOLSTR, MROTR", value = "MTACTR - (Mandatory) Converted vehicle gross mass, MOPTTR - (Mandatory) Conversion full option mass added, MCOR - (Mandatory) corvet mass, including passenger mass, DMTR - (Mandatory) conversion mass added, CATTR - (Mandatory) category of converted vehicle, SCXTR - (Optional) SCx of converted vehicle, STR - (Optional) Frontal area of converted vehicle, CRRTR - (Mandatory) CRR of converted vehicle, HTR - (Optional) Heigth of converted vehicle, LTR - (Optional) Length of converted vehicle, DEPOL - (Mandatory) DEPOL flag of converted car, SPECIAL - (Mandatory)  SPECIAL flag of converted car, RCRRTR - (Mandatory) Real CRR value of converted car, COOLSTR - (Optional) Cooling surface of converted car, MROTR - (Mandatory) mass in running order for converted car")
    private String code;

    /** The value. */
    @ApiModelProperty(example = "MTACTR - (Mandatory) 1800, MOPTTR - (Mandatory) 40, MCOR - (Mandatory) 1551, DMTR - (Mandatory) 55, CATTR - (Mandatory) N1, SCXTR - (Optional) 0.975, STR - (Optional) 2.32, CRRTR - (Mandatory) 7.4, HTR - (Optional) 2.35, LTR - (Optional) 1.95, DEPOL - (Mandatory) Y, SPECIAL - (Mandatory) N, RCRRTR - (Mandatory) 7.5, COOLSTR - (Optional) 1.95, MROTR - (Mandatory) 2008")
    private String value;

    /**
     * Instantiates a new conversion data objects.
     */
    public ConversionDataObjects() {
        // Default constructor for Jackson
    }

    /**
     * Instantiates a new conversion data objects.
     *
     * @param code the code
     * @param value the value
     */
    public ConversionDataObjects(String code, String value) {
        super();
        this.code = code;
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ConversionDataObjects [code=" + code + ", value=" + value + "]";
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
