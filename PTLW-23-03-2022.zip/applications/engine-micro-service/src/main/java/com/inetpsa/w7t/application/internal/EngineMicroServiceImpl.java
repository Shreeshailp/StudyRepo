/*
 * Creation : 24 août 2017
 */
package com.inetpsa.w7t.application.internal;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;
import javax.validation.Valid;

import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.BCVService;
import com.inetpsa.w7t.application.EngineMircoService;
import com.inetpsa.w7t.application.NewtonService;
import com.inetpsa.w7t.domain.model.ResultDto;
import com.inetpsa.w7t.domain.model.WSAnswer;
import com.inetpsa.w7t.domain.model.WSPhase;
import com.inetpsa.w7t.domain.model.WSPhase.Result;
import com.inetpsa.w7t.domain.model.WSPhysicalResult;
import com.inetpsa.w7t.domain.model.WSWltpData;
import com.inetpsa.w7t.domain.services.EngineMicroValidationPolicy;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCode;
import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase.CalculatedMeasure;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.ConversionData;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.shared.ConversionDataCodes;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.references.cache.WltpCacheManager;
import com.inetpsa.w7t.domains.references.common.EmissionConstants;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;
import com.inetpsa.w7t.interfaces.rest.WSResponseRepresentation;

/**
 * The Class EngineMicroServiceImpl.
 */
public class EngineMicroServiceImpl implements EngineMircoService {

    /** The validator policy. */
    @Inject
    private EngineMicroValidationPolicy validatorPolicy;

    /** The bcv service. */
    @Inject
    private BCVService bcvService;

    /** The newton service. */
    @Inject
    private NewtonService newtonService;

    /** The engine calculator service. */
    @Inject

    private EngineCalculatorService engineCalculatorService;
    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /** The physical quantity type repository. */
    @Inject
    PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The Constant CLIENT. */
    private static final String CLIENT = "WS";

    /** The Constant LOW. */
    public static final String LOW = "LOW";

    /** The Constant MID. */
    public static final String MID = "MID";

    /** The Constant HIGH. */
    public static final String HIGH = "HIGH";

    /** The Constant EHIGH. */
    public static final String EHIGH = "EHIGH";

    /** The Constant COMB. */
    public static final String COMB = "COMB";

    /** The Constant CITY. */
    private static final String CITY = "CITY";

    /** The is code S present. */
    private boolean isCodeSPresent = false;

    /** The is code H present. */
    private boolean isCodeHPresent = false;

    /** The is code L present. */
    private boolean isCodeLPresent = false;

    /** The gross vehicle mass repository. */
    @Inject
    private GrossVehicleMassRepository grossVehicleMassRepository;

    /** The calculation factory. */
    @Inject
    private CalculationFactory calculationFactory;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.EngineMircoService#processRequest(com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation)
     */
    @Override
    public Optional<WSResponseRepresentation> processRequest(@Valid WSRequestRepresentation requestObject, String requestId) {
        String statusMatched = "";
        try {
            statusMatched = MaturityCheckUtility.maturityCheckForWebService(requestObject.getRequestType(), requestObject.getVersion16C(), requestId,
                    CLIENT, logger, maturityRepository, clientMaturityRepository);
            logger.info("RequestID : [{}] Maturity : {}", requestId, statusMatched);
        } catch (SeedException e) {

            WSRequestErrorCode wsec = WSRequestErrorCode.CALCULATOR_EXCEPTION;
            if (e.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) e.getErrorCode();
                wsec.setRuleCode(ERRW + ec.getRuleCode());
                wsec.setDescription(ec.getDescription());
            } else if (e.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) e.getErrorCode();
                wsec.setRuleCode(ERRW + ec.getRuleCode());
                wsec.setDescription(ec.getDescription());
            }
            throw new WSWltpException(wsec);
        }
        // Maturity check step 3.12a for CAP-15815 ends here
        validatorPolicy.isWSRequestValid(requestObject, requestId);
        logger.info("Request ID[{}]: CALCUL webservice request valid", requestId);

        if (requestObject.getEcomDate() == null || requestObject.getEcomDate().isEmpty())
            requestObject.setEcomDate(LocalDate.now().toString());

        if (requestObject.getNbOptions().isEmpty())
            requestObject.setNbOptions("00");
        if (requestObject.getNbGestion().isEmpty())
            requestObject.setNbGestion("00");

        if (requestObject.getExtendedTitleAttributes().isEmpty()) {
            logger.info("Request ID[{}]: Extended Title Attributes Missing, Calling BCV webservice", requestId);
            String extendedAttr = bcvService.getCompleteExtendedTitle(requestObject, requestId);
            requestObject.setExtendedTitleAttributes(extendedAttr);
        }
        List<ConversionData> conversionData = new ArrayList<>();
        if (requestObject.getConversionData() != null) {
            requestObject.getConversionData().forEach(obj -> {
                ConversionData e = new ConversionData(obj.getCode(), obj.getValue());
                // lot-23 depol changes
                if (e.getCode().equals(CalculationConstants.CXTR_CODE) && (e.getValue() == null || e.getValue().isEmpty())) {
                    e.setValue(String.valueOf(0));
                }
                conversionData.add(e);
            });
        }
        List<EnginePhysicalQuantity> physicalData = new ArrayList<>();
        if (conversionData.isEmpty())
            physicalData = newtonService.getNewtonPhysicalData(requestObject, requestId);

        // CAP-26709-Mass Control-Newton and Homologated masses consistency-Starts Here
        if ("TEST".equalsIgnoreCase(requestObject.getRequestType())
                && ("USM".equalsIgnoreCase(requestObject.getClientName()) || "XMLSM".equalsIgnoreCase(requestObject.getClientName()))) {
            logger.info("REQUEST_ID[{}] : REQUEST TYPE[{}] : CLIENT[{}]", requestId, requestObject.getRequestType(), requestObject.getClientName());
            Calculation calculation = null;
            String extendedTitle = requestObject.getVersion16C() + requestObject.getColorExtInt() + requestObject.getExtendedTitleAttributes();
            LocalDate ecomDate;
            if (requestObject.getEcomDate() == null || requestObject.getEcomDate().isEmpty())
                ecomDate = LocalDate.parse(requestObject.getExtensionDate());
            else
                ecomDate = LocalDate.parse(requestObject.getEcomDate());
            Version version = new Version(ecomDate, extendedTitle, RequestType.valueOf(requestObject.getRequestType()), "GG8", requestObject.getTvv(),
                    conversionData);
            calculation = calculationFactory.withVersion(version);
            try {
                newtonMassControl(calculation, physicalData, requestId, version);
            } catch (SeedException e) {
                WSRequestErrorCode wsec = WSRequestErrorCode.CALCULATOR_EXCEPTION;
                if (e.getErrorCode() instanceof WltpErrorCode) {
                    WltpErrorCode ec = (WltpErrorCode) e.getErrorCode();
                    wsec.setRuleCode(ERRW + ec.getRuleCode());
                    wsec.setDescription(ec.getDescription());
                    if ("671".equalsIgnoreCase(String.valueOf(ec.getRuleCode())) || "672".equalsIgnoreCase(String.valueOf(ec.getRuleCode()))) {
                        return Optional
                                .ofNullable(buildErrorAnswerObject(requestObject, calculation, ec.getRuleCode(), ec.getDescription(), physicalData));

                    }
                }
                LogErrorUtility.logTheError(logger, requestId, wsec.getRuleCode(), wsec.getDescription());
                throw new WSWltpException(wsec);
            }

        }
        // CAP-26709-Mass Control-Newton and Homologated masses consistency-Ends Here

        Calculation calculationResults = calculateResults(requestObject, physicalData, conversionData, requestId);

        return Optional.ofNullable(buildAnswerObject(requestObject, calculationResults, requestId, statusMatched));
    }

    /**
     * Calculate results.
     *
     * @param wsRequestObject the ws request object
     * @param physicalData    the physical data
     * @param conversionData  the conversion data
     * @param requestId       the request id
     * @return the calculation
     */
    private Calculation calculateResults(WSRequestRepresentation wsRequestObject, List<EnginePhysicalQuantity> physicalData,
            List<ConversionData> conversionData, String requestId) {

        Calculation calculation;
        String extendedTitle = wsRequestObject.getVersion16C() + wsRequestObject.getColorExtInt() + wsRequestObject.getExtendedTitleAttributes();
        LocalDate ecomDate;
        if (wsRequestObject.getEcomDate() == null || wsRequestObject.getEcomDate().isEmpty())
            ecomDate = LocalDate.parse(wsRequestObject.getExtensionDate());
        else
            ecomDate = LocalDate.parse(wsRequestObject.getEcomDate());
        Version version = new Version(ecomDate, extendedTitle, RequestType.valueOf(wsRequestObject.getRequestType()), "GG8", wsRequestObject.getTvv(),
                conversionData);
        if (physicalData.isEmpty() && conversionData != null && !conversionData.isEmpty()) {
            Optional<String> crrTR = getCarConvertorValue(conversionData, ConversionDataCodes.CRRTR.name());
            if (crrTR.isPresent())
                physicalData.add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, Double.parseDouble(crrTR.get())));
            // lot-23 cap-23272 depol changes
            Optional<String> cxTR = getCarConvertorValue(conversionData, ConversionDataCodes.CXTR.name());
            if (cxTR.isPresent())
                physicalData.add(new EnginePhysicalQuantity(CalculationConstants.CXTR_CODE, Double.parseDouble(cxTR.get())));
        }

        String tradingCountry = wsRequestObject.getTradingCountry();
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:GG8(?<country>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (!m.matches()) {
            if (tradingCountry != null && !tradingCountry.isEmpty()) {
                version.setTradingCountry(tradingCountry);
                version.setCharacteristic("GA1");
            } else {
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.PROGR_COUNTRY_MISSING.getRuleCode(),
                        WSRequestErrorCode.PROGR_COUNTRY_MISSING.getDescription());
                throw new WSWltpException(WSRequestErrorCode.PROGR_COUNTRY_MISSING);
            }
        }

        try {
            calculation = engineCalculatorService.calculate(version, physicalData, requestId);
        } catch (SeedException e) {
            WSRequestErrorCode wsec = WSRequestErrorCode.CALCULATOR_EXCEPTION;
            if (e.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) e.getErrorCode();
                wsec.setRuleCode(ERRW + ec.getRuleCode());
                wsec.setDescription(ec.getDescription());
            } else if (e.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) e.getErrorCode();
                wsec.setRuleCode(ERRW + ec.getRuleCode());
                wsec.setDescription(ec.getDescription());
            } else if (e.getErrorCode() instanceof RequestErrorCode) {
                RequestErrorCode ec = (RequestErrorCode) e.getErrorCode();
                wsec.setRuleCode(ec.getRuleCode());
                wsec.setDescription(ec.getDescription());
            }
            // fix 420
            LogErrorUtility.logTheError(logger, requestId, wsec.getRuleCode(), wsec.getDescription());
            throw new WSWltpException(wsec);
        } catch (RuntimeException e) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                    WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
            throw new WSWltpException(WSRequestErrorCode.WEB_SERVICE_EXCEPTION);
        }

        return calculation;
    }

    /**
     * Builds the error answer object.
     *
     * @param wsRequestObject the ws request object
     * @param calculation     the calculation
     * @param errorCode       the error code
     * @param description     the description
     * @param physicalData    the physical data
     * @return the WS response representation
     */
    // CAP-26709-Mass Control-Newton and Homologated masses consistency- Below method is added as part of LOT24 changes
    private WSResponseRepresentation buildErrorAnswerObject(WSRequestRepresentation wsRequestObject, Calculation calculation, int errorCode,
            String description, List<EnginePhysicalQuantity> physicalData) {

        WSResponseRepresentation responseObject = new WSResponseRepresentation();
        responseObject.setRequest(wsRequestObject);
        responseObject.setAnswer(new WSAnswer("ERRW" + errorCode, description));
        if (physicalData != null && !physicalData.isEmpty()) {
            double emasse = 0;
            double umasse = 0;
            for (EnginePhysicalQuantity phyQty : physicalData) {

                if (phyQty.getCode().equalsIgnoreCase(CalculationConstants.EMASS_CODE)) {
                    emasse = phyQty.getValue();
                } else if (phyQty.getCode().equalsIgnoreCase(CalculationConstants.UMASS_CODE)) {
                    umasse = phyQty.getValue();
                }
            }
            List<WSPhysicalResult> wsPhyResults = new ArrayList<>();

            WSPhysicalResult emassResult = new WSPhysicalResult();
            emassResult.setCode(CalculationConstants.EMASS_CODE);
            emassResult.setValue(getPhyResultInFormat(CalculationConstants.EMASS_CODE, emasse));
            wsPhyResults.add(emassResult);

            WSPhysicalResult umassResult = new WSPhysicalResult();
            umassResult.setCode(CalculationConstants.UMASS_CODE);
            umassResult.setValue(getPhyResultInFormat(CalculationConstants.UMASS_CODE, umasse));
            wsPhyResults.add(umassResult);

            WSPhysicalResult mtac = new WSPhysicalResult();
            mtac.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MTAC));
            mtac.setValue(calculation.getmTac());
            wsPhyResults.add(mtac);

            WSPhysicalResult mOPT = new WSPhysicalResult();
            mOPT.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MOPT));
            mOPT.setValue(calculation.getmOPT());
            wsPhyResults.add(mOPT);

            WSPhysicalResult emptyMass = new WSPhysicalResult();
            emptyMass.setCode(getPhysicalQuantityTypeCode(CalculationConstants.EMPTYM));
            emptyMass.setValue(calculation.getEmptyMass());
            wsPhyResults.add(emptyMass);
            responseObject.setPhysResult(wsPhyResults);
        }

        return responseObject;

    }

    /**
     * Newton mass control.
     *
     * @param calculation  the calculation
     * @param physicalData the physical data
     * @param requestId    the request id
     * @param version      the version
     */
    // CAP-26709-Mass Control-Newton and Homologated masses consistency- Below method is added as part of LOT24 changes
    private void newtonMassControl(Calculation calculation, List<EnginePhysicalQuantity> physicalData, String requestId, Version version) {
        logger.info("REQUEST_ID[{}] : Inside newtonMassControl()", requestId);
        if (physicalData != null && !physicalData.isEmpty()) {
            double emasse = 0;
            double umasse = 0;
            for (EnginePhysicalQuantity phyQty : physicalData) {

                if (phyQty.getCode().equalsIgnoreCase(CalculationConstants.EMASS_CODE)) {
                    emasse = phyQty.getValue();
                } else if (phyQty.getCode().equalsIgnoreCase(CalculationConstants.UMASS_CODE)) {
                    umasse = phyQty.getValue();
                }
            }

            String vehicleFamily = version.getVehicleFamily(requestId);
            String emptyMassCode = version.getEmptyMass(requestId);
            String fullMassCode = version.getFullOptionsMass(requestId);

            String t3sValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, fullMassCode, "T3S")
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_FOM_FOUND)).getValue();

            String t3mValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, emptyMassCode, "T3M")
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_EM_FOUND)).getValue();

            GrossVehicleMass t3n = grossVehicleMassRepository
                    .byFamilyCodeAndCharacteristic(calculation.getVersion().getVehicleFamily(requestId),
                            calculation.getVersion().getGrossVehicleMass(requestId), "T3N")
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_GVM_FOUND));

            if (org.apache.commons.lang.math.NumberUtils.isNumber(t3n.getValue()) && Double.parseDouble(t3n.getValue()) >= 0) {
                calculation.setmTac(t3n.getValue());
            }

            if (org.apache.commons.lang.math.NumberUtils.isNumber(t3sValue) && Double.parseDouble(t3sValue) >= 0) {
                calculation.setmOPT(String.valueOf(Integer.parseInt(t3sValue)));
            } else {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getRuleCode(),
                        WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getDescription());
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_FOM_FOUND);
            }

            if (org.apache.commons.lang.math.NumberUtils.isNumber(t3mValue) && Double.parseDouble(t3mValue) > 0) {
                calculation.setEmptyMass(String.valueOf(Integer.parseInt(t3mValue)));
            } else {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_EM_FOUND.getRuleCode(),
                        WltpEngineCalculatorErrorCode.NO_EM_FOUND.getDescription());
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_EM_FOUND);
            }
            int t3m = Integer.parseInt(calculation.getEmptyMass());
            int t3s = Integer.parseInt(calculation.getmOPT());
            int emptym = t3m;
            int mopt = t3s;
            if ((emasse + umasse) >= t3m) {
                double diffValue = BigDecimal.valueOf(emasse + umasse - emptym).setScale(2, RoundingMode.HALF_UP).doubleValue();
                logger.info("REQUEST_ID[{}] - EMASSE[{}], UMASSE[{}], EMPTYM[{}], DIFF_VALUE[{}]", requestId, emasse, umasse, emptym, diffValue);
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.NEWTON_MASS_LOW.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.NEWTON_MASS_LOW.getDescription() + "(" + diffValue + ")");
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            } else if ((emasse + umasse) <= t3m + t3s) {
                double diffValue = BigDecimal.valueOf(emasse + umasse - emptym - mopt).setScale(2, RoundingMode.HALF_UP).doubleValue();
                logger.info("REQUEST_ID[{}] - EMASSE[{}], UMASSE[{}], EMPTYM[{}], MOPT[{}], DIFF_VALUE[{}]", requestId, emasse, umasse, emptym, mopt,
                        diffValue);
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.NEWTON_MASS_HIGH.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.NEWTON_MASS_HIGH.getDescription() + "(" + diffValue + ")");
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            }
        }
    }

    /**
     * Log and create exception.
     *
     * @param requestId the request id
     * @param errorCode the error code
     * @return the seed exception
     */
    private SeedException logAndCreateException(String requestId, WltpEngineCalculatorErrorCode errorCode) {
        LogErrorUtility.logTheError(logger, requestId, ERRW + errorCode.getRuleCode(), errorCode.getDescription());
        return SeedException.createNew(errorCode);
    }

    /**
     * Builds the answer object.
     *
     * @param wsRequestObject    the ws request object
     * @param calculationResults the calculation results
     * @param requestId          the request id
     * @param statusMatched      the status matched
     * @return the WS response representation
     */
    private WSResponseRepresentation buildAnswerObject(WSRequestRepresentation wsRequestObject, Calculation calculationResults, String requestId,
            String statusMatched) {

        WSResponseRepresentation responseObject = new WSResponseRepresentation();

        wsRequestObject.setTvv(calculationResults.getTvvDetails().getTvvDesignation());

        responseObject.setRequest(wsRequestObject);
        responseObject.setAnswer(new WSAnswer("OKW00001", "Calculation successful"));

        String code = calculationResults.getVersion().getFamily(requestId);
        Integer index = Integer.valueOf(calculationResults.getVersion().getIndex(requestId));
        Optional<Family> fam = familyRepository.byCodeAndIndex(code, index);
        if (fam.isPresent()) {
            WSWltpData wData = new WSWltpData();
            wData.setDestination(calculationResults.getReferences().getDestination().getLabel());
            wData.setVehType(fam.get().getType());
            wData.setCategory(calculationResults.getTvvDetails().getTvvVehicleCategory());
            responseObject.setWltpData(wData);
        }
        List<WSPhysicalResult> wsPhyResults = new ArrayList<>();
        List<EnginePhysicalQuantity> engineQuantities = new ArrayList<>();
        calculationResults.getCalculatedData().getRoadLoad().ifPresent(engineQuantities::addAll);
        engineQuantities.stream().forEach(eq -> {
            WSPhysicalResult phyResult = new WSPhysicalResult();
            phyResult.setCode(eq.getCode());
            phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
            wsPhyResults.add(phyResult);
        });
        List<EnginePhysicalQuantity> enginePhysicalQuantities = calculationResults.getPhysicalQuantities();

        enginePhysicalQuantities.stream().forEach(eq -> {
            WSPhysicalResult phyResult = new WSPhysicalResult();
            if (CalculationConstants.MASS_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                eq.setValue(eq.getValue() + 75.0);
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }

        });

        calculationResults.getCalculatedData().getTestMass().map(tm -> {
            WSPhysicalResult pr = new WSPhysicalResult();
            pr.setCode(getPhysicalQuantityTypeCode(CalculationConstants.TMASS_CODE));
            pr.setValue(tm.toString());
            return pr;
        }).ifPresent(wsPhyResults::add);

        enginePhysicalQuantities.stream().forEach(eq -> {
            WSPhysicalResult phyResult = new WSPhysicalResult();
            if (CalculationConstants.EMASS_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                eq.setValue(eq.getValue());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }

        });
        enginePhysicalQuantities.stream().forEach(eq -> {
            WSPhysicalResult phyResult = new WSPhysicalResult();
            if (CalculationConstants.UMASS_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                eq.setValue(eq.getValue());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }

        });

        enginePhysicalQuantities.stream().forEach(eq -> {
            if (CalculationConstants.SCX_CODE.equals(eq.getCode())) {
                WSPhysicalResult phyResult = new WSPhysicalResult();
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }
        });

        enginePhysicalQuantities.stream().forEach(eq -> {
            if (CalculationConstants.ESCX_CODE.equals(eq.getCode())) {
                WSPhysicalResult phyResult = new WSPhysicalResult();
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }
        });

        enginePhysicalQuantities.stream().forEach(eq -> {
            if (CalculationConstants.USCX_CODE.equals(eq.getCode())) {
                WSPhysicalResult phyResult = new WSPhysicalResult();
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }
        });

        enginePhysicalQuantities.stream().forEach(eq -> {
            if (CalculationConstants.CRR_CODE.equals(eq.getCode())) {
                WSPhysicalResult phyResult = new WSPhysicalResult();
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }

        });
        // lot23 depol change
        enginePhysicalQuantities.stream().forEach(eq -> {
            if (CalculationConstants.CXTR_CODE.equals(eq.getCode())) {
                WSPhysicalResult phyResult = new WSPhysicalResult();
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
            }

        });
        // The below lines has been commented as part of JIRA-603 Fix
        // calculationResults.getCalculatedData().getCrrEfficiency().map(ee -> {
        // WSPhysicalResult pr = new WSPhysicalResult();
        // pr.setCode(getPhysicalQuantityTypeCode(CalculationConstants.CRREC_CODE));
        // pr.setValue(ee);
        // return pr;
        // }).ifPresent(wsPhyResults::add);

        // JIRA-CALCULWLTP-480 Fix Starts here
        enginePhysicalQuantities.stream().forEach(eq -> {
            WSPhysicalResult phyResult = new WSPhysicalResult();
            if (CalculationConstants.S.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
                isCodeSPresent = true;
            }
            if (CalculationConstants.H.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
                isCodeHPresent = true;
            }
            if (CalculationConstants.L.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wsPhyResults.add(phyResult);
                isCodeLPresent = true;
            }

        });

        // JIRA-CALCULWLTP-480 Fix Ends here

        if (!isCodeSPresent && calculationResults.getTvvDetails().getTvvAf() != null) {
            String sValue = String.valueOf(calculationResults.getTvvDetails().getTvvAf());
            WSPhysicalResult ps = new WSPhysicalResult();
            ps.setCode(getPhysicalQuantityTypeCode(CalculationConstants.S));
            ps.setValue(sValue);
            wsPhyResults.add(ps);
        }
        if (!isCodeHPresent && calculationResults.getTvvDetails().getTvvHeigth() != null) {
            String hValue = String.valueOf(calculationResults.getTvvDetails().getTvvHeigth());
            WSPhysicalResult ph = new WSPhysicalResult();
            ph.setCode(getPhysicalQuantityTypeCode(CalculationConstants.H));
            ph.setValue(hValue);
            wsPhyResults.add(ph);
        }

        if (!isCodeLPresent && calculationResults.getTvvDetails().getTvvWidth() != null) {
            String lValue = String.valueOf(calculationResults.getTvvDetails().getTvvWidth());
            WSPhysicalResult pl = new WSPhysicalResult();
            pl.setCode(getPhysicalQuantityTypeCode(CalculationConstants.L));
            pl.setValue(lValue);
            wsPhyResults.add(pl);
        }

        if (fam.isPresent()) {
            WSPhysicalResult pr = new WSPhysicalResult();
            pr.setCode(getPhysicalQuantityTypeCode(CalculationConstants.ROADLOAD_TYPE));
            pr.setValue(fam.get().getRoadLoad());
            wsPhyResults.add(pr);
        }

        if (calculationResults.getTvvDetails().getTvvCompleteFlag() != null) {
            String complFlag = calculationResults.getTvvDetails().getTvvCompleteFlag();
            WSPhysicalResult cfl = new WSPhysicalResult();
            cfl.setCode(getPhysicalQuantityTypeCode(CalculationConstants.COMPL));
            cfl.setValue(complFlag);
            wsPhyResults.add(cfl);
        }

        WSPhysicalResult mtac = new WSPhysicalResult();
        mtac.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MTAC));
        mtac.setValue(calculationResults.getmTac());
        wsPhyResults.add(mtac);

        WSPhysicalResult mOPT = new WSPhysicalResult();
        mOPT.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MOPT));
        mOPT.setValue(calculationResults.getmOPT());
        wsPhyResults.add(mOPT);

        WSPhysicalResult emptyMass = new WSPhysicalResult();
        emptyMass.setCode(getPhysicalQuantityTypeCode(CalculationConstants.EMPTYM));
        emptyMass.setValue(calculationResults.getEmptyMass());
        wsPhyResults.add(emptyMass);

        if (!calculationResults.getCalculatedData().getSpeedLimitFlag().isEmpty()) {
            String speedLimitFlag = calculationResults.getCalculatedData().getSpeedLimitFlag();
            WSPhysicalResult speedLimit = new WSPhysicalResult();
            speedLimit.setCode(getPhysicalQuantityTypeCode(CalculationConstants.SPEEDLIMIT));
            speedLimit.setValue(speedLimitFlag);
            wsPhyResults.add(speedLimit);
        }

        if (calculationResults.getCalculatedData().getfDownScale() != null) {
            String fDownscale = String.valueOf(calculationResults.getCalculatedData().getfDownScale());
            WSPhysicalResult fdsc = new WSPhysicalResult();
            fdsc.setCode(getPhysicalQuantityTypeCode(CalculationConstants.FDSC));
            fdsc.setValue(fDownscale);
            wsPhyResults.add(fdsc);
        }

        if (!calculationResults.getCalculatedData().getvMax().isEmpty()) {
            String vMaxValue = calculationResults.getCalculatedData().getvMax();
            WSPhysicalResult vmax = new WSPhysicalResult();
            vmax.setCode(getPhysicalQuantityTypeCode(CalculationConstants.VMAX));
            vmax.setValue(vMaxValue);
            wsPhyResults.add(vmax);
        }

        if ("Y".equalsIgnoreCase(calculationResults.getDepol()) && calculationResults.getTvvDetails().getTvvCodeDepol() != null) {
            String depolValue = calculationResults.getTvvDetails().getTvvCodeDepol();
            WSPhysicalResult ph = new WSPhysicalResult();
            ph.setCode(getPhysicalQuantityTypeCode(CalculationConstants.CODE_DEPOL));
            ph.setValue(depolValue);
            wsPhyResults.add(ph);
        }
        WSPhysicalResult maturity = new WSPhysicalResult();
        maturity.setCode(getPhysicalQuantityTypeCode(CalculationConstants.MATURITY));
        maturity.setValue(statusMatched);
        wsPhyResults.add(maturity);
        responseObject.setPhysResult(wsPhyResults);

        List<WSPhase> phList = new ArrayList<>();
        Optional<List<CalculatedPhase>> results = calculationResults.getCalculatedData().getCalculatedPhases();
        if (results.isPresent()) {
            List<CalculatedPhase> calculatedPhases = results.get();
            calculatedPhases.forEach(calculatedPhase -> {
                WSPhase ph = new WSPhase();
                ph.setCode(calculatedPhase.getPhaseCode());

                Set<ResultDto> emissionSet = new TreeSet<>();
                calculatedPhase.getEmissions().forEach(emission -> {
                    getSortedEmissions(emission, emissionSet);
                });
                List<ResultDto> resultList = new ArrayList<>(emissionSet);
                List<Result> newResultList = new ArrayList<>();
                resultList.stream().forEach(r -> {
                    Result res = ph.new Result(r.getCode(), r.getValue());
                    newResultList.add(res);
                });
                ph.setResult(newResultList);
                phList.add(ph);
            });
            List<WSPhase> sortedPhList = new ArrayList<>(6);
            sortedPhList.addAll(phList);
            if (!phList.isEmpty() && phList.size() == 1) {
                sortedPhList.set(0, phList.get(0));
            } else if (!phList.isEmpty() && phList.size() <= 2) {
                for (WSPhase phases : phList) {
                    if (phases.getCode().equalsIgnoreCase(CITY)) {
                        sortedPhList.set(0, phases);
                    } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                        sortedPhList.set(1, phases);
                    }
                }
            } else if (!phList.isEmpty() && phList.size() <= 5) {
                for (WSPhase phases : phList) {
                    if (phases.getCode().equalsIgnoreCase(LOW)) {
                        sortedPhList.set(0, phases);
                    } else if (phases.getCode().equalsIgnoreCase(MID)) {
                        sortedPhList.set(1, phases);
                    } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                        sortedPhList.set(2, phases);
                    } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                        sortedPhList.set(3, phases);
                    } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                        sortedPhList.set(4, phases);
                    }
                }

            } else if (!phList.isEmpty() && phList.size() <= 6) {
                for (WSPhase phases : phList) {
                    if (phases.getCode().equalsIgnoreCase(LOW)) {
                        sortedPhList.set(0, phases);
                    } else if (phases.getCode().equalsIgnoreCase(MID)) {
                        sortedPhList.set(1, phases);
                    } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                        sortedPhList.set(2, phases);
                    } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                        sortedPhList.set(3, phases);
                    } else if (phases.getCode().equalsIgnoreCase(CITY)) {
                        sortedPhList.set(4, phases);
                    } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                        sortedPhList.set(5, phases);
                    }
                }

            }
            responseObject.setPhase(sortedPhList);
        }
        return responseObject;
    }

    /**
     * Gets the sorted emissions.
     *
     * @param emission    the emission
     * @param emissionSet the emission set
     * @return the sorted emissions
     */
    private void getSortedEmissions(CalculatedMeasure emission, Set<ResultDto> emissionSet) {

        if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CE)) {
            ResultDto resultCE = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 0);
            emissionSet.add(resultCE);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FC)) {
            ResultDto resultFC = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 1);
            emissionSet.add(resultFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCB)) {
            ResultDto resultFCB = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 2);
            emissionSet.add(resultFCB);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCG)) {
            ResultDto resultFCG = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 3);
            emissionSet.add(resultFCG);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2)) {
            ResultDto resultCO2 = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 4);
            emissionSet.add(resultCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2B)) {
            ResultDto resultCO2B = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 5);
            emissionSet.add(resultCO2B);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2G)) {
            ResultDto resultCO2G = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 6);
            emissionSet.add(resultCO2G);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EC)) {
            ResultDto resultEC = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 7);
            emissionSet.add(resultEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.PER)) {
            ResultDto resultPER = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 8);
            emissionSet.add(resultPER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCS)) {
            ResultDto resultFCCS = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 9);
            emissionSet.add(resultFCCS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CS)) {
            ResultDto resultCO2CS = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 10);
            emissionSet.add(resultCO2CS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCD)) {
            ResultDto resultFCCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 11);
            emissionSet.add(resultFCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CD)) {
            ResultDto resultCO2CD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 12);
            emissionSet.add(resultCO2CD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECCD)) {
            ResultDto resultECCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 13);
            emissionSet.add(resultECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFECCD)) {
            ResultDto resultUFECCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 14);
            emissionSet.add(resultUFECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCFC)) {
            ResultDto resultWCFC = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 15);
            emissionSet.add(resultWCFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCCO2)) {
            ResultDto resultWCCO2 = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 16);
            emissionSet.add(resultWCCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFEC)) {
            ResultDto resultUFEC = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 17);
            emissionSet.add(resultUFEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AER)) {
            ResultDto resultAER = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 18);
            emissionSet.add(resultAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EAER)) {
            ResultDto resultEAER = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 19);
            emissionSet.add(resultEAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AERCD)) {
            ResultDto resultAERCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 20);
            emissionSet.add(resultAERCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CRCD)) {
            ResultDto resultCRCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 21);
            emissionSet.add(resultCRCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDCCD)) {
            ResultDto resultECDCCD = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 22);
            emissionSet.add(resultECDCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDC)) {
            ResultDto resultECDC = new ResultDto(emission.getMeasureTypeCode(),
                    getPhaseResultInFormat(emission.getMeasureTypeCode(), emission.getValue()), 23);
            emissionSet.add(resultECDC);
        }
    }

    /**
     * Gets the numeric answer in required format which is decimal separating comma and non scientific representation of the number rounded according
     * to pattern defined for the param code provided. The RoundingMode used is HALF_UP.
     *
     * @param code  the code
     * @param value the value
     * @return the numeric answer in format
     */
    private String getPhyResultInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = pattern.length() < 2 ? 0 : pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * Gets the numeric answer in required format which is decimal separating comma and non scientific representation of the number rounded according
     * to the rounding digit defined for the param code provided. The RoundingMode used is HALF_UP.
     *
     * @param code  the code
     * @param value the value
     * @return the numeric answer in format
     */
    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the car convertor value.
     *
     * @param conversionData the conversion data
     * @param conversionCode the conversion code
     * @return the car convertor value
     */
    private Optional<String> getCarConvertorValue(List<ConversionData> conversionData, String conversionCode) {
        return conversionData.stream().filter(cd -> cd.getCode().equals(conversionCode)).findFirst().map(ConversionData::getValue);
    }

    /**
     * Gets the physical quantity type code.
     *
     * @param code the code
     * @return the physical quantity type code
     */
    private String getPhysicalQuantityTypeCode(String code) {
        String pqtCode = null;
        WltpCacheManager<PhysicalQuantityType> wltpCacheManager = WltpCacheManager.getInstance(PhysicalQuantityType.class);
        String key = "PQT";
        List<PhysicalQuantityType> pqtsList = wltpCacheManager.getListItem(key);
        if (pqtsList != null && !pqtsList.isEmpty()) {
            pqtCode = pqtsList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
            return pqtCode;
        }
        List<PhysicalQuantityType> pqtList = physicalQuantityTypeRepository.all();
        wltpCacheManager.putListItem(key, pqtList);
        if (pqtList != null && !pqtList.isEmpty()) {
            pqtCode = pqtList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
        }
        if (pqtCode == null) {
            logger.warn("Physical Quantity Type code '{}' is missing. Please verify the database", code);
        }
        return pqtCode;
    }
}
