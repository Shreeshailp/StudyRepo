/*
 * Creation : 3 oct. 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

@RunWith(SeedITRunner.class)
public class TestWSRequestRepresentation {

    Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    // @Test
    public void invalidVersion16C() {

        WSRequestRepresentation wsReq = new WSRequestRepresentation("1CB6A5HCQJB0A01", "M09P23FR", "03", "PLT03PNA01PRL05", "DLT03CPDNA01CPDRL05CP",
                "03", "PLT03PNA01PRL05", "DLT03CPDNA01CPDRL05CP", "2017-06-26", "76", "FULL", "VF3ADS6ER12345678", "2017-09-06", "FR", "");
        Set<ConstraintViolation<WSRequestRepresentation>> errors = validator.validate(wsReq);
        assertThat(errors.size()).isEqualTo(1);
    }
}
