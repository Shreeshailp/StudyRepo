/*
 * Creation : 11 août 2017
 */
package com.inetpsa.w7t.domain.services;

import java.util.UUID;

import javax.inject.Inject;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

@RunWith(SeedITRunner.class)
public class ITEngineMicroValidationPolicy {

    @Inject
    private EngineMicroValidationPolicy wsRequestValidator;

    @Test
    public void testOfRequestValidateMethod() {

        WSRequestRepresentation wsRequest = new WSRequestRepresentation();

        String requestId = UUID.randomUUID().toString();
        wsRequest.setTradingCountry("IT");

        Assertions.assertThatExceptionOfType(WSWltpException.class).isThrownBy(() -> {
            wsRequestValidator.isWSRequestValid(wsRequest, requestId);
        }).withMessageContaining("[WSREQUEST] Incorrect trade country");

        /*
         * Throwable ex = catchThrowable(() -> wsRequestValidator.isWSRequestValid(wsRequest.getTradingCountry())); SoftAssertions.assertSoftly(softly
         * -> { softly.assertThat(ex).as("Incorrect trading country").isInstanceOf(WSWltpException.class) .hasMessageContaining(
         * "Incorrect trading country"); });
         */
    }

}
