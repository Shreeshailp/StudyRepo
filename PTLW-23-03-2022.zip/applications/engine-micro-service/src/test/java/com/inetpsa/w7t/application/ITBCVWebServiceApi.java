/*
 * Creation : 24 août 2017
 */
package com.inetpsa.w7t.application;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Base64;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.interfaces.rest.TitleRepresentation;
import com.netflix.hystrix.exception.HystrixRuntimeException;

import feign.FeignException;

@RunWith(SeedITRunner.class)
public class ITBCVWebServiceApi {

    @Inject
    // private BCVWebServiceAPI bcvApi;

    @Logging
    private Logger logger;

    @Configuration("webService.credentials.bcv.username")
    private static String username;

    @Configuration("webService.credentials.bcv.password")
    private static String password;

    @Test
    public void testOfBCVWebServiceCallByBCVApi() {
        String credsBASE64 = Base64.getEncoder().encodeToString((String.format("%s:%s", username, password)).getBytes());

        TitleRepresentation title = new TitleRepresentation();
        title.setVersion16("1CB6A5HCQJB0A0110");
        title.setHabill("M09P23FR");
        title.setNbPers("03");
        title.setCm("");
        title.setPers("DLT03CPDNA01CPDRL05CP");
        title.setNbGest("00");
        title.setGest("");
        title.setIdentity("");
        title.setSitu("");

        title.setDateExt("20170626");

        try {
            // ExtendedTitleRepresentation extTitle = bcvApi.bcvWebServiceCall(credsBASE64, title);
            // assertThat(extTitle.getCodeAno()).isEqualTo("O");
        } catch (HystrixRuntimeException | FeignException e) {
            logger.info("Hystrix Exception thrown by BCV web service", e);
            assertThat(e.getMessage()).isNotEmpty();
        }
        // Correct answer from BCV: ExtendedTitleRepresentation [identity=, cm=76, version16=1CB6A5HCQJB0A010, habill=M09P23FR, situ=,
        // attributes=DAA17CDDAB00CDDAE06CDDAF01CDDAG00CDDAJ01CDDAK01CDDAL12CDDAO00CDDAP01CDDAQ00CDDAT12CDDAZ18CDDA301CDDA401CDDA605CDDA701CDDA900CDDBG02CDDBK59CDDBM35CDDBP00CDDBX00CDDCB09CDDCD07CDDCF08CDDCG26CDDCK02CDDCO01CDDCP01CDDCR13CDDCT08CDDCW67CDDCX01CDDCY02CDDDA29CDDDC28CDDDG11CDDDH34CDDDI01CDDDJ03CDDDO01CDDDR07CDDDV00CDDDZJMCDDD300CDDD400CDDED00CDDEE32CDDEHKMCDDEJ03CDDEK01CDDENGTCDDEZ00CDDE200CDDE701CDDE801CDDFB01CDDFC26CDDFE10CDDFI03CDDFJ04CDDFK01CDDFT02CDDFX00CDDGB16CDDGG00CDDGMAFCDDGQ06CDDGV00CDDGY34CDDGZ04CDDHB10CDDHD43CDDHG06CDDHN01CDDHU03CDDHY00CDDIA78CDDIJ05CDDIN00CDDIP01CDDIQ01CDDIT01CDDIU01CDDIX07CDDJA11CDDJB00CDDJD02CDDJQ00CDDJV04CDDJY00CDDJZ05CDDLA07CDDLE05CDDLGACCDDLI01CDDLN03CDDLT03CPDLU03CDDLV02CDDLX08CDDL600CDDL700CDDMA68CDDMG07CDDMI00CDDMJ54CDDMM02CDDMP00CDDMTB0CDDMV24CDDMW03CDDMY08CDDMZ02CDDNA01CPDNB08CDDNE04CDDNF04CDDNN01CDDNO05CDDNS00CDDOA04CDDOB00CDDOCECCDDOF00CDDOK00CDDOL06CDDON02CDDOP01CDDOR03CDDOS01CDDOX01CDDOY02CDDOZ01CDDO700CDDPDAECDDPG16CDDPH00CDDPJ00CDDPK02CDDPL44CDDPR01CDDPX00CDDPY13CDDQE01CDDQF00CDDQH06CDDQL01CDDQQ00CDDQS00CDDQV01CDDQX01CDDRB32CDDRCD6CDDRD06CDDRE01CDDRG03CDDRH10CDDRI00CDDRJ04CDDRK04CDDRL05CPDRN14CDDRO01CDDRP03CDDRQ01CDDRS00CDDRU00CDDRZ89CDDSD00CDDSE01CDDSH02CDDSL05CDDSP00CDDSQ00CDDSX19CDDSZ02CDDTE00CDDTG09CDDTI01CDDTN02CDDTQ01CDDTS00CDDUB00CDDUE05CDDUF01CDDUH56CDDUR01CDDUT00CDDUV28CDDUW00CDDUZ01CDDVB04CDDVD02CDDVH23CDDVK77CDDVL02CDDVO00CDDVQ30CDDVX18CDDVY09CDDWL2BCDDXC03CDDXF02CDDXG10CDDXQ54CDDXR10CDDXT01CDDXU00CDDYC03CDDYD00CDDYE01CDDYI19CDDYJ09CDDYK02CDDYM04CDDYQ01CDDYR00CDDYT05CDDYW00CDDZH7SCDFR708E
        // FR900E FV502E FV706E FV806E FV906E FW408E T1A08G T1B08G T3N05H T3P02H T3Q02H T3R05H T8X04G T9A01G T9B01G T9C01G T9D01G, attributesFalse=,
        // codeAno=, msgAno=, dateExt=20161226]
    }

}
