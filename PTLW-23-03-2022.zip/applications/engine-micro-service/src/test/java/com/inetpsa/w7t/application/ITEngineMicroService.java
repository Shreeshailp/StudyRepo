/*
 * Creation : 27 sept. 2017
 */
package com.inetpsa.w7t.application;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;
import com.inetpsa.w7t.interfaces.rest.WSResponseRepresentation;

@RunWith(SeedITRunner.class)
public class ITEngineMicroService {

    @Logging
    private Logger logger;

    @Inject
    private EngineMircoService engineMircoService;

    @Test
    public void testOfEngineMircoService() throws WSWltpException {
        WSRequestRepresentation wsRequest = new WSRequestRepresentation();

        wsRequest.setVersion16C("1PT9A5TMAKJ0A0C1");
        wsRequest.setColorExtInt("M6N90NFJ");
        wsRequest.setNbOptions("");
        wsRequest.setOptions5C("");
        wsRequest.setOptions7C("");
        wsRequest.setMountingCenter("");
        wsRequest.setRequestType(RequestType.FULL.toString());
        wsRequest.setVin("");
        wsRequest.setTradingCountry("CL");
        wsRequest.setExtendedTitleAttributes("");
        wsRequest.setNbGestion("");
        wsRequest.setGestion5C("");
        wsRequest.setGestion7C("");
        LocalDate extensionDate = LocalDate.now();
        wsRequest.setExtensionDate(extensionDate.toString());
        LocalDate ecomDate = LocalDate.now();
        wsRequest.setEcomDate(ecomDate.toString());

        logger.info("CALCUL webservice request = [{}]", wsRequest.toString());
        Optional<WSResponseRepresentation> responseObj = engineMircoService.processRequest(wsRequest, "");
        logger.info("CALCUL webservice response = [{}]", responseObj.toString());

        assertThat(responseObj.isPresent()).isTrue();
        assertThat(responseObj.get().getAnswer().getCode().startsWith("OK")).isTrue();
    }
}
