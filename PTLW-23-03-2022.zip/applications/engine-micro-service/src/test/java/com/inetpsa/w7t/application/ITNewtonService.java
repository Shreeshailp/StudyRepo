/*
 * Creation : 25 oct. 2017
 */
package com.inetpsa.w7t.application;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

@RunWith(SeedITRunner.class)
public class ITNewtonService {

    @Inject
    private NewtonService newtonService;

    @Test
    public void testOfNewtonService() {
        WSRequestRepresentation wsRequest = new WSRequestRepresentation();
        String requestId = UUID.randomUUID().toString();

        wsRequest.setVersion16C("1CB6A5HCQJB0A010");
        wsRequest.setColorExtInt("M09P23FR");
        wsRequest.setNbOptions("03");
        wsRequest.setOptions5C("PLT03PNA01PRL05");
        wsRequest.setOptions7C("DLT03CPDNA01CPDRL05CP");
        wsRequest.setMountingCenter("76");
        wsRequest.setRequestType(RequestType.FULL.toString());
        wsRequest.setVin("VF1ABCDEF12345678");
        wsRequest.setTradingCountry("FR");
        wsRequest.setExtendedTitleAttributes("");
        wsRequest.setNbGestion("");
        wsRequest.setGestion5C("");
        wsRequest.setGestion7C("");
        LocalDate extensionDate = LocalDate.of(2017, 06, 26);
        wsRequest.setExtensionDate(extensionDate.toString());
        LocalDate ecomDate = LocalDate.of(2017, 07, 27);
        wsRequest.setEcomDate(ecomDate.toString());

        List<EnginePhysicalQuantity> engQuants = newtonService.getNewtonPhysicalData(wsRequest, requestId);

        assertThat(engQuants.size()).isEqualTo(7);
    }
}
