
/usr/java/jdk1.8.0_77/bin/java -Xms256m -Xmx10G -Xdebug -jar /usersdev2/w7t/data/engine-micro-service/engine-micro-service-${pom.version}-capsule.jar
exit 0