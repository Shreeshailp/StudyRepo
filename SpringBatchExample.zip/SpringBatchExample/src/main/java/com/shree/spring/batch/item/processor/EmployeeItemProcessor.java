/*
 * Creation : 6 Jul 2018
 */
package com.shree.spring.batch.item.processor;

import org.springframework.batch.item.ItemProcessor;

import com.shree.spring.batch.Employee;

public class EmployeeItemProcessor implements ItemProcessor<Employee, Employee> {

    public Employee process(Employee emp) throws Exception {
        System.out.println("Processing... : " + emp);
        String fname = emp.getFirstName();
        String lname = emp.getLastName();

        emp.setFirstName(fname.toUpperCase());
        emp.setLastName(lname.toUpperCase());
        return emp;
    }

}
