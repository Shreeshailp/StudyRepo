/*
 * Creation : 6 Jul 2018
 */
package com.shree.spring.batch.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.shree.spring.batch.Employee;

public class EmployeeFieldSetMapper implements FieldSetMapper<Employee> {
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public Employee mapFieldSet(FieldSet fieldSet) throws BindException {
        Employee emp = new Employee();
        emp.setId(fieldSet.readInt(0));
        emp.setFirstName(fieldSet.readString(1));
        emp.setLastName(fieldSet.readString(2));
        emp.setAddress(fieldSet.readString(3));
        emp.setSalary(fieldSet.readDouble(4));
        emp.setAge(fieldSet.readInt(5));
        String date = fieldSet.readString(6);
        try {
            emp.setDoj(dateFormat.parse(date));
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return emp;
    }

}
