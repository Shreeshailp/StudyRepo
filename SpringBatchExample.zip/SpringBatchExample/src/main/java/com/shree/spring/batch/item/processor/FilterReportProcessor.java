/*
 * Creation : 11 Jul 2018
 */
package com.shree.spring.batch.item.processor;

import org.springframework.batch.item.ItemProcessor;

import com.shree.spring.batch.Report;

public class FilterReportProcessor implements ItemProcessor<Report, Report> {

    public Report process(Report item) throws Exception {
        System.out.println("Name: " + item.getName());
        String name = item.getName();
        item.setName(name.toUpperCase());

        return item;
    }

}
