/*
 * Creation : 9 Jul 2018
 */
package com.shree.spring.batch.item.processor;

import org.springframework.batch.item.ItemProcessor;

import com.shree.spring.batch.AOGEOS;

public class AOGEOSItemProcessor implements ItemProcessor<AOGEOS, AOGEOS> {

    public AOGEOS process(AOGEOS item) throws Exception {

        System.out.println("Processing... : " + item);
        return item;
    }

}
