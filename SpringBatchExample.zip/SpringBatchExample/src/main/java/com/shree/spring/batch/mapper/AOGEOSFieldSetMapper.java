/*
 * Creation : 10 Jul 2018
 */
package com.shree.spring.batch.mapper;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.shree.spring.batch.AOGEOS;

public class AOGEOSFieldSetMapper implements FieldSetMapper<AOGEOS> {

    public AOGEOS mapFieldSet(FieldSet fieldSet) throws BindException {
        AOGEOS aogeos = new AOGEOS();
        if (fieldSet != null && fieldSet.readRawString("value1").contains("9999WLTP")) {
            return null;
        } else {
            aogeos.setValue1(fieldSet.readRawString("value1"));
            aogeos.setValue2(fieldSet.readRawString("value2"));
            System.out.println(aogeos.getValue1());
            System.out.println(aogeos.getValue2());
        }

        return aogeos;
    }

}
