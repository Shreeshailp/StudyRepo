/*
 * Creation : 28 juin 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.UUID;

import javax.inject.Inject;

import org.javatuples.Pair;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.engine.model.calculation.VehicleBoundary;

@RunWith(SeedITRunner.class)
public class ITVehicleBoundaryService {

    @Inject
    private VehicleBoundaryService vehicleBoundaryService;

    private UUID family2Vehicles = UUID.fromString("9af9bdf2-0473-491d-9caa-f6f91b625abe");
    private UUID family3Vehicles = UUID.fromString("51a00f3c-9203-4fc5-bda1-2e5b7fe76b1e");
    private UUID phaseId = UUID.fromString("1ad29e96-3754-4a5a-ba65-7c291ce898c5");

    @Test
    public void nominalBoundariesWith2Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family2Vehicles, phaseId, 150);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 100.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 200.0);
    }

    @Test
    public void nominalBoundariesWith3Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family3Vehicles, phaseId, 125);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 100.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 150.0);

        vb = vehicleBoundaryService.vehicleBoundaries(family3Vehicles, phaseId, 175);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 150.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 200.0);
    }

    @Test
    public void lowBoundariesWith2Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family2Vehicles, phaseId, 50);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 100.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 200.0);
    }

    @Test
    public void lowBoundariesWith3Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family3Vehicles, phaseId, 50);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 100.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 150.0);
    }

    @Test
    public void highBoundariesWith2Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family2Vehicles, phaseId, 250);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 100.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 200.0);
    }

    @Test
    public void highBoundariesWith3Vehicles() {
        Pair<VehicleBoundary, VehicleBoundary> vb = vehicleBoundaryService.vehicleBoundaries(family3Vehicles, phaseId, 250);

        assertThat(vb.getValue0()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 150.0);
        assertThat(vb.getValue1()).isNotNull().hasFieldOrPropertyWithValue("cycleEnergy", 200.0);
    }
}
