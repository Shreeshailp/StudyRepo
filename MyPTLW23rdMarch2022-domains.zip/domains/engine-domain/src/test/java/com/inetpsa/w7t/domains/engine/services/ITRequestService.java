/*
 * Creation : 7 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;

/**
 * The Class ITRequestService.
 */
@RunWith(SeedITRunner.class)
public class ITRequestService {

    /** The request service. */
    @Inject
    private RequestService requestService;

    @Inject
    private RequestRepository requestRepository;

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * Test that upload method runs successfully.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Test
    public void testThatImportMethodRunsSuccessfully() throws IOException {

        List<Request> requestsList = new ArrayList<>();

        Request request1 = new Request(UUID.randomUUID(), false, RequestType.FULL, "W7T3878142932", "W7T86416229728888777", LocalDateTime.now(),
                "VF3L45GTHFS130997", LocalDate.now(), "1CE3T8C01T8D02T3N40GG801");
        requestsList.add(request1);
        String manualFileId = requestService.importRequest(requestsList);
        assertThat(manualFileId.length()).isEqualTo(13);

    }

    @Test
    public void testThatBatchStatusCheckMethodErrorsSuccessfully() {
        String fileId = "W8T3878142933";
        Optional<RequestBatchEntity> manualRequestBatchObject = requestService.batchByFileId(fileId);
        assertThat(manualRequestBatchObject.isPresent()).isFalse();
    }

    @Test
    public void testThatBatchStatusCheckMethodRunsSuccessfully() {
        String fileId = "W7T9563262365";
        Optional<RequestBatchEntity> manualRequestBatchObject = requestService.batchByFileId(fileId);
        assertThat(manualRequestBatchObject.isPresent()).isTrue();
    }

    @Test
    public void testTitleIsValid() {
        String extndTitle = "1CXAXXXXXXXXXXXXXXXXXXXXT3N98H T8CLDG T8D10G T8E01G GG8F0A ";
        Request item = new Request(UUID.randomUUID(), false, RequestType.FULL, "W7T3878142932", "W7T86416229728888777", LocalDateTime.now(),
                "VF3L45GTHFS130997", LocalDate.now(), extndTitle);
        boolean validFlag = requestService.titleIsValid(item);
        assertThat(validFlag).isFalse();
    }
}
