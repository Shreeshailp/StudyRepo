
/*
 * Creation : 12 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;

import org.assertj.core.api.SoftAssertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.SeedException;
import org.seedstack.seed.it.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.fixtures.DestinationFixture;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedDataFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestFactory;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.references.model.MeasureType;

@RunWith(SeedITRunner.class)
public class ITEngineCalculatorService {
    @Inject
    private EngineCalculatorService calculatorService;

    @Inject
    private RequestFactory requestFactory;

    @Inject
    private CalculatedDataFactory calculatedDataFactory;

    @Inject
    private DestinationDetailsRepository destinationDetailsRepository;

    @Inject
    private DestinationFixture destinationFixture;

    private Request nominalRequest;
    private Version nominalVersion;
    private Version nominalEmptyVersion;
    private String nominalExtendedTitle;
    private DestinationDetails nominalDestination;
    boolean createdDestination = false;
    private List<EnginePhysicalQuantity> nominalPhysicalQuantities;

    private String nominalVehicleFamily = "1CXA";
    private String nominalFamilyCode = "01";
    private String nominalFamilyIndex = "01";
    private String nominalProgramCountry = "19";
    private String nominalDataCoherenceIndex = "01";
    private String nominalGvm = "40";

    private String extendedTitleBuilder(String vehicleFamily, String familyCode, String familyIndex, String programCountry, String dataCoherenceIndex,
            String gvm) {
        StringBuilder extendedTitleBuilder = new StringBuilder(vehicleFamily).append("A5HCQJJRA016M6FC23FR");
        extendedTitleBuilder.append("T8C").append(familyCode).append("G ");
        extendedTitleBuilder.append("T8D").append(familyIndex).append("G ");
        extendedTitleBuilder.append("GG8").append(programCountry).append("A ");
        extendedTitleBuilder.append("T8E").append(dataCoherenceIndex).append("G ");
        extendedTitleBuilder.append("T3N").append(gvm).append("H ");
        return extendedTitleBuilder.toString();
    }

    @Before
    @Transactional
    @JpaUnit("wltp-domain-jpa-unit")
    public void setUp() {
        nominalExtendedTitle = extendedTitleBuilder(nominalVehicleFamily, nominalFamilyCode, nominalFamilyIndex, nominalProgramCountry,
                nominalDataCoherenceIndex, nominalGvm);

        nominalRequest = requestFactory.createRequest(UUID.fromString("cc2c67bd-efa0-4bdc-acd0-d8d31891faaf"), false, RequestType.FULL, "W7T1",
                "TESTREQUEST", LocalDateTime.now(), "VF3L45GTHFS130997", LocalDate.parse("2018-02-15"), nominalExtendedTitle);

        nominalVersion = new Version(LocalDate.parse("2018-02-15"), nominalExtendedTitle, RequestType.FULL, "GG8");

        nominalPhysicalQuantities = new ArrayList<>();
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("MASSE", 1300));
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("SCX", 0.7));
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("CRR", 6.9));

        nominalRequest.updatePhysicalQuantities(nominalPhysicalQuantities);

        nominalDestination = destinationDetailsRepository.byCountryAndDate(nominalProgramCountry, "GG8", LocalDate.parse("2018-02-15"))
                .orElseGet(() -> {
                    createdDestination = true;
                    DestinationDetails dest = destinationFixture.createDestination(LocalDate.parse("2018-02-15"), nominalProgramCountry, "GG8",
                            "CONV", Arrays.asList("LOW", "MID", "HIGH"));
                    destinationDetailsRepository.persist(dest);
                    return dest;
                });
    }

    @After
    @Transactional
    @JpaUnit("wltp-domain-jpa-unit")
    public void tearDown() {
        if (createdDestination)
            destinationDetailsRepository.delete(nominalDestination.getGuid());
    }

    @Test
    public void calculateMissingPhysicalQuantities() {
        Throwable noPQ = catchThrowable(() -> calculatorService.calculate(nominalVersion, null, ""));
        Throwable emptyPQ = catchThrowable(() -> calculatorService.calculate(nominalVersion, Collections.emptyList(), ""));

        assertThat(noPQ).as("Null Physical Quantities").isInstanceOf(ConstraintViolationException.class);
        assertThat(emptyPQ).as("Empty Physical Quantities").isInstanceOf(ConstraintViolationException.class);
    }

    @Test
    public void calculateNominalRequest() {
        Calculation calculation = calculatorService.calculate(nominalRequest);

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(calculation).isNotNull();
            softly.assertThat(calculation.getVersion()).isEqualTo(nominalVersion);
        });
    }

    @Test
    public void calculateWithRequestMissingPhysicalQuantities() {
        Request noPQRequest = requestFactory.createRequest(UUID.fromString("cc2c67bd-efa0-4bdc-acd0-d8d31891faaf"), false, RequestType.FULL, "W7T1",
                "TESTREQUEST", LocalDateTime.now(), "VF3L45GTHFS130997", LocalDate.parse("2018-02-15"), nominalExtendedTitle);

        Throwable missingPQ = catchThrowable(() -> calculatorService.calculate(noPQRequest));

        assertThat(missingPQ).as("Missing Physical Quantities in Request").isInstanceOf(SeedException.class).extracting("errorCode")
                .containsExactly(RequestErrorCode.PHYSICAL_DATA_MISSING);
    }

    @Test
    public void calculateNominalVersion() {
        Calculation calculation = calculatorService.calculate(nominalVersion, nominalPhysicalQuantities, "");

        assertThat(calculation.getVersion()).as("Calculation's version").isEqualTo(nominalVersion);
    }

    @Test
    public void retrieveData() {
        Calculation calculation = calculatorService.calculate(nominalVersion, nominalPhysicalQuantities, "");

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(calculation.getFamily().getGuid()).as("Family Details").isNotNull();
            softly.assertThat(calculation.getReferences().getCycles()).as("Cycle Details").isNotEmpty();
            softly.assertThat(calculation.getReferences().getDestination()).as("Destination Details").isNotNull();
            softly.assertThat(calculation.getReferences().getGrossVehicleMass()).as("Gross Vehicle Mass").isNotNull();
            softly.assertThat(calculation.getReferences().getPayloadPercentage()).as("Payload Percentage").isNotNull();
        });
    }

    @Test
    public void failToRetrieveFamily() {
        Version missingFamilyVersion = new Version(LocalDate.now(),
                extendedTitleBuilder("ZZ", nominalFamilyCode, nominalFamilyIndex, nominalProgramCountry, nominalDataCoherenceIndex, nominalGvm),
                RequestType.FULL, "GG8");
        Throwable missingFamily = catchThrowable(() -> calculatorService.calculate(missingFamilyVersion, nominalPhysicalQuantities, ""));

        assertThat(missingFamily).as("Missing Family").isInstanceOf(SeedException.class).extracting("errorCode")
                .containsExactly(WltpEngineCalculatorErrorCode.MISSING_FAMILY);
    }

    @Test
    public void failToRetrieveDestination() {
        Version destinationLess = new Version(LocalDate.parse("2018-01-15"), nominalExtendedTitle, RequestType.FULL, "GG8");

        Throwable missingDestination = catchThrowable(() -> calculatorService.calculate(destinationLess, nominalPhysicalQuantities, ""));

        assertThat(missingDestination).as("Missing Destination").isInstanceOf(SeedException.class).extracting("errorCode")
                .containsExactly(WltpEngineCalculatorErrorCode.NO_DESTINATION_FOUND);
    }

    /**
     * Fail to retrieve gross vehicle mass. The GVM in the database is for family 1CE3 and code 01
     */
    @Test
    public void failToRetrieveGrossVehicleMass() {
        Version v = new Version(LocalDate.parse("2018-02-15"), extendedTitleBuilder(nominalVehicleFamily, nominalFamilyCode, nominalFamilyIndex,
                nominalProgramCountry, nominalDataCoherenceIndex, "02"), RequestType.FULL, "GG8");

        Throwable missingGvm = catchThrowable(() -> calculatorService.calculate(v, nominalPhysicalQuantities, ""));

        assertThat(missingGvm).as("Missing Gross Vehicle Mass").isInstanceOf(SeedException.class).extracting("errorCode")
                .containsExactly(WltpEngineCalculatorErrorCode.NO_GVM_FOUND);
    }

    /**
     * Fail to retrieve payload percentage. The payload percentage in the database (06089fe2-eeb3-4e3b-871c-bdc578b52025) starts 2018-01-01 and ends
     * 2018-02-15
     */
    @Test
    public void failToRetrievePayloadPercentage() {
        Version noPayloadPercentage = new Version(LocalDate.parse("2018-02-20"), nominalExtendedTitle, RequestType.FULL, "GG8");

        Throwable missingPayloadPercentage = catchThrowable(() -> calculatorService.calculate(noPayloadPercentage, nominalPhysicalQuantities, ""));

        assertThat(missingPayloadPercentage).as("Missing Payload Percentage").isInstanceOf(SeedException.class).extracting("errorCode")
                .containsExactly(WltpEngineCalculatorErrorCode.NO_PERCENTAGE_PAYLOAD);
    }

    /**
     * Test mass. The simulated calculated vehicle Mass returned from Newton of the tuple (1CE3, 01) can be 800
     */
    @Test
    public void testMass() {
        Calculation calculation = calculatorService.calculate(nominalVersion, nominalPhysicalQuantities, "");

        int gvm = 2534; // From the database
        int vehicleMass = 1400; // From Newton
        int personMass = CalculationConstants.PERSON_MASS;
        int luggageMass = CalculationConstants.LUGGAGE_MASS;
        double payloadPercentage = calculation.getReferences().getPayloadPercentage().getValue() / 100.0;

        int usedMass = vehicleMass + personMass + luggageMass;
        int payload = gvm - usedMass;
        double exactTestMass = usedMass + payloadPercentage * payload;
        int expectedTestMass = BigDecimal.valueOf(exactTestMass).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(calculation.getCalculatedData()).as("not null calculated data").isNotNull();
            softly.assertThat(calculation.getCalculatedData().getTestMass()).as("Test mass is present").isPresent().contains(expectedTestMass);
        });
    }

    @Test
    public void roadLoad() {
        Calculation calculation = calculatorService.calculate(nominalVersion, nominalPhysicalQuantities, "");

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(calculation.getCalculatedData()).as("not null calculated data").isNotNull();
            softly.assertThat(calculation.getCalculatedData().getRoadLoad()).as("Road load is present").isPresent();
        });
    }

    @Test
    public void calculatedPhases() {
        Calculation calculation = calculatorService.calculate(nominalVersion, nominalPhysicalQuantities, "");

        SoftAssertions.assertSoftly(softly -> {
            softly.assertThat(calculation.getCalculatedData()).as("not null calculated data").isNotNull();
            softly.assertThat(calculation.getCalculatedData().getCalculatedPhases()).as("Calculated phases are present").isPresent();
        });
    }

    @Test
    public void testDataCalculation() {
        Request req = requestFactory.createRequest(UUID.randomUUID(), true, RequestType.FULL, "W7T1", "TESTREQUEST", LocalDateTime.now(),
                "VF3L45GTHFS130997", LocalDate.parse("2017-01-01"), nominalExtendedTitle);

        List<EnginePhysicalQuantity> pq = new ArrayList<>();
        pq.add(new EnginePhysicalQuantity("MASSE", 1400));
        pq.add(new EnginePhysicalQuantity("SCX", 0.7));
        pq.add(new EnginePhysicalQuantity("CRR", 6.9));

        req.updatePhysicalQuantities(pq);

        Calculation calculation = calculatorService.calculate(req);

        assertThat(calculation).isNotNull();
        assertThat(calculation.getCalculatedData()).isNotNull();
        assertThat(calculation.getCalculatedData().getTestMass()).isPresent().contains(1655);
        assertThat(calculation.getCalculatedData().getRoadLoad()).isPresent().map(List::size).isPresent().contains(3);
        assertThat(calculation.getCalculatedData().getCalculatedPhases()).isPresent().map(List::size).isPresent().contains(5);
    }

    @Test
    public void savingRequestEntity() {

        CalculatedData calculatedValues = calculatedDataFactory.empty();
        List<CalculatedPhase> calculatedPhases = new ArrayList<CalculatedPhase>();
        CalculatedPhase e = calculatedDataFactory.createCalculatedPhase(calculatedValues, "code", UUID.randomUUID());
        e.energyValue(150);
        MeasureType mt = new MeasureType();
        mt.setCode("CO2");
        mt.setLabel("label");
        mt.setRoundingDigits(3);
        mt.setSort(1);
        List<UUID> vehicleTypes = new ArrayList<UUID>();
        vehicleTypes.add(UUID.randomUUID());
        mt.setVehicleTypes(vehicleTypes);
        e.addEmission(mt, 160);
        calculatedPhases.add(e);
        calculatedValues.setCalculatedPhases(calculatedPhases);
        List<EnginePhysicalQuantity> roadLoad = new ArrayList<EnginePhysicalQuantity>();
        EnginePhysicalQuantity rl = new EnginePhysicalQuantity("EPQ", 123);
        roadLoad.add(rl);
        calculatedValues.setRoadLoad(roadLoad);
        calculatedValues.setTestMass(1);
        nominalRequest.setCalculatedValues(calculatedValues);
    }
}