/*
 * Creation : 15 mai 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestFactory;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.model.request.Step;

@RunWith(SeedITRunner.class)
public class ITStepRepository {

    /** The request factory. */
    @Inject
    private RequestFactory requestFactory;

    @Inject
    private StepRepository stepRepository;

    private Step nominalStep;
    private Request request;

    @Before
    public void setUp() {

        StringBuilder extendedTitleBuilder = new StringBuilder("1CE3").append("A5HCQJJRA016M6FC23FR");
        extendedTitleBuilder.append("T8C").append("E5").append("G ");
        extendedTitleBuilder.append("T8D").append("01").append("G ");
        extendedTitleBuilder.append("GG8").append("FR").append("A ");
        extendedTitleBuilder.append("T8E").append("01").append("G ");
        extendedTitleBuilder.append("T3N").append("01").append("H ");
        String extendedTitle = extendedTitleBuilder.toString();

        request = requestFactory.createRequest(UUID.randomUUID(), true, RequestType.FULL, "W7T1", "W7T1", LocalDateTime.now(), "VF3L45GTHFS130997",
                LocalDate.now(), extendedTitle);
        request.setGuid(UUID.randomUUID());
        nominalStep = request.nextStep();
    }

    @Test
    public void testPersistStep() {
        stepRepository.persist(nominalStep);
    }

    @After
    public void tearDown() {
        // Supposed to delete the created step but no way to get the ID.
        // Create a delete(Step) method ?
    }
}
