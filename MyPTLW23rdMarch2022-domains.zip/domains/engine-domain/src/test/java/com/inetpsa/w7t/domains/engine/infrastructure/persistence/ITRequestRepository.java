/*
 * Creation : 27 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.assembler.dsl.AggregateNotFoundException;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestEntity;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedDataFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestFactory;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.infrastructure.WltpModelMapper;
import com.inetpsa.w7t.domains.references.model.MeasureType;

/**
 * The Class ITRequestRepository.
 */
@RunWith(SeedITRunner.class)
public class ITRequestRepository {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The request factory. */
    @Inject
    private RequestFactory requestFactory;

    @Inject
    private CalculatedDataFactory calculatedDataFactory;

    /** The request repository. */
    @Inject
    private RequestRepository requestRepository;

    /** The newton repository. */
    @Inject
    private NewtonRepository newtonRepository;

    /** The fluent assembler. */
    @Inject
    private FluentAssembler fluentAssembler;

    /** The request. */
    private Request request;

    /** The request entity. */
    private RequestEntity requestEntity;

    /**
     * Sets the up.
     */
    @Before
    public void setUp() {
        StringBuilder extendedTitleBuilder = new StringBuilder("1CE3").append("A5HCQJJRA016M6FC23FR");
        extendedTitleBuilder.append("T8C").append("E5").append("G ");
        extendedTitleBuilder.append("T8D").append("01").append("G ");
        extendedTitleBuilder.append("GG8").append("FR").append("A ");
        extendedTitleBuilder.append("T8E").append("01").append("G ");
        extendedTitleBuilder.append("T3N").append("01").append("H ");
        String extendedTitle = extendedTitleBuilder.toString();

        request = requestFactory.createRequest(UUID.randomUUID(), true, RequestType.FULL, "W7T1", "W7T1", LocalDateTime.now(), "VF3L45GTHFS130997",
                LocalDate.now(), extendedTitle);
    }

    /**
     * Entity.
     */
    @Test
    public void entity() {

        requestEntity = fluentAssembler.merge(request).with(WltpModelMapper.class).into(RequestEntity.class).fromFactory();

        assertThat(requestEntity).isNotNull();
    }

    /**
     * Calculated data.
     */
    @Test
    public void calculatedData() {
        CalculatedData calculatedData = calculatedDataFactory.empty();

        List<EnginePhysicalQuantity> roadLoad = Arrays.asList(new EnginePhysicalQuantity("F0", 102.55), new EnginePhysicalQuantity("F1", 112.55),
                new EnginePhysicalQuantity("F2", 122.55));

        CalculatedPhase phase = calculatedDataFactory.createCalculatedPhase(calculatedData, "LOW", UUID.randomUUID());
        phase.energyValue(123456789);
        MeasureType mt = new MeasureType();
        mt.setCode("FC");
        mt.setRoundingDigits(1);
        phase.addEmission(mt, 1232.4);
        mt.setCode("EC");
        mt.setRoundingDigits(0);
        phase.addEmission(mt, 1232.0);

        List<CalculatedPhase> calculatedPhases = Arrays.asList(phase);

        calculatedData.setTestMass(1543).setRoadLoad(roadLoad).setCalculatedPhases(calculatedPhases);

        request.update(calculatedData);

        requestEntity = fluentAssembler.merge(request).with(WltpModelMapper.class).into(RequestEntity.class).fromFactory();

        assertThat(requestEntity.getCalculatedValues()).isNotNull();
    }

    /**
     * Test get req by request batch id.
     */
    @Test
    public void testGetReqByRequestBatchId() {

        Optional<List<Request>> requestList = requestRepository.byRequestBatchId(UUID.fromString("32a0c33f-04ad-4093-b6b2-70ca25d1b32a"),
                RequestStatus.timeoutables());
        requestList.ifPresent(request -> request.stream().forEach(req -> testWriteError(req, "corvet")));
        assertThat(requestList).isNotNull();
    }

    /**
     * Test write error.
     *
     * @param request the request
     * @param clientName the client name
     */
    private void testWriteError(Request request, String clientName) {
        logger.info("Client name" + clientName);
        if (!request.getStatus().isCompletedStatus()) {
            logger.info(request.toString());
        }
    }

    /**
     * Test get req by request id.
     */
    @Test
    public void testGetReqByRequestId() {
        Request req = requestRepository.byRequestId("W7T973754287698601769");
        if (req != null) {
            assertThat(newtonRepository.getNewtonEntity(req)).isPresent();
        }
    }

    @Test
    @Transactional
    @JpaUnit("wltp-domain-jpa-unit")
    public void saveRequestEntity() {
        Request req = fluentAssembler.assemble(requestRepository.load(UUID.fromString("2b359724-cc5b-4db2-8f82-53cae50d9e2f")))
                .with(WltpModelMapper.class).to(Request.class);
        logger.info("{}", req);

        assertThat(req.getGuid()).isEqualTo(UUID.fromString("2b359724-cc5b-4db2-8f82-53cae50d9e2f"));

        try {
            RequestEntity reqEntity = fluentAssembler.merge(req).with(WltpModelMapper.class).into(RequestEntity.class).fromRepository().orFail();
        } catch (AggregateNotFoundException e) {
            fail("Should not have thrown", e);
        }
    }

    @Test
    @Transactional
    @JpaUnit("wltp-domain-jpa-unit")
    public void loadRequestEntity() {
        RequestEntity req = requestRepository.load(UUID.fromString("2b359724-cc5b-4db2-8f82-53cae50d9e2f"));

        assertThat(req).isNotNull();
    }

    @Test
    @Transactional
    @JpaUnit("wltp-domain-jpa-unit")
    public void loadRequest() {
        RequestEntity req = requestRepository.load(UUID.fromString("d194072b-a9c5-4646-964a-f66cad77cbeb"));

        Request request = fluentAssembler.assemble(req).with(WltpModelMapper.class).to(Request.class);

        assertThat(req).isNotNull();
        assertThat(request).isNotNull();
    }
}
