/*
 * Creation : 5 mai 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;

/**
 * The Class ITRequestBatchRepository.
 */
@RunWith(SeedITRunner.class)
public class ITRequestBatchRepository {

    /** The request batch repository. */
    @Inject
    RequestBatchRepository requestBatchRepository;

    /**
     * Test get unprocess request batches.
     */
    @Test
    public void testGetUnprocessRequestBatches() {

        Optional<List<RequestBatch>> requestBatchList = requestBatchRepository.getTimeOutRequestBatches(3600, "");
        assertThat(requestBatchList).isNotNull();
    }

    /**
     * Test get completed request batches.
     */
    @Test
    public void testGetCompletedRequestBatches() {

        Optional<List<RequestBatch>> requestBatchList = requestBatchRepository.getCompletedRequestBatches();
        assertThat(requestBatchList).isNotNull();
    }
}
