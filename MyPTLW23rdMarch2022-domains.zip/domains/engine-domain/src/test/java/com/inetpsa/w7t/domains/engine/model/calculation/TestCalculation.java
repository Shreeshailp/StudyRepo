/*
 * Creation : 4 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import javax.validation.ConstraintViolationException;

import org.junit.Before;

import com.google.common.collect.Lists;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;
import com.inetpsa.w7t.domains.references.model.PayloadPercentage;

public class TestCalculation {

    private Version nominalVersion;
    private Calculation nominalCalculation;
    private FamilyDetails nominalFamily;
    private CalculatedData nominalCalculatedData;
    private List<EnginePhysicalQuantity> nominalPhysicalQuantities;

    private CycleDetails nominalCycleDetails;
    private PayloadPercentage nominalPayloadPercentage;
    private GrossVehicleMass nominalGrossVehicleMass;
    private DestinationDetails nominalDestinationDetails;

    @Before
    public void setUp() {
        nominalVersion = new Version(LocalDate.parse("2017-04-04"), "1CE3A5HCQJJRA016M6FC23FRT8CE5G T8D01G GG819A T8E01G T3N01H ", RequestType.FULL,
                "GG8");

        nominalCalculation = new Calculation(nominalVersion);

        nominalFamily = new FamilyDetails();
        nominalFamily.setGuid(UUID.randomUUID());
        nominalFamily.setCode("AS");
        nominalFamily.setIndex(1);
        nominalFamily.setType("CONV");
        // nominalFamily.setCategory("e5");
        nominalFamily.setCycles(new ArrayList<UUID>());
        nominalFamily.setVehicles(Lists.newArrayList(null, null));

        nominalCalculatedData = new CalculatedData();
        nominalCalculatedData.setTestMass(1232);
        nominalCalculatedData.setRoadLoad(Arrays.asList(new EnginePhysicalQuantity("F0", 3.4)));
        nominalCalculatedData.setCalculatedPhases(Arrays.asList(new CalculatedPhase("LOW", UUID.randomUUID())));

        nominalPhysicalQuantities = new ArrayList<>();
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("F0", 102.34));
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("F1", 112.34));
        nominalPhysicalQuantities.add(new EnginePhysicalQuantity("F2", 122.34));

        nominalCycleDetails = new CycleDetails();
        nominalCycleDetails.setGuid(UUID.randomUUID());
        nominalCycleDetails.setCode("STD01LOW");
        nominalCycleDetails.setComment("This is a comment.");
        nominalCycleDetails.setPhase("LOW");
        nominalCycleDetails.setFamilies(Arrays.asList(nominalFamily.getGuid()));
        nominalCycleDetails.setProfiles(Collections.emptyList());
        nominalFamily.getCycles().add(nominalCycleDetails.getGuid());

        nominalPayloadPercentage = new PayloadPercentage();
        nominalPayloadPercentage.setGuid(UUID.randomUUID());
        nominalPayloadPercentage.setValue(15);
        nominalPayloadPercentage.setValidityEnd(LocalDate.MAX);
        nominalPayloadPercentage.setValidityStart(LocalDate.MIN);

        nominalGrossVehicleMass = new GrossVehicleMass();
        nominalGrossVehicleMass.setGuid(UUID.randomUUID());
        nominalGrossVehicleMass.setFamily("1CXA");
        nominalGrossVehicleMass.setCode("01");
        nominalGrossVehicleMass.setValue("1232");

        nominalDestinationDetails = new DestinationDetails();
        nominalDestinationDetails.setGuid(UUID.randomUUID());
        nominalDestinationDetails.setFromDate(LocalDate.MIN);
        nominalDestinationDetails.setToDate(LocalDate.MAX);
        nominalDestinationDetails.setLabel("Europe EURO 1.0");
        nominalDestinationDetails.setCountries(Collections.emptyList());
        nominalDestinationDetails.setParameterDetails(Collections.emptyList());
    }

    // @Test
    public void nominalCalculation() {
        assertThat(nominalCalculation.getVersion()).isEqualTo(nominalVersion);
    }

    // @Test
    public void nullVersionCalculation() {
        Throwable nullVersion = catchThrowable(() -> new Calculation(null));

        assertThat(nullVersion).as("Null version").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The version must not be null");
    }

    // @Test
    public void nominalGetterSetterFamily() {
        Throwable noFamily = catchThrowable(() -> nominalCalculation.getFamily());
        assertThat(noFamily).as("Get family when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The family is not available, call Calculation.setFamily()");

        nominalCalculation.setFamily(nominalFamily);

        assertThat(nominalCalculation.getFamily()).isEqualTo(nominalFamily);
    }

    // @Test
    public void nullSetFamily() {
        Throwable nullFamily = catchThrowable(() -> nominalCalculation.setFamily(null));

        assertThat(nullFamily).as("Set family with null value").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The family must not be null");
    }

    // @Test
    public void setFamilyTwice() {
        nominalCalculation.setFamily(nominalFamily);

        assertThat(nominalCalculation.getFamily()).isEqualTo(nominalFamily);

        Throwable twice = catchThrowable(() -> nominalCalculation.setFamily(nominalFamily));

        assertThat(twice).as("Set family twice").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The family can only be set once");
    }

    // @Test
    public void nominalGetterSetterCalculatedData() {
        Throwable noCalculatedData = catchThrowable(() -> nominalCalculation.getCalculatedData());
        assertThat(noCalculatedData).as("Get calculated data when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The calculated data is not available, call Calculation.setCalculatedData()");

        nominalCalculation.setCalculatedData(nominalCalculatedData);

        assertThat(nominalCalculation.getCalculatedData()).isEqualTo(nominalCalculatedData);
    }

    // @Test
    public void nullSetCalculatedData() {
        Throwable nullCalculatedData = catchThrowable(() -> nominalCalculation.setCalculatedData(null));

        assertThat(nullCalculatedData).as("Set calculated data with null value").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The calculated data must not be null");
    }

    // @Test
    public void nominalGetterSetterPhysicalQuantities() {
        Throwable noPhysicalQuantities = catchThrowable(() -> nominalCalculation.getPhysicalQuantities());
        assertThat(noPhysicalQuantities).as("Get physical quantities when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The physical quantities are not available, call Calculation.setPhysicalQuantities()");

        nominalCalculation.setPhysicalQuantities(nominalPhysicalQuantities);

        assertThat(nominalCalculation.getPhysicalQuantities()).isEqualTo(nominalPhysicalQuantities);
    }

    // @Test
    public void nullOrEmptySetPhysicalQuantities() {
        Throwable nullPhysicalQuantities = catchThrowable(() -> nominalCalculation.setPhysicalQuantities(null));
        Throwable emptyPhysicalQuantities = catchThrowable(() -> nominalCalculation.setPhysicalQuantities(Collections.emptyList()));

        assertThat(nullPhysicalQuantities).as("Set physical quantities with null value").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The physical quantities must not be neither null nor empty");
        assertThat(emptyPhysicalQuantities).as("Set physical quantities with empty value").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The physical quantities must not be neither null nor empty");
    }

    // @Test
    public void getNoReferences() {
        Throwable noReferences = catchThrowable(() -> nominalCalculation.getReferences());
        assertThat(noReferences).as("Get references when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The references are not available, call Calculation.add*Reference()");
    }

    // @Test
    public void nullReferences() {

        Throwable nullCycleReference = catchThrowable(() -> nominalCalculation.addCyclesReference(null));
        Throwable nullPayloadPercentageReference = catchThrowable(() -> nominalCalculation.addPayloadPercentageReference(null));
        Throwable nullGrossVehicleMassReference = catchThrowable(() -> nominalCalculation.addGrossVehicleMassReference(null));
        Throwable nullDestinationReference = catchThrowable(() -> nominalCalculation.addDestinationReference(null));

        assertThat(nullCycleReference).as("Null cycle reference").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The cycles must not be null");
        assertThat(nullPayloadPercentageReference).as("Null payload percentage reference").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The payload percentage must not be null");
        assertThat(nullGrossVehicleMassReference).as("Null gross vehicle mass reference").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The gross vehicle mass must not be null");
        assertThat(nullDestinationReference).as("Null destination reference").isInstanceOf(ConstraintViolationException.class)
                .hasMessageContaining("The destination must not be null");
    }

    // @Test
    public void nominalReferencesExceptDestination() {
        // Add another reference in order to create the References object
        nominalCalculation.addDestinationReference(nominalDestinationDetails);

        Throwable noCycleReference = catchThrowable(() -> nominalCalculation.getReferences().getCycles());
        assertThat(noCycleReference).as("Get cycle reference when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The cycles reference is not available, call Calculation.addCyclesReference()");
        Throwable noPayloadPercentageReference = catchThrowable(() -> nominalCalculation.getReferences().getPayloadPercentage());
        assertThat(noPayloadPercentageReference).as("Get payload percentage reference when there is none")
                .isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The payload percentage reference is not available, call Calculation.addPayloadPercentageReference()");
        Throwable noGrossVehicleMassReference = catchThrowable(() -> nominalCalculation.getReferences().getGrossVehicleMass());
        assertThat(noGrossVehicleMassReference).as("Get gross vehicle mass reference when there is none")
                .isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The gross vehicle mass reference is not available, call Calculation.addGrossVehicleMassReference()");

        nominalCalculation.addCyclesReference(Arrays.asList(nominalCycleDetails)).addPayloadPercentageReference(nominalPayloadPercentage)
                .addGrossVehicleMassReference(nominalGrossVehicleMass);

        assertThat(nominalCalculation.getReferences().getCycles()).containsExactly(nominalCycleDetails);
        assertThat(nominalCalculation.getReferences().getPayloadPercentage()).isEqualTo(nominalPayloadPercentage);
        assertThat(nominalCalculation.getReferences().getGrossVehicleMass()).isEqualTo(nominalGrossVehicleMass);
    }

    // @Test
    public void nominalDestinationReference() {
        // Add another reference in order to create the References object
        nominalCalculation.addCyclesReference(Arrays.asList(nominalCycleDetails));

        Throwable noDestinationReference = catchThrowable(() -> nominalCalculation.getReferences().getDestination());
        assertThat(noDestinationReference).as("Get destination reference when there is none").isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("The destination reference is not available, call Calculation.addDestinationReference()");

        nominalCalculation.addDestinationReference(nominalDestinationDetails);

        assertThat(nominalCalculation.getReferences().getDestination()).isEqualTo(nominalDestinationDetails);

    }

    // @Test
    public void createReferencesWhenAddingCycleReference() {
        nominalCalculation.addCyclesReference(Arrays.asList(nominalCycleDetails));

        assertThat(nominalCalculation.getReferences()).isNotNull();
    }

    // @Test
    public void createReferencesWhenAddingPayloadPercentageReference() {
        nominalCalculation.addPayloadPercentageReference(nominalPayloadPercentage);

        assertThat(nominalCalculation.getReferences()).isNotNull();
    }

    // @Test
    public void createReferencesWhenAddingGrossVehicleMassReference() {
        nominalCalculation.addGrossVehicleMassReference(nominalGrossVehicleMass);

        assertThat(nominalCalculation.getReferences()).isNotNull();
    }

    // @Test
    public void createReferencesWhenAddingDestinationReference() {
        nominalCalculation.addDestinationReference(nominalDestinationDetails);

        assertThat(nominalCalculation.getReferences()).isNotNull();
    }
}
