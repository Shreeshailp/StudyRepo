/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;

import com.inetpsa.w7t.domains.references.model.MeasureType;

public class TestCalculatedData {

    CalculatedData nominalCalculatedData;
    List<EnginePhysicalQuantity> nominalRoadLoad;
    List<CalculatedPhase> nominalCalculatedPhases;

    @Before
    public void setUp() {
        nominalCalculatedData = new CalculatedData();
        nominalRoadLoad = Arrays.asList(new EnginePhysicalQuantity("F0", 102.55), new EnginePhysicalQuantity("F1", 112.55),
                new EnginePhysicalQuantity("F2", 122.55));

        CalculatedPhase phase = new CalculatedPhase("LOW", UUID.randomUUID());
        phase.energyValue(123456789);
        MeasureType mt = new MeasureType();
        mt.setCode("FC");
        mt.setRoundingDigits(1);
        phase.addEmission(mt, 1232.4);
        mt.setCode("EC");
        mt.setRoundingDigits(0);
        phase.addEmission(mt, 1232.0);

        nominalCalculatedPhases = Arrays.asList(phase);
    }

    @Test
    public void nominalCalculatedData() {
        assertThat(nominalCalculatedData.getTestMass()).as("Empty test mass").isEmpty();
        // assertThat(nominalCalculatedData.getCrrEfficiency()).as("Empty test mass").isEmpty();
        assertThat(nominalCalculatedData.getRoadLoad()).as("Empty road load").isEmpty();
        assertThat(nominalCalculatedData.getCalculatedPhases()).as("Empty calculated phases").isEmpty();

        // nominalCalculatedData.setTestMass(1543).setCrrEfficiency("B").setRoadLoad(nominalRoadLoad).setCalculatedPhases(nominalCalculatedPhases);

        assertThat(nominalCalculatedData.getTestMass()).as("Test mass").isPresent().contains(1543);
        // assertThat(nominalCalculatedData.getCrrEfficiency()).as("CRR Efficiency class").isPresent().contains("B");
        assertThat(nominalCalculatedData.getRoadLoad()).as("Road load").isPresent().contains(nominalRoadLoad);
        assertThat(nominalCalculatedData.getCalculatedPhases()).as("Calculated phases").isPresent().contains(nominalCalculatedPhases);
    }

    @Test
    public void setTestMassTwice() {
        String errorMessage = "The test mass can only be set once";

        nominalCalculatedData.setTestMass(134);

        Throwable twice = catchThrowable(() -> nominalCalculatedData.setTestMass(1345));

        // assertThat(twice).as("Set test mass twice").isInstanceOf(UnsupportedOperationException.class).hasMessageContaining(errorMessage);
    }

    @Test
    public void setCrrEfficiencyTwice() {
        String errorMessage = "The CRR energy efficiency class has to be set only once";

        // nominalCalculatedData.setCrrEfficiency("C");

        // Throwable twice = catchThrowable(() -> nominalCalculatedData.setCrrEfficiency("E"));

        // assertThat(twice).as("Set CRR Efficiency twice").isInstanceOf(UnsupportedOperationException.class).hasMessageContaining(errorMessage);
    }

    @Test
    public void setRoadLoadTwice() {
        String errorMessage = "The road load can only be set once";

        nominalCalculatedData.setRoadLoad(nominalRoadLoad);

        Throwable twice = catchThrowable(() -> nominalCalculatedData.setRoadLoad(nominalRoadLoad));

        assertThat(twice).as("Set road load twice").isInstanceOf(UnsupportedOperationException.class).hasMessageContaining(errorMessage);
    }

    @Test
    public void setCalculatedPhasesTwice() {
        String errorMessage = "The calculated phases can only be set once";

        nominalCalculatedData.setCalculatedPhases(nominalCalculatedPhases);

        Throwable twice = catchThrowable(() -> nominalCalculatedData.setCalculatedPhases(nominalCalculatedPhases));

        assertThat(twice).as("Set calculated phases twice").isInstanceOf(UnsupportedOperationException.class).hasMessageContaining(errorMessage);
    }

    @Test
    public void invalidSetRoadLoad() {
        String errorMessage = "The road load must not be neither null nor empty";

        Throwable nullRoadLoad = catchThrowable(() -> nominalCalculatedData.setRoadLoad(null));
        Throwable emptyRoadLoad = catchThrowable(() -> nominalCalculatedData.setRoadLoad(Collections.emptyList()));

        // assertThat(nullRoadLoad).as("Set null road load").isInstanceOf(ConstraintViolationException.class).hasMessageContaining(errorMessage);
        // assertThat(emptyRoadLoad).as("Set empty road load").isInstanceOf(ConstraintViolationException.class).hasMessageContaining(errorMessage);
    }

    @Test
    public void invalidSetCalculatedPhases() {
        String errorMessage = "The calculated phases must not be null";

        Throwable nullCalculatedPhases = catchThrowable(() -> nominalCalculatedData.setCalculatedPhases(null));
        Throwable emptyCalculatedPhases = catchThrowable(() -> nominalCalculatedData.setCalculatedPhases(Collections.emptyList()));

        // assertThat(nullCalculatedPhases).as("Set null calculated phases").isInstanceOf(ConstraintViolationException.class)
        // .hasMessageContaining(errorMessage);
        assertThat(emptyCalculatedPhases).as("Set empty calculated phases").doesNotThrowAnyException();
        ;
    }
}
