/*
 * Creation : 6 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.Test;

public class TestRequestStatus {
    @Test
    public void errorStatus() {
        assertThat(RequestStatus.REQUEST_RECEIVED.isErrorStatus()).as("REQUEST_RECEIVED is an error status").isFalse();
        assertThat(RequestStatus.VALID_REQUEST.isErrorStatus()).as("VALID_REQUEST is an error status").isFalse();
        assertThat(RequestStatus.REQUEST_TO_SEND.isErrorStatus()).as("REQUEST_TO_SEND is an error status").isFalse();
        assertThat(RequestStatus.REQUEST_SENT.isErrorStatus()).as("REQUEST_SENT is an error status").isFalse();
        assertThat(RequestStatus.NEWTON_OK.isErrorStatus()).as("NEWTON_OK is an error status").isFalse();
        assertThat(RequestStatus.REQUEST_REJECTED.isErrorStatus()).as("REQUEST_REJECTED is an error status").isTrue();
        assertThat(RequestStatus.NEWTON_KO.isErrorStatus()).as("NEWTON_KO is an error status").isTrue();
        assertThat(RequestStatus.CALCULATION_KO.isErrorStatus()).as("CALCULATION_KO is an error status").isTrue();
        assertThat(RequestStatus.CALCULATION_OK.isErrorStatus()).as("CALCULATION_OK is an error status").isFalse();
        assertThat(RequestStatus.ANSWER_SENT.isErrorStatus()).as("ANSWER_SENT is an error status").isFalse();
    }

    @Test
    public void successStatus() {
        assertThat(RequestStatus.REQUEST_RECEIVED.isSuccessStatus()).as("REQUEST_RECEIVED is a success status").isFalse();
        assertThat(RequestStatus.VALID_REQUEST.isSuccessStatus()).as("VALID_REQUEST is a success status").isFalse();
        assertThat(RequestStatus.REQUEST_TO_SEND.isSuccessStatus()).as("REQUEST_TO_SEND is a success status").isFalse();
        assertThat(RequestStatus.REQUEST_SENT.isSuccessStatus()).as("REQUEST_SENT is a success status").isFalse();
        assertThat(RequestStatus.NEWTON_OK.isSuccessStatus()).as("NEWTON_OK is a success status").isFalse();
        assertThat(RequestStatus.REQUEST_REJECTED.isSuccessStatus()).as("REQUEST_REJECTED is a success status").isFalse();
        assertThat(RequestStatus.NEWTON_KO.isSuccessStatus()).as("NEWTON_KO is a success status").isFalse();
        assertThat(RequestStatus.CALCULATION_KO.isSuccessStatus()).as("CALCULATION_KO is a success status").isFalse();
        assertThat(RequestStatus.CALCULATION_OK.isSuccessStatus()).as("CALCULATION_OK is a success status").isTrue();
        assertThat(RequestStatus.ANSWER_SENT.isSuccessStatus()).as("ANSWER_SENT is a success status").isFalse();
    }

    @Test
    public void completedStatus() {
        assertThat(RequestStatus.REQUEST_RECEIVED.isCompletedStatus()).as("REQUEST_RECEIVED is a completed status").isFalse();
        assertThat(RequestStatus.VALID_REQUEST.isCompletedStatus()).as("VALID_REQUEST is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_TO_SEND.isCompletedStatus()).as("REQUEST_TO_SEND is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_SENT.isCompletedStatus()).as("REQUEST_SENT is a completed status").isFalse();
        assertThat(RequestStatus.NEWTON_OK.isCompletedStatus()).as("NEWTON_OK is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_REJECTED.isCompletedStatus()).as("REQUEST_REJECTED is a completed status").isTrue();
        assertThat(RequestStatus.NEWTON_KO.isCompletedStatus()).as("NEWTON_KO is a completed status").isTrue();
        assertThat(RequestStatus.CALCULATION_KO.isCompletedStatus()).as("CALCULATION_KO is a completed status").isTrue();
        assertThat(RequestStatus.CALCULATION_OK.isCompletedStatus()).as("CALCULATION_OK is a completed status").isTrue();
        assertThat(RequestStatus.ANSWER_SENT.isCompletedStatus()).as("ANSWER_SENT is a completed status").isFalse();
    }

    @Test
    public void finalStatus() {
        assertThat(RequestStatus.REQUEST_RECEIVED.isFinalStatus()).as("REQUEST_RECEIVED is a completed status").isFalse();
        assertThat(RequestStatus.VALID_REQUEST.isFinalStatus()).as("VALID_REQUEST is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_TO_SEND.isFinalStatus()).as("REQUEST_TO_SEND is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_SENT.isFinalStatus()).as("REQUEST_SENT is a completed status").isFalse();
        assertThat(RequestStatus.NEWTON_OK.isFinalStatus()).as("NEWTON_OK is a completed status").isFalse();
        assertThat(RequestStatus.REQUEST_REJECTED.isFinalStatus()).as("REQUEST_REJECTED is a completed status").isFalse();
        assertThat(RequestStatus.NEWTON_KO.isFinalStatus()).as("NEWTON_KO is a completed status").isFalse();
        assertThat(RequestStatus.CALCULATION_KO.isFinalStatus()).as("CALCULATION_KO is a completed status").isFalse();
        assertThat(RequestStatus.CALCULATION_OK.isFinalStatus()).as("CALCULATION_OK is a completed status").isFalse();
        assertThat(RequestStatus.ANSWER_SENT.isFinalStatus()).as("ANSWER_SENT is a completed status").isTrue();
    }

    @Test
    public void statusCode() {
        assertThat(RequestStatus.REQUEST_RECEIVED.getStatusCode()).as("REQUEST_RECEIVED's status code").isEqualTo(10);
        assertThat(RequestStatus.VALID_REQUEST.getStatusCode()).as("VALID_REQUEST's status code").isEqualTo(20);
        assertThat(RequestStatus.REQUEST_TO_SEND.getStatusCode()).as("REQUEST_TO_SEND's status code").isEqualTo(30);
        assertThat(RequestStatus.REQUEST_SENT.getStatusCode()).as("REQUEST_SENT's status code").isEqualTo(40);
        assertThat(RequestStatus.NEWTON_OK.getStatusCode()).as("NEWTON_OK's status code").isEqualTo(50);
        assertThat(RequestStatus.REQUEST_REJECTED.getStatusCode()).as("REQUEST_REJECTED's status code").isEqualTo(60);
        assertThat(RequestStatus.NEWTON_KO.getStatusCode()).as("NEWTON_KO's status code").isEqualTo(61);
        assertThat(RequestStatus.CALCULATION_KO.getStatusCode()).as("CALCULATION_KO's status code").isEqualTo(62);
        assertThat(RequestStatus.CALCULATION_OK.getStatusCode()).as("CALCULATION_OK's status code").isEqualTo(70);
        assertThat(RequestStatus.ANSWER_SENT.getStatusCode()).as("ANSWER_SENT's status code").isEqualTo(80);
    }

    @Test
    public void nextStatus() {
        assertThat(RequestStatus.REQUEST_RECEIVED.nextStatus()).as("REQUEST_RECEIVED next status").isEqualTo(RequestStatus.VALID_REQUEST);
        assertThat(RequestStatus.VALID_REQUEST.nextStatus()).as("VALID_REQUEST next status").isEqualTo(RequestStatus.REQUEST_TO_SEND);
        assertThat(RequestStatus.REQUEST_TO_SEND.nextStatus()).as("REQUEST_TO_SEND next status").isEqualTo(RequestStatus.REQUEST_SENT);
        assertThat(RequestStatus.REQUEST_SENT.nextStatus()).as("REQUEST_SENT next status").isEqualTo(RequestStatus.NEWTON_OK);
        assertThat(RequestStatus.NEWTON_OK.nextStatus()).as("NEWTON_OK next status").isEqualTo(RequestStatus.CALCULATION_OK);
        assertThat(RequestStatus.REQUEST_REJECTED.nextStatus()).as("REQUEST_REJECTED next status").isEqualTo(RequestStatus.ANSWER_SENT);
        assertThat(RequestStatus.NEWTON_KO.nextStatus()).as("NEWTON_KO next status").isEqualTo(RequestStatus.ANSWER_SENT);
        assertThat(RequestStatus.CALCULATION_KO.nextStatus()).as("CALCULATION_KO next status").isEqualTo(RequestStatus.ANSWER_SENT);
        assertThat(RequestStatus.CALCULATION_OK.nextStatus()).as("CALCULATION_OK next status").isEqualTo(RequestStatus.ANSWER_SENT);

        Throwable t = catchThrowable(() -> RequestStatus.ANSWER_SENT.nextStatus());

        assertThat(t).as("ANSWER_SENT next status").isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("Reached last status. Impossible to go beyond it.");
    }
}
