/*
 * Creation : 31 mai 2017
 */
package com.inetpsa.w7t.domains.engine.fixtures;

import static java.util.stream.Collectors.toList;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.seedstack.seed.it.ITBind;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.enginesettings.model.ParameterDetails;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.VehicleType;

@ITBind
public class DestinationFixture {

    @Inject
    private CountryRepository countryRepository;

    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    @Inject
    private VehicleTypeRepository vehicleTypeRepository;

    public DestinationDetails createDestination(LocalDate ecomDate, String countryCode, String countryCharacteristic, String vehicleTypeCode,
            List<String> cyclePhases) {
        UUID uuid = UUID.randomUUID();
        DestinationDetails dest = new DestinationDetails();
        dest.setFromDate(ecomDate);
        dest.setToDate(ecomDate);
        Country country = countryRepository.byCodeAndCharacteristic(countryCode, countryCharacteristic);
        Optional<Country> countries = Optional.ofNullable(country);
        if (countries.isPresent()) {
            countries.map(Country::getGuid).map(UUID::toString).map(Arrays::asList).ifPresent(dest::setCountries);
        }
        dest.setLabel(uuid.toString().substring(0, 20));
        dest.setParameterDetails(createParameterDetails(vehicleTypeCode, cyclePhases));
        dest.setGuid(uuid);

        return dest;
    }

    private List<ParameterDetails> createParameterDetails(String vehicleTypeCode, List<String> cyclePhases) {
        Optional<VehicleType> vehicleType = vehicleTypeRepository.byCode(vehicleTypeCode);
        List<UUID> measureTypes = vehicleType.map(VehicleType::getMeasureTypes).map(List::stream).orElseGet(Stream::empty).collect(toList());

        return cyclePhases.stream().map(cyclePhaseRepository::byCode).filter(Optional::isPresent).map(Optional::get).map(CyclePhase::getGuid)
                .map(cp -> {
                    return measureTypes.stream().map(mt -> {
                        ParameterDetails p = new ParameterDetails();
                        p.setConcerned(true);
                        p.setMeasureType(mt);
                        p.setCyclePhase(cp);
                        p.setVehicleType(vehicleType.map(VehicleType::getGuid).orElse(null));
                        return p;
                    }).collect(toList());
                }).map(List::stream).flatMap(Function.identity()).collect(toList());
    }
}
