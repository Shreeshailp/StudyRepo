/*
 * Creation : 30 juin 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.engine.model.request.Request;

@RunWith(SeedITRunner.class)
public class ITNewtonRepository {

    @Inject
    NewtonRepository newtonRepository;

    @Test
    public void testNewtonRepository() {
        Request request = new Request();
        request.setFileId("NRV0000008");
        request.setExtendedTitle("1CXAADCKM500A062M0CZ3LFTDAB00CDFR708E FR808E FV707E FV807E FV906E FW408E GG819A T3N01H T8CLDG T8D01G T8E01G ");
        assertThat(newtonRepository.getNewtonEntity(request)).isNotPresent();
    }
}
