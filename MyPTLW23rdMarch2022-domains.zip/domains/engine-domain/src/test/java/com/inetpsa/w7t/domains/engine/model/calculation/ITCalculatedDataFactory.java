/*
 * Creation : 29 mai 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

@RunWith(SeedITRunner.class)
public class ITCalculatedDataFactory {

    @Inject
    private CalculatedDataFactory factory;

    @Test
    public void testEmpty() {
        CalculatedData cd = factory.empty();
        assertThat(cd).as("Empty factory").isNotNull();
        assertThat(cd).as("Factored CalculatedData has a guid").hasNoNullFieldsOrPropertiesExcept("testMass", "roadLoad", "calculatedPhases");
    }

    @Test
    public void testWithTestMass() {
        CalculatedData cd = factory.withTestMass(10);
        assertThat(cd).as("Factory").isNotNull();
        assertThat(cd).as("Factored CalculatedData has a guid").hasNoNullFieldsOrPropertiesExcept("roadLoad", "calculatedPhases");
        assertThat(cd.getTestMass()).as("Factored CalculatedData has a test mass").isPresent().contains(10);
    }
}
