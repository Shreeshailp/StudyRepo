/*
 * Creation : 2 May 2018
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.ToyotaRequestBatchRepository;

public class ToyotaRequestBatchJpaRepository extends BaseJpaRepository<ToyotaRequestBatchEntity, UUID> implements ToyotaRequestBatchRepository {

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant FILE_ID. */
    private static final String FILE_ID = "fileId";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#byfileId(java.lang.String)
     */
    @Override
    public Optional<ToyotaRequestBatchEntity> byfileId(String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<ToyotaRequestBatchEntity> q = cb.createQuery(aggregateRootClass);
        Root<ToyotaRequestBatchEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FILE_ID), cb.parameter(String.class, FILE_ID)));

        TypedQuery<ToyotaRequestBatchEntity> query = entityManager.createQuery(q);
        query.setParameter(FILE_ID, fileId);
        return query.getResultList().stream().findFirst();
    }

    @Override
    public boolean exists(String fileId) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ToyotaRequestBatchEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<ToyotaRequestBatchEntity> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<ToyotaRequestBatchEntity> get(FILE_ID));
        criteriaQuery.where(criteriaBuilder.equal(root.get(FILE_ID), criteriaBuilder.parameter(String.class, FILE_ID)));

        return entityManager.createQuery(criteriaQuery).setParameter(FILE_ID, fileId).getResultList().size() == 1;
    }
}
