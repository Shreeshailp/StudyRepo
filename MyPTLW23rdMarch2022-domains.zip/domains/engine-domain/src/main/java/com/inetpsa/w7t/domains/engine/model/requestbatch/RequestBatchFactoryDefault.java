/*
 * Creation : 23 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.requestbatch;

import java.time.LocalDateTime;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;
import org.seedstack.business.domain.Create;

import com.google.inject.Injector;

/**
 * The Class RequestBatchFactoryDefault.
 */
public class RequestBatchFactoryDefault extends BaseFactory<RequestBatch> implements RequestBatchFactory {

    /** The injector. */
    @Inject
    private Injector injector;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatchFactory#createRequestBatch(java.lang.String, java.lang.String,
     *      java.time.LocalDateTime)
     */
    @Create
    @Override
    public RequestBatch createRequestBatch(String fileId, String client, LocalDateTime requestDate) {
        RequestBatch requestBatch = new RequestBatch(fileId, client, requestDate);
        injector.injectMembers(requestBatch);
        return requestBatch;
    }

}
