/*
 * Creation : 7 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.seedstack.business.domain.BaseValueObject;
import org.seedstack.business.domain.Entity;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CalculatedData extends BaseValueObject implements Entity<UUID> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5182177887163895846L;

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(CalculatedData.class);

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    private UUID guid;

    /** The test mass. */
    @NotNull
    private Integer testMass;

    // /** The crr energy efficiency class. */
    // @NotNull
    // private String crrEfficiency;

    /** The road load type(IRL,DRL,MRL). */
    @NotNull
    private String roadLoadType;

    /** The road load. */
    @NotNull
    private List<EnginePhysicalQuantity> roadLoad;

    /** The calculated phases. */
    @NotNull
    private List<CalculatedPhase> calculatedPhases;

    /** The speed limit flag. */
    private String speedLimitFlag = "";

    /** The v max. */
    private String vMax = "";

    /** The down scale. */
    private Double fDownScale;

    /**
     * Instantiates a new calculated data.
     */
    CalculatedData() { // NOSONAR This constructor is available to create the
                       // instance itself

    }

    /**
     * Sets the test mass.
     *
     * @param testMass the test mass
     * @return the calculated data
     */
    public CalculatedData setTestMass(int testMass) {
        this.testMass = testMass;
        return this;
    }

    /**
     * Sets the road load.
     *
     * @param roadLoad the road load
     * @return the calculated data
     */
    public CalculatedData setRoadLoad(
            @NotEmpty(message = "The road load must not be neither null nor empty") @Valid List<EnginePhysicalQuantity> roadLoad) {
        // this.validateParameters(new Class<?>[] { List.class }, roadLoad);
        if (this.roadLoad != null)
            throw new UnsupportedOperationException("The road load can only be set once");
        this.roadLoad = roadLoad;
        return this;
    }

    /**
     * Sets the calculated phases.
     *
     * @param calculatedPhases the calculated phases
     * @return the calculated data
     */
    public CalculatedData setCalculatedPhases(
            @NotNull(message = "The calculated phases must not be null") @Valid List<CalculatedPhase> calculatedPhases) {
        // this.validateParameters(new Class<?>[] { List.class },
        // calculatedPhases);
        if (this.calculatedPhases != null)
            throw new UnsupportedOperationException("The calculated phases can only be set once");
        this.calculatedPhases = calculatedPhases;
        return this;
    }

    // /**
    // * Sets the crr efficiency.
    // *
    // * @param crrEfficiency the crr efficiency
    // * @return the calculated data
    // */
    // public CalculatedData setCrrEfficiency(
    // @NotEmpty(message = "The CRR energy efficiency class must not be null or empty") @Valid String crrEfficiency) {
    // if (this.crrEfficiency != null)
    // throw new UnsupportedOperationException("The CRR energy efficiency class has to be set only once");
    // this.crrEfficiency = crrEfficiency;
    // return this;
    // }

    /**
     * Gets the road load type.
     *
     * @return the road load type
     */
    public Optional<String> getRoadLoadType() {
        return Optional.ofNullable(roadLoadType);
    }

    /**
     * Sets the road load type.
     *
     * @param roadLoadType the road load type
     * @return the calculated data
     */
    public CalculatedData setRoadLoadType(String roadLoadType) {
        this.roadLoadType = roadLoadType;
        return this;
    }

    /**
     * Gets the test mass.
     *
     * @return the test mass
     */
    public Optional<Integer> getTestMass() {
        return Optional.ofNullable(testMass);
    }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    public Optional<List<EnginePhysicalQuantity>> getRoadLoad() {
        if (roadLoad == null)
            return Optional.empty();
        return Optional.ofNullable(Collections.unmodifiableList(roadLoad));
    }

    /**
     * Gets the calculated phases.
     *
     * @return the calculated phases
     */
    public Optional<List<CalculatedPhase>> getCalculatedPhases() {
        if (calculatedPhases == null)
            return Optional.empty();
        return Optional.ofNullable(Collections.unmodifiableList(calculatedPhases));
    }

    /**
     * Gets the crr efficiency.
     *
     * @return the crr efficiency
     */
    // public Optional<String> getCrrEfficiency() {
    // return Optional.ofNullable(crrEfficiency);
    // }

    /**
     * Validate parameters.
     *
     * @param parameterTypes the parameter types
     * @param parameterValues the parameter values
     */
    private void validateParameters(Class<?>[] parameterTypes, Object... parameterValues) {
        try {
            Set<ConstraintViolation<CalculatedData>> violations = Validation.buildDefaultValidatorFactory().getValidator().forExecutables()
                    .validateParameters(this,
                            CalculatedData.class.getMethod(Thread.currentThread().getStackTrace()[2].getMethodName(), parameterTypes),
                            parameterValues);
            if (!violations.isEmpty())
                throw new ConstraintViolationException(
                        violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList()).toString(), violations);
        } catch (NoSuchMethodException | SecurityException e) {
            logger.error("The class was not able to get the following method for some reasons", e);
        }
    }

    // /**
    // * {@inheritDoc}
    // *
    // * @see java.lang.Object#hashCode()
    // */
    // @Override
    // public int hashCode() {
    // final int prime = 31;
    // int result = super.hashCode();
    // result = prime * result + Objects.hashCode(calculatedPhases);
    // result = prime * result + Objects.hashCode(roadLoad);
    // result = prime * result + Objects.hashCode(testMass);
    // result = prime * result + Objects.hashCode(crrEfficiency);
    // return result;
    // }
    //
    // /**
    // * {@inheritDoc}
    // *
    // * @see java.lang.Object#equals(java.lang.Object)
    // */
    // @Override
    // public boolean equals(Object o) {
    // if (this == o)
    // return true;
    // if (o == null || getClass() != o.getClass())
    // return false;
    //
    // CalculatedData other = (CalculatedData) o;
    // return Objects.equals(testMass, other.testMass) && Objects.equals(roadLoad, other.roadLoad)
    // && Objects.equals(calculatedPhases, other.calculatedPhases) && Objects.equals(crrEfficiency, other.crrEfficiency);
    // }

    /*
     * @Override public String toString() { return "CalculatedData [guid=" + guid + ", testMass=" + testMass + ", roadLoad=" + roadLoad +
     * ", calculatedPhases=" + calculatedPhases + ", crrEfficiency=" + crrEfficiency + "]"; }
     */

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.Entity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((calculatedPhases == null) ? 0 : calculatedPhases.hashCode());
        // result = prime * result + ((crrEfficiency == null) ? 0 : crrEfficiency.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((roadLoad == null) ? 0 : roadLoad.hashCode());
        result = prime * result + ((roadLoadType == null) ? 0 : roadLoadType.hashCode());
        result = prime * result + ((testMass == null) ? 0 : testMass.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        CalculatedData other = (CalculatedData) obj;
        if (calculatedPhases == null) {
            if (other.calculatedPhases != null)
                return false;
        } else if (!calculatedPhases.equals(other.calculatedPhases))
            return false;
        // if (crrEfficiency == null) {
        // if (other.crrEfficiency != null)
        // return false;
        // } else if (!crrEfficiency.equals(other.crrEfficiency))
        // return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (roadLoad == null) {
            if (other.roadLoad != null)
                return false;
        } else if (!roadLoad.equals(other.roadLoad))
            return false;
        if (roadLoadType == null) {
            if (other.roadLoadType != null)
                return false;
        } else if (!roadLoadType.equals(other.roadLoadType))
            return false;
        if (testMass == null) {
            if (other.testMass != null)
                return false;
        } else if (!testMass.equals(other.testMass))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */
    @Override
    public String toString() {
        // return "CalculatedData [guid=" + guid + ", testMass=" + testMass + ", crrEfficiency=" + crrEfficiency + ", roadLoadType=" + roadLoadType
        // + ", roadLoad=" + roadLoad + ", calculatedPhases=" + calculatedPhases + "]";
        return "CalculatedData [guid=" + guid + ", testMass=" + testMass + ", roadLoadType=" + roadLoadType + ", roadLoad=" + roadLoad
                + ", calculatedPhases=" + calculatedPhases + "]";
    }

    /**
     * Gets the speed limit flag.
     *
     * @return the speed limit flag
     */
    public String getSpeedLimitFlag() {
        return speedLimitFlag;
    }

    /**
     * Sets the speed limit flag.
     *
     * @param speedLimitFlag the new speed limit flag
     */
    public void setSpeedLimitFlag(String speedLimitFlag) {
        this.speedLimitFlag = speedLimitFlag;
    }

    /**
     * Gets the v max.
     *
     * @return the v max
     */
    public String getvMax() {
        return vMax;
    }

    /**
     * Sets the v max.
     *
     * @param vMax the new v max
     */
    public void setvMax(String vMax) {
        this.vMax = vMax;
    }

    /**
     * Gets the f down scale.
     *
     * @return the f down scale
     */
    public Double getfDownScale() {
        return fDownScale;
    }

    /**
     * Sets the f down scale.
     *
     * @param fDownScale the new f down scale
     */
    public void setfDownScale(Double fDownScale) {
        this.fDownScale = fDownScale;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */

}