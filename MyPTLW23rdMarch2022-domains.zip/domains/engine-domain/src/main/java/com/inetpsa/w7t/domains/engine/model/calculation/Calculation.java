/*
 * Creation : 28 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.seedstack.business.Producible;
import org.seedstack.business.domain.DomainObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;
import com.inetpsa.w7t.domains.references.model.PayloadPercentage;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

/**
 * The Class Calculation.
 */
public class Calculation implements DomainObject, Producible {

    /** The Constant logger. */
    private static final Logger logger = LoggerFactory.getLogger(Calculation.class);

    /** The version. */
    @NotNull(message = "The version must not be null")
    private Version version;

    /** The family. */
    private FamilyDetails family;

    /** The references. */
    private References references;

    /** The calculated data. */
    private CalculatedData calculatedData;

    /** The physical quantities. */
    private List<EnginePhysicalQuantity> physicalQuantities;

    /** The tvvDetails. */
    private TVV tvvDetails;

    /** The m tac. */
    private String mTac = "";

    /** The empty mass. */
    private String emptyMass = "";

    /** The m OPT. */
    private String mOPT = "";

    /** The depol. */
    private String depol = "";

    /**
     * Gets the depol.
     *
     * @return the depol
     */
    public String getDepol() {
        return depol;
    }

    /**
     * Sets the depol.
     *
     * @param depol the new depol
     */
    public void setDepol(String depol) {
        this.depol = depol;
    }

    /**
     * Gets the m tac.
     *
     * @return the m tac
     */
    public String getmTac() {
        return mTac;
    }

    /**
     * Sets the m tac.
     *
     * @param mTac the new m tac
     */
    public void setmTac(String mTac) {
        this.mTac = mTac;
    }

    /**
     * Gets the empty mass.
     *
     * @return the empty mass
     */
    public String getEmptyMass() {
        return emptyMass;
    }

    /**
     * Sets the empty mass.
     *
     * @param emptyMass the new empty mass
     */
    public void setEmptyMass(String emptyMass) {
        this.emptyMass = emptyMass;
    }

    /**
     * Gets the m OPT.
     *
     * @return the m OPT
     */
    public String getmOPT() {
        return mOPT;
    }

    /**
     * Sets the m OPT.
     *
     * @param mOPT the new m OPT
     */
    public void setmOPT(String mOPT) {
        this.mOPT = mOPT;
    }

    /**
     * Instantiates a new calculation.
     *
     * @param version the version
     */
    @Valid
    Calculation(Version version) {
        this.version = version;
        this.validate();
    }

    /**
     * Sets the family.
     *
     * @param family the new family
     */
    public void setFamily(@NotNull(message = "The family must not be null") @Valid FamilyDetails family) {
        // this.validateParameters(new Class<?>[] { FamilyDetails.class }, family);
        if (this.family == null) {
            this.family = family;
        } else {
            throw new UnsupportedOperationException("The family can only be set once");
        }
    }

    /**
     * Sets the tvv details.
     *
     * @param tvvDetails the new tvv details
     */
    public void setTvvDetails(@Valid TVV tvvDetails) {
        if (this.tvvDetails == null) {
            this.tvvDetails = tvvDetails;
        } else {
            throw new UnsupportedOperationException("The tvv can only be set once");
        }
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */

    public TVV getTvvDetails() {
        if (tvvDetails == null)
            throw new UnsupportedOperationException("The tvv is not available, call Calculation.setTvvDetails()");
        return tvvDetails;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public Version getVersion() {
        return version;
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public FamilyDetails getFamily() {
        if (family == null)
            throw new UnsupportedOperationException("The family is not available, call Calculation.setFamily()");
        return family;
    }

    /**
     * Gets the references.
     *
     * @return the references
     */
    public References getReferences() {
        if (references == null)
            throw new UnsupportedOperationException("The references are not available, call Calculation.add*Reference()");
        return references;
    }

    /**
     * Gets the calculated data.
     *
     * @return the calculated data
     */
    public CalculatedData getCalculatedData() {
        if (calculatedData == null)
            throw new UnsupportedOperationException("The calculated data is not available, call Calculation.setCalculatedData()");
        return calculatedData;
    }

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<EnginePhysicalQuantity> getPhysicalQuantities() {
        if (physicalQuantities == null)
            throw new UnsupportedOperationException("The physical quantities are not available, call Calculation.setPhysicalQuantities()");
        return physicalQuantities;
    }

    /**
     * Sets the calculated data.
     *
     * @param calculatedData the calculated data
     * @return the calculation
     */
    public Calculation setCalculatedData(@NotNull(message = "The calculated data must not be null") CalculatedData calculatedData) {
        // this.validateParameters(new Class<?>[] { CalculatedData.class }, calculatedData);
        this.calculatedData = calculatedData;
        return this;
    }

    /**
     * Sets the physical quantities.
     *
     * @param physicalQuantities the physical quantities
     * @return the calculation
     */
    public Calculation setPhysicalQuantities(
            @NotEmpty(message = "The physical quantities must not be neither null nor empty") List<EnginePhysicalQuantity> physicalQuantities) {
        // this.validateParameters(new Class<?>[] { List.class }, physicalQuantities);
        this.physicalQuantities = physicalQuantities;
        return this;
    }

    /**
     * Adds the cycles reference.
     *
     * @param cycles the cycles
     * @return the calculation
     */
    public Calculation addCyclesReference(@NotEmpty(message = "The cycles must not be null") @Valid List<CycleDetails> cycles) {
        // this.validateParameters(new Class<?>[] { List.class }, cycles);
        if (references == null)
            references = new References();
        references.cycles = cycles;
        return this;
    }

    /**
     * Adds the generated cycles reference.
     *
     * @param generatedCycles the generated cycles
     * @return the calculation
     */
    public Calculation addGeneratedCyclesReference(
            @NotEmpty(message = "The generated cycles must not be null") @Valid List<GeneratedCycle> generatedCycles) {
        references.generatedCycles = generatedCycles;
        return this;
    }

    /**
     * Adds the payload percentage reference.
     *
     * @param payloadPercentage the payload percentage
     * @return the calculation
     */
    public Calculation addPayloadPercentageReference(
            @NotNull(message = "The payload percentage must not be null") @Valid PayloadPercentage payloadPercentage) {
        // this.validateParameters(new Class<?>[] { PayloadPercentage.class }, payloadPercentage);
        if (references == null)
            references = new References();
        references.payloadPercentage = payloadPercentage;
        return this;
    }

    /**
     * Adds the gross vehicle mass reference.
     *
     * @param grossVehicleMass the gross vehicle mass
     * @return the calculation
     */
    public Calculation addGrossVehicleMassReference(
            @NotNull(message = "The gross vehicle mass must not be null") @Valid GrossVehicleMass grossVehicleMass) {
        // this.validateParameters(new Class<?>[] { GrossVehicleMass.class }, grossVehicleMass);
        if (references == null)
            references = new References();
        references.grossVehicleMass = grossVehicleMass;
        return this;
    }

    /**
     * Adds the destination reference.
     *
     * @param destinationDetails the destination details
     * @return the calculation
     */
    public Calculation addDestinationReference(@NotNull(message = "The destination must not be null") @Valid DestinationDetails destinationDetails) {
        // this.validateParameters(new Class<?>[] { DestinationDetails.class }, destinationDetails);
        if (references == null)
            references = new References();
        references.destination = destinationDetails;
        return this;
    }

    /**
     * The Class References.
     */
    public class References {

        /** The cycles. */
        private List<CycleDetails> cycles;

        /** The payload percentage. */
        private PayloadPercentage payloadPercentage;

        /** The gross vehicle mass. */
        private GrossVehicleMass grossVehicleMass;

        /** The destination. */
        private DestinationDetails destination;

        /** The Generated cycles. */
        private List<GeneratedCycle> generatedCycles;

        /**
         * Gets the cycles.
         *
         * @return the cycles
         */
        public List<CycleDetails> getCycles() {
            if (cycles == null)
                throw new UnsupportedOperationException("The cycles reference is not available, call Calculation.addCyclesReference()");
            return cycles;
        }

        /**
         * Gets the Generated cycles.
         *
         * @return the Generated cycles
         */
        public List<GeneratedCycle> getGeneratedCycles() {
            if (generatedCycles == null)
                throw new UnsupportedOperationException(
                        "The Generated cycles reference is not available, call Calculation.addGeneratedCyclesReference()");
            return generatedCycles;
        }

        /**
         * Gets the payload percentage.
         *
         * @return the payload percentage
         */
        public PayloadPercentage getPayloadPercentage() {
            if (payloadPercentage == null)
                throw new UnsupportedOperationException(
                        "The payload percentage reference is not available, call Calculation.addPayloadPercentageReference()");
            return payloadPercentage;
        }

        /**
         * Gets the gross vehicle mass.
         *
         * @return the gross vehicle mass
         */
        public GrossVehicleMass getGrossVehicleMass() {
            if (grossVehicleMass == null)
                throw new UnsupportedOperationException(
                        "The gross vehicle mass reference is not available, call Calculation.addGrossVehicleMassReference()");
            return grossVehicleMass;
        }

        /**
         * Gets the destination.
         *
         * @return the destination
         */
        public DestinationDetails getDestination() {
            if (destination == null)
                throw new UnsupportedOperationException("The destination reference is not available, call Calculation.addDestinationReference()");
            return destination;
        }
    }

    /**
     * Validate.
     */
    private void validate() {
        Set<ConstraintViolation<Calculation>> violations = Validation.buildDefaultValidatorFactory().getValidator().validate(this);
        if (!violations.isEmpty())
            throw new ConstraintViolationException(violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList()).toString(),
                    violations);
    }

    /**
     * Validate parameters.
     *
     * @param parametersTypes the parameters types
     * @param parametersValues the parameters values
     */
    private void validateParameters(Class<?>[] parametersTypes, Object... parametersValues) {
        try {
            Set<ConstraintViolation<Calculation>> violations = Validation.buildDefaultValidatorFactory().getValidator().forExecutables()
                    .validateParameters(this, Calculation.class.getMethod(Thread.currentThread().getStackTrace()[2].getMethodName(), parametersTypes),
                            parametersValues);
            if (!violations.isEmpty())
                throw new ConstraintViolationException(
                        violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList()).toString(), violations);
        } catch (NoSuchMethodException | SecurityException e) {
            logger.error("The class was not able to get the following method for some reasons", e);
        }
    }
}
