/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.stat.SessionStatistics;
import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.domain.identity.IdentityService;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.infrastructure.WltpModelMapper;

/**
 * The Class RequestJpaRepository.
 */
public class RequestJpaRepository extends BaseJpaRepository<RequestEntity, UUID> implements RequestRepository {

    /** The Constant FILE_ID. */
    private static final String FILE_ID = "fileId";

    /** The Constant REQUEST_ID. */
    private static final String REQUEST_ID = "requestId";

    /** The Constant REQ_BATCH_ID. */
    private static final String REQ_BATCH_ID = "requestBatchId";

    /** The Constant REQUEST_STATUS. */
    private static final String REQUEST_STATUS = "status";

    @Logging
    private Logger logger;

    /** The fluent assembler. */
    @Inject
    private FluentAssembler fluentAssembler;

    /** The identity service. */
    @Inject
    private IdentityService identityService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#save(com.inetpsa.w7t.domains.engine.model.request.Request)
     */
    @Override
    public Request save(Request request) {

        RequestEntity reqEntity = null;

        // TODO try 17.4 seed fromREpo or fromFact
        if (request.getGuid() != null) {
            try {
                reqEntity = fluentAssembler.merge(request).with(WltpModelMapper.class).into(RequestEntity.class).fromRepository().orFail();
                // reqEntity = mapRequestToRequestEntity(request);
            } catch (Exception e) {
                logger.error("Error while saving Request", e);
            }
        } else {
            reqEntity = fluentAssembler.merge(request).with(WltpModelMapper.class).into(RequestEntity.class).fromFactory();
            // reqEntity = mapRequestToRequestEntity(request);
            identityService.identify(reqEntity);
        }

        // In order to correctly save the entities in the database and since we diverged from standard SeedStack, we need to persist the
        // CalculatedDataEntity and CalculatedPhaseEntity before saving the RequestEntity.
        if (Objects.nonNull(reqEntity)) {
            saveCalculatedData(reqEntity.getCalculatedValues());

            if (exists(reqEntity.getEntityId()))
                save(reqEntity);
            else
                persist(reqEntity);
        }

        return fluentAssembler.assemble(reqEntity).with(WltpModelMapper.class).to(Request.class);
    }

    /**
     * Save the {@link CalculatedDataEntity} and the {@link CalculatedPhaseEntity}s of the {@link RequestEntity} if they do not exist in the database.
     *
     * @param calculatedDataEntity the calculated data entity
     */
    private void saveCalculatedData(CalculatedDataEntity calculatedDataEntity) {
        if (Objects.isNull(calculatedDataEntity))
            return;

        if (Objects.isNull(entityManager.find(CalculatedDataEntity.class, calculatedDataEntity.getGuid())))
            entityManager.persist(calculatedDataEntity);

        calculatedDataEntity.getCalculatedPhases().stream()
                .filter(cp -> Objects.isNull(entityManager.find(CalculatedPhaseEntity.class, cp.getGuid()))).forEach(entityManager::persist);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#steps(int)
     */
    @Override
    public Optional<List<Request>> steps(int limit) {
        logger.debug("Fetch list of requests limited to {} requests", limit);
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestEntity> r = q.from(RequestEntity.class);

        q.where(cb.notEqual(r.get(REQUEST_STATUS), RequestStatus.ANSWER_SENT));
        q.orderBy(cb.asc(r.get(REQUEST_STATUS)));

        List<RequestEntity> requests = entityManager.createQuery(q).setMaxResults(limit).getResultList();

        if (requests.isEmpty())
            return Optional.empty();
        logger.debug("Fetched list of requests, assembling");

        return Optional.of(fluentAssembler.assemble(requests).with(WltpModelMapper.class).to(Request.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#requestExists(java.lang.String)
     */
    @Override
    public boolean requestExists(String requestNumber) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<RequestEntity> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<RequestEntity>get(REQUEST_ID));
        criteriaQuery.where(criteriaBuilder.equal(root.get(REQUEST_ID), criteriaBuilder.parameter(String.class, REQUEST_ID)));

        return entityManager.createQuery(criteriaQuery).setParameter(REQUEST_ID, requestNumber).getResultList().size() == 1;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#fileIdExists(java.lang.String)
     */
    @Override
    public boolean fileIdExists(String fileId) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<RequestEntity> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<RequestEntity>get(FILE_ID));
        criteriaQuery.where(criteriaBuilder.equal(root.get(FILE_ID), criteriaBuilder.parameter(String.class, FILE_ID)));

        return entityManager.createQuery(criteriaQuery).setParameter(FILE_ID, fileId).getResultList().size() == 1;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#byRequestNumber(java.lang.String)
     */
    @Override
    public Optional<RequestEntity> byRequestNumber(String number) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQUEST_ID), cb.parameter(String.class, REQUEST_ID)));

        TypedQuery<RequestEntity> query = entityManager.createQuery(q);
        query.setParameter(REQUEST_ID, number);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#byRequestBatchId(java.util.UUID, java.util.List)
     */
    @Override
    public Optional<List<Request>> byRequestBatchId(UUID batchId, List<RequestStatus> filteredStatuses) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQ_BATCH_ID), cb.parameter(UUID.class, REQ_BATCH_ID)), root.get(REQUEST_STATUS).in(filteredStatuses));

        TypedQuery<RequestEntity> query = entityManager.createQuery(q);
        query.setParameter(REQ_BATCH_ID, batchId);

        List<RequestEntity> requests = query.getResultList();

        if (requests.isEmpty())
            return Optional.empty();
        List<Request> requestsDtos = fluentAssembler.assemble(requests).with(WltpModelMapper.class).to(Request.class);
        return Optional.of(requestsDtos);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#byRequestId(java.lang.String)
     */
    @Override
    public Request byRequestId(String reqId) {

        Request requestsDto = null;
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQUEST_ID), cb.parameter(String.class, REQUEST_ID)));

        TypedQuery<RequestEntity> query = entityManager.createQuery(q);
        query.setParameter(REQUEST_ID, reqId);

        RequestEntity requestEnt = null;
        if (query.getResultList() != null && !query.getResultList().isEmpty()) {
            requestEnt = query.getResultList().get(0);
        }

        if (requestEnt != null) {
            requestsDto = fluentAssembler.assemble(requestEnt).with(WltpModelMapper.class).to(Request.class);
        }
        return requestsDto;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#byRequestBatchIds(java.util.List, java.util.List)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<Request>> byRequestBatchIds(List<UUID> requestBatchIds, List<RequestStatus> filteredStatuses) {
        String requestBatchQuery = "select * from W7TQTREQ WHERE BATCH_ID IN (:requestBatchIds) and STATUS IN (:filteredStatuses)";
        Query query = entityManager.createNativeQuery(requestBatchQuery);
        query.setParameter("requestBatchIds", requestBatchIds);
        query.setParameter("filteredStatuses", filteredStatuses);
        if (query.getResultList().isEmpty()) {
            return Optional.empty();
        }
        logger.debug("Fetched list of TimeOutRequestBatches");

        return Optional.of(fluentAssembler.assemble(query.getResultList()).with(WltpModelMapper.class).to(Request.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#getSteps(int, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<Request>> getSteps(int stepCount, String reqMacName) {

        logger.debug("Fetch list of requests limited to {} requests", stepCount);

        String requestBatchQuery = "SELECT * FROM W7TQTREQ req WHERE req.STATUS != ? AND req.BATCH_ID IN (SELECT rqb.ID FROM W7TQTRQB rqb WHERE req.BATCH_ID = rqb.ID AND rqb.MANUAL = ?) AND req.CREATED_DATE LIKE ? ORDER BY req.STATUS LIMIT ?";
        Query query = entityManager.createNativeQuery(requestBatchQuery, RequestEntity.class);
        query.setParameter(1, RequestStatus.ANSWER_SENT.getStatusCode());
        query.setParameter(2, true);
        query.setParameter(3, "%" + LocalDate.now().toString() + "%");
        query.setParameter(4, stepCount);
        List<RequestEntity> requests = query.getResultList();
        if (requests.isEmpty()) {
            return Optional.empty();
        }
        logger.debug("Fetched list of requests, assembling");

        return Optional.of(fluentAssembler.assemble(requests).with(WltpModelMapper.class).to(Request.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#getRejectedRequests(java.lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<Request>> getRejectedRequests(String internalFileId, String newtonResMacName) {
        String rejectedRequestQuery = "SELECT * FROM W7TQTREQ req WHERE req.STATUS = ? AND req.INTERNAL_FILE_ID=? AND req.BATCH_ID IN (SELECT rqb.ID FROM W7TQTRQB rqb WHERE req.BATCH_ID = rqb.ID AND ( rqb.BCV_RES_MAC_NAME = ?)) ORDER BY req.STATUS";
        Query query = entityManager.createNativeQuery(rejectedRequestQuery, RequestEntity.class);
        query.setParameter(1, RequestStatus.REQUEST_REJECTED.getStatusCode());
        query.setParameter(2, internalFileId);
        query.setParameter(3, newtonResMacName);
        List<RequestEntity> rejectedRequestsList = query.getResultList();
        if (rejectedRequestsList.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(fluentAssembler.assemble(rejectedRequestsList).with(WltpModelMapper.class).to(Request.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#updateAnswerSentStatus(java.lang.String)
     */
    @Override
    public int updateAnswerSentStatus(String internalFileId) {
        String sqlString = "UPDATE W7TQTREQ SET STATUS=? WHERE INTERNAL_FILE_ID=? ";
        Query query = entityManager.createNativeQuery(sqlString);
        query.setParameter(1, RequestStatus.ANSWER_SENT.getStatusCode());
        query.setParameter(2, internalFileId);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#getAllRequests(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<Request>> getAllRequests(String internalFileId) {
        String listQuery = "SELECT * FROM W7TQTREQ WHERE INTERNAL_FILE_ID=?";
        Query query = entityManager.createNativeQuery(listQuery, RequestEntity.class);
        query.setParameter(1, internalFileId);
        List<RequestEntity> requestsList = query.getResultList();
        if (requestsList.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(fluentAssembler.assemble(requestsList).with(WltpModelMapper.class).to(Request.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#fetchComptoolDataCount(java.lang.String)
     */
    @Override
    public Object[] fetchComptoolDataCount(String newtonResponseMachineName) {
        String requestBatchQuery = "SELECT req.INTERNAL_FILE_ID,count(*) FROM W7TQTREQ req WHERE req.STATUS IN('50','60','61') AND req.BATCH_ID IN (SELECT rqb.ID FROM W7TQTRQB rqb WHERE rqb.STATUS='C' AND req.BATCH_ID = rqb.ID AND ( rqb.BCV_RES_MAC_NAME = ? OR rqb.BCV_RES_MAC_NAME IS NULL) AND rqb.MANUAL = false AND rqb.CLIENT='COMPTOOL' ORDER BY rqb.CREATED_DATE desc) GROUP BY req.INTERNAL_FILE_ID";
        Query query = entityManager.createNativeQuery(requestBatchQuery);
        query.setParameter(1, newtonResponseMachineName);
        if (query.getResultList().isEmpty()) {
            return new Object[0];
        }

        return (Object[]) query.getResultList().get(0);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#getAllRequestsCountFromDatabase(java.lang.String)
     */
    @Override
    public int getAllRequestsCountFromDatabase(String internalFileId) {
        String countQuery = "SELECT count(*) FROM W7TQTREQ WHERE INTERNAL_FILE_ID=?";
        Query query = entityManager.createNativeQuery(countQuery);
        query.setParameter(1, internalFileId);
        if (query.getResultList().isEmpty()) {
            return 0;
        }
        BigInteger recordCount = (BigInteger) query.getResultList().get(0);
        return recordCount.intValue();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#clearSession()
     */
    @Override
    public void clearSession() {
        Session session = entityManager.unwrap(Session.class);

        if (session != null) {
            SessionStatistics statistics = session.getStatistics();
            logger.debug("Collection Count [{}]", statistics.getCollectionCount());
            logger.debug("Entity Count [{}]", statistics.getEntityCount());
            session.clear(); // internal cache clear
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository#updateCalculationStatus(int, java.lang.String,
     *      java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public int updateCalculationStatus(int statusCode, String answerCode, String answerDesignation, String requestId, String internalFileId) {
        String sqlString = "UPDATE W7TQTREQ SET STATUS=?,ANSWER_CODE=?,ANSWER_DESIGNATION=? WHERE REQUEST_ID=? and INTERNAL_FILE_ID=? ";
        Query query = entityManager.createNativeQuery(sqlString);
        query.setParameter(1, statusCode);
        query.setParameter(2, answerCode);
        query.setParameter(3, answerDesignation);
        query.setParameter(4, requestId);
        query.setParameter(5, internalFileId);
        return query.executeUpdate();
    }

}
