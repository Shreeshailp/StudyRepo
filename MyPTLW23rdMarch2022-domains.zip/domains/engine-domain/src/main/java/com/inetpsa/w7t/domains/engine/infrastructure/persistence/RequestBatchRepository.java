/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;

/**
 * The Interface RequestBatchRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface RequestBatchRepository extends GenericRepository<RequestBatchEntity, UUID> {

    /**
     * Read a RequestBatchEntity from the database with the given fileId.
     * 
     * @param fileId the fileId
     * @return the RequestBatchEntity if found, Optional empty otherwise
     */
    Optional<RequestBatchEntity> byfileId(String fileId);

    /**
     * Gets the time out request batches.
     *
     * @param timeOutParam the time out param
     * @param reqMachineName the req machine name
     * @return the time out request batches
     */
    Optional<List<RequestBatch>> getTimeOutRequestBatches(int timeOutParam, String reqMachineName);

    /**
     * Read List of RequestBatch from the database which are completed.
     * 
     * @return the list of RequestBatch if found, Optional empty otherwise
     */
    Optional<List<RequestBatch>> getCompletedRequestBatches();

    /**
     * Updates the database with the given Request Batch.
     * 
     * @param reqBatch the RequestBatch
     */
    void updateReqBatch(RequestBatch reqBatch);

    /**
     * client name.
     *
     * @param requestBatchId the request batch id
     * @return the string
     */
    String clientName(UUID requestBatchId);

    /**
     * Update req batch with columns.
     *
     * @param status the status
     * @param requestId the request id
     * @return the int
     */
    int updateReqBatchWithColumns(String status, String requestId);

    /**
     * By status and to machine.
     *
     * @param status the status
     * @param bcvResMacName the bcv res mac name
     * @param isManual the is manual
     * @return the list
     */
    List<String> byStatusAndToMachine(String status, String bcvResMacName, boolean isManual);

    /**
     * Gets the time out request batches ids.
     *
     * @param timeout the timeout
     * @return the time out request batches ids
     */
    List<UUID> getTimeOutRequestBatchesIds(int timeout);

    /**
     * Gets the corvet or manual batch ids.
     *
     * @param status the status
     * @param reqMacName the req mac name
     * @param bcvResMacName the bcv res mac name
     * @param isManual the is manual
     * @return the corvet or manual batch ids
     */
    List<String> getCorvetOrManualBatchIds(String status, String reqMacName, String bcvResMacName, boolean isManual);

    /**
     * Gets the request batch by internal file id.
     *
     * @param internalFileId the internal file id
     * @return the request batch by internal file id
     */
    RequestBatch getRequestBatchByInternalFileId(String internalFileId);

    /**
     * Update res mac name as rec mac name.
     *
     * @param requestBatch the request batch
     * @return the int
     */
    int updateResMacNameAsRecMacName(RequestBatch requestBatch);

}
