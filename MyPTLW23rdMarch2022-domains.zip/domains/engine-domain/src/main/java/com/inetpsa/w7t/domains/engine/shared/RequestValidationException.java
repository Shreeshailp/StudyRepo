/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.shared;

import org.seedstack.seed.SeedException;

/**
 * The Class RequestValidationException.
 */
public class RequestValidationException extends SeedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 9181087638576258908L;

    /**
     * Instantiates a new request validation exception.
     *
     * @param errorCode the error code
     */
    public RequestValidationException(RequestErrorCode errorCode) {
        super(errorCode);

    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {
        return ((RequestErrorCode) this.getErrorCode()).getDescription();
    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((RequestErrorCode) this.getErrorCode()).getRuleCode();
    }
}
