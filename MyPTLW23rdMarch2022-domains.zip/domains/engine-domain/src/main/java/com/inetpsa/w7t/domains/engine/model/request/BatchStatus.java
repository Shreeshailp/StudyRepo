/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

/**
 * The Enum BatchStatus.
 */
public enum BatchStatus {

    /** The received. */
    RECEIVED("R"),

    /** The complete. */
    COMPLETE("C"),

    /** The generated. */
    GENERATED("G"),

    /** The invalid. */
    INVALID("I");

    /** The code. */
    private String code;

    /**
     * Instantiates a new batch status.
     *
     * @param code the code
     */
    private BatchStatus(String code) {
        this.code = code;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

}
