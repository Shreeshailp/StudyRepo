/*
 * Creation : 4 Sep 2019
 */
package com.inetpsa.w7t.domains.engine.utilities;

import java.time.LocalDateTime;
import java.util.List;
import java.util.regex.Matcher;

import org.apache.commons.lang.time.StopWatch;
import org.seedstack.seed.SeedException;
import org.seedstack.shed.exception.ErrorCode;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.domains.maturity.model.MaturityDto;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * The Class MaturityCheckUtility.
 */
public class MaturityCheckUtility {

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The Constant REQUEST_TYPE. */
    private static final String REQUEST_TYPE = "TEST";

    /** The Constant MATURITY_LOG. */
    private static final String MATURITY_LOG = "RequestID : [{}] Maturity : {}";

    /** The Constant D. */
    private static final String D = "D";

    /** The Constant O. */
    private static final String O = "O";

    /** The Constant U. */
    private static final String U = "U";

    /** The Constant C. */
    private static final String C = "C";

    private static final String F = "F";

    /** The Constant VERSION16_REG_EX. */
    private static final String VERSION16_REG_EX = "(?:^.{16})";

    /** The Constant MATURITY_CHECK_LOG. */
    private static final String MATURITY_CHECK_LOG = "Request ID[{}]: StopWatch - Maturity Check took {}ms";

    /** The Constant MATURITY_AUTHORIZATION_LOG. */
    private static final String MATURITY_AUTHORIZATION_LOG = "Request ID[{}]: StopWatch - Maturity Authorization Check took {}ms";

    /**
     * Maturity check.
     *
     * @param version16C the version 16 C
     * @param logger the version 16 c
     * @param maturityRepository the logger
     * @return the list
     */
    public static List<Maturity> maturityCheck(String version16C, Logger logger, MaturityRepository maturityRepository) {
        String patternToMatchs = "";
        if (version16C != null && !version16C.isEmpty()) {
            patternToMatchs = version16C.substring(0, 6) + "*" + version16C.substring(7, 10) + "****" + version16C.substring(14, 16);
        }
        return maturityRepository.getMatchedPatterns(patternToMatchs);
    }

    /**
     * Insert unknown pattern.
     *
     * @param logger the logger
     * @param version16 the version 16
     * @param client the client
     * @param maturityRepository the maturity repository
     */
    public static void insertUnknownPattern(Logger logger, String version16, String client, MaturityRepository maturityRepository) {
        MaturityDto maturity = new MaturityDto();
        maturity.setFamily(version16.substring(0, 4));
        maturity.setBody(version16.substring(4, 6));
        maturity.setMotor(version16.substring(7, 9));
        maturity.setGearbox(version16.substring(9, 10));
        maturity.setIndex(version16.substring(14, 16));

        boolean flag = maturityRepository.exists(maturity.getFamily(), maturity.getBody(), maturity.getMotor(), maturity.getGearbox(),
                maturity.getIndex());
        if (!flag) {
            maturityRepository.insertIntoPatternTable(version16, U, client);
            logger.info("The maturity is inserted");
        }
    }

    /**
     * Maturity authorization check.
     *
     * @param version16 the version 16
     * @param matchedList the matched list
     * @param logger the logger
     * @param requestId the request id
     * @param client the client
     * @param clientMaturityRepository the client maturity repository
     * @param maturityRepository the maturity repository
     * @return the string
     */
    public static String maturityAuthorizationCheck(String version16, List<Maturity> matchedList, Logger logger, String requestId, String client,
            ClientMaturityRepository clientMaturityRepository, MaturityRepository maturityRepository) {
        String maturityStatus = null;
        if (matchedList.size() > 1) {
            throw SeedException.createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.SEVERAL_PATTERN_FOUND, ""));
        } else if (matchedList.isEmpty()) {
            maturityStatus = U;
            // fixed jira 609
            maturityRepository.insertIntoPatternTable(version16, maturityStatus, client);
            if (!clientMaturityRepository.exists(client, maturityStatus)) {
                throw SeedException
                        .createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.MATURITY_NOT_AUTHORIZED, maturityStatus));
            }
        } else {
            maturityStatus = matchedList.get(0).getStatus();
            if (!clientMaturityRepository.exists(client, maturityStatus)) {
                throw SeedException
                        .createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.MATURITY_NOT_AUTHORIZED, maturityStatus));
            }
        }
        return maturityStatus;
    }

    /**
     * Maturity authorization check.
     *
     * @param matchedList the matched list
     * @param logger the logger
     * @param requestId the request id
     * @param client the client
     * @param clientMaturityRepository the client maturity repository
     * @return the string
     */
    public static String maturityAuthorizationCheck(List<Maturity> matchedList, Logger logger, String requestId, String client,
            ClientMaturityRepository clientMaturityRepository) {
        String maturityStatus = null;
        if (matchedList.size() > 1) {
            throw SeedException.createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.SEVERAL_PATTERN_FOUND, ""));
        } else if (matchedList.isEmpty()) {
            maturityStatus = U;
            if (!clientMaturityRepository.exists(client, maturityStatus)) {
                throw SeedException
                        .createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.MATURITY_NOT_AUTHORIZED, maturityStatus));
            }
        } else {
            maturityStatus = matchedList.get(0).getStatus();
            if (!clientMaturityRepository.exists(client, maturityStatus)) {
                throw SeedException
                        .createNew(wrapSeedException(logger, requestId, WltpEngineCalculatorErrorCode.MATURITY_NOT_AUTHORIZED, maturityStatus));
            }
        }
        return maturityStatus;
    }

    /**
     * Wrap seed exception.
     *
     * @param logger the logger
     * @param requestId the request id
     * @param errorCode the error code
     * @param maturityStatus the maturity status
     * @return the error code
     */
    private static ErrorCode wrapSeedException(Logger logger, String requestId, WltpEngineCalculatorErrorCode errorCode, String maturityStatus) {

        WltpErrorCode wltpErrorCode = new WltpErrorCode();
        wltpErrorCode.setRuleCode(errorCode.getRuleCode());
        if (maturityStatus.equalsIgnoreCase(D)) {
            wltpErrorCode.setDescription(errorCode.getDescription() + " (Draft)");
        } else if (maturityStatus.equalsIgnoreCase(O)) {
            wltpErrorCode.setDescription(errorCode.getDescription() + " (Obsolete)");
        } else if (maturityStatus.equalsIgnoreCase(U)) {
            wltpErrorCode.setDescription(errorCode.getDescription() + " (Unknown)");
        } else if (maturityStatus.equalsIgnoreCase(C)) {
            wltpErrorCode.setDescription(errorCode.getDescription() + " (Checked)");
        } else if (maturityStatus.equalsIgnoreCase(F)) {
            wltpErrorCode.setDescription(errorCode.getDescription() + " (Captive fleet)");
        } else {
            wltpErrorCode.setDescription(errorCode.getDescription());
        }

        LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
        return wltpErrorCode;
    }

    /**
     * Maturity check for web service.
     *
     * @param requestType the request type
     * @param version16 the version 16
     * @param requestId the request id
     * @param client the client
     * @param logger the logger
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @return the string
     */
    public static String maturityCheckForWebService(String requestType, String version16, String requestId, String client, Logger logger,
            MaturityRepository maturityRepository, ClientMaturityRepository clientMaturityRepository) {
        StopWatch sw = new StopWatch();
        sw.start();
        List<Maturity> matchedList = MaturityCheckUtility.maturityCheck(version16, logger, maturityRepository);
        sw.stop();
        logger.info(MATURITY_CHECK_LOG, requestId, sw.getTime());
        String statusMatched = null;
        if (!version16.isEmpty() && matchedList != null && !requestType.equalsIgnoreCase(REQUEST_TYPE)) {
            StopWatch sw1 = new StopWatch();
            sw1.start();
            // fixed jira-648
            statusMatched = MaturityCheckUtility.maturityAuthorizationCheck(matchedList, logger, requestId, client, clientMaturityRepository);
            sw1.stop();
            logger.info(MATURITY_AUTHORIZATION_LOG, requestId, sw1.getTime());

        } else if (!version16.isEmpty() && requestType.equalsIgnoreCase(REQUEST_TYPE)) {

            if (matchedList != null && !matchedList.isEmpty()) {
                statusMatched = matchedList.get(0).getStatus();
            } else {
                statusMatched = U;
            }
        }

        return statusMatched;
    }

    /**
     * Determine maturity check for simulation.
     *
     * @param request the request
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @param logger the logger
     * @param client the client
     * @return true, if successful
     */
    public static boolean determineMaturityCheckForSimulation(Request request, MaturityRepository maturityRepository,
            ClientMaturityRepository clientMaturityRepository, Logger logger, String client) {

        // Maturity check step 3.12a for CAP-15815 starts here
        String statusMatched = null;
        String version16 = null;
        boolean proceed = true;
        Matcher m = java.util.regex.Pattern.compile(VERSION16_REG_EX).matcher(request.getExtendedTitle());
        if (m.lookingAt())
            version16 = m.group(0);
        StopWatch sw = new StopWatch();
        sw.start();
        List<Maturity> matchedList = MaturityCheckUtility.maturityCheck(version16, logger, maturityRepository);
        sw.stop();
        logger.info(MATURITY_CHECK_LOG, request.getRequestId(), sw.getTime());
        if ((version16 != null && !version16.isEmpty() && !request.getRequestType().toString().equalsIgnoreCase(REQUEST_TYPE))) {
            try {
                StopWatch sw1 = new StopWatch();
                sw1.start();
                statusMatched = MaturityCheckUtility.maturityAuthorizationCheck(matchedList, logger, request.getRequestId(), client,
                        clientMaturityRepository);
                sw1.stop();
                logger.info(MATURITY_AUTHORIZATION_LOG, request.getRequestId(), sw1.getTime());
                request.setMaturity(statusMatched);
                logger.info(MATURITY_LOG, request.getRequestId(), statusMatched);
            } catch (SeedException se) {
                if (se.getErrorCode() instanceof WltpErrorCode) {
                    WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                    WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                }
                if (request.getAnswerDesignation().contains("Draft")) {
                    request.setMaturity("D");
                } else if (request.getAnswerDesignation().contains("Obsolete")) {
                    request.setMaturity("O");
                } else if (request.getAnswerDesignation().contains("Checked")) {
                    request.setMaturity("C");
                } else if (request.getAnswerDesignation().contains("Unknown")) {
                    request.setMaturity("U");
                } else if (request.getAnswerDesignation().contains("Captive fleet")) {
                    request.setMaturity("F");
                }
                proceed = false;
            }

        } else if (version16 != null && !version16.isEmpty() && request.getRequestType().toString().equalsIgnoreCase(REQUEST_TYPE)) {

            if (!matchedList.isEmpty()) {
                statusMatched = matchedList.get(0).getStatus();
            } else {
                statusMatched = U;

            }
            request.setMaturity(statusMatched);
            logger.info(MATURITY_LOG, request.getRequestId(), statusMatched);
        }
        // Maturity check step 3.12a for CAP-15815 ends here
        return proceed;
    }

    /**
     * Instantiates a new maturity check utility.
     */
    private MaturityCheckUtility() {

    }

    /**
     * Determine maturity check for corvet.
     *
     * @param requestNumber the request number
     * @param requestType the request type
     * @param extendedTitle the extended title
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @param logger the logger
     * @param client the client
     * @return the string
     */
    public static String determineMaturityCheckForCorvet(String requestNumber, String requestType, String extendedTitle,
            MaturityRepository maturityRepository, ClientMaturityRepository clientMaturityRepository, Logger logger, String client) {
        String statusMatched = null;
        String version16 = null;
        Matcher m = java.util.regex.Pattern.compile(VERSION16_REG_EX).matcher(extendedTitle);
        if (m.lookingAt())
            version16 = m.group(0);
        StopWatch sw = new StopWatch();
        sw.start();
        List<Maturity> matchedList = MaturityCheckUtility.maturityCheck(version16, logger, maturityRepository);
        sw.stop();
        logger.info(MATURITY_CHECK_LOG, requestNumber, sw.getTime());
        if ((version16 != null && !version16.isEmpty() && !requestType.equalsIgnoreCase(REQUEST_TYPE))) {
            try {
                StopWatch sw1 = new StopWatch();
                sw1.start();
                statusMatched = MaturityCheckUtility.maturityAuthorizationCheck(version16, matchedList, logger, requestNumber, client,
                        clientMaturityRepository, maturityRepository);
                sw1.stop();
                logger.info(MATURITY_AUTHORIZATION_LOG, requestNumber, sw1.getTime());
                logger.info(MATURITY_LOG, requestNumber, statusMatched);
            } catch (SeedException se) {
                throw se;
            }

        } else if (version16 != null && !version16.isEmpty() && requestType.equalsIgnoreCase(REQUEST_TYPE)) {

            if (!matchedList.isEmpty()) {
                statusMatched = matchedList.get(0).getStatus();
            } else {
                statusMatched = U;

            }
            logger.info(MATURITY_LOG, requestNumber, statusMatched);
        }
        return statusMatched;
    }

    /**
     * Determine maturity check for marketing clients.
     *
     * @param requestId the request id
     * @param version the version
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @param logger the logger
     * @param client the client
     * @return the string
     */
    public static String determineMaturityCheckForMarketingClients(String requestId, String version, MaturityRepository maturityRepository,
            ClientMaturityRepository clientMaturityRepository, Logger logger, String client) {
        String statusMatched = null;
        StopWatch sw = new StopWatch();
        sw.start();
        List<Maturity> matchedList = MaturityCheckUtility.maturityCheck(version, logger, maturityRepository);
        sw.stop();
        logger.info(MATURITY_CHECK_LOG, requestId, sw.getTime());
        if ((!version.isEmpty())) {
            try {
                StopWatch sw1 = new StopWatch();
                sw1.start();
                statusMatched = MaturityCheckUtility.maturityAuthorizationCheck(version, matchedList, logger, requestId, client,
                        clientMaturityRepository, maturityRepository);
                sw1.stop();
                logger.info(MATURITY_AUTHORIZATION_LOG, requestId, sw1.getTime());
                logger.info(MATURITY_LOG, requestId, statusMatched);
            } catch (SeedException se) {
                throw se;
            }

        }
        return statusMatched;
    }

    /**
     * Determine maturity check for marketing simulation.
     *
     * @param requestId the request id
     * @param version16 the version 16
     * @param requestType the request type
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @param logger the logger
     * @param client the client
     * @return the string
     */
    public static String determineMaturityCheckForMarketingSimulation(String requestId, String version16, String requestType,
            MaturityRepository maturityRepository, ClientMaturityRepository clientMaturityRepository, Logger logger, String client) {
        String statusMatched = null;
        StopWatch sw = new StopWatch();
        sw.start();
        List<Maturity> matchedList = MaturityCheckUtility.maturityCheck(version16, logger, maturityRepository);
        sw.stop();
        logger.info(MATURITY_CHECK_LOG, requestId, sw.getTime());
        if ((!version16.isEmpty()) && !requestType.equalsIgnoreCase(REQUEST_TYPE)) {
            try {
                StopWatch sw1 = new StopWatch();
                sw1.start();
                statusMatched = MaturityCheckUtility.maturityAuthorizationCheck(matchedList, logger, requestId, client, clientMaturityRepository);
                sw1.stop();
                logger.info(MATURITY_AUTHORIZATION_LOG, requestId, sw1.getTime());
                logger.info(MATURITY_LOG, requestId, statusMatched);
            } catch (SeedException se) {
                throw se;
            }

        } else if (!version16.isEmpty() && requestType.equalsIgnoreCase(REQUEST_TYPE)) {

            if (!matchedList.isEmpty()) {
                statusMatched = matchedList.get(0).getStatus();
            } else {
                statusMatched = U;

            }
            logger.info(MATURITY_LOG, requestId, statusMatched);
        }
        return statusMatched;
    }

}
