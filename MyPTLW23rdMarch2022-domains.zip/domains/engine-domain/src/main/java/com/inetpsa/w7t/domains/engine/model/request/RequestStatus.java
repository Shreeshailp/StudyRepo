/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.stream.Stream;

/**
 * The Enum RequestStatus.
 */
public enum RequestStatus {

    /** The request received. */
    REQUEST_RECEIVED(10),
    /** The valid request. */
    VALID_REQUEST(20),
    /** The wltp hub calculation ko. */
    WLTP_HUB_CALCULATION_KO(25),
    /** The request to send. */
    REQUEST_TO_SEND(30),
    /** The request sent. */
    REQUEST_SENT(40),
    /** The newton ok. */
    NEWTON_OK(50),
    /** The request rejected. */
    REQUEST_REJECTED(60),
    /** The newton ko. */
    NEWTON_KO(61),
    /** The calculation ko. */
    CALCULATION_KO(62),
    /** The calculation ok. */
    CALCULATION_OK(70),
    /** The answer sent. */
    ANSWER_SENT(80);

    /** The status code. */
    private int statusCode;

    /**
     * Instantiates a new request status.
     *
     * @param statusCode the status code
     */
    RequestStatus(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Returns a RequestStatus corresponding to the specified status code, or else null.
     *
     * @param statusCode the status code
     * @return the request status
     */
    public static RequestStatus of(int statusCode) {
        return Stream.of(RequestStatus.values()).filter(s -> s.statusCode == statusCode).findFirst().orElse(null);
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public int getStatusCode() {
        return this.statusCode;
    }

    /**
     * Return timeoutable request statuses.
     *
     * @return the list of timeoutable statuses
     */
    public static List<RequestStatus> timeoutables() {
        return Stream.of(RequestStatus.values()).filter(v -> !v.isCompletedStatus() && !v.isFinalStatus()).collect(toList());
    }

    /**
     * Checks if is error status.
     *
     * @return true, if is error status
     */
    public boolean isErrorStatus() {
        return this.equals(RequestStatus.REQUEST_REJECTED) || this.equals(RequestStatus.NEWTON_KO) || this.equals(RequestStatus.CALCULATION_KO);
    }

    /**
     * Checks if is success status.
     *
     * @return true, if is success status
     */
    public boolean isSuccessStatus() {
        return this.equals(RequestStatus.CALCULATION_OK);
    }

    /**
     * Checks if is completed status.
     *
     * @return true, if is completed status
     */
    public boolean isCompletedStatus() {
        return this.isSuccessStatus() || this.isErrorStatus();
    }

    /**
     * Checks if is final status.
     *
     * @return true, if is final status
     */
    public boolean isFinalStatus() {
        return this.equals(RequestStatus.ANSWER_SENT);
    }

    /**
     * Next status.
     *
     * @return the request status
     */
    public RequestStatus nextStatus() {
        if (this.isFinalStatus())
            throw new IllegalStateException("Reached last status. Impossible to go beyond it.");
        if (this.isErrorStatus())
            return RequestStatus.ANSWER_SENT;
        RequestStatus next = this;
        do {
            next = RequestStatus.values()[next.ordinal() + 1];
        } while (next.isErrorStatus());
        return next;
    }
}
