/*
 * Creation : 24 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatusConverter;

/**
 * The Class StepEntity.
 */
@Entity
@Table(name = "W7TQTSTP")
public class StepEntity extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Id
    @Identity(handler = UUIDHandler.class)
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The request id. */
    @Column(name = "REQUEST_ID")
    @Type(type = "uuid-char")
    private UUID requestId;

    /** The new status. */
    @Convert(converter = RequestStatusConverter.class)
    @Column(name = "NEW_STATUS")
    private RequestStatus newStatus;

    /** The old status. */
    @Convert(converter = RequestStatusConverter.class)
    @Column(name = "OLD_STATUS")
    private RequestStatus oldStatus;

    /** The time. */
    @Column(name = "TIME")
    private LocalDateTime time;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public UUID getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(UUID requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the new status.
     *
     * @return the new status
     */
    public RequestStatus getNewStatus() {
        return newStatus;
    }

    /**
     * Sets the new status.
     *
     * @param newStatus the new new status
     */
    public void setNewStatus(RequestStatus newStatus) {
        this.newStatus = newStatus;
    }

    /**
     * Gets the old status.
     *
     * @return the old status
     */
    public RequestStatus getOldStatus() {
        return oldStatus;
    }

    /**
     * Sets the old status.
     *
     * @param oldStatus the new old status
     */
    public void setOldStatus(RequestStatus oldStatus) {
        this.oldStatus = oldStatus;
    }

    /**
     * Gets the time.
     *
     * @return the time
     */
    public LocalDateTime getTime() {
        return time;
    }

    /**
     * Sets the time.
     *
     * @param time the new time
     */
    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashCode = super.hashCode();
        hashCode = hashCode * 31 + requestId.toString().hashCode();
        hashCode = hashCode * 31 + newStatus.hashCode();
        hashCode = hashCode * 31 + oldStatus.hashCode();
        return hashCode;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof StepEntity))
            return false;
        StepEntity other = (StepEntity) o;
        String hash = new StringBuilder(requestId.toString()).append(newStatus).append(oldStatus).toString();
        String otherHash = new StringBuilder(other.requestId.toString()).append(other.newStatus).append(other.oldStatus).toString();
        return hash.equals(otherHash);
    }

}
