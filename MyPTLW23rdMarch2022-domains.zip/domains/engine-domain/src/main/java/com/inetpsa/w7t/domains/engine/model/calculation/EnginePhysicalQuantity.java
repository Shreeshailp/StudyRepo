/*
 * Creation : 6 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.Valid;

import org.seedstack.business.domain.BaseValueObject;

import com.inetpsa.w7t.domains.references.validation.PhysicalQuantityTypeCode;

/**
 * The Class EnginePhysicalQuantity. This class is used when handling the response from Newton (and the manual upload) or when calculating the road
 * load of the requested vehicle. TODO Create JPA entity
 */
@Embeddable
public class EnginePhysicalQuantity extends BaseValueObject {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 580186866378799290L;

    /** The code. */
    @Column(name = "CODE")
    @PhysicalQuantityTypeCode
    private String code;

    /** The value. */
    @Column(name = "VALUE")
    private double value;

    /**
     * Instantiates a new empty engine physical quantity.
     */
    EnginePhysicalQuantity() {
        super();
    }

    /**
     * Instantiates a new engine physical quantity.
     *
     * @param code the code
     * @param value the value
     */
    @Valid
    public EnginePhysicalQuantity(String code, double value) {
        this.code = code;
        this.value = value;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(double value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        EnginePhysicalQuantity other = (EnginePhysicalQuantity) o;
        return Objects.equals(code, other.code) && Objects.equals(value, other.value);
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hashCode(code);
        result = prime * result + Objects.hashCode(value);
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */
    @Override
    public String toString() {
        return "EPQ[" + code + ", " + value + "]";
    }

}
