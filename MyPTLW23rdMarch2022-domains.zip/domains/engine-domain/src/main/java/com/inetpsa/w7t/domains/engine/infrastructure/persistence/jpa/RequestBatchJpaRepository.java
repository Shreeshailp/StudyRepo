/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.business.assembler.dsl.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;
import com.inetpsa.w7t.domains.infrastructure.WltpModelMapper;

/**
 * The Class RequestBatchJpaRepository.
 */
public class RequestBatchJpaRepository extends BaseJpaRepository<RequestBatchEntity, UUID> implements RequestBatchRepository {

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant FILE_ID. */
    private static final String FILE_ID = "fileId";

    /** The Constant INTERNAL_FILE_ID. */
    private static final String INTERNAL_FILE_ID = "internalFileId";

    /** The req mac name. */
    @Configuration("daemon.reqMacName")
    private static String reqMacName;

    /** The bcv res mac name. */
    @Configuration("daemon.bcvResMacName")
    private static String bcvResMacName;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#byfileId(java.lang.String)
     */
    @Override
    public Optional<RequestBatchEntity> byfileId(String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestBatchEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestBatchEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FILE_ID), cb.parameter(String.class, FILE_ID)));

        TypedQuery<RequestBatchEntity> query = entityManager.createQuery(q);
        query.setParameter(FILE_ID, fileId);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#getTimeOutRequestBatches(int, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<RequestBatch>> getTimeOutRequestBatches(int timeOutParam, String reqMachineName) {
        logger.debug("TimeOut Param [{}] and Request Machine [{}]", timeOutParam, reqMachineName);
        String requestBatchQuery = "select * from W7TQTRQB WHERE STATUS = 'C' and REQ_MAC_NAME= ?1 and TIMESTAMPDIFF(SECOND, REQUEST_DATE, now()) > ?2";
        Query query = entityManager.createNativeQuery(requestBatchQuery, RequestBatchEntity.class);
        query.setParameter(1, reqMachineName);
        query.setParameter(2, timeOutParam);
        List<RequestBatchEntity> requestBatchList = query.getResultList();
        if (requestBatchList.isEmpty()) {
            logger.debug("Time out request list is empty");
            return Optional.empty();
        }
        logger.debug("Fetched list of TimeOutRequestBatches");
        return Optional.of(fluentAssembler.assemble(requestBatchList).with(WltpModelMapper.class).to(RequestBatch.class));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#getCompletedRequestBatches()
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<List<RequestBatch>> getCompletedRequestBatches() {

        // String requestBatchQuery = "select * from W7TQTRQB RB where status = 'C' and BCV_RES_MAC_NAME='" + bcvResMacName
        // + "' and not exists (select 1 from W7TQTREQ RQ where RB.id = RQ.BATCH_ID and status <> '80')";
        //
        // Query query = entityManager.createNativeQuery(requestBatchQuery, RequestBatchEntity.class);
        // List<RequestBatchEntity> requestBatchList = query.getResultList();
        // if (requestBatchList.isEmpty()) {
        // return Optional.empty();
        // }
        // logger.debug("Fetched list of CompletedRequestBatches");
        // return Optional.of(fluentAssembler.assemble(requestBatchList).with(WltpModelMapper.class).to(RequestBatch.class));

        // String requestBatchQuery = "SELECT ID, FILE_ID, CLIENT, REQUEST_DATE, MANUAL,REQ_MAC_NAME, BCV_RES_MAC_NAME, INTERNAL_FILE_ID from W7TQTRQB
        // RB "
        // + "where status = 'C' and ((REQ_MAC_NAME='" + reqMacName + "' AND BCV_RES_MAC_NAME IS NULL) OR BCV_RES_MAC_NAME='" + bcvResMacName
        // + "' AND MANUAL=true) and not exists (select 1 from W7TQTREQ RQ where RB.id = RQ.BATCH_ID and status <> '80')";

        String requestBatchQuery = "SELECT ID, FILE_ID, CLIENT, REQUEST_DATE, MANUAL,REQ_MAC_NAME, BCV_RES_MAC_NAME, INTERNAL_FILE_ID from W7TQTRQB RB "
                + "where status = 'C' AND MANUAL=true  and not exists (select 1 from W7TQTREQ RQ where RB.id = RQ.BATCH_ID and status <> '80')";

        Query query = entityManager.createNativeQuery(requestBatchQuery);
        List<Object[]> arrList = query.getResultList();
        if (arrList.isEmpty()) {
            return Optional.empty();
        }
        return mapRowsToRequestBatch(arrList);
    }

    /**
     * Map rows to request batch.
     *
     * @param arrList the arr list
     * @return the optional
     */
    private Optional<List<RequestBatch>> mapRowsToRequestBatch(List<Object[]> arrList) {
        List<RequestBatch> requestBatchList = new ArrayList<>();
        for (Object[] obj : arrList) {
            RequestBatch requestBatch = new RequestBatch();
            requestBatch.setGuid(UUID.fromString(obj[0].toString()));
            requestBatch.setFileId(obj[1].toString());
            requestBatch.setClient(obj[2].toString());

            java.sql.Timestamp sqltime = (Timestamp) obj[3];

            requestBatch.setRequestDate(sqltime.toLocalDateTime());

            requestBatch.setManualFlag(Boolean.valueOf(obj[4].toString()));
            if (obj[5] != null)
                requestBatch.setReqMacName(obj[5].toString());
            if (obj[6] != null)
                requestBatch.setBcvResMacName(obj[6].toString());
            if (!Boolean.valueOf(obj[4].toString()))
                requestBatch.setInternalFileId(obj[7].toString());

            requestBatchList.add(requestBatch);
        }
        return Optional.of(requestBatchList);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#updateReqBatch(com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch)
     */
    @Override
    public void updateReqBatch(RequestBatch reqBatch) {

        try {
            // Added below if condition as part of JIRA-539 fix
            if (reqBatch.getManualFlag() && reqBatch.getInternalFileId() == null) {
                reqBatch.setInternalFileId(reqBatch.getFileId());
            }

            RequestBatchEntity rBatchEnty = fluentAssembler.merge(reqBatch).with(WltpModelMapper.class).into(RequestBatchEntity.class)
                    .fromRepository().orFail();
            if (rBatchEnty != null) {
                save(rBatchEnty);
            }
        } catch (AggregateNotFoundException e) {
            logger.error("Exception while updateReqBatch [{}]" + e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#clientName(java.util.UUID)
     */
    @Override
    @CacheResult(cacheName = "requestBatchIdCache")
    public String clientName(UUID requestBatchId) {
        return super.load(requestBatchId).getClient();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#updateReqBatchWithColumns(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public int updateReqBatchWithColumns(String status, String requestId) {
        Query query = entityManager.createQuery("UPDATE RequestBatchEntity req SET req.status = :STATUS where req.guid = :ID");
        query.setParameter("STATUS", status);
        query.setParameter("ID", UUID.fromString(requestId));
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#byStatusAndToMachine(java.lang.String, java.lang.String,
     *      boolean)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<String> byStatusAndToMachine(String status, String bcvResMacName, boolean isManual) {
        String requestBatchQuery = "SELECT FILE_ID FROM W7TQTRQB WHERE STATUS = ? AND BCV_RES_MAC_NAME = ? AND MANUAL = ?";
        Query query = entityManager.createNativeQuery(requestBatchQuery);
        query.setParameter(1, status);
        query.setParameter(2, bcvResMacName);
        query.setParameter(3, isManual);
        if (query.getResultList().isEmpty()) {
            return Collections.emptyList();
        }
        logger.debug("Fetched list of Status And ToMachine Fiele Ids");

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#getTimeOutRequestBatchesIds(int)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<UUID> getTimeOutRequestBatchesIds(int timeOutParam) {
        String requestBatchQuery = "select ID from W7TQTRQB WHERE STATUS = 'C' and TIMESTAMPDIFF(SECOND, REQUEST_DATE, now()) > ?1";
        Query query = entityManager.createNativeQuery(requestBatchQuery);
        query.setParameter(1, timeOutParam);
        if (query.getResultList().isEmpty()) {
            return Collections.emptyList();
        }
        logger.debug("Fetched list of TimeOutRequestBatches");

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#getCorvetOrManualBatchIds(java.lang.String,
     *      java.lang.String, java.lang.String, boolean)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<String> getCorvetOrManualBatchIds(String status, String reqMacName, String bcvResMacName, boolean isManual) {
        String requestBatchIdsQuery = "";
        Query query = null;
        if (isManual) {
            requestBatchIdsQuery = "SELECT ID from W7TQTRQB rqb WHERE rqb.STATUS = ? AND rqb.MANUAL = ? ";
            query = entityManager.createNativeQuery(requestBatchIdsQuery);
            query.setParameter(1, status);
            query.setParameter(2, isManual);
        } else {
            requestBatchIdsQuery = "SELECT ID from W7TQTRQB rqb WHERE rqb.STATUS = ? AND rqb.MANUAL = ? AND rqb.REQ_MAC_NAME = ? AND (rqb.BCV_RES_MAC_NAME IS NULL OR rqb.BCV_RES_MAC_NAME = ?)";
            query = entityManager.createNativeQuery(requestBatchIdsQuery);
            query.setParameter(1, status);
            query.setParameter(2, isManual);
            query.setParameter(3, reqMacName);
            query.setParameter(4, bcvResMacName);
        }

        if (query.getResultList().isEmpty()) {
            return Collections.emptyList();
        }
        logger.debug("Fetched list of BatchIds By Manual Or BcvResMac");

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#getRequestBatchByInternalFileId(java.lang.String)
     */
    @Override
    public RequestBatch getRequestBatchByInternalFileId(String internalFileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RequestBatchEntity> q = cb.createQuery(aggregateRootClass);
        Root<RequestBatchEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(INTERNAL_FILE_ID), cb.parameter(String.class, INTERNAL_FILE_ID)));

        TypedQuery<RequestBatchEntity> query = entityManager.createQuery(q);
        query.setParameter(INTERNAL_FILE_ID, internalFileId);
        List<RequestBatchEntity> requestBatchList = new ArrayList<>();
        Optional<RequestBatchEntity> optionalRequestBatch = query.getResultList().stream().findFirst();
        if (optionalRequestBatch.isPresent()) {
            requestBatchList.add(optionalRequestBatch.get());
        }
        Optional<List<RequestBatch>> optionalRequestBatchObj = Optional
                .of(fluentAssembler.assemble(requestBatchList).with(WltpModelMapper.class).to(RequestBatch.class));
        RequestBatch requestBatch = null;
        if (optionalRequestBatchObj.isPresent()) {
            requestBatch = optionalRequestBatchObj.get().get(0);
        }

        return requestBatch;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository#updateResMacNameAsRecMacName(com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch)
     */
    @Override
    public int updateResMacNameAsRecMacName(RequestBatch requestBatch) {
        Query query = entityManager.createQuery("UPDATE RequestBatchEntity req SET req.bcvResMacName = :RESPMACNAME where req.guid = :ID");
        query.setParameter("RESPMACNAME", requestBatch.getBcvResMacName());
        query.setParameter("ID", requestBatch.getGuid());
        return query.executeUpdate();

    }
}
