/*
 * Creation : 11 août 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import org.seedstack.business.domain.GenericFactory;

/**
 * A factory for creating Calculation objects.
 */
public interface CalculationFactory extends GenericFactory<Calculation> {

    /**
     * Create a Calculation with a version
     *
     * @param version the version
     * @return the calculation
     */
    Calculation withVersion(Version version);
}
