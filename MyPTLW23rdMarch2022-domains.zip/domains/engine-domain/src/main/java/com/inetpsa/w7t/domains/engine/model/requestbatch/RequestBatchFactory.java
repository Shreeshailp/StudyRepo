/*
 * Creation : 23 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.requestbatch;

import java.time.LocalDateTime;

import org.seedstack.business.domain.Create;
import org.seedstack.business.domain.GenericFactory;

/**
 * A factory for creating RequestBatch objects.
 */
public interface RequestBatchFactory extends GenericFactory<RequestBatch> {

    /**
     * Creates a new RequestBatch object.
     *
     * @param fileId the file id
     * @param client the client
     * @param requestDate the request date
     * @return the request batch
     */
    @Create
    RequestBatch createRequestBatch(String fileId, String client, LocalDateTime requestDate);
}
