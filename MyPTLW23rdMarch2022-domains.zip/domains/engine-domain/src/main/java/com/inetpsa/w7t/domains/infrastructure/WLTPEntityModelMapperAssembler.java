/*
 * Creation : 6 févr. 2017
 */
package com.inetpsa.w7t.domains.infrastructure;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.modelmapper.AbstractConverter;
import org.modelmapper.ModelMapper;
import org.modelmapper.config.Configuration.AccessLevel;
import org.seedstack.business.assembler.modelmapper.ModelMapperAssembler;
import org.seedstack.business.domain.AggregateRoot;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.spi.GenericImplementation;

import com.google.common.reflect.TypeToken;
import com.google.inject.Injector;
import com.google.inject.assistedinject.Assisted;
import com.inetpsa.w7t.domains.core.model.WLTPEntity;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.CalculatedDataEntity;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.CalculatedPhaseEntity;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * The Class WLTPEntityModelMapperAssembler.
 *
 * @param <A> any entity extending {@link AggregateRoot}, either directly through {@link BaseAggregateRoot} or {@link WLTPEntity}.
 * @param <D> the identifier type
 */
@WltpModelMapper
@GenericImplementation
public class WLTPEntityModelMapperAssembler<A extends AggregateRoot<?>, D> extends ModelMapperAssembler<A, D> {

    @Inject
    private Injector injector;

    /**
     * Instantiates a new WLTP entity model mapper assembler.
     *
     * @param genericClasses the generic classes
     */
    @SuppressWarnings("unchecked")
    @Inject
    public WLTPEntityModelMapperAssembler(@Assisted Object[] genericClasses) {
        super((Class<D>) genericClasses.clone()[1]);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.assembler.modelmapper.ModelMapperAssembler#configureAssembly(org.modelmapper.ModelMapper)
     */
    @Override
    protected void configureAssembly(ModelMapper modelMapper) {
        // We do not add converters here since LocalDate and UUID display their correct representation via a toString().
        modelMapper.getConfiguration().setFieldMatchingEnabled(true).setFieldAccessLevel(AccessLevel.PRIVATE);

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.assembler.modelmapper.ModelMapperAssembler#configureMerge(org.modelmapper.ModelMapper)
     */
    @Override
    protected void configureMerge(ModelMapper modelMapper) {
        modelMapper.getConfiguration().setFieldMatchingEnabled(true).setFieldAccessLevel(AccessLevel.PRIVATE);
        modelMapper.addConverter(new AbstractConverter<String, UUID>() {
            @Override
            protected UUID convert(String source) {
                if (source != null)
                    return UUID.fromString(source);
                return null;
            }
        });

        modelMapper.addConverter(new AbstractConverter<java.util.Optional<Integer>, Integer>() {
            @Override
            protected Integer convert(java.util.Optional<Integer> source) {
                return source.orElse(null);
            }
        });

        modelMapper.addConverter(new AbstractConverter<java.util.Optional<List<EnginePhysicalQuantity>>, List<EnginePhysicalQuantity>>() {
            @Override
            protected List<EnginePhysicalQuantity> convert(Optional<List<EnginePhysicalQuantity>> source) {
                return source.orElseGet(ArrayList::new);
            }
        });

        modelMapper.addConverter(new AbstractConverter<Optional<List<CalculatedPhase>>, List<CalculatedPhase>>() {
            @Override
            protected List<CalculatedPhase> convert(Optional<List<CalculatedPhase>> source) {
                return source.orElseGet(ArrayList::new);
            }
        });

        modelMapper.addConverter(new AbstractConverter<String, LocalDate>() {
            @Override
            protected LocalDate convert(String source) {
                if (source != null)
                    return LocalDate.parse(source);
                return null;
            }
        });

        modelMapper.addConverter(new AbstractConverter<CalculatedData, CalculatedDataEntity>() {

            @Override
            protected CalculatedDataEntity convert(CalculatedData source) {
                if (Objects.nonNull(source)) {
                    CalculatedDataEntity cde = new CalculatedDataEntity();
                    cde.setGuid(source.getEntityId());
                    cde.setTestMass(source.getTestMass().orElse(null));
                    // cde.setCrrEfficiency(source.getCrrEfficiency().orElse(null));
                    cde.setRoadLoad(source.getRoadLoad().orElse(null));
                    if (source.getfDownScale() != null) {
                        cde.setfDownScale(source.getfDownScale());
                    } else {
                        cde.setfDownScale(null);
                    }
                    if ("Y".equals(source.getSpeedLimitFlag())) {
                        cde.setSpeedLimitFlag("Y");
                    } else {
                        cde.setSpeedLimitFlag("N");
                    }

                    /*
                     * In order to have a correct mapping from the list of CalculatedPhase into a list of CalculatedPhaseEntity we need to use Google
                     * Guava's TypeToken through ModelMapper to keep track of the parameterized type.
                     */
                    Type l = new TypeToken<List<CalculatedPhaseEntity>>() {
                    }.getType();
                    cde.setCalculatedPhases(modelMapper.map(source.getCalculatedPhases().orElse(null), l));
                    // Then we manually set the CalculatedPhaseEntity calculatedDataId field to correctly insert the data into the database.
                    cde.getCalculatedPhases().stream().forEach(cp -> cp.setCalculatedDataId(cde.getEntityId()));
                    return cde;
                }

                return null;
            }
        });

    }

}
