/*
 * Creation : 26 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.NewtonEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;


/**
 * The Interface NewtonRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface NewtonRepository extends GenericRepository<NewtonEntity, Long> {

    /**
     * Read a NewtonEntity from the database.
     * 
     * @param request the request that will be used to find the newtonEntity
     * @return the found NewtonEntity
     */
    Optional<NewtonEntity> getNewtonEntity(Request request);

    /**
     * Update newton request by file ID.
     *
     * @param status the status
     * @param isRequestSent the is request sent
     * @param fileId the file id
     * @return the int
     */
    int updateNewtonRequestByFileID(RequestStatus status, boolean isRequestSent, String fileId);

    /**
     * Gets the latest newton entity.
     *
     * @param request the request
     * @return the latest newton entity
     */
    Optional<NewtonEntity> getLatestNewtonEntity(Request request);

    /**
     * Update all newton request by file ID.
     *
     * @param status the status
     * @param isRequestSent the is request sent
     * @param reqNos the req nos
     * @return the int
     */
    int updateAllNewtonRequestByFileID(RequestStatus status, boolean isRequestSent, List<Long> reqNos);

}
