/*
 * Creation : 23 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;
import org.seedstack.business.domain.Create;

import com.google.inject.Injector;

/**
 * The Class RequestFactoryDefault.
 */
public class RequestFactoryDefault extends BaseFactory<Request> implements RequestFactory {

    /** The injector. */
    @Inject
    private Injector injector;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.model.request.RequestFactory#createRequest(java.util.UUID, java.lang.Boolean,
     *      com.inetpsa.w7t.domains.engine.model.request.RequestType, java.lang.String, java.lang.String, java.time.LocalDateTime, java.lang.String,
     *      java.time.LocalDate, java.lang.String)
     */
    @Create
    @Override
    public Request createRequest(UUID requestBatchId, Boolean manualRequest, RequestType requestType, String fileId, String clientRequestNumber,
            LocalDateTime requestDate, String vin, LocalDate ecomDate, String extendedTitle) {
        Request request = new Request(requestBatchId, manualRequest, requestType, fileId, clientRequestNumber, requestDate, vin, ecomDate,
                extendedTitle);
        injector.injectMembers(request);
        return request;
    }

}
