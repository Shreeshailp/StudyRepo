/*
 * Creation : 4 mai 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import java.util.Objects;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * The Class RequestStatusConverter.
 */
@Converter(autoApply = true)
public class RequestStatusConverter implements AttributeConverter<RequestStatus, String> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.persistence.AttributeConverter#convertToDatabaseColumn(java.lang.Object)
     */
    @Override
    public String convertToDatabaseColumn(RequestStatus attribute) {
        if (Objects.isNull(attribute))
            return null;
        return String.valueOf(attribute.getStatusCode());
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.persistence.AttributeConverter#convertToEntityAttribute(java.lang.Object)
     */
    @Override
    public RequestStatus convertToEntityAttribute(String dbData) {
        if (Objects.isNull(dbData))
            return null;
        return RequestStatus.of(Integer.parseInt(dbData));
    }
}
