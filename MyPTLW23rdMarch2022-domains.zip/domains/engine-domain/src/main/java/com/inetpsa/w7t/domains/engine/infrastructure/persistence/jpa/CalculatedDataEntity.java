/*
 * Creation : 28 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseEntity;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * @author E539596
 */
@Entity
@Table(name = "W7TQTCLD")
public class CalculatedDataEntity extends BaseEntity<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The testMass. */
    @Column(name = "TEST_MASS")
    private Integer testMass;

    /** The crr efficiency. */
    // @Column(name = "EECLASS")
    // private String crrEfficiency;

    /** The down scale. */
    @Column(name = "F_DOWN_SCALE")
    private Double fDownScale;

    /** The speed limit flag. */
    @Column(name = "SPEED_LIMIT_FLAG")
    private String speedLimitFlag;

    /** The roadLoad. */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTCRL", joinColumns = @JoinColumn(name = "DATA_ID", referencedColumnName = "ID"))
    private List<EnginePhysicalQuantity> roadLoad;

    /** The calculatedPhases. */
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "DATA_ID", referencedColumnName = "ID")
    private List<CalculatedPhaseEntity> calculatedPhases;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the test mass.
     *
     * @return the test mass
     */
    public Integer getTestMass() {
        return testMass;
    }

    /**
     * Sets the test mass.
     *
     * @param testMass the new test mass
     */
    public void setTestMass(Integer testMass) {
        this.testMass = testMass;
    }

    /**
     * Gets the crr efficiency.
     *
     * @return the crr efficiency
     */
    // public String getCrrEfficiency() {
    // return crrEfficiency;
    // }

    /**
     * Sets the crr efficiency.
     *
     * @param crrEfficiency the new crr efficiency
     */
    // public void setCrrEfficiency(String crrEfficiency) {
    // this.crrEfficiency = crrEfficiency;
    // }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    public List<EnginePhysicalQuantity> getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the road load.
     *
     * @param roadLoad the new road load
     */
    public void setRoadLoad(List<EnginePhysicalQuantity> roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Gets the calculated phases.
     *
     * @return the calculated phases
     */
    public List<CalculatedPhaseEntity> getCalculatedPhases() {
        return calculatedPhases;
    }

    /**
     * Sets the calculated phases.
     *
     * @param calculatedPhases the new calculated phases
     */
    public void setCalculatedPhases(List<CalculatedPhaseEntity> calculatedPhases) {
        this.calculatedPhases = calculatedPhases;
    }

    /**
     * Gets the f down scale.
     *
     * @return the f down scale
     */
    public Double getfDownScale() {
        return fDownScale;
    }

    /**
     * Sets the f down scale.
     *
     * @param fDownScale the new f down scale
     */
    public void setfDownScale(Double fDownScale) {
        this.fDownScale = fDownScale;
    }

    /**
     * Gets the speed limit flag.
     *
     * @return the speed limit flag
     */
    public String getSpeedLimitFlag() {
        return speedLimitFlag;
    }

    /**
     * Sets the speed limit flag.
     *
     * @param speedLimitFlag the new speed limit flag
     */
    public void setSpeedLimitFlag(String speedLimitFlag) {
        this.speedLimitFlag = speedLimitFlag;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((calculatedPhases == null) ? 0 : calculatedPhases.hashCode());
        // result = prime * result + ((crrEfficiency == null) ? 0 : crrEfficiency.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((roadLoad == null) ? 0 : roadLoad.hashCode());
        result = prime * result + ((testMass == null) ? 0 : testMass.hashCode());
        return result;
    }

    /**
     * Equals.
     *
     * @param obj the obj
     * @return true, if successful
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        CalculatedDataEntity other = (CalculatedDataEntity) obj;
        if (calculatedPhases == null) {
            if (other.calculatedPhases != null)
                return false;
        } else if (!calculatedPhases.equals(other.calculatedPhases))
            return false;
        // if (crrEfficiency == null) {
        // if (other.crrEfficiency != null)
        // return false;
        // } else if (!crrEfficiency.equals(other.crrEfficiency))
        // return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (roadLoad == null) {
            if (other.roadLoad != null)
                return false;
        } else if (!roadLoad.equals(other.roadLoad))
            return false;
        if (testMass == null) {
            if (other.testMass != null)
                return false;
        } else if (!testMass.equals(other.testMass))
            return false;
        return true;
    }

}
