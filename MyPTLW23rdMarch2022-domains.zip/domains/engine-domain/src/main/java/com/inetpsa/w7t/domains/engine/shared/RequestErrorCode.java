/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum RequestErrorCode.
 */
public enum RequestErrorCode implements ErrorCode {

    /** The file id missing. */
    FILE_ID_INCORRECT(100, "File ID missing or incorrect", "ERRW100"),
    /** The request number missing. */
    REQUEST_NUMBER_INCORRECT(101, "Request number missing or incorrect", "ERRW101"),
    /** The request number not unique. */
    REQUEST_NUMBER_NOT_UNIQUE(102, "Request number not unique", "ERRW102"),
    /** The unknown request type. */
    UNKNOWN_REQUEST_TYPE(103, "Unknown request type", "ERRW103"),
    /** The extended title missing. */
    EXTENDED_TITLE_INCORRECT(104, "Extended title missing or incorrect", "ERRW104"),
    /** The ecom date incorrect. */
    ECOM_DATE_INCORRECT(105, "ECOM Date missing or incorrect format", "ERRW105"),
    /** The physical data missing. */
    PHYSICAL_DATA_MISSING(106, "Physical data missing", "ERRW106"),
    /** The vin missing. */
    VIN_INCORRECT(107, "VIN missing or incorrect", "ERRW107"),
    /** The file id not unique. */
    FILE_ID_NOT_UNIQUE(108, "File ID not unique", "ERRW108"),

    /** The family code missing. */
    FAMILY_CODE_MISSING(201, "WLTP family missing in the extended title", "ERRW201"),
    /** The family index missing. */
    FAMILY_INDEX_MISSING(202, "WLTP family index missing in the extended title", "ERRW202"),
    /** The unknown family couple. */
    UNKNOWN_FAMILY_COUPLE(203, "Unknown couple family index in the extended title", "ERRW203"),
    /** The program country missing. */
    PROGRAM_COUNTRY_MISSING(204, "Program country missing in the extended title", "ERRW204"),
    /** The unknown program country. */
    UNKNOWN_PROGRAM_COUNTRY(205, "Unknown program country in the extended title", "ERRW205"),
    /** The phys coherence index missing. */
    PHYS_COHERENCE_INDEX_MISSING(206, "Phys coherence index missing in the extended title", "ERRW206"),
    /** The mtac missing. */
    MTAC_MISSING(207, "MTAC missing in the extended title", "ERRW207"),
    /** The unknown family couple. */
    UNKNOWN_MTAC_VALUE(208, "MTAC code unknown in the extended title", "ERRW208"),
    /** The fom missing. */
    FOM_MISSING(216, "Full options mass missing in the extended title", "ERRW216"),
    /** The unknown fom value. */
    UNKNOWN_FOM_VALUE(217, "Full options mass value unknown", "ERRW217"),
    /** The em missing. */
    EMM_MISSING(214, "Empty mass missing in the extended title", "ERRW214"),
    /** The unknown em value. */
    UNKNOWN_EMM_VALUE(215, "Empty mass value unknown", "ERRW215"),

    /** The unknown exception. */
    UNKNOWN_EXCEPTION(109, "Unknown Technical Exception", "ERRW109"),

    /** The unknown tvv. */
    UNKNOWN_TVV(218, "Unknown TVV", "ERRW218"),

    /** several TVV found. */
    SEVERAL_TVV(219, "Several TVV found", "ERRW219"),

    /** The unknown vehicle family. */
    UNKNOWN_VEHICLE_FAMILY(223, "Unknown Vehicle Family", "ERRW223"),

    /** The incorrect tvv. */
    INCORRECT_TVV(109, "incorrect TVV", "ERRW109"),

    /** The too many requests. */
    TOO_MANY_REQUESTS(700, "Too many requests for CalculWLTP Interface", "ERRW700"),

    /** The unknown technical exception. */
    UNKNOWN_TECHNICAL_EXCEPTION(701, "Technical issue while calling WLTPHUB", "ERRW701"),

    /** The wltphub timeout exception. */
    WLTPHUB_TIMEOUT_EXCEPTION(702, "Timeout error while calling WLTPHUB", "ERRW702");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new request error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    RequestErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
