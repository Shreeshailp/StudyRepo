/*
 * Creation : 28 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.seedstack.business.domain.BaseValueObject;
import org.seedstack.business.domain.Entity;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;

/**
 * The Class CalculatedPhase.
 */
public class CalculatedPhase extends BaseValueObject implements Entity<UUID> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5479245730365722394L;

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    private UUID guid;

    /** The phase code. */
    @CyclePhaseCode
    private String phaseCode;

    /** The cycle guid. */
    private UUID cycleGuid;

    /** The cycle energy. */
    private CalculatedMeasure cycleEnergy;

    /** The emissions. */
    private List<CalculatedMeasure> emissions;

    CalculatedPhase() {

    }

    /**
     * Instantiates a new calculated phase.
     *
     * @param phaseCode the phase code
     * @param cycleGuid the phase guid
     */
    CalculatedPhase(@CyclePhaseCode String phaseCode, UUID cycleGuid) {
        super();
        this.phaseCode = phaseCode;
        this.cycleGuid = cycleGuid;
    }

    /**
     * Instantiates a new calculated phase.
     *
     * @param phaseCode the phase code
     */
    public CalculatedPhase(@CyclePhaseCode String phaseCode) {
        super();
        this.phaseCode = phaseCode;
    }

    /**
     * Energy value.
     *
     * @param value the value
     */
    public void energyValue(double value) {
        if (cycleEnergy == null) {
            cycleEnergy = new CalculatedMeasure("CE", value);
        } else {
            throw new UnsupportedOperationException("The cycle energy can only be set once for an instance of CalculatedPhase.");
        }
    }

    /**
     * Adds the emission.
     *
     * @param measureType the measure type
     * @param value the value
     */
    public void addEmission(MeasureType measureType, double value) {
        if (emissions == null)
            emissions = new ArrayList<>();
        emissions.add(new CalculatedMeasure(measureType.getCode(),
                BigDecimal.valueOf(value).setScale(measureType.getRoundingDigits(), RoundingMode.HALF_UP).doubleValue()));
    }

    /**
     * Gets the phase code.
     *
     * @return the phase code
     */
    public String getPhaseCode() {
        return phaseCode;
    }

    /**
     * Getter cycleEnergy.
     *
     * @return the cycleEnergy
     */
    public CalculatedMeasure getCycleEnergy() {
        return cycleEnergy;
    }

    /**
     * Getter cycleGuid.
     *
     * @return the cycleGuid
     */
    public UUID getCycleGuid() {
        return cycleGuid;
    }

    /**
     * Emissions.
     *
     * @return the list
     */
    public List<CalculatedMeasure> emissions() {
        return Collections.unmodifiableList(emissions);
    }

    public List<CalculatedMeasure> getEmissions() {
        return emissions;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        CalculatedPhase other = (CalculatedPhase) o;
        return Objects.equals(phaseCode, other.phaseCode) && Objects.equals(cycleGuid, other.cycleGuid)
                && Objects.equals(cycleEnergy, other.cycleEnergy) && Objects.equals(emissions, other.emissions);
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hashCode(phaseCode);
        result = prime * result + Objects.hashCode(cycleGuid);
        result = prime * result + Objects.hashCode(cycleEnergy);
        result = prime * result + Objects.hashCode(emissions);
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */
    @Override
    public String toString() {
        return "CalculatedPhase [guid=" + guid + ", phaseCode=" + phaseCode + ", cycleGuid=" + cycleGuid + ", cycleEnergy=" + cycleEnergy
                + ", emissions=" + emissions + "]";
    }

    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * The Class CalculatedMeasure.
     */
    @Embeddable
    public static class CalculatedMeasure extends BaseValueObject {

        /** The Constant serialVersionUID. */
        private static final long serialVersionUID = 8725573835286099669L;

        /** The measure type code. */
        @Column(name = "TYPE_CODE")
        @MeasureTypeCode
        private String measureTypeCode;

        /** The value. */
        @Column(name = "VALUE")
        private double value;

        CalculatedMeasure() {
            super();
        }

        /**
         * Instantiates a new calculated measure.
         *
         * @param measureTypeCode the measure type code
         * @param value the value
         */
        public CalculatedMeasure(String measureTypeCode, double value) {
            super();
            this.measureTypeCode = measureTypeCode;
            this.value = value;
        }

        /**
         * Getter value.
         *
         * @return the value
         */
        public double getValue() {
            return value;
        }

        /**
         * Gets the measure type code.
         *
         * @return the measure type code
         */
        public String getMeasureTypeCode() {
            return measureTypeCode;
        }

        /**
         * Sets the measure type code.
         *
         * @param measureTypeCode the new measure type code
         */
        public void setMeasureTypeCode(String measureTypeCode) {
            this.measureTypeCode = measureTypeCode;
        }

        /**
         * Sets the value.
         *
         * @param value the new value
         */
        public void setValue(double value) {
            this.value = value;
        }

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#equals(java.lang.Object)
         */
        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;

            CalculatedMeasure other = (CalculatedMeasure) o;
            return Objects.equals(measureTypeCode, other.measureTypeCode) && Objects.equals(value, other.value);
        }

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#hashCode()
         */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = super.hashCode();
            result = prime * result + Objects.hashCode(measureTypeCode);
            result = prime * result + Objects.hashCode(value);
            return result;
        }

        /**
         * {@inheritDoc}
         * 
         * @see org.seedstack.business.domain.BaseValueObject#toString()
         */
        @Override
        public String toString() {
            return "CalculatedMeasure [measureTypeCode=" + measureTypeCode + ", value=" + value + "]";
        }
    }
}
