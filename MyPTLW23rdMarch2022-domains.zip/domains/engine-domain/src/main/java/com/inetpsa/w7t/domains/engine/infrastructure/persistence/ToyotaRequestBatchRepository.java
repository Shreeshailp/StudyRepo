/*
 * Creation : 2 May 2018
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.ToyotaRequestBatchEntity;

/**
 * The Interface ToyotaRequestBatchRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ToyotaRequestBatchRepository extends GenericRepository<ToyotaRequestBatchEntity, UUID> {

    /**
     * Read a ToyotaRequestBatchEntity from the database with the given fileId.
     * 
     * @param fileId the fileId
     * @return the ToyotaRequestBatchEntity if found, Optional empty otherwise
     */
    Optional<ToyotaRequestBatchEntity> byfileId(String fileId);

    @Read
    boolean exists(String fileId);
}
