/*
 * Creation : 2 May 2018
 */
package com.inetpsa.w7t.domains.engine.model.toyotarequestbatch;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import org.seedstack.business.Producible;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.business.assembler.MatchingEntityId;
import org.seedstack.business.domain.DomainObject;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.ToyotaRequestBatchEntity;

/**
 * The Class ToyotaRequestBatch.
 */
@DtoOf(ToyotaRequestBatchEntity.class)
public class ToyotaRequestBatch implements DomainObject, Producible {

    /** The guid. */
    private UUID guid;

    /** The file id. */
    @NotNull
    private String fileId;

    /** The client. */
    @NotNull
    private String client;

    /** The request date. */
    @NotNull
    private LocalDateTime requestDate;

    /** The status. */
    private String status;

    /**
     * Instantiates a new request batch.
     */
    protected ToyotaRequestBatch() { // NOSONAR Only used for Hibernate
        super();
    }

    /**
     * Client name.
     *
     * @return the string
     */
    public String clientName() {
        return this.client;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    @MatchingEntityId
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

}
