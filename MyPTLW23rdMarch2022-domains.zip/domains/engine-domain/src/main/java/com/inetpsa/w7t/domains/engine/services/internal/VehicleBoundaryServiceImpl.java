/*
 * Creation : 13 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.services.internal;

import static java.util.stream.Collectors.toMap;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.javatuples.KeyValue;
import org.javatuples.Pair;

import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.VehicleBoundary;
import com.inetpsa.w7t.domains.engine.services.VehicleBoundaryService;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyDetailsRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.details.PhysicalQuantityValue;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.MeasureType;

/**
 * The Class VehicleBoundaryServiceImpl.
 */
public class VehicleBoundaryServiceImpl implements VehicleBoundaryService {

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The physical quantity type repository. */
    @Inject
    private PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The family details repository. */
    @Inject
    private FamilyDetailsRepository familyDetailsRepository;

    /** The test vehicle type repository. */
    @Inject
    private TestVehicleTypeRepository testVehicleTypeRepository;

    /** The cycle energy guid. */
    private UUID cycleEnergyGuid;

    /** The vehicle boundary comparator. */
    Comparator<? super VehicleBoundary> vehicleBoundaryComparator = (b1, b2) -> Double.compare(b1.getCycleEnergy(), b2.getCycleEnergy());

    /** The test vehicle type comparator. */
    Comparator<? super TestVehicle> testVehicleTypeComparator = (tv1, tv2) -> Integer.compare(testVehicleTypeRepository.load(tv1.getType()).getSort(),
            testVehicleTypeRepository.load(tv2.getType()).getSort());

    /**
     * {@inheritDoc} <br>
     * This method implements a bi-function that defines a sliding window algorithm used to find the two closer vehicle boundaries given a cycle
     * energy value. Three cases are possible:
     * <ul>
     * <li>The case is nominal so there is a lower and a upper boundary</li>
     * <li>The case is less than the lowest value so we get the 2 lowest boundaries</li>
     * <li>The case is greater than the uppermost value so we get the 2 uppermost boundaries</li>
     * </ul>
     * The algorithm takes in a stream of vehicle boundaries (given by {@link VehicleBoundaryServiceImpl#vehicleBoundaries(UUID, UUID)}) sorted
     * according to their ascending cycle energy. This following explains how the algorithm works:
     * <ol>
     * <li>Define a 2-element sliding window with null values</li>
     * <li>Slide the window in the ascending direction over the stream of objects until the window is full</li>
     * <li>While the second element of the window is less than the given value, slide the window by one element</li>
     * </ol>
     * For the three cases above, it is very simple:
     * <ul>
     * <li>Nominal: the window slides until the value test condition is met;</li>
     * <li>Lowest: Once the window is full, the value test condition is met, so it returns;</li>
     * <li>Uppermost: The window slides to the end, then returns.</li>
     * </ul>
     * This algo allows any number of elements in the list and will not throw an error. A non-null filter upstream protect the algo against null. In
     * the context of WLTP, a WLTP family have least 2 test vehicles (vehicle boundaries)
     * 
     * @see com.inetpsa.w7t.domains.engine.services.VehicleBoundaryService#vehicleBoundaries(java.util.UUID, java.util.UUID, double)
     */
    /* @CacheResult(cacheName = "vehicleBoundariesPairCache") */
    @Override
    public Pair<VehicleBoundary, VehicleBoundary> vehicleBoundaries(UUID familyId, UUID phaseId, double cycleEnergy) {

        BiFunction<Pair<VehicleBoundary, VehicleBoundary>, VehicleBoundary, Pair<VehicleBoundary, VehicleBoundary>> slidingWindow = (window,
                vehicle) -> {
            if (Objects.nonNull(window.getValue0()) && window.getValue1().getCycleEnergy() > cycleEnergy)
                return window;
            return window.setAt0(window.getValue1()).setAt1(vehicle);
        };

        /*
         * The combiner function is not tested, because it is never called;
         */
        return this.vehicleBoundaries(familyId, phaseId).stream().sequential().filter(Objects::nonNull).sorted(vehicleBoundaryComparator)
                .reduce(Pair.<VehicleBoundary, VehicleBoundary>with(null, null), slidingWindow, (a, b) -> {
                    throw new UnsupportedOperationException("Sequential stream dues to fold-left operation");
                });

        // This code is commented in case the current implementation does not please.
        // The following algorithm only allows for in-boundaries interpolation.
        // Map<Boolean, List<VehicleBoundary>> split = this.vehicleBoundaries(familyId, phaseId).stream()
        // .collect(partitioningBy(b -> b.getCycleEnergy() < cycleEnergy));
        // VehicleBoundary lower = split.get(true).stream().max(vehicleBoundaryComparator)
        // .orElseThrow(() -> new NoSuchElementException("Unable to get the upper bound vehicle of the family for the provided cycle energy"));
        // VehicleBoundary upper = split.get(false).stream().min(vehicleBoundaryComparator)
        // .orElseThrow(() -> new NoSuchElementException("Unable to get the upper bound vehicle of the family for the provided cycle energy"));
        //
        // return Pair.with(lower, upper);
    }

    /**
     * Get a list of vehicle boundaries given a family ID and a cycle phase ID.
     *
     * @param familyId the family id
     * @param phaseId the phase id
     * @return the list
     */
    /* @CacheResult(cacheName = "vehicleBoundariesListCache") */
    List<VehicleBoundary> vehicleBoundaries(UUID familyId, UUID phaseId) {
        /* VREF ISSUE FIXED on 20-08-2018 */
        return familyDetailsRepository.load(familyId).getVehicles().stream()
                .filter(t -> !testVehicleTypeRepository.load(t.getType()).getCode().equals(CalculationConstants.VREF))
                .map(v -> this.testVehicleToBoundary(v, phaseId)).collect(Collectors.toList());
        /*
         * return familyDetailsRepository.load(familyId).getVehicles().stream().map(v -> this.testVehicleToBoundary(v, phaseId))
         * .collect(Collectors.toList());
         */
    }

    /**
     * Test vehicle to boundary.
     *
     * @param vehicle the vehicle
     * @param phaseId the phase id
     * @return the vehicle boundary
     */
    VehicleBoundary testVehicleToBoundary(TestVehicle vehicle, UUID phaseId) {
        Map<UUID, Double> measures = vehicle.getMeasures().stream().filter(m -> m.getPhase().equals(phaseId))
                .map(m -> KeyValue.with(m.getType(), m.getValue())).collect(toMap(KeyValue::getKey, KeyValue::getValue));

        Double ce = measures.get(getCycleEnergyGuid());

        if (Objects.isNull(ce))
            throw new NoSuchElementException("No measure found with the cycle energy guid as key");

        return new VehicleBoundary(ce, measures);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.VehicleBoundaryService#physicalBoundaries(com.inetpsa.w7t.domains.families.model.details.FamilyDetails)
     */
    @Override
    public Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> physicalBoundaries(FamilyDetails family) {
        // List<TestVehicle> testVehicles = family.getVehicles().stream().sorted(testVehicleTypeComparator).collect(Collectors.toList());
        List<TestVehicle> testVehicles = family.getVehicles();
        Collections.sort(testVehicles, testVehicleTypeComparator);
        List<EnginePhysicalQuantity> lowest = testVehicleToPhysicalQuantities(testVehicles.get(0));
        List<EnginePhysicalQuantity> highest = testVehicleToPhysicalQuantities(testVehicles.get(testVehicles.size() - 1));

        return Pair.with(lowest, highest);
    }

    /**
     * Test vehicle to physical quantities.
     *
     * @param vehicle the vehicle
     * @return the list
     */
    // private List<EnginePhysicalQuantity> testVehicleToPhysicalQuantities(TestVehicle vehicle) {
    // return vehicle.getQuantities().stream()
    // .map(q -> new EnginePhysicalQuantity(physicalQuantityTypeRepository.load(q.getType()).getCode(), q.getValue()))
    // .collect(Collectors.toList());
    // }

    private List<EnginePhysicalQuantity> testVehicleToPhysicalQuantities(TestVehicle vehicle) {
        List<EnginePhysicalQuantity> epqList = new CopyOnWriteArrayList<>();
        for (PhysicalQuantityValue pqv : vehicle.getQuantities()) {
            epqList.add(new EnginePhysicalQuantity(physicalQuantityTypeRepository.load(pqv.getType()).getCode(), pqv.getValue()));
        }
        return epqList;
    }

    /**
     * Gets the cycle energy guid.
     *
     * @return the cycle energy guid
     */
    UUID getCycleEnergyGuid() {
        if (cycleEnergyGuid == null) {
            Optional<MeasureType> ceMeasureType = measureTypeRepository.byCode(CalculationConstants.CYCLE_ENERGY_CODE);
            if (ceMeasureType.isPresent())
                cycleEnergyGuid = ceMeasureType.get().getGuid();
        }
        return cycleEnergyGuid;
    }
}
