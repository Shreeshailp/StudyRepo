/*
 * Creation : 29 mai 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.UUID;

import org.seedstack.business.domain.Create;
import org.seedstack.business.domain.GenericFactory;

/**
 * A factory for creating CalculatedData objects.
 */
@Create
public interface CalculatedDataFactory extends GenericFactory<CalculatedData> {

    /**
     * Empty.
     *
     * @return the calculated data
     */
    CalculatedData empty();

    /**
     * With test mass.
     *
     * @param testMass the test mass
     * @return the calculated data
     */
    CalculatedData withTestMass(int testMass);

    /**
     * Creates a new CalculatedData object.
     *
     * @param current the current
     * @param phaseCode the phase code
     * @param cycleGuid the cycle guid
     * @return the calculated phase
     */
    CalculatedPhase createCalculatedPhase(CalculatedData current, String phaseCode, UUID cycleGuid);
}
