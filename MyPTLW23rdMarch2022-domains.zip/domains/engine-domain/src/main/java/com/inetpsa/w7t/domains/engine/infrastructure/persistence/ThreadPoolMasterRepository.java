/*
 * Creation : 2 Aug 2019
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.ThreadPoolMaster;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ThreadPoolMasterRepository extends GenericRepository<ThreadPoolMaster, String> {

    public int getThreadPoolSize(String jobName);

    public long getLastRequestNumber(String client, String reqMachine);

    public void updateMRS(String client, long prevReqNumber, String reqMachine);

    public void createMRS(String client, long reqCount, String reqMachine);
}
