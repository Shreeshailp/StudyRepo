/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;

import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatusConverter;

/**
 * The Class NewtonEntity.
 */
@Entity
@Table(name = "W7TQTNEW")
public class NewtonEntity extends BaseAggregateRoot<Long> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4803393814085590313L;

    /** The guid. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "REQ_NO")
    private Long reqNo;

    /** The requestDate. */
    @Column(name = "REQ_DATE")
    private Date requestDate;

    /** The answerDate. */
    @Column(name = "ANSWER_DATE")
    private Date answerDate;

    /** The answerCode. */
    @Column(name = "ANSWER_CODE")
    private String answerCode;

    /** The answerDesignation. */
    @Column(name = "ANSWER_DESIG")
    private String answerDesignation;

    /** The unladenMass. */
    @Column(name = "UNLADEN_MASS")
    private Double unladenMass;

    /** The equipmentMass. */
    @Column(name = "EQUIPMENT_MASS")
    private Double equipmentMass;

    /** The vehicleMass. */
    @Column(name = "VEHICLE_MASS")
    private Double vehicleMass;

    /** The unladenSCx. */
    @Column(name = "UNLADEN_SCX")
    private Double unladenSCx;

    /** The equipmentSCx. */
    @Column(name = "EQUIPMENT_SCX")
    private Double equipmentSCx;

    /** The vehicleSCx. */
    @Column(name = "VEHICLE_SCX")
    private Double vehicleSCx;

    /** The vehicleCRR. */
    @Column(name = "VEHICLE_CRR")
    private Double vehicleCRR;

    /** The status. */
    @Convert(converter = RequestStatusConverter.class)
    @Column(name = "STATUS")
    private RequestStatus status;

    /** The fileId. */
    @Column(name = "FILE_ID")
    private String fileId;

    /** The extendedTitle. */
    @Column(name = "EXTENDED_TITLE")
    private String extendedTitle;

    /** The isRequestSent. */
    @Column(name = "IS_REQUEST_SENT")
    private boolean isRequestSent;

    /** The req id. */
    @Column(name = "REQ_ID")
    private String reqId;

    /**
     * Gets the req id.
     *
     * @return the req id
     */
    public String getReqId() {
        return reqId;
    }

    /**
     * Sets the req id.
     *
     * @param reqId the new req id
     */
    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    /**
     * Checks if is request sent.
     *
     * @return true, if is request sent
     */
    public boolean isRequestSent() {
        return isRequestSent;
    }

    /**
     * Sets the request sent.
     *
     * @param isRequestSent the new request sent
     */
    public void setRequestSent(boolean isRequestSent) {
        this.isRequestSent = isRequestSent;
    }

    /**
     * Gets the fileId.
     *
     * @return the fileId
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the fileId.
     *
     * @param fileId the new fileId
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the extendedTitle.
     *
     * @return the extendedTitle
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extendedTitle.
     *
     * @param extendedTitle the new extendedTitle
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public Long getReqNo() {
        return reqNo;
    }

    /**
     * Sets the guid.
     *
     * @param reqNo the new guid
     */
    public void setReqNo(Long reqNo) {
        this.reqNo = reqNo;
    }

    /**
     * Gets the requestDate.
     *
     * @return the requestDate
     */
    public Date getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the requestDate.
     *
     * @param requestDate the new requestDate
     */
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the answerDate.
     *
     * @return the answerDate
     */
    public Date getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the answerDate.
     *
     * @param answerDate the new answerDate
     */
    public void setAnswerDate(Date answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the answerCode.
     *
     * @return the answerCode
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answerCode.
     *
     * @param answerCode the new answerCode
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answerDesignation.
     *
     * @return the answerDesignation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answerDesignation.
     *
     * @param answerDesignation the new answerDesignation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the unladenMass.
     *
     * @return the unladenMass
     */
    public Double getUnladenMass() {
        return unladenMass;
    }

    /**
     * Sets the unladenMass.
     *
     * @param unladenMass the new unladenMass
     */
    public void setUnladenMass(Double unladenMass) {
        this.unladenMass = unladenMass;
    }

    /**
     * Gets the equipmentMass.
     *
     * @return the equipmentMass
     */
    public Double getEquipmentMass() {
        return equipmentMass;
    }

    /**
     * Sets the equipmentMass.
     *
     * @param equipmentMass the new equipmentMass
     */
    public void setEquipmentMass(Double equipmentMass) {
        this.equipmentMass = equipmentMass;
    }

    /**
     * Gets the vehicleMass.
     *
     * @return the vehicleMass
     */
    public Double getVehicleMass() {
        return vehicleMass;
    }

    /**
     * Sets the vehicleMass.
     *
     * @param vehicleMass the new vehicleMass
     */
    public void setVehicleMass(Double vehicleMass) {
        this.vehicleMass = vehicleMass;
    }

    /**
     * Gets the unladenSCx.
     *
     * @return the unladenSCx
     */
    public Double getUnladenSCx() {
        return unladenSCx;
    }

    /**
     * Sets the unladenSCx.
     *
     * @param unladenSCx the new unladenSCx
     */
    public void setUnladenSCx(Double unladenSCx) {
        this.unladenSCx = unladenSCx;
    }

    /**
     * Gets the equipmentSCx.
     *
     * @return the equipmentSCx
     */
    public Double getEquipmentSCx() {
        return equipmentSCx;
    }

    /**
     * Sets the equipmentSCx.
     *
     * @param equipmentSCx the new equipmentSCx
     */
    public void setEquipmentSCx(Double equipmentSCx) {
        this.equipmentSCx = equipmentSCx;
    }

    /**
     * Gets the vehicleSCx.
     *
     * @return the vehicleSCx
     */
    public Double getVehicleSCx() {
        return vehicleSCx;
    }

    /**
     * Sets the vehicleSCx.
     *
     * @param vehicleSCx the new vehicleSCx
     */
    public void setVehicleSCx(Double vehicleSCx) {
        this.vehicleSCx = vehicleSCx;
    }

    /**
     * Gets the vehicleCRR.
     *
     * @return the vehicleCRR
     */
    public Double getVehicleCRR() {
        return vehicleCRR;
    }

    /**
     * Sets the vehicleCRR.
     *
     * @param vehicleCRR the new vehicleCRR
     */
    public void setVehicleCRR(Double vehicleCRR) {
        this.vehicleCRR = vehicleCRR;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public Long getEntityId() {
        return reqNo;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(answerCode, answerDate, answerDesignation, equipmentMass, equipmentSCx, extendedTitle, fileId, reqNo, requestDate, status,
                unladenMass, unladenSCx, vehicleCRR, vehicleMass, vehicleSCx, reqId);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        NewtonEntity other = (NewtonEntity) obj;

        boolean equals = Objects.equals(answerCode, other.answerCode);
        equals = equals && Objects.equals(answerDate, other.answerDate);
        equals = equals && Objects.equals(answerDesignation, other.answerDesignation);
        equals = equals && Objects.equals(equipmentMass, other.equipmentMass);
        equals = equals && Objects.equals(equipmentSCx, other.equipmentSCx);
        equals = equals && Objects.equals(extendedTitle, other.extendedTitle);
        equals = equals && Objects.equals(fileId, other.fileId);
        equals = equals && Objects.equals(reqNo, other.reqNo);
        equals = equals && Objects.equals(requestDate, other.requestDate);
        equals = equals && Objects.equals(status, other.status);
        equals = equals && Objects.equals(unladenMass, other.unladenMass);
        equals = equals && Objects.equals(unladenSCx, other.unladenSCx);
        equals = equals && Objects.equals(vehicleCRR, other.vehicleCRR);
        equals = equals && Objects.equals(vehicleMass, other.vehicleMass);
        equals = equals && Objects.equals(vehicleSCx, other.vehicleSCx);
        equals = equals && Objects.equals(reqId, other.reqId);

        return equals;
    }

}
