/*
 * Creation : 5 mai 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.util.UUID;

import javax.inject.Inject;

import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.StepRepository;
import com.inetpsa.w7t.domains.engine.model.request.Step;
import com.inetpsa.w7t.domains.infrastructure.WltpModelMapper;

/**
 * The Class StepJpaRepository.
 */
public class StepJpaRepository extends BaseJpaRepository<StepEntity, UUID> implements StepRepository {

    /** The fluent assembler. */
    @Inject
    private FluentAssembler fluentAssembler;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.StepRepository#persist(com.inetpsa.w7t.domains.engine.model.request.Step)
     */
    @Override
    public void persist(Step step) {
        this.persist(fluentAssembler.merge(step).with(WltpModelMapper.class).into(StepEntity.class).fromFactory());
    }
}
