/*
 * Creation : 5 mai 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.StepEntity;
import com.inetpsa.w7t.domains.engine.model.request.Step;

/**
 * The Interface StepRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface StepRepository extends GenericRepository<StepEntity, UUID> {

    /**
     * Persist.
     * 
     * @param step the step entity to be persisted
     */
    void persist(Step step);
}
