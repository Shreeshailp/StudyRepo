/*
 * Creation : 28 Jun 2019
 */
package com.inetpsa.w7t.domains.engine.utilities;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Class WltpErrorCode.
 */
public class WltpErrorCode implements ErrorCode {
    /** The rule code. */
    private int ruleCode;

    /** The description. */
    private String description;

    /** The str rule code. */
    private String strRuleCode;

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public int getRuleCode() {
        return ruleCode;
    }

    /**
     * Sets the rule code.
     *
     * @param ruleCode the new rule code
     */
    public void setRuleCode(int ruleCode) {
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the str rule code.
     *
     * @return the str rule code
     */
    public String getStrRuleCode() {
        return strRuleCode;
    }

    /**
     * Sets the str rule code.
     *
     * @param strRuleCode the new str rule code
     */
    public void setStrRuleCode(String strRuleCode) {
        this.strRuleCode = strRuleCode;
    }

}
