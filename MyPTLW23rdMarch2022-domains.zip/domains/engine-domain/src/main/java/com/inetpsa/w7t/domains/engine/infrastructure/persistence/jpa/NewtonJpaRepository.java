/*
 * Creation : 26 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.cache.annotation.CacheResult;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;

/**
 * The Class NewtonJpaRepository.
 */
public class NewtonJpaRepository extends BaseJpaRepository<NewtonEntity, Long> implements NewtonRepository {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant FILE_ID. */
    private static final String FILE_ID = "fileId";

    /** The Constant REQ_DATE. */
    private static final String REQ_DATE = "requestDate";

    /** The Constant REQ_ID. */
    private static final String REQ_ID = "reqId";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository#getNewtonEntity(com.inetpsa.w7t.domains.engine.model.request.Request)
     */
    @Override
    public Optional<NewtonEntity> getNewtonEntity(Request request) {
        // fixed jira-572
        return Optional.ofNullable(getCachedNewtonEntity(request.getInternalFileId(), request.getRequestId()));
    }

    /**
     * Gets the cached newton entity.
     *
     * @param fileId the file id
     * @param reqId the req id
     * @return the cached newton entity
     */
    @CacheResult(cacheName = "newtonEntityCache", skipGet = true)
    public NewtonEntity getCachedNewtonEntity(String fileId, String reqId) {
        logger.info("For fetching newton physical quantities using REQUEST_ID[{}] and FILE_ID[{}]", reqId, fileId);
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<NewtonEntity> q = cb.createQuery(aggregateRootClass);
        Root<NewtonEntity> r = q.from(NewtonEntity.class);
        // fixed jira-572
        q.where(cb.and(cb.equal(r.get(FILE_ID), cb.parameter(String.class, FILE_ID)), cb.equal(r.get(REQ_ID), cb.parameter(String.class, REQ_ID))));

        TypedQuery<NewtonEntity> query = entityManager.createQuery(q);
        query.setParameter(FILE_ID, fileId);
        // fixed jira-572
        query.setParameter(REQ_ID, reqId);

        return query.getResultList().stream().findFirst().orElse(null);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository#updateNewtonRequestByFileID(com.inetpsa.w7t.domains.engine.model.request.RequestStatus,
     *      boolean, java.lang.String)
     */
    public int updateNewtonRequestByFileID(RequestStatus status, boolean isRequestSent, String fileId) {
        Query query = entityManager
                .createQuery("UPDATE NewtonEntity ne SET ne.status = :STATUS, ne.isRequestSent = :IS_REQUEST_SENT where ne.fileId = :FILE_ID");
        query.setParameter("STATUS", status);
        query.setParameter("IS_REQUEST_SENT", isRequestSent);
        query.setParameter("FILE_ID", fileId);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository#getLatestNewtonEntity(com.inetpsa.w7t.domains.engine.model.request.Request)
     */
    @Override
    // @CacheResult(cacheName = "newtonEntityCache", skipGet = true)
    public Optional<NewtonEntity> getLatestNewtonEntity(Request request) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<NewtonEntity> q = cb.createQuery(aggregateRootClass);
        Root<NewtonEntity> r = q.from(NewtonEntity.class);

        q.where(cb.and(cb.equal(r.get(FILE_ID), cb.parameter(String.class, FILE_ID)), cb.equal(r.get(REQ_ID), cb.parameter(String.class, REQ_ID)),
                cb.equal(r.get(REQ_DATE), cb.parameter(Date.class, REQ_DATE))));

        TypedQuery<NewtonEntity> query = entityManager.createQuery(q);
        query.setParameter(FILE_ID, request.getInternalFileId());
        query.setParameter(REQ_ID, request.getRequestId());

        try {
            String strDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                    .format(Date.from(request.getRequestDate().atZone(ZoneId.systemDefault()).toInstant()));
            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = ft.parse(strDate);

            query.setParameter(REQ_DATE, date);

        } catch (ParseException e1) {
            logger.error("Error while parsing the date : {} ", e1);
        }

        return Optional.ofNullable(query.getResultList().stream().findFirst().orElse(null));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository#updateAllNewtonRequestByFileID(com.inetpsa.w7t.domains.engine.model.request.RequestStatus,
     *      boolean, java.util.List)
     */
    @Override
    public int updateAllNewtonRequestByFileID(RequestStatus status, boolean isRequestSent, List<Long> reqNos) {
        Query query = entityManager
                .createQuery("UPDATE NewtonEntity ne SET ne.status = :STATUS, ne.isRequestSent = :IS_REQUEST_SENT where ne.reqNo in (:REQ_NOS)");
        query.setParameter("STATUS", status);
        query.setParameter("IS_REQUEST_SENT", isRequestSent);
        query.setParameter("REQ_NOS", reqNos);
        return query.executeUpdate();
    }
}
