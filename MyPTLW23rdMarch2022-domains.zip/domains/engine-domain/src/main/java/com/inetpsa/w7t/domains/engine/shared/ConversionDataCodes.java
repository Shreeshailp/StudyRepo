/*
 * Creation : 10 oct. 2018
 */
package com.inetpsa.w7t.domains.engine.shared;

/**
 * The Enum ConversionDataCodes.
 *
 * @author E539596
 */
public enum ConversionDataCodes {

    /** The mtactr. */
    MTACTR("MTACTR"),

    /** The mopttr. */
    MOPTTR("MOPTTR"),

    /** The mcor. */
    MCOR("MCOR"),

    /** The dmtr. */
    DMTR("DMTR"),

    /** The cattr. */
    CATTR("CATTR"),

    /** The scxtr. */
    SCXTR("SCXTR"),

    /** The str. */
    STR("STR"),

    /** The crrtr. */
    CRRTR("CRRTR"),

    /** The htr. */
    HTR("HTR"),

    /** The ltr. */
    LTR("LTR"),

    /** The coolstr. */
    COOLSTR("COOLSTR"),

    /** The special. */
    SPECIAL("SPECIAL"),

    /** The depol. */
    DEPOL("DEPOL"),

    /** The rcrrtr. */
    RCRRTR("RCRRTR"),

    /** The mrotr. */
    MROTR("MROTR"),

    /** The cxtr. */
    CXTR("CXTR");

    /** The code. */
    String code;

    /**
     * Instantiates a new conversion data codes.
     *
     * @param code the code
     */
    private ConversionDataCodes(String code) {
        this.code = code;
    }
}
