/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.requestbatch;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.seedstack.business.Producible;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.business.assembler.MatchingEntityId;
import org.seedstack.business.domain.DomainObject;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;

/**
 * The Class RequestBatch.
 */
@DtoOf(RequestBatchEntity.class)
public class RequestBatch implements DomainObject, Producible {

    /** The guid. */
    private UUID guid;

    /** The file id. */
    @NotNull
    private String fileId;

    /** The client. */
    @NotNull
    private String client;

    /** The request date. */
    @NotNull
    private LocalDateTime requestDate;

    /** The manual flag. */
    private Boolean manualFlag;

    /** The status. */
    private String status;

    /** The importing. */
    private boolean importing = true;

    /** The all requests. */
    private List<Request> allRequests;

    /** The error steps. */
    private List<Request> errorSteps;

    /** The completed steps. */
    private List<Request> completedSteps;

    /** The req mac name. */
    private String reqMacName;

    /** The bcv res mac name. */
    private String bcvResMacName;

    /** The internal file id. */
    private String internalFileId;

    /** The updated date. */
    private String updatedDate;

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate the new updated date
     */
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the internal file id.
     *
     * @return the internal file id
     */
    public String getInternalFileId() {
        return internalFileId;
    }

    /**
     * Sets the internal file id.
     *
     * @param internalFileId the new internal file id
     */
    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    /**
     * Gets the req mac name.
     *
     * @return the req mac name
     */
    public String getReqMacName() {
        return reqMacName;
    }

    /**
     * Sets the req mac name.
     *
     * @param reqMacName the new req mac name
     */
    public void setReqMacName(String reqMacName) {
        this.reqMacName = reqMacName;
    }

    /**
     * Gets the bcv res mac name.
     *
     * @return the bcv res mac name
     */
    public String getBcvResMacName() {
        return bcvResMacName;
    }

    /**
     * Sets the bcv res mac name.
     *
     * @param bcvResMacName the new bcv res mac name
     */
    public void setBcvResMacName(String bcvResMacName) {
        this.bcvResMacName = bcvResMacName;
    }

    /**
     * Instantiates a new request batch.
     *
     * @param fileId the file id
     * @param client the client
     * @param requestDate the request date
     */
    @Valid // NOSONAR validation is done on the return value
    public RequestBatch(String fileId, String client, LocalDateTime requestDate) {
        this.fileId = fileId;
        this.client = client;
        this.requestDate = requestDate;
    }

    /**
     * Instantiates a new request batch.
     */
    public RequestBatch() { // NOSONAR Only used for Hibernate
        super();
    }

    /**
     * Load state.
     *
     * @param requests the requests
     */
    public void loadState(@Valid @NotNull List<Request> requests) {
        if (!requests.stream().allMatch(r -> r.getRequestBatchId().equals(this.guid)))
            throw new IllegalArgumentException(String.format("All requests must have this Request Batch Id ( %s )", this.guid));

        this.allRequests = requests;

        this.errorSteps = requests.stream().filter(r -> r.getStatus().isErrorStatus()).collect(Collectors.toList());
        this.completedSteps = requests.stream().filter(r -> r.getStatus().isCompletedStatus()).collect(Collectors.toList());

        // TODO Check valid allRequests, then populate transient lists;
    }

    /**
     * All requests.
     *
     * @return the list
     */
    public List<Request> allRequests() {
        if (this.allRequests != null)
            return Collections.unmodifiableList(this.allRequests);
        throw new IllegalStateException("Request list not loaded. Use RequestBatch#loadState to populate the list.");
    }

    /**
     * Checks if is timed out.
     *
     * @param timeout the timeout
     * @return the boolean
     */
    public Boolean isTimedOut(Duration timeout) {
        return this.requestDate.plus(timeout).isBefore(LocalDateTime.now());
    }

    /**
     * Checks if is completed.
     *
     * @return the boolean
     */
    public Boolean isCompleted() {
        if (this.allRequests == null)
            throw new IllegalStateException("Request list not loaded. Use RequestBatch#loadState to populate the list.");
        return this.allRequests.stream().allMatch(r -> r.getStatus().isCompletedStatus());
    }

    /**
     * Checks if is importing.
     *
     * @return true, if is importing
     */
    public boolean isImporting() {
        return importing;
    }

    /**
     * Sets the importing.
     *
     * @param importing the new importing
     */
    public void setImporting(boolean importing) {
        this.importing = importing;
    }

    /**
     * Client name.
     *
     * @return the string
     */
    public String clientName() {
        return this.client;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    @MatchingEntityId
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the manual flag.
     *
     * @return the manual flag
     */
    public Boolean getManualFlag() {
        return manualFlag;
    }

    /**
     * Sets the manual flag.
     *
     * @param manualFlag the new manual flag
     */
    public void setManualFlag(Boolean manualFlag) {
        this.manualFlag = manualFlag;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the all requests.
     *
     * @return the all requests
     */
    public List<Request> getAllRequests() {
        return allRequests;
    }

    /**
     * Sets the all requests.
     *
     * @param allRequests the new all requests
     */
    public void setAllRequests(List<Request> allRequests) {
        this.allRequests = allRequests;
    }

}
