/*
 * Creation : 3 Feb 2020
 */
package com.inetpsa.w7t.domains.engine.utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class FileHandlingUtility.
 */
public final class FileHandlingUtility {
    /** The log. */
    private static Logger logger = LoggerFactory.getLogger(FileHandlingUtility.class.getName());

    /**
     * Creates the fs flag file.
     *
     * @param fsFlagFilePath    the fs flag file path
     * @param indusFlagFilePath the indus flag file path
     * @param prefix            the prefix
     * @param suffix            the suffix
     */
    public static void createFsFlagFile(String fsFlagFilePath, String indusFlagFilePath, String prefix, String suffix) {
        if (indusFlagFilePath != null && !indusFlagFilePath.isEmpty()) {
            File dir = new File(indusFlagFilePath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                logger.info("Indus FS Flag File Path: {}", indusFlagFilePath);
                logger.info("Some Database cleanup operations are running, stopping the current job...");
            } else {
                FileHandlingUtility.createFsFlag(fsFlagFilePath, prefix, suffix);
            }
        }

    }

    /**
     * Creates the fs flag.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param prefix         the prefix
     * @param suffix         the suffix
     */
    public static void createFsFlag(String fsFlagFilePath, String prefix, String suffix) {
        if (fsFlagFilePath != null && !fsFlagFilePath.isEmpty()) {

            try {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS");
                LocalDateTime now = LocalDateTime.now();
                String dateStr = now.format(dateTimeFormatter);
                String fileName = prefix + "_" + dateStr + "_" + suffix;
                FileHandlingUtility.createNewFile(fsFlagFilePath, fileName);
                logger.info("FS Flag File [{}] has been created successfully!", fileName);
            } catch (IOException e) {
                logger.error("Failed to create a file in {} : {}", fsFlagFilePath, e);
            }

        }
    }

    /**
     * Creates the new file.
     *
     * @param filePath the file path
     * @param fileName the file name
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void createNewFile(String filePath, String fileName) throws IOException {
        if (filePath != null && fileName != null) {
            Path newFilePath = Paths.get(filePath + File.separator + fileName + ".txt");
            if (!newFilePath.toFile().exists()) {
                Files.createFile(newFilePath);
            }
        } else {
            throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to create a file in the location "
                    + filePath + " with the file name " + fileName);
        }
    }

    /**
     * Delete application fs flag.
     *
     * @param fsFlagFilePath    the fs flag file path
     * @param indusFlagFilePath the indus flag file path
     * @param clientName        the client name
     */
    public static void deleteApplicationFsFlag(String fsFlagFilePath, String indusFlagFilePath, String clientName) {
        if (indusFlagFilePath != null && !indusFlagFilePath.isEmpty()) {
            File dir = new File(indusFlagFilePath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                logger.info("Indus FS Flag File Path: {}", indusFlagFilePath);
                logger.info("Some Database cleanup operations are running, stopping the current job...");
            } else {
                FileHandlingUtility.deleteApplicationFsFlagFile(fsFlagFilePath, clientName);
            }
        }
    }

    /**
     * Delete application fs flag file.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param clientName     the client name
     */
    public static void deleteApplicationFsFlagFile(String fsFlagFilePath, String clientName) {
        if (fsFlagFilePath != null && !fsFlagFilePath.isEmpty()) {
            File dir = new File(fsFlagFilePath);
            File[] dirContents = dir.listFiles();
            // fix jira-595
            if (dirContents != null && dirContents.length > 0) {
                Arrays.sort(dirContents, Comparator.comparingLong(File::lastModified));
                for (File file : dirContents) {
                    try {
                        if (file.getName().contains(clientName)) {
                            FileUtils.forceDelete(file);
                            logger.info("FS Flag File [{}] has been deleted from the location {}", file.getName(), fsFlagFilePath);
                            break;
                        }

                    } catch (IOException e) {
                        logger.error("Exception while deleting the file : {}", e);
                    }
                }
            }
        }
    }

    /**
     * Checks if is indus flag file present.
     *
     * @param indusFlagFilePath the indus flag file path
     * @return true, if is indus flag file present
     */
    public static boolean isIndusFlagFilePresent(String indusFlagFilePath) {
        if (indusFlagFilePath != null && !indusFlagFilePath.isEmpty()) {
            File dir = new File(indusFlagFilePath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Instantiates a new file handling utility.
     */
    private FileHandlingUtility() {
        super();
    }
}
