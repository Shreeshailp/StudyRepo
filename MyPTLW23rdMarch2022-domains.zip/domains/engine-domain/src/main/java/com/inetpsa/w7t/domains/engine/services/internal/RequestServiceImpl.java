/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.services.internal;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.core.services.UserService;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.NewtonEntity;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestEntity;
import com.inetpsa.w7t.domains.engine.model.request.BatchStatus;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.services.RequestService;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.model.Country;

/**
 * The Class RequestServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class RequestServiceImpl implements RequestService {

    /** The Constant FILE_ID_MIN. */
    private static final long FILE_ID_MIN = 1000000000L;
    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant FILE_ID_MAX. */
    private static final long FILE_ID_MAX = 9999999999L;

    /** The request repository. */
    @Inject
    private RequestRepository requestRepository;

    /** The newton repo. */
    @Inject
    @Jpa
    private Repository<NewtonEntity, Long> newtonRepo;

    /** The User service. */
    @Inject
    UserService userService;

    /** The Constant BOOL_YES. */
    private static final boolean BOOL_YES = true;

    /** The Constant W7T. */
    private static final String W7T = "W7T";

    /** The Constant REQ_ID_MIN. */
    private static final long REQ_ID_MIN = 10000000000000000L;

    /** The Constant REQ_ID_MAX. */
    private static final long REQ_ID_MAX = 99999999999999999L;

    /** The request batch repository. */
    @Inject
    private RequestBatchRepository requestBatchRepository;

    /** The request batch entity. */
    private RequestBatchEntity requestBatchEntity;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /** The gross vehicle mass repository. */
    @Inject
    private GrossVehicleMassRepository grossVehicleMassRepository;

    /** The number 0. */
    public static final int NUM_ZERO = 0;

    /** The number 1. */
    public static final int NUM_ONE = 1;

    /** The number 2. */
    public static final int NUM_TWO = 2;

    /** The number 3. */
    public static final int NUM_THREE = 3;

    /** The number 4. */
    public static final int NUM_FOUR = 4;

    /** The number 5. */
    public static final int NUM_FIVE = 5;

    @Inject
    private MaturityRepository maturityRepository;

    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    private static final String CLIENT = "MANUAL";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.RequestService#importRequest(java.util.List)
     */
    @Override
    public String importRequest(List<Request> requestsList) throws IOException {
        requestBatchEntity = new RequestBatchEntity();

        setBatchEntity(requestsList);

        String fileId = requestBatchEntity.getFileId();
        String userId = userService.getUserId();
        StringBuilder traceLog = new StringBuilder();
        traceLog.append(userId).append(" ").append(LocalDate.now().toString()).append(" ").append(LocalTime.now().toString()).append(" Simulation ")
                .append(requestsList.size()).toString();
        logger.info(traceLog.toString());

        return fileId;
    }

    /**
     * Sets the batch entity.
     *
     * @param requestsList the new batch entity
     */
    private void setBatchEntity(List<Request> requestsList) {
        String fileId = W7T + ThreadLocalRandom.current().nextLong(FILE_ID_MIN, FILE_ID_MAX + 1);
        UUID batchId = UUID.randomUUID();
        requestBatchEntity.setGuid(batchId);
        requestBatchEntity.setFileId(fileId);
        requestBatchEntity.setRequestDate(LocalDateTime.now());
        requestBatchEntity.setClient(CLIENT);
        requestBatchEntity.setManualFlag(BOOL_YES);
        requestBatchEntity.setStatus(BatchStatus.RECEIVED.getCode());
        // Added below two lines of code as part of JIRA-539 fix
        requestBatchEntity.setInternalFileId(fileId);
        requestBatchEntity.setCreatedDate(LocalDateTime.now().toString());

        requestBatchRepository.persist(requestBatchEntity);

        setRequestEntity(requestsList, fileId, batchId);

        requestBatchEntity.setStatus(BatchStatus.COMPLETE.getCode());
        requestBatchRepository.save(requestBatchEntity);
    }

    /**
     * Sets the request entity.
     *
     * @param requestsList the requests list
     * @param fileId the file id
     * @param batchId the batch id
     * @return the list
     */
    private void setRequestEntity(List<Request> requestsList, String fileId, UUID batchId) {
        for (Request request : requestsList) {

            RequestEntity requestEntity = new RequestEntity();
            try {
                UUID rId = UUID.randomUUID();
                requestEntity.setGuid(rId);

                request.setRequestId(W7T + ThreadLocalRandom.current().nextLong(REQ_ID_MIN, REQ_ID_MAX + 1));
                requestEntity.setRequestId(request.getRequestId());
                // fixed Jira-547
                logger.info("Request ID[{}] :  VIN : [{}],  {}", request.getRequestId(), request.getVin(), request);
                requestEntity.setRequestType(request.getRequestType());
                requestEntity.setVin(request.getVin());
                requestEntity.setEcomDate(request.getEcomDate());
                requestEntity.setExtendedTitle(request.getExtendedTitle());
                requestEntity.setTvvDesignation(request.getTvv());

                request.setFileId(fileId);
                requestEntity.setFileId(fileId);
                // Added below two lines of code as part of JIRA-514 fix
                request.setInternalFileId(fileId);
                requestEntity.setInternalFileId(fileId);

                request.setRequestBatchId(batchId);
                requestEntity.setRequestBatchId(batchId);

                request.setRequestDate(LocalDateTime.now());
                requestEntity.setRequestDate(LocalDateTime.now());

                if (!MaturityCheckUtility.determineMaturityCheckForSimulation(request, maturityRepository, clientMaturityRepository, logger,
                        CLIENT)) {
                    request.setStatus(RequestStatus.REQUEST_REJECTED);
                }
                requestEntity.setMaturity(request.getMaturity());

                if (!request.getStatus().equals(RequestStatus.REQUEST_REJECTED) && !titleIsValid(request)) {
                    request.setStatus(RequestStatus.REQUEST_REJECTED);
                }

                request.answerCode().ifPresent(requestEntity::setAnswerCode);
                request.answerDesignation().ifPresent(requestEntity::setAnswerDesignation);

                if (request.getStatus().equals(RequestStatus.REQUEST_REJECTED)) {
                    requestEntity.setStatus(RequestStatus.REQUEST_REJECTED);
                } else {
                    requestEntity.setStatus(RequestStatus.NEWTON_OK);
                }

                logger.info("{} {} Old Status = BLANK, New Status = {}({})", requestEntity.getRequestId(),
                        LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS), requestEntity.getStatus().getStatusCode(), requestEntity.getStatus());
            } catch (RuntimeException e) {
                requestEntity.setStatus(RequestStatus.REQUEST_REJECTED);
                requestEntity.setAnswerCode(RequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode());
                requestEntity.setAnswerDesignation(RequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
                LogErrorUtility.logTheError(logger, requestEntity.getRequestId(), requestEntity.getAnswerCode(),
                        requestEntity.getAnswerDesignation());
                logger.info("{} {} Old Status = BLANK, New Status = {}({})", requestEntity.getRequestId(),
                        LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS), requestEntity.getStatus().getStatusCode(), requestEntity.getStatus());
            }

            requestRepository.persist(requestEntity);
            setNewtonEntity(request, fileId);

        }
    }

    /**
     * Sets the newton entity.
     *
     * @param request the request
     * @param fileId the file id
     * @return the newton entity
     */
    private NewtonEntity setNewtonEntity(Request request, String fileId) {

        NewtonEntity newton = new NewtonEntity();

        newton.setExtendedTitle(request.getExtendedTitle());
        newton.setFileId(fileId);
        newton.setUnladenMass(request.getUnladenMass());
        newton.setEquipmentMass(request.getEquipmentMass());
        newton.setVehicleMass(request.getVehicleMass());
        newton.setUnladenSCx(request.getUnladenSCX());
        newton.setEquipmentSCx(request.getEquipmentSCX());
        newton.setVehicleSCx(request.getVehicleSCX());
        newton.setVehicleCRR(request.getVehicleCRR());
        newton.setReqId(request.getRequestId());

        if (request.getStatus().equals(RequestStatus.REQUEST_REJECTED)) {
            newton.setStatus(RequestStatus.REQUEST_REJECTED);
        } else {
            newton.setStatus(RequestStatus.NEWTON_OK);
        }

        newton.setRequestDate(new Date());
        newton.setAnswerDate(new Date());
        request.answerCode().ifPresent(newton::setAnswerCode);
        request.answerDesignation().ifPresent(newton::setAnswerDesignation);

        newtonRepo.persist(newton);
        return newton;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.RequestService#batchByFileId(java.lang.String)
     */
    @Override
    public Optional<RequestBatchEntity> batchByFileId(String fileId) {
        return requestBatchRepository.byfileId(fileId);
    }

    /**
     * Title is valid.
     *
     * @param item the item
     * @return true, if successful
     */
    @Override
    public boolean titleIsValid(Request item) {

        String title = item.getExtendedTitle();

        Matcher vehicleFamilyMatch = Pattern.compile("(....).{20}(?:.{7})*").matcher(title);
        Matcher wltpFamilyCodeMatch = Pattern.compile(".{24}(?:.{7})*(?:T8C(..)(..))(?:.{7})*").matcher(title);
        Matcher wltpFamilyIndexMatch = Pattern.compile(".{24}(?:.{7})*(?:T8D(..)(..))(?:.{7})*").matcher(title);
        Matcher countryMatch = Pattern.compile(".{24}(?:.{7})*(?:GG8(..)(..))(?:.{7})*").matcher(title);
        Matcher gvmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3N(..)(..))(?:.{7})*").matcher(title);
        Matcher fomMatch = Pattern.compile(".{24}(?:.{7})*(?:T3S(..)(..))(?:.{7})*").matcher(title);
        Matcher emmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3M(..)(..))(?:.{7})*").matcher(title);
        Matcher coherenceIndexMatch = Pattern.compile(".{24}(?:.{7})*(?:T8E(..)(..))(?:.{7})*").matcher(title);

        String requestNumber = item.getRequestId();

        RequestErrorCode error = null;

        boolean proceed = true;
        if (!wltpFamilyCodeMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FAMILY_CODE_MISSING.getRuleCode(),
                    RequestErrorCode.FAMILY_CODE_MISSING.getDescription());
            error = RequestErrorCode.FAMILY_CODE_MISSING;
            proceed = false;
        }

        else if (!wltpFamilyIndexMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FAMILY_INDEX_MISSING.getRuleCode(),
                    RequestErrorCode.FAMILY_INDEX_MISSING.getDescription());
            error = RequestErrorCode.FAMILY_INDEX_MISSING;
            proceed = false;
        }

        if (proceed) {
            String indexInString = wltpFamilyIndexMatch.group(1);
            if (!indexInString.matches("[0-9]{1,2}")) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getDescription());
                error = RequestErrorCode.UNKNOWN_FAMILY_COUPLE;
                proceed = false;
            }

            String code = wltpFamilyCodeMatch.group(1);
            if (proceed && !familyRepository.exists(code, Integer.parseInt(indexInString))) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getDescription());
                error = RequestErrorCode.UNKNOWN_FAMILY_COUPLE;
                proceed = false;
            }
        }

        if (proceed && !countryMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.PROGRAM_COUNTRY_MISSING.getRuleCode(),
                    RequestErrorCode.PROGRAM_COUNTRY_MISSING.getDescription());
            error = RequestErrorCode.PROGRAM_COUNTRY_MISSING;
            proceed = false;
        }
        if (proceed) {
            String country = countryMatch.group(1);
            Country existingCountry = countryRepository.byCodeAndCharacteristic(country, "GG8");
            Optional<Country> optionalCountry = Optional.ofNullable(existingCountry);
            if (!optionalCountry.isPresent()) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY.getRuleCode(),
                        RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY.getDescription());
                error = RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY;
                proceed = false;
            }
        }
        if (proceed && !coherenceIndexMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING.getRuleCode(),
                    RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING.getDescription());
            error = RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING;
            proceed = false;
        }
        if (proceed && !gvmMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.MTAC_MISSING.getRuleCode(),
                    RequestErrorCode.MTAC_MISSING.getDescription());
            error = RequestErrorCode.MTAC_MISSING;
            proceed = false;
        }
        if (proceed && !fomMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FOM_MISSING.getRuleCode(),
                    RequestErrorCode.FOM_MISSING.getDescription());
            error = RequestErrorCode.FOM_MISSING;
            proceed = false;
        }
        if (proceed && !emmMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.EMM_MISSING.getRuleCode(),
                    RequestErrorCode.EMM_MISSING.getDescription());
            error = RequestErrorCode.EMM_MISSING;
            proceed = false;
        }
        if (proceed && !vehicleFamilyMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                    RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            error = RequestErrorCode.EXTENDED_TITLE_INCORRECT;
            proceed = false;
        }
        if (proceed) {
            String mtacCode = gvmMatch.group(1);
            String vehicleFamily = vehicleFamilyMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, mtacCode, "T3N")) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_MTAC_VALUE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_MTAC_VALUE.getDescription());
                error = RequestErrorCode.UNKNOWN_MTAC_VALUE;
                proceed = false;
            }

        }
        if (proceed) {
            String fomCode = fomMatch.group(1);
            String vehicleFamily = vehicleFamilyMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, fomCode, "T3S")) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_FOM_VALUE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_FOM_VALUE.getDescription());
                error = RequestErrorCode.UNKNOWN_FOM_VALUE;
                proceed = false;
            }

        }
        if (proceed) {
            String emmCode = emmMatch.group(1);
            String vehicleFamily = vehicleFamilyMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, emmCode, "T3M")) {
                LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_EMM_VALUE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_EMM_VALUE.getDescription());
                error = RequestErrorCode.UNKNOWN_EMM_VALUE;
                proceed = false;
            }

        }
        if (!proceed)
            item.useAnswer(LocalDateTime.now(), error.getRuleCode(), error.getDescription());

        return proceed;
    }

}