/*
 * Creation : 23 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import org.seedstack.business.domain.Create;
import org.seedstack.business.domain.GenericFactory;

/**
 * A factory for creating Request objects.
 */
public interface RequestFactory extends GenericFactory<Request> {

    /**
     * Creates a new Request object.
     *
     * @param requestBatchId the request batch id
     * @param manualRequest the manual request
     * @param requestType the request type
     * @param fileId the file id
     * @param clientRequestNumber the client request number
     * @param requestDate the request date
     * @param vin the vin
     * @param ecomDate the ecom date
     * @param extendedTitle the extended title
     * @return the request
     */
    @Create
    Request createRequest(UUID requestBatchId, Boolean manualRequest, RequestType requestType, String fileId, String clientRequestNumber,
            LocalDateTime requestDate, String vin, LocalDate ecomDate, String extendedTitle);// NOSONAR [Won't fix] Methods should not have too many
                                                                                             // parameters
}
