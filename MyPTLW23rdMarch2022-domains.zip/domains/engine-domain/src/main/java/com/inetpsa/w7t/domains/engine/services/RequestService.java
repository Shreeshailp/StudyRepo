/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestBatchEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;

/**
 * The interface Request Service.
 */
@Service
public interface RequestService {

    /**
     * Import request.
     *
     * @param requestsList the requests list
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    String importRequest(List<Request> requestsList) throws IOException;

    /**
     * Batch status check.
     *
     * @param fileId the file id
     * @return the request batch
     */
    Optional<RequestBatchEntity> batchByFileId(String fileId);

    /**
     * Title is valid.
     *
     * @param item the item
     * @return true, if successful
     */
    boolean titleIsValid(Request item);

}
