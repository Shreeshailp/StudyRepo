/*
 * Creation : 29 mai 2017
 */
package com.inetpsa.w7t.domains.engine.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum NewtonAnswerErrorCode.
 */
public enum NewtonAnswerErrorCode implements ErrorCode {

    /** The request no missing. */
    REQUEST_NO_MISSING(301, "NEWTON request number missing", "ERRW301"),
    /** The request no unknown. */
    REQUEST_NO_UNKNOWN(302, "Unknown Newton Request Number", "ERRW302"),
    /** The answer code missing. */
    ANSWER_CODE_MISSING(303, " NEWTON answer code missing", "ERRW303"),
    /** The request no already processed. */
    REQUEST_NO_ALREADY_PROCESSED(304, "Newton Request Number already processed", "ERRW304"),
    /** The timeout. */
    TIMEOUT(501, "WLTP timeout", "ERRW501"),
    /** The calculation success. */
    CALCULATION_SUCCESS(001, "WLTP calculation successful", "OKW00001");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new request error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    NewtonAnswerErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
