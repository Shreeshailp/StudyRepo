/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;

/**
 * The Interface NewtonRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface RequestRepository extends GenericRepository<RequestEntity, UUID> {

    /**
     * Save.
     * 
     * @param request the request object to be saved
     * @return the request
     */
    Request save(Request request);

    /**
     * Steps.
     *
     * @param limit the limit
     * @return the optional
     */
    Optional<List<Request>> steps(int limit);

    /**
     * Request exists.
     * 
     * @param requestNumber the identity of the request to be retrieved
     * @return true if exists, false otherwise
     */
    boolean requestExists(String requestNumber);

    /**
     * File ID exists.
     * 
     * @param fileId the file identifier those will be checked
     * @return true if exists, false otherwise
     */
    boolean fileIdExists(String fileId);

    /**
     * By Request number.
     * 
     * @param number the requestNumber
     * @return list of RequestEntity, optional empty otherwise
     */
    Optional<RequestEntity> byRequestNumber(String number);

    /**
     * By Request Batch ID.
     *
     * @param batchId          the batch identifier to be used to list of the requests
     * @param filteredStatuses the filtered statuses
     * @return List of Request, empty optional otherwise
     */
    Optional<List<Request>> byRequestBatchId(UUID batchId, List<RequestStatus> filteredStatuses);

    /**
     * By Request Batch ID.
     * 
     * @param reqId the identifier of the batch, that we need to retrieve
     * @return the request retrieved
     */
    Request byRequestId(String reqId);

    /**
     * By request batch ids.
     *
     * @param list         the list
     * @param timeoutables the timeoutables
     * @return the optional
     */
    Optional<List<Request>> byRequestBatchIds(List<UUID> list, List<RequestStatus> timeoutables);

    /**
     * Gets the steps.
     *
     * @param stepCount     the step count
     * @param bcvResMachine the bcv res machine
     * @return the steps
     */
    Optional<List<Request>> getSteps(int stepCount, String bcvResMachine);

    /**
     * Gets the rejected requests.
     *
     * @param internalFileId   the internal file id
     * @param newtonResMacName the newton res mac name
     * @return the rejected requests
     */
    Optional<List<Request>> getRejectedRequests(String internalFileId, String newtonResMacName);

    /**
     * Update answer sent status.
     *
     * @param internalFileId the internal file id
     * @return the int
     */
    int updateAnswerSentStatus(String internalFileId);

    /**
     * Gets the all requests.
     *
     * @param internalFileId the internal file id
     * @return the all requests
     */
    Optional<List<Request>> getAllRequests(String internalFileId);

    /**
     * Fetch comptool data count.
     *
     * @param newtonResponseMachineName the newton response machine name
     * @return the object[]
     */
    Object[] fetchComptoolDataCount(String newtonResponseMachineName);

    /**
     * Gets the all requests count from database.
     *
     * @param internalFileId the internal file id
     * @return the all requests count from database
     */
    int getAllRequestsCountFromDatabase(String internalFileId);

    /**
     * Clear session.
     */
    public void clearSession();

    /**
     * Update calculation status.
     *
     * @param statusCode        the status code
     * @param answerCode        the answer code
     * @param answerDesignation the answer designation
     * @param requestId         the request id
     * @param internalFileId    the internal file id
     * @return the int
     */
    int updateCalculationStatus(int statusCode, String answerCode, String answerDesignation, String requestId, String internalFileId);

}