/*
 * Creation : 28 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.Map;

import com.google.common.collect.ImmutableMap;

/**
 * The Class CalculationConstants.
 */
public final class CalculationConstants {

    /** The Constant CYCLE_ENERGY_CODE. */
    public static final String CYCLE_ENERGY_CODE = "CE";

    /** The Constant MASS_CODE. */
    public static final String MASS_CODE = "MASSE";

    /** The Constant S. */
    public static final String S = "S";

    /** The Constant H. */
    public static final String H = "H";

    /** The Constant L. */
    public static final String L = "L";

    /** The Constant UMASS_CODE. */
    public static final String UMASS_CODE = "UMASSE";

    /** The Constant EMASS_CODE. */
    public static final String EMASS_CODE = "EMASSE";

    /** The Constant TMASS_CODE. */
    public static final String TMASS_CODE = "TMASSE";

    /** The Constant SCX_CODE. */
    public static final String SCX_CODE = "SCX";

    /** The Constant USCX_CODE. */
    public static final String USCX_CODE = "USCX";

    /** The Constant ESCX_CODE. */
    public static final String ESCX_CODE = "ESCX";

    /** The Constant CRR_CODE. */
    public static final String CRR_CODE = "CRR";

    // lot23 depol change
    /** The Constant CXTR_CODE. */
    public static final String CXTR_CODE = "CXTR";

    /** The Constant CRREC_CODE. */
    // public static final String CRREC_CODE = "CRREC"; // This line has been commented as part of JIRA-603 Fix

    /** The Constant VREF. */
    public static final String VREF = "VREF";

    /** The Constant ROADLOAD_TYPE. */
    public static final String ROADLOAD_TYPE = "ROADLOAD";

    /** The Constant ROADLOAD_TYPE_MRL. */
    public static final String ROADLOAD_TYPE_MRL = "MRL";

    /** The Constant ROADLOAD_TYPE_IRL. */
    public static final String ROADLOAD_TYPE_IRL = "IRL";

    /** The Constant ROADLOAD_TYPE_DRL. */
    public static final String ROADLOAD_TYPE_DRL = "DRL";

    /** The Constant F0_CODE. */
    public static final String F0_CODE = "F0";

    /** The Constant F1_CODE. */
    public static final String F1_CODE = "F1";

    /** The Constant F2_CODE. */
    public static final String F2_CODE = "F2";

    /** The Constant PHASE_CODE. */
    public static final String PHASE_CODE = "PSE";

    /** The Constant CO2. */
    public static final String CO2 = "CO2";

    /** The Constant LUGGAGE_MASS. */
    public static final int LUGGAGE_MASS = 25;

    /** The Constant PERSON_MASS. */
    public static final int PERSON_MASS = 75;

    /** The Constant ROUND_CE. */
    public static final int ROUND_CE = 0;

    /** The Constant ROUND_F0. */
    public static final int ROUND_F0 = 1;

    /** The Constant ROUND_F1. */
    public static final int ROUND_F1 = 4;

    /** The Constant ROUND_F2. */
    public static final int ROUND_F2 = 5;

    /** The Constant ROUND_F3. */
    public static final int ROUND_F3 = 3;

    /** The Constant TEST_MASS_COEFFICIENT. */
    public static final double TEST_MASS_COEFFICIENT = 1.03;

    /** The Constant VEHICLE_FAMILY_LENGTH. */
    public static final int VEHICLE_FAMILY_LENGTH = 4;

    /** The Constant ROUND_TO_0. */
    private static final String ROUND_TO_0 = "0";

    /** The Constant ROUND TO 1 decimal position. */
    private static final String ROUND_TO_1 = "0.0";

    /** The Constant ROUND_TO_2 decimal position. */
    private static final String ROUND_TO_2 = "0.00";

    /** The Constant ROUND_TO_3 decimal position. */
    private static final String ROUND_TO_3 = "0.000";

    /** The Constant ROUND_TO_4. */
    private static final String ROUND_TO_4 = "0.0000";

    /** The Constant ROUND_TO_5. */
    private static final String ROUND_TO_5 = "0.00000";

    /** The Constant COMPL. */
    public static final String COMPL = "COMPL";

    /** The Constant FDSC. */
    public static final String FDSC = "FDSC";

    /** The Constant SPEEDLIMIT. */
    public static final String SPEEDLIMIT = "SPEEDLIMIT";

    /** The Constant VMAX. */
    public static final String VMAX = "VMAX";

    /** The Constant MTAC. */
    public static final String MTAC = "MTAC";

    /** The Constant EMPTYM. */
    public static final String EMPTYM = "EMPTYM";

    /** The Constant MOPT. */
    public static final String MOPT = "MOPT";

    /** The Constant CODE_DEPOL. */
    public static final String CODE_DEPOL = "CODE_DEPOL";

    /** The Constant CXTR. */
    private static final String CXTR = "CXTR";

    /** The Constant phyQuantityRoundingMap. */
    public static final Map<String, String> phyQuantityRoundingMap = ImmutableMap.<String, String>builder().put(F0_CODE, ROUND_TO_1)
            .put(F1_CODE, ROUND_TO_4).put(F2_CODE, ROUND_TO_5).put(MASS_CODE, ROUND_TO_0).put(UMASS_CODE, ROUND_TO_1).put(EMASS_CODE, ROUND_TO_1)
            .put(CRR_CODE, ROUND_TO_1).put(SCX_CODE, ROUND_TO_3).put(USCX_CODE, ROUND_TO_3).put(ESCX_CODE, ROUND_TO_3).put(TMASS_CODE, ROUND_TO_0)
            .put(PHASE_CODE, ROUND_TO_2).put(H, ROUND_TO_3).put(L, ROUND_TO_3).put(S, ROUND_TO_3).put(CXTR, ROUND_TO_2).build();

    /** The Constant resultRoundingMap. */
    public static final Map<Integer, String> resultRoundingMap = ImmutableMap.<Integer, String>builder().put(0, ROUND_TO_0).put(1, ROUND_TO_1)
            .put(2, ROUND_TO_2).put(3, ROUND_TO_3).put(4, ROUND_TO_4).put(5, ROUND_TO_5).build();

    /** The Constant propertyNameToCodeMap. */
    public static final Map<String, String> propertyNameToCodeMap = ImmutableMap.<String, String>builder().put("VehicleMass", MASS_CODE)
            .put("UnladenMass", UMASS_CODE).put("EquipmentMass", EMASS_CODE).put("VehicleSCx", SCX_CODE).put("UnladenSCx", USCX_CODE)
            .put("EquipmentSCx", ESCX_CODE).put("VehicleCRR", CRR_CODE).build();

    /** The Constant mtpRoundingMap. */
    public static final Map<String, Integer> mtpRoundingMap = ImmutableMap.<String, Integer>builder().put("CE", 0).put("FC", 1).put("FCB", 1)
            .put("FCG", 1).put("CO2", 0).put("CO2B", 0).put("CO2G", 0).put("EC", 0).put("PER", 0).put("FCCS", 1).put("CO2CS", 0).put("FCCD", 1)
            .put("CO2CD", 0).put("ECCD", 0).put("UFECCD", 0).put("WCFC", 1).put("WCCO2", 0).put("UFEC", 0).put("AER", 0).put("EAER", 0)
            .put("AERCD", 0).put("CRCD", 0).put("ECDCCD", 0).put("ECDC", 0).build();

    /** The Constant amplitudeUpperLimit. */
    public static final int AMPLITUDE_UPPER_LIMIT = 30;

    /** The Constant amplitudeVHighPercent. */
    public static final double AMPLITUDE_VHIGH_PERCENTAGE = 0.2;

    /** The Constant minEmissionRange. */
    public static final int MIN_EMISSION_RANGE = 3;

    /** The Constant maxEmissionRange. */
    public static final int MAX_EMISSION_RANGE = 3;

    /** The Constant MATURITY. */
    public static final String MATURITY = "MATURITY";

    /** The Constant CO2CS. */
    public static final String CO2CS = "CO2CS";

    /** The Constant EC. */
    public static final String EC = "EC";

    /** The Constant PER. */
    public static final String PER = "PER";

    /** The Constant B0. */
    public static final double B0 = 1.375;

    /** The Constant VHIGH. */
    public static final String VHIGH = "VHIGH";

    /** The Constant VLOW. */
    public static final String VLOW = "VLOW";

    /** The Constant CO2_EMISSION. */
    public static final String CO2_EMISSION = "CO2";

    /** The Constant FUEL_CONSUMPTION. */
    public static final String FUEL_CONSUMPTION = "FC";

    /** The Constant CX_MAX_LIMIT. */
    public static final String CX_MAX_LIMIT = "99";

    /** The Constant CX_MIN_LIMIT. */
    public static final String CX_MIN_LIMIT = "0";

    /**
     * Instantiates a new calculation constants.
     */
    private CalculationConstants() {
    }
}
