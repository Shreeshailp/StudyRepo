/*
 * Creation : 29 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import org.seedstack.business.domain.BaseValueObject;

/**
 * The Class VehicleBoundary.
 */
public class VehicleBoundary extends BaseValueObject {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4358210524545503635L;

    /** The cycle energy. */
    private double cycleEnergy;

    /** The measures. */
    private Map<UUID, Double> measures;

    /**
     * Instantiates a new vehicle boundary.
     *
     * @param cycleEnergy the cycle energy
     * @param measures the measures
     */
    public VehicleBoundary(double cycleEnergy, Map<UUID, Double> measures) {
        this.cycleEnergy = cycleEnergy;
        this.measures = measures;
    }

    /**
     * Gets the cycle energy.
     *
     * @return the cycle energy
     */
    public double getCycleEnergy() {
        return cycleEnergy;
    }

    /**
     * Gets the measures.
     *
     * @return the measures
     */
    public Map<UUID, Double> getMeasures() {
        return measures;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hashCode(cycleEnergy);
        result = prime * result + Objects.hashCode(measures);
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        VehicleBoundary other = (VehicleBoundary) o;
        return Objects.equals(cycleEnergy, other.cycleEnergy) && Objects.equals(measures, other.measures);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */
    @Override
    public String toString() {
        return "VehicleBoundary [cycleEnergy=" + cycleEnergy + ", measures=" + measures + "]";
    }
}
