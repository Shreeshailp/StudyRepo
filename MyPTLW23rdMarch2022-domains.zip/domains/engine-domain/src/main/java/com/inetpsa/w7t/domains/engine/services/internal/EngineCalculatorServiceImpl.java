/*
 * Creation : 27 mars 2017
 */
package com.inetpsa.w7t.domains.engine.services.internal;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.mtpRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntToDoubleFunction;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.inject.Inject;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.lang3.math.NumberUtils;
import org.javatuples.Pair;
import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.model.CycleProfile;
import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedDataFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase.CalculatedMeasure;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationFactory;
import com.inetpsa.w7t.domains.engine.model.calculation.ConversionData;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.VehicleBoundary;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.services.VehicleBoundaryService;
import com.inetpsa.w7t.domains.engine.shared.ConversionDataCodes;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.enginesettings.model.ParameterDetails;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.details.PhysicalQuantityValue;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;
import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycleProfile;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PayloadPercentageRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;
import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.model.Parameter;
import com.inetpsa.w7t.domains.references.model.PayloadPercentage;
import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

/**
 * The Class EngineCalculatorServiceImpl.
 */
public class EngineCalculatorServiceImpl implements EngineCalculatorService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The family repository.. */
    @Inject
    private FamilyRepository familyRepository;

    /** The cycle details repository. */
    @Inject
    private CycleDetailsRepository cycleDetailsRepository;

    /** The cycle phase repository. */
    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    /** The payload percentage repository. */
    @Inject
    private PayloadPercentageRepository payloadPercentageRepository;

    /** The gross vehicle mass repository. */
    @Inject
    private GrossVehicleMassRepository grossVehicleMassRepository;

    /** The destination details repository. */
    @Inject
    private DestinationDetailsRepository destinationDetailsRepository;

    /** The vehicle type repository. */
    @Inject
    private VehicleTypeRepository vehicleTypeRepository;

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The vehicle boundary service. */
    @Inject
    private VehicleBoundaryService vehicleBoundaryService;

    /** The calculated data factory. */
    @Inject
    private CalculatedDataFactory calculatedDataFactory;

    /** The calculation factory. */
    @Inject
    private CalculationFactory calculationFactory;

    /** The tvv repository. */
    @Inject
    private TVVRepository tvvRepository;

    /** The test vehicle type repository. */
    @Inject
    private TestVehicleTypeRepository testVehicleTypeRepository;

    /** The physical quantity type repository. */
    @Inject
    PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The parameter repository. */
    @Inject
    private ParameterRepository parameterRepository;

    /** The generated cycle repository. */
    @Inject
    private GeneratedCycleRepository generatedCycleRepository;

    /** The depol repository. */
    @Inject
    private DepolRepository depolRepository;

    /** The i 1. */
    private int i1;

    /** The r 0 downscale. */
    private double r0Downscale;

    /** The a 1 downscale. */
    private double a1Downscale;

    /** The b 1 downscale. */
    private double b1Downscale;

    /**
     * The request Id. Default value is 'REQUEST' for the web service calls or other clients which bypasses the assignment.
     */

    /** The Constant CO2_LIMIT_VIOLATED. */

    /** The Constant F0_LOG. */
    private static final String F0_LOG = "Request ID[{}]: Road Load Calculation - F0 : {} rounded to {}";

    /** The Constant F1_LOG. */
    private static final String F1_LOG = "Request ID[{}]: Road Load Calculation - F1 : {} rounded to {}";

    /** The Constant F2_LOG. */
    private static final String F2_LOG = "Request ID[{}]: Road Load Calculation - F2 : {} rounded to {}";

    /** The Constant I1_DOWN_SCALE_PMAX_TIME. */
    private static final String I1_DOWN_SCALE_PMAX_TIME = "i1_downscale_pmax_time";

    /** The Constant A1_DOWN_SCALE. */
    private static final String A1_DOWN_SCALE = "a1_downscale";

    /** The Constant B1_DOWN_SCALE. */
    private static final String B1_DOWN_SCALE = "b1_downscale";

    /** The Constant R0_DOWN_SCALE. */
    private static final String R0_DOWN_SCALE = "r0_downscale";

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The Constant DOWN_SCALE. */
    public static final String DOWN_SCALE = "_D";

    /** The Constant SPEED_LIMITING. */
    public static final String SPEED_LIMITING = "_V";

    /** The Constant ZERO. */
    public static final int ZERO = 0;

    /** The Constant THIRTY. */
    public static final int THIRTY = 30;

    /** The Constant THREE. */
    public static final int THREE = 3;

    /** The Constant TWENTY. */
    public static final int TWENTY = 20;

    /** The Constant FIVE. */
    public static final int FIVE = 5;

    /** The Constant FETCH_TVV_TIME_LOG. */
    private static final String FETCH_TVV_TIME_LOG = "Request ID[{}]: StopWatch - TVV details fetching took {}ms";

    /**
     * The Enum RoadLoadTypes.
     */
    private enum RoadLoadTypes {

        /** The irl. */
        IRL("IRL"),
        /** The drl. */
        DRL("DRL"),
        /** The mrl. */
        MRL("MRL");

        /** The road load type. */
        String roadLoadType;

        /**
         * Instantiates a new road load types.
         *
         * @param roadLoadType the road load type
         */
        private RoadLoadTypes(String roadLoadType) {
            this.roadLoadType = roadLoadType;
        }

    }

    /**
     * The Enum VehicleTypes.
     */
    private enum VehicleTypes {

        /** The hyre. */
        HYRE("HYRE"),

        /** The elec. */
        ELEC("ELEC"),

        /** The conv. */
        CONV("CONV");

        /** The vehicle type. */
        String vehicleType;

        /**
         * Instantiates a new vehicle types.
         *
         * @param vehicleType the vehicle type
         */
        private VehicleTypes(String vehicleType) {
            this.vehicleType = vehicleType;
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.EngineCalculatorService#calculate(com.inetpsa.w7t.domains.engine.model.request.Request)
     */
    @Override
    public Calculation calculate(@Valid Request request) {
        return this.calculate(
                new Version(request.getEcomDate(), request.getExtendedTitle(), request.getRequestType(), "GG8", request.getTvv(), new ArrayList<>()),
                request.physicalQuantities().orElseThrow(
                        () -> logAndCreateException(request.getRequestId(), WltpEngineCalculatorErrorCode.PHYSICAL_DATA_MISSING)),
                request);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.EngineCalculatorService#calculate(com.inetpsa.w7t.domains.engine.model.calculation.Version,
     *      java.util.List, java.lang.String)
     */
    @Override
    public Calculation calculate(@Valid Version version, List<EnginePhysicalQuantity> physicalQuantities, String requestId) {

        if (logger.isInfoEnabled())
            logger.info("Request ID[{}]: Request - ecom date({}), family code/index({}, {}), extended title({})", requestId, version.getEcomDate(),
                    version.getFamily(requestId), version.getIndex(requestId), version.extendedTitle().orElse(null));
        logger.info("Request ID[{}]: Physical Quantities: {}", requestId, physicalQuantities);
        logger.info("Request ID[{}]: Conversion data: {}", requestId, version.getConversionData());

        return this.calculate(calculationFactory.withVersion(version).setPhysicalQuantities(physicalQuantities), requestId);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.services.EngineCalculatorService#calculate(com.inetpsa.w7t.domains.engine.model.calculation.Version,
     *      java.util.List, java.lang.String)
     */
    @Override
    public Calculation calculate(@Valid Version version, List<EnginePhysicalQuantity> physicalQuantities, Request request) {

        if (logger.isInfoEnabled())
            logger.info("Request ID[{}]: Request - ecom date({}), family code/index({}, {}), extended title({})", request.getRequestId(),
                    version.getEcomDate(), version.getFamily(request.getRequestId()), version.getIndex(request.getRequestId()),
                    version.extendedTitle().orElse(null));
        logger.info("Request ID[{}]: Physical Quantities: {}", request.getRequestId(), physicalQuantities);
        logger.info("Request ID[{}]: Conversion data: {}", request.getRequestId(), version.getConversionData());

        return this.calculate(calculationFactory.withVersion(version).setPhysicalQuantities(physicalQuantities), request);
    }

    /**
     * Calculate all the data.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */
    private Calculation calculate(Calculation calculation, String requestId) {

        StopWatch sw = new StopWatch();
        sw.start();
        // Added the below code as part of the 11825 work order(Depol Changes) Starts here
        boolean isDepolCodeValueExists = depolCodeValueExists(calculation);

        // Added the below code as part of the 11825 work order(Depol Changes) Ends here

        this.retrieveData(calculation, requestId);

        // Added the below code as part of the 11825 work order(Depol Changes) Starts here
        // if ("Y".equalsIgnoreCase(calculation.getDepol())) {
        if (isDepolCodeValueExists) {
            this.controlDepolLimitsForCarConverters(calculation, requestId);
        }
        // Added the below code as part of the 11825 work order(Depol Changes) Ends here

        // String energyClass = this.calculateEnergyEfficiency(calculation, requestId);This line has been commented as part of JIRA-603 Fix

        // CAP-23272(Regulatory Changes) Starts here
        boolean vlvhFlag = false;
        boolean incompleteTestMassFlag = false;
        if (this.checkVlowAndVhighCEValues(calculation, requestId)) {
            vlvhFlag = true;
        }
        List<ConversionData> conversionData = calculation.getVersion().getConversionData();
        String inCompleteflag = calculation.getTvvDetails().getTvvCompleteFlag();
        logger.info("Request ID[{}]: TVV Vehicle Flag : {}", requestId, inCompleteflag);
        if ((conversionData == null || conversionData.isEmpty()) && "I".equalsIgnoreCase(inCompleteflag) && !vlvhFlag) {
            incompleteTestMassFlag = true;
            manageIncompleteVehicle(calculation, requestId);
        }
        if (incompleteTestMassFlag) {
            this.calculateRoadLoad(calculation, requestId);
        } else if (!vlvhFlag) {
            this.calculateTestMass(calculation, requestId);
            this.calculateRoadLoad(calculation, requestId);
        }

        // Added the below if conditions and also a method inside if conditions as part of the prod incident(INCI10638035) fix -Starts Here
        if ("C".equalsIgnoreCase(inCompleteflag) && vlvhFlag) {
            this.setT3Values(calculation, requestId);

        }
        if ("I".equalsIgnoreCase(inCompleteflag) && vlvhFlag) {
            this.setT3Values(calculation, requestId);
        }
        // Added the above if conditions and also a method inside if conditions as part of the prod incident(INCI10638035) fix -Ends Here
        // CAP-23272(Regulatory Changes) ends here

        this.calculatePhases(calculation, requestId);
        // fixed Jira - 489 starts here
        String completeflag = calculation.getTvvDetails().getTvvCompleteFlag();
        if (!vlvhFlag && (!"I".equalsIgnoreCase(completeflag)
                || (calculation.getVersion().getConversionData() != null && !calculation.getVersion().getConversionData().isEmpty()))) {
            this.checkCO2Controls(calculation, requestId);
        }
        // fixed Jira - 489 end here
        sw.stop();
        logger.info("Request ID[{}]: All calculations complete", requestId);
        logger.info("Request ID[{}]: StopWatch - All calculation took {}ms", requestId, sw.getTime());

        return calculation;
    }

    /**
     * Sets the T 3 values.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     */
    private void setT3Values(Calculation calculation, String requestId) {
        Version version = calculation.getVersion();
        String vehicleFamily = version.getVehicleFamily(requestId);
        String emptyMassCode = version.getEmptyMass(requestId);
        String fullMassCode = version.getFullOptionsMass(requestId);

        String t3sValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, fullMassCode, "T3S")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_FOM_FOUND)).getValue();

        String t3mValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, emptyMassCode, "T3M")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_EM_FOUND)).getValue();

        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3sValue) && Double.parseDouble(t3sValue) >= 0) {
            calculation.setmOPT(String.valueOf(Integer.parseInt(t3sValue)));
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_FOM_FOUND);
        }
        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3mValue) && Double.parseDouble(t3mValue) > 0) {
            calculation.setEmptyMass(String.valueOf(Integer.parseInt(t3mValue)));
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_EM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_EM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_EM_FOUND);
        }

    }

    /**
     * Manage incomplete vehicle.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     */
    private void manageIncompleteVehicle(Calculation calculation, String requestId) {

        String completeflag = calculation.getTvvDetails().getTvvCompleteFlag();

        String vehicleCategory = calculation.getTvvDetails().getTvvVehicleCategory();

        String roadLoadType = calculation.getFamily().getRoadLoad();

        if ("I".equalsIgnoreCase(completeflag) && "N1".equalsIgnoreCase(vehicleCategory)
                && RoadLoadTypes.DRL.roadLoadType.equalsIgnoreCase(roadLoadType)) {
            this.calculateTestMassForN1(calculation, requestId);
        } else if ("I".equalsIgnoreCase(completeflag) && "N1".equalsIgnoreCase(vehicleCategory)
                && RoadLoadTypes.MRL.roadLoadType.equalsIgnoreCase(roadLoadType)) {
            this.calculateTestMassForN1(calculation, requestId);
        } else if ("I".equalsIgnoreCase(completeflag) && "N1".equalsIgnoreCase(vehicleCategory)
                && RoadLoadTypes.IRL.roadLoadType.equalsIgnoreCase(roadLoadType)) {
            this.calculateTestMassForN1(calculation, requestId);
        } else if ("I".equalsIgnoreCase(completeflag) && !"N1".equalsIgnoreCase(vehicleCategory)) {
            this.calculateTestMass(calculation, requestId);
        }

    }

    /**
     * Calculate test mass for N 1.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */
    private Calculation calculateTestMassForN1(Calculation calculation, String requestId) {
        // CALCULWLTP-761 - Fix Starts Here
        Version version = calculation.getVersion();
        String vehicleFamily = version.getVehicleFamily(requestId);
        String emptyMassCode = version.getEmptyMass(requestId);
        String fullMassCode = version.getFullOptionsMass(requestId);

        String t3sValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, fullMassCode, "T3S")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_FOM_FOUND)).getValue();

        String t3mValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, emptyMassCode, "T3M")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_EM_FOUND)).getValue();
        GrossVehicleMass t3n = grossVehicleMassRepository
                .byFamilyCodeAndCharacteristic(vehicleFamily, calculation.getVersion().getGrossVehicleMass(requestId), "T3N")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_GVM_FOUND));
        String t3nValue = null;
        if (t3n != null) {
            t3nValue = t3n.getValue();
        }

        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3sValue) && Double.parseDouble(t3sValue) >= 0) {
            calculation.setmOPT(String.valueOf(Integer.parseInt(t3sValue)));
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_FOM_FOUND);
        }
        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3mValue) && Double.parseDouble(t3mValue) > 0) {
            calculation.setEmptyMass(String.valueOf(Integer.parseInt(t3mValue)));
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_EM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_EM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_EM_FOUND);
        }
        // CALCULWLTP-761 - Fix Ends Here
        int mroBase = Integer.parseInt(t3mValue) + CalculationConstants.PERSON_MASS;
        logger.info("Request ID[{}]: T3M : {} MROBase : {}", requestId, t3mValue, mroBase);
        int tpmlBase = Integer.parseInt(t3nValue);
        logger.info("Request ID[{}]: T3N : {} TPMLBase : {}", requestId, t3nValue, tpmlBase);
        double mvl = 0.28 * (tpmlBase - (mroBase * CalculationConstants.B0 + CalculationConstants.LUGGAGE_MASS));
        logger.info("Request ID[{}]: MVL : {}", requestId, mvl);
        int testMass = BigDecimal.valueOf(mroBase * CalculationConstants.B0 + CalculationConstants.LUGGAGE_MASS + mvl)
                .setScale(0, BigDecimal.ROUND_HALF_UP).intValue();

        logger.info("Request ID[{}]: Test Mass Calculation for N1 category - Final Test mass({})", requestId, testMass);

        calculation.setCalculatedData(calculatedDataFactory.withTestMass(testMass));
        return calculation;
    }

    /**
     * Depol code value exists.
     *
     * @param calculation the calculation
     * @return true, if successful
     */
    private boolean depolCodeValueExists(Calculation calculation) {
        List<ConversionData> conversionData = calculation.getVersion().getConversionData();
        boolean isDepolValueExists = false;
        if (conversionData != null && !conversionData.isEmpty()) {
            Optional<String> depolValue = getCarConvertorValue(conversionData, ConversionDataCodes.DEPOL.name());
            if (depolValue.isPresent()) {
                String depolValueStr = depolValue.get();
                if ("Y".equalsIgnoreCase(depolValueStr)) {
                    calculation.setDepol(depolValueStr);
                    isDepolValueExists = true;
                }
            }
        }
        return isDepolValueExists;
    }

    /**
     * Calculate all the data.
     *
     * @param calculation the calculation
     * @param request     the request
     * @return the calculation
     */
    private Calculation calculate(Calculation calculation, Request request) {

        StopWatch sw = new StopWatch();
        sw.start();

        this.retrieveData(calculation, request.getRequestId());

        // String energyClass = this.calculateEnergyEfficiency(calculation, request.getRequestId()); This line has been commented as part of JIRA-603
        // Fix

        // CAP-23272(Regulatory Changes) Starts here
        boolean vlvhFlag = false;
        boolean incompleteTestMassFlag = false;
        if (this.checkVlowAndVhighCEValues(calculation, request.getRequestId())) {
            vlvhFlag = true;
        }
        List<ConversionData> conversionData = calculation.getVersion().getConversionData();
        String inCompleteflag = calculation.getTvvDetails().getTvvCompleteFlag();
        logger.info("Request ID[{}]: TVV Vehicle Flag : {}", request.getRequestId(), inCompleteflag);
        if ((conversionData == null || conversionData.isEmpty()) && "I".equalsIgnoreCase(inCompleteflag) && !vlvhFlag) {
            incompleteTestMassFlag = true;
            manageIncompleteVehicle(calculation, request.getRequestId());
        }
        if (incompleteTestMassFlag) {
            this.calculateRoadLoad(calculation, request.getRequestId());
        } else if (!vlvhFlag) {
            this.calculateTestMass(calculation, request.getRequestId());
            this.calculateRoadLoad(calculation, request.getRequestId());
        }

        // Added the below if conditions and also a method inside if conditions as part of the prod incident(INCI10638035) fix -Starts Here
        if ("C".equalsIgnoreCase(inCompleteflag) && vlvhFlag) {
            this.setT3Values(calculation, request.getRequestId());

        }
        if ("I".equalsIgnoreCase(inCompleteflag) && vlvhFlag) {
            this.setT3Values(calculation, request.getRequestId());
        }
        // Added the above if conditions and also a method inside if conditions as part of the prod incident(INCI10638035) fix -Ends Here
        // CAP-23272(Regulatory Changes) ends here

        this.calculatePhases(calculation, request.getRequestId());
        // fixed Jira - 489 starts here
        String completeflag = calculation.getTvvDetails().getTvvCompleteFlag();
        if (!vlvhFlag && (!"I".equalsIgnoreCase(completeflag)
                || (calculation.getVersion().getConversionData() != null && !calculation.getVersion().getConversionData().isEmpty()))) {
            this.checkCO2Controls(calculation, request.getRequestId());
        }
        // fixed Jira - 489 ends here
        sw.stop();
        logger.info("Request ID[{}]: All calculations complete", request.getRequestId());
        logger.info("Request ID[{}]: StopWatch - All calculation took {}ms", request.getRequestId(), sw.getTime());

        return calculation;
    }

    /**
     * Control depol limits for car converters.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     */
    private void controlDepolLimitsForCarConverters(Calculation calculation, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        List<ConversionData> conversionData = calculation.getVersion().getConversionData();

        String specialValue = getCarConvertorValue(conversionData, ConversionDataCodes.SPECIAL.name()).orElse(null);
        String mrotrValue = getCarConvertorValue(conversionData, ConversionDataCodes.MROTR.name()).orElse(null);
        String coolSTRValue = getCarConvertorValue(conversionData, ConversionDataCodes.COOLSTR.name()).orElse(null);
        String realCRRValue = getCarConvertorValue(conversionData, ConversionDataCodes.RCRRTR.name()).orElse(null);
        String strValue = getCarConvertorValue(conversionData, ConversionDataCodes.STR.name()).orElse(null);
        String cxTRValue = getCarConvertorValue(conversionData, ConversionDataCodes.CXTR.name()).orElse(null);
        if (specialValue != null) {
            logger.info("Request ID[{}]: SPECIAL : {}", requestId, specialValue);
        }

        if (mrotrValue != null) {
            logger.info("Request ID[{}]: MROTR : {}", requestId, mrotrValue);
        }

        if (coolSTRValue != null) {
            logger.info("Request ID[{}]: COOLSTR : {}", requestId, coolSTRValue);
        }
        if (realCRRValue != null) {
            logger.info("Request ID[{}]: REALCRR : {}", requestId, realCRRValue);
        }

        if (strValue != null) {
            logger.info("Request ID[{}]: STR : {} ", requestId, strValue);
        }

        if (cxTRValue != null) {
            logger.info("Request ID[{}]: CXTR : {} ", requestId, cxTRValue);
        }
        sw.stop();
        logger.info("Request ID[{}]: StopWatch - depol control value fetch from car converters took {}ms", requestId, sw.getTime());
        depolControlForTVVUsingDepolKey(calculation, requestId, specialValue, coolSTRValue, realCRRValue, strValue, mrotrValue, cxTRValue);

    }

    /**
     * Depol control for TVV using depol key.
     *
     * @param calculation  the calculation
     * @param requestId    the request id
     * @param specialValue the special value
     * @param coolSTRValue the cool STR value
     * @param realCRRValue the real CRR value
     * @param strValue     the str value
     * @param mrotrValue   the mrotr value
     * @param cxTRValue    the cx TR value
     */
    private void depolControlForTVVUsingDepolKey(Calculation calculation, String requestId, String specialValue, String coolSTRValue,
            String realCRRValue, String strValue, String mrotrValue, String cxTRValue) {
        Double rccr = null;
        Double cxtr = null;
        if (realCRRValue != null && !realCRRValue.isEmpty()) {
            rccr = Double.parseDouble(realCRRValue);
        }
        if (StringUtils.isNotBlank(cxTRValue)) {
            cxtr = Double.parseDouble(cxTRValue);
        }
        StopWatch sw = new StopWatch();
        sw.start();
        TVV tvv = calculation.getTvvDetails();
        Optional<TVV> tvvOptional = Optional.ofNullable(tvv);
        if (tvvOptional.isPresent()) {
            String codeDepol = tvvOptional.get().getTvvCodeDepol();
            logger.info("Request ID[{}]: Depol code for TVV : {}", requestId, codeDepol);
            if (codeDepol == null || codeDepol.isEmpty()) {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_CODE_DEPOL_FOR_TVV.getRuleCode(),
                        WltpEngineCalculatorErrorCode.MISSING_CODE_DEPOL_FOR_TVV.getDescription());
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_CODE_DEPOL_FOR_TVV);
            } else if (specialValue != null && (!specialValue.isEmpty())) {
                // fixed jira-772
                List<Depol> list = depolRepository.depolByKey(codeDepol, specialValue, rccr, cxtr);
                List<Depol> rcrrMatchedList = new ArrayList<>();
                if (list == null || list.isEmpty()) {
                    LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.DEPOL_DATA_NOT_FOUND.getRuleCode(),
                            WltpEngineCalculatorErrorCode.DEPOL_DATA_NOT_FOUND.getDescription());
                    throw SeedException.createNew(WltpEngineCalculatorErrorCode.DEPOL_DATA_NOT_FOUND);
                } else if (!list.isEmpty()) { // JIRA-478 starts here
                    for (Depol depol : list) {
                        if (Double.valueOf(depol.getCrrMin().toString()) <= rccr && Double.valueOf(depol.getCrrMax().toString()) >= rccr) {
                            logger.info("RCRR:{} is within the range of CrrMin :{} AND CrrMax:{} for the code_depol :{} and code_special:{}", rccr,
                                    depol.getCrrMin(), depol.getCrrMax(), depol.getCodeDepol(), depol.getSpecialFlag());
                            rcrrMatchedList.add(depol);
                        }
                    }
                    if (rcrrMatchedList.isEmpty()) {
                        LogErrorUtility.logTheError(logger, requestId,
                                ERRW + WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_REAL_CRR.getRuleCode(),
                                WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_REAL_CRR.getDescription());
                        throw SeedException.createNew(WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_REAL_CRR);
                    } else if (rcrrMatchedList.size() > 1) {
                        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.SEVERAL_DEPOL_DATA_FOUND.getRuleCode(),
                                WltpEngineCalculatorErrorCode.SEVERAL_DEPOL_DATA_FOUND.getDescription());
                        throw SeedException.createNew(WltpEngineCalculatorErrorCode.SEVERAL_DEPOL_DATA_FOUND);
                    }
                } // JIRA-478 ends here
                Depol depol = list.get(0);
                logger.info("Request ID[{}]: CODE_DEPOL : {}, SPECIAL_FLAG : {}, RCRR_MIN : {}, RCRR_MAX : {} ", requestId, depol.getCodeDepol(),
                        depol.getSpecialFlag(), depol.getCrrMin(), depol.getCrrMax());

                int mrovind = 0;
                if (mrotrValue != null && !mrotrValue.isEmpty()) {
                    mrovind = Integer.valueOf(mrotrValue);
                }
                logger.info("Request ID[{}]: MRO_MIN : {}, MRO_MAX : {}, MRO_VIND : {}", requestId, depol.getMroMin(), depol.getMroMax(), mrovind);

                depolControls(mrovind, depol, requestId, coolSTRValue, strValue, cxTRValue);
            }

        }

        logger.info("Request ID[{}]: StopWatch - depol control for TVV took {}ms", requestId, sw.getTime());

    }

    /**
     * Depol controls.
     *
     * @param mrovind      the mro vind
     * @param depol        the depol
     * @param requestId    the request id
     * @param coolSTRValue the cool STR value
     * @param strValue     the str value
     * @param cxTRValue    the cx TR value
     */
    private void depolControls(int mrovind, Depol depol, String requestId, String coolSTRValue, String strValue, String cxTRValue) {
        StopWatch sw = new StopWatch();
        sw.start();
        if (depol.getMroMin() > mrovind || depol.getMroMax() < mrovind) {

            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT.getRuleCode(),
                    WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT);
        }
        if ((strValue != null && !strValue.isEmpty())
                && (Float.parseFloat(strValue) < depol.getFrontalAreaMin() || Float.parseFloat(strValue) > depol.getFrontalAreaMax())) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_STR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_STR.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_STR);
        }

        if (strValue != null)
            logger.info("Request ID[{}]: STR : {}, STR_MIN : {}, STR_MAX : {}", requestId, strValue, depol.getFrontalAreaMin(),
                    depol.getFrontalAreaMax());

        if ((coolSTRValue != null && !coolSTRValue.isEmpty())
                && (Float.parseFloat(coolSTRValue) < depol.getCoolingSurfaceMin() || Float.parseFloat(coolSTRValue) > depol.getCoolingSurfaceMax())) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_COOL_STR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_COOL_STR.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_COOL_STR);
        }

        if (coolSTRValue != null)
            logger.info("Request ID[{}]: COOLSTR : {}, COOLSTR_MIN : {}, COOLSTR_MAX : {}", requestId, coolSTRValue, depol.getCoolingSurfaceMin(),
                    depol.getCoolingSurfaceMax());

        if ((cxTRValue != null && !cxTRValue.isEmpty() && cxTRValue.equals("0"))
                && (!depolRepository.depolByTripletFields(depol.getCodeDepol(), depol.getSpecialFlag(), Double.valueOf(cxTRValue)).isPresent())) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_CXTR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.MISSING_CXTR.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_CXTR);
        } else if ((cxTRValue != null && !cxTRValue.isEmpty())
                && (Float.parseFloat(cxTRValue) < depol.getCxMin() || Float.parseFloat(cxTRValue) > depol.getCxMax())) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_CXTR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_CXTR.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.OUT_OF_MAXI_POLLUTANT_CXTR);
        }

        if (cxTRValue != null)
            logger.info("Request ID[{}]: CXTR : {}, CX_MIN : {}, CX_MAX : {}", requestId, cxTRValue, depol.getCxMin(), depol.getCxMax());

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - 4 Depol controls took {}ms", requestId, sw.getTime());

    }

    /**
     * Retrieve the necessary data for the final calculation.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */
    private Calculation retrieveData(Calculation calculation, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        FamilyDetails family = familyRepository
                .byCodeAndIndexDetails(calculation.getVersion().getFamily(requestId), Integer.parseInt(calculation.getVersion().getIndex(requestId)))
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.UNKNOWN_FAMILY_COUPLE));
        calculation.setFamily(family);
        logger.info("Request ID[{}]: Fetched WLTP Family ({},{}) ID: {}, RoadLoad:{}, PMax :{}", requestId, family.getCode(), family.getIndex(),
                family.getGuid(), family.getRoadLoad(), family.getPmax());

        if ("I".equalsIgnoreCase(family.getStatus()) || family.getBlocked()) {
            WltpErrorCode wltpErrorCode = new WltpErrorCode();
            wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.FAMILY_NOT_AVAILABLE.getRuleCode());
            wltpErrorCode.setDescription("WLTP family (T8C" + family.getCode() + "/T8D" + family.getIndex() + ") not available");
            LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
            throw SeedException.createNew(wltpErrorCode);
        }
        fetchingTVV(calculation, sw, calculation.getVersion(), requestId);

        if (calculation.getVersion().getRequestType().equals(RequestType.FULL)
                || calculation.getVersion().getRequestType().equals(RequestType.TEST)) {
            calculation.addCyclesReference(family.getCycles().stream().map(cycleDetailsRepository::load).collect(toList()));
        }
        if (calculation.getVersion().getRequestType().equals(RequestType.COMB)) {
            calculation.addCyclesReference(
                    family.getCycles().stream().map(cycleDetailsRepository::load).filter(cycle -> "COMB".equals(cycle.getPhase())).collect(toList()));
        }

        logger.info("Request ID[{}]: Fetched WLTP Family corresponding cycles: {}", requestId, family.getCycles());
        logger.info("Request ID[{}]: Cycles names: {}", requestId,
                calculation.getReferences().getCycles().stream().map(CycleDetails::getCode).collect(toList()));

        try {
            String category;
            String specialFlag = null;
            List<ConversionData> conversionData = calculation.getVersion().getConversionData();
            if (conversionData == null || conversionData.isEmpty())
                category = calculation.getTvvDetails().getTvvVehicleCategory();
            else {
                // Lot24 changes needs to be done for Special vehicle management here: In case of SPECIAL vehicle (FLAG SPECIAL = Y) , then use the
                // CATEGORY found in TVV TABLE to determine the PAYLOAD Percentage
                specialFlag = getCarConvertorValue(conversionData, ConversionDataCodes.SPECIAL.name())
                        .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_SPECIAL));
                if ("Y".equalsIgnoreCase(specialFlag)) {
                    logger.info("Request ID[{}]: Found SPECIAL Vehicle & the flag is:[{}]", requestId, specialFlag);
                    category = calculation.getTvvDetails().getTvvVehicleCategory();
                    logger.info("Request ID[{}]: Fetched the CATEGORY:[{}] found in TVV TABLE to determine the PAYLOAD Percentage", requestId,
                            category);

                } else {
                    category = getCarConvertorValue(conversionData, ConversionDataCodes.CATTR.name())
                            .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_CATTR_CC));
                }
            }

            calculation.addPayloadPercentageReference(payloadPercentageRepository.byCategoryAndDate(category, calculation.getVersion().getEcomDate())
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_PERCENTAGE_PAYLOAD)));
        } catch (IllegalStateException e) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.SEVERAL_PERCENTAGE_PAYLOAD.getRuleCode(),
                    WltpEngineCalculatorErrorCode.SEVERAL_PERCENTAGE_PAYLOAD.getDescription());
            throw SeedException.wrap(e, WltpEngineCalculatorErrorCode.SEVERAL_PERCENTAGE_PAYLOAD);
        }

        PayloadPercentage pp = calculation.getReferences().getPayloadPercentage();
        logger.info("Request ID[{}]: Fetched Payload Percentage: ID({}), vehicle category({}), value({}), start({}), end({})", requestId,
                pp.getGuid(), pp.getCategory(), pp.getValue(), pp.getValidityStart(), pp.getValidityEnd());

        GrossVehicleMass t3n = grossVehicleMassRepository
                .byFamilyCodeAndCharacteristic(calculation.getVersion().getVehicleFamily(requestId),
                        calculation.getVersion().getGrossVehicleMass(requestId), "T3N")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_GVM_FOUND));
        // change in package of NumberUtils.isNumber method
        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3n.getValue()) && Double.parseDouble(t3n.getValue()) >= 0) {
            calculation.setmTac(t3n.getValue());// JIRA-385 Fix
        }
        // change in package of NumberUtils.isNumber method
        if (!org.apache.commons.lang.math.NumberUtils.isNumber(t3n.getValue()) || Double.parseDouble(t3n.getValue()) <= 0) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_GVM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_GVM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_GVM_FOUND);
        }
        calculation.addGrossVehicleMassReference(t3n);
        // to be implement on corvet
        calculation.addDestinationReference(destinationDetailsRepository
                .byCountryAndDate(calculation.getVersion().getProgramCountry(requestId), calculation.getVersion().getCharacteristic(),
                        calculation.getVersion().getEcomDate())
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_DESTINATION_FOUND)));
        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Data retrieval - Took {}ms", requestId, sw.getTime());

        return calculation;
    }

    /**
     * Log and create exception.
     *
     * @param requestId the request id
     * @param errorCode the error code
     * @return the seed exception
     */
    private SeedException logAndCreateException(String requestId, WltpEngineCalculatorErrorCode errorCode) {
        LogErrorUtility.logTheError(logger, requestId, ERRW + errorCode.getRuleCode(), errorCode.getDescription());
        return SeedException.createNew(errorCode);
    }

    /**
     * Fetching TVV.
     *
     * @param calculation the calculation
     * @param sw          the sw
     * @param version     the version
     * @param requestId   the request id
     */
    private void fetchingTVV(Calculation calculation, StopWatch sw, Version version, String requestId) {
        String t1a = version.getTvvT1A();
        String t1b = version.getTvvT1B();
        // jira-744 and 745 fix starts here
        if (version.getTvvDesignation() != null && !version.getTvvDesignation().isEmpty() && !t1a.isEmpty() && !t1b.isEmpty()) {
            List<TVV> tvv = tvvRepository.tvvByFamilyTvvDesigT1AT1B(version.getVehicleFamily(requestId), version.getTvvDesignation(), t1a, t1b);
            tvv.stream().findFirst().ifPresent(calculation::setTvvDetails);
            if (!tvv.isEmpty()) {
                logger.info(
                        "Request ID[{}]: Fetched TVV details by vehicle family({}), TVV Designation({}), T1A_VALUE({}), T1B_VALUE({}) : TVV_VEHICLE_CATEGORY({}),TVV_AF({}),TVV_HEIGHT({}),TVV_WIDTH({}),TVV_MAX_SPEED({}),TVV_COMPLETE_FLAG({}),TVV_CODE_DEPOL({})",
                        requestId, version.getVehicleFamily(requestId), version.getTvvDesignation(), calculation.getTvvDetails().getT1AValue(),
                        calculation.getTvvDetails().getT1BValue(), calculation.getTvvDetails().getTvvVehicleCategory(),
                        calculation.getTvvDetails().getTvvAf(), calculation.getTvvDetails().getTvvHeigth(), calculation.getTvvDetails().getTvvWidth(),
                        calculation.getTvvDetails().getTvvMaxspeed(), calculation.getTvvDetails().getTvvCompleteFlag(),
                        calculation.getTvvDetails().getTvvCodeDepol());
                sw.split();
                long splitTime = sw.getSplitTime();
                logger.debug(FETCH_TVV_TIME_LOG, requestId, splitTime);
                sw.unsplit();
            } else {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getDescription() + "[" + version.getVehicleFamily(requestId)
                        + "," + version.getTvvDesignation() + "]");
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                // JIRA-535 Fix Ends Here
                throw SeedException.createNew(wltpErrorCode);

            }
            // jira-744 and 745 fix ends here
        } else if (version.getTvvDesignation() != null && !version.getTvvDesignation().isEmpty()) {
            List<TVV> tvv = tvvRepository.tvvByUniqueFields(version.getVehicleFamily(requestId), version.getTvvDesignation());
            tvv.stream().findFirst().ifPresent(calculation::setTvvDetails);
            if (!tvv.isEmpty()) {
                logger.info(
                        "Request ID[{}]: Fetched TVV details by vehicle family({}), TVV Designation({}) : T1A_VALUE({}),T1B_VALUE({}),TVV_VEHICLE_CATEGORY({}),TVV_AF({}),TVV_HEIGHT({}),TVV_WIDTH({}),TVV_MAX_SPEED({}),TVV_COMPLETE_FLAG({}),TVV_CODE_DEPOL({})",
                        requestId, version.getVehicleFamily(requestId), version.getTvvDesignation(), calculation.getTvvDetails().getT1AValue(),
                        calculation.getTvvDetails().getT1BValue(), calculation.getTvvDetails().getTvvVehicleCategory(),
                        calculation.getTvvDetails().getTvvAf(), calculation.getTvvDetails().getTvvHeigth(), calculation.getTvvDetails().getTvvWidth(),
                        calculation.getTvvDetails().getTvvMaxspeed(), calculation.getTvvDetails().getTvvCompleteFlag(),
                        calculation.getTvvDetails().getTvvCodeDepol());
            }
            sw.split();
            long splitTime = sw.getSplitTime();
            logger.debug(FETCH_TVV_TIME_LOG, requestId, splitTime);
            sw.unsplit();
            if (tvv.isEmpty()) {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getDescription() + "[" + version.getVehicleFamily(requestId)
                        + "," + version.getTvvDesignation() + "]");
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                // JIRA-535 Fix Ends Here
                throw SeedException.createNew(wltpErrorCode);
            }
        } else if (!t1a.isEmpty() && !t1b.isEmpty()) {
            List<TVV> tvv = tvvRepository.tvvByUniqueFields(version.getVehicleFamily(requestId), t1a, t1b);
            tvv.stream().findFirst().ifPresent(calculation::setTvvDetails);
            if (!tvv.isEmpty()) {
                logger.info(
                        "Request ID[{}]: Fetched TVV details by vehicle family({}), T1A({}), T1B({}) : TVV_DESIGNATION({}),TVV_VEHICLE_CATEGORY({}),TVV_AF({}),TVV_HEIGHT({}),TVV_WIDTH({}),TVV_MAX_SPEED({}),TVV_COMPLETE_FLAG({}),TVV_CODE_DEPOL({})",
                        requestId, version.getVehicleFamily(requestId), t1a, t1b, calculation.getTvvDetails().getTvvDesignation(),
                        calculation.getTvvDetails().getTvvVehicleCategory(), calculation.getTvvDetails().getTvvAf(),
                        calculation.getTvvDetails().getTvvHeigth(), calculation.getTvvDetails().getTvvWidth(),
                        calculation.getTvvDetails().getTvvMaxspeed(), calculation.getTvvDetails().getTvvCompleteFlag(),
                        calculation.getTvvDetails().getTvvCodeDepol());
            }
            sw.split();
            long splitTime = sw.getSplitTime();
            logger.debug(FETCH_TVV_TIME_LOG, requestId, splitTime);
            sw.unsplit();
            if (tvv.isEmpty()) {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getDescription() + "[" + version.getVehicleFamily(requestId)
                        + ", T1A" + t1a + ", T1B" + t1b + "]");
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                // JIRA-535 Fix Ends Here
                throw SeedException.createNew(wltpErrorCode);
            }

        } // fix Jira 453 starts here
        else if (t1a.isEmpty() || t1b.isEmpty() || version.getTvvDesignation() == null) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getRuleCode(),
                    WltpEngineCalculatorErrorCode.UNKNOWN_TVV.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.UNKNOWN_TVV);
        } // end here
    }

    // /**
    // * Calculate energy efficiency.
    // *
    // * @param calculation the calculation
    // * @param requestId the request id
    // * @return the string
    // */
    // private String calculateEnergyEfficiency(Calculation calculation, String requestId) {
    // double crrValue = calculation.getPhysicalQuantities().stream().filter(p -> CalculationConstants.CRR_CODE.equals(p.getCode())).findAny()
    // .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.PHYSICAL_DATA_MISSING)).getValue();
    // String energyClass = energyEfficiencyRepository.getEnergyClassByValue(crrValue);
    // if (energyClass.trim().isEmpty()) {
    // LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.UNKNOWN_CRR.getRuleCode(),
    // WltpEngineCalculatorErrorCode.UNKNOWN_CRR.getDescription());
    // throw SeedException.createNew(WltpEngineCalculatorErrorCode.UNKNOWN_CRR);
    // }
    //
    // logger.info("Request ID[{}]: Energy Efficiency Class set to [{}] for CRR value [{}]", requestId, energyClass, crrValue);
    // return energyClass;
    // }

    /**
     * Calculate test mass.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */
    private Calculation calculateTestMass(Calculation calculation, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        List<ConversionData> conversionData = calculation.getVersion().getConversionData();
        double grossVehicleMass = 0;
        if (conversionData == null || conversionData.isEmpty()) {
            grossVehicleMass = Double.parseDouble(calculation.getReferences().getGrossVehicleMass().getValue());
        } else {
            String mtacTR = getCarConvertorValue(conversionData, ConversionDataCodes.MTACTR.name())
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_MTACTR_CC));
            grossVehicleMass = Double.parseDouble(mtacTR);
        }
        Version version = calculation.getVersion();
        String vehicleFamily = version.getVehicleFamily(requestId);
        String fullMassCode = version.getFullOptionsMass(requestId);
        String emptyMassCode = version.getEmptyMass(requestId);

        String t3sValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, fullMassCode, "T3S")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_FOM_FOUND)).getValue();

        String t3mValue = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(vehicleFamily, emptyMassCode, "T3M")
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.NO_EM_FOUND)).getValue();

        // CALCULWLTP-285 -Fix Starts Here
        double fullOptionsMass = 0;
        // change in package of NumberUtils.isNumber method
        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3sValue) && Double.parseDouble(t3sValue) >= 0) {
            fullOptionsMass = Double.parseDouble(t3sValue);
            calculation.setmOPT(String.valueOf(Integer.parseInt(t3sValue)));// JIRA-385 Fix
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_FOM_FOUND);
        }
        double emptyMass = 0;
        // change in package of NumberUtils.isNumber method
        if (org.apache.commons.lang.math.NumberUtils.isNumber(t3mValue) && Double.parseDouble(t3mValue) > 0) {
            emptyMass = Double.parseDouble(t3mValue);
            calculation.setEmptyMass(String.valueOf(Integer.parseInt(t3mValue)));// JIRA-385 Fix
        } else {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_EM_FOUND.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NO_EM_FOUND.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_EM_FOUND);
        }
        // CALCULWLTP-285 - Fix Ends Here

        logger.info("Request ID[{}]: Test Mass Calculation - Gross vehicle mass = ({})", requestId, grossVehicleMass);
        logger.info("Request ID[{}]: Test Mass Calculation - Full options mass = ({})", requestId, fullOptionsMass);
        logger.info("Request ID[{}]: Test Mass Calculation - Empty mass = ({})", requestId, emptyMass);

        double usedMass = 0;
        if (conversionData == null || conversionData.isEmpty()) {
            usedMass = calculation.getPhysicalQuantities().stream().filter(p -> CalculationConstants.MASS_CODE.equals(p.getCode())).findAny()
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.PHYSICAL_DATA_MISSING)).getValue();
        } else {
            double mcor = Double.parseDouble(getCarConvertorValue(conversionData, ConversionDataCodes.MCOR.name())
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_MCOR_CC)));
            double dmtr = Double.parseDouble(getCarConvertorValue(conversionData, ConversionDataCodes.DMTR.name())
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_DMTR_CC)));
            usedMass = mcor - CalculationConstants.PERSON_MASS + dmtr;
            updatePhysicalQuantity(calculation, usedMass, CalculationConstants.MASS_CODE);

            String mpotTR = getCarConvertorValue(conversionData, ConversionDataCodes.MOPTTR.name())
                    .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_MOPTTR_CC));
            fullOptionsMass = fullOptionsMass + Double.parseDouble(mpotTR);

        }
        double payloadPercentage = calculation.getReferences().getPayloadPercentage().getValue() / 100.0;
        double preciseVehicleMass = fullOptionsMass + emptyMass;

        double payload = grossVehicleMass - preciseVehicleMass - CalculationConstants.PERSON_MASS - CalculationConstants.LUGGAGE_MASS;

        logger.info("Request ID[{}]: Test Mass Calculation - Payload({}), Payload percentage({})", requestId, payload, payloadPercentage);

        if (payload < 0) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NEGATIVE_VEHICLE_PAYLOAD.getRuleCode(),
                    WltpEngineCalculatorErrorCode.NEGATIVE_VEHICLE_PAYLOAD.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.NEGATIVE_VEHICLE_PAYLOAD);
        }
        int testMass = BigDecimal
                .valueOf(usedMass + CalculationConstants.PERSON_MASS + CalculationConstants.LUGGAGE_MASS + payloadPercentage * payload)
                .setScale(0, BigDecimal.ROUND_HALF_UP).intValue();

        logger.info("Request ID[{}]: Test Mass Calculation - Final Mass_Vind = ({})", requestId, usedMass);
        logger.info("Request ID[{}]: Test Mass Calculation - Final Test mass({})", requestId, testMass);

        calculation.setCalculatedData(calculatedDataFactory.withTestMass(testMass));
        // calculation.getCalculatedData().setCrrEfficiency(energyClass); This line has been commented as part of JIRA-603 Fix
        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Test Mass - Calculation took {}ms", requestId, sw.getTime());

        return calculation;
    }

    /**
     * Calculate road load.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */
    private Calculation calculateRoadLoad(Calculation calculation, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> boundaries = vehicleBoundaryService
                .physicalBoundaries(calculation.getFamily());

        sw.stop();
        logger.debug("Request ID[{}]: StopWatch - Road load - Physical boundaries took {}ms", requestId, sw.getTime());
        sw.reset();
        sw.start();

        List<EnginePhysicalQuantity> roadLoad = Arrays.asList(
                new EnginePhysicalQuantity(CalculationConstants.F0_CODE, roadLoadCoefficientF0(calculation, boundaries, requestId)),
                new EnginePhysicalQuantity(CalculationConstants.F1_CODE, roadLoadCoefficientF1(calculation, boundaries, requestId)),
                new EnginePhysicalQuantity(CalculationConstants.F2_CODE, roadLoadCoefficientF2(calculation, boundaries, requestId)));

        calculation.getCalculatedData().setRoadLoad(roadLoad);

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Road load - Calculation took {}ms", requestId, sw.getTime());

        return calculation;
    }

    /**
     * Road load coefficient f0.
     *
     * @param calculation the calculation
     * @param boundaries  the boundaries
     * @param requestId   the request id
     * @return the double
     */
    private double roadLoadCoefficientF0(Calculation calculation, Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> boundaries,
            String requestId) {
        FamilyDetails fd = calculation.getFamily();
        Optional<FamilyDetails> fdOptional = Optional.ofNullable(fd);
        double f0 = 0;
        StopWatch sw = new StopWatch();
        sw.start();
        if (fdOptional.isPresent()) {
            String roadLoadType = fd.getRoadLoad();
            if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using IRL formula for roadLoadCoefficientF0", requestId);
                double lowMass = getPhysicalQuantity(boundaries.getValue0(), CalculationConstants.MASS_CODE, requestId);
                double lowCrr = getPhysicalQuantity(boundaries.getValue0(), CalculationConstants.CRR_CODE, requestId);
                double lowRollingResistance = lowMass * lowCrr;

                double highMass = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.MASS_CODE, requestId);
                double highCrr = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.CRR_CODE, requestId);
                double highRollingResistance = highMass * highCrr;

                double f0Low = getPhysicalQuantity(boundaries.getValue0(), CalculationConstants.F0_CODE, requestId);

                if (BigDecimal.valueOf(lowRollingResistance).equals(BigDecimal.valueOf(highRollingResistance)))
                    return f0Low;

                double indMass = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
                double f0High = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.F0_CODE, requestId);
                double indCrr = 0;

                List<ConversionData> conversionData = calculation.getVersion().getConversionData();
                if (conversionData == null || conversionData.isEmpty())
                    indCrr = getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.CRR_CODE, requestId);
                else {
                    String scxTR = getCarConvertorValue(conversionData, ConversionDataCodes.SCXTR.name()).orElse("");
                    if (!NumberUtils.isParsable(scxTR)) {
                        Double crrVhigh = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.CRR_CODE, requestId);
                        updatePhysicalQuantity(calculation, crrVhigh, CalculationConstants.CRR_CODE);

                        Double scxVhigh = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.SCX_CODE, requestId);
                        updatePhysicalQuantity(calculation, scxVhigh, CalculationConstants.SCX_CODE);

                        indMass = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.MASS_CODE, requestId);
                        calculation.getCalculatedData().setTestMass((int) indMass);
                        logger.info("Request ID[{}]: Resetting Test Mass to [{}]", requestId, indMass);

                        f0 = BigDecimal.valueOf(f0High).setScale(CalculationConstants.ROUND_F0, RoundingMode.HALF_UP).doubleValue();
                        sw.stop();
                        logger.info("Request ID[{}]: StopWatch - Road load - F0 calculation took {}ms", requestId, sw.getTime());
                        logger.info(F0_LOG, requestId, f0High, f0);
                        return f0;
                    }
                    String crrTR = getCarConvertorValue(conversionData, ConversionDataCodes.CRRTR.name())
                            .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_CRRTR_CC));
                    indCrr = Double.parseDouble(crrTR);
                    updatePhysicalQuantity(calculation, indCrr, CalculationConstants.CRR_CODE);
                }
                double indRollingResistance = indMass * indCrr;
                double f0Ind = f0High
                        - (f0High - f0Low) * ((highRollingResistance - indRollingResistance) / (highRollingResistance - lowRollingResistance));
                f0 = BigDecimal.valueOf(f0Ind).setScale(CalculationConstants.ROUND_F0, RoundingMode.HALF_UP).doubleValue();
                logger.info(F0_LOG, requestId, f0Ind, f0);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using DRL formula for roadLoadCoefficientF0", requestId);
                double indMass = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
                f0 = BigDecimal.valueOf((0.140 * indMass)).setScale(CalculationConstants.ROUND_F0, RoundingMode.HALF_UP).doubleValue();
                logger.info(F0_LOG, requestId, (0.140 * indMass), f0);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using MRL formula for roadLoadCoefficientF0", requestId);
                List<TestVehicle> vRefLst = calculation.getFamily().getVehicles().stream()
                        .filter(t -> testVehicleTypeRepository.load(t.getType()).getCode().equals(CalculationConstants.VREF))
                        .collect(Collectors.toList());
                if (vRefLst != null && !vRefLst.isEmpty()) {
                    List<PhysicalQuantityValue> pqsValueLst = vRefLst.get(0).getQuantities();
                    double f0Vref = getPhysicalQuantityValue(pqsValueLst, CalculationConstants.F0_CODE);
                    double testMassVind = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
                    double massVref = getPhysicalQuantityValue(pqsValueLst, CalculationConstants.MASS_CODE);
                    double crrVind = 0;
                    List<ConversionData> conversionData = calculation.getVersion().getConversionData();

                    if (conversionData == null || conversionData.isEmpty())
                        crrVind = getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.CRR_CODE, requestId);

                    else {
                        String crrTR = getCarConvertorValue(conversionData, ConversionDataCodes.CRRTR.name())
                                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_CRRTR_CC));
                        crrVind = Double.parseDouble(crrTR);
                        updatePhysicalQuantity(calculation, crrVind, CalculationConstants.CRR_CODE);
                    }
                    double crrVref = getPhysicalQuantityValue(pqsValueLst, CalculationConstants.CRR_CODE);
                    logger.info("Request ID[{}]: Road Load Calculation - F0 VRef={}, Mass VRef={}, CRR VRef={}, Test Mass Vind={}, CRR Vind={}",
                            requestId, f0Vref, massVref, crrVref, testMassVind, crrVind);
                    double f0Vind = Math.max(
                            (0.05 * f0Vref + 0.95 * (f0Vref * testMassVind / massVref + (crrVind - crrVref) * 9.81 * testMassVind / 1000)),
                            (0.2 * f0Vref + 0.8 * (f0Vref * testMassVind / massVref + (crrVind - crrVref) * 9.81 * testMassVind / 1000)));
                    f0 = BigDecimal.valueOf(f0Vind).setScale(CalculationConstants.ROUND_F0, RoundingMode.HALF_UP).doubleValue();
                    logger.info(F0_LOG, requestId, f0Vind, f0);
                }

            }
        }

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Road load - F0 calculation took {}ms", requestId, sw.getTime());

        return f0;
    }

    /**
     * Road load coefficient f1.
     *
     * @param calculation the calculation
     * @param boundaries  the boundaries
     * @param requestId   the request id
     * @return the double
     */
    private double roadLoadCoefficientF1(Calculation calculation, Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> boundaries,
            String requestId) {
        FamilyDetails fd = calculation.getFamily();
        Optional<FamilyDetails> fdOptional = Optional.ofNullable(fd);
        double f1 = 0;
        StopWatch sw = new StopWatch();
        sw.start();
        if (fdOptional.isPresent()) {
            String roadLoadType = fd.getRoadLoad();
            if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using IRL formula for roadLoadCoefficientF1", requestId);
                double f1Ind = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.F1_CODE, requestId);
                f1 = BigDecimal.valueOf(f1Ind).setScale(CalculationConstants.ROUND_F1, RoundingMode.HALF_UP).doubleValue();
                logger.info(F1_LOG, requestId, f1Ind, f1);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using DRL formula for roadLoadCoefficientF1", requestId);
                double f1Ind = 0;
                f1 = BigDecimal.valueOf(f1Ind).setScale(CalculationConstants.ROUND_F1, RoundingMode.HALF_UP).doubleValue();
                logger.info(F1_LOG, requestId, f1Ind, f1);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using MRL formula for roadLoadCoefficientF1", requestId);
                double f1Ind = 0;
                f1 = BigDecimal.valueOf(f1Ind).setScale(CalculationConstants.ROUND_F1, RoundingMode.HALF_UP).doubleValue();
                logger.info(F1_LOG, requestId, f1Ind, f1);
            }

        }
        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Road load - F1 calculation took {}ms", requestId, sw.getTime());
        return f1;
    }

    /**
     * Road load coefficient f2.
     *
     * @param calculation the calculation
     * @param boundaries  the boundaries
     * @param requestId   the request id
     * @return the double
     */
    private double roadLoadCoefficientF2(Calculation calculation, Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> boundaries,
            String requestId) {

        FamilyDetails fd = calculation.getFamily();
        Optional<FamilyDetails> fdOptional = Optional.ofNullable(fd);
        TVV tvv = calculation.getTvvDetails();
        Optional<TVV> tvvOptional = Optional.ofNullable(tvv);
        double f2 = 0;
        StopWatch sw = new StopWatch();
        sw.start();
        if (fdOptional.isPresent()) {
            double lowScx = getPhysicalQuantity(boundaries.getValue0(), CalculationConstants.SCX_CODE, requestId); // VLOW SCX From Family
            double highScx = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.SCX_CODE, requestId);// VHIGH SCX From Family
            String vehicleCategory = calculation.getTvvDetails().getTvvVehicleCategory();
            String roadLoadType = fd.getRoadLoad();
            if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                logger.info("Request ID[{}]: Using IRL formula for roadLoadCoefficientF2", requestId);
                double f2Low = getPhysicalQuantity(boundaries.getValue0(), CalculationConstants.F2_CODE, requestId);
                if (BigDecimal.valueOf(lowScx).equals(BigDecimal.valueOf(highScx)))
                    return f2Low;

                double f2High = getPhysicalQuantity(boundaries.getValue1(), CalculationConstants.F2_CODE, requestId);
                double indScx = 0;
                List<ConversionData> conversionData = calculation.getVersion().getConversionData();
                if (conversionData == null || conversionData.isEmpty()) {
                    // fixed jira-767
                    if ("I".equalsIgnoreCase(tvv.getTvvCompleteFlag()) && "N1".equalsIgnoreCase(vehicleCategory)) {// Added this block of code as part
                                                                                                                   // of regulatory changes(LOT23)
                        indScx = BigDecimal.valueOf((lowScx + highScx) / 2).setScale(CalculationConstants.ROUND_F3, RoundingMode.HALF_UP)
                                .doubleValue();
                        logger.info("Request ID[{}]: VLOW SCX:[{}] VHIGH SCX:[{}] Average SCX:[{}]", requestId, lowScx, highScx, indScx);
                        updatePhysicalQuantity(calculation, indScx, CalculationConstants.SCX_CODE);
                        logger.info("Request ID[{}]: Vehicle Category:[{}] RoadLoad Type:[{}] SCX:[{}]", requestId, vehicleCategory, roadLoadType,
                                indScx);
                    } else {
                        indScx = getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.SCX_CODE, requestId); // SCX Newton
                    }
                } else {
                    String scxTR = getCarConvertorValue(conversionData, ConversionDataCodes.SCXTR.name()).orElse("");
                    if (!NumberUtils.isParsable(scxTR)) {
                        updatePhysicalQuantity(calculation, indScx, CalculationConstants.SCX_CODE);
                        f2 = BigDecimal.valueOf(f2High).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP).doubleValue();
                        sw.stop();
                        logger.info("Request ID[{}]: StopWatch - Road load - F2 calculation took {}ms", requestId, sw.getTime());
                        logger.info(F2_LOG, requestId, f2High, f2);
                        return f2;
                    }
                    indScx = Double.parseDouble(scxTR);
                    updatePhysicalQuantity(calculation, indScx, CalculationConstants.SCX_CODE);
                }

                double f2Ind = f2High - (f2High - f2Low) * (1 - (indScx - lowScx) / (highScx - lowScx));
                f2 = BigDecimal.valueOf(f2Ind).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP).doubleValue();
                logger.info(F2_LOG, requestId, f2Ind, f2);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType) && tvvOptional.isPresent()) {
                logger.info("Request ID[{}]: Using DRL formula for roadLoadCoefficientF2", requestId);
                double heightVind = 0;
                double widthVind = 0;
                double sVind = 0;
                List<ConversionData> conversionData = calculation.getVersion().getConversionData();
                if (conversionData == null || conversionData.isEmpty()) {
                    if (tvv.getTvvHeigth() != null) {
                        heightVind = tvv.getTvvHeigth();
                    } else {
                        LogErrorUtility.logTheError(logger, requestId,
                                ERRW + WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getRuleCode(),
                                WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getDescription());
                        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD);
                    }

                    if (tvv.getTvvWidth() != null) {
                        widthVind = tvv.getTvvWidth();
                    } else {
                        LogErrorUtility.logTheError(logger, requestId,
                                ERRW + WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getRuleCode(),
                                WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getDescription());
                        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD);
                    }
                    // fixed jira-767
                    if ("I".equalsIgnoreCase(tvv.getTvvCompleteFlag()) && "N1".equalsIgnoreCase(vehicleCategory)) {// Added this block of code as part
                                                                                                                   // of regulatory changes(LOT23)
                        sVind = BigDecimal.valueOf((heightVind + widthVind) / 2).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP)
                                .doubleValue();
                        logger.info("Request ID[{}]: TVV Height:[{}] TVV Width:[{}] Average TVV Height-Width:[{}]", requestId, heightVind, widthVind,
                                sVind);
                        logger.info("Request ID[{}]: Vehicle Category:[{}] RoadLoad Type:[{}] Height-Width:[{}]", requestId, vehicleCategory,
                                roadLoadType, sVind);
                    }

                } else {
                    String hTR = getCarConvertorValue(conversionData, ConversionDataCodes.HTR.name()).orElse("");
                    String lTR = getCarConvertorValue(conversionData, ConversionDataCodes.LTR.name()).orElse("");
                    if (!NumberUtils.isParsable(hTR) || !NumberUtils.isParsable(lTR)) {
                        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA.getRuleCode(),
                                WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA.getDescription());
                        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA);
                    }
                    heightVind = Double.parseDouble(hTR);
                    widthVind = Double.parseDouble(lTR);

                    double crrTR = Double.parseDouble(getCarConvertorValue(conversionData, ConversionDataCodes.CRRTR.name())
                            .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_CRRTR_CC)));
                    updatePhysicalQuantity(calculation, crrTR, CalculationConstants.CRR_CODE);
                }
                updatePhysicalQuantity(calculation, heightVind, CalculationConstants.H);
                updatePhysicalQuantity(calculation, widthVind, CalculationConstants.L);

                double testMasseVind = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
                double f2Vind = (2.8 * Math.pow((10), (-6)) * testMasseVind) + (0.0170 * heightVind * widthVind);
                f2 = BigDecimal.valueOf(f2Vind).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP).doubleValue();
                logger.info(F2_LOG, requestId, f2Vind, f2);
            } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType) && tvvOptional.isPresent()) {
                logger.info("Request ID[{}]: Using MRL formula for roadLoadCoefficientF2", requestId);
                List<TestVehicle> vRefLst = calculation.getFamily().getVehicles().stream()
                        .filter(t -> testVehicleTypeRepository.load(t.getType()).getCode().equals(CalculationConstants.VREF))
                        .collect(Collectors.toList());
                if (vRefLst != null && !vRefLst.isEmpty()) {
                    List<PhysicalQuantityValue> pqsValueLst = vRefLst.get(0).getQuantities();
                    double f2Vref = getPhysicalQuantityValue(pqsValueLst, CalculationConstants.F2_CODE);
                    double sVind = 0;
                    List<ConversionData> conversionData = calculation.getVersion().getConversionData();
                    if (conversionData == null || conversionData.isEmpty()) {
                        // fixed jira-767
                        if ("I".equalsIgnoreCase(tvv.getTvvCompleteFlag()) && "N1".equalsIgnoreCase(vehicleCategory)) {// Added this block of code as
                                                                                                                       // part of regulatory
                                                                                                                       // changes(LOT23)
                            List<TestVehicle> vehList = calculation.getFamily().getVehicles();
                            Map<String, Double> scxLowHighMap = getVehicleFamilyScxValues(vehList);
                            double vlowScx = scxLowHighMap.get(CalculationConstants.VLOW); // VLOW SCX From
                                                                                           // Family
                            double vhighScx = scxLowHighMap.get(CalculationConstants.VHIGH);// VHIGH SCX From
                                                                                            // Family
                            sVind = BigDecimal.valueOf((vlowScx + vhighScx) / 2).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP)
                                    .doubleValue();
                            logger.info("Request ID[{}]: VLOW Frontal Area:[{}] VHIGH Frontal Area:[{}] Average Frontal Area:[{}]", requestId,
                                    vlowScx, vhighScx, sVind);
                            logger.info("Request ID[{}]: Vehicle Category:[{}] RoadLoad Type:[{}] Frontal Area:[{}]", requestId, vehicleCategory,
                                    roadLoadType, sVind);
                        } else {
                            if (tvv.getTvvAf() != null) {
                                sVind = tvv.getTvvAf();
                            } else {
                                LogErrorUtility.logTheError(logger, requestId,
                                        ERRW + WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getRuleCode(),
                                        WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD.getDescription());
                                throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD);
                            }
                        }

                    } else {
                        String sTR = getCarConvertorValue(conversionData, ConversionDataCodes.STR.name()).orElse("");
                        if (!NumberUtils.isParsable(sTR)) {
                            LogErrorUtility.logTheError(logger, requestId,
                                    ERRW + WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA.getRuleCode(),
                                    WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA.getDescription());
                            throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA);
                        }
                        sVind = Double.parseDouble(sTR);
                    }
                    updatePhysicalQuantity(calculation, sVind, CalculationConstants.S);

                    double sVref = getPhysicalQuantityValue(pqsValueLst, CalculationConstants.SCX_CODE);
                    double f2Vind = Math.max((0.05 * f2Vref + 0.95 * f2Vref * sVind / sVref), (0.2 * f2Vref + 0.8 * f2Vref * sVind / sVref));
                    f2 = BigDecimal.valueOf(f2Vind).setScale(CalculationConstants.ROUND_F2, RoundingMode.HALF_UP).doubleValue();
                    logger.info(F2_LOG, requestId, f2Vind, f2);
                }

            }
        }
        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Road load - F2 calculation took {}ms", requestId, sw.getTime());

        return f2;
    }

    /**
     * Gets the vehicle family scx values.
     *
     * @param vehList the veh list
     * @return the vehicle family scx values
     */
    private Map<String, Double> getVehicleFamilyScxValues(List<TestVehicle> vehList) {
        Map<String, Double> vehMeasures = new HashMap<>();
        for (TestVehicle testVehicle : vehList) {
            TestVehicleType vehType = testVehicleTypeRepository.load(testVehicle.getType());
            if (vehType.getCode().equalsIgnoreCase(CalculationConstants.VHIGH) || vehType.getCode().equalsIgnoreCase(CalculationConstants.VLOW)) {
                vehMeasures.put(vehType.getCode(), getPhysicalQuantityValue(testVehicle.getQuantities(), CalculationConstants.SCX_CODE));
            }
        }
        return vehMeasures;
    }

    /**
     * Updates physical quantity.
     *
     * @param calculation      the calculation
     * @param newValue         the new value
     * @param quantityToUpdate the quantity to update
     */
    private void updatePhysicalQuantity(Calculation calculation, double newValue, String quantityToUpdate) {

        List<EnginePhysicalQuantity> quantities = calculation.getPhysicalQuantities();

        Optional<EnginePhysicalQuantity> pq = quantities.stream().filter(p -> p.getCode().equals(quantityToUpdate)).findFirst();
        if (pq.isPresent())
            pq.get().setValue(newValue);
        else
            quantities.add(new EnginePhysicalQuantity(quantityToUpdate, newValue));

        calculation.setPhysicalQuantities(quantities);
    }

    /**
     * Calculate phases.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the calculation
     */

    private Calculation calculatePhases(Calculation calculation, String requestId) {

        StopWatch sw = new StopWatch();
        sw.start();
        setParameterValues(requestId);
        UUID vehicleType = vehicleTypeRepository.guidByCode(calculation.getFamily().getType()).orElseThrow(IllegalStateException::new);

        logger.info("Request ID[{}]: Phases Calculation - VehicleType ID: {}", requestId, vehicleType);

        sw.split();
        long splitTime = sw.getSplitTime();
        logger.debug("Request ID[{}]: StopWatch - Phases - vehicle type fetching took {}ms", requestId, splitTime);
        sw.unsplit();

        Map<UUID, List<UUID>> groupedParameters = calculation.getReferences().getDestination().getParameterDetails().stream()
                .filter(ParameterDetails::isConcerned).filter(p -> p.getVehicleType().equals(vehicleType))
                .collect(groupingBy(ParameterDetails::getCyclePhase, mapping(ParameterDetails::getMeasureType, toList())));

        if (RequestType.COMB.equals(calculation.getVersion().getRequestType())) {
            Iterator<UUID> cyclePhaseKeyIterator = groupedParameters.keySet().iterator();
            while (cyclePhaseKeyIterator.hasNext()) {
                UUID cyclePhaseKey = cyclePhaseKeyIterator.next();
                CyclePhase cyclePhase = cyclePhaseRepository.load(cyclePhaseKey);
                if (!"COMB".equals(cyclePhase.getCode())) {
                    cyclePhaseKeyIterator.remove();
                }
            }
        }

        sw.split();
        logger.debug("Request ID[{}]: StopWatch - Phases - filtered grouped parameters took {}ms", requestId, sw.getSplitTime() - splitTime);
        splitTime = sw.getSplitTime();
        sw.unsplit();

        if (!calculation.getReferences().getCycles().stream().map(CycleDetails::getPhase).map(cyclePhaseRepository::uuidByCode)
                .filter(Optional::isPresent).map(Optional::get).collect(toSet()).containsAll(groupedParameters.keySet())) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_FAMILY.getRuleCode(),
                    WltpEngineCalculatorErrorCode.MISSING_FAMILY.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_FAMILY);
        }
        CalculatedData cd = calculation.getCalculatedData();

        sw.stop();
        logger.debug("Request ID[{}]: StopWatch - Phases - Checking data presence took {}ms", requestId, sw.getTime() - splitTime);
        logger.debug("Request ID[{}]: StopWatch - Phases - Fetching and checking took {}ms", requestId, sw.getTime());
        sw.reset();
        sw.start();

        List<CyclePhase> cyclePhaseOriginalList = cyclePhaseRepository.all();

        Function<CycleDetails, CalculatedPhase> cycleEnergyCalculation = c -> {
            CalculatedPhase calculatedPhase = calculatedDataFactory.createCalculatedPhase(cd, c.getPhase(),
                    cyclePhaseRepository.uuidByCode(c.getPhase()).get());

            Float pMax = calculation.getFamily().getPmax();
            Integer tvvMaxSpeed = calculation.getTvvDetails().getTvvMaxspeed();

            CyclePhase cyclePhase = null;
            if (!cyclePhaseOriginalList.isEmpty()) {
                cyclePhase = cyclePhaseOriginalList.stream().filter(cp -> cp.getCode().equals(c.getPhase())).collect(Collectors.toList()).get(0);
            }
            if (cyclePhase != null) {
                if (!(cyclePhase.getSpeedLimitingFlag()) && !(cyclePhase.getDownScaleFlag())) {
                    calculatedPhase.energyValue(calculateCycleEnergy(calculation, c, requestId));
                    return calculatedPhase;
                }
                Float f_dsc = null;
                if (cyclePhase.getDownScaleFlag()) {
                    f_dsc = fDownScaleVInd(calculation, requestId, cd, c, pMax, cyclePhase);
                }
                boolean isSpeedLimitFlag = false;
                if (cyclePhase.getSpeedLimitingFlag()) {
                    isSpeedLimitFlag = getSpeedLimit(calculation, c, cd, requestId);

                }
                if (isSpeedLimitFlag) {
                    cd.setSpeedLimitFlag("Y");
                } else {
                    if ("Y".equals(cd.getSpeedLimitFlag()))
                        cd.setSpeedLimitFlag("Y");
                    else {
                        cd.setSpeedLimitFlag("N");
                    }
                }
                calculateEnergy(isSpeedLimitFlag, cyclePhase.getDownScaleFlag(), calculation, requestId, c, calculatedPhase, f_dsc, tvvMaxSpeed);
            }

            return calculatedPhase;
        };

        UnaryOperator<CalculatedPhase> emissionsCalculation = cp -> calculateEmissions(calculation, cp, groupedParameters.get(cp.getCycleGuid()),
                requestId);

        List<CalculatedPhase> calculatedPhases = calculation.getReferences().getCycles().stream()
                .filter(c -> groupedParameters.keySet().contains(cyclePhaseRepository.uuidByCode(c.getPhase()).get())).map(cycleEnergyCalculation)
                .map(emissionsCalculation).collect(toList());

        cd.setCalculatedPhases(calculatedPhases);

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Phases - calculation took {}ms", requestId, sw.getTime());
        return calculation;
    }

    /**
     * F down scale V ind.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @param cd          the cd
     * @param c           the c
     * @param pMax        the max
     * @param cyclePhase  the cycle phase
     * @return the float
     */
    private Float fDownScaleVInd(Calculation calculation, String requestId, CalculatedData cd, CycleDetails c, Float pMax, CyclePhase cyclePhase) {
        Float fDownScale = null;
        if (cyclePhase != null && cyclePhase.getDownScaleFlag() && pMax != null) {
            Double f_dsc = calculateDownscale(c.getPhase(), calculation, requestId);
            if (f_dsc != null && f_dsc > 0.01) {
                cd.setfDownScale(f_dsc);
                fDownScale = Float.valueOf(String.valueOf(f_dsc));
            }

        }
        return fDownScale;
    }

    /**
     * Calculate energy.
     *
     * @param isSpeedLimitFlag the is speed limit flag
     * @param isDownscaleFlag  the is downscale flag
     * @param calculation      the calculation
     * @param requestId        the request id
     * @param cycleDetails     the cycle details
     * @param calculatedPhase  the calculated phase
     * @param f_dsc            the f dsc
     * @param tvvMaxSpeed      the tvv max speed
     */
    private void calculateEnergy(boolean isSpeedLimitFlag, boolean isDownscaleFlag, Calculation calculation, String requestId,
            CycleDetails cycleDetails, CalculatedPhase calculatedPhase, Float f_dsc, Integer tvvMaxSpeed) {
        if ((isSpeedLimitFlag || (isDownscaleFlag && f_dsc != null))) {
            GeneratedCycle generatedCycle = replaceReferenceCyclesByGeneratedCycles(isDownscaleFlag, cycleDetails.getCode(), f_dsc, tvvMaxSpeed,
                    requestId);

            calculatedPhase.energyValue(calculateCycleEnergy(calculation, cycleDetails, generatedCycle, requestId));
        } else {
            calculatedPhase.energyValue(calculateCycleEnergy(calculation, cycleDetails, requestId));
        }

    }

    /**
     * Replace reference cycles by generated cycles.
     *
     * @param isDownscaleFlag the is downscale flag
     * @param cycleCode       the cycle code
     * @param fDownScale      the f down scale
     * @param maxSpeed        the max speed
     * @param requestId       the request id
     * @return the list
     */
    private GeneratedCycle replaceReferenceCyclesByGeneratedCycles(boolean isDownscaleFlag, String cycleCode, Float fDownScale, Integer maxSpeed,
            String requestId) {

        String generatedCode = "";
        StopWatch swMain = new StopWatch();
        swMain.start();

        if (!isDownscaleFlag && maxSpeed != null) {
            generatedCode = cycleCode + SPEED_LIMITING + getSpeedLimitInString(maxSpeed);

        } else if ((fDownScale != null && maxSpeed != null)) {

            generatedCode = cycleCode + DOWN_SCALE + getFdsc(fDownScale) + SPEED_LIMITING + getSpeedLimitInString(maxSpeed);
        } else if (fDownScale != null) {
            generatedCode = cycleCode + DOWN_SCALE + getFdsc(fDownScale);
        } else if (maxSpeed != null) {
            generatedCode = cycleCode + SPEED_LIMITING + getSpeedLimitInString(maxSpeed);
        }
        Optional<GeneratedCycle> generatedCycle = generatedCycleRepository.byGeneratedCode(requestId, generatedCode);
        GeneratedCycle generatedCycles = null;
        if (generatedCycle.isPresent()) {
            logger.info(
                    "Request ID[{}] : Replacing  the reference cycle by generated cycle for the phase code :{},FDownScale:{},MaxSpeed:{}, Generated Code:{} ",
                    requestId, cycleCode, fDownScale, maxSpeed, generatedCycle.get().getGeneratedCode());
            generatedCycles = generatedCycle.get();
        } else {

            // JIRA-445 Fix Starts Here
            WltpErrorCode wltpErrorCode = new WltpErrorCode();
            wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.NO_GENERATED_CYCLES_FOUND.getRuleCode());
            wltpErrorCode.setDescription("cycle not found : " + generatedCode);
            // JIRA-445 Fix Ends Here
            LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
            throw SeedException.createNew(wltpErrorCode);
        }
        swMain.stop();
        logger.debug("Request ID[{}]: StopWatch - Replacing the reference cycle by generated cycle for the phase code :{} took {}ms", requestId,
                cycleCode, swMain.getTime());
        return generatedCycles;
    }

    /**
     * Gets the speed limit in string.
     *
     * @param maxSpeed the max speed
     * @return the speed limit in string
     */
    private String getSpeedLimitInString(Integer maxSpeed) {

        String speed = maxSpeed + "";
        if (speed.length() < 3) {
            speed = ZERO + speed;
        }

        return speed;
    }

    /**
     * Gets the fdsc.
     *
     * @param fdsc the fdsc
     * @return the fdsc
     */
    private String getFdsc(Float fdsc) {
        String sFdsc = fdsc + "";
        if (sFdsc.contains(".")) {
            sFdsc = sFdsc.replace(".", "");
        }
        return sFdsc;
    }

    /**
     * Gets the speed limit.
     *
     * @param calculation    the calculation
     * @param cycleDetails   the cycle details
     * @param calculatedData the calculated data
     * @param requestId      the request id
     * @return the speed limit
     */
    private boolean getSpeedLimit(Calculation calculation, CycleDetails cycleDetails, CalculatedData calculatedData, String requestId) {
        Integer maxSpeed = calculation.getTvvDetails().getTvvMaxspeed();
        boolean isSpeedLimitFlag = false;
        if (maxSpeed != null) {
            logger.info("Request ID[{}] : Cycle Energy - Phase {}, Max speed from TVV :{} and Max Velocity from Cycle Profile :{}", requestId,
                    cycleDetails.getPhase(), maxSpeed, cycleDetails.getCycleMaxVelocity());
            calculatedData.setvMax(String.valueOf(calculation.getTvvDetails().getTvvMaxspeed()));
            if (maxSpeed > cycleDetails.getCycleMaxVelocity()) {
                logger.info("Request ID[{}] : Cycle Energy - Phase {},max_speed is greater than the max velocity of the reference cycle", requestId,
                        cycleDetails.getPhase());
                // ignore this phase
            } else {
                isSpeedLimitFlag = true;
            }
        }

        return isSpeedLimitFlag;
    }

    /**
     * Calculate cycle energy.
     *
     * @param calculation the calculation
     * @param cycle       the cycle
     * @param requestId   the request id
     * @return the double
     */
    private double calculateCycleEnergy(Calculation calculation, CycleDetails cycle, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        double f0 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F0_CODE, requestId))
                .orElseThrow(IllegalStateException::new);
        double f1 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F1_CODE, requestId))
                .orElseThrow(IllegalStateException::new);
        double f2 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F2_CODE, requestId))
                .orElseThrow(IllegalStateException::new);

        int testMass = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
        double usableMass = CalculationConstants.TEST_MASS_COEFFICIENT * testMass;
        StopWatch swRef = new StopWatch();
        swRef.start();
        List<CycleProfile> profiles = cycle.getProfiles();
        swRef.stop();
        logger.info("Request ID[{}] : Cycle profile points for phase {} took {}ms", requestId, cycle.getPhase(), swRef.getTime());
        sw.split();
        long sortTime = sw.getSplitTime();
        logger.debug("Request ID[{}]: StopWatch - Cycle energy ({}) - Fetching data took {}ms", requestId, cycle.getPhase(), sortTime);
        sw.unsplit();

        IntToDoubleFunction mapper = i -> {
            CycleProfile currentProfile = profiles.get(i);
            double avgSpeed = (profiles.get(i - 1).getVelocity() + currentProfile.getVelocity()) / 2;

            double fi = f0 + f1 * avgSpeed + f2 * avgSpeed * avgSpeed + usableMass * currentProfile.getAcceleration();
            double ei = 0;
            if (fi > 0)
                ei = fi * currentProfile.getDistance();

            return ei;
        };

        double ceInd = IntStream.range(1, profiles.size()).mapToDouble(mapper).filter(i -> i > 0).sum();
        double ce = BigDecimal.valueOf(ceInd).setScale(CalculationConstants.ROUND_CE, RoundingMode.HALF_UP).doubleValue();
        sw.stop();

        logger.debug("Request ID[{}]: Cycle Energy - Phase {} - f0({}), f1({}), f2({}), testmass({}), usableMass(testMass * {})({})", requestId,
                cycle.getPhase(), f0, f1, f2, testMass, CalculationConstants.TEST_MASS_COEFFICIENT, usableMass);
        logger.debug("Request ID[{}]: Cycle Energy - Phase {} - {} cycle profiles", requestId, cycle.getPhase(), profiles.size());
        logger.info("Request ID[{}]: Cycle Energy - Phase {} - CE: {} rounded from {}", requestId, cycle.getPhase(), ce, ceInd);

        logger.info("Request ID[{}]: StopWatch - Cycle energy ({}) - Energy calculation took {}ms", requestId, cycle.getPhase(),
                sw.getTime() - sortTime);
        return ce;
    }

    /**
     * Calculate cycle energy.
     *
     * @param calculation    the calculation
     * @param cycle          the cycle
     * @param generatedCycle the generated cycle
     * @param requestId      the request id
     * @return the double
     */
    private double calculateCycleEnergy(Calculation calculation, CycleDetails cycle, GeneratedCycle generatedCycle, String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        double f0 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F0_CODE, requestId))
                .orElseThrow(IllegalStateException::new);
        double f1 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F1_CODE, requestId))
                .orElseThrow(IllegalStateException::new);
        double f2 = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F2_CODE, requestId))
                .orElseThrow(IllegalStateException::new);

        int testMass = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);
        double usableMass = CalculationConstants.TEST_MASS_COEFFICIENT * testMass;
        sw.split();
        long sortTime = sw.getSplitTime();
        logger.debug("Request ID[{}]: StopWatch - Cycle energy ({}) - Fetching data took {}ms", requestId, cycle.getPhase(), sortTime);
        sw.unsplit();
        StopWatch swG = new StopWatch();
        swG.start();
        List<GeneratedCycleProfile> profiles = generatedCycle.getGenCycleProfiles();
        swG.stop();
        logger.info("Request ID[{}] : Generated Cycle profile points for phase {} took {}ms", requestId, generatedCycle.getPhase(), swG.getTime());
        IntToDoubleFunction mapper = i -> {
            GeneratedCycleProfile currentGeneratedCycleProfile = profiles.get(i);
            double avgSpeed = (profiles.get(i - 1).getVelocity() + currentGeneratedCycleProfile.getVelocity()) / 2;

            logger.debug("Request ID[{}]: Cycle Energy - Phase {} - {}", requestId, cycle.getPhase(), currentGeneratedCycleProfile);

            double fi = f0 + f1 * avgSpeed + f2 * avgSpeed * avgSpeed + usableMass * currentGeneratedCycleProfile.getAcceleration();
            double ei = 0;
            if (fi > 0)
                ei = fi * currentGeneratedCycleProfile.getDistance();

            return ei;
        };

        double ceInd = IntStream.range(1, profiles.size()).mapToDouble(mapper).filter(i -> i > 0).sum();
        double ce = BigDecimal.valueOf(ceInd).setScale(CalculationConstants.ROUND_CE, RoundingMode.HALF_UP).doubleValue();
        sw.stop();

        logger.debug("Request ID[{}]: Cycle Energy - Phase {} - f0({}), f1({}), f2({}), testmass({}), usableMass(testMass * {})({})", requestId,
                cycle.getPhase(), f0, f1, f2, testMass, CalculationConstants.TEST_MASS_COEFFICIENT, usableMass);
        logger.debug("Request ID[{}]: Cycle Energy - Phase {} - {} cycle profiles", requestId, cycle.getPhase(), profiles.size());
        logger.info("Request ID[{}]: Cycle Energy - Phase {} - CE: {} rounded from {}", requestId, cycle.getPhase(), ce, ceInd);

        logger.info("Request ID[{}]: StopWatch - Cycle energy ({}) - Energy calculation took {}ms", requestId, cycle.getPhase(),
                sw.getTime() - sortTime);

        return ce;
    }

    /**
     * * Calculate Downscale.
     *
     * @param pHASE_CODE  the hase code
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the cycle details
     */
    private Double calculateDownscale(String pHASE_CODE, Calculation calculation, String requestId) {

        try {

            double fDownscale = 0;
            StopWatch sw = new StopWatch();
            sw.start();
            double f0_Vind = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F0_CODE, requestId))
                    .orElseThrow(IllegalStateException::new);
            double f1_Vind = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F1_CODE, requestId))
                    .orElseThrow(IllegalStateException::new);
            double f2_Vind = calculation.getCalculatedData().getRoadLoad().map(q -> getPhysicalQuantity(q, CalculationConstants.F2_CODE, requestId))
                    .orElseThrow(IllegalStateException::new);
            int testMass = calculation.getCalculatedData().getTestMass().orElseThrow(IllegalStateException::new);

            double aDsci1 = 0;
            double pReqMaxi = 0;
            double vI = 0;
            double vI1 = 0;

            Optional<CycleDetails> cycleDetails = calculation.getReferences().getCycles().stream().filter(c -> c.getPhase().equals(pHASE_CODE))
                    .collect(Collectors.toList()).stream().findFirst();

            List<CycleProfile> profiles = null;
            if (cycleDetails.isPresent()) {
                profiles = cycleDetails.get().getProfiles();
            }

            if (profiles != null && !profiles.isEmpty()) {
                Optional<CycleProfile> cycleProfileVI = profiles.stream().filter(cp -> cp.getTime() == i1).collect(Collectors.toList()).stream()
                        .findFirst();

                Optional<CycleProfile> cycleProfileVI1 = profiles.stream().filter(cp -> cp.getTime() == i1 + 1).collect(Collectors.toList()).stream()
                        .findFirst();

                if (cycleProfileVI.isPresent())
                    vI = cycleProfileVI.get().getVelocity();
                if (cycleProfileVI1.isPresent())
                    vI1 = cycleProfileVI1.get().getVelocity();
            }

            aDsci1 = (vI1 - vI) / 3.6;

            pReqMaxi = ((f0_Vind * vI) + (f1_Vind * Math.pow(vI, 2)) + (f2_Vind * Math.pow(vI, 3)) + (1.03 * testMass * vI * aDsci1)) / 3600;
            Float pMax = calculation.getFamily().getPmax();
            double rMax = 0;
            if (pMax != null && pMax > 0) {
                rMax = pReqMaxi / pMax;
            } else {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.DOWN_SCALE_ERR.getRuleCode(),
                        WltpEngineCalculatorErrorCode.DOWN_SCALE_ERR.getDescription());
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.DOWN_SCALE_ERR);
            }
            if (rMax < r0Downscale)
                fDownscale = 0;

            if (rMax >= r0Downscale)
                fDownscale = (a1Downscale * rMax) + b1Downscale;

            fDownscale = BigDecimal.valueOf(fDownscale).setScale(CalculationConstants.ROUND_F3, RoundingMode.HALF_UP).doubleValue();

            logger.info("Request ID[{}]: vI : {}, vI1 : {}, aDsci1 : {}, pReqMaxi : {}, PMAX : {}, rMax : {}, a1Downscale : {}", requestId, vI, vI1,
                    aDsci1, pReqMaxi, pMax, rMax, a1Downscale);
            logger.info("Request ID[{}]: fDownscale : {}", requestId, fDownscale);
            if (fDownscale <= 0.010) {
                fDownscale = 0;
            }

            sw.stop();
            logger.info("Request ID[{}]: StopWatch - fDownscale calculation took {}ms", requestId, sw.getTime());
            return fDownscale;
        } catch (Exception e) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.DOWN_SCALE_ERR.getRuleCode(),
                    WltpEngineCalculatorErrorCode.DOWN_SCALE_ERR.getDescription());
            throw e;
        }

    }

    /**
     * Sets the parameter values.
     *
     * @param requestId the new parameter values
     */
    private void setParameterValues(String requestId) {
        StopWatch sw = new StopWatch();
        sw.start();
        List<Parameter> parametersList = parameterRepository.all();

        Parameter i1_downscale_pmax_time = null;
        Parameter a1_downscale = null;
        Parameter b1_downscale = null;
        Parameter r0_downscale = null;
        if (!parametersList.isEmpty()) {
            i1_downscale_pmax_time = parametersList.stream().filter(p -> p.getCode().equals(I1_DOWN_SCALE_PMAX_TIME)).collect(Collectors.toList())
                    .get(0);
            a1_downscale = parametersList.stream().filter(p -> p.getCode().equals(A1_DOWN_SCALE)).collect(Collectors.toList()).get(0);
            b1_downscale = parametersList.stream().filter(p -> p.getCode().equals(B1_DOWN_SCALE)).collect(Collectors.toList()).get(0);
            r0_downscale = parametersList.stream().filter(p -> p.getCode().equals(R0_DOWN_SCALE)).collect(Collectors.toList()).get(0);
        }

        if (i1_downscale_pmax_time != null)
            i1 = Integer.parseInt(i1_downscale_pmax_time.getValue());

        if (a1_downscale != null)
            a1Downscale = Double.parseDouble(a1_downscale.getValue());

        if (b1_downscale != null)
            b1Downscale = Double.parseDouble(b1_downscale.getValue());

        if (r0_downscale != null)
            r0Downscale = Double.parseDouble(r0_downscale.getValue());

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Fetching the details from parameter table took {}ms", requestId, sw.getTime());
    }

    /**
     * Calculate emissions.
     *
     * @param calculation  the calculation
     * @param phase        the phase
     * @param measureTypes the measure types
     * @param requestId    the request id
     * @return the calculated phase
     */
    private CalculatedPhase calculateEmissions(Calculation calculation, CalculatedPhase phase, List<UUID> measureTypes, String requestId) {
        logger.info("Request ID[{}]: Emissions - phase {}, energy {}", requestId, phase.getPhaseCode(), phase.getCycleEnergy().getValue());

        StopWatch sw = new StopWatch();
        sw.start();
        Pair<VehicleBoundary, VehicleBoundary> boundaries = vehicleBoundaryService.vehicleBoundaries(calculation.getFamily().getGuid(),
                phase.getCycleGuid(), phase.getCycleEnergy().getValue());

        double energyLow = boundaries.getValue0().getCycleEnergy();
        double energyHigh = boundaries.getValue1().getCycleEnergy();
        double energyInd = phase.getCycleEnergy().getValue();

        logger.info("Request ID[{}]: Emissions - energies low({}) ind({}) high({})", requestId, energyLow, energyInd, energyHigh);

        Map<UUID, Double> highMeasureMap = boundaries.getValue1().getMeasures();
        // CAP-23272 How to manage incomplete vehicles where vehCategory!=N1 && vehCategory!=M1 starts here
        if ((calculation.getVersion().getConversionData() == null || calculation.getVersion().getConversionData().isEmpty())
                && "I".equalsIgnoreCase(calculation.getTvvDetails().getTvvCompleteFlag())) {
            String vehicleCategory = calculation.getTvvDetails().getTvvVehicleCategory();
            // fixed jira-762 and 763 as N1, M1, M2 should follow standard calculations a
            if (StringUtils.isNotBlank(vehicleCategory) && vehicleCategory.equalsIgnoreCase("N2")) {
                logger.info("Request ID[{}]: Incomplete Vehicle category {}", requestId, vehicleCategory);
                FamilyDetails family = calculation.getFamily();
                String familyType = family != null ? family.getType() : "";
                if (StringUtils.isNotBlank(familyType) && !highMeasureMap.isEmpty()) {
                    if ("CONV".equalsIgnoreCase(familyType)) {
                        logger.info("Request ID[{}]: Incomplete Vehicle family type {}", requestId, familyType);
                        measureTypes.stream().forEach(t -> {
                            MeasureType mtp = measureTypeRepository.load(t);
                            // fixed jira-762 for N2 category to include cycle energy line
                            if (mtp.getCode().equalsIgnoreCase(CalculationConstants.CO2_EMISSION)
                                    || mtp.getCode().equalsIgnoreCase(CalculationConstants.FUEL_CONSUMPTION)
                                    || mtp.getCode().equalsIgnoreCase(CalculationConstants.CYCLE_ENERGY_CODE)) {
                                phase.addEmission(mtp, highMeasureMap.get(t));

                                logger.info("Request ID[{}]: Incomplete Vehicle Emissions - Calcul - {}  - {} - VHIGH result({})", requestId,
                                        phase.getPhaseCode(), measureTypeRepository.load(t).getCode(), highMeasureMap.get(t));
                            }
                        });
                        return phase;
                    } else if ("HYRE".equalsIgnoreCase(familyType) || "ELEC".equalsIgnoreCase(familyType)) {
                        logger.info("Request ID[{}]: Incomplete Vehicle inside family type condition", requestId);
                        measureTypes.stream().forEach(t -> {
                            phase.addEmission(measureTypeRepository.load(t), highMeasureMap.get(t));

                            logger.info("Request ID[{}]: Incomplete Vehicle Emissions - Calcul - {}  - {} - VHIGH result({})", requestId,
                                    phase.getPhaseCode(), measureTypeRepository.load(t).getCode(), highMeasureMap.get(t));
                        });
                        return phase;
                    }
                }
            }
        }
        // CAP-23272 How to manage incomplete vehicles where vehCategory!=N1 && vehCategory!=M1 ends here

        double lowIndDelta = energyInd - energyLow;
        double lowHighDelta = energyHigh - energyLow;
        double interpolationCoeff = lowIndDelta / lowHighDelta;
        logger.info("Request ID[{}]: Emissions - Deltas: lowIndDelta({}) lowHighDelta({})", requestId, lowIndDelta, lowHighDelta);
        logger.info("Request ID[{}]: Emissions - Interpolation coeff: {}", requestId, interpolationCoeff);

        Map<UUID, Double> lowMeasureMap = boundaries.getValue0().getMeasures();

        logger.info("Request ID[{}]: Emissions - Measures low : {}", requestId, lowMeasureMap);
        logger.info("Request ID[{}]: Emissions - Measures high: {}", requestId, highMeasureMap);

        if (!lowMeasureMap.keySet().containsAll(measureTypes) || !highMeasureMap.keySet().containsAll(measureTypes)) {
            LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_FAMILY.getRuleCode(),
                    WltpEngineCalculatorErrorCode.MISSING_FAMILY.getDescription());
            throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_FAMILY);
        }

        // fixed JIRA-466 and JIRA-460 starts here
        if (!highMeasureMap.isEmpty() && BigDecimal.valueOf(energyLow).equals(BigDecimal.valueOf(energyHigh))) {
            measureTypes.stream().forEach(t -> {
                phase.addEmission(measureTypeRepository.load(t), highMeasureMap.get(t));

                logger.info("Request ID[{}]: Emissions - Calcul - {}  - {} - VHIGH result({})", requestId, phase.getPhaseCode(),
                        measureTypeRepository.load(t).getCode(), highMeasureMap.get(t));
            });
            return phase;
        }
        // fixed JIRA-466 and JIRA-460 ends here
        sw.split();
        long splitTime = sw.getSplitTime();
        logger.debug("Request ID[{}]: StopWatch - Emissions ({}) - Fetching and calculation preparation took {}ms", requestId, phase.getPhaseCode(),
                splitTime);
        sw.unsplit();

        Consumer<MeasureType> emissionCalculation = t -> {
            double lowValue = lowMeasureMap.get(t.getGuid());
            double highValue = highMeasureMap.get(t.getGuid());

            double result = lowValue + (highValue - lowValue) * interpolationCoeff;

            logger.info("Request ID[{}]: Emissions - Calcul - {} - {} - low({}) high({}) result({}), rounded to {}", requestId, phase.getPhaseCode(),
                    t.getCode(), lowValue, highValue, result, getPhaseResultInFormat(t.getCode(), result));

            phase.addEmission(t, result);
        };

        measureTypes.stream().map(measureTypeRepository::load).forEach(emissionCalculation);

        sw.stop();
        logger.info("Request ID[{}]: StopWatch - Emissions ({}) - Emissions calculation took {}ms", requestId, phase.getPhaseCode(),
                sw.getTime() - splitTime);
        return phase;
    }

    /**
     * Gets the car convertor value.
     *
     * @param conversionData the conversion data
     * @param conversionCode the conversion code
     * @return the car convertor value
     */
    private Optional<String> getCarConvertorValue(List<ConversionData> conversionData, String conversionCode) {
        return conversionData.stream().filter(cd -> cd.getCode().equals(conversionCode)).findFirst().map(ConversionData::getValue);
    }

    /**
     * Check CO 2 controls.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return the list
     */
    private void checkCO2Controls(Calculation calculation, String requestId) {
        StopWatch swTotal = new StopWatch();
        swTotal.start();
        StopWatch sw1 = new StopWatch();
        sw1.start();
        String roadLoadType = calculation.getFamily().getRoadLoad();
        String vehicleType = calculation.getFamily().getType();

        /** The UUID of phase of VLOW Test Vehicle TYPE */
        UUID vLowTypeID = testVehicleTypeRepository.guidByCode("VLOW").orElseThrow(IllegalStateException::new);
        /** The UUID of phase of VLOW Test Vehicle TYPE */
        UUID vHighTypeID = testVehicleTypeRepository.guidByCode("VHIGH").orElseThrow(IllegalStateException::new);

        // JIRA-327 Fix -Added the filter for COMB type
        Optional<List<CalculatedPhase>> calculatedPhases = calculation.getCalculatedData().getCalculatedPhases();

        sw1.stop();
        logger.debug("Request ID[{}]: StopWatch - CO2 controls - Initial Data retrieval {}ms", requestId, sw1.getTime());
        if (calculatedPhases.isPresent()) {
            List<CalculatedPhase> combPhases = calculatedPhases.get().stream().filter(cp -> cp.getPhaseCode().equals(RequestType.COMB.name()))
                    .collect(Collectors.toList());

            if (combPhases != null && !combPhases.isEmpty())
                combPhases.forEach(cph -> {
                    /** The UUID of phase of C02 to check in Test Vehicles */
                    logger.info("Request ID[{}]: Vehicle Type[{}] and RoadLoadType[{}]", requestId, vehicleType, roadLoadType);
                    UUID phaseID = cph.getCycleGuid();
                    if (VehicleTypes.HYRE.vehicleType.equalsIgnoreCase(vehicleType)
                            && roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                        irlCO2ControlsForHybridVehicles(calculation.getFamily().getVehicles(), cph, vLowTypeID, vHighTypeID, phaseID, requestId);
                    } else if (VehicleTypes.ELEC.vehicleType.equalsIgnoreCase(vehicleType)) {
                        // jira-749 fixed
                        co2ControlsForElectricVehicles(calculation.getFamily().getVehicles(), cph, vLowTypeID, vHighTypeID, phaseID, requestId);
                    } else {
                        if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType)
                                || roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType))
                            mrlAndDrlCO2Controls(calculation.getFamily().getVehicles(), cph, vLowTypeID, vHighTypeID, phaseID, requestId);
                        else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType))
                            irlCO2Controls(calculation.getFamily().getVehicles(), cph, vLowTypeID, vHighTypeID, phaseID, roadLoadType, requestId);
                    }
                });

        }
        swTotal.stop();
        logger.info("Request ID[{}]: StopWatch - CO2 controls - CO2 limits check took {}ms", requestId, swTotal.getTime());
    }

    /**
     * Irl CO 2 controls for hybrid vehicles.
     *
     * @param testVehicles the test vehicles
     * @param cph          the cph
     * @param vLowTypeID   the v low type ID
     * @param vHighTypeID  the v high type ID
     * @param phaseID      the phase ID
     * @param requestId    the request id
     */
    private void irlCO2ControlsForHybridVehicles(List<TestVehicle> testVehicles, CalculatedPhase cph, UUID vLowTypeID, UUID vHighTypeID, UUID phaseID,
            String requestId) {
        logger.info("Request ID[{}]: Using IRL rules for Hybrid Vehicle for checking CO2 limits of phase[{}]", requestId, cph.getPhaseCode());
        cph.getEmissions().stream().filter(cm -> cm.getMeasureTypeCode().equalsIgnoreCase(CalculationConstants.CO2CS)).forEach(em -> {

            StopWatch stpw1 = new StopWatch();
            stpw1.start();

            String mtCode = em.getMeasureTypeCode();

            UUID co2csMeasureTypeID = measureTypeRepository.guidByCode(mtCode).orElseThrow(IllegalStateException::new);

            Double vlowCO2CS = getMeasureValue(testVehicles, vLowTypeID, co2csMeasureTypeID, phaseID, requestId);

            Double vhighCO2CS = getMeasureValue(testVehicles, vHighTypeID, co2csMeasureTypeID, phaseID, requestId);

            Double vindCO2CS = em.getValue();

            Double resultC = vhighCO2CS + THREE;

            Double resultC1 = vlowCO2CS - THREE;

            int resultE = 0;

            /* Commented the below lines of code as part of LOT24 changes */
//          int resultE = 0;
//
//          if (vhighCO2CS >= THIRTY) {
//              resultE = THIRTY;
//          }
            /* Added the below line and if condition as part of the LOT24 changes -Starts Here */
            Double resultD = ((vhighCO2CS * 20) / 100) + FIVE;
            if (resultD >= TWENTY) {
                resultE = TWENTY;
            } else {
                resultE = resultD.intValue();
            }
            /* Added the above code as part of the LOT24 changes -Ends Here */

            Double resultF = vlowCO2CS + resultE;

            Double resultF1 = vhighCO2CS - resultE;

            double resultG = Math.min(resultC, resultF);

            double resultG1 = Math.max(resultC1, resultF1);

            logger.info("Request ID[{}]: CO2 VIN {}: [{}], VLOW {}: [{}], VHIGH {}: [{}]", requestId, mtCode, vindCO2CS, mtCode, vlowCO2CS, mtCode,
                    vhighCO2CS);

            logger.info("Request ID[{}]: C: [{}], C': [{}], E: [{}], F: [{}], F': [{}], G=Min(C,F): [{}], G'=Max(C',F'): [{}]", requestId, resultC,
                    resultC1, resultE, resultF, resultF1, resultG, resultG1);

            stpw1.stop();
            if (vindCO2CS > resultG1 || vindCO2CS < resultG) {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());

                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            }

        });
    }

    /**
     * Co 2 controls for electric vehicles.
     *
     * @param testVehicles the test vehicles
     * @param cph          the cph
     * @param vLowTypeID   the v low type ID
     * @param vHighTypeID  the v high type ID
     * @param phaseID      the phase ID
     * @param requestId    the request id
     */
    private void co2ControlsForElectricVehicles(List<TestVehicle> testVehicles, CalculatedPhase cph, UUID vLowTypeID, UUID vHighTypeID, UUID phaseID,
            String requestId) {
        CalculatedMeasure ce = cph.getEmissions().stream()
                .filter(cm -> cm.getMeasureTypeCode().equalsIgnoreCase(CalculationConstants.CYCLE_ENERGY_CODE)).findAny().orElse(null);
        logger.info("Request ID[{}]: Using IRL rules for Electric Vehicle for checking CO2 limits of phase[{}]", requestId, cph.getPhaseCode());
        cph.getEmissions().stream().filter(cm -> cm.getMeasureTypeCode().equalsIgnoreCase(CalculationConstants.EC)).forEach(em -> {

            StopWatch stpw2 = new StopWatch();
            stpw2.start();
            String mtCode = em.getMeasureTypeCode();

            UUID ecMeasureTypeID = measureTypeRepository.guidByCode(mtCode).orElseThrow(IllegalStateException::new);

            Double vlowEC = getMeasureValue(testVehicles, vLowTypeID, ecMeasureTypeID, phaseID, requestId);

            Double vhighEC = getMeasureValue(testVehicles, vHighTypeID, ecMeasureTypeID, phaseID, requestId);

            Double ecTvvValue = em.getValue();

            stpw2.stop();
            logger.info("Request ID[{}]: TVV EC : [{}], VLOW {}: [{}], VHIGH {}: [{}]", requestId, ecTvvValue, mtCode, vlowEC, mtCode, vhighEC);

            logger.debug("Request ID[{}]: StopWatch - Electric Consumption controls - Data retrieval rules for {} calculation {}ms", requestId,
                    mtCode, stpw2.getTime());

            String vlowECStrRoundedValue = getPhaseResultInFormat(mtCode, vlowEC);
            String vhighECStrRoundedValue = getPhaseResultInFormat(mtCode, vhighEC);
            Double vlowECRoundedDoubleValue = Double.valueOf(vlowECStrRoundedValue);
            Double vhighECRoundedDoubleValue = Double.valueOf(vhighECStrRoundedValue);
            if (ecTvvValue < vlowECRoundedDoubleValue || ecTvvValue > vhighECRoundedDoubleValue) {
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.EC_VALIDITY.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.EC_VALIDITY.getDescription() + " :" + ecTvvValue + " - CE:"
                        + getPhaseResultInFormat(ce.getMeasureTypeCode(), ce.getValue()));
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            }

        });

        cph.getEmissions().stream().filter(cm -> cm.getMeasureTypeCode().equalsIgnoreCase(CalculationConstants.PER)).forEach(em -> {

            StopWatch stpw3 = new StopWatch();
            stpw3.start();
            String mtCode = em.getMeasureTypeCode();

            UUID perMeasureTypeID = measureTypeRepository.guidByCode(mtCode).orElseThrow(IllegalStateException::new);

            Double vlowPER = getMeasureValue(testVehicles, vLowTypeID, perMeasureTypeID, phaseID, requestId);

            Double vhighPER = getMeasureValue(testVehicles, vHighTypeID, perMeasureTypeID, phaseID, requestId);

            Double perTvvValue = em.getValue();

            stpw3.stop();
            logger.info("Request ID[{}]: TVV PER : [{}], VLOW {}: [{}], VHIGH {}: [{}]", requestId, perTvvValue, mtCode, vlowPER, mtCode, vhighPER);

            logger.debug("Request ID[{}]: StopWatch - Pure Electric Range controls - Data retrieval rules for {} calculation {}ms", requestId, mtCode,
                    stpw3.getTime());

            String vlowPERStrRoundedValue = getPhaseResultInFormat(mtCode, vlowPER);
            String vhighPERStrRoundedValue = getPhaseResultInFormat(mtCode, vhighPER);
            Double vlowPERRoundedDoubleValue = Double.valueOf(vlowPERStrRoundedValue);
            Double vhighPERRoundedDoubleValue = Double.valueOf(vhighPERStrRoundedValue);

            if (perTvvValue < vhighPERRoundedDoubleValue || perTvvValue > vlowPERRoundedDoubleValue) {
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setRuleCode(WltpEngineCalculatorErrorCode.PER_VALIDITY.getRuleCode());
                wltpErrorCode.setDescription(WltpEngineCalculatorErrorCode.PER_VALIDITY.getDescription() + " :" + perTvvValue + " - CE:"
                        + getPhaseResultInFormat(ce.getMeasureTypeCode(), ce.getValue()));
                LogErrorUtility.logTheError(logger, requestId, ERRW + wltpErrorCode.getRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            }

        });

    }

    /**
     * Mrl CO 2 controls.
     *
     * @param testVehicles the test vehicles
     * @param cph          the cph
     * @param vLowTypeID   the v low type ID
     * @param vHighTypeID  the v high type ID
     * @param phaseID      the phase ID
     * @param requestId    the request id
     */
    private void mrlAndDrlCO2Controls(List<TestVehicle> testVehicles, CalculatedPhase cph, UUID vLowTypeID, UUID vHighTypeID, UUID phaseID,
            String requestId) {
        logger.info("Request ID[{}]: Using MRL or DRL rules for checking CO2 limits of phase[{}]", requestId, cph.getPhaseCode());
        cph.getEmissions().stream().filter(cm -> cm.getMeasureTypeCode().contains(CalculationConstants.CO2)).forEach(em -> {
            StopWatch sw4 = new StopWatch();
            sw4.start();

            String mtCode = em.getMeasureTypeCode();
            /** The UUID of CO2 measure Type */
            UUID co2MeasureTypeID = measureTypeRepository.guidByCode(mtCode).orElseThrow(IllegalStateException::new);

            /** Measure Type containing CO2's value of VLOW TestVehicle according to Phase */
            Double vlowCO2 = getMeasureValue(testVehicles, vLowTypeID, co2MeasureTypeID, phaseID, requestId);
            /** Measure Type containing CO2's value of VHIGH TestVehicle according to Phase */
            Double vhighCO2 = getMeasureValue(testVehicles, vHighTypeID, co2MeasureTypeID, phaseID, requestId);
            /** Measure Type containing CO2's value of individual request according to Phase */
            Double vindCO2 = em.getValue();

            logger.info("Request ID[{}]: VIND {}: [{}], VLOW {}: [{}], VHIGH {}: [{}]", requestId, mtCode, vindCO2, mtCode, vlowCO2, mtCode,
                    vhighCO2);
            sw4.stop();
            logger.debug("Request ID[{}]: StopWatch - CO2 controls - Data retrieval for MRL or DRL rules for {} calculation {}ms", requestId, mtCode,
                    sw4.getTime());
            if (vindCO2 < vlowCO2 || vindCO2 > vhighCO2) {
                // logger.error(CO2_LIMIT_VIOLATED, requestId, cph.getPhaseCode(), mtCode);
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());

                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            }
        });
    }

    /**
     * IRL and DRL CO 2 controls.
     *
     * @param testVehicles the test vehicles
     * @param cph          the cph
     * @param vLowTypeID   the v low type ID
     * @param vHighTypeID  the v high type ID
     * @param phaseID      the phase ID
     * @param roadLoadType the road load type
     * @param requestId    the request id
     */
    private void irlCO2Controls(List<TestVehicle> testVehicles, CalculatedPhase cph, UUID vLowTypeID, UUID vHighTypeID, UUID phaseID,
            String roadLoadType, String requestId) {
        logger.info("Request ID[{}]: Using {} rules for checking CO2 limits of phase[{}]", requestId, roadLoadType, cph.getPhaseCode());

        cph.getEmissions().stream().filter(cm -> cm.getMeasureTypeCode().contains(CalculationConstants.CO2)).forEach(em -> {
            StopWatch sw6 = new StopWatch();
            sw6.start();
            String mtCode = em.getMeasureTypeCode();

            int amplitudeUpperLimit = CalculationConstants.AMPLITUDE_UPPER_LIMIT;
            double amplitudeVHighPercent = CalculationConstants.AMPLITUDE_VHIGH_PERCENTAGE;
            int lowerRange = CalculationConstants.MIN_EMISSION_RANGE;
            int upperRange = CalculationConstants.MAX_EMISSION_RANGE;
            UUID co2MeasureTypeID = measureTypeRepository.guidByCode(mtCode).orElseThrow(IllegalStateException::new);

            /** Measure Type containing CO2's value of VLOW TestVehicle according to Phase */
            Double vlowCO2 = getMeasureValue(testVehicles, vLowTypeID, co2MeasureTypeID, phaseID, requestId);
            /** Measure Type containing CO2's value of VHIGH TestVehicle according to Phase */
            Double vhighCO2 = getMeasureValue(testVehicles, vHighTypeID, co2MeasureTypeID, phaseID, requestId);
            /** Measure Type containing CO2's value of individual request according to Phase */
            Double vindCO2 = em.getValue();

            double amplitude = Math.min(amplitudeVHighPercent * vhighCO2, amplitudeUpperLimit);

            logger.info("Request ID[{}]: VIND [{}]: [{}], VLOW {}: [{}], VHIGH {}: [{}]", requestId, mtCode, vindCO2, mtCode, vlowCO2, mtCode,
                    vhighCO2);
            logger.info("Request ID[{}]: Amplitude: [{}]", requestId, amplitude);
            sw6.stop();
            logger.debug("Request ID[{}]: StopWatch - CO2 controls - Data retrieval for {} rules for measure type {} calculation took {}ms",
                    requestId, roadLoadType, mtCode, sw6.getTime());
            if (vindCO2 < (vlowCO2 - lowerRange)) {
                // logger.error(CO2_LIMIT_VIOLATED, requestId, cph.getPhaseCode(), mtCode);
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());

                logger.error("Request ID[{}]: [{}] Result [{}] is lesser than the difference of VLOW {} [{}] and [{}]", requestId, mtCode, vindCO2,
                        mtCode, vlowCO2, lowerRange);

                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            } else if (vindCO2 < vlowCO2 && Math.abs(vindCO2 - vhighCO2) > amplitude) {
                // logger.error(CO2_LIMIT_VIOLATED, requestId, cph.getPhaseCode(), mtCode);
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());
                logger.error(
                        "Request ID[{}]: [{}] Result [{}] is lesser than VLOW {} value [{}] AND the absolute difference of [{}] Result [{}] and VHIGH {} value [{}] is greater than Amplitude value [{}]",
                        requestId, mtCode, vindCO2, mtCode, vlowCO2, mtCode, vindCO2, mtCode, vhighCO2, amplitude);
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            } else if (vindCO2 > (vhighCO2 + upperRange)) {
                // logger.error(CO2_LIMIT_VIOLATED, requestId, cph.getPhaseCode(), mtCode);
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());
                logger.error("Request ID[{}]: [{}] Result [{}] is greater than sum of VHIGH {} [{}] and [{}]", requestId, mtCode, vindCO2, mtCode,
                        vhighCO2, upperRange);
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            } else if (vindCO2 > vhighCO2 && Math.abs(vindCO2 - vlowCO2) > amplitude) {
                // logger.error(CO2_LIMIT_VIOLATED, requestId, cph.getPhaseCode(), mtCode);
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.CO2_VALIDITY.getRuleCode(),
                        WltpEngineCalculatorErrorCode.CO2_VALIDITY.getDescription());
                logger.error(
                        "Request ID[{}]: [{}] Result [{}] is greater than VHIGH {} value [{}] AND the absolute difference of [{}] Result [{}] and VLOW {} value [{}] is greater than Amplitude value [{}]",
                        requestId, mtCode, vindCO2, mtCode, vhighCO2, mtCode, vindCO2, mtCode, vlowCO2, amplitude);
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.CO2_VALIDITY);
            }
        });
    }

    /**
     * Gets the measure value.
     *
     * @param testVehicles      the test vehicles
     * @param testVehicleTypeID the test vehicle type ID
     * @param co2MeasureTypeID  the co 2 measure type ID
     * @param phaseID           the phase ID
     * @param requestId         the request id
     * @return the measure value
     */
    private Double getMeasureValue(List<TestVehicle> testVehicles, UUID testVehicleTypeID, UUID co2MeasureTypeID, UUID phaseID, String requestId) {
        return testVehicles.stream().filter(tv -> tv.getType().equals(testVehicleTypeID)).findFirst()
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA)).getMeasures().stream()
                .filter(mvl -> mvl.getPhase().equals(phaseID) && mvl.getType().equals(co2MeasureTypeID)).findFirst()
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA)).getValue();
    }

    /**
     * Gets the physical quantity.
     *
     * @param physicalQuantities the physical quantities
     * @param code               the code
     * @param requestId          the request id
     * @return the physical quantity
     */
    private Double getPhysicalQuantity(List<EnginePhysicalQuantity> physicalQuantities, String code, String requestId) {
        return physicalQuantities.stream().filter(epq -> code.equals(epq.getCode())).findFirst().map(EnginePhysicalQuantity::getValue)
                .orElseThrow(() -> logAndCreateException(requestId, WltpEngineCalculatorErrorCode.MISSING_COMPUTATION_DATA));
    }

    /**
     * Gets the physical quantity value.
     *
     * @param pqsValueLst the pqs value lst
     * @param code        the code
     * @return the physical quantity value
     */
    private Double getPhysicalQuantityValue(List<PhysicalQuantityValue> pqsValueLst, String code) {
        return pqsValueLst.stream().filter(t -> physicalQuantityTypeRepository.load(t.getType()).getCode().equals(code))
                .mapToDouble(m -> m.getValue()).findFirst().getAsDouble();

    }

    /**
     * Gets the phase result in format.
     *
     * @param code  the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = mtpRoundingMap.get(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Check vlow and vhigh CE values.
     *
     * @param calculation the calculation
     * @param requestId   the request id
     * @return true, if successful
     */
    private boolean checkVlowAndVhighCEValues(Calculation calculation, String requestId) {
        FamilyDetails family = calculation.getFamily();
        if (family != null) {
            List<TestVehicle> vehList = family.getVehicles();
            Map<String, Double> ceLowHighMap = getVehicleCEValue(vehList);
            logger.info("Request ID[{}] : Phase COMB - CE(VLOW) : [{}], CE(VHIGH) : [{}]", requestId, ceLowHighMap.get(CalculationConstants.VLOW),
                    ceLowHighMap.get(CalculationConstants.VHIGH));
            if (Double.compare(ceLowHighMap.get(CalculationConstants.VLOW), ceLowHighMap.get(CalculationConstants.VHIGH)) == 0) {
                int testMass = getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.MASS_CODE).intValue();
                logger.info("Request ID[{}]: TestMass : {}", requestId, testMass);
                calculation.setCalculatedData(calculatedDataFactory.withTestMass(testMass));

                List<EnginePhysicalQuantity> roadLoad = new ArrayList<>();

                String roadLoadType = family.getRoadLoad();
                roadLoad.add(new EnginePhysicalQuantity(CalculationConstants.F0_CODE,
                        getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F0_CODE)));
                logger.info("Request ID[{}]: F0 : {}", requestId,
                        getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F0_CODE));
                if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                    roadLoad.add(new EnginePhysicalQuantity(CalculationConstants.F1_CODE,
                            getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F1_CODE)));
                    logger.info("Request ID[{}]: F1 : {}", requestId,
                            getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F1_CODE));
                } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType)
                        || roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType)) {
                    roadLoad.add(new EnginePhysicalQuantity(CalculationConstants.F1_CODE, 0));
                    logger.info("Request ID[{}]: F1 : {}", requestId, 0);
                }

                roadLoad.add(new EnginePhysicalQuantity(CalculationConstants.F2_CODE,
                        getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F2_CODE)));
                logger.info("Request ID[{}]: F2 : {}", requestId,
                        getPhysicalQuantityValue(vehList.get(0).getQuantities(), CalculationConstants.F2_CODE));
                calculation.getCalculatedData().setRoadLoad(roadLoad);
                if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.IRL.roadLoadType)) {
                    logger.info("Request ID[{}]: Newton SCX : {}", requestId,
                            getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.SCX_CODE, requestId));
                    logger.info("Request ID[{}]: Newton CRR : {}", requestId,
                            getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.CRR_CODE, requestId));
                } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.MRL.roadLoadType)) {
                    logger.info("Request ID[{}]: Newton CRR : {}", requestId,
                            getPhysicalQuantity(calculation.getPhysicalQuantities(), CalculationConstants.CRR_CODE, requestId));
                    logger.info("Request ID[{}]: TVV Frontal Area : {}", requestId, calculation.getTvvDetails().getTvvAf());
                } else if (roadLoadType.equalsIgnoreCase(RoadLoadTypes.DRL.roadLoadType)) {
                    logger.info("Request ID[{}]: TVV Height : {} TVV Width : {}", requestId, calculation.getTvvDetails().getTvvHeigth(),
                            calculation.getTvvDetails().getTvvWidth());
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Gets the vehicle CE value.
     *
     * @param vehList the veh list
     * @return the vehicle CE value
     */
    private Map<String, Double> getVehicleCEValue(List<TestVehicle> vehList) {
        Map<String, Double> vehMeasures = new HashMap<>();
        for (TestVehicle testVehicle : vehList) {
            TestVehicleType vehType = testVehicleTypeRepository.load(testVehicle.getType());
            if (vehType.getCode().equalsIgnoreCase(CalculationConstants.VHIGH) || vehType.getCode().equalsIgnoreCase(CalculationConstants.VLOW)) {
                testVehicle.getMeasures().forEach(mvl -> {
                    MeasureType mtp = measureTypeRepository.load(mvl.getType());
                    CyclePhase cph = cyclePhaseRepository.load(mvl.getPhase());
                    if (null != mtp && mtp.getCode().equalsIgnoreCase(CalculationConstants.CYCLE_ENERGY_CODE) && null != cph
                            && "COMB".equalsIgnoreCase(cph.getCode())) {
                        vehMeasures.put(vehType.getCode(), mvl.getValue());
                    }
                });
            }
        }
        return vehMeasures;
    }

}
