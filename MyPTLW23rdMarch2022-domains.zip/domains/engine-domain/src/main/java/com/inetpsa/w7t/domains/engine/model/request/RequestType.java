/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

/**
 * The Enum RequestType.
 */
public enum RequestType {

    FULL, UNKNOWN, COMB, TEST;
}
