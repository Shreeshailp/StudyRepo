/*
 * Creation : 13 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum WltpEngineCalculatorErrorCode.
 */
public enum WltpEngineCalculatorErrorCode implements ErrorCode {

    /** The no gvm found. */
    NO_GVM_FOUND(208, "MTAC value missing or unknown"),
    /** The no percentage payload. */
    NO_PERCENTAGE_PAYLOAD(209, "No percentage payload found for this vehicle"),
    /** Too many payload percentage found. */
    SEVERAL_PERCENTAGE_PAYLOAD(210, "Several percentages payload found for this vehicle"),
    /** The no destination found. */
    NO_DESTINATION_FOUND(211, "No destination found for this vehicle"),
    /** Too many destinations found. */
    SEVERAL_DESTINATIONS_FOUND(212, "Several destinations found for this vehicle"),
    /** The negative vehicle payload. */
    NEGATIVE_VEHICLE_PAYLOAD(401, "Payload negative for this vehicle"),
    /** The missing computation data. */
    MISSING_COMPUTATION_DATA(402, "Missing required data for computation"),
    /** The missing family. */
    MISSING_FAMILY(403, "Wltp family data missing for computation"),

    /** The coherence on ref profile cycle . */
    REF_PROFILE_MISSING(213, "Ref. profile missing in wltp family for this veh."),
    /** The CO2 validity. */
    CO2_VALIDITY(404, "The CO2 value is outside the limits"),

    /** The missing family code. */
    MISSING_FAMILY_CODE(201, "Wltp family code missing"),
    /** The missing family index. */
    MISSING_FAMILY_INDEX(202, "Wltp family index missing"),
    /** The missing country. */
    MISSING_COUNTRY(205, "Missing program country in the extended title"),

    /** The no fom found. */
    NO_FOM_FOUND(217, "Full options mass value missing or unknown"),
    /** The no em found. */
    NO_EM_FOUND(215, "Empty mass value missing or unknown"),
    /** The unknown crr. */
    UNKNOWN_CRR(305, "Energy Efficiency Class not found"),
    /** The unknown tvv. */
    UNKNOWN_TVV(218, "Unknown TVV"),

    /** The down scale err. */
    DOWN_SCALE_ERR(405, "error during downscale calculation"),

    /** The energy calcul err. */
    ENERGY_CALCUL_ERR(405, "error during energy calculation"),

    /** The missing computation data for road load. */
    MISSING_COMPUTATION_DATA_FOR_ROAD_LOAD(402, "Data missing for road load computation"),

    /** The missing mtac cc. */
    MISSING_MTACTR_CC(650, "MTAC of converted car missing or incorrect"),
    /** The missing mopt cc. */
    MISSING_MOPTTR_CC(651, "Full option mass of converted car missing or incorrect"),
    /** The missing cattr cc. */
    MISSING_CATTR_CC(652, "Category of converted car missing or incorrect"),
    /** The missing mcor cc. */
    MISSING_MCOR_CC(653, "Corvet Mass of converted car missing or incorrect"),
    /** The missing dmtr cc. */
    MISSING_DMTR_CC(654, "Delta Mass of converted car missing or incorrect"),
    /** The missing crrtr cc. */
    MISSING_CRRTR_CC(656, "CRR of converted car missing or incorrect"),

    /** The no generated cycles found. */
    NO_GENERATED_CYCLES_FOUND(411, "cycle not found"),

    /** The illegal calculation. */
    ILLEGAL_CALCULATION(400, "Illegal calculation state error, check engine logs"),

    /** The missing depol. */
    MISSING_DEPOL(657, "DEPOL flag missing or incorrect"),

    /** The missing special. */
    MISSING_SPECIAL(658, "SPECIAL flag missing or incorrect (DEPOL)"),

    /** The missing real crr. */
    MISSING_REAL_CRR(659, "real CRR missing for converted car (DEPOL)"),

    /** The missing cool str. */
    MISSING_COOL_STR(660, " cooling surface missing for converted car (DEPOL)"),

    /** The missing code depol for tvv. */
    MISSING_CODE_DEPOL_FOR_TVV(661, "code depol missing for this TVV"),

    /** The depol data not found. */
    DEPOL_DATA_NOT_FOUND(661, "depol data not found for this TVV and special_flag"),

    /** The out of maxi pollutant. */
    OUT_OF_MAXI_POLLUTANT(663, "out of the maxi pollutant controls [MRO]"),

    /** The out of maxi pollutant str. */
    OUT_OF_MAXI_POLLUTANT_STR(664, "out of the maxi pollutant controls [Frontal Area]"),

    /** The out of maxi pollutant cool str. */
    OUT_OF_MAXI_POLLUTANT_COOL_STR(665, "out of the maxi pollutant controls [Cooling surf]"),

    /** The missing str. */
    MISSING_STR(667, "frontal area missing for converted car (DEPOL)"),

    /** The several depol data found. */
    SEVERAL_DEPOL_DATA_FOUND(666, "several depol data found for this CRR"),

    /** The out of maxi pollutant real crr. */
    OUT_OF_MAXI_POLLUTANT_REAL_CRR(662, "out of the maxi pollutant controls [CRR]"),
    /** The unknown family couple. */
    UNKNOWN_FAMILY_COUPLE(203, "Unknown couple family index in the extended title"),
    /** The physical data missing. */
    PHYSICAL_DATA_MISSING(106, "Physical data missing"),

    /** The pattern data not found. */
    PATTERN_DATA_NOT_FOUND(224, "unknown maturity : no pattern found"),

    /** The several pattern found. */
    SEVERAL_PATTERN_FOUND(225, "Unknown CO2 maturity : several patterns found"),

    /** The maturity not authorized. */
    MATURITY_NOT_AUTHORIZED(226, "CO2 not robust"),

    /** The family not available. */
    FAMILY_NOT_AVAILABLE(222, "WLTP family (aa/bb) not available"),

    /** The ec validity. */
    EC_VALIDITY(415, "The EC is outside the limit"),

    /** The per validity. */
    PER_VALIDITY(416, "The PER is outside the limit"),

    /** The out of maxi pollutant cxtr. */
    OUT_OF_MAXI_POLLUTANT_CXTR(670, "CXTR received is outside the limits"),

    /** The missing cxtr. */
    MISSING_CXTR(669, "CX received is equal to '0' and the CX in DEPOL table is not null"), NEWTON_MASS_LOW(671, "Newton mass error too low"),
    NEWTON_MASS_HIGH(672, "Newton mass error too high");

    /** The rule code. */
    private int ruleCode;

    /** The description. */
    private String description;

    /**
     * Instantiates a new wltp engine calculator error code.
     *
     * @param ruleCode    the rule code
     * @param description the description
     */
    WltpEngineCalculatorErrorCode(int ruleCode, String description) {
        this.ruleCode = ruleCode;
        this.description = description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public int getRuleCode() {
        return ruleCode;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    protected void setDescription(String description) {
        this.description = description;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return String.format("[%s] %d - %s", this.name(), ruleCode, description);
    }
}
