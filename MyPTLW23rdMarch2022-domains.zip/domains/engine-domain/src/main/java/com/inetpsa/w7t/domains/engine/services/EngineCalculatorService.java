/*
 * Creation : 27 mars 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import java.util.List;

import javax.validation.Valid;

import org.seedstack.business.Service;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.Request;

/**
 * The Interface EngineCalculatorService.
 */
@Service
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface EngineCalculatorService {
    /**
     * Calculate the emissions from a request entity.
     *
     * @param request the request
     * @return the calculated
     */
    Calculation calculate(@Valid Request request);

    /**
     * Calculate.
     *
     * @param version the version
     * @param physicalQuantities the physical quantities
     * @param requestId the request id
     * @return the calculation
     */
    Calculation calculate(@Valid Version version, List<EnginePhysicalQuantity> physicalQuantities, String requestId);

    /**
     * Calculate.
     *
     * @param version the version
     * @param physicalQuantities the physical quantities
     * @param request the request
     * @return the calculation
     */
    Calculation calculate(@Valid Version version, List<EnginePhysicalQuantity> physicalQuantities, Request request);
}
