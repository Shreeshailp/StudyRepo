/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.seedstack.business.Producible;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.business.assembler.MatchingEntityId;
import org.seedstack.business.assembler.MatchingFactoryParameter;
import org.seedstack.business.domain.DomainObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.RequestEntity;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedData;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;

/**
 * The Class Request. AOP validations are not enabled because of performance hits and {@code javax.validation} annotations are not possible on non
 * Guice created instances (<a href="https://github.com/google/guice/wiki/AOP#limitations">See limitations of AOP in Google Guice</a>)
 */
@DtoOf(RequestEntity.class)
public class Request implements Producible, DomainObject {

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(Request.class);

    /** The guid. */
    private UUID guid;

    /** The request batch id. */
    @NotNull(message = "The request batch ID must not be null")
    private UUID requestBatchId;

    /** The status. */
    @NotNull(message = "The request status must not be null")
    private RequestStatus status;

    /** The manual request. */
    private boolean manualRequest;

    /** The request type. */
    @NotNull(message = "The request type must not be null")
    private RequestType requestType;

    /** The file id. */
    @NotNull(message = "The file ID must not be null")
    @Pattern(regexp = "\\w{3}\\d{1,10}", message = "The file ID must follow the required pattern")
    @Size(min = 4, max = 13, message = "The file ID must be at least 4 and at most 13 characters long")
    private String fileId;

    /** The client request number. */

    @NotNull(message = "The client request number must not be null")
    @Pattern(regexp = "\\w{3}\\d{1,17}", message = "The client request number must follow the required pattern")
    @Size(min = 4, max = 20, message = "The client request number must be at least 4 and at most 20 characters long")
    private String requestId;

    /** The provider request number. */
    private String providerRequestNumber;

    /** The request date. */
    @NotNull(message = "The request date must not be null")
    private LocalDateTime requestDate;

    /** The answer date. */
    private LocalDateTime answerDate;

    /** The answer code. */
    @Size(min = 1, max = 8, message = "The answer code must be neither empty nor more than 8 characters long")
    private String answerCode;

    /** The answer designation. */
    @Size(min = 1, max = 50, message = "The answer designation must be neither empty nor more than 50 characters long")
    private String answerDesignation;

    /** The unladen mass. */
    private Double unladenMass;

    /** The equipment mass. */
    private Double equipmentMass;

    /** The vehicle mass. */
    private Double vehicleMass;

    /** The unladen scx. */
    private Double unladenSCX;

    /** The equipment scx. */
    private Double equipmentSCX;

    /** The vehicle scx. */
    private Double vehicleSCX;

    /** The vehicle crr. */
    private Double vehicleCRR;

    /** The vin. */
    @NotNull(message = "The VIN number must not be null")
    @Size(min = 17, max = 17, message = "The VIN must be exactly 17 characters long")
    private String vin;

    /** The ecom date. */
    @NotNull(message = "The ecom date must not be null")
    private LocalDate ecomDate;

    /** The extended title. */
    @NotNull(message = "The extended title must not be null")
    @Pattern(regexp = ".{24}(?:.{7})*", message = "The extended title is incorrect")
    @Size(min = 1, max = 3524, message = "The extended title must be at most 3524 characters long and not be empty")
    private String extendedTitle;

    /** The calculated values from the engine calculator. */
    private CalculatedData calculatedValues;

    /** The physical quantities from NEWTON. */
    private List<EnginePhysicalQuantity> physicalQuantities;

    /** the tvvDesignation. */
    private String tvv = "";

    /** The internal file id. */
    private String internalFileId;

    /** The maturity. */
    private String maturity = "";

    /**
     * Instantiates a new request.
     *
     * @param requestBatchId the request batch id
     * @param manualRequest the manual request
     * @param requestType the request type
     * @param fileId the file id
     * @param requestId the client request number
     * @param requestDate the request date
     * @param vin the vin
     * @param ecomDate the ecom date
     * @param extendedTitle the extended title
     */
    @Valid
    public Request(UUID requestBatchId, boolean manualRequest, RequestType requestType, String fileId, String requestId, LocalDateTime requestDate,
            String vin, LocalDate ecomDate, String extendedTitle) {
        this.requestBatchId = requestBatchId;
        this.status = RequestStatus.REQUEST_RECEIVED;
        this.manualRequest = manualRequest;
        this.requestType = requestType;
        this.fileId = fileId;
        this.requestId = requestId;
        this.requestDate = requestDate;
        this.vin = vin;
        this.ecomDate = ecomDate;
        this.extendedTitle = extendedTitle;
    }

    /**
     * Instantiates a new request.
     */
    public Request() { // NOSONAR No validation on empty constructor
        // Empty constructor for the factories and assemblers to use
    }

    /**
     * Update the request with the data calculated by the engine calculator.
     *
     * @param calculateObj the calculate obj
     * @return the request
     */
    public Request update(@Valid CalculatedData calculateObj) {
        this.calculatedValues = calculateObj;
        return this;
    }

    /**
     * Physical quantities.
     *
     * @return the optional
     */
    public Optional<List<EnginePhysicalQuantity>> physicalQuantities() {
        if (this.physicalQuantities == null)
            return Optional.empty();
        return Optional.of(this.physicalQuantities);
    }

    /**
     * Next step.
     *
     * @return the step
     */
    public Step nextStep() {
        String requestNo = this.requestId;
        RequestStatus oldStatus = this.status;
        this.status = this.status.nextStatus();

        StringBuilder nextStepLog = new StringBuilder();
        nextStepLog.append("Request ID[{").append(requestNo).append("}: ").append(LocalDate.now()).append(" ")
                .append(LocalTime.now().truncatedTo(ChronoUnit.SECONDS)).append(" ").append("Old Status = ").append(oldStatus.getStatusCode())
                .append("(").append(oldStatus).append("), New Status = ").append(this.status.getStatusCode()).append("(").append(this.status)
                .append(")");
        logger.info(nextStepLog.toString());

        return new Step(this.guid, this.status, oldStatus);
    }

    /**
     * To error status.
     *
     * @param error the error
     * @return the step
     */
    public Step toErrorStatus(RequestStatus error) {
        String requestNo = this.requestId;
        RequestStatus oldStatus = this.status;
        if (this.status.isCompletedStatus() || this.status.isFinalStatus())
            throw new IllegalArgumentException("Impossible to go from a completed status or a final status to an error status");
        if (!error.isErrorStatus())
            throw new IllegalArgumentException("Impossible to set the error status by providing a non-error status");
        this.status = error;

        StringBuilder errorStepLog = new StringBuilder();
        errorStepLog.append("Request ID[{").append(requestNo).append("}: ").append(LocalDate.now()).append(" ")
                .append(LocalTime.now().truncatedTo(ChronoUnit.SECONDS)).append(" ").append("Old Status = ").append(oldStatus.getStatusCode())
                .append("(").append(oldStatus).append("), New Status = ").append(this.status.getStatusCode()).append("(").append(this.status)
                .append(")");
        logger.info(errorStepLog.toString());

        return new Step(this.guid, this.status, oldStatus);
    }

    /**
     * Use answer.
     *
     * @param answerDate the answer date
     * @param answerCode the answer code
     * @param answerDesignation the answer designation
     * @return the request
     */
    @Valid
    public Request useAnswer(@NotNull(message = "The answer date must not be null") LocalDateTime answerDate,
            @NotNull(message = "The answer code must not be null") String answerCode,
            @NotNull(message = "The answer designation must not be null") String answerDesignation) {
        this.answerDate = LocalDateTime.from(answerDate);
        this.answerCode = answerCode;
        this.answerDesignation = answerDesignation;
        return this;
    }

    /**
     * Update physical quantities.
     *
     * @param physicalQuantities the physical quantities
     * @return the request
     */
    public Request updatePhysicalQuantities(
            @NotEmpty(message = "When updating the physical quantities, the list must neither be null nor empty") List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
        return this;
    }

    /**
     * Answer date.
     *
     * @return the optional
     */
    public Optional<LocalDateTime> answerDate() {
        if (answerDate == null)
            return Optional.empty();
        return Optional.of(LocalDateTime.from(answerDate));
    }

    /**
     * Answer code.
     *
     * @return the optional
     */
    public Optional<String> answerCode() {
        return Optional.ofNullable(answerCode);
    }

    /**
     * Answer designation.
     *
     * @return the optional
     */
    public Optional<String> answerDesignation() {
        return Optional.ofNullable(answerDesignation);
    }

    /**
     * Gets the client request number.
     *
     * @return the client request number
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the client request number.
     *
     * @param requestId the request number
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the request batch id.
     *
     * @return the request batch id
     */
    public UUID getRequestBatchId() {
        return requestBatchId;
    }

    /**
     * Sets the request batch id.
     *
     * @param requestBatchId the new request batch id
     */
    public void setRequestBatchId(UUID requestBatchId) {
        this.requestBatchId = requestBatchId;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Gets the wltp family.
     *
     * @param requestId the request id
     * @return the wltp family
     */
    public String getWltpFamily(String requestId) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8C(?<family>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("family");
        LogErrorUtility.logTheError(logger, requestId, RequestErrorCode.FAMILY_CODE_MISSING.getRuleCode(),
                RequestErrorCode.FAMILY_CODE_MISSING.getDescription());
        throw new IllegalStateException("The set extended title does not contain the WLTP family");
    }

    /**
     * Gets the wltp index.
     *
     * @param requestId the request id
     * @return the wltp index
     */
    public String getWltpIndex(String requestId) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("index");
        LogErrorUtility.logTheError(logger, requestId, RequestErrorCode.FAMILY_INDEX_MISSING.getRuleCode(),
                RequestErrorCode.FAMILY_INDEX_MISSING.getDescription());
        throw new IllegalStateException("The set extended title does not contain the WLTP family index");
    }

    /**
     * Gets the program country.
     *
     * @return the program country
     */
    public String getProgramCountry() {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:GG8(?<country>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("country");
        LogErrorUtility.logTheError(logger, requestId, RequestErrorCode.PROGRAM_COUNTRY_MISSING.getRuleCode(),
                RequestErrorCode.PROGRAM_COUNTRY_MISSING.getDescription());
        throw new IllegalStateException("The set extended title does not contain the program country");
    }

    /**
     * Gets the tvvT1A.
     *
     * @return the tvvT1A
     */
    public String getTvvT1A() {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T1A(?<t1a>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1a");

        return "";
    }

    /**
     * Gets the tvvT1B.
     *
     * @return the tvvT1B
     */
    public String getTvvT1B() {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T1B(?<t1b>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1b");
        return "";
    }

    /**
     * Gets the Vehicle Family.
     *
     * @param requestId the request id
     * @return the Vehicle Family
     */
    public String getVehicleFamily(String requestId) {
        Matcher m = java.util.regex.Pattern.compile("(....).{20}(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group(1);
        LogErrorUtility.logTheError(logger, requestId, RequestErrorCode.UNKNOWN_VEHICLE_FAMILY.getRuleCode(),
                RequestErrorCode.UNKNOWN_VEHICLE_FAMILY.getDescription());
        return "";
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Request [fileId=" + fileId + ", clientRequestNumber=" + requestId + ",guid=" + guid + ", requestBatchId=" + requestBatchId
                + ", status=" + status + ", manualRequest=" + manualRequest + ", requestType=" + requestType + ",  providerRequestNumber="
                + providerRequestNumber + ", requestDate=" + requestDate + ", answerDate=" + answerDate + ", answerCode=" + answerCode
                + ", answerDesignation=" + answerDesignation + ", unladenMass=" + unladenMass + ", equipmentMass=" + equipmentMass + ", vehicleMass="
                + vehicleMass + ", unladenSCX=" + unladenSCX + ", equipmentSCX=" + equipmentSCX + ", vehicleSCX=" + vehicleSCX + ", vehicleCRR="
                + vehicleCRR + ", vin=" + vin + ", ecomDate=" + ecomDate + ", extendedTitle=" + extendedTitle + ", calculatedValues="
                + calculatedValues + ", physicalQuantities=" + physicalQuantities + ", tvvDesignation=" + tvv + ", maturity=" + maturity + "]";
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    @MatchingEntityId
    @MatchingFactoryParameter(index = 0)
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Checks if is manual request.
     *
     * @return true, if is manual request
     */
    public boolean isManualRequest() {
        return manualRequest;
    }

    /**
     * Sets the manual request.
     *
     * @param manualRequest the new manual request
     */
    public void setManualRequest(boolean manualRequest) {
        this.manualRequest = manualRequest;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public LocalDate getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(LocalDate ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public RequestType getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the unladen mass.
     *
     * @return the unladen mass
     */
    public Double getUnladenMass() {
        return unladenMass;
    }

    /**
     * Sets the unladen mass.
     *
     * @param unladenMass the new unladen mass
     */
    public void setUnladenMass(Double unladenMass) {
        this.unladenMass = unladenMass;
    }

    /**
     * Gets the equipment mass.
     *
     * @return the equipment mass
     */
    public Double getEquipmentMass() {
        return equipmentMass;
    }

    /**
     * Sets the equipment mass.
     *
     * @param equipmentMass the new equipment mass
     */
    public void setEquipmentMass(Double equipmentMass) {
        this.equipmentMass = equipmentMass;
    }

    /**
     * Gets the vehicle mass.
     *
     * @return the vehicle mass
     */
    public Double getVehicleMass() {
        return vehicleMass;
    }

    /**
     * Sets the vehicle mass.
     *
     * @param vehicleMass the new vehicle mass
     */
    public void setVehicleMass(Double vehicleMass) {
        this.vehicleMass = vehicleMass;
    }

    /**
     * Gets the unladen scx.
     *
     * @return the unladen scx
     */
    public Double getUnladenSCX() {
        return unladenSCX;
    }

    /**
     * Sets the unladen scx.
     *
     * @param unladenSCX the new unladen scx
     */
    public void setUnladenSCX(Double unladenSCX) {
        this.unladenSCX = unladenSCX;
    }

    /**
     * Gets the equipment scx.
     *
     * @return the equipment scx
     */
    public Double getEquipmentSCX() {
        return equipmentSCX;
    }

    /**
     * Sets the equipment scx.
     *
     * @param equipmentSCX the new equipment scx
     */
    public void setEquipmentSCX(Double equipmentSCX) {
        this.equipmentSCX = equipmentSCX;
    }

    /**
     * Gets the vehicle scx.
     *
     * @return the vehicle scx
     */
    public Double getVehicleSCX() {
        return vehicleSCX;
    }

    /**
     * Sets the vehicle scx.
     *
     * @param vehicleSCX the new vehicle scx
     */
    public void setVehicleSCX(Double vehicleSCX) {
        this.vehicleSCX = vehicleSCX;
    }

    /**
     * Gets the vehicle crr.
     *
     * @return the vehicle crr
     */
    public Double getVehicleCRR() {
        return vehicleCRR;
    }

    /**
     * Sets the vehicle crr.
     *
     * @param vehicleCRR the new vehicle crr
     */
    public void setVehicleCRR(Double vehicleCRR) {
        this.vehicleCRR = vehicleCRR;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the calculated values.
     *
     * @return the calculated values
     */
    public CalculatedData getCalculatedValues() {
        return calculatedValues;
    }

    /**
     * Sets the calculated values.
     *
     * @param calculatedValues the new calculated values
     */
    public void setCalculatedValues(CalculatedData calculatedValues) {
        this.calculatedValues = calculatedValues;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Gets the provider request number.
     *
     * @return the provider request number
     */
    public String getProviderRequestNumber() {
        return providerRequestNumber;
    }

    /**
     * Sets the provider request number.
     *
     * @param providerRequestNumber the new provider request number
     */
    public void setProviderRequestNumber(String providerRequestNumber) {
        this.providerRequestNumber = providerRequestNumber;
    }

    /**
     * Gets the answer date.
     *
     * @return the answer date
     */
    public LocalDateTime getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the answer date.
     *
     * @param answerDate the new answer date
     */
    public void setAnswerDate(LocalDateTime answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<EnginePhysicalQuantity> getPhysicalQuantities() {
        return physicalQuantities;
    }

    /**
     * Sets the physical quantities.
     *
     * @param physicalQuantities the new physical quantities
     */
    public void setPhysicalQuantities(List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
    }

    /**
     * Gets the internal file id.
     *
     * @return the internal file id
     */
    public String getInternalFileId() {
        return internalFileId;
    }

    /**
     * Sets the internal file id.
     *
     * @param internalFileId the new internal file id
     */
    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    /**
     * Gets the maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Sets the maturity.
     *
     * @param maturity the new maturity
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

}
