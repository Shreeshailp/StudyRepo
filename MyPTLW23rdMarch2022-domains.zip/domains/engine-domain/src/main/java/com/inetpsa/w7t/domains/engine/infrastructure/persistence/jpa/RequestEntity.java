/*
 * Creation : 23 mars 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatusConverter;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;

/**
 * The Class RequestEntity.
 */
@Entity
@Table(name = "W7TQTREQ")
public class RequestEntity extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Id
    @Identity(handler = UUIDHandler.class)
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The request id. */
    @Column(name = "REQUEST_ID")
    private String requestId;

    /** The request batch id. */
    @Column(name = "BATCH_ID")
    @Type(type = "uuid-char")
    private UUID requestBatchId;

    /** The request type. */
    @Enumerated(EnumType.STRING)
    @Column(name = "REQUEST_TYPE")
    private RequestType requestType;

    /** The vin. */
    @Column(name = "VIN")
    private String vin;

    /** The ecom date. */
    @Column(name = "ECOM_Date")
    private LocalDate ecomDate;

    /** The extended title. */
    @Column(name = "EXTENDED_TITLE")
    private String extendedTitle;

    /** The file id. */
    @Column(name = "FILE_ID")
    private String fileId;

    /** The status. */
    @Convert(converter = RequestStatusConverter.class)
    @Column(name = "STATUS")
    private RequestStatus status;

    /** The requestDate. */
    @Column(name = "REQUEST_DATE")
    private LocalDateTime requestDate;

    /** The answerCode. */
    @Column(name = "ANSWER_CODE")
    private String answerCode;

    /** The answerDesignation. */
    @Column(name = "ANSWER_DESIGNATION")
    private String answerDesignation;

    /** The tvvDesignation. */
    @Column(name = "TVV_DESIGNATION")
    private String tvvDesignation;

    /** The calculated values. */
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CALC_DATA_ID", referencedColumnName = "ID")
    private CalculatedDataEntity calculatedValues;

    @Column(name = "INTERNAL_FILE_ID")
    private String internalFileId;

    @Column(name = "MATURITY")
    private String maturity;

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    public String getInternalFileId() {
        return internalFileId;
    }

    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    /**
     * Instantiates a new request entity.
     */
    public RequestEntity() {
        super();
    }

    /**
     * Instantiates a new request entity.
     *
     * @param guid the guid
     */
    public RequestEntity(UUID guid) {
        this.guid = guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the tvv designation.
     *
     * @return the tvv designation
     */
    public String getTvvDesignation() {
        return tvvDesignation;
    }

    /**
     * Sets the tvv designation.
     *
     * @param tvvDesignation the new tvv designation
     */
    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the request batch id.
     *
     * @return the request batch id
     */
    public UUID getRequestBatchId() {
        return requestBatchId;
    }

    /**
     * Sets the request batch id.
     *
     * @param requestBatchId the new request batch id
     */
    public void setRequestBatchId(UUID requestBatchId) {
        this.requestBatchId = requestBatchId;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public RequestType getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public LocalDate getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(LocalDate ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Getter calculatedValues.
     *
     * @return the calculatedValues
     */
    public CalculatedDataEntity getCalculatedValues() {
        return calculatedValues;
    }

    /**
     * Sets the calculated values.
     *
     * @param calculatedValues the new calculated values
     */
    public void setCalculatedValues(CalculatedDataEntity calculatedValues) {
        this.calculatedValues = calculatedValues;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "RequestEntity [guid=" + guid + ", fileId=" + fileId + ",  requestId=" + requestId + ",status=" + status + ", requestBatchId="
                + requestBatchId + ", requestType=" + requestType + ", vin=" + vin + ", ecomDate=" + ecomDate + ", extendedTitle=" + extendedTitle
                + ", tvvDesignation=" + tvvDesignation + ", requestDate=" + requestDate + ", calculatedValues=" + calculatedValues + "]";
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((answerCode == null) ? 0 : answerCode.hashCode());
        result = prime * result + ((answerDesignation == null) ? 0 : answerDesignation.hashCode());
        result = prime * result + ((calculatedValues == null) ? 0 : calculatedValues.hashCode());
        result = prime * result + ((ecomDate == null) ? 0 : ecomDate.hashCode());
        result = prime * result + ((extendedTitle == null) ? 0 : extendedTitle.hashCode());
        result = prime * result + ((fileId == null) ? 0 : fileId.hashCode());
        result = prime * result + ((requestBatchId == null) ? 0 : requestBatchId.hashCode());
        result = prime * result + ((requestDate == null) ? 0 : requestDate.hashCode());
        result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
        result = prime * result + ((requestType == null) ? 0 : requestType.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((vin == null) ? 0 : vin.hashCode());
        result = prime * result + ((tvvDesignation == null) ? 0 : tvvDesignation.hashCode());

        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        RequestEntity other = (RequestEntity) obj;
        if (answerCode == null) {
            if (other.answerCode != null)
                return false;
        } else if (!answerCode.equals(other.answerCode))
            return false;
        if (answerDesignation == null) {
            if (other.answerDesignation != null)
                return false;
        } else if (!answerDesignation.equals(other.answerDesignation))
            return false;
        if (calculatedValues == null) {
            if (other.calculatedValues != null)
                return false;
        } else if (!calculatedValues.equals(other.calculatedValues))
            return false;
        if (ecomDate == null) {
            if (other.ecomDate != null)
                return false;
        } else if (!ecomDate.equals(other.ecomDate))
            return false;
        if (extendedTitle == null) {
            if (other.extendedTitle != null)
                return false;
        } else if (!extendedTitle.equals(other.extendedTitle))
            return false;
        if (fileId == null) {
            if (other.fileId != null)
                return false;
        } else if (!fileId.equals(other.fileId))
            return false;
        if (requestBatchId == null) {
            if (other.requestBatchId != null)
                return false;
        } else if (!requestBatchId.equals(other.requestBatchId))
            return false;
        if (requestDate == null) {
            if (other.requestDate != null)
                return false;
        } else if (!requestDate.equals(other.requestDate))
            return false;
        if (requestId == null) {
            if (other.requestId != null)
                return false;
        } else if (!requestId.equals(other.requestId))
            return false;
        if (requestType != other.requestType)
            return false;
        if (status != other.status)
            return false;
        if (vin == null) {
            if (other.vin != null)
                return false;
        } else if (!vin.equals(other.vin))
            return false;
        return true;
    }

}
