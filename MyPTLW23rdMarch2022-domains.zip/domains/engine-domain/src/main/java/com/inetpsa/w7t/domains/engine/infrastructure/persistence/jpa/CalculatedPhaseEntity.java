/*
 * Creation : 28 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase.CalculatedMeasure;

/**
 * The class CalculatedPhaseEntity.
 */
@Entity
@Table(name = "W7TQTCLP")
public class CalculatedPhaseEntity {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The phaseCode. */
    @Column(name = "PHASE_CODE")
    private String phaseCode;

    /** The cycleGuid. */
    @Column(name = "CYCLE_ID")
    @Type(type = "uuid-char")
    private UUID cycleGuid;

    /** The cycleEnergy. */
    @Embedded
    @AttributeOverrides({ @AttributeOverride(name = "measureTypeCode", column = @Column(name = "CE_TYPE_CODE")),
            @AttributeOverride(name = "value", column = @Column(name = "CE_VALUE")) })
    private CalculatedMeasure cycleEnergy;

    /** The emissions. */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTCEM", joinColumns = @JoinColumn(name = "CALC_PHASE_ID", referencedColumnName = "ID"))
    private List<CalculatedMeasure> emissions;

    /**
     * The calculated data id. This field is only set in order to correctly set the DATA_ID column to keep the @OneToMany relationship in the
     * {@link CalculatedDataEntity}
     */
    @Column(name = "DATA_ID")
    @Type(type = "uuid-char")
    private UUID calculatedDataId;

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getPhaseCode() {
        return phaseCode;
    }

    public void setPhaseCode(String phaseCode) {
        this.phaseCode = phaseCode;
    }

    public UUID getCycleGuid() {
        return cycleGuid;
    }

    public void setCycleGuid(UUID cycleGuid) {
        this.cycleGuid = cycleGuid;
    }

    public CalculatedMeasure getCycleEnergy() {
        return cycleEnergy;
    }

    public void setCycleEnergy(CalculatedMeasure cycleEnergy) {
        this.cycleEnergy = cycleEnergy;
    }

    public List<CalculatedMeasure> getEmissions() {
        return emissions;
    }

    public void setEmissions(List<CalculatedMeasure> emissions) {
        this.emissions = emissions;
    }

    public UUID getCalculatedDataId() {
        return calculatedDataId;
    }

    public void setCalculatedDataId(UUID calculatedDataId) {
        this.calculatedDataId = calculatedDataId;
    }

}
