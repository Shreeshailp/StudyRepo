/*
 * Creation : 24 May 2019
 */
package com.inetpsa.w7t.domains.engine.utilities;

import org.slf4j.Logger;

/**
 * The Class LogErrorUtility.
 */
public class LogErrorUtility {

    /**
     * Log the error.
     *
     * @param logger the logger
     * @param requestId the request id
     * @param errorCode the error code
     * @param errorDesignation the error designation
     */
    public static void logTheError(Logger logger, String requestId, String errorCode, String errorDesignation) {
        logger.error("Request ID[{}]: [{}] : [{}]", requestId, errorCode, errorDesignation);
    }

    /**
     * Instantiates a new log error utility.
     */
    private LogErrorUtility() {

    }

    /**
     * Log the error.
     *
     * @param logger the logger
     * @param ruleCode the rule code
     * @param description the description
     */
    public static void logTheError(Logger logger, String ruleCode, String description) {

        logger.error("[{}] - [{}]", ruleCode, description);
    }
}
