/*
 * Creation : 28 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;

/**
 * The Class Version.
 */
public class Version {

    private static final String ERRW = "ERRW";

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(Version.class);

    /** The ecom date. */
    @NotNull(message = "The ecom date must not be null")
    private LocalDate ecomDate;

    /** The request type. */
    @NotNull(message = "The request type must not be null")
    private RequestType requestType;

    /** The extended title. */
    @Size(min = 1, max = 3524, message = "The extended title must be at most 3524 characters long and not be empty")
    private String extendedTitle;

    /** The trading country. */
    private String tradingCountry;

    /** The characteristic. */
    private String characteristic;

    /**
     * The tvvDesignation.
     */
    private String tvvDesignation;

    /** The conversion data. */
    private List<ConversionData> conversionData;

    /**
     * Instantiates a new version.
     *
     * @param ecomDate the ecom date
     * @param extendedTitle the extended title
     * @param requestType the request type
     * @param characteristic the characteristic
     */
    @Valid
    public Version(LocalDate ecomDate, String extendedTitle, RequestType requestType, String characteristic) {
        this.ecomDate = ecomDate;
        this.extendedTitle = extendedTitle;
        this.requestType = requestType;
        this.characteristic = characteristic;
        this.validate();
    }

    /**
     * Instantiates a new version.
     *
     * @param ecomDate the ecom date
     * @param extendedTitle the extended title
     * @param requestType the request type
     * @param characteristic the characteristic
     * @param tvvDesignation the tvv designation
     * @param conversionData the conversion data
     */
    @Valid
    public Version(LocalDate ecomDate, String extendedTitle, RequestType requestType, String characteristic, String tvvDesignation,
            List<ConversionData> conversionData) {
        this.ecomDate = ecomDate;
        this.extendedTitle = extendedTitle;
        this.requestType = requestType;
        this.characteristic = characteristic;
        this.tvvDesignation = tvvDesignation;
        this.conversionData = conversionData;
        this.validate();
    }

    /**
     * Gets the tvv designation.
     *
     * @return tvvDesignation
     */
    public String getTvvDesignation() {
        return tvvDesignation;
    }

    /**
     * Sets the tvv designation.
     *
     * @param tvvDesignation the new tvv designation
     */
    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the characteristic.
     *
     * @return the characteristic
     */
    public String getCharacteristic() {
        return characteristic;
    }

    /**
     * Sets the characteristic.
     *
     * @param characteristic the new characteristic
     */
    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public LocalDate getEcomDate() {
        return ecomDate;
    }

    /**
     * Getter requestType.
     *
     * @return the requestType
     */
    public RequestType getRequestType() {
        return requestType;
    }

    /**
     * Extended title.
     *
     * @return the optional
     */
    public Optional<String> extendedTitle() {
        return Optional.ofNullable(extendedTitle);
    }

    /**
     * Gets the conversion data.
     *
     * @return the conversion data
     */
    public List<ConversionData> getConversionData() {
        return conversionData;
    }

    /**
     * Sets the conversion data.
     *
     * @param conversionData the new conversion data
     */
    public void setConversionData(List<ConversionData> conversionData) {
        this.conversionData = conversionData;
    }

    /**
     * Gets the family.
     *
     * @param requestId the request id
     * @return the family
     */
    public String getFamily(String requestId) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8C(?<family>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("family");
        // logger.error("Request ID[{}]: The set extended title [{}] does not contain the WLTP family code", requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_FAMILY_CODE.getRuleCode(),
                WltpEngineCalculatorErrorCode.MISSING_FAMILY_CODE.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_FAMILY_CODE);
    }

    /**
     * Gets the index.
     *
     * @param requestId the request id
     * @return the index
     */
    public String getIndex(String requestId) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches()) {
            // Added the below block of code as part of the JIRA-679 - Starts Here
            String indexInString = m.group("index");
            if (!indexInString.matches("[0-9]{1,2}")) {
                LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.UNKNOWN_FAMILY_COUPLE.getRuleCode(),
                        WltpEngineCalculatorErrorCode.UNKNOWN_FAMILY_COUPLE.getDescription());
                throw SeedException.createNew(WltpEngineCalculatorErrorCode.UNKNOWN_FAMILY_COUPLE);
            }
            // Added the above block of code as part of the JIRA-679 - Ends Here
            return m.group("index");
        }

        // logger.error("Request ID[{}]: The set extended title [{}] does not contain the WLTP family index", requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_FAMILY_INDEX.getRuleCode(),
                WltpEngineCalculatorErrorCode.MISSING_FAMILY_INDEX.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_FAMILY_INDEX);
    }

    /**
     * Gets the vehicle family.
     *
     * @param requestId the request id
     * @return the vehicle family
     */
    public String getVehicleFamily(String requestId) {
        if (extendedTitle.length() < CalculationConstants.VEHICLE_FAMILY_LENGTH) {
            // logger.error("Request ID[{}]: The extended title [{}] is less than 4 characters long", requestId, extendedTitle);
            LogErrorUtility.logTheError(logger, requestId, RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                    RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            throw new IllegalStateException("Unable to get the vehicle family from a extended title that is less than 4 characters long");
        }
        return extendedTitle.substring(0, CalculationConstants.VEHICLE_FAMILY_LENGTH);
    }

    /**
     * Gets the program country.
     *
     * @param requestId the request id
     * @return the program country
     */
    public String getProgramCountry(String requestId) {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:GG8(?<country>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("country");
        else if (tradingCountry != null && !tradingCountry.isEmpty())
            return tradingCountry;
        // logger.error(
        // "Request ID[{}]: The set extended title [{}] does not contain a Program country neither does the request contain a Trading country",
        // requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.MISSING_COUNTRY.getRuleCode(),
                WltpEngineCalculatorErrorCode.MISSING_COUNTRY.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.MISSING_COUNTRY);
    }

    /**
     * Gets the gross vehicle mass.
     *
     * @param requestId the request id
     * @return the gross vehicle mass
     */
    public String getGrossVehicleMass(String requestId) {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:T3N(?<gvm>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("gvm");
        // logger.error("Request ID[{}]: The set extended title [{}] contains an unknown GVM value", requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_GVM_FOUND.getRuleCode(),
                WltpEngineCalculatorErrorCode.NO_GVM_FOUND.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_GVM_FOUND);
    }

    /**
     * Gets the full options mass and returns an empty string if not found.
     *
     * @param requestId the request id
     * @return the full options mass
     */
    public String getFullOptionsMass(String requestId) {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:T3S(?<full>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("full");
        // logger.error("Request ID[{}]: The set extended title [{}] contains an unknown Full Options Mass value", requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getRuleCode(),
                WltpEngineCalculatorErrorCode.NO_FOM_FOUND.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_FOM_FOUND);
    }

    /**
     * Gets the empty mass and returns an empty string if not found.
     *
     * @param requestId the request id
     * @return the empty mass
     */
    public String getEmptyMass(String requestId) {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:T3M(?<empty>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("empty");
        // logger.error("Request ID[{}]: The set extended title [{}] contains an unknown Empty Mass value", requestId, extendedTitle);
        LogErrorUtility.logTheError(logger, requestId, ERRW + WltpEngineCalculatorErrorCode.NO_EM_FOUND.getRuleCode(),
                WltpEngineCalculatorErrorCode.NO_EM_FOUND.getDescription());
        throw SeedException.createNew(WltpEngineCalculatorErrorCode.NO_EM_FOUND);
    }

    /**
     * Gets the tvvT1A.
     *
     * @return the tvvT1A
     */
    public String getTvvT1A() {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:T1A(?<t1a>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1a");
        return "";
    }

    /**
     * Gets the tvvT1B.
     *
     * @return the tvvT1B
     */
    public String getTvvT1B() {
        Matcher m = Pattern.compile(".{24}(?:.{7})*(?:T1B(?<t1b>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1b");
        return "";
    }

    /**
     * Validate.
     */
    private void validate() {
        Set<ConstraintViolation<Version>> violations = Validation.buildDefaultValidatorFactory().getValidator().validate(this);
        if (!violations.isEmpty())
            throw new ConstraintViolationException(violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList()).toString(),
                    violations);
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Version other = (Version) o;
        boolean equals = Objects.equals(ecomDate, other.ecomDate);
        equals = equals && Objects.equals(extendedTitle, other.extendedTitle);
        return equals;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hashCode(ecomDate);
        result = prime * result + Objects.hashCode(extendedTitle);
        return result;
    }
}
