/*
 * Creation : 11 août 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;

import com.google.inject.Injector;

/**
 * The Class CalculationFactoryDefault. Default implementation of {@link CalculationFactory}.
 */
public class CalculationFactoryDefault extends BaseFactory<Calculation> implements CalculationFactory {

    @Inject
    private Injector injector;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.engine.model.calculation.CalculationFactory#withVersion(com.inetpsa.w7t.domains.engine.model.calculation.Version)
     */
    @Override
    public Calculation withVersion(Version version) {
        Calculation calculation = new Calculation(version);
        injector.injectMembers(calculation);
        return calculation;
    }

}
