/*
 * Creation : 13 avr. 2017
 */
package com.inetpsa.w7t.domains.engine.services;

import java.util.List;
import java.util.UUID;

import org.javatuples.Pair;
import org.seedstack.business.Service;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.VehicleBoundary;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

/**
 * The Interface VehicleBoundaryService.
 */
@Service
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface VehicleBoundaryService {

    /**
     * Get the vehicle boundaries given a family, a cycle phase and a cycle energy value.
     *
     * @param familyId the family id
     * @param phaseId the phase id
     * @param cycleEnergy the cycle energy
     * @return the pair of vehicle boundaries
     */
    Pair<VehicleBoundary, VehicleBoundary> vehicleBoundaries(UUID familyId, UUID phaseId, double cycleEnergy);

    /**
     * Physical boundaries.
     *
     * @param family the family
     * @return the pair
     */
    Pair<List<EnginePhysicalQuantity>, List<EnginePhysicalQuantity>> physicalBoundaries(FamilyDetails family);
}
