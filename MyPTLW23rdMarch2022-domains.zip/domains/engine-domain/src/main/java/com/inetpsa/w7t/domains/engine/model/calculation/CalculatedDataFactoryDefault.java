/*
 * Creation : 29 mai 2017
 */
package com.inetpsa.w7t.domains.engine.model.calculation;

import java.util.Objects;
import java.util.UUID;

import org.seedstack.business.domain.BaseFactory;

public class CalculatedDataFactoryDefault extends BaseFactory<CalculatedData> implements CalculatedDataFactory {

    @Override
    public CalculatedData empty() {
        return new CalculatedData();
    }

    @Override
    public CalculatedData withTestMass(int testMass) {
        return new CalculatedData().setTestMass(testMass);
    }

    @Override
    public CalculatedPhase createCalculatedPhase(CalculatedData current, String phaseCode, UUID cycleGuid) {
        Objects.requireNonNull(current);
        return new CalculatedPhase(phaseCode, cycleGuid);
    }

}
