/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.domains.engine.model.request;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.StepEntity;

/**
 * The Class Step.
 */
@DtoOf(StepEntity.class)
public class Step {

    /** The request id. */
    @NotNull
    private UUID requestId;

    /** The new status. */
    @NotNull
    private RequestStatus newStatus;

    /** The old status. */
    private RequestStatus oldStatus;

    /** The time. */
    @NotNull
    private LocalDateTime time; // NOSONAR if this field is set to transient, this value-object don't have anymore sense

    /**
     * Instantiates a new step.
     *
     * @param requestId the request id
     * @param newStatus the new status
     * @param oldStatus the old status
     */
    public Step(UUID requestId, RequestStatus newStatus, RequestStatus oldStatus) {
        super();
        this.requestId = requestId;
        this.newStatus = newStatus;
        this.oldStatus = oldStatus;
        this.time = LocalDateTime.now();
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public UUID getRequestId() {
        return requestId;
    }

    /**
     * Gets the new status.
     *
     * @return the new status
     */
    public RequestStatus getNewStatus() {
        return newStatus;
    }

    /**
     * Gets the old status.
     *
     * @return the old status
     */
    public RequestStatus getOldStatus() {
        return oldStatus;
    }

    /**
     * Gets the time.
     *
     * @return the time
     */
    public LocalDateTime getTime() {
        return time;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Step other = (Step) o;
        return Objects.equals(requestId, other.requestId) && Objects.equals(newStatus, other.newStatus) && Objects.equals(oldStatus, other.oldStatus)
                && Objects.equals(time, other.time);
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + Objects.hashCode(requestId);
        result = prime * result + Objects.hashCode(newStatus);
        result = prime * result + Objects.hashCode(oldStatus);
        result = prime * result + Objects.hashCode(time);
        return result;
    }
}
