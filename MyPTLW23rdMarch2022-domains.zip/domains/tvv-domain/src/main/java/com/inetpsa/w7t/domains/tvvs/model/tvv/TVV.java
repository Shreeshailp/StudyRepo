/*
 * Creation : 16 May 2018
 */
package com.inetpsa.w7t.domains.tvvs.model.tvv;

import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class TVV. This represents the summary of a WLTP TVV.
 */

@Entity
@Table(name = "W7TQTTVV")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class TVV extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Size(max = 4)
    @Column(name = "VEHICLE_FAMILY")
    private String vehicleFamily;

    @Size(max = 2)
    @Column(name = "T1A_VALUE")
    private String t1AValue;

    @Size(max = 2)
    @Column(name = "T1B_VALUE")
    private String t1BValue;

    @Column(name = "TVV_DESIGNATION")
    private String tvvDesignation;

    @Column(name = "TVV_HEIGHT")
    private Float tvvHeigth;

    @Column(name = "TVV_WIDTH")
    private Float tvvWidth;

    @Column(name = "TVV_AF")
    private Float tvvAf;

    @Column(name = "TVV_MAX_SPEED")
    private Integer tvvMaxspeed;

    @Column(name = "TVV_SCX_BASE")
    private Float tvvScxBase;

    @Column(name = "TVV_VEHICLE_CATEGORY")
    private String tvvVehicleCategory;

    @Column(name = "TVV_COMPLETE_FLAG")
    private String tvvCompleteFlag;

    @Column(name = "TVV_CODE_DEPOL")
    private String tvvCodeDepol;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getVehicleFamily() {
        return vehicleFamily;
    }

    public void setVehicleFamily(String vehicleFamily) {
        this.vehicleFamily = vehicleFamily;
    }

    public String getT1AValue() {
        return t1AValue;
    }

    public void setT1AValue(String t1aValue) {
        t1AValue = t1aValue;
    }

    public String getT1BValue() {
        return t1BValue;
    }

    public void setT1BValue(String t1bValue) {
        t1BValue = t1bValue;
    }

    public String getTvvDesignation() {
        return tvvDesignation;
    }

    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    public Float getTvvHeigth() {
        return tvvHeigth;
    }

    public void setTvvHeigth(Float tvvHeigth) {
        this.tvvHeigth = tvvHeigth;
    }

    public Float getTvvWidth() {
        return tvvWidth;
    }

    public void setTvvWidth(Float tvvWidth) {
        this.tvvWidth = tvvWidth;
    }

    public Float getTvvAf() {
        return tvvAf;
    }

    public void setTvvAf(Float tvvAf) {
        this.tvvAf = tvvAf;
    }

    public Integer getTvvMaxspeed() {
        return tvvMaxspeed;
    }

    public void setTvvMaxspeed(Integer tvvMaxspeed) {
        this.tvvMaxspeed = tvvMaxspeed;
    }

    public Float getTvvScxBase() {
        return tvvScxBase;
    }

    public void setTvvScxBase(Float tvvScxBase) {
        this.tvvScxBase = tvvScxBase;
    }

    public String getTvvVehicleCategory() {
        return tvvVehicleCategory;
    }

    public void setTvvVehicleCategory(String tvvVehicleCategory) {
        this.tvvVehicleCategory = tvvVehicleCategory;
    }

    public String getTvvCompleteFlag() {
        return tvvCompleteFlag;
    }

    public void setTvvCompleteFlag(String tvvCompleteFlag) {
        this.tvvCompleteFlag = tvvCompleteFlag;
    }

    public String getTvvCodeDepol() {
        return tvvCodeDepol;
    }

    public void setTvvCodeDepol(String tvvCodeDepol) {
        this.tvvCodeDepol = tvvCodeDepol;
    }

    @Override
    public String toString() {
        return "TVV [guid=" + guid + ", vehicleFamily=" + vehicleFamily + ", t1AValue=" + t1AValue + ", t1BValue=" + t1BValue + ", tvvDesignation="
                + tvvDesignation + ", tvvHeigth=" + tvvHeigth + ", tvvWidth=" + tvvWidth + ", tvvAf=" + tvvAf + ", tvvMaxspeed=" + tvvMaxspeed
                + ", tvvScxBase=" + tvvScxBase + ", tvvVehicleCategory=" + tvvVehicleCategory + ", tvvCompleteFlag=" + tvvCompleteFlag
                + ", tvvCodeDepol=" + tvvCodeDepol + "]";
    }

}
