/*
 * Creation : 6 Jan 2022
 */
package com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.depol.model.DepolStatusReport;

/**
 * The Interface DepolStatusReportRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface DepolStatusReportRepository extends GenericRepository<DepolStatusReport, UUID> {

    /**
     * Gets the depol status report by file name.
     *
     * @param fileName the file name
     * @return the depol status report by file name
     */
    public List<DepolStatusReport> getDepolStatusReportByFileName(String fileName);

}
