/*
 * Creation : 29 May 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;

import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

/**
 * Description.
 *
 * @author E539454
 */
public interface TVVRepository extends GenericRepository<TVV, UUID> {

    /**
     * Exists.
     *
     * @param vFamily the v family
     * @param t1a the t 1 a
     * @param t1b the t 1 b
     * @return true, if successful
     */
    public boolean exists(String vFamily, String t1a, String t1b);

    /**
     * Tvv by unique fields.
     *
     * @param vehiclefamily the vehiclefamily
     * @param t1a_value the t 1 a value
     * @param t1b_value the t 1 b value
     * @return the list
     */
    public List<TVV> tvvByUniqueFields(String vehiclefamily, String t1a_value, String t1b_value);

    /**
     * Tvv by unique fields.
     *
     * @param vehiclefamily the vehiclefamily
     * @param tvvdesignation the tvvdesignation
     * @return the list
     */
    public List<TVV> tvvByUniqueFields(String vehiclefamily, String tvvdesignation);

    /**
     * Exists above bottom value.
     *
     * @param tvvMaxspeed the tvv maxspeed
     * @return true, if successful
     */
    public boolean existsAboveBottomValue(Integer tvvMaxspeed);

    /**
     * Tvv by family tvv desig T 1 AT 1 B.
     *
     * @param vFamily the v family
     * @param tvvDesignation the tvv designation
     * @param t1a the t 1 a
     * @param t1b the t 1 b
     * @return the list
     */
    // jira-744 fix
    List<TVV> tvvByFamilyTvvDesigT1AT1B(String vFamily, String tvvDesignation, String t1a, String t1b);
}
