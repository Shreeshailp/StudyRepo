/*
 * Creation : 30 May 2018
 */
package com.inetpsa.w7t.domains.tvv.exceptions;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum TVVErrorCode.
 */
public enum TVVErrorCode implements ErrorCode {

    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(100, "At least one line of the file is not recognized, the import has not been performed", "RG37"),

    /** TVV entry present in sheet */
    TVV_ENTRY_PRESENT_IN_SHEET(101, "At least one duplicate list (Vehicle Family {0}, T1A {1}, T1B {2}, TVV {3}), the import was not made", "RG38"),

    /** The TVV index already exists. */
    /* TVV_ALREADY_EXISTS(103, "creation of an existing TVV (Vehicle Family {0}, T1A {1}, T1B {2}, TVV {3}), the import was not made", "RG39"), */
    TVV_ALREADY_EXISTS(103, "{0} ", "RG39"),
    /** First line should start with C or M or D char. */
    FIRST_LINE_STARTS_C_M_D_CHECK(110, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG40"),

    UNKNOWN_EXCEPTION(109, "Unknown Technical Exception", "RGXX"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    TVV_UNKNOWN_EXCEPTION(112, "At least one piece of data is not correct, the import has not been made", "RGXX"),
    TVV_UNKNOWN_ERROR(120, "{0}, the import has not been made. Stop treatment", "RG40"),
    TVV_INVALID_COMPLETE_FLAG(113, "line {0} : incorrect complete flag", "RG38"), TVV_INVALID_CATEGORY(114, "line {0} : category incorrect", "RG38"),
    TVV_MAX_SPEED_ERROR(115, "vehicle family {0}, T1A {1}, T1B {2}, TVV {3}): max_speed too low, the import was not made", "RG38"),
    TVV_HEADER_COLUMN_MISSING(116, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG40"),
    TVV_INVALID_CODE_DEPOL(117, "line {0} : incorrect Depol Code", "RG38"),
    TVV_DESIGNATION_EXCEEDED_LENGTH(118, "line {0}: one of the data is not at the expected format, the import can not be done", "RG38");
    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new family error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    TVVErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
