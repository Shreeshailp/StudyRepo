/*
 * Creation : 19 Jul 2018
 */
package com.inetpsa.w7t.domains.tvvs.model.tvv;

public class TvvDto {

    private String action;

    private String vehicleFamily;

    private String t1AValue;

    private String t1BValue;

    private String tvvDesignation;

    private Float tvvHeigth;

    private Float tvvWidth;

    private Float tvvAf;

    private Integer tvvMaxspeed;

    private Float tvvScxBase;

    private String tvvVehicleCategory;

    private String tvvCompleteFlag;

    private String tvvCodeDepol;

    private int lineNumber;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getVehicleFamily() {
        return vehicleFamily;
    }

    public void setVehicleFamily(String vehicleFamily) {
        this.vehicleFamily = vehicleFamily;
    }

    public String getT1AValue() {
        return t1AValue;
    }

    public void setT1AValue(String t1aValue) {
        t1AValue = t1aValue;
    }

    public String getT1BValue() {
        return t1BValue;
    }

    public void setT1BValue(String t1bValue) {
        t1BValue = t1bValue;
    }

    public String getTvvDesignation() {
        return tvvDesignation;
    }

    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    public Float getTvvHeigth() {
        return tvvHeigth;
    }

    public void setTvvHeigth(Float tvvHeigth) {
        this.tvvHeigth = tvvHeigth;
    }

    public Float getTvvWidth() {
        return tvvWidth;
    }

    public void setTvvWidth(Float tvvWidth) {
        this.tvvWidth = tvvWidth;
    }

    public Float getTvvAf() {
        return tvvAf;
    }

    public void setTvvAf(Float tvvAf) {
        this.tvvAf = tvvAf;
    }

    public Integer getTvvMaxspeed() {
        return tvvMaxspeed;
    }

    public void setTvvMaxspeed(Integer tvvMaxspeed) {
        this.tvvMaxspeed = tvvMaxspeed;
    }

    public Float getTvvScxBase() {
        return tvvScxBase;
    }

    public void setTvvScxBase(Float tvvScxBase) {
        this.tvvScxBase = tvvScxBase;
    }

    public String getTvvVehicleCategory() {
        return tvvVehicleCategory;
    }

    public void setTvvVehicleCategory(String tvvVehicleCategory) {
        this.tvvVehicleCategory = tvvVehicleCategory;
    }

    public String getTvvCompleteFlag() {
        return tvvCompleteFlag;
    }

    public void setTvvCompleteFlag(String tvvCompleteFlag) {
        this.tvvCompleteFlag = tvvCompleteFlag;
    }

    public String getTvvCodeDepol() {
        return tvvCodeDepol;
    }

    public void setTvvCodeDepol(String tvvCodeDepol) {
        this.tvvCodeDepol = tvvCodeDepol;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(int lineNumber) {
        this.lineNumber = lineNumber;
    }

}
