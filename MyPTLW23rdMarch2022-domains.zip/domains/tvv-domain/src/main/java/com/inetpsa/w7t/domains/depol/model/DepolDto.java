/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.domains.depol.model;

/**
 * The Class DepolDto.
 */
public class DepolDto {

    /** The code depol. */
    private String codeDepol;

    /** The special flag. */
    private String specialFlag;

    /** The designation. */
    private String designation;

    /** The mro min. */
    private Integer mroMin;

    /** The mro max. */
    private Integer mroMax;

    /** The frontal area min. */
    private Float frontalAreaMin;

    /** The frontal area max. */
    private Float frontalAreaMax;

    /** The cooling surface min. */
    private Float coolingSurfaceMin;

    /** The cooling surface max. */
    private Float coolingSurfaceMax;

    /** The crr min. */
    private Float crrMin;

    /** The crr max. */
    private Float crrMax;

    /** The cx min. */
    private Float cxMin;

    /** The cx max. */
    private Float cxMax;

    /** The status. */
    private String status;

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the code depol.
     *
     * @return the code depol
     */
    public String getCodeDepol() {
        return codeDepol;
    }

    /**
     * Sets the code depol.
     *
     * @param codeDepol the new code depol
     */
    public void setCodeDepol(String codeDepol) {
        this.codeDepol = codeDepol;
    }

    /**
     * Gets the special flag.
     *
     * @return the special flag
     */
    public String getSpecialFlag() {
        return specialFlag;
    }

    /**
     * Sets the special flag.
     *
     * @param specialFlag the new special flag
     */
    public void setSpecialFlag(String specialFlag) {
        this.specialFlag = specialFlag;
    }

    /**
     * Gets the designation.
     *
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Sets the designation.
     *
     * @param designation the new designation
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * Gets the mro min.
     *
     * @return the mro min
     */
    public Integer getMroMin() {
        return mroMin;
    }

    /**
     * Sets the mro min.
     *
     * @param mroMin the new mro min
     */
    public void setMroMin(Integer mroMin) {
        this.mroMin = mroMin;
    }

    /**
     * Gets the mro max.
     *
     * @return the mro max
     */
    public Integer getMroMax() {
        return mroMax;
    }

    /**
     * Sets the mro max.
     *
     * @param mroMax the new mro max
     */
    public void setMroMax(Integer mroMax) {
        this.mroMax = mroMax;
    }

    /**
     * Gets the frontal area min.
     *
     * @return the frontal area min
     */
    public Float getFrontalAreaMin() {
        return frontalAreaMin;
    }

    /**
     * Sets the frontal area min.
     *
     * @param frontalAreaMin the new frontal area min
     */
    public void setFrontalAreaMin(Float frontalAreaMin) {
        this.frontalAreaMin = frontalAreaMin;
    }

    /**
     * Gets the frontal area max.
     *
     * @return the frontal area max
     */
    public Float getFrontalAreaMax() {
        return frontalAreaMax;
    }

    /**
     * Sets the frontal area max.
     *
     * @param frontalAreaMax the new frontal area max
     */
    public void setFrontalAreaMax(Float frontalAreaMax) {
        this.frontalAreaMax = frontalAreaMax;
    }

    /**
     * Gets the cooling surface min.
     *
     * @return the cooling surface min
     */
    public Float getCoolingSurfaceMin() {
        return coolingSurfaceMin;
    }

    /**
     * Sets the cooling surface min.
     *
     * @param coolingSurfaceMin the new cooling surface min
     */
    public void setCoolingSurfaceMin(Float coolingSurfaceMin) {
        this.coolingSurfaceMin = coolingSurfaceMin;
    }

    /**
     * Gets the cooling surface max.
     *
     * @return the cooling surface max
     */
    public Float getCoolingSurfaceMax() {
        return coolingSurfaceMax;
    }

    /**
     * Sets the cooling surface max.
     *
     * @param coolingSurfaceMax the new cooling surface max
     */
    public void setCoolingSurfaceMax(Float coolingSurfaceMax) {
        this.coolingSurfaceMax = coolingSurfaceMax;
    }

    /**
     * Gets the crr min.
     *
     * @return the crr min
     */
    public Float getCrrMin() {
        return crrMin;
    }

    /**
     * Sets the crr min.
     *
     * @param crrMin the new crr min
     */
    public void setCrrMin(Float crrMin) {
        this.crrMin = crrMin;
    }

    /**
     * Gets the crr max.
     *
     * @return the crr max
     */
    public Float getCrrMax() {
        return crrMax;
    }

    /**
     * Sets the crr max.
     *
     * @param crrMax the new crr max
     */
    public void setCrrMax(Float crrMax) {
        this.crrMax = crrMax;
    }

    /**
     * Gets the cx min.
     *
     * @return the cx min
     */
    public Float getCxMin() {
        return cxMin;
    }

    /**
     * Sets the cx min.
     *
     * @param cxMin the new cx min
     */
    public void setCxMin(Float cxMin) {
        this.cxMin = cxMin;
    }

    /**
     * Gets the cx max.
     *
     * @return the cx max
     */
    public Float getCxMax() {
        return cxMax;
    }

    /**
     * Sets the cx max.
     *
     * @param cxMax the new cx max
     */
    public void setCxMax(Float cxMax) {
        this.cxMax = cxMax;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DepolDto [codeDepol=" + codeDepol + ", specialFlag=" + specialFlag + ", designation=" + designation + ", mroMin=" + mroMin
                + ", mroMax=" + mroMax + ", frontalAreaMin=" + frontalAreaMin + ", frontalAreaMax=" + frontalAreaMax + ", coolingSurfaceMin="
                + coolingSurfaceMin + ", coolingSurfaceMax=" + coolingSurfaceMax + ", crrMin=" + crrMin + ", crrMax=" + crrMax + ", cxMin=" + cxMin
                + ", cxMax=" + cxMax + ", status=" + status + "]";
    }

}
