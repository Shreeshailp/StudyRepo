/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.depol.model.Depol;

/**
 * The Class DepolJpaRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class DepolJpaRepository extends BaseJpaRepository<Depol, UUID> implements DepolRepository {

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CODE_DEPOL. */
    private static final String CODE_DEPOL = "codeDepol";

    /** The Constant SPECIAL_FLAG. */
    private static final String SPECIAL_FLAG = "specialFlag";

    /** The Constant CRR_MIN. */
    private static final String CRR_MIN = "crrMin";

    /** The Constant CRR_MAX. */
    private static final String CRR_MAX = "crrMax";

    /** The Constant CX_MIN. */
    private static final String CX_MIN = "cxMin";

    /** The Constant CX_MAX. */
    private static final String CX_MAX = "cxMax";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#exists(java.lang.String, java.lang.String,
     *      java.lang.Float, java.lang.Float)
     */
    @Override
    public boolean exists(String codeDepol, String specialFlag, Float crrMin, Float crrMax) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<Depol> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE_DEPOL), cb.parameter(String.class, CODE_DEPOL)),
                cb.equal(root.get(SPECIAL_FLAG), cb.parameter(String.class, SPECIAL_FLAG)),
                cb.equal(cb.trim(root.get(CRR_MIN)), cb.parameter(String.class, CRR_MIN)),
                cb.equal(cb.trim(root.get(CRR_MAX)), cb.parameter(String.class, CRR_MAX)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE_DEPOL, codeDepol);
        query.setParameter(SPECIAL_FLAG, specialFlag);

        String crrMin1 = crrMin.toString();
        if (crrMin1.endsWith(".0")) {
            crrMin1 = crrMin1.replace(".0", "");
            query.setParameter(CRR_MIN, crrMin1);
        } else {
            query.setParameter(CRR_MIN, crrMin.toString());
        }

        String crrMax1 = crrMax.toString();
        if (crrMax1.endsWith(".0")) {
            crrMax1 = crrMax1.replace(".0", "");
            query.setParameter(CRR_MAX, crrMax1);
        } else {
            query.setParameter(CRR_MAX, crrMax.toString());
        }
        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#depolByUniqueFields(java.lang.String,
     *      java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Depol> depolByUniqueFields(String codeDepol, String specialFlag) {
        Query query = entityManager.createNativeQuery(
                "select ID,CODE_DEPOL,CODE_SPECIAL,LABEL_DEPOL,MROTR_MIN,MROTR_MAX,STR_MIN,STR_MAX,COOLSTR_MIN,COOLSTR_MAX,trim(RCRRTR_MIN) AS RCRRTR_MIN,trim(RCRRTR_MAX) AS RCRRTR_MAX,trim(CX_MIN) AS CX_MIN,trim(CX_MAX) AS CX_MAX from W7TQTDEP where CODE_DEPOL=? AND CODE_SPECIAL=?",
                Depol.class);
        query.setParameter(1, codeDepol);
        query.setParameter(2, specialFlag);

        List<Depol> depolList = null;
        depolList = query.getResultList();
        if (!depolList.isEmpty())
            return depolList;
        return depolList;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#depolByUniqueFields(java.lang.String,
     *      java.lang.String, java.lang.Float, java.lang.Float, java.lang.Float, java.lang.Float)
     */
    @Override
    public Optional<Depol> depolByUniqueFields(String codeDepol, String specialFlag, Float crrMin, Float crrMax, Float cxMin, Float cxMax) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Depol> q = cb.createQuery(Depol.class);
        Root<Depol> root = q.from(Depol.class);
        q.where(cb.equal(root.get(CODE_DEPOL), cb.parameter(String.class, CODE_DEPOL)),
                cb.equal(root.get(SPECIAL_FLAG), cb.parameter(String.class, SPECIAL_FLAG)),
                cb.equal(cb.trim(root.get(CRR_MIN)), cb.parameter(String.class, CRR_MIN)),
                cb.equal(cb.trim(root.get(CRR_MAX)), cb.parameter(String.class, CRR_MAX)),
                cb.equal(cb.trim(root.get(CX_MIN)), cb.parameter(String.class, CX_MIN)),
                cb.equal(cb.trim(root.get(CX_MAX)), cb.parameter(String.class, CX_MAX)));

        TypedQuery<Depol> query = entityManager.createQuery(q);
        query.setParameter(CODE_DEPOL, codeDepol);
        query.setParameter(SPECIAL_FLAG, specialFlag);
        String crrMin1 = crrMin.toString();
        if (crrMin1.endsWith(".0")) {
            crrMin1 = crrMin1.replace(".0", "");
            query.setParameter(CRR_MIN, crrMin1);
        } else {
            query.setParameter(CRR_MIN, crrMin.toString());
        }

        String crrMax1 = crrMax.toString();
        if (crrMax1.endsWith(".0")) {
            crrMax1 = crrMax1.replace(".0", "");
            query.setParameter(CRR_MAX, crrMax1);
        } else {
            query.setParameter(CRR_MAX, crrMax.toString());
        }

        String cxMin1 = cxMin.toString();
        if (cxMin1.endsWith(".0")) {
            cxMin1 = cxMin1.replace(".0", "");
            query.setParameter(CX_MIN, cxMin1);
        } else {
            query.setParameter(CX_MIN, cxMin.toString());
        }

        String cxMax1 = cxMax.toString();
        if (cxMax1.endsWith(".0")) {
            cxMax1 = cxMax1.replace(".0", "");
            query.setParameter(CX_MAX, cxMax1);
        } else {
            query.setParameter(CX_MAX, cxMax.toString());
        }

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#getAllDepolsByUniqueFields(java.lang.String,
     *      java.lang.String, java.lang.Float, java.lang.Float)
     */
    @Override
    public List<Depol> getAllDepolsByUniqueFields(String codeDepol, String specialFlag, Float crrMin, Float crrMax) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Depol> q = cb.createQuery(Depol.class);
        Root<Depol> root = q.from(Depol.class);
        q.where(cb.equal(root.get(CODE_DEPOL), cb.parameter(String.class, CODE_DEPOL)),
                cb.equal(root.get(SPECIAL_FLAG), cb.parameter(String.class, SPECIAL_FLAG)),
                cb.equal(cb.trim(root.get(CRR_MIN)), cb.parameter(String.class, CRR_MIN)),
                cb.equal(cb.trim(root.get(CRR_MAX)), cb.parameter(String.class, CRR_MAX)));

        TypedQuery<Depol> query = entityManager.createQuery(q);
        query.setParameter(CODE_DEPOL, codeDepol);
        query.setParameter(SPECIAL_FLAG, specialFlag);
        String crrMin1 = crrMin.toString();
        if (crrMin1.endsWith(".0")) {
            crrMin1 = crrMin1.replace(".0", "");
            query.setParameter(CRR_MIN, crrMin1);
        } else {
            query.setParameter(CRR_MIN, crrMin.toString());
        }

        String crrMax1 = crrMax.toString();
        if (crrMax1.endsWith(".0")) {
            crrMax1 = crrMax1.replace(".0", "");
            query.setParameter(CRR_MAX, crrMax1);
        } else {
            query.setParameter(CRR_MAX, crrMax.toString());
        }

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String codeDepol) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<Depol> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE_DEPOL), cb.parameter(String.class, CODE_DEPOL)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE_DEPOL, codeDepol);

        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#depolByQuadrupleFields(java.lang.String,
     *      java.lang.String, java.lang.Double)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Depol> depolByQuadrupleFields(String codeDepol, String specialFlag, Double rcrr) {
        Query query = entityManager.createNativeQuery(
                "select * from W7TQTDEP where CODE_DEPOL=? AND CODE_SPECIAL=? AND trim(RCRRTR_MIN) <=? AND trim(RCRRTR_MAX) >=?", Depol.class);
        query.setParameter(1, codeDepol);
        query.setParameter(2, specialFlag);
        query.setParameter(3, rcrr);
        query.setParameter(4, rcrr);
        List<Depol> depolList = null;
        depolList = query.getResultList();
        if (!depolList.isEmpty())
            return depolList;
        return depolList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#depolByTripletFields(java.lang.String,
     *      java.lang.String, java.lang.Double)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<Depol> depolByTripletFields(String codeDepol, String specialFlag, Double cxtr) {
        Query query = entityManager.createNativeQuery(
                "select * from W7TQTDEP where CODE_DEPOL=? AND CODE_SPECIAL=? AND (trim(CX_MIN) =? OR trim(CX_MAX) =?)", Depol.class);
        query.setParameter(1, codeDepol);
        query.setParameter(2, specialFlag);
        query.setParameter(3, cxtr);
        query.setParameter(4, cxtr);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository#depolByKey(java.lang.String, java.lang.String,
     *      java.lang.Double, java.lang.Double)
     */
    // fixed jira-772
    @SuppressWarnings("unchecked")
    @Override
    public List<Depol> depolByKey(String codeDepol, String specialFlag, Double rcrr, Double cxtr) {
        Query query = entityManager.createNativeQuery(
                "select * from W7TQTDEP where CODE_DEPOL=? AND CODE_SPECIAL=? AND trim(RCRRTR_MIN) <=? AND trim(RCRRTR_MAX) >=? AND (trim(CX_MIN) <=? AND trim(CX_MAX) >=?)",
                Depol.class);
        query.setParameter(1, codeDepol);
        query.setParameter(2, specialFlag);
        query.setParameter(3, rcrr);
        query.setParameter(4, rcrr);
        query.setParameter(5, cxtr);
        query.setParameter(6, cxtr);

        return query.getResultList();
    }

}
