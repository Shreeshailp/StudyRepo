/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.domains.depol.exceptions;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum DepolErrorCode.
 */
public enum DepolErrorCode implements ErrorCode {

    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(100, "At least one line of the file is not recognized, the import was not made", "RG61"),

    /** The first line starts c m check. */
    FIRST_LINE_STARTS_C_M_CHECK(110, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG62"),

    /** The depol entry present in sheet. */
    DEPOL_ENTRY_PRESENT_IN_SHEET(101,
            "At least one duplicate list (CODE_DEPOL {0}, flag_special {1}, CRR_MIN{2}, CRR_MAX{3}, CX_MIN{4}, CX_MAX{5}), the import was not made",
            "RG63"),

    /** The not enough data. */
    NOT_ENOUGH_DATA(114, "the file has no depol lines, the import has not been made. Stop treatment.", "RG64"),

    /** The unknown exception. */
    UNKNOWN_EXCEPTION(109, "Unknown Technical Exception", "RGXX"),

    /** The depol header column missing. */
    DEPOL_HEADER_COLUMN_MISSING(110, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG65"),

    /** The depol already exists. */
    DEPOL_ALREADY_EXISTS(111, "{0}", "RG66"),

    /** The depol deletion records. */
    DEPOL_DELETION_RECORDS(135, "{0} deletion ", "RG90"),

    /** The invalid special flag. */
    INVALID_SPECIAL_FLAG(112, "Incorrect special flag", "RG67"),

    /** The depol unknown exception. */
    DEPOL_UNKNOWN_EXCEPTION(113, "At least one piece of data is not correct, the import has not been made", "RG68"),

    /** The depol unknown error. */
    DEPOL_UNKNOWN_ERROR(114, "{0}, the import has not been made. Stop treatment", "RG69"),

    /** The invalid designaton. */
    INVALID_DESIGNATON(115, "Invalid Designation", "RG70"),

    /** The blank designaton. */
    BLANK_DESIGNATON(116, "Blank Designation", "RG71"),

    /** The invalid depol code. */
    INVALID_DEPOL_CODE(117, "Invalid Depol Code", "RG72"),

    /** The blank depol code. */
    BLANK_DEPOL_CODE(118, "Blank Depol Code", "RG73"),

    /** The blank special flag. */
    BLANK_SPECIAL_FLAG(119, "Blank Special Flag", "RG74"),

    /** The blank crr min. */
    BLANK_CRR_MIN(120, "Blank or Zero CRR Min", "RG75"),

    /** The blank crr max. */
    BLANK_CRR_MAX(121, "Blank or Zero CRR Max", "RG76"),

    /** The blank mro max. */
    BLANK_MRO_MAX(122, "Blank or Zero MRO Max", "RG77"),

    /** The blank mro min. */
    BLANK_MRO_MIN(123, "Blank or Zero MRO Min", "RG78"),

    /** The blank frontal area min. */
    BLANK_FRONTAL_AREA_MIN(124, "Blank or Zero Frontal Area Min", "RG79"),

    /** The blank frontal area max. */
    BLANK_FRONTAL_AREA_MAX(125, "Blank or Zero Frontal Area Max", "RG80"),

    /** The blank cooling surface min. */
    BLANK_COOLING_SURFACE_MIN(126, "Blank or Zero Cooling Surface Min", "RG81"),

    /** The indus maintainance error. */
    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    /** The blank cooling surface max. */
    BLANK_COOLING_SURFACE_MAX(124, "Blank or Zero Cooling Surface Max", "RG82"),

    /** The blank cx min. */
    BLANK_CX_MIN(127, "CX_MIN est vide", "RG83"),

    /** The blank cx max. */
    BLANK_CX_MAX(128, "CX_MAX est vide", "RG84"),

    /** The cx min cx max present. */
    CX_MIN_CX_MAX_PRESENT(129, "avec borne et sans borne", "RG85"),

    /** The cx min cx max equal. */
    CX_MIN_CX_MAX_EQUAL(130, "CX MIN = CX MAX", "RG86"),

    /** The cx min cx max present in another line. */
    CX_MIN_CX_MAX_PRESENT_IN_ANOTHER_LINE(131, "chevauchement de borne", "RG87"),

    /** The no import data available error. */
    NO_IMPORT_DATA_AVAILABLE_ERROR(132, "No data found", "RG88"),

    /** The depol import file functional error. */
    DEPOL_IMPORT_FILE_FUNCTIONAL_ERROR(133, "The import has not been made, as least one functional error is present in the Excel file", "RG89");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new family error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    DepolErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
