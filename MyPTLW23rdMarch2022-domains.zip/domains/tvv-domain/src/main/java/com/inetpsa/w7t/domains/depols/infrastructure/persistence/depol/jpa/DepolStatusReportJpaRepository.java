/*
 * Creation : 6 Jan 2022
 */
package com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.depol.model.DepolStatusReport;

/**
 * The Class DepolStatusReportJpaRepository.
 */
public class DepolStatusReportJpaRepository extends BaseJpaRepository<DepolStatusReport, UUID> implements DepolStatusReportRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolStatusReportRepository#getDepolStatusReportByFileName(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<DepolStatusReport> getDepolStatusReportByFileName(String fileName) {
        Query query = entityManager.createNativeQuery("select * from W7TQTDSR where FILE_NAME=?", DepolStatusReport.class);
        query.setParameter(1, fileName);
        return query.getResultList();
    }

}
