/*
 * Creation : 6 Jan 2022
 */
package com.inetpsa.w7t.domains.depol.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class DepolStatusReport.
 */
@Entity
@Table(name = "W7TQTDSR")
public class DepolStatusReport extends BaseAggregateRoot<UUID> implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 8149098435837630921L;

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The file name. */
    @Size(max = 50)
    @Column(name = "FILE_NAME")
    private String fileName;

    /** The code depol. */
    @Size(max = 25)
    @Column(name = "CODE_DEPOL")
    private String codeDepol;

    /** The code special. */
    @Size(max = 1)
    @Column(name = "CODE_SPECIAL")
    private String codeSpecial;

    /** The depol label. */
    @Size(max = 50)
    @Column(name = "DEPOL_LABEL")
    private String depolLabel;

    /** The crr min. */
    @Column(name = "RCRRTR_MIN")
    private Float crrMin;

    /** The crr max. */
    @Column(name = "RCRRTR_MAX")
    private Float crrMax;

    /** The mro min. */
    @Column(name = "MROTR_MIN")
    private Integer mroMin;

    /** The mro max. */
    @Column(name = "MROTR_MAX")
    private Integer mroMax;

    /** The str min. */
    @Column(name = "STR_MIN")
    private Float strMin;

    /** The str max. */
    @Column(name = "STR_MAX")
    private Float strMax;

    /** The coolstr min. */
    @Column(name = "COOLSTR_MIN")
    private Float coolstrMin;

    /** The cool str max. */
    @Column(name = "COOLSTR_MAX")
    private Float coolStrMax;

    /** The cx min. */
    @Column(name = "CX_MIN")
    private Float cxMin;

    /** The cx max. */
    @Column(name = "CX_MAX")
    private Float cxMax;

    /** The checking. */
    @Size(max = 256)
    @Column(name = "CHECKING")
    private String checking;

    /** The created date. */
    @Column(name = "CREATED_DATE")
    private String createdDate;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the file name.
     *
     * @param fileName the new file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Gets the code depol.
     *
     * @return the code depol
     */
    public String getCodeDepol() {
        return codeDepol;
    }

    /**
     * Sets the code depol.
     *
     * @param codeDepol the new code depol
     */
    public void setCodeDepol(String codeDepol) {
        this.codeDepol = codeDepol;
    }

    /**
     * Gets the code special.
     *
     * @return the code special
     */
    public String getCodeSpecial() {
        return codeSpecial;
    }

    /**
     * Sets the code special.
     *
     * @param codeSpecial the new code special
     */
    public void setCodeSpecial(String codeSpecial) {
        this.codeSpecial = codeSpecial;
    }

    /**
     * Gets the depol label.
     *
     * @return the depol label
     */
    public String getDepolLabel() {
        return depolLabel;
    }

    /**
     * Sets the depol label.
     *
     * @param depolLabel the new depol label
     */
    public void setDepolLabel(String depolLabel) {
        this.depolLabel = depolLabel;
    }

    /**
     * Gets the crr min.
     *
     * @return the crr min
     */
    public Float getCrrMin() {
        return crrMin;
    }

    /**
     * Sets the crr min.
     *
     * @param crrMin the new crr min
     */
    public void setCrrMin(Float crrMin) {
        this.crrMin = crrMin;
    }

    /**
     * Gets the crr max.
     *
     * @return the crr max
     */
    public Float getCrrMax() {
        return crrMax;
    }

    /**
     * Sets the crr max.
     *
     * @param crrMax the new crr max
     */
    public void setCrrMax(Float crrMax) {
        this.crrMax = crrMax;
    }

    /**
     * Gets the mro min.
     *
     * @return the mro min
     */
    public Integer getMroMin() {
        return mroMin;
    }

    /**
     * Sets the mro min.
     *
     * @param mroMin the new mro min
     */
    public void setMroMin(Integer mroMin) {
        this.mroMin = mroMin;
    }

    /**
     * Gets the mro max.
     *
     * @return the mro max
     */
    public Integer getMroMax() {
        return mroMax;
    }

    /**
     * Sets the mro max.
     *
     * @param mroMax the new mro max
     */
    public void setMroMax(Integer mroMax) {
        this.mroMax = mroMax;
    }

    /**
     * Gets the str min.
     *
     * @return the str min
     */
    public Float getStrMin() {
        return strMin;
    }

    /**
     * Sets the str min.
     *
     * @param strMin the new str min
     */
    public void setStrMin(Float strMin) {
        this.strMin = strMin;
    }

    /**
     * Gets the str max.
     *
     * @return the str max
     */
    public Float getStrMax() {
        return strMax;
    }

    /**
     * Sets the str max.
     *
     * @param strMax the new str max
     */
    public void setStrMax(Float strMax) {
        this.strMax = strMax;
    }

    /**
     * Gets the coolstr min.
     *
     * @return the coolstr min
     */
    public Float getCoolstrMin() {
        return coolstrMin;
    }

    /**
     * Sets the coolstr min.
     *
     * @param coolstrMin the new coolstr min
     */
    public void setCoolstrMin(Float coolstrMin) {
        this.coolstrMin = coolstrMin;
    }

    /**
     * Gets the cool str max.
     *
     * @return the cool str max
     */
    public Float getCoolStrMax() {
        return coolStrMax;
    }

    /**
     * Sets the cool str max.
     *
     * @param coolStrMax the new cool str max
     */
    public void setCoolStrMax(Float coolStrMax) {
        this.coolStrMax = coolStrMax;
    }

    /**
     * Gets the cx min.
     *
     * @return the cx min
     */
    public Float getCxMin() {
        return cxMin;
    }

    /**
     * Sets the cx min.
     *
     * @param cxMin the new cx min
     */
    public void setCxMin(Float cxMin) {
        this.cxMin = cxMin;
    }

    /**
     * Gets the cx max.
     *
     * @return the cx max
     */
    public Float getCxMax() {
        return cxMax;
    }

    /**
     * Sets the cx max.
     *
     * @param cxMax the new cx max
     */
    public void setCxMax(Float cxMax) {
        this.cxMax = cxMax;
    }

    /**
     * Gets the checking.
     *
     * @return the checking
     */
    public String getChecking() {
        return checking;
    }

    /**
     * Sets the checking.
     *
     * @param checking the new checking
     */
    public void setChecking(String checking) {
        this.checking = checking;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((checking == null) ? 0 : checking.hashCode());
        result = prime * result + ((codeDepol == null) ? 0 : codeDepol.hashCode());
        result = prime * result + ((codeSpecial == null) ? 0 : codeSpecial.hashCode());
        result = prime * result + ((coolStrMax == null) ? 0 : coolStrMax.hashCode());
        result = prime * result + ((coolstrMin == null) ? 0 : coolstrMin.hashCode());
        result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
        result = prime * result + ((crrMax == null) ? 0 : crrMax.hashCode());
        result = prime * result + ((crrMin == null) ? 0 : crrMin.hashCode());
        result = prime * result + ((cxMax == null) ? 0 : cxMax.hashCode());
        result = prime * result + ((cxMin == null) ? 0 : cxMin.hashCode());
        result = prime * result + ((depolLabel == null) ? 0 : depolLabel.hashCode());
        result = prime * result + ((fileName == null) ? 0 : fileName.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((mroMax == null) ? 0 : mroMax.hashCode());
        result = prime * result + ((mroMin == null) ? 0 : mroMin.hashCode());
        result = prime * result + ((strMax == null) ? 0 : strMax.hashCode());
        result = prime * result + ((strMin == null) ? 0 : strMin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        DepolStatusReport other = (DepolStatusReport) obj;
        if (checking == null) {
            if (other.checking != null)
                return false;
        } else if (!checking.equals(other.checking))
            return false;
        if (codeDepol == null) {
            if (other.codeDepol != null)
                return false;
        } else if (!codeDepol.equals(other.codeDepol))
            return false;
        if (codeSpecial == null) {
            if (other.codeSpecial != null)
                return false;
        } else if (!codeSpecial.equals(other.codeSpecial))
            return false;
        if (coolStrMax == null) {
            if (other.coolStrMax != null)
                return false;
        } else if (!coolStrMax.equals(other.coolStrMax))
            return false;
        if (coolstrMin == null) {
            if (other.coolstrMin != null)
                return false;
        } else if (!coolstrMin.equals(other.coolstrMin))
            return false;
        if (createdDate == null) {
            if (other.createdDate != null)
                return false;
        } else if (!createdDate.equals(other.createdDate))
            return false;
        if (crrMax == null) {
            if (other.crrMax != null)
                return false;
        } else if (!crrMax.equals(other.crrMax))
            return false;
        if (crrMin == null) {
            if (other.crrMin != null)
                return false;
        } else if (!crrMin.equals(other.crrMin))
            return false;
        if (cxMax == null) {
            if (other.cxMax != null)
                return false;
        } else if (!cxMax.equals(other.cxMax))
            return false;
        if (cxMin == null) {
            if (other.cxMin != null)
                return false;
        } else if (!cxMin.equals(other.cxMin))
            return false;
        if (depolLabel == null) {
            if (other.depolLabel != null)
                return false;
        } else if (!depolLabel.equals(other.depolLabel))
            return false;
        if (fileName == null) {
            if (other.fileName != null)
                return false;
        } else if (!fileName.equals(other.fileName))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (mroMax == null) {
            if (other.mroMax != null)
                return false;
        } else if (!mroMax.equals(other.mroMax))
            return false;
        if (mroMin == null) {
            if (other.mroMin != null)
                return false;
        } else if (!mroMin.equals(other.mroMin))
            return false;
        if (strMax == null) {
            if (other.strMax != null)
                return false;
        } else if (!strMax.equals(other.strMax))
            return false;
        if (strMin == null) {
            if (other.strMin != null)
                return false;
        } else if (!strMin.equals(other.strMin))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "DepolStatusReport [guid=" + guid + ", fileName=" + fileName + ", codeDepol=" + codeDepol + ", codeSpecial=" + codeSpecial
                + ", depolLabel=" + depolLabel + ", crrMin=" + crrMin + ", crrMax=" + crrMax + ", mroMin=" + mroMin + ", mroMax=" + mroMax
                + ", strMin=" + strMin + ", strMax=" + strMax + ", coolstrMin=" + coolstrMin + ", coolStrMax=" + coolStrMax + ", cxMin=" + cxMin
                + ", cxMax=" + cxMax + ", checking=" + checking + ", createdDate=" + createdDate + "]";
    }

}
