/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;

import com.inetpsa.w7t.domains.depol.model.Depol;

/**
 * The Interface DepolRepository.
 */
public interface DepolRepository extends GenericRepository<Depol, UUID> {

    /**
     * Exists.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param crrMin the crr min
     * @param crrMax the crr max
     * @return true, if successful
     */
    public boolean exists(String codeDepol, String specialFlag, Float crrMin, Float crrMax);

    /**
     * Depol by unique fields.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @return the list
     */
    public List<Depol> depolByUniqueFields(String codeDepol, String specialFlag);

    /**
     * Depol by unique fields.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param crrMin the crr min
     * @param crrMax the crr max
     * @param cxMin the cx min
     * @param cxMax the cx max
     * @return the optional
     */
    public Optional<Depol> depolByUniqueFields(String codeDepol, String specialFlag, Float crrMin, Float crrMax, Float cxMin, Float cxMax);

    /**
     * Exists.
     *
     * @param codeDepol the code depol
     * @return true, if successful
     */
    public boolean exists(String codeDepol);

    /**
     * Depol by quadruple fields.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param rcrr the rcrr
     * @return the list
     */
    public List<Depol> depolByQuadrupleFields(String codeDepol, String specialFlag, Double rcrr);

    /**
     * Gets the all depols by unique fields.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param crrMin the crr min
     * @param crrMax the crr max
     * @return the all depols by unique fields
     */
    List<Depol> getAllDepolsByUniqueFields(String codeDepol, String specialFlag, Float crrMin, Float crrMax);

    /**
     * Depol by triplet fields.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param cxtr the cxtr
     * @return the optional
     */
    public Optional<Depol> depolByTripletFields(String codeDepol, String specialFlag, Double cxtr);

    /**
     * Depol by key.
     *
     * @param codeDepol the code depol
     * @param specialFlag the special flag
     * @param rcrr the rcrr
     * @param cxtr the cxtr
     * @return the list
     */
    List<Depol> depolByKey(String codeDepol, String specialFlag, Double rcrr, Double cxtr);
}
