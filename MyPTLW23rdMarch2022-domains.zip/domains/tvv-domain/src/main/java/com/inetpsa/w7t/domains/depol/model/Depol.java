/*
 * Creation : 9 Jul 2019
 */
package com.inetpsa.w7t.domains.depol.model;

import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class Depol.
 */
@Entity
@Table(name = "W7TQTDEP")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Depol extends BaseAggregateRoot<UUID> {
    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code depol. */
    @Size(max = 25)
    @Column(name = "CODE_DEPOL")
    private String codeDepol;

    /** The special flag. */
    @Size(max = 1)
    @Column(name = "CODE_SPECIAL")
    private String specialFlag;

    /** The designation. */
    @Size(max = 50)
    @Column(name = "LABEL_DEPOL")
    private String designation;

    /** The mro min. */
    @Column(name = "MROTR_MIN")
    private Integer mroMin;

    /** The mro max. */
    @Column(name = "MROTR_MAX")
    private Integer mroMax;

    /** The frontal area min. */
    @Column(name = "STR_MIN")
    private Float frontalAreaMin;

    /** The frontal area max. */
    @Column(name = "STR_MAX")
    private Float frontalAreaMax;

    /** The cooling surface min. */
    @Column(name = "COOLSTR_MIN")
    private Float coolingSurfaceMin;

    /** The cooling surface max. */
    @Column(name = "COOLSTR_MAX")
    private Float coolingSurfaceMax;

    /** The crr min. */
    @Column(name = "RCRRTR_MIN")
    private Float crrMin;

    /** The crr max. */
    @Column(name = "RCRRTR_MAX")
    private Float crrMax;

    /** The cx min. */
    @Column(name = "CX_MIN")
    private Float cxMin;

    /** The cx max. */
    @Column(name = "CX_MAX")
    private Float cxMax;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code depol.
     *
     * @return the code depol
     */
    public String getCodeDepol() {
        return codeDepol;
    }

    /**
     * Sets the code depol.
     *
     * @param codeDepol the new code depol
     */
    public void setCodeDepol(String codeDepol) {
        this.codeDepol = codeDepol;
    }

    /**
     * Gets the special flag.
     *
     * @return the special flag
     */
    public String getSpecialFlag() {
        return specialFlag;
    }

    /**
     * Sets the special flag.
     *
     * @param specialFlag the new special flag
     */
    public void setSpecialFlag(String specialFlag) {
        this.specialFlag = specialFlag;
    }

    /**
     * Gets the designation.
     *
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Sets the designation.
     *
     * @param designation the new designation
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * Gets the mro min.
     *
     * @return the mro min
     */
    public Integer getMroMin() {
        return mroMin;
    }

    /**
     * Sets the mro min.
     *
     * @param mroMin the new mro min
     */
    public void setMroMin(Integer mroMin) {
        this.mroMin = mroMin;
    }

    /**
     * Gets the mro max.
     *
     * @return the mro max
     */
    public Integer getMroMax() {
        return mroMax;
    }

    /**
     * Sets the mro max.
     *
     * @param mroMax the new mro max
     */
    public void setMroMax(Integer mroMax) {
        this.mroMax = mroMax;
    }

    /**
     * Gets the frontal area min.
     *
     * @return the frontal area min
     */
    public Float getFrontalAreaMin() {
        return frontalAreaMin;
    }

    /**
     * Sets the frontal area min.
     *
     * @param frontalAreaMin the new frontal area min
     */
    public void setFrontalAreaMin(Float frontalAreaMin) {
        this.frontalAreaMin = frontalAreaMin;
    }

    /**
     * Gets the frontal area max.
     *
     * @return the frontal area max
     */
    public Float getFrontalAreaMax() {
        return frontalAreaMax;
    }

    /**
     * Sets the frontal area max.
     *
     * @param frontalAreaMax the new frontal area max
     */
    public void setFrontalAreaMax(Float frontalAreaMax) {
        this.frontalAreaMax = frontalAreaMax;
    }

    /**
     * Gets the cooling surface min.
     *
     * @return the cooling surface min
     */
    public Float getCoolingSurfaceMin() {
        return coolingSurfaceMin;
    }

    /**
     * Sets the cooling surface min.
     *
     * @param coolingSurfaceMin the new cooling surface min
     */
    public void setCoolingSurfaceMin(Float coolingSurfaceMin) {
        this.coolingSurfaceMin = coolingSurfaceMin;
    }

    /**
     * Gets the cooling surface max.
     *
     * @return the cooling surface max
     */
    public Float getCoolingSurfaceMax() {
        return coolingSurfaceMax;
    }

    /**
     * Sets the cooling surface max.
     *
     * @param coolingSurfaceMax the new cooling surface max
     */
    public void setCoolingSurfaceMax(Float coolingSurfaceMax) {
        this.coolingSurfaceMax = coolingSurfaceMax;
    }

    /**
     * Gets the crr min.
     *
     * @return the crr min
     */
    public Float getCrrMin() {
        return crrMin;
    }

    /**
     * Sets the crr min.
     *
     * @param crrMin the new crr min
     */
    public void setCrrMin(Float crrMin) {
        this.crrMin = crrMin;
    }

    /**
     * Gets the crr max.
     *
     * @return the crr max
     */
    public Float getCrrMax() {
        return crrMax;
    }

    /**
     * Sets the crr max.
     *
     * @param crrMax the new crr max
     */
    public void setCrrMax(Float crrMax) {
        this.crrMax = crrMax;
    }

    /**
     * Gets the cx min.
     *
     * @return the cx min
     */
    public Float getCxMin() {
        return cxMin;
    }

    /**
     * Sets the cx min.
     *
     * @param cxMin the new cx min
     */
    public void setCxMin(Float cxMin) {
        this.cxMin = cxMin;
    }

    /**
     * Gets the cx max.
     *
     * @return the cx max
     */
    public Float getCxMax() {
        return cxMax;
    }

    /**
     * Sets the cx max.
     *
     * @param cxMax the new cx max
     */
    public void setCxMax(Float cxMax) {
        this.cxMax = cxMax;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((codeDepol == null) ? 0 : codeDepol.hashCode());
        result = prime * result + ((coolingSurfaceMax == null) ? 0 : coolingSurfaceMax.hashCode());
        result = prime * result + ((coolingSurfaceMin == null) ? 0 : coolingSurfaceMin.hashCode());
        result = prime * result + ((crrMax == null) ? 0 : crrMax.hashCode());
        result = prime * result + ((crrMin == null) ? 0 : crrMin.hashCode());
        result = prime * result + ((cxMin == null) ? 0 : cxMin.hashCode());
        result = prime * result + ((cxMax == null) ? 0 : cxMax.hashCode());
        result = prime * result + ((designation == null) ? 0 : designation.hashCode());
        result = prime * result + ((frontalAreaMax == null) ? 0 : frontalAreaMax.hashCode());
        result = prime * result + ((frontalAreaMin == null) ? 0 : frontalAreaMin.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((mroMax == null) ? 0 : mroMax.hashCode());
        result = prime * result + ((mroMin == null) ? 0 : mroMin.hashCode());
        result = prime * result + ((specialFlag == null) ? 0 : specialFlag.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Depol other = (Depol) obj;
        if (codeDepol == null) {
            if (other.codeDepol != null)
                return false;
        } else if (!codeDepol.equals(other.codeDepol))
            return false;
        if (coolingSurfaceMax == null) {
            if (other.coolingSurfaceMax != null)
                return false;
        } else if (!coolingSurfaceMax.equals(other.coolingSurfaceMax))
            return false;
        if (coolingSurfaceMin == null) {
            if (other.coolingSurfaceMin != null)
                return false;
        } else if (!coolingSurfaceMin.equals(other.coolingSurfaceMin))
            return false;
        if (crrMax == null) {
            if (other.crrMax != null)
                return false;
        } else if (!crrMax.equals(other.crrMax))
            return false;
        if (crrMin == null) {
            if (other.crrMin != null)
                return false;
        } else if (!crrMin.equals(other.crrMin))
            return false;
        if (cxMin == null) {
            if (other.cxMin != null)
                return false;
        } else if (!cxMin.equals(other.cxMin))
            return false;
        if (cxMax == null) {
            if (other.cxMax != null)
                return false;
        } else if (!cxMax.equals(other.cxMax))
            return false;
        if (designation == null) {
            if (other.designation != null)
                return false;
        } else if (!designation.equals(other.designation))
            return false;
        if (frontalAreaMax == null) {
            if (other.frontalAreaMax != null)
                return false;
        } else if (!frontalAreaMax.equals(other.frontalAreaMax))
            return false;
        if (frontalAreaMin == null) {
            if (other.frontalAreaMin != null)
                return false;
        } else if (!frontalAreaMin.equals(other.frontalAreaMin))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (mroMax == null) {
            if (other.mroMax != null)
                return false;
        } else if (!mroMax.equals(other.mroMax))
            return false;
        if (mroMin == null) {
            if (other.mroMin != null)
                return false;
        } else if (!mroMin.equals(other.mroMin))
            return false;
        if (specialFlag == null) {
            if (other.specialFlag != null)
                return false;
        } else if (!specialFlag.equals(other.specialFlag))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Depol [guid=" + guid + ", codeDepol=" + codeDepol + ", specialFlag=" + specialFlag + ", designation=" + designation + ", mroMin="
                + mroMin + ", mroMax=" + mroMax + ", frontalAreaMin=" + frontalAreaMin + ", frontalAreaMax=" + frontalAreaMax + ", coolingSurfaceMin="
                + coolingSurfaceMin + ", coolingSurfaceMax=" + coolingSurfaceMax + ", crrMin=" + crrMin + ", crrMax=" + crrMax + ", cxMin=" + cxMin
                + ", cxMax=" + cxMax + "]";
    }

}
