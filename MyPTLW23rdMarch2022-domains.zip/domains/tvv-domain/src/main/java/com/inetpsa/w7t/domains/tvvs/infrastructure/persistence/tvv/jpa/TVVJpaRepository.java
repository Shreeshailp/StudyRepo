/*
 * Creation : 29 May 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.jpa;

import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class TVVJpaRepository extends BaseJpaRepository<TVV, UUID> implements TVVRepository {

    @Inject
    @Jpa
    private Repository<TVV, UUID> tvvRepo;

    private static final String GUID = "guid";
    private static final String VEHICLE_FAMILY = "vehicleFamily";
    private static final String T1A_VALUE = "t1AValue";
    private static final String T1B_VALUE = "t1BValue";
    private static final String TVV_DESIGNATION = "tvvDesignation";

    public boolean exists(String vFamily, String t1a, String t1b) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<TVV> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(VEHICLE_FAMILY), cb.parameter(String.class, VEHICLE_FAMILY)),
                cb.equal(root.get(T1A_VALUE), cb.parameter(String.class, T1A_VALUE)),
                cb.equal(root.get(T1B_VALUE), cb.parameter(String.class, T1B_VALUE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(VEHICLE_FAMILY, vFamily);
        query.setParameter(T1A_VALUE, t1a);
        query.setParameter(T1B_VALUE, t1b);

        return query.getResultList().stream().findFirst().isPresent();
    }

    public List<TVV> tvvByUniqueFields(String vFamily, String t1a, String t1b) {
        // WltpCacheManager<TVV> wltpCacheManager = WltpCacheManager.getInstance(TVV.class);
        // String key = vFamily + "_" + t1a + "_" + t1b;
        // List<TVV> list = wltpCacheManager.getListItem(key);
        //
        // if (list != null && !list.isEmpty()) {
        // return list;
        // }

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TVV> q = cb.createQuery(TVV.class);
        Root<TVV> root = q.from(TVV.class);
        q.where(cb.equal(root.get(VEHICLE_FAMILY), cb.parameter(String.class, VEHICLE_FAMILY)),
                cb.equal(root.get(T1A_VALUE), cb.parameter(String.class, T1A_VALUE)),
                cb.equal(root.get(T1B_VALUE), cb.parameter(String.class, T1B_VALUE)));

        TypedQuery<TVV> query = entityManager.createQuery(q);
        query.setParameter(VEHICLE_FAMILY, vFamily);
        query.setParameter(T1A_VALUE, t1a);
        query.setParameter(T1B_VALUE, t1b);
        // list = query.getResultList();
        // wltpCacheManager.putListItem(key, list);
        // return list;
        return query.getResultList();
    }

    public List<TVV> tvvByUniqueFields(String vFamily, String tvvdesignation) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TVV> q = cb.createQuery(TVV.class);
        Root<TVV> root = q.from(TVV.class);
        q.where(cb.equal(root.get(VEHICLE_FAMILY), cb.parameter(String.class, VEHICLE_FAMILY)),
                cb.equal(root.get(TVV_DESIGNATION), cb.parameter(String.class, TVV_DESIGNATION)));

        TypedQuery<TVV> query = entityManager.createQuery(q);
        query.setParameter(VEHICLE_FAMILY, vFamily);
        query.setParameter(TVV_DESIGNATION, tvvdesignation);

        return query.getResultList();
    }

    @Override
    public boolean existsAboveBottomValue(Integer tvvMaxspeed) {
        String q = "SELECT VALUE FROM W7TQTPRM WHERE ID ='tvv_max_speed_bottom_value'";
        Query query = entityManager.createNativeQuery(q);
        if (query.getResultList().isEmpty())
            return false;
        return (tvvMaxspeed < Integer.valueOf((String) query.getSingleResult())) ? false : true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository#tvvByFamilyTvvDesigT1AT1B(java.lang.String, java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    // jira-744 fix starts here
    public List<TVV> tvvByFamilyTvvDesigT1AT1B(String vFamily, String tvvDesignation, String t1a, String t1b) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TVV> q = cb.createQuery(TVV.class);
        Root<TVV> root = q.from(TVV.class);
        q.where(cb.equal(root.get(VEHICLE_FAMILY), cb.parameter(String.class, VEHICLE_FAMILY)),
                cb.equal(root.get(TVV_DESIGNATION), cb.parameter(String.class, TVV_DESIGNATION)),
                cb.equal(root.get(T1A_VALUE), cb.parameter(String.class, T1A_VALUE)),
                cb.equal(root.get(T1B_VALUE), cb.parameter(String.class, T1B_VALUE)));

        TypedQuery<TVV> query = entityManager.createQuery(q);
        query.setParameter(VEHICLE_FAMILY, vFamily);
        query.setParameter(TVV_DESIGNATION, tvvDesignation);
        query.setParameter(T1A_VALUE, t1a);
        query.setParameter(T1B_VALUE, t1b);

        return query.getResultList();
    }// jira-744 fix ends here

}
