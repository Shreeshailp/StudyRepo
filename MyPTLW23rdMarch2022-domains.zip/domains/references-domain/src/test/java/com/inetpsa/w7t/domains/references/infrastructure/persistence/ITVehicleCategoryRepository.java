/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.VehicleCategory;

@RunWith(SeedITRunner.class)
public class ITVehicleCategoryRepository {

    @Inject
    private VehicleCategoryRepository vehicleCategoryRepository;

    @Test
    public void allVehicleCategories() {
        List<VehicleCategory> vehicleCategories = vehicleCategoryRepository.all();

        assertThat(vehicleCategories).isNotNull();

    }

    @Test
    public void vehicleCategoryWithExistingCode() {
        Optional<VehicleCategory> vehicleCategory = vehicleCategoryRepository.byCode("M1");

        assertThat(vehicleCategory.isPresent()).isTrue();
        assertThat(vehicleCategory.get().getGuid()).hasToString("d9d3f543-17cc-4418-a8a5-ca400406c36a");
    }

    @Test
    public void vehicleCategoryWithNonExistingCode() {
        Optional<VehicleCategory> vehicleCategory = vehicleCategoryRepository.byCode("gg");

        assertThat(vehicleCategory.isPresent()).isFalse();

    }

    @Test
    public void vehicleCategoryExists() {
        boolean vehicleCategory = vehicleCategoryRepository.exists("N1");

        assertThat(vehicleCategory).isTrue();
    }

    @Test
    public void vehicleCategoryNotExists() {
        boolean testVehicleType = vehicleCategoryRepository.exists("wp");

        assertThat(testVehicleType).isFalse();
    }
}
