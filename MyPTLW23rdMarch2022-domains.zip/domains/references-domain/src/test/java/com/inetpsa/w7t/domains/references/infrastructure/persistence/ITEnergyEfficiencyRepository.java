
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.EnergyEfficiency;

@RunWith(SeedITRunner.class)
public class ITEnergyEfficiencyRepository {

    @Inject
    private EnergyEfficiencyRepository energyEfficiencyRepository;

    @Test
    public void allEnergyEfficiencyClasses() {
        List<EnergyEfficiency> energyEfficiencies = energyEfficiencyRepository.all();

        assertThat(energyEfficiencies).isNotNull().hasSize(12);
    }

    @Test
    public void energyEfficiencyClassExistingValue() {
        String energyEfficiencyClass = energyEfficiencyRepository.getEnergyClassByValue(7.1);

        assertThat(energyEfficiencyClass).isEqualTo("B");
    }

    @Test
    public void energyEfficiencyClassNonExistingValue() {
        String energyEfficiencyClass = energyEfficiencyRepository.getEnergyClassByValue(5.6);

        assertThat(energyEfficiencyClass).isEqualTo(" ");
    }
}
