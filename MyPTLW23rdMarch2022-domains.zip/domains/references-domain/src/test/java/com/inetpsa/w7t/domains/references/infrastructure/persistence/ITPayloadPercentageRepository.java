/*
 * Creation : 19 avr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.PayloadPercentage;

@RunWith(SeedITRunner.class)
public class ITPayloadPercentageRepository {
    @Inject
    private PayloadPercentageRepository payloadPercentageRepository;

    private PayloadPercentage nominalPayloadPercentage;

    @Before
    public void setUp() {
        nominalPayloadPercentage = new PayloadPercentage();
        nominalPayloadPercentage.setGuid(UUID.fromString("0d95ce48-709f-4386-8d59-12b606766ac9"));
        // nominalPayloadPercentage.setCategory("N1");
        nominalPayloadPercentage.setValue(28);
        nominalPayloadPercentage.setValidityStart(LocalDate.parse("2016-05-01"));
        nominalPayloadPercentage.setValidityEnd(LocalDate.parse("9999-12-31"));
    }

    @Test
    public void existingByCategoryAndDate() {
        assertThat(payloadPercentageRepository.byCategoryAndDate("N1", LocalDate.parse("2016-05-01"))).as("Existing Payload Percentage").isPresent()
                .contains(nominalPayloadPercentage);
    }

    @Test
    public void nonExistingByCategoryAndDate() {
        assertThat(payloadPercentageRepository.byCategoryAndDate("00", LocalDate.parse("1017-02-15"))).as("Non-existing Payload Percentage")
                .isNotPresent();
    }
}
