/*
 * Creation : 31 mai 2017
 */
package com.inetpsa.w7t.domains.core.services;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

@RunWith(SeedITRunner.class)
public class ITUserService {

    @Inject
    private UserService userService;

    @Test
    public void userWithValidId() {
        String id = userService.getUserId();

        assertThat(id).isNotEmpty();

    }
}
