/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;

@RunWith(SeedITRunner.class)
public class ITPhysicalQuantityTypeRepository {

    @Inject
    private PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    @Test
    public void allPhysicalQuantityTypes() {
        List<PhysicalQuantityType> physicalQuantityTypes = physicalQuantityTypeRepository.all();

        assertThat(physicalQuantityTypes).isNotNull();
    }

    @Test
    public void physicalQuantityTypeWithExistingCode() {
        Optional<PhysicalQuantityType> physicalQuantityType = physicalQuantityTypeRepository.byCode("TMASSE");

        assertThat(physicalQuantityType.isPresent()).isTrue();
        assertThat(physicalQuantityType.get().getGuid()).hasToString("1f84db74-ed88-45c7-860c-55a47a0edba2");
        assertThat(physicalQuantityType.get().getSort()).isEqualTo(4);
    }

    @Test
    public void physicalQuantityTypeWithNonExistingCode() {
        Optional<PhysicalQuantityType> physicalQuantityType = physicalQuantityTypeRepository.byCode("XMATT");

        assertThat(physicalQuantityType.isPresent()).isFalse();

    }

    @Test
    public void physicalQuantityTypeExists() {
        boolean physicalQuantityType = physicalQuantityTypeRepository.exists("SCX");

        assertThat(physicalQuantityType).isTrue();
    }

    @Test
    public void physicalQuantityTypeNotExists() {
        boolean physicalQuantityType = physicalQuantityTypeRepository.exists("XCS");

        assertThat(physicalQuantityType).isFalse();
    }

}
