/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.VehicleType;

@RunWith(SeedITRunner.class)
public class ITVehicleTypeRepository {

    @Inject
    private VehicleTypeRepository vehicleTypeRepository;

    @Test
    public void allVehicleTypes() {
        List<VehicleType> vehicleTypes = vehicleTypeRepository.all();

        assertThat(vehicleTypes).isNotNull();

    }

    @Test
    public void vehicleTypeWithExistingCode() {
        Optional<VehicleType> vehicleType = vehicleTypeRepository.byCode("ELEC");

        assertThat(vehicleType.isPresent()).isTrue();
        assertThat(vehicleType.get().getGuid()).hasToString("fdff5043-8621-474b-b2b3-3b92ae2aceb3");
    }

    @Test
    public void cachedVehicleType() {
        Optional<UUID> vehicleType1 = vehicleTypeRepository.guidByCode("ELEC");
        Optional<UUID> vehicleType2 = vehicleTypeRepository.guidByCode("ELEC");

    }

    @Test
    public void vehicleTypeWithNonExistingCode() {
        Optional<VehicleType> vehicleType = vehicleTypeRepository.byCode("COAL");

        assertThat(vehicleType.isPresent()).isFalse();

    }

    @Test
    public void vehicleTypeExists() {
        boolean vehicleType = vehicleTypeRepository.exists("HYNR");

        assertThat(vehicleType).isTrue();
    }

    @Test
    public void vehicleTypeNotExists() {
        boolean vehicleType = vehicleTypeRepository.exists("GGWP");

        assertThat(vehicleType).isFalse();
    }
}
