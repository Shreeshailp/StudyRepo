/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.TestVehicleType;

@RunWith(SeedITRunner.class)
public class ITTestVehicleTypeRepository {

    @Inject
    private TestVehicleTypeRepository testVehicleTypeRepository;

    @Test
    public void alltestVehicleTypes() {
        List<TestVehicleType> testVehicleTypes = testVehicleTypeRepository.all();

        assertThat(testVehicleTypes).isNotNull();
        assertThat(testVehicleTypes).hasSize(3);

    }

    @Test
    public void testVehicleTypeWithExistingCode() {
        Optional<TestVehicleType> testVehicleType = testVehicleTypeRepository.byCode("VLOW");

        assertThat(testVehicleType.isPresent()).isTrue();
        assertThat(testVehicleType.get().getGuid()).hasToString("227513f7-2b0a-47f4-9480-4729be0b3277");
    }

    @Test
    public void testVehicleTypeWithNonExistingCode() {
        Optional<TestVehicleType> testVehicleType = testVehicleTypeRepository.byCode("VVLOW");

        assertThat(testVehicleType.isPresent()).isFalse();

    }

    @Test
    public void testVehicleTypeExists() {
        boolean testVehicleType = testVehicleTypeRepository.exists("VHIGH");

        assertThat(testVehicleType).isTrue();
    }

    @Test
    public void testVehicleTypeNotExists() {
        boolean testVehicleType = testVehicleTypeRepository.exists("LIGH");

        assertThat(testVehicleType).isFalse();
    }
}
