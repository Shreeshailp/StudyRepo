/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.MeasureType;

@RunWith(SeedITRunner.class)
public class ITMeasureTypeRepository {

    @Inject
    private MeasureTypeRepository measureTypeRepository;

    @Test
    public void allMeasureTypes() {
        List<MeasureType> measureTypes = measureTypeRepository.all();

        assertThat(measureTypes).isNotNull();
    }

    @Test
    public void measureTypeWithExistingCode() {
        Optional<MeasureType> measureType = measureTypeRepository.byCode("CO2CD");

        assertThat(measureType.isPresent()).isTrue();
        assertThat(measureType.get().getGuid()).hasToString("d2493a4a-ef77-4292-a744-b01d663539e5");
        assertThat(measureType.get().getSort()).isEqualTo(12);
    }

    @Test
    public void measureTypeWithNonExistingCode() {
        Optional<MeasureType> measureType = measureTypeRepository.byCode("CO3");

        assertThat(measureType.isPresent()).isFalse();

    }

    @Test
    public void measureTypeExists() {
        boolean measureType = measureTypeRepository.exists("CE");

        assertThat(measureType).isTrue();
    }

    @Test
    public void measureTypeNotExists() {
        boolean measureType = measureTypeRepository.exists("CEOO");

        assertThat(measureType).isFalse();
    }

    @Test
    public void roudingDigitForExistingCode() {
        int roundingDigit = measureTypeRepository.roundingDigitByCode("CO2CD");

        assertThat(roundingDigit).isEqualTo(0);
    }

    @Test
    public void roudingDigitForNonExistingCode() {
        int roundingDigit = measureTypeRepository.roundingDigitByCode("CO3");

        assertThat(roundingDigit).isEqualTo(0);

    }
}
