/*
 * Creation : 14 févr. 2017
 */
package com.inetpsa.w7t.domains.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.core.infrastructure.persistence.LabelRepository;
import com.inetpsa.w7t.domains.core.model.Label;

@RunWith(SeedITRunner.class)
public class ITLabelRepository {

    private static final UUID UUID_TEST = UUID.fromString("012d1a12-da1e-4069-b00e-0f94d289b87f");
    @Inject
    private LabelRepository labelRepository;

    @Test
    public void existingLabel() {
        Optional<Label> label = labelRepository.byKeyAndLocale(UUID_TEST, "FR");

        assertThat(label.isPresent()).isTrue();
        assertThat(label.get()).isNotNull();
        assertThat(label.get().getValue()).isEqualTo("ISRAEL");
    }

    @Test
    public void badKey() {
        Optional<Label> label = labelRepository.byKeyAndLocale(UUID.randomUUID(), Locale.FRANCE.toString());

        assertThat(label.isPresent()).isFalse();
    }

    @Test
    public void nullKey() {
        Optional<Label> label = labelRepository.byKeyAndLocale(null, Locale.FRANCE.toString());

        assertThat(label.isPresent()).isFalse();
    }

    @Test
    public void badLocale() {
        Optional<Label> label = labelRepository.byKeyAndLocale(UUID_TEST, "fr-ZH");

        assertThat(label.isPresent()).isFalse();
    }

    @Test
    public void nullLocale() {
        Optional<Label> label = labelRepository.byKeyAndLocale(UUID_TEST, null);

        assertThat(label.isPresent()).isFalse();
    }

}
