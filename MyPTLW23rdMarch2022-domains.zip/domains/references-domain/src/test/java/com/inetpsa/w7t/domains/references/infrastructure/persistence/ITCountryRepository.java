/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.Country;

@RunWith(SeedITRunner.class)
public class ITCountryRepository {

    @Inject
    private CountryRepository countryRepository;

    @Test
    public void allCountries() {
        List<Country> countries = countryRepository.all();

        assertThat(countries).isNotNull();

    }

    @Test
    public void countryWithExistingCode() {
        Optional<Country> country = countryRepository.byCode("A0");

        assertThat(country.isPresent()).isTrue();
        assertThat(country.get().getGuid()).hasToString("4eda7455-485a-4918-a076-ccc95adbbd75");
    }

    @Test
    public void countryWithNonExistingCode() {
        Optional<Country> country = countryRepository.byCode("ze");

        assertThat(country.isPresent()).isFalse();

    }

    @Test
    public void countryExists() {
        boolean country = countryRepository.exists("F9");

        assertThat(country).isTrue();
    }

    @Test
    public void countryNotExists() {
        boolean country = countryRepository.exists("ze");

        assertThat(country).isFalse();
    }

    @Test
    public void countryWithExistingCodeAndCharacteristic() {
        Country country = countryRepository.byCodeAndCharacteristic("A0", "GG8");
        Optional<Country> countries = Optional.ofNullable(country);

        assertThat(countries.isPresent()).isTrue();
        assertThat(countries.get().getGuid()).hasToString("4eda7455-485a-4918-a076-ccc95adbbd75");

    }

    @Test
    public void countryWithNonExistingCodeAndCharacteristic() {
        Country country = countryRepository.byCodeAndCharacteristic("ze", "8GG");
        Optional<Country> countries = Optional.ofNullable(country);
        assertThat(countries.isPresent()).isFalse();

    }

}
