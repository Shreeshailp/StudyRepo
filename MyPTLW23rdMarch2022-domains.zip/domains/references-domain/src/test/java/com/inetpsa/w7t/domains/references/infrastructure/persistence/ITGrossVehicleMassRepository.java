/*
 * Creation : 19 avr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.UUID;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;

@RunWith(SeedITRunner.class)
public class ITGrossVehicleMassRepository {
	@Inject
	GrossVehicleMassRepository grossVehicleMassRepository;

	GrossVehicleMass nominalGrossVehicleMass;

	@Before
	public void setUp() {
		nominalGrossVehicleMass = new GrossVehicleMass();
		nominalGrossVehicleMass.setGuid(UUID.fromString("08e8a9be-b152-47d8-9d69-25590293822c"));
		nominalGrossVehicleMass.setCode("40");
		nominalGrossVehicleMass.setFamily("1CXA");
		nominalGrossVehicleMass.setValue("1433");
	}

	@Test
	public void existingByFamilyCodeAndCharacteristic() {
		assertThat(grossVehicleMassRepository.byFamilyCodeAndCharacteristic("1CXA", "40", "T3N")).as("Existing gvm")
				.isPresent().contains(nominalGrossVehicleMass);
	}

	@Test
	public void missingByFamilyCodeAndCharacteristic() {
		assertThat(grossVehicleMassRepository.byFamilyCodeAndCharacteristic("1CE4", "02", "T3N")).as("Non Existing gvm")
				.isNotPresent();
	}

	@Test
	public void isDefinedFamilyCodeAndCharacteristic() {
		assertThat(grossVehicleMassRepository.isDefined("1CE4", "02", "T3N")).as("Defined gvm").isTrue();
	}
}
