/*
 * Creation : 3 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.references.model.CyclePhase;

@RunWith(SeedITRunner.class)
public class ITCyclePhaseRepository {

    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    @Test
    public void allCyclePhases() {
        List<CyclePhase> cyclephases = cyclePhaseRepository.all();

        assertThat(cyclephases).isNotNull();
        assertThat(cyclephases).hasSize(6);
    }

    @Test
    public void cyclePhaseWithExistingCode() {
        Optional<CyclePhase> cyclephase = cyclePhaseRepository.byCode("EHIGH");

        assertThat(cyclephase.isPresent()).isTrue();
        assertThat(cyclephase.get().getGuid()).hasToString("3eb99a95-f14b-4034-8d16-8568b8682e7c");
        assertThat(cyclephase.get().getSort()).isEqualTo(3);
    }

    @Test
    public void countryWithNonExistingCode() {
        Optional<CyclePhase> cyclephase = cyclePhaseRepository.byCode("ZHIGH");

        assertThat(cyclephase.isPresent()).isFalse();

    }

    @Test
    public void cyclePhaseExists() {
        boolean cyclephase = cyclePhaseRepository.exists("CITY");

        assertThat(cyclephase).isTrue();
    }

    @Test
    public void cyclePhaseNotExists() {
        boolean cyclephase = cyclePhaseRepository.exists("TOWN");

        assertThat(cyclephase).isFalse();
    }

    @Test
    public void cyclePhaseGuidCache() {
        cyclePhaseRepository.uuidByCode("CITY").orElse(null);
        cyclePhaseRepository.uuidByCode("CITY").orElse(null);
    }
}
