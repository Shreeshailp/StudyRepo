/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.cache.annotation.CacheResult;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;

/**
 * The Class CyclePhaseJpaRepository. JPA Implementation of {@link CyclePhaseRepository}.
 */
public class CyclePhaseJpaRepository extends BaseJpaRepository<CyclePhase, UUID> implements CyclePhaseRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";
    /** The Constant GUID. */
    private static final String GUID = "guid";

    private static ConcurrentHashMap<String, List<CyclePhase>> phaseMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository#all()
     */
    @Override
    public List<CyclePhase> all() {
        String key = "CPH";
        List<CyclePhase> list = phaseMap.get(key);
        if (list != null && !list.isEmpty()) {
            return list;
        }
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<CyclePhase> q = entityManager.createQuery(criteriaQuery);
        list = q.getResultList();
        if (list != null && !list.isEmpty()) {
            phaseMap.put(key, list);
        }
        return list;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<CyclePhase> byCode(String code) {
        return cachedByCode(code);
    }

    // @CacheResult(cacheName = "cyclePhaseByCodeCache")
    public Optional<CyclePhase> cachedByCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> q = cb.createQuery(CyclePhase.class);
        Root<CyclePhase> phase = q.from(CyclePhase.class);
        q.where(cb.equal(phase.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<CyclePhase> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository#uuidByCode(java.lang.String)
     */
    @Override
    public Optional<UUID> uuidByCode(@CyclePhaseCode String code) {
        return Optional.ofNullable(cachedGuidByCode(code));
    }

    /**
     * Cached guid by code.
     *
     * @param code the code
     * @return the uuid
     */
    @CacheResult(cacheName = "cyclePhaseGuidCache")
    public UUID cachedGuidByCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<CyclePhase> phase = q.from(CyclePhase.class);
        q.select(phase.get(GUID));
        q.where(cb.equal(phase.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst().orElse(null);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(@CyclePhaseCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CyclePhase> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<CyclePhase> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<CyclePhase>get(CODE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
    }
}
