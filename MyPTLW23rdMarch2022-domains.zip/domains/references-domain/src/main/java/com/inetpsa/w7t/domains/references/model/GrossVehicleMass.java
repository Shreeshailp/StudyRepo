
package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class GrossVehicleMass. This aggregate represents
 */
// TODO update the entity
@Entity
@Table(name = "W7TQTGVM")
public class GrossVehicleMass extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The family. */
    @NotNull
    @Size(min = 4, max = 4)
    @Column(name = "FAMILY")
    private String family;

    /** The code. */ // TODO Validation
    @NotNull
    @Size(min = 2, max = 2)
    @Column(name = "CODE")
    private String code;

    /** The value. */ // TODO Validation
    @NotEmpty
    @Size(max = 30)
    @Column(name = "VALUE")
    private String value;

    /** The characteristic. */
    @NotNull
    @Size(min = 3, max = 3)
    @Column(name = "CHARACTERISTIC")
    private String characteristic;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof GrossVehicleMass))
            return false;

        GrossVehicleMass other = (GrossVehicleMass) o;
        String hash = new StringBuilder(family).append(code).append(value).toString();
        String otherHash = new StringBuilder(other.family).append(other.code).append(other.value).toString();
        return hash.equals(otherHash);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + family.hashCode();
        hashcode = hashcode * 31 + code.hashCode();
        return hashcode * 31 + value.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * Sets the family.
     *
     * @param family the new family
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the characteristic.
     *
     * @return the characteristic
     */
    public String getCharacteristic() {
        return characteristic;
    }

    /**
     * Sets the characteristic.
     *
     * @param characteristic the new characteristic
     */
    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

}
