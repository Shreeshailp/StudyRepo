/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.moteur.gearbox.services;

import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.references.model.GearBoxEntity;
import com.inetpsa.w7t.domains.references.model.MoteurEntity;
import com.inetpsa.w7t.domains.references.model.MoteurGearBoxDto;

/**
 * The Interface MoteurGearBoxService.
 */
@Service
public interface MoteurGearBoxService {

    /**
     * Save moteur entity.
     *
     * @param moteurGearBoxDto the moteur gear box dto
     */
    void saveMoteurEntity(MoteurGearBoxDto moteurGearBoxDto);

    /**
     * Save gear box entity.
     *
     * @param moteurGearBoxDto the moteur gear box dto
     */
    void saveGearBoxEntity(MoteurGearBoxDto moteurGearBoxDto);

    /**
     * By moteur code.
     *
     * @param code the code
     * @return the optional
     */
    Optional<MoteurEntity> byMoteurCode(String code);

    /**
     * By gear box code.
     *
     * @param code the code
     * @return the optional
     */
    Optional<GearBoxEntity> byGearBoxCode(String code);
}
