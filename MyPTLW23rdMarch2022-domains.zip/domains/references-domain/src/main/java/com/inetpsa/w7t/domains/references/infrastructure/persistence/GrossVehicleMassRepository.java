/*
 * Creation : 30 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;

/**
 * The Interface GrossVehicleMassRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface GrossVehicleMassRepository extends GenericRepository<GrossVehicleMass, UUID> {

    /**
     * By family code and characteristic.
     *
     * @param family the family
     * @param code the code
     * @param characteristic the characteristic
     * @return the optional
     */
    Optional<GrossVehicleMass> byFamilyCodeAndCharacteristic(String family, String code, String characteristic);

    /**
     * Checks if is defined.
     *
     * @param family the family
     * @param code the code
     * @param characteristic the characteristic
     * @return true, if is defined
     */
    boolean isDefined(String family, String code, String characteristic);

    /**
     * Performance change.
     *
     * @param family the family
     * @param code the code
     * @param characteristic the characteristic
     * @return the value by family code and characteristic
     */
    Optional<String> getValueByFamilyCodeAndCharacteristic(String family, String code, String characteristic);
}
