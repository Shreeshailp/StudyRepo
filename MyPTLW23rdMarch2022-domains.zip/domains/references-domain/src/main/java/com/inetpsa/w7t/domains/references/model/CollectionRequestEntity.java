/*
 * Creation : 10 Aug 2020
 */
package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.sql.Blob;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class CollectionRequestEntity.
 */
@Entity
@Table(name = "W7TQTCRQ")
public class CollectionRequestEntity extends BaseAggregateRoot<UUID> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8739268065120290009L;

    /** The collection request id. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID collectionRequestId;

    /** The request name. */
    @Column(name = "REQ_NAME")
    private String requestName;

    /** The request blob. */
    @Lob
    @Column(name = "REQUEST")
    private Blob requestBlob;

    /** The collection. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COL_ID", referencedColumnName = "ID")
    private CollectionEntity collection;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.collectionRequestId;
    }

    /**
     * Gets the collection request id.
     *
     * @return the collection request id
     */
    public UUID getCollectionRequestId() {
        return collectionRequestId;
    }

    /**
     * Sets the collection request id.
     *
     * @param collectionRequestId the new collection request id
     */
    public void setCollectionRequestId(UUID collectionRequestId) {
        this.collectionRequestId = collectionRequestId;
    }

    /**
     * Gets the request name.
     *
     * @return the request name
     */
    public String getRequestName() {
        return requestName;
    }

    /**
     * Sets the request name.
     *
     * @param requestName the new request name
     */
    public void setRequestName(String requestName) {
        this.requestName = requestName;
    }

    /**
     * Gets the request blob.
     *
     * @return the request blob
     */
    public Blob getRequestBlob() {
        return requestBlob;
    }

    /**
     * Sets the request blob.
     *
     * @param requestBlob the new request blob
     */
    public void setRequestBlob(Blob requestBlob) {
        this.requestBlob = requestBlob;
    }

    /**
     * Gets the collection.
     *
     * @return the collection
     */
    public CollectionEntity getCollection() {
        return collection;
    }

    /**
     * Sets the collection.
     *
     * @param collection the new collection
     */
    public void setCollection(CollectionEntity collection) {
        this.collection = collection;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((collectionRequestId == null) ? 0 : collectionRequestId.hashCode());
        result = prime * result + ((requestName == null) ? 0 : requestName.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        CollectionRequestEntity other = (CollectionRequestEntity) obj;
        if (collectionRequestId == null) {
            if (other.collectionRequestId != null)
                return false;
        } else if (!collectionRequestId.equals(other.collectionRequestId))
            return false;
        if (requestName == null) {
            if (other.requestName != null)
                return false;
        } else if (!requestName.equals(other.requestName))
            return false;
        return true;
    }

}
