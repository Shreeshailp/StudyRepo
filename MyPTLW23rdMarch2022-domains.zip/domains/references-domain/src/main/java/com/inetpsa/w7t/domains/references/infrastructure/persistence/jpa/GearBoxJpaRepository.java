/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.GearBoxEntity;

/**
 * The Class GearBoxJpaRepository.
 */
public class GearBoxJpaRepository extends BaseJpaRepository<GearBoxEntity, UUID> implements GearBoxRepository {

    private static final String CODE = "code";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.GearBoxRepository#all()
     */
    @Override
    public List<GearBoxEntity> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<GearBoxEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));
        TypedQuery<GearBoxEntity> q = entityManager.createQuery(criteriaQuery);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.GearBoxRepository#byGearBoxCode(java.lang.String)
     */
    @Override
    public Optional<GearBoxEntity> byGearBoxCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GearBoxEntity> q = cb.createQuery(aggregateRootClass);
        Root<GearBoxEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<GearBoxEntity> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        return query.getResultList().stream().findFirst();
    }

}
