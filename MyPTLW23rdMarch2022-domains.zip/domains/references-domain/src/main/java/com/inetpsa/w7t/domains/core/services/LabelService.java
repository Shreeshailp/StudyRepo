/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.services;

import java.util.UUID;

import org.seedstack.business.Service;

/**
 * The Interface LabelService. This service is used to retrieve internationalized labels by providing a key.
 */
@Service
@FunctionalInterface
public interface LabelService {

    /**
     * Fetch the corresponding label for the provided key.
     *
     * @param key the key
     * @return the internationalized label, or null if not found
     */
    String value(UUID key);

}
