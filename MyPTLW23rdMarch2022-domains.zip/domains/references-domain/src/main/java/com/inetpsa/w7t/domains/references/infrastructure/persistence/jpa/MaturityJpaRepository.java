/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.stat.SessionStatistics;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.maturity.model.Maturity;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * The Class MaturityJpaRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MaturityJpaRepository extends BaseJpaRepository<Maturity, UUID> implements MaturityRepository {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(MaturityJpaRepository.class);

    /** The maturity repo. */
    @Inject
    @Jpa
    private Repository<Maturity, UUID> maturityRepo;

    /** The maturity factory. */
    @Inject
    private Factory<Maturity> maturityFactory;

    /** The date time formatter. */
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant FAMILY. */
    private static final String FAMILY = "family";

    /** The Constant BODY. */
    private static final String BODY = "body";

    /** The Constant MOTOR. */
    private static final String MOTOR = "motor";

    /** The Constant GEARBOX. */
    private static final String GEARBOX = "gearbox";

    /** The Constant INDEX. */
    private static final String INDEX = "index";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository#exists(java.lang.String, java.lang.String,
     *      java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public boolean exists(String family, String body, String motor, String gearbox, String index) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<Maturity> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(FAMILY), cb.parameter(String.class, FAMILY)), cb.equal(root.get(BODY), cb.parameter(String.class, BODY)),
                cb.equal(root.get(MOTOR), cb.parameter(String.class, MOTOR)), cb.equal(root.get(GEARBOX), cb.parameter(String.class, GEARBOX)),
                cb.equal(root.get(INDEX), cb.parameter(String.class, INDEX)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(FAMILY, family);
        query.setParameter(BODY, body);
        query.setParameter(MOTOR, motor);
        query.setParameter(GEARBOX, gearbox);
        query.setParameter(INDEX, index);

        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository#maturityByUniqueFields(java.lang.String,
     *      java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public List<Maturity> maturityByUniqueFields(String family, String body, String motor, String gearbox, String index) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Maturity> q = cb.createQuery(Maturity.class);
        Root<Maturity> root = q.from(Maturity.class);
        q.where(cb.equal(root.get(FAMILY), cb.parameter(String.class, FAMILY)), cb.equal(root.get(BODY), cb.parameter(String.class, BODY)),
                cb.equal(root.get(MOTOR), cb.parameter(String.class, MOTOR)), cb.equal(root.get(GEARBOX), cb.parameter(String.class, GEARBOX)),
                cb.equal(root.get(INDEX), cb.parameter(String.class, INDEX)));

        TypedQuery<Maturity> query = entityManager.createQuery(q);
        query.setParameter(FAMILY, family);
        query.setParameter(BODY, body);
        query.setParameter(MOTOR, motor);
        query.setParameter(GEARBOX, gearbox);
        query.setParameter(INDEX, index);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository#getAllMaturities()
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Maturity> getAllMaturities() {
        Query query = entityManager.createNativeQuery("select * from W7TQTPAT", Maturity.class);
        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository#getMatchedPatterns(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Maturity> getMatchedPatterns(String pattern) {
        Query query = entityManager.createNativeQuery("select pat.STATUS from W7TQTPAT pat where pat.PATTERN = ?");
        query.setParameter(1, pattern);
        List<Object> status = query.getResultList();
        List<Maturity> maturityList = new ArrayList<>();
        for (Object obj : status) {
            Maturity mat = new Maturity();
            mat.setStatus(obj.toString());
            maturityList.add(mat);
        }
        return maturityList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository#insertIntoPatternTable(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public void insertIntoPatternTable(String version16, String maturityStatus, String client) {
        String patternToMatchs = "";
        if (version16 != null && !version16.isEmpty()) {
            Maturity maturity = maturityFactory.create();
            patternToMatchs = version16.substring(0, 6) + "*" + version16.substring(7, 10) + "****" + version16.substring(14, 16);
            maturity.setPattern(patternToMatchs);
            maturity.setFamily(version16.substring(0, 4));
            maturity.setBody(version16.substring(4, 6));
            maturity.setMotor(version16.substring(7, 9));
            maturity.setGearbox(version16.substring(9, 10));
            maturity.setIndex(version16.substring(14, 16));
            maturity.setStatus(maturityStatus);
            maturity.setCreatedBy(client);
            maturity.setCreatedOn(getTodayDateAsString());

            maturityRepo.persist(maturity);
        }
    }

    /**
     * Gets the today date as string.
     *
     * @return the today date as string
     */
    private static String getTodayDateAsString() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    @Override
    public void clearSession() {
        Session session = entityManager.unwrap(Session.class);

        if (session != null) {
            SessionStatistics statistics = session.getStatistics();
            logger.info("Collection Count [{}]", statistics.getCollectionCount());
            logger.info("Entity Count [{}]", statistics.getEntityCount());
            session.clear(); // internal cache clear
        }

    }
}
