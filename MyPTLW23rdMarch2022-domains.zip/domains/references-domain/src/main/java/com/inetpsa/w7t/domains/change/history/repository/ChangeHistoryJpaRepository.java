/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.domains.change.history.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryEntity;

public class ChangeHistoryJpaRepository extends BaseJpaRepository<ChangeHistoryEntity, UUID> implements ChangeHistoryRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.change.history.repository.ChangeHistoryRepository#all()
     */
    @Override
    public List<ChangeHistoryEntity> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ChangeHistoryEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));
        TypedQuery<ChangeHistoryEntity> q = entityManager.createQuery(criteriaQuery);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.change.history.repository.ChangeHistoryRepository#getExistingChangeHistoryEntity(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<ChangeHistoryEntity> getExistingChangeHistoryEntity(String dataId) {
        Query query = entityManager.createNativeQuery("SELECT * FROM W7TQTCHG WHERE DATA_ID = ? ORDER BY TIME_STAMP desc", ChangeHistoryEntity.class);
        query.setParameter(1, dataId);
        return query.getResultList().stream().findFirst();
    }

}
