/*
 * Creation : 4 Sep 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.model.ClientMaturity;

/**
 * The Class ClientMaturityJpaRepository.
 */
public class ClientMaturityJpaRepository extends BaseJpaRepository<ClientMaturity, UUID> implements ClientMaturityRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository#all()
     */
    @Override
    public List<ClientMaturity> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ClientMaturity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<ClientMaturity> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository#exists(java.lang.String, java.lang.String)
     */
    @Override
    public boolean exists(String client, String status) {

        Query query = entityManager.createNativeQuery("select * from W7TQTCMT where CLIENT = ? AND MATURITY = ?", ClientMaturity.class);
        query.setParameter(1, client);
        query.setParameter(2, status);
        return query.getResultList().stream().findFirst().isPresent();
    }

}
