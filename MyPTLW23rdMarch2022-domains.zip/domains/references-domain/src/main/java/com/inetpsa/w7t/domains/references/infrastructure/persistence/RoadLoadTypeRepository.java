/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.RoadLoadType;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;


/**
 * The Interface RoadLoadTypeRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface RoadLoadTypeRepository extends GenericRepository<RoadLoadType, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<RoadLoadType> all();

    /**
     * Byroad load type.
     *
     * @param roadLoadType the road load type
     * @return the optional
     */
    @Read
    Optional<RoadLoadType> byroadLoadType(@VehicleRoadLoadType String roadLoadType);

    /**
     * Exists.
     *
     * @param code the code
     * @return true, if successful
     */
    @Read
    boolean exists(@VehicleRoadLoadType String code);
}
