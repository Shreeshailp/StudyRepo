/*
 * Creation : 11 Sep 2019
 */
package com.inetpsa.w7t.domains.user.model;

public class UserDto {

    private boolean status;

    /**
     * Getter status.
     *
     * @return the status
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * Setter status
     * 
     * @param status the status to set
     */
    public void setStatus(boolean status) {
        this.status = status;
    }
}
