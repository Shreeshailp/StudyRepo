package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.FsFlagFileEntity;

/**
 * The Interface FsFlagFileRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface FsFlagFileRepository extends GenericRepository<FsFlagFileEntity, String> {

    /**
     * Save entity.
     *
     * @param fsFlagFileEntity the fs flag file
     */
    void saveEntity(FsFlagFileEntity fsFlagFileEntity);

    /**
     * Gets the fs flag file name by file id.
     *
     * @param fileId the file id
     * @return the fs flag file name by file id
     */
    String getFsFlagFileNameByFileId(String fileId);

    /**
     * Delete fs flag file by file id.
     *
     * @param fileId the file id
     * @return the int
     */
    int deleteFsFlagFileByFileId(String fileId);

    /**
     * Checks if is file id exist.
     *
     * @param fileId the file id
     * @return true, if is file id exist
     */
    boolean isFileIdExist(String fileId);

}
