/*
 * Creation : 20 sept. 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.Parameter;

/**
 * The Interface ParameterRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ParameterRepository extends GenericRepository<Parameter, String> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<Parameter> all();

    /**
     * By id.
     *
     * @param id the id
     * @return the optional
     */
    @Read
    Optional<Parameter> byId(String id);

}
