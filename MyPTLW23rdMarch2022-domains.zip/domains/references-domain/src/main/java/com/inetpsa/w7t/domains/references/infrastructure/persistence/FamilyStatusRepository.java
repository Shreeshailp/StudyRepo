/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.FamilyStatus;

/**
 * The Interface FamilyStatusRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyStatusRepository extends GenericRepository<FamilyStatus, UUID> {
    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<FamilyStatus> getAllFamilyStatus();

    /**
     * Exists.
     *
     * @param status the status
     * @return true, if successful
     */
    @Read
    boolean exists(String status);

    /**
     * Gets the family status.
     *
     * @param status the status
     * @return the family status
     */
    public Optional<FamilyStatus> getFamilyStatus(String status);
}
