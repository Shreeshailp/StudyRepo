package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class EnergyEfficiency.
 */
@Entity
@Table(name = "W7TQTCEE")
public class EnergyEfficiency extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The crr. */
    @Column(name = "CRR")
    private Double crr;

    /** The ee class. */
    @Column(name = "EECLASS")
    private String eeClass;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the crr value.
     *
     * @return the crr value
     */
    public Double getCrrValue() {
        return crr;
    }

    /**
     * Sets the crr value.
     *
     * @param crr the new crr value
     */
    public void setCrrValue(Double crr) {
        this.crr = crr;
    }

    /**
     * Gets the ee class.
     *
     * @return the ee class
     */
    public String getEeClass() {
        return eeClass;
    }

    /**
     * Sets the ee class.
     *
     * @param eeClass the new ee class
     */
    public void setEeClass(String eeClass) {
        this.eeClass = eeClass;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((crr == null) ? 0 : crr.hashCode());
        result = prime * result + ((eeClass == null) ? 0 : eeClass.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        EnergyEfficiency other = (EnergyEfficiency) obj;
        if (crr == null) {
            if (other.crr != null)
                return false;
        } else if (!crr.equals(other.crr))
            return false;
        if (eeClass == null) {
            if (other.eeClass != null)
                return false;
        } else if (!eeClass.equals(other.eeClass))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        return true;
    }

}
