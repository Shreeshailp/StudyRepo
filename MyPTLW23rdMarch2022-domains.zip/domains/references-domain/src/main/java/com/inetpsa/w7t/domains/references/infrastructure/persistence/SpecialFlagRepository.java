/*
 * Creation : 12 Jul 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.SpecialFlag;


/**
 * The Interface SpecialFlagRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface SpecialFlagRepository extends GenericRepository<SpecialFlag, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<SpecialFlag> all();

    /**
     * Exists.
     *
     * @param codeSpecial the code special
     * @return true, if successful
     */
    @Read
    boolean exists(String codeSpecial);
}
