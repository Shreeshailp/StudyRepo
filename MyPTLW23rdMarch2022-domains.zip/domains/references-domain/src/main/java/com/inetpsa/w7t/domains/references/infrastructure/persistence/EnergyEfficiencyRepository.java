
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.EnergyEfficiency;

/**
 * The Interface EnergyEfficiencyRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface EnergyEfficiencyRepository extends GenericRepository<EnergyEfficiency, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<EnergyEfficiency> all();

    /**
     * Gets the energy class by value.
     *
     * @param value the value
     * @return the energy class by value
     */
    @Read
    String getEnergyClassByValue(Double value);

}
