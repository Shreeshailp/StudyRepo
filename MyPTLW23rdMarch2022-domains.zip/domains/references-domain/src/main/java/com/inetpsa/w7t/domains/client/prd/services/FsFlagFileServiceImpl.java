package com.inetpsa.w7t.domains.client.prd.services;

import java.util.UUID;

import javax.inject.Inject;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.FsFlagFileRepository;
import com.inetpsa.w7t.domains.references.model.FsFlagFileEntity;

/**
 * The Class FsFlagFileServiceImpl.
 */
public class FsFlagFileServiceImpl implements FsFlagFileService {

    /** The fs flag file repository. */
    @Inject
    FsFlagFileRepository fsFlagFileRepository;

    /**
     * Save fs flag entity.
     *
     * @param client         the client
     * @param fsFlagFileName the fs flag file name
     * @param fileId         the file id
     */
    @Override
    public void saveFsFlagEntity(String client, String fsFlagFileName, String fileId) {
        FsFlagFileEntity fsFlagFileEntity = new FsFlagFileEntity();
        fsFlagFileEntity.setGuid(UUID.randomUUID());
        fsFlagFileEntity.setFileId(fileId);
        fsFlagFileEntity.setClient(client);
        fsFlagFileEntity.setFsFlagFileName(fsFlagFileName);
        fsFlagFileRepository.saveEntity(fsFlagFileEntity);

    }

    /**
     * Gets the fs flag file name by file id.
     *
     * @param fileId the file id
     * @return the fs flag file name by file id
     */
    @Override
    public String getFsFlagFileNameByFileId(String fileId) {
        return fsFlagFileRepository.getFsFlagFileNameByFileId(fileId);
    }

    /**
     * Delete fs flag file by file id.
     *
     * @param fileId the file id
     * @return the int
     */
    @Override
    public int deleteFsFlagFileByFileId(String fileId) {
        return fsFlagFileRepository.deleteFsFlagFileByFileId(fileId);
    }

    /**
     * Checks if is file id exist.
     *
     * @param fileId the file id
     * @return true, if is file id exist
     */
    @Override
    public boolean isFileIdExist(String fileId) {
        return fsFlagFileRepository.isFileIdExist(fileId);
    }

}
