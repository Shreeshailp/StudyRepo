/*
 * Creation : 16 Mar 2021
 */
package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class WltpHubParameterEntity.
 */
@Entity
@Table(name = "W7TQTWPT")
public class WltpHubParameterEntity extends BaseAggregateRoot<UUID> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1463803835051506205L;

    /** The Id. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID Id;

    /** The client. */
    @Column(name = "CLIENT")
    private String client;

    /** The code. */
    @Column(name = "CODE")
    private String code;

    /**
     * Instantiates a new wltp hub parameter entity.
     */
    public WltpHubParameterEntity() {
        // Empty Constructor
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.Id;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public UUID getId() {
        return Id;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(UUID id) {
        Id = id;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((Id == null) ? 0 : Id.hashCode());
        result = prime * result + ((client == null) ? 0 : client.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        WltpHubParameterEntity other = (WltpHubParameterEntity) obj;
        if (Id == null) {
            if (other.Id != null)
                return false;
        } else if (!Id.equals(other.Id))
            return false;
        if (client == null) {
            if (other.client != null)
                return false;
        } else if (!client.equals(other.client))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        return true;
    }

}
