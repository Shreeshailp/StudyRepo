/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.domains.change.history.services;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryDto;
import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryEntity;
import com.inetpsa.w7t.domains.change.history.repository.ChangeHistoryRepository;

/**
 * The Class ChangeHistoryServiceImpl.
 */
public class ChangeHistoryServiceImpl implements ChangeHistoryService {

    /** The Constant CHANGE_HISTORY_LOG. */
    private static final String CHANGE_HISTORY_LOG = "The change history entity saved is : {}";

    /** The Constant NULL. */
    private static final String NULL = "null";

    /** The change history repository. */
    @Inject
    private ChangeHistoryRepository changeHistoryRepository;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(ChangeHistoryServiceImpl.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.change.history.services.ChangeHistoryService#getDeclaredFieldsOfAnObject(java.lang.Class)
     */
    @SuppressWarnings("rawtypes")
    @Override
    public List<String> getDeclaredFieldsOfAnObject(Class clazz) {
        List<String> propertyNameList = new ArrayList<>();
        for (Field field : clazz.getDeclaredFields()) {

            propertyNameList.add(field.getName());
        }
        return propertyNameList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.change.history.services.ChangeHistoryService#saveChangeHistoryEntity(com.inetpsa.w7t.domains.change.history.model.ChangeHistoryDto,
     *      java.lang.Object, java.util.List)
     */
    @Override
    public <T> void saveChangeHistoryEntity(ChangeHistoryDto changeHistoryDto, T t, List<String> propertyNameList) {
        for (String propertyName : propertyNameList) {
            try {
                Object obj = PropertyUtils.getProperty(t, propertyName);
                if (changeHistoryDto != null) {
                    ChangeHistoryEntity changeHistoryEntity = new ChangeHistoryEntity();
                    changeHistoryEntity.setGuid(UUID.randomUUID());
                    changeHistoryEntity.setDataCategory(changeHistoryDto.getDataCategory());
                    changeHistoryEntity.setDataId(changeHistoryDto.getDataId() + "-" + propertyName.toUpperCase());
                    changeHistoryEntity.setTimeStamp(getCurrentDateInStringFormat());
                    changeHistoryEntity.setUser(changeHistoryDto.getUser());
                    Optional<ChangeHistoryEntity> optChangeHistoryEntity = changeHistoryRepository
                            .getExistingChangeHistoryEntity(changeHistoryEntity.getDataId());
                    if (optChangeHistoryEntity.isPresent()) {
                        saveIfAlreadyExist(changeHistoryDto, obj, changeHistoryEntity, optChangeHistoryEntity);
                    } else if (changeHistoryDto.getNewValue() != null && !changeHistoryDto.getNewValue().equalsIgnoreCase(NULL)) {
                        changeHistoryEntity.setNewValue(changeHistoryDto.getNewValue());
                        saveIntoHistoryTable(changeHistoryEntity);
                    } else if (obj != null && !obj.toString().equalsIgnoreCase(NULL)) {
                        changeHistoryEntity.setNewValue(String.valueOf(obj));
                        saveIntoHistoryTable(changeHistoryEntity);
                    }
                }
            } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                logger.error("Error {}", e);
            }

        }

    }

    /**
     * Save if already exist.
     *
     * @param changeHistoryDto the change history dto
     * @param obj the obj
     * @param changeHistoryEntity the change history entity
     * @param optChangeHistoryEntity the opt change history entity
     */
    private void saveIfAlreadyExist(ChangeHistoryDto changeHistoryDto, Object obj, ChangeHistoryEntity changeHistoryEntity,
            Optional<ChangeHistoryEntity> optChangeHistoryEntity) {
        if (optChangeHistoryEntity.isPresent()) {
            if (optChangeHistoryEntity.get().getNewValue() != null
                    && !optChangeHistoryEntity.get().getNewValue().equalsIgnoreCase(String.valueOf(obj))) {
                changeHistoryEntity.setOldValue(optChangeHistoryEntity.get().getNewValue());

                if (changeHistoryDto.getNewValue() != null && !changeHistoryDto.getNewValue().equalsIgnoreCase(NULL)) {
                    changeHistoryEntity.setNewValue(changeHistoryDto.getNewValue());
                    saveIntoHistoryTable(changeHistoryEntity);
                } else if (obj != null && !obj.toString().equalsIgnoreCase(NULL)) {
                    changeHistoryEntity.setNewValue(String.valueOf(obj));
                    saveIntoHistoryTable(changeHistoryEntity);
                }
            } else if (obj != null && !obj.toString().equalsIgnoreCase(NULL)) {
                changeHistoryEntity.setNewValue(String.valueOf(obj));
                saveIntoHistoryTable(changeHistoryEntity);
            }
        }
    }

    /**
     * Save into history table.
     *
     * @param changeHistoryEntity the change history entity
     */
    private void saveIntoHistoryTable(ChangeHistoryEntity changeHistoryEntity) {
        logger.info(CHANGE_HISTORY_LOG, changeHistoryEntity);
        changeHistoryRepository.persist(changeHistoryEntity);
    }

    /**
     * Gets the current date in string format.
     *
     * @return the current date in string format
     */
    private String getCurrentDateInStringFormat() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.change.history.services.ChangeHistoryService#saveListOfChangeHistoryEntities(java.util.List)
     */
    @Override
    public void saveListOfChangeHistoryEntities(List<ChangeHistoryDto> dtoList) {

        for (ChangeHistoryDto changeHistoryDto : dtoList) {
            ChangeHistoryEntity changeHistoryEntity = new ChangeHistoryEntity();
            changeHistoryEntity.setGuid(UUID.randomUUID());
            changeHistoryEntity.setDataCategory(changeHistoryDto.getDataCategory());
            changeHistoryEntity.setDataId(changeHistoryDto.getDataId());
            changeHistoryEntity.setTimeStamp(getCurrentDateInStringFormat());
            changeHistoryEntity.setUser(changeHistoryDto.getUser());
            Optional<ChangeHistoryEntity> optChangeHistoryEntity = changeHistoryRepository
                    .getExistingChangeHistoryEntity(changeHistoryDto.getDataId());
            if (optChangeHistoryEntity.isPresent()) {
                if (!optChangeHistoryEntity.get().getNewValue().equalsIgnoreCase(changeHistoryDto.getNewValue())) {
                    changeHistoryEntity.setOldValue(optChangeHistoryEntity.get().getNewValue());
                    changeHistoryEntity.setNewValue(changeHistoryDto.getNewValue());
                    saveIntoHistoryTable(changeHistoryEntity);
                }

            } else if (changeHistoryDto.getNewValue() != null && !changeHistoryDto.getNewValue().equalsIgnoreCase(NULL)) {
                changeHistoryEntity.setNewValue(changeHistoryDto.getNewValue());
                saveIntoHistoryTable(changeHistoryEntity);
            }
        }

    }
}
