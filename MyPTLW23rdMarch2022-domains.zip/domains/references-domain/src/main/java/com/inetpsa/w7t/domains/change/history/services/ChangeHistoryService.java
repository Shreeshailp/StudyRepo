/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.domains.change.history.services;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryDto;

/**
 * The Interface ChangeHistoryService.
 */
@Service
public interface ChangeHistoryService {

    /**
     * Gets the declared fields of an object.
     *
     * @param clazz the clazz
     * @return the declared fields of an object
     */
    @SuppressWarnings("rawtypes")
    List<String> getDeclaredFieldsOfAnObject(Class clazz);

    /**
     * Save change history entity.
     *
     * @param <T> the generic type
     * @param changeHistoryDto the change history dto
     * @param t the t
     * @param propertyNameList the property name list
     */
    <T> void saveChangeHistoryEntity(ChangeHistoryDto changeHistoryDto, T t, List<String> propertyNameList);

    /**
     * Save list of change history entities.
     *
     * @param dtoList the dto list
     */
    void saveListOfChangeHistoryEntities(List<ChangeHistoryDto> dtoList);
}
