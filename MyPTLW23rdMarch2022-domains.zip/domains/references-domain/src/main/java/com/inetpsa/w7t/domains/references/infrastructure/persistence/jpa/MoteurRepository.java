/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.MoteurEntity;

// TODO: Auto-generated Javadoc
/**
 * The Interface MoteurRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface MoteurRepository extends GenericRepository<MoteurEntity, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<MoteurEntity> all();

    /**
     * By moteur code.
     *
     * @param code the code
     * @return the optional
     */
    Optional<MoteurEntity> byMoteurCode(String code);

}
