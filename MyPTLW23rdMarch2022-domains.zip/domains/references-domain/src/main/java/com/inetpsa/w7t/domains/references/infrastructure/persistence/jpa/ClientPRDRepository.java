/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.ClientPRDEntity;

/**
 * The Interface ClientPRDRepository.
 */
/**
 * @author E539596
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ClientPRDRepository extends GenericRepository<ClientPRDEntity, UUID> {

    /**
     * Gets the client by PRD.
     *
     * @param prd the prd
     * @return the client by PRD
     */
    public String getClientByPRD(String prd);
}
