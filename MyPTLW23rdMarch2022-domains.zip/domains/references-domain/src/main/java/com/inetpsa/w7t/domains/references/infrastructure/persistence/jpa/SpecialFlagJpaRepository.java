/*
 * Creation : 12 Jul 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.SpecialFlagRepository;
import com.inetpsa.w7t.domains.references.model.SpecialFlag;

public class SpecialFlagJpaRepository extends BaseJpaRepository<SpecialFlag, UUID> implements SpecialFlagRepository {

    /** The Constant CODE. */
    private static final String CODE_SPECIAL = "codeSpecial";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    @Override
    public List<SpecialFlag> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<SpecialFlag> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<SpecialFlag> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    @Override
    public boolean exists(String codeSpecial) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<SpecialFlag> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE_SPECIAL), cb.parameter(String.class, CODE_SPECIAL)));
        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE_SPECIAL, codeSpecial);
        return query.getResultList().stream().findFirst().isPresent();
    }

}
