/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.moteur.gearbox.services;

import java.util.Optional;
import java.util.UUID;

import javax.inject.Inject;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.GearBoxRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.MoteurRepository;
import com.inetpsa.w7t.domains.references.model.GearBoxEntity;
import com.inetpsa.w7t.domains.references.model.MoteurEntity;
import com.inetpsa.w7t.domains.references.model.MoteurGearBoxDto;

/**
 * The Class MoteurGearBoxServiceImpl.
 */
public class MoteurGearBoxServiceImpl implements MoteurGearBoxService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The moteur repository. */
    @Inject
    private MoteurRepository moteurRepository;

    /** The gear box repository. */
    @Inject
    private GearBoxRepository gearBoxRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.moteur.gearbox.services.MoteurGearBoxService#saveMoteurEntity(com.inetpsa.w7t.domains.references.model.MoteurGearBoxDto)
     */
    @Override
    public void saveMoteurEntity(MoteurGearBoxDto moteurGearBoxDto) {
        try {
            MoteurEntity moteurEntity = new MoteurEntity();
            moteurEntity.setGuid(UUID.randomUUID());
            moteurEntity.setCode(moteurGearBoxDto.getCode());
            moteurEntity.setDesignation(moteurGearBoxDto.getDesignation());
            moteurEntity.setCharacteristic(moteurGearBoxDto.getCharacteristic());
            Optional<MoteurEntity> optional = Optional.empty();
            if (moteurGearBoxDto.getCode() != null) {
                optional = byMoteurCode(moteurGearBoxDto.getCode());
            }
            if (optional.isPresent()) {
                MoteurEntity moteurDbEntity = optional.get();
                moteurDbEntity.setCode(moteurGearBoxDto.getCode());
                moteurDbEntity.setDesignation(moteurGearBoxDto.getDesignation());
                moteurDbEntity.setCharacteristic(moteurGearBoxDto.getCharacteristic());
                moteurRepository.save(moteurDbEntity);
                logger.info("The moteur code[{}] and designation[{}] has been updated sucessfully.", moteurGearBoxDto.getCode(),
                        moteurGearBoxDto.getDesignation());
            } else {
                moteurRepository.save(moteurEntity);
                logger.info("The moteur code[{}] and designation[{}] has been created in the database.", moteurGearBoxDto.getCode(),
                        moteurGearBoxDto.getDesignation());
            }
        } catch (Exception e) {
            logger.error("error {}", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.moteur.gearbox.services.MoteurGearBoxService#saveGearBoxEntity(com.inetpsa.w7t.domains.references.model.MoteurGearBoxDto)
     */
    @Override
    public void saveGearBoxEntity(MoteurGearBoxDto moteurGearBoxDto) {
        try {
            GearBoxEntity gearBoxEntity = new GearBoxEntity();
            gearBoxEntity.setGuid(UUID.randomUUID());
            gearBoxEntity.setCode(moteurGearBoxDto.getCode());
            gearBoxEntity.setDesignation(moteurGearBoxDto.getDesignation());
            gearBoxEntity.setCharacteristic(moteurGearBoxDto.getCharacteristic());
            Optional<GearBoxEntity> optional = Optional.empty();
            if (moteurGearBoxDto.getCode() != null) {
                optional = byGearBoxCode(moteurGearBoxDto.getCode());
            }
            if (optional.isPresent()) {
                GearBoxEntity gearBoxDbEntity = optional.get();
                gearBoxDbEntity.setCode(moteurGearBoxDto.getCode());
                gearBoxDbEntity.setDesignation(moteurGearBoxDto.getDesignation());
                gearBoxDbEntity.setCharacteristic(moteurGearBoxDto.getCharacteristic());
                gearBoxRepository.save(gearBoxDbEntity);
                logger.info("The gearbox code[{}] and designation[{}] has been updated sucessfully.", moteurGearBoxDto.getCode(),
                        moteurGearBoxDto.getDesignation());
            } else {
                gearBoxRepository.save(gearBoxEntity);
                logger.info("The gearbox code[{}] and designation[{}] has been created in the database.", moteurGearBoxDto.getCode(),
                        moteurGearBoxDto.getDesignation());
            }

        } catch (Exception e) {
            logger.error("error {}", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.moteur.gearbox.services.MoteurGearBoxService#byMoteurCode(java.lang.String)
     */
    @Override
    public Optional<MoteurEntity> byMoteurCode(String code) {
        return moteurRepository.byMoteurCode(code);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.moteur.gearbox.services.MoteurGearBoxService#byGearBoxCode(java.lang.String)
     */
    @Override
    public Optional<GearBoxEntity> byGearBoxCode(String code) {
        return gearBoxRepository.byGearBoxCode(code);
    }

}
