/*
 * Creation : 18 Jun 2019
 */
package com.inetpsa.w7t.domains.references.cache;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.jcs.JCS;
import org.apache.commons.jcs.access.CacheAccess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class WltpCacheManager.
 *
 * @param <T> the generic type
 */
public class WltpCacheManager<T> {

    /** The cache. */
    private static CacheAccess<Object, Object> cache = null;

    /** The Constant CACHE_REGION_NAME. */
    private static final String CACHE_REGION_NAME = "wltpCache";

    /** The instance map. */
    private static Map<Class<?>, Object> instanceMap = null;

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(WltpCacheManager.class);

    /**
     * Gets the single instance of WltpCacheManager.
     *
     * @param <T> the generic type
     * @param classObj the class obj
     * @return single instance of WltpCacheManager
     */
    @SuppressWarnings("unchecked")
    public static <T> WltpCacheManager<T> getInstance(final Class<T> classObj) {
        T instance = null;
        try {

            synchronized (WltpCacheManager.class) {
                if (instanceMap == null) {
                    instanceMap = new ConcurrentHashMap<>();
                    WltpCacheManager.cache = JCS.getInstance(CACHE_REGION_NAME);
                    instance = (T) new WltpCacheManager<T>();
                    instanceMap.put(classObj, instance);
                    return (WltpCacheManager<T>) instance;
                }

            }
            instance = (T) instanceMap.get(classObj);
            if (instance != null) {
                return (WltpCacheManager<T>) instance;
            }
            instance = (T) new WltpCacheManager<T>();
            instanceMap.put(classObj, instance);

        } catch (final Exception e) {
            logger.error("Error in wltp cache manager : {}", e);

        }
        return (WltpCacheManager<T>) instance;
    }

    /**
     * Instantiates a new wltp cache manager.
     */
    private WltpCacheManager() {
    }

    /**
     * Gets the item.
     *
     * @param key the key
     * @return the item
     */
    @SuppressWarnings("unchecked")
    public T getItem(final String key) {
        return (T) WltpCacheManager.cache.get(key);

    }

    /**
     * Put item.
     *
     * @param key the key
     * @param obj the obj
     * @return true, if successful
     */
    public boolean putItem(final String key, final T obj) {
        WltpCacheManager.cache.put(key, obj);
        return true;
    }

    /**
     * Put optinal item.
     *
     * @param key the key
     * @param obj the obj
     * @return true, if successful
     */
    public boolean putOptinalItem(final String key, final Optional<T> obj) {
        WltpCacheManager.cache.put(key, obj);
        return true;
    }

    /**
     * Gets the optinal item.
     *
     * @param key the key
     * @return the optinal item
     */
    @SuppressWarnings("unchecked")
    public Optional<T> getOptinalItem(final String key) {
        return (Optional<T>) WltpCacheManager.cache.get(key);

    }

    /**
     * Put list item.
     *
     * @param key the key
     * @param obj the obj
     * @return true, if successful
     */
    public boolean putListItem(final String key, final List<T> obj) {
        WltpCacheManager.cache.put(key, obj);
        return true;
    }

    /**
     * Gets the list item.
     *
     * @param key the key
     * @return the list item
     */
    @SuppressWarnings("unchecked")
    public List<T> getListItem(final String key) {
        return (List<T>) WltpCacheManager.cache.get(key);

    }

    /**
     * Removes the item.
     *
     * @param key the key
     */
    public void removeItem(final String key) {
        cache.remove(key);
    }

}
