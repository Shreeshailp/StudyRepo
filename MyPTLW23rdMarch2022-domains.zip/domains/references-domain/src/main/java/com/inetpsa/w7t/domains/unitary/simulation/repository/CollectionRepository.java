/*
 * Creation : 18 Aug 2020
 */
package com.inetpsa.w7t.domains.unitary.simulation.repository;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CollectionEntity;

/**
 * The Interface CollectionRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CollectionRepository extends GenericRepository<CollectionEntity, UUID> {

    /**
     * Gets the all collections.
     *
     * @param userId the user id
     * @param type   the type
     * @return the all collections
     */
    @Read
    List<CollectionEntity> getAllCollections(String userId, String type);
}
