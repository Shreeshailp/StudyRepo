/*
 * Creation : 17 Feb 2021
 */
package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class AvoidCache.
 */
@Entity
@Table(name = "W7TQTCAC")
public class AvoidCache extends BaseAggregateRoot<UUID> {
    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The client. */
    @Column(name = "CLIENT")
    private String client;

    /** The adc value. */
    @Column(name = "AVOIDCACHE")
    private Boolean adcValue;

    /**
     * Getter guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid.
     *
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Setter client.
     *
     * @param client the client to set
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Getter adcValue.
     *
     * @return the adcValue
     */
    public Boolean getAdcValue() {
        return adcValue;
    }

    /**
     * Setter adcValue.
     *
     * @param adcValue the adcValue to set
     */
    public void setAdcValue(Boolean adcValue) {
        this.adcValue = adcValue;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((adcValue == null) ? 0 : adcValue.hashCode());
        result = prime * result + ((client == null) ? 0 : client.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        AvoidCache other = (AvoidCache) obj;
        if (adcValue == null) {
            if (other.adcValue != null)
                return false;
        } else if (!adcValue.equals(other.adcValue))
            return false;
        if (client == null) {
            if (other.client != null)
                return false;
        } else if (!client.equals(other.client))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AvoidCache [guid=" + guid + ", client=" + client + ", adcValue=" + adcValue + "]";
    }

}
