/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.VehicleType;
import com.inetpsa.w7t.domains.references.validation.VehicleTypeCode;

/**
 * The Interface VehicleTypeRepository. This repository is used to retrieve and save any {@link VehicleType} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface VehicleTypeRepository extends GenericRepository<VehicleType, UUID> {
    /**
     * Read all VehicleType from the database.
     *
     * @return the list of VehicleType read.
     */
    @Read
    List<VehicleType> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the VehicleType entity retrieved
     */
    @Read
    Optional<VehicleType> byCode(@VehicleTypeCode String code);

    /**
     * Read the aggregate identified by the specified code and return its UUID.
     *
     * @param code the code
     * @return the optional
     */
    @Read
    Optional<UUID> guidByCode(@VehicleTypeCode String code);

    /**
     * Check that the VehicleType identified by the specified code exists.
     *
     * @param code the @VehicleTypeCode code
     * @return true if the @VehicleTypeCode exists, false otherwise.
     */
    @Read
    boolean exists(@VehicleTypeCode String code);
}
