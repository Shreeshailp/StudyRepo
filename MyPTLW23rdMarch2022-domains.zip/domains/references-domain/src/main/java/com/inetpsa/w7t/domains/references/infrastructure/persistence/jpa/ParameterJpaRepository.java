/*
 * Creation : 20 sept. 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository;
import com.inetpsa.w7t.domains.references.model.Parameter;

/**
 * The Class ParameterJpaRepository.
 */
public class ParameterJpaRepository extends BaseJpaRepository<Parameter, String> implements ParameterRepository {

    /** The Constant CODE. */
    private static final String ID = "id";// ID

    private static ConcurrentHashMap<String, List<Parameter>> prmMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository#all()
     */
    @Override
    public List<Parameter> all() {
        // WltpCacheManager<Parameter> wltpCacheManager = WltpCacheManager.getInstance(Parameter.class);
        String key = "PRM";
        // List<Parameter> list = wltpCacheManager.getListItem(key);
        List<Parameter> list = prmMap.get(key);

        if (list != null && !list.isEmpty()) {
            return list;
        }
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Parameter> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));
        TypedQuery<Parameter> q = entityManager.createQuery(criteriaQuery);
        list = q.getResultList();

        if (list != null && !list.isEmpty()) {
            prmMap.put(key, list);
        }
        return list;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ParameterRepository#byId(java.lang.String)
     */
    @Override
    public Optional<Parameter> byId(String id) {// byId
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Parameter> q = cb.createQuery(Parameter.class);
        Root<Parameter> root = q.from(Parameter.class);
        q.where(cb.equal(root.get(ID), cb.parameter(String.class, ID)));
        TypedQuery<Parameter> query = entityManager.createQuery(q);

        query.setParameter(ID, id);

        return query.getResultList().stream().findFirst();
    }

}
