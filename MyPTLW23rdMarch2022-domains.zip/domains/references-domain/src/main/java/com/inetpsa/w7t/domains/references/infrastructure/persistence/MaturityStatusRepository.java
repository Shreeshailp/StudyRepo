/*
 * Creation : 21 Aug 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.MaturityStatus;


/**
 * The Interface MaturityStatusRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface MaturityStatusRepository extends GenericRepository<MaturityStatus, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<MaturityStatus> all();

    /**
     * Exists.
     *
     * @param statusCode the status code
     * @return true, if successful
     */
    @Read
    boolean exists(String statusCode);
}
