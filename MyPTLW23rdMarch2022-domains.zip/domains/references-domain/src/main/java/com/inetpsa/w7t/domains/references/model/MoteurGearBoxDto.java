/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.references.model;

public class MoteurGearBoxDto {
    private String code;

    private String designation;

    private String characteristic;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCharacteristic() {
        return characteristic;
    }

    public void setCharacteristic(String characteristic) {
        this.characteristic = characteristic;
    }

}
