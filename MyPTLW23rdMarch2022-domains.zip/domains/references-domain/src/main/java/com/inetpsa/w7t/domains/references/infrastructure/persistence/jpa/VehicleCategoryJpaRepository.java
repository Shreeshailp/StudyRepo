/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository;
import com.inetpsa.w7t.domains.references.model.VehicleCategory;
import com.inetpsa.w7t.domains.references.validation.VehicleCategoryCode;

/**
 * The Class VehicleCategoryJpaRepository. JPA Implementation of {@link VehicleCategoryRepository}.
 */
public class VehicleCategoryJpaRepository extends BaseJpaRepository<VehicleCategory, UUID> implements VehicleCategoryRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository#all()
     */
    @Override
    public List<VehicleCategory> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<VehicleCategory> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<VehicleCategory> byCode(@VehicleCategoryCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> q = cb.createQuery(VehicleCategory.class);
        Root<VehicleCategory> root = q.from(VehicleCategory.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<VehicleCategory> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleCategoryRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(@VehicleCategoryCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleCategory> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<VehicleCategory> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<VehicleCategory> get(CODE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
    }
}
