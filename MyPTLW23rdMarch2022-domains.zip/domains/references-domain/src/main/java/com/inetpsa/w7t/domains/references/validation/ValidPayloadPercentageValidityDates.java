/*
 * Creation : 10 févr. 2017
 */
package com.inetpsa.w7t.domains.references.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.inetpsa.w7t.domains.references.model.PayloadPercentage;
import com.inetpsa.w7t.domains.references.validation.internal.ValidPayloadPercentageValidityDatesValidator;

/**
 * The Interface ValidPayloadPercentageValidityDates. This validation annotation is used validate the {@link PayloadPercentage} {@code validityStart}
 * and {@code validityEnd} against each other.
 * 
 * @see ValidPayloadPercentageValidityDatesValidator
 */
@Target({ ElementType.TYPE })
@Constraint(validatedBy = { ValidPayloadPercentageValidityDatesValidator.class })
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidPayloadPercentageValidityDates {

    /**
     * Message.
     *
     * @return the message
     */
    String message() default "{com.inetpsa.w7t.validation.constraints.ValidPayloadPercentageValidityDates.message}";

    /**
     * Groups.
     *
     * @return the groups
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the payload
     */
    Class<? extends Payload>[] payload() default {};
}
