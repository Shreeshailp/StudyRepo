package com.inetpsa.w7t.domains.client.prd.services;

import org.seedstack.business.Service;

/**
 * The Interface FsFlagFileService.
 */
@Service
public interface FsFlagFileService {

    /**
     * Save fs flag entity.
     *
     * @param client         the client
     * @param fsFlagFileName the fs flag file name
     * @param fileId         the file id
     */
    void saveFsFlagEntity(String client, String fsFlagFileName, String fileId);

    /**
     * Gets the fs flag file name by file id.
     *
     * @param fileId the file id
     * @return the fs flag file name by file id
     */
    String getFsFlagFileNameByFileId(String fileId);

    /**
     * Delete fs flag file by file id.
     *
     * @param fileId the file id
     * @return the int
     */
    int deleteFsFlagFileByFileId(String fileId);

    /**
     * Checks if is file id exist.
     *
     * @param fileId the file id
     * @return true, if is file id exist
     */
    boolean isFileIdExist(String fileId);
}
