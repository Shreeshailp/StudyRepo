/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;

/**
 * The Class MeasureTypeJpaRepository. JPA Implementation of {@link MeasureTypeRepository}.
 */
public class MeasureTypeJpaRepository extends BaseJpaRepository<MeasureType, UUID> implements MeasureTypeRepository {
    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository#all()
     */
    @Override
    public List<MeasureType> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<MeasureType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<MeasureType> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<MeasureType> byCode(@MeasureTypeCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MeasureType> q = cb.createQuery(MeasureType.class);
        Root<MeasureType> root = q.from(MeasureType.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<MeasureType> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(@MeasureTypeCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<MeasureType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<MeasureType> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<MeasureType>get("code"));
        criteriaQuery.where(criteriaBuilder.equal(root.get("code"), criteriaBuilder.parameter(String.class, "code")));

        return entityManager.createQuery(criteriaQuery).setParameter("code", code).getResultList().size() == 1;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository#roundingDigitByCode(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    @CacheResult(cacheName = "mtpRoundingCodeCache")
    public int roundingDigitByCode(@MeasureTypeCode String code) {
        String sqlQuery = "select measuretyp0_.ROUNDINGDIGITS as col_0_0_ from W7TQTMTP measuretyp0_ where measuretyp0_.CODE=:CODE";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter("CODE", code);
        List<Integer> list = q.getResultList();
        if (list.isEmpty())
            return 0;
        return list.get(0);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository#guidByCode(java.lang.String)
     */
    @Override
    public Optional<UUID> guidByCode(String code) {
        // return Optional.ofNullable(cachedGuidByCode(code));

        /**
         * performance change
         */
        return Optional.ofNullable(getCachedGuidByCode(code));
    }

    /**
     * Cached guid by code.
     *
     * @param code the code
     * @return the uuid
     */
    @CacheResult(cacheName = "measureTypeCache")
    public UUID cachedGuidByCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<MeasureType> root = q.from(MeasureType.class);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst().orElse(null);
    }

    /**
     * @param code
     * @return
     */
    @CacheResult(cacheName = "measureTypeCache")
    public UUID getCachedGuidByCode(String code) {
        Query query = entityManager.createNativeQuery("SELECT mt.ID FROM W7TQTMTP mt WHERE mt.CODE = :CODE");
        query.setParameter("CODE", code);
        String singleResult = (String) query.getSingleResult();
        if (singleResult != null)
            return UUID.fromString(singleResult);

        return null;
    }
}
