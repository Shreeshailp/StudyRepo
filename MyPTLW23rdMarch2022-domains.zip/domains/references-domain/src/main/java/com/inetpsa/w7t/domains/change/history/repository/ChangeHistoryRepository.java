/*
 * Creation : 4 Feb 2020
 */
package com.inetpsa.w7t.domains.change.history.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.change.history.model.ChangeHistoryEntity;

/**
 * The Interface ChangeHistoryRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ChangeHistoryRepository extends GenericRepository<ChangeHistoryEntity, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<ChangeHistoryEntity> all();

    /**
     * Gets the existing change history entity.
     *
     * @param dataId the data id
     * @return the existing change history entity
     */
    Optional<ChangeHistoryEntity> getExistingChangeHistoryEntity(String dataId);
}
