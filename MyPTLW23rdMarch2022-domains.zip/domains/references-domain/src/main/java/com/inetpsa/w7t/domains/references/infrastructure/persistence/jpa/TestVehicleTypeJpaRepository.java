/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.references.validation.TestVehicleTypeCode;

/**
 * The Class TestVehicleTypeJpaRepository. JPA Implementation of {@link TestVehicleTypeRepository}.
 */
public class TestVehicleTypeJpaRepository extends BaseJpaRepository<TestVehicleType, UUID> implements TestVehicleTypeRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository#all()
     */
    @Override
    public List<TestVehicleType> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<TestVehicleType> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<TestVehicleType> byCode(@TestVehicleTypeCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> q = cb.createQuery(TestVehicleType.class);
        Root<TestVehicleType> root = q.from(TestVehicleType.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<TestVehicleType> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(@TestVehicleTypeCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<TestVehicleType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<TestVehicleType> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<TestVehicleType>get(CODE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository#guidByCode(java.lang.String)
     */
    @Override
    public Optional<UUID> guidByCode(String code) {
        // return Optional.ofNullable(cachedGuidByCode(code));

        /**
         * performance change
         */
        return Optional.ofNullable(getCachedGuidByCode(code));
    }

    /**
     * Cached guid by code.
     *
     * @param code the code
     * @return the uuid
     */
    @CacheResult(cacheName = "testVehicleTypeCache")
    public UUID cachedGuidByCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<TestVehicleType> root = q.from(TestVehicleType.class);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst().orElse(null);
    }

    /**
     * performance change
     * 
     * @param code
     * @return
     */
    @CacheResult(cacheName = "testVehicleTypeCache")
    public UUID getCachedGuidByCode(String code) {
        logger.info("=======================================================================getCachedGuidByCode for testing");
        Query query = entityManager.createNativeQuery("SELECT tvt.ID FROM W7TQTTVT tvt WHERE tvt.CODE = :CODE");
        query.setParameter("CODE", code);
        String singleResult = (String) query.getSingleResult();
        if (singleResult != null)
            return UUID.fromString(singleResult);

        return null;
    }
}
