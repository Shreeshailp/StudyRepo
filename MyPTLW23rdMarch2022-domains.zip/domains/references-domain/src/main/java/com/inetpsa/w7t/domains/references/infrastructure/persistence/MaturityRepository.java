/*
 * Creation : 19 Aug 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;

import com.inetpsa.w7t.domains.maturity.model.Maturity;

/**
 * The Interface MaturityRepository.
 */
public interface MaturityRepository extends GenericRepository<Maturity, UUID> {

    /**
     * Exists.
     *
     * @param family the family
     * @param body the body
     * @param motor the motor
     * @param gearbox the gearbox
     * @param index the index
     * @return true, if successful
     */
    public boolean exists(String family, String body, String motor, String gearbox, String index);

    /**
     * Maturity by unique fields.
     *
     * @param family the family
     * @param body the body
     * @param motor the motor
     * @param gearbox the gearbox
     * @param index the index
     * @return the list
     */
    public List<Maturity> maturityByUniqueFields(String family, String body, String motor, String gearbox, String index);

    /**
     * Gets the all maturities.
     *
     * @return the all maturities
     */
    public List<Maturity> getAllMaturities();

    /**
     * Gets the matched patterns.
     *
     * @param pattern the pattern
     * @return the matched patterns
     */
    public List<Maturity> getMatchedPatterns(String pattern);

    /**
     * Insert into pattern table.
     *
     * @param version16 the version 16
     * @param maturityStatus the maturity status
     * @param client the client
     */
    public void insertIntoPatternTable(String version16, String maturityStatus, String client);

    /**
     * Clear session.
     */
    public void clearSession();

}
