/*
 * Creation : 18 Aug 2021
 */
package com.inetpsa.w7t.domains.wltphub.answer.repository;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;

import com.inetpsa.w7t.domains.references.model.WltpHubAnswerEntity;

/**
 * The Interface WltpHubAnswerRepository.
 */
public interface WltpHubAnswerRepository extends GenericRepository<WltpHubAnswerEntity, UUID> {

    /**
     * Gets the wltp hub answer by request id and file id.
     *
     * @param requestId the request id
     * @param internalFileId the internal file id
     * @return the wltp hub answer by request id and file id
     */
    public WltpHubAnswerEntity getWltpHubAnswerByRequestIdAndFileId(String requestId, String internalFileId);

    /**
     * Gets the all wltp hub answers by internal file id.
     *
     * @param internalFileId the internal file id
     * @return the all wltp hub answers by internal file id
     */
    List<WltpHubAnswerEntity> getAllWltpHubAnswersByInternalFileId(String internalFileId);
}
