/*
 * Creation : 18 Aug 2020
 */
package com.inetpsa.w7t.domains.unitary.simulation.repository;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CollectionRequestEntity;

/**
 * The Interface CollectionRequestRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CollectionRequestRepository extends GenericRepository<CollectionRequestEntity, UUID> {

    /**
     * Update collection request.
     *
     * @param requestEntity the request entity
     */
    void updateCollectionRequest(CollectionRequestEntity requestEntity);

}
