/*
 * Creation : 24 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.validation.CountryCode;

/**
 * The Interface CountryRepository. This repository is used to retrieve and save any {@link Country} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CountryRepository extends GenericRepository<Country, UUID> {
    /**
     * Read all countries from the database.
     *
     * @return the list of countries read.
     */
    @Read
    List<Country> all();

    @Read
    List<Country> allByCharacteristic(String characteristic);

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the countries entity retrieved
     */
    @Read
    Optional<Country> byCode(@CountryCode String code);

    /**
     * Check that the countries identified by the specified code exists.
     *
     * @param code the country code
     * @return true if the country exists, false otherwise.
     */
    @Read
    boolean exists(@CountryCode String code);

    /**
     * By code and characteristic.
     *
     * @param code the code
     * @param characteristic the characteristic
     * @return the optional
     */
    @Read
    Country byCodeAndCharacteristic(@CountryCode String code, String characteristic);
}
