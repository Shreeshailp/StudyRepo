/*
 * Creation : 1 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;

import com.inetpsa.w7t.domains.references.model.DestinationCountry;

/**
 * The Interface DestinationCountryRepository.
 *
 * @author E534811
 */
public interface DestinationCountryRepository extends GenericRepository<DestinationCountry, UUID> {

    /**
     * By country id.
     *
     * @param guid the guid
     * @return the list
     */
    @Read
    List<DestinationCountry> byCountryId(UUID guid);

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<DestinationCountry> all();

}
