/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.infrastructure.persistence;

import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.core.model.Label;
import com.inetpsa.w7t.domains.core.model.LabelKey;

/**
 * The Interface LabelRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface LabelRepository extends GenericRepository<Label, LabelKey> {

    /**
     * Retrieve a {@link Label} given a {@code key} and a {@code locale}. Return an {@link Optional} label in case no label for the pair key/locale
     * has been found.
     *
     * @param key the key
     * @param locale the locale
     * @return an optional {@link Label}
     */
    Optional<Label> byKeyAndLocale(UUID key, String locale);
}
