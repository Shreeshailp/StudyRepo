/*
 * Creation : 7 Nov 2019
 */
package com.inetpsa.w7t.domains.references.common;

/**
 * The Class EmissionConstants.
 */
public final class EmissionConstants {

    /** The Constant CE. */
    public static final String CE = "CE";

    /** The Constant FC. */
    public static final String FC = "FC";

    /** The Constant FCB. */
    public static final String FCB = "FCB";

    /** The Constant FCG. */
    public static final String FCG = "FCG";

    /** The Constant CO2. */
    public static final String CO2 = "CO2";

    /** The Constant CO2B. */
    public static final String CO2B = "CO2B";

    /** The Constant CO2G. */
    public static final String CO2G = "CO2G";

    /** The Constant EC. */
    public static final String EC = "EC";

    /** The Constant PER. */
    public static final String PER = "PER";

    /** The Constant FCCS. */
    public static final String FCCS = "FCCS";

    /** The Constant CO2CS. */
    public static final String CO2CS = "CO2CS";

    /** The Constant FCCD. */
    public static final String FCCD = "FCCD";

    /** The Constant CO2CD. */
    public static final String CO2CD = "CO2CD";

    /** The Constant ECCD. */
    public static final String ECCD = "ECCD";

    /** The Constant UFECCD. */
    public static final String UFECCD = "UFECCD";

    /** The Constant WCFC. */
    public static final String WCFC = "WCFC";

    /** The Constant WCCO2. */
    public static final String WCCO2 = "WCCO2";

    /** The Constant UFEC. */
    public static final String UFEC = "UFEC";

    /** The Constant AER. */
    public static final String AER = "AER";

    /** The Constant EAER. */
    public static final String EAER = "EAER";

    /** The Constant AERCD. */
    public static final String AERCD = "AERCD";

    /** The Constant CRCD. */
    public static final String CRCD = "CRCD";

    /** The Constant ECDCCD. */
    public static final String ECDCCD = "ECDCCD";

    /** The Constant ECDC. */
    public static final String ECDC = "ECDC";

    /**
     * Instantiates a new emission constants.
     */
    private EmissionConstants() {

    }

}
