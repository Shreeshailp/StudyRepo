package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class FsFlagFileEntity.
 */
@Entity
@Table(name = "W7TQTFSF")
public class FsFlagFileEntity extends BaseAggregateRoot<String> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The file id. */
    @Column(name = "FILE_ID")
    private String fileId = "";

    /** The client. */
    @Column(name = "CLIENT")
    private String client = "";

    /** The fs flag file name. */
    @Column(name = "FS_FLAG_FILE_NAME")
    private String fsFlagFileName = "";

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the new fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Getter guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid.
     *
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the entity id.
     *
     * @return the entity id
     */
    @Override
    public String getEntityId() {
        return this.guid.toString();
    }

    /**
     * To string.
     *
     * @return the string
     */
    @Override
    public String toString() {
        return "FsFlagFileEntity [guid=" + guid + ", fileId=" + fileId + ", client=" + client + ", fsFlagFileName=" + fsFlagFileName + "]";
    }

}
