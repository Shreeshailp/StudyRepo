/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.domains.maturity.model;

import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

@Entity
@Table(name = "W7TQTPAT")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Maturity extends BaseAggregateRoot<UUID> {
    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "PATTERN")
    private String pattern;

    @Column(name = "FAMILY")
    private String family;

    @Column(name = "MATURITY_BODY")
    private String body;

    @Column(name = "MOTOR")
    private String motor;

    @Column(name = "GEARBOX")
    private String gearbox;

    @Column(name = "MATURITY_INDEX")
    private String index;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATED_ON")
    private String createdOn;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "STATUS_UPDATED_ON")
    private String statusUpdatedOn;

    @Column(name = "STATUS_UPDATED_BY")
    private String statusUpdatedBy;

    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * Getter guid
     * 
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid
     * 
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter pattern
     * 
     * @return the pattern
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Setter pattern
     * 
     * @param pattern the pattern to set
     */
    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    /**
     * Getter family
     * 
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * Setter family
     * 
     * @param family the family to set
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * Getter body
     * 
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * Setter body
     * 
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * Getter motor
     * 
     * @return the motor
     */
    public String getMotor() {
        return motor;
    }

    /**
     * Setter motor
     * 
     * @param motor the motor to set
     */
    public void setMotor(String motor) {
        this.motor = motor;
    }

    /**
     * Getter gearbox
     * 
     * @return the gearbox
     */
    public String getGearbox() {
        return gearbox;
    }

    /**
     * Setter gearbox
     * 
     * @param gearbox the gearbox to set
     */
    public void setGearbox(String gearbox) {
        this.gearbox = gearbox;
    }

    /**
     * Getter index
     * 
     * @return the index
     */
    public String getIndex() {
        return index;
    }

    /**
     * Setter index
     * 
     * @param index the index to set
     */
    public void setIndex(String index) {
        this.index = index;
    }

    /**
     * Getter status
     * 
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Setter status
     * 
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Getter createdOn
     * 
     * @return the createdOn
     */
    public String getCreatedOn() {
        return createdOn;
    }

    /**
     * Setter createdOn
     * 
     * @param createdOn the createdOn to set
     */
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * Getter createdBy
     * 
     * @return the createdBy
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Setter createdBy
     * 
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getStatusUpdatedOn() {
        return statusUpdatedOn;
    }

    public void setStatusUpdatedOn(String statusUpdatedOn) {
        this.statusUpdatedOn = statusUpdatedOn;
    }

    /**
     * Getter statusUpdatedBy
     * 
     * @return the statusUpdatedBy
     */
    public String getStatusUpdatedBy() {
        return statusUpdatedBy;
    }

    /**
     * Setter statusUpdatedBy
     * 
     * @param statusUpdatedBy the statusUpdatedBy to set
     */
    public void setStatusUpdatedBy(String statusUpdatedBy) {
        this.statusUpdatedBy = statusUpdatedBy;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Maturity [guid=" + guid + ", pattern=" + pattern + ", family=" + family + ", body=" + body + ", motor=" + motor + ", gearbox="
                + gearbox + ", index=" + index + ", status=" + status + ", createdOn=" + createdOn + ", createdBy=" + createdBy + ", statusUpdatedOn="
                + statusUpdatedOn + ", statusUpdatedBy=" + statusUpdatedBy + "]";
    }

}
