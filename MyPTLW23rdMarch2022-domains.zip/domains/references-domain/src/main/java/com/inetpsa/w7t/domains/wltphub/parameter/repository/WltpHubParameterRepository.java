/*
 * Creation : 16 Mar 2021
 */
package com.inetpsa.w7t.domains.wltphub.parameter.repository;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.WltpHubParameterEntity;

/**
 * The Interface WltpHubParameterRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface WltpHubParameterRepository extends GenericRepository<WltpHubParameterEntity, UUID> {

    /**
     * Gets the code by client.
     *
     * @param client the client
     * @return the code by client
     */
    public String getCodeByClient(String client);
}
