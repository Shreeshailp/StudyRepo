/*
 * Creation : 17 Oct 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.ClientParameter;

/**
 * The Interface ClientParameterFinder.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface ClientParameterFinder {

    /**
     * Gets the 7 c flag.
     *
     * @param prd the prd
     * @param flagValue the flag value
     * @return the 7 c flag
     */
    public String get7cFlag(String prd, String flagValue);

    /**
     * Gets the flag 7 C.
     *
     * @param prd the prd
     * @param flagValue the flag value
     * @return the flag 7 C
     */
    public ClientParameter getFlag7C(String prd, String flagValue);

}
