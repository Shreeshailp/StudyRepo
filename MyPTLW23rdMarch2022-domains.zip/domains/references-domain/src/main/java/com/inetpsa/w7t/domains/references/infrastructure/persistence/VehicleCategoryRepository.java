/*
 * Creation : 6 janv. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.VehicleCategory;
import com.inetpsa.w7t.domains.references.validation.VehicleCategoryCode;

/**
 * The Interface VehicleCategoryRepository. This repository is used to retrieve and save any {@link VehicleCategory} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface VehicleCategoryRepository extends GenericRepository<VehicleCategory, UUID> {

    /**
     * Read all vehicle categories from the database.
     *
     * @return the list of families read.
     */
    @Read
    List<VehicleCategory> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the vehicle category entity retrieved
     */
    @Read
    Optional<VehicleCategory> byCode(@VehicleCategoryCode String code);

    /**
     * Check that the vehicle category identified by the specified code exists.
     *
     * @param code the vehicle category code
     * @return true if the vehicle category exists, false otherwise.
     */
    @Read
    boolean exists(@VehicleCategoryCode String code);

}
