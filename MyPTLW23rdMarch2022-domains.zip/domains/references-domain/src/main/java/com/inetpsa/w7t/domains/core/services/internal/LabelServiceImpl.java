/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.services.internal;

import java.util.Optional;
import java.util.UUID;

import javax.cache.annotation.CacheResult;

import org.seedstack.seed.Logging;
import org.seedstack.seed.security.SecuritySupport;
import org.seedstack.seed.security.principals.PrincipalProvider;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.exception.LDAPException;
import com.inetpsa.w7t.domains.core.infrastructure.persistence.LabelRepository;
import com.inetpsa.w7t.domains.core.model.Label;
import com.inetpsa.w7t.domains.core.services.LabelService;

/**
 * The Class LabelServiceImpl. This implementation uses a {@link SecuritySupport} to access the current connected user in order to fetch its LDAP
 * language. This implementation defines a default language as French ({@code fr-FR}) is case the i18n label for the provided key is not found.
 */
public class LabelServiceImpl implements LabelService {

    /** The Constant DEFAULT_LANGUAGE. */
    private static final String DEFAULT_LANGUAGE = "FR";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The label repository. */
    @Inject
    private LabelRepository labelRepository;

    /** The security support. */
    @Inject
    private SecuritySupport securitySupport;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.core.services.LabelService#value(java.util.UUID)
     */
    @Override
    public String value(UUID key) {
        String locale = securitySupport.getPrincipalsByType(LDAPUser.class).stream().findFirst().map(PrincipalProvider::getPrincipal).map(u -> {
            try {
                return u.getLocale();
            } catch (LDAPException e) {
                logger.warn("Exception while trying to access current connected user");
                logger.debug("Current connected user exception", e);
                return DEFAULT_LANGUAGE;
            }
        }).orElse(DEFAULT_LANGUAGE);

        return value(key, locale);
    }

    @CacheResult(cacheName = "labelCache")
    private String value(UUID key, String locale) {
        Optional<String> label = labelRepository.byKeyAndLocale(key, locale).map(Label::getValue);

        if (label.isPresent())
            return label.get();
        if (!locale.equals(DEFAULT_LANGUAGE))
            return labelRepository.byKeyAndLocale(key, DEFAULT_LANGUAGE).map(Label::getValue).orElse(null);
        return null;
    }

}
