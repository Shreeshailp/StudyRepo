/*
 * Creation : 18 Aug 2021
 */
package com.inetpsa.w7t.domains.wltphub.answer.services;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.inetpsa.w7t.domains.references.model.WltpHubAnswerEntity;
import com.inetpsa.w7t.domains.wltphub.answer.repository.WltpHubAnswerRepository;

/**
 * The Class WltpHubAnswerServiceImpl.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class WltpHubAnswerServiceImpl implements WltpHubAnswerService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The wltp hub answer repository. */
    @Inject
    private WltpHubAnswerRepository wltpHubAnswerRepository;

    /** The wltp hub answer entity factory. */
    @Inject
    private Factory<WltpHubAnswerEntity> wltpHubAnswerEntityFactory;

    /** The date time formatter. */
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.answer.services.WltpHubAnswerService#saveWltpHubAnswer(java.lang.String, java.lang.String,
     *      java.lang.Object)
     */
    @Override
    public <T> void saveWltpHubAnswer(String requestId, String internalFileId, T t) {
        WltpHubAnswerEntity wltpHubAnswerEntity = wltpHubAnswerEntityFactory.create();
        wltpHubAnswerEntity.setRequestId(requestId);
        wltpHubAnswerEntity.setInternalFileId(internalFileId);
        wltpHubAnswerEntity.setJsonAnswer(new Gson().toJson(t));
        wltpHubAnswerEntity.setCreatedDate(getTodaysDate());
        wltpHubAnswerRepository.save(wltpHubAnswerEntity);
    }

    /**
     * Convert to response object.
     *
     * @param <T> the generic type
     * @param jsonStr the json str
     * @param clazz the clazz
     * @return the t
     */
    private <T> T convertToResponseObject(String jsonStr, Class<T> clazz) {
        T value = null;
        if (jsonStr != null) {
            value = new Gson().fromJson(jsonStr, clazz);
        }
        return value;

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.answer.services.WltpHubAnswerService#getWltpHubAnswerByRequestIdAndFileId(java.lang.String,
     *      java.lang.String, java.lang.Class)
     */
    @Override
    public <T> T getWltpHubAnswerByRequestIdAndFileId(String requestId, String internalFileId, Class<T> clazz) {
        WltpHubAnswerEntity hubAnswerEntity = wltpHubAnswerRepository.getWltpHubAnswerByRequestIdAndFileId(requestId, internalFileId);
        T object = null;
        if (hubAnswerEntity != null) {
            String jsonStr = hubAnswerEntity.getJsonAnswer();
            object = convertToResponseObject(jsonStr, clazz);
        }
        return object;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.answer.services.WltpHubAnswerService#getAllWltpHubAnswers(java.lang.String, java.lang.Class)
     */
    @Override
    public <T> List<T> getAllWltpHubAnswers(String internalFileId, Class<T> clazz) {
        List<WltpHubAnswerEntity> list = wltpHubAnswerRepository.getAllWltpHubAnswersByInternalFileId(internalFileId);
        List<T> newList = new ArrayList<>();
        for (WltpHubAnswerEntity hubAnswerEntity : list) {
            String jsonStr = hubAnswerEntity.getJsonAnswer();
            newList.add(convertToResponseObject(jsonStr, clazz));
        }
        return newList;
    }

    /**
     * Gets the todays date.
     *
     * @return the todays date
     */
    private String getTodaysDate() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }
}
