/*
 * Creation : 1 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class DestinationCountry.
 *
 * @author E534811
 */
@Entity
@Table(name = "W7TQTDCO")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class DestinationCountry extends BaseAggregateRoot<UUID> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7897636220320867978L;

    /** The destination id. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "DESTINATION_ID")
    private UUID destinationId;

    /** The counry id. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "COUNTRY_ID")
    private UUID counryId;

    /**
     * Gets the destination id.
     *
     * @return the destination id
     */
    public UUID getDestinationId() {
        return destinationId;
    }

    /**
     * Sets the destination id.
     *
     * @param destinationId the new destination id
     */
    public void setDestinationId(UUID destinationId) {
        this.destinationId = destinationId;
    }

    /**
     * Gets the counry id.
     *
     * @return the counry id
     */
    public UUID getCounryId() {
        return counryId;
    }

    /**
     * Sets the counry id.
     *
     * @param counryId the new counry id
     */
    public void setCounryId(UUID counryId) {
        this.counryId = counryId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.destinationId;
    }

    /**
     * Instantiates a new destination country.
     */
    public DestinationCountry() {

    }

    /**
     * Instantiates a new destination country.
     *
     * @param destinationId the destination id
     * @param counryId the counry id
     */
    public DestinationCountry(UUID destinationId, UUID counryId) {
        super();
        this.destinationId = destinationId;
        this.counryId = counryId;
    }

}
