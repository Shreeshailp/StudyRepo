/*
 * Creation : 17 Oct 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;
import com.inetpsa.w7t.domains.references.model.ClientParameter;

public class ClientParameterJpaFinder extends BaseJpaRepository<ClientParameter, UUID> implements ClientParameterFinder {
    @Inject
    EntityManager entityManager;
    @Logging
    private Logger logger;

    private static final String PRD = "prd";
    private static final String FLAG7C = "flag7c";

    @Override
    public String get7cFlag(String prd, String flagValue) {
        String sqlQuery = "SELECT cpt.7c FROM W7TQTCPT cpt where cpt.prd=? and cpt.7c=? ";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, prd);
        q.setParameter(2, flagValue);

        logger.debug("Fetched Combo Value");

        return q.getResultList().isEmpty() ? "" : (String) q.getResultList().get(0);
    }

    @Override
    @CacheResult(cacheName = "clientParameter")
    public ClientParameter getFlag7C(String prd, String flagValue) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<ClientParameter> q = cb.createQuery(ClientParameter.class);
        Root<ClientParameter> root = q.from(ClientParameter.class);
        q.where(cb.equal(root.get(PRD), cb.parameter(String.class, PRD)), cb.equal(root.get(FLAG7C), cb.parameter(String.class, FLAG7C)));

        TypedQuery<ClientParameter> query = entityManager.createQuery(q);
        query.setParameter(PRD, prd);
        query.setParameter(FLAG7C, flagValue);

        return query.getResultList().isEmpty() ? null : query.getResultList().get(0);
    }

}
