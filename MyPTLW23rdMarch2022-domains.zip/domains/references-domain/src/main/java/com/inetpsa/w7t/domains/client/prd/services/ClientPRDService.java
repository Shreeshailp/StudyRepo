/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.client.prd.services;

import org.seedstack.business.Service;

/**
 * The Interface ClientPRDService.
 */
@Service
public interface ClientPRDService {

    /**
     * Gets the client by PRD.
     *
     * @param prd the prd
     * @return the client by PRD
     */
    String getClientByPRD(String prd);
}
