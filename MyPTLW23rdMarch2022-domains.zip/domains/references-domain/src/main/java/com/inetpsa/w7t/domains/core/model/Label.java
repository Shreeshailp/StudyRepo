/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.seedstack.business.domain.BaseAggregateRoot;

/**
 * The Class Label. This entity represents a label identified by a key and a locale and is used to internationalize designations in other entities.
 */
@Entity
@Table(name = "W7TQTI18")
public class Label extends BaseAggregateRoot<LabelKey> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3582738716591593287L;

    /** The value. */
    @Size(max = 250)
    @Column(name = "VALUE")
    private String value;

    /** The key. */
    @NotNull
    @EmbeddedId
    private LabelKey key;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public LabelKey getEntityId() {
        return key;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object other) {
        if (other instanceof Label) {
            String hash = new StringBuilder(value).append(key).toString();
            String otherHash = new StringBuilder(((Label) other).value).append(((Label) other).key).toString();
            return hash.equals(otherHash);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        String hash = new StringBuilder(value).append(key).toString();
        return hash.hashCode();
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    public LabelKey getKey() {
        return key;
    }

    /**
     * Sets the key.
     *
     * @param key the new key
     */
    public void setKey(LabelKey key) {
        this.key = key;
    }
}
