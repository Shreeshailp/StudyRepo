/*
 * Creation : 24 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;

/**
 * The Interface CyclePhaseRepository. This repository is used to retrieve and save any {@link CyclePhase} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CyclePhaseRepository extends GenericRepository<CyclePhase, UUID> {

    /**
     * Read all CyclePhase from the database.
     *
     * @return the list of CyclePhase read.
     */
    @Read
    List<CyclePhase> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the CyclePhase entity retrieved
     */
    @Read
    Optional<CyclePhase> byCode(@CyclePhaseCode String code);

    /**
     * Read the UUID of the cycle phase specified by a code.
     *
     * @param code the cycle phase code
     * @return the optional UUID
     */
    @Read
    Optional<UUID> uuidByCode(@CyclePhaseCode String code);

    /**
     * Check that the CyclePhase identified by the specified code exists.
     *
     * @param code the CyclePhase code
     * @return true if the CyclePhase exists, false otherwise.
     */
    @Read
    boolean exists(@CyclePhaseCode String code);
}
