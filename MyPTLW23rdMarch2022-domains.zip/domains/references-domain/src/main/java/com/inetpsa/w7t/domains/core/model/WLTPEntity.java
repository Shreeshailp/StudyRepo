/*
 * Creation : 6 févr. 2017
 */
package com.inetpsa.w7t.domains.core.model;

import java.util.UUID;

import org.seedstack.business.domain.AggregateRoot;

/**
 * The Interface WLTPEntity. This interface is used to identify which entities own at least an {@link UUID} member, in order to convert it to an
 * {@link String} equivalent in the corresponding Representation through the Assembler.
 *
 * @param <T> the identity type
 */
public interface WLTPEntity<T> extends AggregateRoot<T> {

}
