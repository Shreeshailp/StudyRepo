/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.CompleteFlag;

/**
 * The Interface CompleteFlagRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CompleteFlagRepository extends GenericRepository<CompleteFlag, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<CompleteFlag> all();

    /**
     * Exists.
     *
     * @param code the code
     * @return true, if successful
     */
    @Read
    boolean exists(String code);
}
