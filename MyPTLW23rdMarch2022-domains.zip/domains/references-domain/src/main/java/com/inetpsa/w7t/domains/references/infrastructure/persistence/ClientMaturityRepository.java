/*
 * Creation : 4 Sep 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.ClientMaturity;

/**
 * The Interface ClientMaturityRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ClientMaturityRepository extends GenericRepository<ClientMaturity, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<ClientMaturity> all();

    /**
     * Exists.
     *
     * @param client the client
     * @param status the status
     * @return true, if successful
     */
    @Read
    boolean exists(String client, String status);
}
