/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.UUID;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.ClientPRDEntity;

/**
 * The Class ClientPRDJpaRepository.
 */
/**
 * @author E539596
 */
public class ClientPRDJpaRepository extends BaseJpaRepository<ClientPRDEntity, UUID> implements ClientPRDRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.ClientPRDRepository#getClientByPRD(java.lang.String)
     */
    @Override
    public String getClientByPRD(String prd) {
        String sqlQuery = "SELECT prd.CLIENT FROM W7TQTPRD prd where prd.PRD=? ";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, prd);
        return q.getResultList().isEmpty() ? "" : (String) q.getResultList().get(0);
    }

}
