/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.ConversionDataType;

/**
 * The Interface ConversionDataTypeRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface ConversionDataTypeRepository extends GenericRepository<ConversionDataType, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<ConversionDataType> all();

    /**
     * Exists.
     *
     * @param dataType the data type
     * @return true, if successful
     */
    @Read
    boolean exists(String dataType);
}
