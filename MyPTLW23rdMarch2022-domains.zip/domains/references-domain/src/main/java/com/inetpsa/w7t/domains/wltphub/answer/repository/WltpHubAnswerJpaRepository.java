/*
 * Creation : 18 Aug 2021
 */
package com.inetpsa.w7t.domains.wltphub.answer.repository;

import java.util.List;
import java.util.UUID;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.WltpHubAnswerEntity;

/**
 * The Class WltpHubAnswerJpaRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class WltpHubAnswerJpaRepository extends BaseJpaRepository<WltpHubAnswerEntity, UUID> implements WltpHubAnswerRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.answer.repository.WltpHubAnswerRepository#getWltpHubAnswerByRequestIdAndFileId(java.lang.String,
     *      java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public WltpHubAnswerEntity getWltpHubAnswerByRequestIdAndFileId(String requestId, String internalFileId) {
        String sqlQuery = "SELECT * FROM W7TQTWHA WHERE REQUEST_ID=? AND INTERNAL_FILE_ID=?";
        Query query = entityManager.createNativeQuery(sqlQuery, WltpHubAnswerEntity.class);
        query.setParameter(1, requestId);
        query.setParameter(2, internalFileId);
        List<WltpHubAnswerEntity> entityList = query.getResultList();
        WltpHubAnswerEntity hubAnswerEntity = null;
        if (entityList != null && !entityList.isEmpty()) {
            hubAnswerEntity = entityList.get(0);
        }
        return hubAnswerEntity;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.answer.repository.WltpHubAnswerRepository#getAllWltpHubAnswersByInternalFileId(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<WltpHubAnswerEntity> getAllWltpHubAnswersByInternalFileId(String internalFileId) {
        String sqlQuery = "SELECT * FROM W7TQTWHA WHERE INTERNAL_FILE_ID=?";
        Query query = entityManager.createNativeQuery(sqlQuery, WltpHubAnswerEntity.class);
        query.setParameter(1, internalFileId);
        return query.getResultList();
    }

}
