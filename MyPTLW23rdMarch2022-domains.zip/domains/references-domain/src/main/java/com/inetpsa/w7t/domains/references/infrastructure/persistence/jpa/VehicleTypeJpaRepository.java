/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository;
import com.inetpsa.w7t.domains.references.model.VehicleType;
import com.inetpsa.w7t.domains.references.validation.VehicleTypeCode;

/**
 * The Class VehicleTypeJpaRepository. JPA Implementation of {@link VehicleTypeRepository}.
 */
public class VehicleTypeJpaRepository extends BaseJpaRepository<VehicleType, UUID> implements VehicleTypeRepository {

    @Logging
    private Logger logger;

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository#all()
     */
    @Override
    public List<VehicleType> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<VehicleType> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<VehicleType> byCode(@VehicleTypeCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> q = cb.createQuery(VehicleType.class);
        Root<VehicleType> root = q.from(VehicleType.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<VehicleType> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    @Override
    public Optional<UUID> guidByCode(String code) {
        return Optional.ofNullable(cachedGuidByCode(code));
    }

    /**
     * Get the guid of a vehicle type and cache it.
     *
     * @param code the code
     * @return the uuid
     */
    @CacheResult(cacheName = "vehicleTypeGuidCache")
    public UUID cachedGuidByCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<VehicleType> root = q.from(VehicleType.class);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst().orElse(null);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(@VehicleTypeCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<VehicleType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<VehicleType> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<VehicleType>get(CODE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
    }
}
