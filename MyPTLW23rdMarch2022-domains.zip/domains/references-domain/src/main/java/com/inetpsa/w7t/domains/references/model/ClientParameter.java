package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

@Entity
@Table(name = "W7TQTCPT")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class ClientParameter extends BaseAggregateRoot<UUID> implements Serializable {

    private static final long serialVersionUID = -5106760639593672334L;

    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "PRD")
    private String prd;

    @Column(name = "7C")
    private String flag7c;

    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getPrd() {
        return prd;
    }

    public void setPrd(String prd) {
        this.prd = prd;
    }

    public String getFlag7c() {
        return flag7c;
    }

    public void setFlag7c(String flag7c) {
        this.flag7c = flag7c;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((flag7c == null) ? 0 : flag7c.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((prd == null) ? 0 : prd.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        ClientParameter other = (ClientParameter) obj;
        if (flag7c == null) {
            if (other.flag7c != null)
                return false;
        } else if (!flag7c.equals(other.flag7c))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (prd == null) {
            if (other.prd != null)
                return false;
        } else if (!prd.equals(other.prd))
            return false;
        return true;
    }

}
