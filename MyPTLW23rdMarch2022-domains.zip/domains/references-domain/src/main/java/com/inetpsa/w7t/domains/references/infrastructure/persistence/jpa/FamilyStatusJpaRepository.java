/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.FamilyStatusRepository;
import com.inetpsa.w7t.domains.references.model.FamilyStatus;

/**
 * The Class FamilyStatusJpaRepository.
 */
public class FamilyStatusJpaRepository extends BaseJpaRepository<FamilyStatus, UUID> implements FamilyStatusRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.FamilyStatusRepository#getAllFamilyStatus()
     */
    @Override
    public List<FamilyStatus> getAllFamilyStatus() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyStatus> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<FamilyStatus> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.FamilyStatusRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String status) {
        Query query = entityManager.createNativeQuery("select * from W7TQTFST where STATUS = ? ", FamilyStatus.class);
        query.setParameter(1, status);
        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.FamilyStatusRepository#getFamilyStatus(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<FamilyStatus> getFamilyStatus(String status) {
        Query query = entityManager.createNativeQuery("select * from W7TQTFST where STATUS = ? ", FamilyStatus.class);
        query.setParameter(1, status);
        return query.getResultList().stream().findFirst();
    }

}
