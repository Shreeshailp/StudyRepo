/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.CompleteFlagRepository;
import com.inetpsa.w7t.domains.references.model.CompleteFlag;

public class CompleteFlagJpaRepository extends BaseJpaRepository<CompleteFlag, UUID> implements CompleteFlagRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    @Override
    public List<CompleteFlag> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CompleteFlag> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<CompleteFlag> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    @Override
    public boolean exists(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<CompleteFlag> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));
        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        return query.getResultList().stream().findFirst().isPresent();

    }

}
