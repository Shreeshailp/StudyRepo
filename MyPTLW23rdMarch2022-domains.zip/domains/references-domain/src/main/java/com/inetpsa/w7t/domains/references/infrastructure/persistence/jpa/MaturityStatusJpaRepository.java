/*
 * Creation : 21 Aug 2019
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityStatusRepository;
import com.inetpsa.w7t.domains.references.model.MaturityStatus;

public class MaturityStatusJpaRepository extends BaseJpaRepository<MaturityStatus, UUID> implements MaturityStatusRepository {

    private static final String STATUS_CODE = "statusCode";

    private static final String GUID = "guid";

    @Override
    public List<MaturityStatus> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<MaturityStatus> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<MaturityStatus> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    @Override
    public boolean exists(String statusCode) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<MaturityStatus> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(STATUS_CODE), cb.parameter(String.class, STATUS_CODE)));
        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(STATUS_CODE, statusCode);
        return query.getResultList().stream().findFirst().isPresent();
    }
}
