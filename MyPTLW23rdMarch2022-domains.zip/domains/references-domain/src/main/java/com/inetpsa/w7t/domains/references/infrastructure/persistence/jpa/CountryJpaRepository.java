/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.validation.CountryCode;

/**
 * The Class CountryJpaRepository. JPA Implementation of {@link CountryRepository}.
 */
public class CountryJpaRepository extends BaseJpaRepository<Country, UUID> implements CountryRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    private static final String CHARACTERISTIC = "characteristic";

    private static ConcurrentHashMap<String, Country> countryMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository#all()
     */
    @Override
    public List<Country> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<Country> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();

    }

    @Override
    public List<Country> allByCharacteristic(String characteristic) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> cq = cb.createQuery(Country.class);
        Root<Country> root = cq.from(Country.class);
        cq.where(cb.equal(root.get(CHARACTERISTIC), cb.parameter(String.class, CHARACTERISTIC)));

        TypedQuery<Country> query = entityManager.createQuery(cq);
        query.setParameter(CHARACTERISTIC, characteristic);
        return query.getResultList();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<Country> byCode(@CountryCode String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> q = cb.createQuery(Country.class);
        Root<Country> root = q.from(Country.class);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<Country> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository#exists(java.lang.String)
     */
    @Override
    /* @CacheResult(cacheName = "countryByCodeExistenceCache") */
    public boolean exists(@CountryCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<Country> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<Country>get("code"));
        criteriaQuery.where(criteriaBuilder.equal(root.get("code"), criteriaBuilder.parameter(String.class, "code")));

        return entityManager.createQuery(criteriaQuery).setParameter("code", code).getResultList().size() == 1;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository#byCodeAndCharacteristic(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public Country byCodeAndCharacteristic(@CountryCode String code, String characteristic) {
        String key = code + "_" + characteristic + "_Country";
        Country country = countryMap.get(key);

        if (country != null) {
            return country;
        }

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Country> q = cb.createQuery(aggregateRootClass);
        Root<Country> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)),
                cb.equal(root.get(CHARACTERISTIC), cb.parameter(String.class, CHARACTERISTIC)));

        TypedQuery<Country> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        query.setParameter(CHARACTERISTIC, characteristic);
        country = query.getResultList().isEmpty() ? null : query.getResultList().get(0);
        if (country != null) {
            countryMap.put(key, country);
        }
        return country;
    }
}
