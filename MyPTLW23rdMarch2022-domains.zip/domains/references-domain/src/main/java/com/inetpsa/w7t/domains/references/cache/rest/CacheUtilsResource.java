/*
 * Creation : 25 Jul 2019
 */
package com.inetpsa.w7t.domains.references.cache.rest;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

/**
 * The Class CacheUtilsResource.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
// @Path("v1/cache")
// URL:http://localhost:8080/calcul/v1/cache/clearcache
public class CacheUtilsResource {

    /** The Constant CLEAR_CACHE_PATH. */
    public static final String CLEAR_CACHE_PATH = "clearcache";
    /** The logger. */
    // @Logging
    // private Logger logger;
    //
    // @Rel(value = CLEAR_CACHE_PATH, home = true)
    // @GET
    // @Path(CLEAR_CACHE_PATH)
    // @Produces({ MediaType.TEXT_PLAIN, "application/text" })
    // public Response clearCache() {
    // logger.info("Inside clearCache()[IN]:");
    // WltpCacheManager<String> wltpCacheManager = WltpCacheManager.getInstance(String.class);
    // wltpCacheManager.putItem("Shree", "Shreeshail");
    // String value = wltpCacheManager.getItem("Shree");
    // logger.info("Retrived Value :{}", value);
    // wltpCacheManager.removeItem("Shree");
    // String removedKey = wltpCacheManager.getItem("Shree");
    // logger.info("Removed Value :{}", removedKey);
    // return Response.ok("Cleared the cache").build();
    // }
}
