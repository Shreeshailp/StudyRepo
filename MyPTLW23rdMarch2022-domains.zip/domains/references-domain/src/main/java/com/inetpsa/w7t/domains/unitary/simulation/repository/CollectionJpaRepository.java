/*
 * Creation : 18 Aug 2020
 */
package com.inetpsa.w7t.domains.unitary.simulation.repository;

import java.util.List;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.CollectionEntity;

/**
 * The Class CollectionJpaRepository.
 */
public class CollectionJpaRepository extends BaseJpaRepository<CollectionEntity, UUID> implements CollectionRepository {

    /** The Constant USER_ID. */
    private static final String USER_ID = "userId";

    /** The Constant TYPE. */
    private static final String TYPE = "type";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.unitary.simulation.repository.CollectionRepository#getAllCollections(java.lang.String, java.lang.String)
     */
    @Override
    public List<CollectionEntity> getAllCollections(String userId, String type) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<CollectionEntity> q = cb.createQuery(aggregateRootClass);
        Root<CollectionEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(USER_ID), cb.parameter(String.class, USER_ID)), cb.equal(root.get(TYPE), cb.parameter(String.class, TYPE)));

        TypedQuery<CollectionEntity> query = entityManager.createQuery(q);
        query.setParameter(USER_ID, userId);
        query.setParameter(TYPE, type);
        return query.getResultList();
    }

}
