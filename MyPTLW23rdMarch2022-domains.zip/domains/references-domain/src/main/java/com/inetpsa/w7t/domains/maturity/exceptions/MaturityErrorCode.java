/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.domains.maturity.exceptions;

import org.seedstack.shed.exception.ErrorCode;

public enum MaturityErrorCode implements ErrorCode {

    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(100, "At least one line of the file is not recognized, the import has not been performed", "RG37"),

    MATURITY_UNKNOWN_EXCEPTION(112, "At least one piece of data is not correct, the import has not been made", "RGXX"),

    UNKNOWN_EXCEPTION(109, "Unknown Technical Exception", "RGXX"),

    MATURITY_ALREADY_EXISTS(103, "{0} ", "RG39"),
    /** MATURITY entry present in sheet */
    MATURITY_ENTRY_PRESENT_IN_SHEET(101,
            "At least one duplicate list (Family {0}, Body {1}, Motor {2}, Gearbox {3}, Index{4}), the import was not made", "RG38"),

    FIRST_LINE_STARTS_C_M_D_CHECK(110, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG40"),

    MATURITY_HEADER_COLUMN_MISSING(116, "At least one line is not in the required format, the import has not been made. Stop treatment", "RG40"),

    MATURITY_UNKNOWN_ERROR(120, "{0}, the import has not been made. Stop treatment", "RG40"),

    MISSING_FAMILY(121, "Family missing for maturity", "RG41"),

    INVALID_FAMILY(122, "incorrect family (MATURITY)", "RG42"),

    MISSING_BODY(123, "Body missing for maturity", "RG43"),

    INVALID_BODY(124, "incorrect body (MATURITY)", "RG44"),

    MISSING_MOTOR(125, "Motor missing for maturity", "RG45"),

    INVALID_MOTOR(126, "incorrect motor (MATURITY)", "RG46"),

    MISSING_GEARBOX(127, "Gearbox missing for maturity", "RG47"),

    INVALID_GEARBOX(128, "incorrect gearbox (MATURITY)", "RG48"),

    MISSING_INDEX(129, "Index missing for maturity", "RG49"),

    INVALID_INDEX(130, "incorrect index (MATURITY)", "RG50"),

    INVALID_MATURITY_STATUS(131, "incorrect maturity status", "RG51"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    SOMEONE_IMPORTING_DATA(132, "Someone else is importing data. Please try again later", "RG52");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Getter code
     * 
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * Getter description
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Getter ruleCode
     * 
     * @return the ruleCode
     */
    public String getRuleCode() {
        return ruleCode;
    }

    MaturityErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

}
