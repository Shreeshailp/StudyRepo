/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.model;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.seedstack.business.domain.BaseAggregateRoot;

/**
 * Parameter entity
 *
 * @author E505988
 */
@Entity
@Table(name = "W7TQTPRM")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Parameter extends BaseAggregateRoot<String> {

    /** The id. */
    @Id
    @Column(name = "ID")
    private String id;

    /** The value. */
    @Column(name = "VALUE")
    private String value;

    /**
     * Instantiates a new parameter.
     */
    public Parameter() {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public String getEntityId() {
        return this.id;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getCode() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setCode(String id) {
        this.id = id;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "Parameter [id=" + id + ", value=" + value + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Parameter other = (Parameter) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        return true;
    }

    /**
     * Instantiates a new parameter.
     *
     * @param id    the id
     * @param value the value
     */
    public Parameter(String id, String value) {
        super();
        this.id = id;
        this.value = value;
    }

}
