package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.FsFlagFileEntity;

/**
 * The Class FsFlagFileJpaRepository.
 */
public class FsFlagFileJpaRepository extends BaseJpaRepository<FsFlagFileEntity, String> implements FsFlagFileRepository {

    /**
     * Save.
     *
     * @param fsFlagFileEntity the fs flag file entity
     * @return the fs flag file entity
     */
    @Override
    public FsFlagFileEntity save(FsFlagFileEntity fsFlagFileEntity) {
        return entityManager.merge(fsFlagFileEntity);

    }

    /**
     * Save entity.
     *
     * @param fsFlagFileEntity the fs flag file entity
     */
    @Override
    public void saveEntity(FsFlagFileEntity fsFlagFileEntity) {
        entityManager.merge(fsFlagFileEntity);
    }

    /**
     * Gets the fs flag file name by file id.
     *
     * @param fileId the file id
     * @return the fs flag file name by file id
     */
    @SuppressWarnings("unchecked")
    @Override
    public String getFsFlagFileNameByFileId(String fileId) {
        String sqlQuery = "SELECT FS_FLAG_FILE_NAME FROM W7TQTFSF WHERE FILE_ID=?";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, fileId);
        List<String> fsFlagFileNameList = q.getResultList();
        if (fsFlagFileNameList != null && !fsFlagFileNameList.isEmpty()) {
            return fsFlagFileNameList.get(0);
        }
        return null;
    }

    /**
     * Delete fs flag file by file id.
     *
     * @param fileId the file id
     * @return the int
     */
    @Override
    public int deleteFsFlagFileByFileId(String fileId) {
        String sqlQuery = "DELETE FROM W7TQTFSF WHERE FILE_ID=?";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, fileId);
        return q.executeUpdate();

    }

    /**
     * Checks if is file id exist.
     *
     * @param fileId the file id
     * @return true, if is file id exist
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean isFileIdExist(String fileId) {
        String sqlQuery = "SELECT FS_FLAG_FILE_NAME FROM W7TQTFSF WHERE FILE_ID=?";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, fileId);
        List<String> fsFlagFileNameList = q.getResultList();
        if (fsFlagFileNameList != null && !fsFlagFileNameList.isEmpty()) {
            return true;
        }
        return false;
    }

}
