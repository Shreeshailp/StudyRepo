/*
 * Creation : 10 févr. 2017
 */
package com.inetpsa.w7t.domains.references.validation.internal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.inetpsa.w7t.domains.references.model.PayloadPercentage;
import com.inetpsa.w7t.domains.references.validation.ValidPayloadPercentageValidityDates;

/**
 * The Class ValidPayloadPercentageValidityDatesValidator. The validator is used to validate the {@link ValidPayloadPercentageValidityDates}
 * annotation.
 */
public class ValidPayloadPercentageValidityDatesValidator implements ConstraintValidator<ValidPayloadPercentageValidityDates, PayloadPercentage> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
     */
    @Override
    public void initialize(ValidPayloadPercentageValidityDates constraintAnnotation) {
        // This method is intentionally empty because there is nothing to initialize.
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
     */
    @Override
    public boolean isValid(PayloadPercentage percentage, ConstraintValidatorContext context) {
        if (percentage == null)
            return true;

        return percentage.getValidityStart().isBefore(percentage.getValidityEnd());
    }

}
