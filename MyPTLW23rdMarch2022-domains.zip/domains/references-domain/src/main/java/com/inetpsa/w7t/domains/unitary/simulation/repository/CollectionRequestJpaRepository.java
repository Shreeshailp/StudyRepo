/*
 * Creation : 18 Aug 2020
 */
package com.inetpsa.w7t.domains.unitary.simulation.repository;

import java.util.UUID;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.CollectionRequestEntity;

/**
 * The Class CollectionRequestJpaRepository.
 */
public class CollectionRequestJpaRepository extends BaseJpaRepository<CollectionRequestEntity, UUID> implements CollectionRequestRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.unitary.simulation.repository.CollectionRequestRepository#updateCollectionRequest(com.inetpsa.w7t.domains.references.model.CollectionRequestEntity)
     */
    @Override
    public void updateCollectionRequest(CollectionRequestEntity requestEntity) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        // create update
        CriteriaUpdate<CollectionRequestEntity> update = cb.createCriteriaUpdate(CollectionRequestEntity.class);

        // set the root class
        Root<CollectionRequestEntity> e = update.from(CollectionRequestEntity.class);

        // set update and where clause
        update.set("requestName", requestEntity.getRequestName());
        update.set("requestBlob", requestEntity.getRequestBlob());
        update.where(cb.equal(e.get("collectionRequestId"), requestEntity.getCollectionRequestId()));
        entityManager.createQuery(update).executeUpdate();
    }

}
