/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.GearBoxEntity;

/**
 * The Interface GearBoxRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface GearBoxRepository extends GenericRepository<GearBoxEntity, UUID> {

    /**
     * All.
     *
     * @return the list
     */
    @Read
    List<GearBoxEntity> all();

    /**
     * By gear box code.
     *
     * @param code the code
     * @return the optional
     */
    Optional<GearBoxEntity> byGearBoxCode(String code);
}
