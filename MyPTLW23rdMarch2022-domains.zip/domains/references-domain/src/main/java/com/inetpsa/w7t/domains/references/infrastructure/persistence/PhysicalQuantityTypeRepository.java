/*
 * Creation : 24 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;
import com.inetpsa.w7t.domains.references.validation.PhysicalQuantityTypeCode;

/**
 * The Interface PhysicalQuantityTypeRepository. This repository is used to retrieve and save any {@link PhysicalQuantityType} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface PhysicalQuantityTypeRepository extends GenericRepository<PhysicalQuantityType, UUID> {
    /**
     * Read all PhysicalQuantityType from the database.
     *
     * @return the list of PhysicalQuantityType read.
     */
    @Read
    List<PhysicalQuantityType> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the PhysicalQuantityType entity retrieved
     */
    @Read
    Optional<PhysicalQuantityType> byCode(@PhysicalQuantityTypeCode String code);

    /**
     * Check that the PhysicalQuantityType identified by the specified code exists.
     *
     * @param code the PhysicalQuantityType code
     * @return true if the PhysicalQuantityType exists, false otherwise.
     */
    @Read
    boolean exists(@PhysicalQuantityTypeCode String code);
}
