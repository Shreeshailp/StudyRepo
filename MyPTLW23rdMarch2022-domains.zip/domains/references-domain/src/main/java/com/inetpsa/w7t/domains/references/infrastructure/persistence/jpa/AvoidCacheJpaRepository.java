/*
 * Creation : 17 Feb 2021
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.UUID;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository;
import com.inetpsa.w7t.domains.references.model.AvoidCache;

/**
 * The Class AvoidCacheJpaRepository.
 */
public class AvoidCacheJpaRepository extends BaseJpaRepository<AvoidCache, UUID> implements AvoidCacheRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String client) {
        Query query = entityManager.createNativeQuery("select * from W7TQTCAC where CLIENT = ? ", AvoidCache.class);
        query.setParameter(1, client);
        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository#getAdcValueByClient(java.lang.String)
     */
    @Override
    public boolean getAdcValueByClient(String client) {
        Query query = entityManager.createNativeQuery("select AVOIDCACHE from W7TQTCAC where CLIENT = ? ");
        query.setParameter(1, client);
        return (boolean) query.getSingleResult();
    }

}
