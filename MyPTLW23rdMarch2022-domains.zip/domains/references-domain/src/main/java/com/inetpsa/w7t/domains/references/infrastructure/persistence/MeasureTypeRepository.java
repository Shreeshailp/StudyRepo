/*
 * Creation : 24 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;

/**
 * The Interface MeasureTypeRepository. This repository is used to retrieve and save any {@link MeasureType} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface MeasureTypeRepository extends GenericRepository<MeasureType, UUID> {
    /**
     * Read all MeasureType from the database.
     *
     * @return the list of MeasureType read.
     */
    @Read
    List<MeasureType> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the MeasureType entity retrieved
     */
    @Read
    Optional<MeasureType> byCode(@MeasureTypeCode String code);

    /**
     * Guid by code.
     *
     * @param code the code
     * @return the optional
     */
    @Read
    Optional<UUID> guidByCode(@MeasureTypeCode String code);

    /**
     * Check that the MeasureType identified by the specified code exists.
     *
     * @param code the MeasureType code
     * @return true if the MeasureType exists, false otherwise.
     */
    @Read
    boolean exists(@MeasureTypeCode String code);

    /**
     * Rounding digit by code.
     *
     * @param code the code
     * @return the int
     */
    @Read
    int roundingDigitByCode(@MeasureTypeCode String code);
}
