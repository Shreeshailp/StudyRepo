/*
 * Creation : 18 Aug 2021
 */
package com.inetpsa.w7t.domains.wltphub.answer.services;

import java.util.List;

import org.seedstack.business.Service;

/**
 * The Interface WltpHubAnswerService.
 */
@Service
public interface WltpHubAnswerService {

    /**
     * Save wltp hub answer.
     *
     * @param <T> the generic type
     * @param requestId the request id
     * @param internalFileId the internal file id
     * @param t the t
     */
    public <T> void saveWltpHubAnswer(String requestId, String internalFileId, T t);

    /**
     * Gets the wltp hub answer by request id and file id.
     *
     * @param <T> the generic type
     * @param requestId the request id
     * @param internalFileId the internal file id
     * @param clazz the clazz
     * @return the wltp hub answer by request id and file id
     */
    public <T> T getWltpHubAnswerByRequestIdAndFileId(String requestId, String internalFileId, Class<T> clazz);

    /**
     * Gets the all wltp hub answers.
     *
     * @param <T> the generic type
     * @param internalFileId the internal file id
     * @param clazz the clazz
     * @return the all wltp hub answers
     */
    <T> List<T> getAllWltpHubAnswers(String internalFileId, Class<T> clazz);

}
