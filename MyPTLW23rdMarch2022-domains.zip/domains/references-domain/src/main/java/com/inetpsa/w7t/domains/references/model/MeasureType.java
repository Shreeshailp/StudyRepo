/*
 * Creation : 1 févr. 2017
 */
package com.inetpsa.w7t.domains.references.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.references.validation.MeasureTypeCode;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeRoundingDigits;
import com.inetpsa.w7t.domains.references.validation.MeasureTypeSort;

/**
 * The Class MeasureType. This aggregate represents the type of a MeasureValue.
 */
@Entity
@Table(name = "W7TQTMTP")
public class MeasureType extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code. */
    @MeasureTypeCode
    @Column(name = "CODE")
    private String code;

    /** The sort. */
    @MeasureTypeSort
    @Column(name = "SORT")
    private Integer sort;

    /** The rounding digits. */
    @MeasureTypeRoundingDigits
    @Column(name = "ROUNDINGDIGITS")
    private Integer roundingDigits;

    /** The label. */
    @Transient
    private String label;

    /** The vehicle types. */
    @NotNull
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTMVT", joinColumns = @JoinColumn(name = "MEASURE_TYPE", referencedColumnName = "ID"))
    @Column(name = "VEHICLE_TYPE")
    @Type(type = "uuid-char")
    private List<UUID> vehicleTypes;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof MeasureType))
            return false;

        MeasureType other = (MeasureType) o;
        String hash = new StringBuilder(code).append(sort).append(roundingDigits).toString();
        String otherHash = new StringBuilder(other.code).append(other.sort).append(other.roundingDigits).toString();
        return hash.equals(otherHash) && vehicleTypes.equals(other.vehicleTypes);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + code.hashCode();
        hashcode = hashcode * 31 + sort.hashCode();
        hashcode = hashcode * 31 + roundingDigits.hashCode();
        return hashcode * 31 + vehicleTypes.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the sort.
     *
     * @return the sort
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * Sets the sort.
     *
     * @param sort the new sort
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * Gets the rounding digits.
     *
     * @return the rounding digits
     */
    public Integer getRoundingDigits() {
        return roundingDigits;
    }

    /**
     * Sets the rounding digits.
     *
     * @param roundingDigits the new rounding digits
     */
    public void setRoundingDigits(Integer roundingDigits) {
        this.roundingDigits = roundingDigits;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the vehicle types.
     *
     * @return the vehicle types
     */
    public List<UUID> getVehicleTypes() {
        return vehicleTypes;
    }

    /**
     * Sets the vehicle types.
     *
     * @param vehicleTypes the new vehicle types
     */
    public void setVehicleTypes(List<UUID> vehicleTypes) {
        this.vehicleTypes = vehicleTypes;
    }
}
