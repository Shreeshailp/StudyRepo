/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseValueObject;

/**
 * The Class LabelKey. This Value-Object is used to represent a identifier of a {@link Label}.
 * 
 * @see Label
 */
@Embeddable
public class LabelKey extends BaseValueObject {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8411364280887128389L;

    /** The key. */
    @NotNull
    @Type(type = "uuid-char")
    @Column(name = "LABEL_KEY")
    private UUID key;

    /** The locale. */
    @NotNull
    @Size(min = 5, max = 5)
    @Column(name = "LOCALE")
    private String locale;

    public LabelKey() {
        // For JPA
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object other) {
        if (other instanceof LabelKey) {
            String hash = new StringBuilder(locale).append(key).toString();
            String otherHash = new StringBuilder(((LabelKey) other).locale).append(((LabelKey) other).key).toString();
            return hash.equals(otherHash);
        }
        return false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#hashCode()
     */
    @Override
    public int hashCode() {
        String hash = new StringBuilder(locale).append(key).toString();
        return hash.hashCode();
    }

    public UUID getKey() {
        return key;
    }

    public void setKey(UUID key) {
        this.key = key;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseValueObject#toString()
     */
    @Override
    public String toString() {
        return new StringBuilder(locale).append("-").append(key).toString();
    }

}
