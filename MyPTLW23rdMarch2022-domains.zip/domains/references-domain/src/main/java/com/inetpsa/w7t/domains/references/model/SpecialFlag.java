/*
 * Creation : 12 Jul 2019
 */
package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

@Entity
@Table(name = "W7TQTSPE")
public class SpecialFlag extends BaseAggregateRoot<UUID> {
    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "CODE_SPECIAL")
    private String codeSpecial;

    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getCodeSpecial() {
        return codeSpecial;
    }

    public void setCodeSpecial(String codeSpecial) {
        this.codeSpecial = codeSpecial;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((codeSpecial == null) ? 0 : codeSpecial.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        SpecialFlag other = (SpecialFlag) obj;
        if (codeSpecial == null) {
            if (other.codeSpecial != null)
                return false;
        } else if (!codeSpecial.equals(other.codeSpecial))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "SpecialFlag [guid=" + guid + ", codeSpecial=" + codeSpecial + "]";
    }

}
