/*
 * Creation : 5 Feb 2020
 */
package com.inetpsa.w7t.domains.client.prd.services;

import javax.inject.Inject;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.ClientPRDRepository;

/**
 * The Class ClientPRDServiceImpl.
 */
public class ClientPRDServiceImpl implements ClientPRDService {

    /** The client PRD repository. */
    @Inject
    private ClientPRDRepository clientPRDRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.client.prd.services.ClientPRDService#getClientByPRD(java.lang.String)
     */
    @Override
    public String getClientByPRD(String prd) {
        String client = null;
        if (clientPRDRepository != null) {
            client = clientPRDRepository.getClientByPRD(prd);
        }
        return client;
    }

}
