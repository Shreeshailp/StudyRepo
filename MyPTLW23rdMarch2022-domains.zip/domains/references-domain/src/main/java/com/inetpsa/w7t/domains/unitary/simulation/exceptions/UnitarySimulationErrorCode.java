/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.domains.unitary.simulation.exceptions;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum UnitarySimulationErrorCode.
 */
public enum UnitarySimulationErrorCode implements ErrorCode {

    /** The indus maintainance error. */
    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    /** The service unavailable error. */
    SERVICE_UNAVAILABLE_ERROR(621,
            "Service Unavailable.The server is temporarily unable to service your request due to maintenance downtime or capacity problems. Please try again later."),
    UNKNOWN_TECHNICAL_EXCEPTION(701, "Technical issue while calling WLTPHUB", "ERRW701"), SERVER_ERROR(622, "HUB Server error.");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Getter code.
     *
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * Getter description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Getter ruleCode.
     *
     * @return the ruleCode
     */
    public String getRuleCode() {
        return ruleCode;
    }

    /**
     * Instantiates a new unitary simulation error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    UnitarySimulationErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Instantiates a new unitary simulation error code.
     *
     * @param code        the code
     * @param description the description
     */
    UnitarySimulationErrorCode(int code, String description) {
        this.code = code;
        this.description = description;
    }

}
