/*
 * Creation : 9 févr. 2017
 */
package com.inetpsa.w7t.domains.references.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

/**
 * The Interface PayloadPercentageValue. This validation annotation is used validate the {@link PayloadPercentageValue} {@code value}.
 */
@NotNull
@Digits(integer = 2, fraction = 0)
@Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD })
@Constraint(validatedBy = {})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface PayloadPercentageValue {

    /**
     * Message.
     *
     * @return the message
     */
    String message() default "{com.inetpsa.w7t.validation.constraints.PayloadPercentageValue.message}";

    /**
     * Groups.
     *
     * @return the groups
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the payload
     */
    Class<? extends Payload>[] payload() default {};
}
