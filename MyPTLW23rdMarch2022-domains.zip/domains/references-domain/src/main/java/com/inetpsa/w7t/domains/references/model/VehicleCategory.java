/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.domains.references.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.type.descriptor.sql.JdbcTypeFamilyInformation.Family;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.references.validation.VehicleCategoryCode;

/**
 * The Class VehicleCategory. This aggregate represents the vehicle category of a {@link Family}.
 */
@Entity
@Table(name = "W7TQTCAT")
public class VehicleCategory extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code. */
    @VehicleCategoryCode
    @Column(name = "CODE")
    private String code;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof VehicleCategory))
            return false;

        return code.equals(((VehicleCategory) o).code);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        return super.hashCode() * 31 + code.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

}
