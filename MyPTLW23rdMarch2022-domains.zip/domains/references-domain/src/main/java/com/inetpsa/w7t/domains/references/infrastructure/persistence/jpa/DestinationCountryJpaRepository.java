/*
 * Creation : 6 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;

import javax.cache.annotation.CacheResult;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.model.DestinationCountry;

/**
 * @author E534811
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class DestinationCountryJpaRepository extends BaseJpaRepository<DestinationCountry, UUID> implements DestinationCountryRepository {

    private static final String COUNTRY_ID = "counryId";
    private static final String DESTINATION_ID = "destinationId";

    @Override
    @CacheResult(cacheName = "destinationListByCountryId")
    public List<DestinationCountry> byCountryId(UUID guid) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DestinationCountry> q = cb.createQuery(aggregateRootClass);
        Root<DestinationCountry> root = q.from(aggregateRootClass);
        q.multiselect(root.get(COUNTRY_ID), root.get(DESTINATION_ID));
        q.where(cb.equal(root.get(COUNTRY_ID), cb.parameter(UUID.class, COUNTRY_ID)));

        TypedQuery<DestinationCountry> query = entityManager.createQuery(q);
        query.setParameter(COUNTRY_ID, guid);

        return query.getResultList();
    }

    @Override
    public List<DestinationCountry> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<DestinationCountry> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<DestinationCountry> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

}
