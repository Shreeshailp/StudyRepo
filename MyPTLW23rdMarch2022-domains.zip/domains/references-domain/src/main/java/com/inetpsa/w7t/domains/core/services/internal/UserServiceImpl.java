/*
 * Creation : 21 avr. 2017
 */
package com.inetpsa.w7t.domains.core.services.internal;

import org.seedstack.seed.Logging;
import org.seedstack.seed.security.SecuritySupport;
import org.seedstack.seed.security.principals.Principals;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.core.services.UserService;

/**
 * The Class UserServiceImpl. This implementation uses a {@link SecuritySupport} to access the current connected user in order to fetch information
 * about the user like the User ID.
 */
public class UserServiceImpl implements UserService {

    /** The Constant DEFAULT_ID. */
    private static final String DEFAULT_ID = "DEV";

    /** The logger. */
    @Logging
    private Logger logger;

    /** The security support. */
    @Inject
    private SecuritySupport securitySupport;

    @Override
    public String getUserId() {

        String userId;
        try {
            userId = securitySupport.getSimplePrincipalByName(Principals.IDENTITY).getValue();
        } catch (Exception e) {
            logger.warn("Exception while trying to access current connected user");
            logger.debug("Current connected user exception", e);
            userId = DEFAULT_ID;
        }
        return userId;

    }

}
