/*

 * Creation : 14 avr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;

/**
 * The Class GrossVehicleMassJpaRepository.
 */
public class GrossVehicleMassJpaRepository extends BaseJpaRepository<GrossVehicleMass, UUID> implements GrossVehicleMassRepository {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant FAMILY. */
    private static final String FAMILY = "family";

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant CHARACTERISTIC. */
    private static final String CHARACTERISTIC = "characteristic";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository#byFamilyCodeAndCharacteristic(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public Optional<GrossVehicleMass> byFamilyCodeAndCharacteristic(String family, String code, String characteristic) {
        // WltpCacheManager<GrossVehicleMass> wltpCacheManager = WltpCacheManager.getInstance(GrossVehicleMass.class);
        // String key = family + "_" + code + "_" + characteristic;
        // Optional<GrossVehicleMass> grossVehicleMass = wltpCacheManager.getOptinalItem(key);
        // if (grossVehicleMass != null && grossVehicleMass.isPresent()) {
        // return grossVehicleMass;
        // }
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GrossVehicleMass> q = cb.createQuery(aggregateRootClass);
        Root<GrossVehicleMass> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FAMILY), cb.parameter(String.class, FAMILY)), cb.equal(root.get(CODE), cb.parameter(String.class, CODE)),
                cb.equal(root.get(CHARACTERISTIC), cb.parameter(String.class, CHARACTERISTIC)));

        TypedQuery<GrossVehicleMass> query = entityManager.createQuery(q);
        query.setParameter(FAMILY, family);
        query.setParameter(CODE, code);
        query.setParameter(CHARACTERISTIC, characteristic);
        // grossVehicleMass = query.getResultList().stream().findFirst();
        // wltpCacheManager.putOptinalItem(key, grossVehicleMass);
        // return grossVehicleMass;

        return query.getResultList().stream().findFirst();

    }

    /**
     * performance change {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository#getValueByFamilyCodeAndCharacteristic(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public Optional<String> getValueByFamilyCodeAndCharacteristic(String family, String code, String characteristic) {

        Query query = entityManager.createNativeQuery(
                "SELECT gvm.VALUE FROM W7TQTGVM gvm WHERE gvm.FAMILY = :FAMILY AND gvm.CODE = :CODE AND gvm.CHARACTERISTIC = :CHARACTERISTIC");
        query.setParameter("FAMILY", family);
        query.setParameter("CODE", code);
        query.setParameter("CHARACTERISTIC", characteristic);
        return Optional.ofNullable((String) query.getSingleResult());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository#isDefined(java.lang.String, java.lang.String,
     *      java.lang.String)
     */
    @Override
    /* @CacheResult(cacheName = "gvmByFamilyAndCodeExistenceCache") */
    public boolean isDefined(String family, String code, String characteristic) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GrossVehicleMass> q = cb.createQuery(aggregateRootClass);
        Root<GrossVehicleMass> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FAMILY), cb.parameter(String.class, FAMILY)), cb.equal(root.get(CODE), cb.parameter(String.class, CODE)),
                cb.equal(root.get(CHARACTERISTIC), cb.parameter(String.class, CHARACTERISTIC)));

        TypedQuery<GrossVehicleMass> query = entityManager.createQuery(q);
        query.setParameter(FAMILY, family);
        query.setParameter(CODE, code);
        query.setParameter(CHARACTERISTIC, characteristic);

        return query.getResultList().stream().map(GrossVehicleMass::getValue).anyMatch(v -> {
            try {
                if ("T3S".equals(characteristic))
                    return Integer.parseInt(v) >= 0;
                return Integer.parseInt(v) > 0;
            } catch (NumberFormatException e) {
                logger.trace("Parsing of Mass value for Family=[{}], Code=[{}] and Characteristic=[{}] failed", family, code, characteristic, e);
                return false;
            }
        });
    }

}
