/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.ConversionDataTypeRepository;
import com.inetpsa.w7t.domains.references.model.ConversionDataType;

/**
 * The Class ConversionDataTypeJpaRepository.
 */
public class ConversionDataTypeJpaRepository extends BaseJpaRepository<ConversionDataType, UUID> implements ConversionDataTypeRepository {

    /** The Constant ROAD_LOAD_TYPE. */
    private static final String DATA_TYPE = "dataType";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    private static Map<String, Boolean> cdtMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ConversionDataTypeRepository#all()
     */
    @Override
    public List<ConversionDataType> all() {

        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ConversionDataType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<ConversionDataType> q = entityManager.createQuery(criteriaQuery);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.ConversionDataTypeRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String dataType) {
        if (cdtMap.get(dataType) != null)
            return cdtMap.get(dataType);

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<ConversionDataType> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(DATA_TYPE), cb.parameter(String.class, DATA_TYPE)));
        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(DATA_TYPE, dataType);
        Boolean cdtFlag = query.getResultList().stream().findFirst().isPresent();
        cdtMap.put(dataType, cdtFlag);
        return cdtFlag;

    }

}
