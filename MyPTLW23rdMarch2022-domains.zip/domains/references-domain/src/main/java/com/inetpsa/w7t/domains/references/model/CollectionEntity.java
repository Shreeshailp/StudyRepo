/*
 * Creation : 10 Aug 2020
 */
package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class CollectionEntity.
 */
@Entity
@Table(name = "W7TQTCOL")
public class CollectionEntity extends BaseAggregateRoot<UUID> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7667007823239194410L;

    /** The collection id. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID collectionId;

    /** The client. */
    @Column(name = "COL_NAME")
    private String collectionName;

    /** The client. */
    @Column(name = "USER_ID")
    private String userId;

    /** The collection requests. */
    @OneToMany(mappedBy = "collection", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CollectionRequestEntity> collectionRequests = new ArrayList<>();

    /** The type. */
    @Column(name = "TYPE")
    private String type;

    /**
     * Instantiates a new collection entity.
     */
    public CollectionEntity() {
        // Empty Constructor
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.collectionId;
    }

    /**
     * Gets the collection id.
     *
     * @return the collection id
     */
    public UUID getCollectionId() {
        return collectionId;
    }

    /**
     * Sets the collection id.
     *
     * @param collectionId the new collection id
     */
    public void setCollectionId(UUID collectionId) {
        this.collectionId = collectionId;
    }

    /**
     * Gets the collection name.
     *
     * @return the collection name
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * Sets the collection name.
     *
     * @param collectionName the new collection name
     */
    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user id.
     *
     * @param userId the new user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the collection requests.
     *
     * @return the collection requests
     */
    public List<CollectionRequestEntity> getCollectionRequests() {
        return collectionRequests;
    }

    /**
     * Sets the collection requests.
     *
     * @param collectionRequests the new collection requests
     */
    public void setCollectionRequests(List<CollectionRequestEntity> collectionRequests) {
        this.collectionRequests = collectionRequests;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((collectionId == null) ? 0 : collectionId.hashCode());
        result = prime * result + ((collectionName == null) ? 0 : collectionName.hashCode());
        result = prime * result + ((collectionRequests == null) ? 0 : collectionRequests.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        CollectionEntity other = (CollectionEntity) obj;
        if (collectionId == null) {
            if (other.collectionId != null)
                return false;
        } else if (!collectionId.equals(other.collectionId))
            return false;
        if (collectionName == null) {
            if (other.collectionName != null)
                return false;
        } else if (!collectionName.equals(other.collectionName))
            return false;
        if (collectionRequests == null) {
            if (other.collectionRequests != null)
                return false;
        } else if (!collectionRequests.equals(other.collectionRequests))
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        return true;
    }

    /**
     * Adds the request.
     *
     * @param requestEntity the request entity
     */
    public void addRequest(CollectionRequestEntity requestEntity) {
        requestEntity.setCollection(this);
        collectionRequests.add(requestEntity);
    }

}
