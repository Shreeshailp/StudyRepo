package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.EnergyEfficiencyRepository;
import com.inetpsa.w7t.domains.references.model.EnergyEfficiency;

/**
 * The Class EnergyEfficiencyJpaRepository.
 */
public class EnergyEfficiencyJpaRepository extends BaseJpaRepository<EnergyEfficiency, UUID> implements EnergyEfficiencyRepository {

    /** The Constant CRR. */
    private static final String CRR = "crr";

    private static ConcurrentHashMap<String, String> energyEfficiencyMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.EnergyEfficiencyRepository#all()
     */
    @Override
    public List<EnergyEfficiency> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<EnergyEfficiency> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<EnergyEfficiency> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.EnergyEfficiencyRepository#getEnergyClassByValue(java.lang.Double)
     */
    @Override

    public String getEnergyClassByValue(Double value) {

        String key = CRR;
        String key1 = "CrrValue";
        String energyClassByValue = energyEfficiencyMap.get(key);
        String valueStr = energyEfficiencyMap.get(key1);
        boolean isValueInCache = false;
        if (valueStr != null && !valueStr.isEmpty() && value != null && valueStr.equals(String.valueOf(value))) {
            isValueInCache = true;
        }
        if (energyClassByValue != null && isValueInCache) {
            return energyClassByValue;
        }
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<EnergyEfficiency> q = cb.createQuery(EnergyEfficiency.class);
        Root<EnergyEfficiency> energyEfficiency = q.from(EnergyEfficiency.class);
        q.where(cb.equal(energyEfficiency.get(CRR), cb.parameter(Double.class, CRR)));

        TypedQuery<EnergyEfficiency> query = entityManager.createQuery(q);
        query.setParameter(CRR, value);
        energyClassByValue = query.getResultList().stream().findFirst().map(EnergyEfficiency::getEeClass).orElse(" ");
        energyEfficiencyMap.put(key, energyClassByValue);
        if (value != null)
            energyEfficiencyMap.put(key1, value.toString());
        // else
        // energyEfficiencyMap.put(key1, null);
        return energyClassByValue;
    }

}
