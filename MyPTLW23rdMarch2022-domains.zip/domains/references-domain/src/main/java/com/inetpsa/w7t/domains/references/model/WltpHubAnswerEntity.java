/*
 * Creation : 18 Aug 2021
 */
package com.inetpsa.w7t.domains.references.model;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class WltpHubAnswerEntity.
 */
@Entity
@Table(name = "W7TQTWHA")
public class WltpHubAnswerEntity extends BaseAggregateRoot<UUID> implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -6138194968278977984L;

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The json answer. */
    @Column(name = "ANSWER")
    private String jsonAnswer;

    /** The request id. */
    @Column(name = "REQUEST_ID")
    private String requestId;

    /** The internal file id. */
    @Column(name = "INTERNAL_FILE_ID")
    private String internalFileId;

    /** The created date. */
    @Column(name = "CREATED_DATE")
    private String createdDate;

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the json answer.
     *
     * @return the json answer
     */
    public String getJsonAnswer() {
        return jsonAnswer;
    }

    /**
     * Sets the json answer.
     *
     * @param jsonAnswer the new json answer
     */
    public void setJsonAnswer(String jsonAnswer) {
        this.jsonAnswer = jsonAnswer;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the internal file id.
     *
     * @return the internal file id
     */
    public String getInternalFileId() {
        return internalFileId;
    }

    /**
     * Sets the internal file id.
     *
     * @param internalFileId the new internal file id
     */
    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((internalFileId == null) ? 0 : internalFileId.hashCode());
        result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        WltpHubAnswerEntity other = (WltpHubAnswerEntity) obj;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (internalFileId == null) {
            if (other.internalFileId != null)
                return false;
        } else if (!internalFileId.equals(other.internalFileId))
            return false;
        if (requestId == null) {
            if (other.requestId != null)
                return false;
        } else if (!requestId.equals(other.requestId))
            return false;
        return true;
    }

}
