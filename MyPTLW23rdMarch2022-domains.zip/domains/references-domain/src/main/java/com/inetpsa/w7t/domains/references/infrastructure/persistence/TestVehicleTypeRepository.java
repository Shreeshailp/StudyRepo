/*
 * Creation : 27 févr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.TestVehicleType;
import com.inetpsa.w7t.domains.references.validation.TestVehicleTypeCode;

/**
 * The Interface TestVehicleTypeRepository. This repository is used to retrieve and save any {@link TestVehicleType} entities.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface TestVehicleTypeRepository extends GenericRepository<TestVehicleType, UUID> {
    /**
     * Read all TestVehicleType from the database.
     *
     * @return the list of TestVehicleType read.
     */
    @Read
    List<TestVehicleType> all();

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate code
     * @return the TestVehicleType entity retrieved
     */
    @Read
    Optional<TestVehicleType> byCode(@TestVehicleTypeCode String code);

    /**
     * Guid by code.
     *
     * @param code the code
     * @return the optional
     */
    @Read
    Optional<UUID> guidByCode(@TestVehicleTypeCode String code);

    /**
     * Check that the TestVehicleType identified by the specified code exists.
     *
     * @param code the @TestVehicleTypeCode code
     * @return true if the TestVehicleType exists, false otherwise.
     */
    @Read
    boolean exists(@TestVehicleTypeCode String code);
}
