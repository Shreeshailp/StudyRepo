/*
 * Creation : 12 janv. 2017
 */
package com.inetpsa.w7t.domains.core.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.core.infrastructure.persistence.LabelRepository;
import com.inetpsa.w7t.domains.core.model.Label;
import com.inetpsa.w7t.domains.core.model.LabelKey;

/**
 * The Class LabelJpaRepository. JPA Implementation of {@link LabelRepository}.
 */
public class LabelJpaRepository extends BaseJpaRepository<Label, LabelKey> implements LabelRepository {

    /** The Constant KEY. */
    private static final String KEY = "key";

    /** The Constant LOCALE. */
    private static final String LOCALE = "locale";

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.core.infrastructure.persistence.LabelRepository#byKeyAndLocale(java.util.UUID, java.lang.String)
     */
    @Override
    public Optional<Label> byKeyAndLocale(UUID key, String locale) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Label> q = cb.createQuery(aggregateRootClass);
        Root<Label> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(KEY).get(KEY), cb.parameter(UUID.class, KEY)),
                cb.like(root.get(KEY).get(LOCALE), cb.parameter(String.class, LOCALE)));

        TypedQuery<Label> query = entityManager.createQuery(q);
        query.setParameter(KEY, key);
        query.setParameter(LOCALE, locale.toLowerCase() + "-%");

        logger.debug("Fetching internationalized label for the key '{}' and the locale '{}'", key, locale);

        List<Label> list = query.getResultList();
        Optional<Label> label = Optional.empty();
        if (!list.isEmpty()) {
            label = list.stream().findFirst();
        }
        if (!label.isPresent())
            logger.warn("No internationalized label was found for the key '{}' and the locale '{}'", key, locale);

        return label;
    }

}
