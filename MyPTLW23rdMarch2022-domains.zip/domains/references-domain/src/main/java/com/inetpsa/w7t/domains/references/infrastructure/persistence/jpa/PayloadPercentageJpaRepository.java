/*
 * Creation : 14 avr. 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.NotImplementedException;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.PayloadPercentageRepository;
import com.inetpsa.w7t.domains.references.model.PayloadPercentage;

public class PayloadPercentageJpaRepository extends BaseJpaRepository<PayloadPercentage, UUID> implements PayloadPercentageRepository {

    /** The Constant CODE. */
    private static final String CATEGORY = "category";
    private static final String VALIDITY_START = "validityStart";
    private static final String VALIDITY_END = "validityEnd";

    /** The logger. */
    @Logging
    private Logger logger;

    private static ConcurrentHashMap<String, PayloadPercentage> payloadMap = new ConcurrentHashMap<>();

    @Override
    public Optional<PayloadPercentage> byCategoryAndDate(String category, LocalDate date) {
        String key = category;
        PayloadPercentage tempPayloadPercentage = payloadMap.get(key);
        Optional<PayloadPercentage> payloadPercentage = Optional.ofNullable(tempPayloadPercentage);
        if (payloadPercentage.isPresent()) {
            // Added the below if block as part of the JIRA-654 fix.
            PayloadPercentage pp = payloadPercentage.get();
            LocalDate dbStartDate = pp.getValidityStart();
            if (date.isBefore(dbStartDate)) {
                logger.info("Ecom date[{}] is before the start date[{}] of database", date, dbStartDate);
            } else {
                return payloadPercentage;
            }
        }
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayloadPercentage> q = cb.createQuery(aggregateRootClass);
        Root<PayloadPercentage> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CATEGORY), cb.parameter(String.class, CATEGORY)),
                cb.greaterThanOrEqualTo(cb.parameter(LocalDate.class, VALIDITY_START), root.get(VALIDITY_START)),
                cb.lessThanOrEqualTo(cb.parameter(LocalDate.class, VALIDITY_END), root.get(VALIDITY_END)));

        TypedQuery<PayloadPercentage> query = entityManager.createQuery(q);
        query.setParameter(CATEGORY, category);
        query.setParameter(VALIDITY_START, date);
        query.setParameter(VALIDITY_END, date);

        List<PayloadPercentage> percentages = query.getResultList();
        payloadPercentage = query.getResultList().stream().findFirst();
        if (payloadPercentage.isPresent()) {
            payloadMap.put(key, payloadPercentage.get());
        }
        if (percentages.size() > 1)
            throw new IllegalStateException("Too many payload percentages found");

        return payloadPercentage;
    }

    @Override
    public List<PayloadPercentage> byCategory(String category) {
        throw new NotImplementedException("PayloadPercentageJpaRepository.byCategory() not implemented");
    }

}
