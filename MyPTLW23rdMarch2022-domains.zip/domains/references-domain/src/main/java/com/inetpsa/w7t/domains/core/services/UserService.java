/*
 * Creation : 21 avr. 2017
 */
package com.inetpsa.w7t.domains.core.services;

import org.seedstack.business.Service;

/**
 * The Interface UserService. This service is used to retrieve information about the User of the system.
 */
@Service
@FunctionalInterface
public interface UserService {

    /**
     * Fetch the User ID for the current user.
     *
     * @return the user id of the user
     */
    String getUserId();

}
