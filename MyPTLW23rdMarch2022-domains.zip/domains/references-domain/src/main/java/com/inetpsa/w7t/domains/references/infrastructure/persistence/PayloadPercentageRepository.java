/*
 * Creation : 30 mars 2017
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.PayloadPercentage;
import com.inetpsa.w7t.domains.references.validation.VehicleCategoryCode;


/**
 * The Interface PayloadPercentageRepository.
 */
@Transactional(rollbackOn = IllegalStateException.class, rollbackOnParticipationFailure = false)
@JpaUnit("wltp-domain-jpa-unit")
public interface PayloadPercentageRepository extends GenericRepository<PayloadPercentage, UUID> {

    /**
     * By category and date.
     *
     * @param category the category
     * @param date the date
     * @return the optional
     */
    Optional<PayloadPercentage> byCategoryAndDate(@VehicleCategoryCode String category, LocalDate date);

    /**
     * By category.
     *
     * @param category the category
     * @return the list
     */
    List<PayloadPercentage> byCategory(@VehicleCategoryCode String category);
}
