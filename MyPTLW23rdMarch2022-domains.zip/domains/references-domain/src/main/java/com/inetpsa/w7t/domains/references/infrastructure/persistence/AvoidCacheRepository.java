/*
 * Creation : 17 Feb 2021
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.references.model.AvoidCache;

/**
 * The Interface AvoidCacheRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface AvoidCacheRepository extends GenericRepository<AvoidCache, UUID> {

    /**
     * Exists.
     *
     * @param client the client
     * @return true, if successful
     */
    @Read
    boolean exists(String client);

    /**
     * Gets the adc value by client.
     *
     * @param client the client
     * @return the adc value by client
     */
    public boolean getAdcValueByClient(String client);

}
