/*
 * Creation : 2 févr. 2017
 */
package com.inetpsa.w7t.domains.references.model;

import java.time.LocalDate;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.references.validation.PayloadPercentageValue;
import com.inetpsa.w7t.domains.references.validation.ValidPayloadPercentageValidityDates;
import com.inetpsa.w7t.domains.references.validation.VehicleCategoryCode;

/**
 * The Class PayloadPercentage. This aggregate represents the payload percentage of a {@link VehicleCategory} during a period.
 */
@ValidPayloadPercentageValidityDates
@Entity
@Table(name = "W7TQTPLP")
public class PayloadPercentage extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The vehicle category. */
    @VehicleCategoryCode
    @Column(name = "VEHICLE_CATEGORY")
    private String category;

    /** The percentage value. */
    @PayloadPercentageValue
    @Column(name = "VALUE")
    private Integer value;

    /** The validity start date. */
    @NotNull
    @Column(name = "START_VALIDITY")
    private LocalDate validityStart;

    /** The validity end date. */
    @NotNull
    @Column(name = "END_VALIDITY")
    private LocalDate validityEnd;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof PayloadPercentage))
            return false;

        PayloadPercentage other = (PayloadPercentage) o;
        String hash = new StringBuilder(category).append(value).append(validityStart).append(validityEnd).toString();
        String otherHash = new StringBuilder(other.category).append(other.value).append(other.validityStart).append(other.validityEnd).toString();
        return hash.equals(otherHash);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + category.hashCode();
        hashcode = hashcode * 31 + value.hashCode();
        hashcode = hashcode * 31 + validityStart.hashCode();
        return hashcode * 31 + validityEnd.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the vehicle category.
     *
     * @return the vehicle category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the vehicle category.
     *
     * @param category the new vehicle category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Gets the percentage value.
     *
     * @return the percentage value
     */
    public Integer getValue() {
        return value;
    }

    /**
     * Sets the percentage value.
     *
     * @param value the new percentage value
     */
    public void setValue(Integer value) {
        this.value = value;
    }

    /**
     * Gets the validity start date.
     *
     * @return the validity start date
     */
    public LocalDate getValidityStart() {
        return validityStart;
    }

    /**
     * Sets the validity start date.
     *
     * @param validityStart the new validity start date
     */
    public void setValidityStart(LocalDate validityStart) {
        this.validityStart = validityStart;
    }

    /**
     * Gets the validity end date.
     *
     * @return the validity end date
     */
    public LocalDate getValidityEnd() {
        return validityEnd;
    }

    /**
     * Sets the validity end date.
     *
     * @param validityEnd the new validity end date
     */
    public void setValidityEnd(LocalDate validityEnd) {
        this.validityEnd = validityEnd;
    }

}
