/*
 * Creation : 24 Sep 2018
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.infrastructure.persistence.RoadLoadTypeRepository;
import com.inetpsa.w7t.domains.references.model.RoadLoadType;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;

public class RoadLoadTypeJpaRepository extends BaseJpaRepository<RoadLoadType, UUID> implements RoadLoadTypeRepository {

    /** The Constant ROAD_LOAD_TYPE. */
    private static final String ROAD_LOAD_TYPE = "roadLoadType";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    @Override
    public List<RoadLoadType> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<RoadLoadType> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));

        TypedQuery<RoadLoadType> q = entityManager.createQuery(criteriaQuery);

        return q.getResultList();
    }

    @Override
    public Optional<RoadLoadType> byroadLoadType(@VehicleRoadLoadType String roadLoadType) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<RoadLoadType> q = cb.createQuery(RoadLoadType.class);
        Root<RoadLoadType> root = q.from(RoadLoadType.class);
        q.where(cb.equal(root.get(ROAD_LOAD_TYPE), cb.parameter(String.class, ROAD_LOAD_TYPE)));
        TypedQuery<RoadLoadType> query = entityManager.createQuery(q);
        query.setParameter(ROAD_LOAD_TYPE, roadLoadType);
        return query.getResultList().stream().findFirst();
    }

    @Override
    public boolean exists(@VehicleRoadLoadType String roadLoadType) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<RoadLoadType> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(ROAD_LOAD_TYPE), cb.parameter(String.class, ROAD_LOAD_TYPE)));
        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(ROAD_LOAD_TYPE, roadLoadType);
        return query.getResultList().stream().findFirst().isPresent();

    }

}
