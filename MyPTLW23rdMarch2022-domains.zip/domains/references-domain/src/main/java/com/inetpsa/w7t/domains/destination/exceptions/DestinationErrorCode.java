/*
 * Creation : 16 Aug 2019
 */
package com.inetpsa.w7t.domains.destination.exceptions;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum DestinationErrorCode.
 */
public enum DestinationErrorCode implements ErrorCode {

    /** The indus maintainance error. */
    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Getter code.
     *
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * Getter description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Getter ruleCode.
     *
     * @return the ruleCode
     */
    public String getRuleCode() {
        return ruleCode;
    }

    /**
     * Instantiates a new destination error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    DestinationErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

}
