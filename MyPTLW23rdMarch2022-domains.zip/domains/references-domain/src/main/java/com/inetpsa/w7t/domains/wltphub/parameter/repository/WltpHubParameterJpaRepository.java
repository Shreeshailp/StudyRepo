/*
 * Creation : 16 Mar 2021
 */
package com.inetpsa.w7t.domains.wltphub.parameter.repository;

import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.WltpHubParameterEntity;

/**
 * The Class WltpHubParameterJpaRepository.
 */
public class WltpHubParameterJpaRepository extends BaseJpaRepository<WltpHubParameterEntity, UUID> implements WltpHubParameterRepository {

    /** The Constant CLIENT. */
    private static final String CLIENT = "client";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.wltphub.parameter.repository.WltpHubParameterRepository#getCodeByClient(java.lang.String)
     */
    @Override
    public String getCodeByClient(String client) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<WltpHubParameterEntity> q = cb.createQuery(aggregateRootClass);
        Root<WltpHubParameterEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)));

        TypedQuery<WltpHubParameterEntity> query = entityManager.createQuery(q);
        query.setParameter(CLIENT, client);
        WltpHubParameterEntity wltpHubParameterEntity = query.getResultList().get(0);
        return wltpHubParameterEntity.getCode();
    }

}
