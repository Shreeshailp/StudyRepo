/*
 * Creation : 13 Mar 2020
 */
package com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.references.model.MoteurEntity;

/**
 * The Class MoteurJpaRepository.
 */
public class MoteurJpaRepository extends BaseJpaRepository<MoteurEntity, UUID> implements MoteurRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.MoteurRepository#all()
     */
    @Override
    public List<MoteurEntity> all() {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<MoteurEntity> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        criteriaQuery.select(criteriaQuery.from(aggregateRootClass));
        TypedQuery<MoteurEntity> q = entityManager.createQuery(criteriaQuery);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.references.infrastructure.persistence.jpa.MoteurRepository#byMoteurCode(java.lang.String)
     */
    @Override
    public Optional<MoteurEntity> byMoteurCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MoteurEntity> q = cb.createQuery(aggregateRootClass);
        Root<MoteurEntity> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<MoteurEntity> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        return query.getResultList().stream().findFirst();
    }

}
