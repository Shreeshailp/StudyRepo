/*
 * Creation : 15 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.annotations.Type;

import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.MeasureType;
import com.inetpsa.w7t.domains.references.model.VehicleType;

@Embeddable
public class ParameterDetails {

    /**
     * The Vehicle Type.
     * 
     * @see VehicleType
     */
    @Type(type = "uuid-char")
    @Column(name = "VEHICLE_TYPE_ID")
    private UUID vehicleType;

    /**
     * The Measure Type.
     * 
     * @see MeasureType
     */
    @Type(type = "uuid-char")
    @Column(name = "MEASURE_TYPE_ID")
    private UUID measureType;

    /**
     * The phase code.
     * 
     * @see CyclePhase
     */
    @Type(type = "uuid-char")
    @Column(name = "CYCLE_PAHSE_ID")
    private UUID cyclePhase;

    @Column(name = "CONCERNED")
    private boolean concerned;

    public boolean isConcerned() {
        return concerned;
    }

    public void setConcerned(boolean concerned) {
        this.concerned = concerned;
    }

    public UUID getCyclePhase() {
        return cyclePhase;
    }

    public void setCyclePhase(UUID phase) {
        this.cyclePhase = phase;
    }

    public UUID getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(UUID vehicleType) {
        this.vehicleType = vehicleType;
    }

    public UUID getMeasureType() {
        return measureType;
    }

    public void setMeasureType(UUID measureType) {
        this.measureType = measureType;
    }

}
