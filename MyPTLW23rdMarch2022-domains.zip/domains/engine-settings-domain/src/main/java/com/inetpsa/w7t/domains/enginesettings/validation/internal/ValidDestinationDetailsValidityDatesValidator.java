/*
 * Creation : 4 avr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation.internal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.enginesettings.validation.ValidDestinationValidityDates;

public class ValidDestinationDetailsValidityDatesValidator implements ConstraintValidator<ValidDestinationValidityDates, DestinationDetails> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
     */
    @Override
    public void initialize(ValidDestinationValidityDates constraintAnnotation) {
        // This method is intentionally empty because there is nothing to initialize.
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
     */
    @Override
    public boolean isValid(DestinationDetails destination, ConstraintValidatorContext context) {
        if (destination == null)
            return true;

        return destination.getFromDate().isEqual(destination.getToDate()) || destination.getFromDate().isBefore(destination.getToDate());
    }

}
