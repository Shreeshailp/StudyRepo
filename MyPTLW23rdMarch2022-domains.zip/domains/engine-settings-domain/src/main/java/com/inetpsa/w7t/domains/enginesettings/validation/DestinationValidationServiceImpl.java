/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Class DestinationValidationServiceImpl.
 */
public class DestinationValidationServiceImpl implements DestinationValidationService {

    /** The policy. */
    @Inject
    private DestinationDetailsValidationPolicy policy;

    /** The invald destination label. */
    private static final String INVALD_DESTINATION_LABEL = "Une destination du même nom existe déjà, l’enregistrement n’a pas été effectué ";

    /** The invald country for dest. */
    private static final String INVALD_COUNTRY_FOR_DEST = "L’un des pays est déjà associé à une autre destination sur une même plage de dates, l’enregistrement n’a pas été effectué";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.validation.DestinationValidationService#validate(com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails)
     */
    @Override
    public void validate(DestinationDetails d) {
        if (!policy.isValidLabel(d))
            throw new InvalidDestinationException("R68", INVALD_DESTINATION_LABEL);
        if (!policy.isValidCountry(d))
            throw new InvalidDestinationException("R69", INVALD_COUNTRY_FOR_DEST);
        if (policy.isOverlapping(d))
            throw new InvalidDestinationException("R69", INVALD_COUNTRY_FOR_DEST);
    }

}
