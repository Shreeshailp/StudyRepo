/*
 * Creation : 21 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.model;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.enginesettings.validation.DestinationLabel;
import com.inetpsa.w7t.domains.enginesettings.validation.ValidDestinationValidityDates;

/**
 * The Class DestinationDetails. This represents Destination Details in the engine settings. This entity is used to fetch the parameter details and
 * countries
 */
@Entity
@Table(name = "W7TQTDES")
@ValidDestinationValidityDates
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class DestinationDetails extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    protected UUID guid;

    /** The label. */
    @DestinationLabel
    @Column(name = "LABEL")
    private String label;

    /** The from date. */
    @Column(name = "FROMDATE")
    private LocalDate fromDate;

    /** The to date. */
    @Column(name = "TODATE")
    private LocalDate toDate;

    /** The countries. */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTDCO", joinColumns = @JoinColumn(name = "DESTINATION_ID", referencedColumnName = "ID"))
    @Column(name = "COUNTRY_ID")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<String> countries;

    /** The parameter details. */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTPAD", joinColumns = @JoinColumn(name = "DESTINATION_ID"))
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<ParameterDetails> parameterDetails;

    public DestinationDetails() {
        // For JPA
    }

    public DestinationDetails(UUID guid) {
        this.guid = guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof DestinationDetails))
            return false;

        DestinationDetails other = (DestinationDetails) o;
        String hash = new StringBuilder(label).append(fromDate).append(toDate).toString();
        String otherHash = new StringBuilder(other.label).append(other.fromDate).append(other.toDate).toString();
        return hash.equals(otherHash) && countries.equals(other.countries) && parameterDetails.equals(other.parameterDetails);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + label.hashCode();
        hashcode = hashcode * 31 + fromDate.hashCode();
        hashcode = hashcode * 31 + toDate.hashCode();
        hashcode = hashcode * 31 + countries.hashCode();
        return hashcode * 31 + parameterDetails.hashCode();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the countries.
     *
     * @return the countries
     */
    public List<String> getCountries() {
        return countries;
    }

    /**
     * Sets the countries.
     *
     * @param countries the new countries
     */
    public void setCountries(List<String> countries) {
        this.countries = countries;
    }

    /**
     * Gets the parameter details.
     *
     * @return the parameter details
     */
    public List<ParameterDetails> getParameterDetails() {
        return parameterDetails;
    }

    /**
     * Sets the parameter details.
     *
     * @param parameterDetails the new parameter details
     */
    public void setParameterDetails(List<ParameterDetails> parameterDetails) {
        this.parameterDetails = parameterDetails;
    }

    /**
     * Gets the from date.
     *
     * @return the from date
     */
    public LocalDate getFromDate() {
        return fromDate;
    }

    /**
     * Sets the from date.
     *
     * @param fromDate the new from date
     */
    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * Gets the to date.
     *
     * @return the to date
     */
    public LocalDate getToDate() {
        return toDate;
    }

    /**
     * Sets the to date.
     *
     * @param toDate the new to date
     */
    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }
}
