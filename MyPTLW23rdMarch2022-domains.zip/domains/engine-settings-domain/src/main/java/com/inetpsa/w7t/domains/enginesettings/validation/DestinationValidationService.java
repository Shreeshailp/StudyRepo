/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Interface DestinationValidationService.
 */
@Service
@FunctionalInterface
public interface DestinationValidationService {

    /**
     * Validate.
     *
     * @param d the d
     */
    public void validate(DestinationDetails d);
}
