/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.javatuples.Pair;
import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.jpa.DestinationJpaRepository;
import com.inetpsa.w7t.domains.enginesettings.model.Destination;

/**
 * The Interface DestinationRepository.
 * 
 * @see DestinationJpaRepository
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface DestinationRepository extends GenericRepository<Destination, UUID> {

    /**
     * Read all Destinations from the database.
     *
     * @param filter the filter
     * @return the list of Destinations read.
     */

    @Read
    List<Destination> all(Pair<String, String> filter);

    /**
     * By label.
     *
     * @param label the label
     * @return the destination
     */
    @Read
    Optional<Destination> byLabel(String label);

    /**
     * Check that the Destination identified by the specified key exists.
     *
     * @param label the Destination label
     * @return true if the Destination exists, false otherwise.
     */
    @Read
    boolean exists(String label);

}
