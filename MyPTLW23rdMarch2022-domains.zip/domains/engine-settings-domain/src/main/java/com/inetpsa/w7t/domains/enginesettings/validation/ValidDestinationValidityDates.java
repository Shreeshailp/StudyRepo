/*
 * Creation : 28 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.inetpsa.w7t.domains.enginesettings.validation.internal.ValidDestinationDetailsValidityDatesValidator;
import com.inetpsa.w7t.domains.enginesettings.validation.internal.ValidDestinationValidityDatesValidator;

/**
 * The Interface ValidDestinationValidityDates. This is used to validate the start date and end date for Destination
 */
@Target({ ElementType.TYPE })
@Constraint(validatedBy = { ValidDestinationValidityDatesValidator.class, ValidDestinationDetailsValidityDatesValidator.class })
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidDestinationValidityDates {

    /**
     * Message.
     *
     * @return the string
     */
    String message() default "{com.inetpsa.w7t.validation.constraints.ValidDestinationValidityDates.message}";

    /**
     * Groups.
     *
     * @return the class[]
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the class&lt;? extends payload&gt;[]
     */
    Class<? extends Payload>[] payload() default {};
}
