/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import org.seedstack.business.domain.DomainPolicy;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Interface DestinationDetailsValidationPolicy.
 */
@DomainPolicy
public interface DestinationDetailsValidationPolicy {

    /**
     * Checks if is valid label.
     *
     * @param d the d
     * @return true, if is valid label
     */
    public boolean isValidLabel(DestinationDetails d);

    /**
     * Checks if is valid country.
     *
     * @param d the d
     * @return true, if is valid country
     */
    public boolean isValidCountry(DestinationDetails d);

    /**
     * Checks if the current destination dates for the countries are overlapping another one.
     *
     * @param d the d
     * @return true, if is overlapping
     */
    boolean isOverlapping(DestinationDetails d);

}
