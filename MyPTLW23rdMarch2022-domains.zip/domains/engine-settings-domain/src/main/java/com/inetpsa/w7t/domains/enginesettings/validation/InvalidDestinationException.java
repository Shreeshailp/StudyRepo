/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

/**
 * The Class InvalidDestinationException.
 */
public class InvalidDestinationException extends RuntimeException {

    /** The error code. */
    private String errorCode;

    /**
     * Instantiates a new invalid destination exception.
     *
     * @param errorCode the error code
     * @param msg the msg
     */
    public InvalidDestinationException(String errorCode, String msg) {
        super(msg);
        this.setErrorCode(errorCode);
    }

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the error code.
     *
     * @param errorCode the new error code
     */
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

}
