/*
 * Creation : 28 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation.internal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.inetpsa.w7t.domains.enginesettings.model.Destination;
import com.inetpsa.w7t.domains.enginesettings.validation.ValidDestinationValidityDates;

/**
 * The Class ValidDestinationValidityDatesValidator. This is used to validate start date and end date of Destination
 */
public class ValidDestinationValidityDatesValidator implements ConstraintValidator<ValidDestinationValidityDates, Destination> {

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
     */
    @Override
    public void initialize(ValidDestinationValidityDates constraintAnnotation) {
        // This method is intentionally empty because there is nothing to initialize.
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
     */
    @Override
    public boolean isValid(Destination destination, ConstraintValidatorContext context) {
        if (destination == null)
            return true;

        return destination.getFromDate().isEqual(destination.getToDate()) || destination.getFromDate().isBefore(destination.getToDate());
    }

}
