/*
 * Creation : 17 févr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.javatuples.Pair;
import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationRepository;
import com.inetpsa.w7t.domains.enginesettings.model.Destination;

/**
 * The Class DestinationJpaRepository This class is used to fetch Destination entity.
 * 
 * @see Destination
 */
public class DestinationJpaRepository extends BaseJpaRepository<Destination, UUID> implements DestinationRepository {

    /** The Constant LABEL. */
    private static final String LABEL = "label";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationRepository#all(org.javatuples.Pair)
     */
    @Override
    public List<Destination> all(Pair<String, String> filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Destination> criteriaQuery = cb.createQuery(aggregateRootClass);
        Root<Destination> root = criteriaQuery.from(aggregateRootClass);

        Optional<String> label = Optional.ofNullable(filter.getValue0());

        List<Predicate> filters = new ArrayList<>();
        label.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(LABEL)), cb.parameter(String.class, LABEL))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Destination> q = entityManager.createQuery(criteriaQuery);

        label.ifPresent(c -> q.setParameter(LABEL, new StringBuilder().append("%").append(c).append("%").toString()));

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationRepository#byLabel(java.lang.String)
     */
    @Override
    public Optional<Destination> byLabel(String label) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Destination> q = cb.createQuery(aggregateRootClass);
        Root<Destination> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(LABEL), cb.parameter(String.class, LABEL)));

        TypedQuery<Destination> query = entityManager.createQuery(q);
        query.setParameter(LABEL, label);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String label) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Destination> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<Destination> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<Destination> get(LABEL));
        criteriaQuery.where(criteriaBuilder.equal(root.get(LABEL), criteriaBuilder.parameter(String.class, LABEL)));
        return entityManager.createQuery(criteriaQuery).setParameter(LABEL, label).getResultList().size() == 1;
    }
}
