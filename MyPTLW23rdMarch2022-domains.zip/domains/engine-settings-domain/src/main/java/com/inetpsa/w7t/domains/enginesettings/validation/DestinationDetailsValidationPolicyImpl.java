/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Class DestinationDetailsValidationPolicyImpl.
 */
public class DestinationDetailsValidationPolicyImpl implements DestinationDetailsValidationPolicy {

    /** The repository. */
    @Inject
    DestinationDetailsRepository repository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.validation.DestinationDetailsValidationPolicy#isValidLabel(com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails)
     */
    @Override
    public boolean isValidLabel(DestinationDetails d) {
        if (repository.exists(d.getGuid(), d.getLabel()))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.validation.DestinationDetailsValidationPolicy#isValidCountry(com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails)
     */
    @Override
    public boolean isValidCountry(DestinationDetails destinationDetails) {
        if (!destinationDetails.getCountries().isEmpty() && !repository.byCountryAndDate(destinationDetails.getGuid(),
                destinationDetails.getCountries(), destinationDetails.getFromDate(), destinationDetails.getToDate()).isEmpty())
            return false;

        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.validation.DestinationDetailsValidationPolicy#isOverlapping(com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails)
     */
    @Override
    public boolean isOverlapping(DestinationDetails d) {
        return repository.isDestinationOverlapping(d);
    }

}
