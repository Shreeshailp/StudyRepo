/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

/**
 * The Interface DestinationDetailsRepository.
 */
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface DestinationDetailsRepository extends GenericRepository<DestinationDetails, UUID> {

    /**
     * By country and date.
     *
     * @param uuid the uuid
     * @param list the list
     * @param fromDate the from date
     * @param toDate the to date
     * @return the list
     */
    @Read
    List<DestinationDetails> byCountryAndDate(UUID uuid, List<String> list, LocalDate fromDate, LocalDate toDate);

    /**
     * Exists.
     *
     * @param guId the gu id
     * @param label the label
     * @return true, if successful
     */
    @Read
    boolean exists(UUID guId, String label);

    /**
     * Retrieve a {@link DestinationDetails} from a country code and a date.
     *
     * @param countryCode the country code
     * @param countryCharacteristic the country characteristic
     * @param date the date
     * @return the optional
     */
    @Read
    Optional<DestinationDetails> byCountryAndDate(String countryCode, String countryCharacteristic, LocalDate date);

    /**
     * Checks if is destination overlapping.
     *
     * @param destinationDetails the destination details
     * @return true, if is destination overlapping
     */
    @Read
    boolean isDestinationOverlapping(DestinationDetails destinationDetails);

}
