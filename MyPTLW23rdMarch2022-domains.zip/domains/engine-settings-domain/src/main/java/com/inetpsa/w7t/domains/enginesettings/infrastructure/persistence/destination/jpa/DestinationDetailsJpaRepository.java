/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.jpa;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import javax.inject.Inject;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.model.Country;

import edu.emory.mathcs.backport.java.util.Collections;

/**
 * The Class DestinationDetailsJpaRepository.
 */
public class DestinationDetailsJpaRepository extends BaseJpaRepository<DestinationDetails, UUID> implements DestinationDetailsRepository {

    /** The log. */
    @Logging
    private Logger log = LoggerFactory.getLogger(DestinationDetailsJpaRepository.class.getName());

    /** The Constant FROM_DATE. */
    private static final String FROM_DATE = "fromDate";

    /** The Constant TO_DATE. */
    private static final String TO_DATE = "toDate";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    private static final String COUNTRY = "countries";

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository#exists(java.util.UUID,
     *      java.lang.String)
     */
    @Override
    @SuppressWarnings("unchecked")
    public boolean exists(UUID guId, String label) {
        String labelQuery = "select d.* from W7TQTDES as d where d.label = ?1";

        List<DestinationDetails> dest = entityManager.createNativeQuery(labelQuery, DestinationDetails.class).setParameter(1, label).getResultList();
        if (dest.isEmpty() || dest.get(0).getGuid().equals(guId)) {
            return false;
        }
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository#byCountryAndDate(java.util.UUID,
     *      java.util.List, java.time.LocalDate, java.time.LocalDate)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<DestinationDetails> byCountryAndDate(UUID guId, List<String> countries, LocalDate inFromDate, LocalDate inToDate) {
        DestinationDetails destintionDetailsFromRepo = entityManager.find(DestinationDetails.class, guId);
        List<String> countriesToValidate = new ArrayList<>(countries);
        if (destintionDetailsFromRepo != null)
            countriesToValidate.removeAll(destintionDetailsFromRepo.getCountries());
        if (!countriesToValidate.isEmpty()) {
            String query = "select d.* from W7TQTDES as d, W7TQTDCO as c " + " where d.id = c.destination_id " + " and d.fromdate < ?1 "
                    + " and d.todate > ?2 " + "and c.country_id in (?3) ";

            return entityManager.createNativeQuery(query, DestinationDetails.class).setParameter(1, inToDate).setParameter(2, inFromDate)
                    .setParameter(3, countriesToValidate).getResultList();
        }
        return Collections.emptyList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository#byCountryAndDate(java.lang.String,
     *      java.lang.String, java.time.LocalDate)
     */
    @Override
    public Optional<DestinationDetails> byCountryAndDate(String countryCode, String countryCharacteristic, LocalDate date) {
        Country country = countryRepository.byCodeAndCharacteristic(countryCode, countryCharacteristic);

        if (country == null)
            return Optional.empty();

        /*
         * CriteriaBuilder cb = entityManager.getCriteriaBuilder(); CriteriaQuery<DestinationDetails> q = cb.createQuery(aggregateRootClass);
         * Root<DestinationDetails> root = q.from(aggregateRootClass); q.where(cb.greaterThanOrEqualTo(cb.parameter(LocalDate.class, FROM_DATE),
         * root.get(FROM_DATE)), cb.lessThanOrEqualTo(cb.parameter(LocalDate.class, TO_DATE), root.get(TO_DATE)));
         * 
         * TypedQuery<DestinationDetails> query = entityManager.createQuery(q); query.setParameter(FROM_DATE, date); query.setParameter(TO_DATE,
         * date);
         */
        // WltpCacheManager<DestinationDetails> wltpCacheManager = WltpCacheManager.getInstance(DestinationDetails.class);
        // String key = countryCode + "_" + countryCharacteristic;
        // Optional<DestinationDetails> destinationDetails = wltpCacheManager.getOptinalItem(key);
        // if (destinationDetails != null && destinationDetails.isPresent()) {
        // return destinationDetails;
        // }

        TypedQuery<DestinationDetails> query = entityManager.createQuery("FROM DestinationDetails where FROMDATE <=:FROMDATE and TODATE >=:TODATE",
                DestinationDetails.class);
        query.setParameter("FROMDATE", date);
        query.setParameter("TODATE", date);
        // destinationDetails = query.getResultList().stream().filter(dest -> dest.getCountries().contains(country.getGuid().toString())).findFirst();
        // wltpCacheManager.putOptinalItem(key, destinationDetails);
        // return destinationDetails;
        return query.getResultList().stream().filter(dest -> dest.getCountries().contains(country.getGuid().toString())).findFirst();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository#isDestinationOverlapping(com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails)
     */
    @Override
    public boolean isDestinationOverlapping(DestinationDetails destinationDetails) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<DestinationDetails> q = cb.createQuery(aggregateRootClass);
        Root<DestinationDetails> root = q.from(aggregateRootClass);

        q.where(cb.not(cb.or(cb.greaterThan(cb.parameter(LocalDate.class, FROM_DATE), root.get(TO_DATE)),
                cb.lessThan(cb.parameter(LocalDate.class, TO_DATE), root.get(FROM_DATE)))),
                cb.not(cb.equal(root.get(GUID), cb.parameter(UUID.class, GUID))));

        TypedQuery<DestinationDetails> query = entityManager.createQuery(q);
        query.setParameter(FROM_DATE, destinationDetails.getFromDate());
        query.setParameter(TO_DATE, destinationDetails.getToDate());
        query.setParameter(GUID, destinationDetails.getGuid());

        List<String> countries = destinationDetails.getCountries();

        return query.getResultList().stream().map(DestinationDetails::getCountries).map(List::stream).flatMap(Function.identity()).distinct()
                .anyMatch(countries::contains);
    }
}
