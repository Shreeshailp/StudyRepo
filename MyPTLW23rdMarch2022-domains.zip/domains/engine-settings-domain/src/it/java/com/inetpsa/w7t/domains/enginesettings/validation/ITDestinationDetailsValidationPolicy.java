/*
 * Creation : 30 juin 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

@RunWith(SeedITRunner.class)
public class ITDestinationDetailsValidationPolicy {

    @Inject
    private DestinationDetailsValidationPolicy destinationDetailsValidationPolicy;

    private UUID guid = UUID.fromString("7b522085-9a89-4a2e-bf7e-8e895950f24f");
    private List<String> countries = Arrays.asList("0310b986-2c1f-480b-98d1-6f96d6496dbb", "036ed0d1-e126-4c9e-87b2-cd221e81a739");

    @Test
    public void testIsValidLabel() {

        DestinationDetails d = new DestinationDetails();
        d.setGuid(guid);
        d.setLabel("Test Destination");
        boolean valid = destinationDetailsValidationPolicy.isValidLabel(d);

        assertThat(valid).isTrue();
    }

    @Test
    public void testIsValidCountry() {

        DestinationDetails d = new DestinationDetails();
        d.setGuid(guid);
        d.setCountries(countries);
        boolean valid = destinationDetailsValidationPolicy.isValidCountry(d);

        assertThat(valid).isTrue();
    }

    @Test
    public void testIsOverlapping() {

        DestinationDetails d = new DestinationDetails();
        d.setGuid(guid);
        d.setCountries(countries);
        boolean valid = destinationDetailsValidationPolicy.isOverlapping(d);

        assertThat(valid).isFalse();
    }
}
