/*
 * Creation : 30 juin 2017
 */
package com.inetpsa.w7t.domains.enginesettings.validation.internal;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.validation.ConstraintValidatorContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.enginesettings.model.Destination;

@RunWith(SeedITRunner.class)
public class ITValidDestinationValidityDatesValidator {

    ValidDestinationValidityDatesValidator validDestinationValidityDatesValidator = new ValidDestinationValidityDatesValidator();

    private UUID guid = UUID.fromString("7b522085-9a89-4a2e-bf7e-8e895950f24f");
    private List<UUID> countries = Arrays.asList(UUID.fromString("0310b986-2c1f-480b-98d1-6f96d6496dbb"),
            UUID.fromString("036ed0d1-e126-4c9e-87b2-cd221e81a739"));

    @Test
    public void testValidDestinationValidityDatesValidator() {

        Destination d = new Destination();
        d.setGuid(guid);
        d.setLabel("Test Destination");
        d.setCountries(countries);
        d.setFromDate(LocalDate.parse("2017-06-01"));
        d.setToDate(LocalDate.parse("2017-06-30"));
        ConstraintValidatorContext context = null;
        validDestinationValidityDatesValidator.isValid(d, context);

    }
}
