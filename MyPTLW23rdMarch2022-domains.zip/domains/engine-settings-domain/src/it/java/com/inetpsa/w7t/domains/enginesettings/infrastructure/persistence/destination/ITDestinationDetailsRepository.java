/*
 * Creation : 20 avr. 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.it.SeedITRunner;

import com.google.common.collect.Lists;
import com.inetpsa.w7t.domains.enginesettings.model.DestinationDetails;

@RunWith(SeedITRunner.class)
public class ITDestinationDetailsRepository {

    @Inject
    private DestinationDetailsRepository destinationDetailsRepository;

    @Inject
    private Factory<DestinationDetails> destinationDetailsFactory;

    @Test
    public void existingByCountryAndDate() {
        assertThat(destinationDetailsRepository.byCountryAndDate("F9", "GG8", LocalDate.parse("2016-01-05"))).as("Existing destination").isPresent()
                .hasValueSatisfying(dest -> dest.getGuid().equals(UUID.fromString("25cd8cea-b55e-4bc3-8fdb-0a741a7eedd8")));
    }

    @Test
    public void nonExistingCountryByCountryAndDate() {
        assertThat(destinationDetailsRepository.byCountryAndDate("ZZ", "GG8", LocalDate.now())).as("Non existing country").isNotPresent();
    }

    @Test
    public void missingByCountryAndDate() {
        assertThat(destinationDetailsRepository.byCountryAndDate("GB", "GG8", LocalDate.parse("2017-01-01"))).as("Missing Destination")
                .isNotPresent();
    }

    @Test
    public void testOverlapping() {
        DestinationDetails destinationDetails = destinationDetailsFactory.create();
        destinationDetails.setFromDate(LocalDate.parse("2017-04-01"));
        destinationDetails.setToDate(LocalDate.parse("2017-05-31"));

        destinationDetails.setCountries(Lists.newArrayList("6da59ff8-237f-4c68-b537-bcb508dff884", "b1033888-a5b8-4a5e-a8b6-b3e8ddca413b"));
        assertThat(destinationDetailsRepository.isDestinationOverlapping(destinationDetails)).isTrue();

        destinationDetails.setCountries(Lists.newArrayList("510f4360-eef4-47e8-b62e-038315f64b35", "6a26811a-b7d1-48d3-9553-66c3ed4037c5"));
        assertThat(destinationDetailsRepository.isDestinationOverlapping(destinationDetails)).isFalse();
    }
}
