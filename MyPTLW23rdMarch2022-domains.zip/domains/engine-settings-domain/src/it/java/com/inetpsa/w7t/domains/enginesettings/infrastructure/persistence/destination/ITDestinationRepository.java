/*
 * Creation : 1 mars 2017
 */
package com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.javatuples.Pair;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.enginesettings.model.Destination;

@RunWith(SeedITRunner.class)
public class ITDestinationRepository {

    @Inject
    private DestinationRepository destinationRepository;

    @Test
    public void allDestinations() {
        Pair<String, String> filter = new Pair<>(null, null);

        List<Destination> destination = destinationRepository.all(filter);

        assertThat(destination).isNotNull();
    }

    @Test
    public void destinationWithExistingLabel() {
        Optional<Destination> destination = destinationRepository.byLabel("Europe Euro 6.2");

        assertThat(destination.isPresent()).isTrue();
        assertThat(destination.get().getGuid()).hasToString("25cd8cea-b55e-4bc3-8fdb-0a741a7eedd8");
        assertThat(destination.get().getFromDate()).isEqualTo("2016-01-05");
        assertThat(destination.get().getToDate()).isEqualTo("2017-12-31");

    }

    @Test
    public void destinationWithNonExistingLabel() {
        Optional<Destination> destination = destinationRepository.byLabel("Europe Euro 6.9");

        assertThat(destination.isPresent()).isFalse();
    }

    @Test
    public void destinationWithNullLabel() {
        Optional<Destination> destination = destinationRepository.byLabel(null);

        assertThat(destination.isPresent()).isFalse();
    }

    @Test
    public void destinationExists() {
        boolean destination = destinationRepository.exists("Europe Euro 6.2");

        assertThat(destination).isTrue();
    }

    @Test
    public void destinationNotExists() {
        boolean destination = destinationRepository.exists("Europe Euro 6.9");

        assertThat(destination).isFalse();
    }

}
