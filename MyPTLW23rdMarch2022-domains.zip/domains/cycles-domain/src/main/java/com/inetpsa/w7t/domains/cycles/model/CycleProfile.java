/*
 * Creation : 14 févr. 2017
 */
package com.inetpsa.w7t.domains.cycles.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class CycleProfile. This entity represents the physical quantity test values (i.e. acceleration, distance, time, velocity) of a certain phase
 * belonging to a certain cycle.
 * 
 * @see Cycle
 */
@Entity
@Table(name = "W7TQTCYP")
public class CycleProfile extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The acceleration. */
    @Column(name = "ACCELERATION")
    private double acceleration;

    /** The distance. */
    @Column(name = "DISTANCE")
    private double distance;

    /** The time. */
    @Column(name = "TIME")
    private int time;

    /** The velocity. */
    @Column(name = "VELOCITY")
    private double velocity;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof CycleProfile))
            return false;

        CycleProfile other = (CycleProfile) o;
        String hash = new StringBuilder(guid.toString()).toString();
        String otherHash = new StringBuilder(other.guid.toString()).toString();
        return hash.equals(otherHash);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + guid.hashCode();
        return hashcode;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the acceleration.
     *
     * @return the acceleration
     */
    public double getAcceleration() {
        return acceleration;
    }

    /**
     * Sets the acceleration.
     *
     * @param acceleration the new acceleration
     */
    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    /**
     * Gets the distance.
     *
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Sets the distance.
     *
     * @param distance the new distance
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }

    /**
     * Gets the time.
     *
     * @return the time
     */
    public int getTime() {
        return time;
    }

    /**
     * Sets the time.
     *
     * @param time the new time
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * Gets the velocity.
     *
     * @return the velocity
     */
    public double getVelocity() {
        return velocity;
    }

    /**
     * Sets the velocity.
     *
     * @param velocity the new velocity
     */
    public void setVelocity(double velocity) {
        this.velocity = velocity;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.Entity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    @Override
    public String toString() {
        return "CycleProfile [time=" + time + ",acceleration=" + acceleration + ", distance=" + distance + ",  velocity=" + velocity + "]";
    }

}
