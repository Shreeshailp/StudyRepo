/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.exception;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum GeneratedCycleErrorCode.
 */
public enum GeneratedCycleErrorCode implements ErrorCode {
    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(111, "At least one line of the file is not recognized, the import has not been performed", "RG12"),
    /** The only one metadata check. */
    ONLY_ONE_METADATA_CHECK(112, "Missing or multiple metadata row, the import was not made. Stop treatment.", "RG14"),
    /** The line m out of format. */
    LINE_M_OUT_OF_FORMAT(113, "At least one of the metadata is not in the defined format, the import was not performed. Stop processing", "RG15"),
    /** The not enough data. */
    NOT_ENOUGH_DATA(114, "the file has less than two profile points, the import has not been made. Stop treatment.", "RG16"),
    /** The line d out of format. */
    LINE_D_OUT_OF_FORMAT(115, "At least one point of the profile is not in the required format, the import has not been made. Stop treatment.",
            "RG17"),
    /** The cycle profile exists. */
    GENERATED_CYCLE_PROFILE_EXISTS(116,
            "This Generated Cycle Profile already exists in the database, Do you confirm its replacement with that of the selected file?", "RG18"),
    /** Unknown technical exception. */
    UNKNOWN_TECHNICAL_EXCEPTION(119, "Unknown technical exception", "RGXX"),
    /** The speedlimit fdsc empty. */
    SPEEDLIMIT_FDSC_EMPTY(121, "one of the two parameters f_dsc or max_speed must be non-white, the import has not been done", "RG19"),
    /** The unknown reference code. */
    UNKNOWN_REFERENCE_CODE(123, "At least one metadata line contains an unknown reference cycle, the import was not done. Stop treatment", "RG20"),
    /** The time value repeated. */
    TIME_VALUE_REPEATED(124, "At least one duplicate in the cycle profile, the import was not made", "RG21"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    TIMEOUT_EXCEPTION(125, "Error : Timeout. Number of files are too high", "RG22");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new family error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    GeneratedCycleErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }

}
