/*
 * Creation : 26 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.javatuples.Pair;
import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;

/**
 * The Interface GeneratedCycleRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface GeneratedCycleRepository extends GenericRepository<GeneratedCycle, UUID> {

    /**
     * All.
     *
     * @param filter the filter
     * @return the list
     */
    @Read
    List<GeneratedCycle> all(Pair<String, String> filter);

    /**
     * Exists.
     *
     * @param generatedCode the generated code
     * @return true, if successful
     */
    @Read
    boolean exists(String generatedCode);

    /**
     * By generated code.
     *
     * @param reuestId the reuest id
     * @param generatedCode the generated code
     * @return the optional
     */
    @Read
    Optional<GeneratedCycle> byGeneratedCode(String reuestId, String generatedCode);

    /**
     * By cycle code F downscale max speed.
     *
     * @param code the code
     * @param fDownScale the f down scale
     * @param maxSpeed the max speed
     * @return the optional
     */
    @Read
    GeneratedCycle byCycleCodeFDownscaleMaxSpeed(String code, Float fDownScale, Integer maxSpeed);

    /**
     * Delete by cycle code.
     *
     * @param code the code
     * @return the int
     */
    int deleteByCycleCode(String code);

    @Read
    public GeneratedCycle byCycleCode(String cycleCode);

    @Read
    public List<GeneratedCycle> findAll();

}
