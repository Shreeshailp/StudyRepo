/*
 * Creation : 20 févr. 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.javatuples.Pair;
import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository;
import com.inetpsa.w7t.domains.cycles.model.Cycle;

/**
 * The Class CycleJpaRepository. This is the JPA Implementation of the {@link CycleRepository}.
 * 
 * @see CycleRepository
 */
public class CycleJpaRepository extends BaseJpaRepository<Cycle, UUID> implements CycleRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository#all(org.javatuples.Pair)
     */
    @Override
    public List<Cycle> all(Pair<String, String> filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cycle> q = cb.createQuery(aggregateRootClass);
        Root<Cycle> root = q.from(aggregateRootClass);

        Optional<String> code = Optional.ofNullable(filter.getValue0());

        code.ifPresent(c -> q.where(cb.like(root.get(CODE), cb.parameter(String.class, CODE))));

        TypedQuery<Cycle> query = entityManager.createQuery(q);

        code.ifPresent(c -> query.setParameter(CODE, new StringBuilder().append("%").append(c).append("%").toString()));

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository#byCode(java.lang.String)
     */
    @Override
    public Optional<Cycle> byCode(String code) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cycle> q = cb.createQuery(aggregateRootClass);
        Root<Cycle> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

        TypedQuery<Cycle> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Cycle> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<Cycle> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.select(root.<Cycle>get(CODE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
    }

    // @SuppressWarnings("unchecked")
    // @Override
    // public List<CycleProfile> getCycleProfiles(String id) {
    // List<CycleProfile> list = new ArrayList<>();
    // Query query = entityManager
    // .createNativeQuery("select cyp.VELOCITY, cyp.ACCELERATION, cyp.DISTANCE from W7TQTCYP cyp where cyp.CYCLE_ID=? order by cyp.TIME");
    // query.setParameter(1, id);
    // try {
    // List<Object[]> tempList = query.getResultList();
    // for (Object[] objects : tempList) {
    // CycleProfile cyp = new CycleProfile();
    // cyp.setVelocity(Double.valueOf(objects[0].toString()));
    // cyp.setAcceleration(Double.valueOf(objects[1].toString()));
    // cyp.setDistance(Double.valueOf(objects[2].toString()));
    // list.add(cyp);
    // }
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // return list;
    // }

}
