/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.domains.cycles.model;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

/**
 * The Class CycleDto.
 */
@DtoOf(CycleDetails.class)
public class CycleDto {

    /** The code. */
    private String code;

    /** The phase. */
    private String phase;

    /** The comment. */
    private String comment;

    public Double getCycleMaxVelocity() {
        return cycleMaxVelocity;
    }

    public void setCycleMaxVelocity(Double cycleMaxVelocity) {
        this.cycleMaxVelocity = cycleMaxVelocity;
    }

    private Double cycleMaxVelocity;

    /** The cycle profiles. */
    private List<CycleProfileDto> profiles;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the comment.
     *
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     *
     * @param comment the new comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * Gets the profiles.
     *
     * @return the profiles
     */
    public List<CycleProfileDto> getProfiles() {
        return profiles;
    }

    /**
     * Sets the profiles.
     *
     * @param profiles the new profiles
     */
    public void setProfiles(List<CycleProfileDto> profiles) {
        this.profiles = profiles;
    }

}
