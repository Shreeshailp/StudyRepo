/*
 * Creation : 1 avr. 2017
 */
package com.inetpsa.w7t.domains.cycles.shared;

import org.seedstack.seed.SeedException;

/**
 * The Class CycleValidationException.
 */
public class CycleValidationException extends SeedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6128794118118832438L;

    /**
     * Instantiates a new cycle validation exception.
     *
     * @param errorCode the error code
     */
    public CycleValidationException(CycleErrorCode errorCode) {
        super(errorCode);

    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {

        return ((CycleErrorCode) this.getErrorCode()).getDescription();

    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((CycleErrorCode) this.getErrorCode()).getRuleCode();
    }
}
