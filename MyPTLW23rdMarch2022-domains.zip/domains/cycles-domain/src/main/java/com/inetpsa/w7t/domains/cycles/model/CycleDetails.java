/*
 * Creation : 9 févr. 2017
 */
package com.inetpsa.w7t.domains.cycles.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.inetpsa.w7t.domains.cycles.validation.CycleCode;
import com.inetpsa.w7t.domains.cycles.validation.CycleComment;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;

/**
 * The Aggregate CycleDetails. It is used to display all the details of a WLTP cycle along with the cycle profiles belonging to that cycle.
 * 
 * @see CycleProfile
 * @see Cycle
 */
@Entity
@Table(name = "W7TQTCYL")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class CycleDetails extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code. */
    @CycleCode
    @Column(name = "CODE")
    private String code;

    /** The phase. */
    @CyclePhaseCode
    @Column(name = "PHASE")
    private String phase;

    /** The comment. */
    @CycleComment
    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "CYCLE_MAX_VELOCITY")
    private Double cycleMaxVelocity;

    /** The families. */
    @JsonIgnore
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTCYF", joinColumns = @JoinColumn(name = "CYCLE_ID", referencedColumnName = "ID"))
    @Column(name = "FAMILY_ID")
    @Type(type = "uuid-char")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<UUID> families;

    /** The cycle profiles. */
    @JsonIgnore
    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("time")
    @JoinColumn(name = "CYCLE_ID", nullable = false)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<CycleProfile> profiles;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof CycleDetails))
            return false;

        CycleDetails other = (CycleDetails) o;
        String hash = new StringBuilder(code).append(phase).append(comment).toString();
        String otherHash = new StringBuilder(other.code).append(other.phase).append(other.comment).toString();
        return hash.equals(otherHash) && families.equals(other.families) && profiles.equals(other.profiles);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + code.hashCode();
        hashcode = hashcode * 31 + phase.hashCode();
        hashcode = hashcode * 31 + comment.hashCode();
        hashcode = hashcode * 31 + families.hashCode();
        return hashcode * 31 + profiles.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the comment.
     *
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     *
     * @param comment the new comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * Gets the families.
     *
     * @return the families
     */
    public List<UUID> getFamilies() {
        return families;
    }

    /**
     * Sets the families.
     *
     * @param families the new families
     */
    public void setFamilies(List<UUID> families) {
        this.families = families;
    }

    /**
     * Gets the profiles.
     *
     * @return the profiles
     */
    public List<CycleProfile> getProfiles() {
        return profiles;
    }

    /**
     * Sets the profiles.
     *
     * @param profiles the new profiles
     */
    public void setProfiles(List<CycleProfile> profiles) {
        this.profiles = profiles;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    public Double getCycleMaxVelocity() {
        return cycleMaxVelocity;
    }

    public void setCycleMaxVelocity(Double cycleMaxVelocity) {
        this.cycleMaxVelocity = cycleMaxVelocity;
    }

}
