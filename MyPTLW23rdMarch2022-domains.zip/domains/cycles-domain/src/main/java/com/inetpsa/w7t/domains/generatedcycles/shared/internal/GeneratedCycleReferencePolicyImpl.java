/*
 * Creation : 11 Apr 2019
 */
package com.inetpsa.w7t.domains.generatedcycles.shared.internal;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleErrorCode;
import com.inetpsa.w7t.domains.generatedcycles.exception.GeneratedCycleException;
import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;
import com.inetpsa.w7t.domains.generatedcycles.shared.GeneratedCycleReferencePolicy;

/**
 * The Class GeneratedCycleReferencePolicyImpl.
 */
public class GeneratedCycleReferencePolicyImpl implements GeneratedCycleReferencePolicy {

    /** The gen cycle repo. */
    @Inject
    GeneratedCycleRepository genCycleRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.generatedcycles.shared.GeneratedCycleReferencePolicy#isValid(com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle)
     */
    @Override
    public boolean isValid(GeneratedCycle cycleDetails) {
        /** RG15 **/
        if (!genCycleRepo.exists(cycleDetails.getGeneratedCode())) {
            throw new GeneratedCycleException(GeneratedCycleErrorCode.GENERATED_CYCLE_PROFILE_EXISTS);

        }

        return true;
    }

}
