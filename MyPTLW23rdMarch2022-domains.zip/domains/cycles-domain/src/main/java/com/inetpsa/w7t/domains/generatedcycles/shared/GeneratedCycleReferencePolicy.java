/*
 * Creation : 29 Mar 2019
 */
package com.inetpsa.w7t.domains.generatedcycles.shared;

import org.seedstack.business.domain.DomainPolicy;

import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;

/**
 * The Interface GeneratedCycleReferencePolicy.
 */
@DomainPolicy
@FunctionalInterface
public interface GeneratedCycleReferencePolicy {

    /**
     * Checks if is valid.
     *
     * @param cycleDetails the cycle details
     * @return true, if is valid
     */
    boolean isValid(GeneratedCycle cycleDetails);
}
