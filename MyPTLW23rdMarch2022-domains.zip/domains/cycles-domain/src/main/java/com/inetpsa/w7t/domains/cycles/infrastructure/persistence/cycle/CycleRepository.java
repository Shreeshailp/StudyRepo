/*
 * Creation : 15 févr. 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.javatuples.Pair;
import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.cycles.model.Cycle;

/**
 * The Interface CycleRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CycleRepository extends GenericRepository<Cycle, UUID> {
    /**
     * Read all cycles from the database.
     *
     * @param filter the filter
     * @return the list of cycles.
     */
    @Read
    List<Cycle> all(Pair<String, String> filter);

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate key
     * @return cycle the cycle entity retrieved
     */
    @Read
    Optional<Cycle> byCode(String code);

    /**
     * Check that the cycle identified by the specified key exists.
     *
     * @param code the cycle code
     * @return true if the cycle exists, false otherwise.
     */
    @Read
    boolean exists(String code);

    // @Read
    // List<CycleProfile> getCycleProfiles(String id);

}
