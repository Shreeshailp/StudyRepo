/*
 * Creation : 16 Apr 2019
 */
package com.inetpsa.w7t.domains.generatedcycles.model;

import org.seedstack.business.assembler.DtoOf;

/**
 * The Class GeneratedCycleProfileDto.
 */
@DtoOf(GeneratedCycleProfile.class)
public class GeneratedCycleProfileDto {

    /** The acceleration. */
    private double acceleration;

    /** The distance. */
    private double distance;

    /** The time. */
    private int time;

    /** The velocity. */
    private double velocity;

    /**
     * Gets the acceleration.
     *
     * @return the acceleration
     */
    public double getAcceleration() {
        return acceleration;
    }

    /**
     * Sets the acceleration.
     *
     * @param acceleration the new acceleration
     */
    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    /**
     * Gets the distance.
     *
     * @return the distance
     */
    public double getDistance() {
        return distance;
    }

    /**
     * Sets the distance.
     *
     * @param distance the new distance
     */
    public void setDistance(double distance) {
        this.distance = distance;
    }

    /**
     * Gets the time.
     *
     * @return the time
     */
    public int getTime() {
        return time;
    }

    /**
     * Sets the time.
     *
     * @param time the new time
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * Gets the velocity.
     *
     * @return the velocity
     */
    public double getVelocity() {
        return velocity;
    }

    /**
     * Sets the velocity.
     *
     * @param velocity the new velocity
     */
    public void setVelocity(double velocity) {
        this.velocity = velocity;
    }

}
