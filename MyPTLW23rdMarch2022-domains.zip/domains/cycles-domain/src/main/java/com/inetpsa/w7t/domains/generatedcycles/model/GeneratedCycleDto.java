/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.model;

import java.util.List;

import org.seedstack.business.assembler.DtoOf;

/**
 * The Class GeneratedCycleDto.
 */
@DtoOf(GeneratedCycle.class)
public class GeneratedCycleDto {

    /** The generated code. */
    private String generatedCode;

    /** The cycle code. */
    private String cycleCode;

    /** The phase. */
    private String phase;

    /** The profiles. */
    private List<GeneratedCycleProfileDto> profiles;

    /** The fdsc. */
    private Float fdsc;

    /** The speed limit. */
    private int speedLimit;

    /** The total distance. */
    private Float totalDistance;

    /** The v max. */
    private Float vMax;

    /** The downscale flag. */
    private boolean downscaleFlag;

    /** The speed limit flag. */
    private boolean speedLimitFlag;

    /** The created by. */
    private String createdBy;

    /** The created date. */
    private String createdDate;

    /** The updated by. */
    private String updatedBy;

    /** The updated date. */
    private String updatedDate;

    /**
     * Getter profiles.
     *
     * @return the profiles
     */
    public List<GeneratedCycleProfileDto> getProfiles() {
        return profiles;
    }

    /**
     * Setter profiles.
     *
     * @param list the profiles to set
     */
    public void setProfiles(List<GeneratedCycleProfileDto> list) {
        this.profiles = list;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Getter generatedCode.
     *
     * @return the generatedCode
     */
    public String getGeneratedCode() {
        return generatedCode;
    }

    /**
     * Setter generatedCode.
     *
     * @param generatedCode the generatedCode to set
     */
    public void setGeneratedCode(String generatedCode) {
        this.generatedCode = generatedCode;
    }

    /**
     * Getter cycleCode.
     *
     * @return the cycleCode
     */
    public String getCycleCode() {
        return cycleCode;
    }

    /**
     * Setter cycleCode.
     *
     * @param cycleCode the cycleCode to set
     */
    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }

    /**
     * Gets the fdsc.
     *
     * @return the fdsc
     */
    public Float getFdsc() {
        return fdsc;
    }

    /**
     * Setter fdsc.
     *
     * @param fdsc the fdsc to set
     */
    public void setFdsc(Float fdsc) {
        this.fdsc = fdsc;
    }

    /**
     * Gets the speed limit.
     *
     * @return the speed limit
     */
    public int getSpeedLimit() {
        return speedLimit;
    }

    /**
     * Setter speedLimit.
     *
     * @param speedLimit the speedLimit to set
     */
    public void setSpeedLimit(int speedLimit) {
        this.speedLimit = speedLimit;
    }

    /**
     * Getter totalDistance.
     *
     * @return the totalDistance
     */
    public Float getTotalDistance() {
        return totalDistance;
    }

    /**
     * Setter totalDistance.
     *
     * @param totalDistance the totalDistance to set
     */
    public void setTotalDistance(Float totalDistance) {
        this.totalDistance = totalDistance;
    }

    /**
     * Getter vMax.
     *
     * @return the vMax
     */
    public Float getvMax() {
        return vMax;
    }

    /**
     * Setter vMax.
     *
     * @param vMax the vMax to set
     */
    public void setvMax(Float vMax) {
        this.vMax = vMax;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Setter createdBy.
     *
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Getter createdDate.
     *
     * @return the createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * Setter createdDate.
     *
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Getter updatedBy.
     *
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Setter updatedBy.
     *
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * Getter updatedDate.
     *
     * @return the updatedDate
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Setter updatedDate.
     *
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Gets the downscale flag.
     *
     * @return the downscale flag
     */
    public boolean getDownscaleFlag() {
        return downscaleFlag;
    }

    /**
     * Sets the downscale flag.
     *
     * @param downscaleFlag the new downscale flag
     */
    public void setDownscaleFlag(boolean downscaleFlag) {
        this.downscaleFlag = downscaleFlag;
    }

    /**
     * Gets the speed limit flag.
     *
     * @return the speed limit flag
     */
    public boolean getSpeedLimitFlag() {
        return speedLimitFlag;
    }

    /**
     * Sets the speed limit flag.
     *
     * @param speedLimitFlag the new speed limit flag
     */
    public void setSpeedLimitFlag(boolean speedLimitFlag) {
        this.speedLimitFlag = speedLimitFlag;
    }

}
