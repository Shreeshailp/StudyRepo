/*
 * Creation : 14 avr. 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Interface CycleDetailsRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface CycleDetailsRepository extends GenericRepository<CycleDetails, UUID> {
    /**
     * Check that the cycle details identified by the specified key exists.
     *
     * @param code the cycle code
     * @return true if the cycle details exists, false otherwise.
     */
    @Read
    boolean exists(String code);

    /**
     * Read the aggregate identified by the specified code.
     *
     * @param code the aggregate key
     * @return cycle the cycle detail entity retrieved
     */
    @Read
    Optional<CycleDetails> byCode(String code);

    /**
     * By uuids.
     *
     * @param uuids the uuids
     * @return the list
     */
    @Read
    List<CycleDetails> byUUIDs(List<UUID> uuids);
}
