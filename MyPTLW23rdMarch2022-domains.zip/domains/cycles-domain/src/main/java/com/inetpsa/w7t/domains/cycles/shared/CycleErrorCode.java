/*
 * Creation : 1 avr. 2017
 */
package com.inetpsa.w7t.domains.cycles.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum CycleErrorCode.
 */
public enum CycleErrorCode implements ErrorCode {

    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(111, "At least one line of the file is not recognized, the import has not been performed", "RG12"),
    /** The only one metadata check. */
    ONLY_ONE_METADATA_CHECK(112, "Metadata line missing or multiple, the import was not performed. Stop processing", "RG14"),
    /** The line m out of format. */
    LINE_M_OUT_OF_FORMAT(113, "At least one of the metadata is not in the defined format, the import was not performed. Stop processing", "RG15"),
    /** The not enough data. */
    NOT_ENOUGH_DATA(114, "The file has fewer than two profile points, the import has not been performed. Stop processing.", "RG16"),
    /** The line d out of format. */
    LINE_D_OUT_OF_FORMAT(115, "At least one point in the profile is not in the required format, the import was not made. Stop processing", "RG17"),
    /** The cycle profile exists. */
    CYCLE_PROFILE_EXISTS(116, "This Cycle Profile already exists in the database, Do you confirm its replacement with that of the selected file?",
            "RG18"),
    /** Unknown technical exception. */
    UNKNOWN_TECHNICAL_EXCEPTION(119, "Unknown technical exception", "RGXX"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    CYCLE_PROFILE_EXISTS_WITH_GENERATED_CYCLE(120,
            "Be careful there are downscaled or limited cycles related to this cycle. If you update this cycle they will be automatically deleted. Attention for phases low mid high ehigh cycles combined / city are not recalculated automatically.Would you like to continue ?",
            "RG20");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new cycle error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    CycleErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
