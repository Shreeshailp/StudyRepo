/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.domains.cycles.shared.internal;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;
import com.inetpsa.w7t.domains.cycles.shared.CycleErrorCode;
import com.inetpsa.w7t.domains.cycles.shared.CycleReferencesPolicy;
import com.inetpsa.w7t.domains.cycles.shared.CycleValidationException;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;

/**
 * The Class CycleReferencesPolicyImpl.
 */
public class CycleReferencesPolicyImpl implements CycleReferencesPolicy {

    /** The cycle phase repo. */
    @Inject
    CyclePhaseRepository cyclePhaseRepo;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.cycles.shared.CycleReferencesPolicy#isValid(com.inetpsa.w7t.domains.cycles.model.CycleDetails)
     */
    @Override
    public boolean isValid(CycleDetails cycleDetails) {

        /** RG15 **/
        if (!cyclePhaseRepo.exists(cycleDetails.getPhase())) {
            throw new CycleValidationException(CycleErrorCode.LINE_M_OUT_OF_FORMAT);
        }

        return true;

    }

}
