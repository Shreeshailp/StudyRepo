/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.exception;

import org.seedstack.seed.SeedException;

/**
 * The Class GeneratedCycleException.
 */
public class GeneratedCycleException extends SeedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6128794118118832438L;

    /**
     * Instantiates a new cycle validation exception.
     *
     * @param errorCode the error code
     */
    public GeneratedCycleException(GeneratedCycleErrorCode errorCode) {

        super(errorCode);

    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {

        return ((GeneratedCycleErrorCode) this.getErrorCode()).getDescription();

    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((GeneratedCycleErrorCode) this.getErrorCode()).getRuleCode();
    }
}
