/*
 * Creation : 14 avr. 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.jpa;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Class CycleDetailsJpaRepository. This is the JPA Implementation of the
 * {@link CycleDetailsRepository}.
 * 
 * @see CycleDetailsRepository
 */
public class CycleDetailsJpaRepository extends BaseJpaRepository<CycleDetails, UUID> implements CycleDetailsRepository {

	/** The Constant CODE. */
	private static final String CODE = "code";
	private static final String ID = "guid";

	/**
	 * {@inheritDoc}
	 * 
	 * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository#exists(java.lang.String)
	 */
	@Override
	public boolean exists(String code) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<CycleDetails> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
		Root<CycleDetails> root = criteriaQuery.from(aggregateRootClass);
		criteriaQuery.select(root.get(CODE));
		criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

		return entityManager.createQuery(criteriaQuery).setParameter(CODE, code).getResultList().size() == 1;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository#byCode(java.lang.String)
	 */
	@Override
	public Optional<CycleDetails> byCode(String code) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<CycleDetails> q = cb.createQuery(CycleDetails.class);
		Root<CycleDetails> root = q.from(CycleDetails.class);
		q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)));

		TypedQuery<CycleDetails> query = entityManager.createQuery(q);
		query.setParameter(CODE, code);
		return query.getResultList().stream().findFirst();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle.CycleDetailsRepository#byUUIDs(java.util.List)
	 */
	@Override
	public List<CycleDetails> byUUIDs(List<UUID> uuids) {

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<CycleDetails> q = cb.createQuery(CycleDetails.class);
		Root<CycleDetails> root = q.from(CycleDetails.class);
		q.select(root);
		Expression<String> parentExpression = root.get(ID);
		Predicate parentPredicate = parentExpression.in(uuids);
		q.where(parentPredicate);
		TypedQuery<CycleDetails> query = entityManager.createQuery(q);

		/*
		 * final String parameterizedQuery =
		 * "select * from W7TQTCYL where ID in (:idList)"; return
		 * entityManager.createNativeQuery(parameterizedQuery).setParameter(
		 * "idList", uuids).getResultList();
		 */

		/*
		 * TypedQuery<CycleDetails> query =
		 * entityManager.createQuery("FROM CycleDetails where ID in (:idList)",
		 * CycleDetails.class); query.setParameter("idList", uuids);
		 * 
		 */

		return query.getResultList();
	}
}
