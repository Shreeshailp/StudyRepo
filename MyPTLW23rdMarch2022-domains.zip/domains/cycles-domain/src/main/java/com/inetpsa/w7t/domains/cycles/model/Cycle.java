/*
 * Creation : 9 févr. 2017
 */
package com.inetpsa.w7t.domains.cycles.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.cycles.validation.CycleCode;
import com.inetpsa.w7t.domains.cycles.validation.CycleComment;
import com.inetpsa.w7t.domains.references.validation.CyclePhaseCode;

/**
 * The Class Cycle. This represents the summary of a cycle.
 * 
 * @see CycleDetails
 */
@Entity
@Table(name = "W7TQTCYL")
public class Cycle extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code. */
    @CycleCode
    @Column(name = "CODE")
    private String code;

    /** The phase. */
    @CyclePhaseCode
    @Column(name = "PHASE")
    private String phase;

    /** The comment. */
    @CycleComment
    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "CYCLE_MAX_VELOCITY")
    private Double cycleMaxVelocity;

    public Double getCycleMaxVelocity() {
        return cycleMaxVelocity;
    }

    public void setCycleMaxVelocity(Double cycleMaxVelocity) {
        this.cycleMaxVelocity = cycleMaxVelocity;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof Cycle))
            return false;

        Cycle other = (Cycle) o;
        String hash = new StringBuilder(code).append(phase).append(comment).toString();
        String otherHash = new StringBuilder(other.code).append(other.phase).append(other.comment).toString();
        return hash.equals(otherHash);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + code.hashCode();
        hashcode = hashcode * 31 + phase.hashCode();
        return hashcode * 31 + comment.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Gets the comment.
     *
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the comment.
     *
     * @param comment the new comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

}
