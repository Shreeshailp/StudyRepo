/*
 * Creation : 27 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycle.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang.time.StopWatch;
import org.javatuples.Pair;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository;
import com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle;

/**
 * The Class GeneratedCycleJpaRepository.
 */
public class GeneratedCycleJpaRepository extends BaseJpaRepository<com.inetpsa.w7t.domains.generatedcycles.model.GeneratedCycle, UUID>
        implements GeneratedCycleRepository {

    @Logging
    private Logger logger;

    /** The Constant GENERATED_CODE. */
    private static final String GENERATED_CODE = "generatedCode";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /** The Constant CYCLE_CODE. */
    private static final String CYCLE_CODE = "cycleCode";

    /** The Constant F_DSC. */
    // private static final String F_DSC = "fdsc";

    /** The Constant MAX_SPEED. */
    // private static final String MAX_SPEED = "speedLimit";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository#all(org.javatuples.Pair)
     */
    @Override
    public List<GeneratedCycle> all(Pair<String, String> filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> q = cb.createQuery(aggregateRootClass);
        Root<GeneratedCycle> root = q.from(aggregateRootClass);

        Optional<String> code = Optional.ofNullable(filter.getValue0());

        code.ifPresent(c -> q.where(cb.like(root.get(GENERATED_CODE), cb.parameter(String.class, GENERATED_CODE))));

        TypedQuery<GeneratedCycle> query = entityManager.createQuery(q);

        code.ifPresent(c -> query.setParameter(GENERATED_CODE, new StringBuilder().append("%").append(c).append("%").toString()));

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository#exists(java.lang.String)
     */
    @Override
    public boolean exists(String generatedCode) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<GeneratedCycle> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(GENERATED_CODE), cb.parameter(String.class, GENERATED_CODE)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(GENERATED_CODE, generatedCode);

        return query.getResultList().stream().findFirst().isPresent();
    }

    @Override
    public Optional<GeneratedCycle> byGeneratedCode(String requestId, String generatedCode) {
        StopWatch sw = new StopWatch();
        sw.start();
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> q = cb.createQuery(aggregateRootClass);
        Root<GeneratedCycle> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(GENERATED_CODE), cb.parameter(String.class, GENERATED_CODE)));

        TypedQuery<GeneratedCycle> query = entityManager.createQuery(q);
        query.setParameter(GENERATED_CODE, generatedCode);
        Optional<GeneratedCycle> generatedCycle = query.getResultList().stream().findFirst();
        sw.stop();
        logger.info("Request ID[{}]: The time taken to retrieve generated cycle is {}ms", requestId, sw.getTime());
        return generatedCycle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository#byCycleCodeFDownscaleMaxSpeed(java.lang.String,
     *      java.lang.Float, java.lang.Integer)
     */
    @SuppressWarnings("unchecked")
    @Override
    public GeneratedCycle byCycleCodeFDownscaleMaxSpeed(String cycleCode, Float fDownScale, Integer maxSpeed) {
        Query query = entityManager.createNativeQuery(
                "select * from W7TQTCYG cyg where cyg.CYCLE_CODE=? AND ((trim(cyg.F_DSC))=?) AND cyg.SPEED_LIMIT=?", GeneratedCycle.class);

        query.setParameter(1, cycleCode);
        query.setParameter(2, fDownScale);
        if (maxSpeed == null) {
            maxSpeed = 0;
        }
        query.setParameter(3, maxSpeed);
        StopWatch sw = new StopWatch();
        sw.start();
        List<GeneratedCycle> generatedCyclesList = query.getResultList();
        GeneratedCycle generatedCycle = null;
        if (generatedCyclesList != null && !generatedCyclesList.isEmpty()) {
            generatedCycle = generatedCyclesList.get(0);
        }
        sw.stop();
        logger.info("The time taken to retrieve generated cycle is {}ms", sw.getTime());
        return generatedCycle;
    }

    /*
     * @Override public GeneratedCycle byCycleCodeFDownscaleMaxSpeed(String cycleCode, Float fDownScale, Integer maxSpeed) { CriteriaBuilder cb =
     * entityManager.getCriteriaBuilder(); CriteriaQuery<GeneratedCycle> q = cb.createQuery(aggregateRootClass); Root<GeneratedCycle> root =
     * q.from(aggregateRootClass); List<Predicate> predicatesList = new ArrayList<>(); predicatesList.add(cb.equal(root.get(CYCLE_CODE),
     * cb.parameter(String.class, CYCLE_CODE)));
     * 
     * if (fDownScale != null) { predicatesList.add(cb.and((cb.equal(cb.trim(root.get(F_DSC)), fDownScale)))); } else {
     * predicatesList.add((cb.isNull(cb.trim(root.get(F_DSC))))); }
     * 
     * if (maxSpeed != null) { predicatesList.add(cb.and((cb.equal(root.get(MAX_SPEED), maxSpeed)))); } else {
     * predicatesList.add((cb.equal(root.get(MAX_SPEED), 0))); } q.where(predicatesList.toArray(new Predicate[] {})); TypedQuery<GeneratedCycle> query
     * = entityManager.createQuery(q); query.setParameter(CYCLE_CODE, cycleCode); List<GeneratedCycle> generatedCyclesList = query.getResultList();
     * GeneratedCycle generatedCycle = null; if (generatedCyclesList != null && !generatedCyclesList.isEmpty()) { generatedCycle =
     * generatedCyclesList.get(0); } return generatedCycle; }
     */

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.generatedcycles.infrastructure.persistence.generatedcycles.GeneratedCycleRepository#deleteByCycleCode(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public int deleteByCycleCode(String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaDelete<GeneratedCycle> query = criteriaBuilder.createCriteriaDelete(GeneratedCycle.class);
        Root<GeneratedCycle> root = query.from(GeneratedCycle.class);
        query.where(criteriaBuilder.equal(root.get(CYCLE_CODE), criteriaBuilder.parameter(String.class, CYCLE_CODE)));
        TypedQuery<GeneratedCycle> q = (TypedQuery<GeneratedCycle>) entityManager.createQuery(query);
        q.setParameter(CYCLE_CODE, code);

        return q.executeUpdate();
    }

    @Override
    public GeneratedCycle byCycleCode(String cycleCode) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<GeneratedCycle> q = cb.createQuery(aggregateRootClass);
        Root<GeneratedCycle> root = q.from(aggregateRootClass);
        List<Predicate> predicatesList = new ArrayList<>();
        predicatesList.add(cb.equal(root.get(CYCLE_CODE), cb.parameter(String.class, CYCLE_CODE)));
        q.where(predicatesList.toArray(new Predicate[] {}));
        TypedQuery<GeneratedCycle> query = entityManager.createQuery(q);
        query.setParameter(CYCLE_CODE, cycleCode);
        List<GeneratedCycle> generatedCyclesList = query.getResultList();
        GeneratedCycle generatedCycle = null;
        if (generatedCyclesList != null && !generatedCyclesList.isEmpty()) {
            generatedCycle = generatedCyclesList.get(0);
        }
        return generatedCycle;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GeneratedCycle> findAll() {
        Query query = entityManager.createNativeQuery("select * from W7TQTCYG", GeneratedCycle.class);

        return query.getResultList();
    }

}
