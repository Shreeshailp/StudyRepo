/*
 * Creation : 26 Mar 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.generatedcycles.model;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Class GeneratedCycle. This represents the summary of a generated cycle.
 * 
 * @see CycleDetails
 */
@Entity
@Table(name = "W7TQTCYG")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class GeneratedCycle extends BaseAggregateRoot<UUID> implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The generated code. */
    @Column(name = "GENERATED_CODE")
    private String generatedCode;

    /** The code. */
    @Column(name = "CYCLE_CODE")
    private String cycleCode;

    /** The phase. */
    @Column(name = "PHASE")
    private String phase;

    /** The downscale coefficient. */
    @Column(name = "F_DSC")
    private Float fdsc;

    /** The speed limit. */
    @Column(name = "SPEED_LIMIT")
    private int speedLimit;

    /** The total distance. */
    @Column(name = "TOTAL_DISTANCE")
    private Float totalDistance;

    /** The v_max. */
    @Column(name = "V_MAX")
    private Float vMax;

    /** The downscale flag. */
    @Column(name = "DOWN_SCALE_FLAG")
    private boolean downscaleFlag;

    /** The speed limit flag. */
    @Column(name = "SPEED_LIMIT_FLAG")
    private boolean speedLimitFlag;

    /** The createdBy. */
    @Column(name = "CREATED_BY")
    private String createdBy;

    /** The createdDate. */
    @Column(name = "CREATED_DATE")
    private String createdDate;

    /** The updatedBy. */
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    /** The updatedDate. */
    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    /** The generated cycle profiles. */
    @JsonIgnore
    @OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("time")
    @JoinColumn(name = "GENERATED_CYCLE_ID", nullable = false)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<GeneratedCycleProfile> genCycleProfiles;

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    public UUID getEntityId() {
        return guid;
    }

    /**
     * Getter guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid.
     *
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Getter generatedCode.
     *
     * @return the generatedCode
     */
    public String getGeneratedCode() {
        return generatedCode;
    }

    /**
     * Setter generatedCode.
     *
     * @param generatedCode the generatedCode to set
     */
    public void setGeneratedCode(String generatedCode) {
        this.generatedCode = generatedCode;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
        this.phase = phase;
    }

    /**
     * Getter cycleCode.
     *
     * @return the cycleCode
     */
    public String getCycleCode() {
        return cycleCode;
    }

    /**
     * Setter cycleCode.
     *
     * @param cycleCode the cycleCode to set
     */
    public void setCycleCode(String cycleCode) {
        this.cycleCode = cycleCode;
    }

    /**
     * Gets the fdsc.
     *
     * @return the fdsc
     */
    public Float getFdsc() {
        return fdsc;
    }

    /**
     * Sets the fdsc.
     *
     * @param fdsc the new fdsc
     */
    public void setFdsc(Float fdsc) {
        this.fdsc = fdsc;
    }

    /**
     * Sets the downscale flag.
     *
     * @param downscaleFlag the new downscale flag
     */
    public void setDownscaleFlag(boolean downscaleFlag) {
        this.downscaleFlag = downscaleFlag;
    }

    /**
     * Sets the speed limit flag.
     *
     * @param speedLimitFlag the new speed limit flag
     */
    public void setSpeedLimitFlag(boolean speedLimitFlag) {
        this.speedLimitFlag = speedLimitFlag;
    }

    /**
     * Getter speedLimit.
     *
     * @return the speedLimit
     */
    public int getSpeedLimit() {
        return speedLimit;
    }

    /**
     * Setter speedLimit.
     *
     * @param speedLimit the speedLimit to set
     */
    public void setSpeedLimit(int speedLimit) {
        this.speedLimit = speedLimit;
    }

    /**
     * Getter totalDistance.
     *
     * @return the totalDistance
     */
    public Float getTotalDistance() {
        return totalDistance;
    }

    /**
     * Setter totalDistance.
     *
     * @param totalDistance the totalDistance to set
     */
    public void setTotalDistance(Float totalDistance) {
        this.totalDistance = totalDistance;
    }

    /**
     * Getter vMax.
     *
     * @return the vMax
     */
    public Float getvMax() {
        return vMax;
    }

    /**
     * Setter vMax.
     *
     * @param vMax the vMax to set
     */
    public void setvMax(Float vMax) {
        this.vMax = vMax;
    }

    /**
     * Checks if is downscale flag.
     *
     * @return true, if is downscale flag
     */
    public boolean isDownscaleFlag() {
        return downscaleFlag;
    }

    /**
     * Getter speedLimitFlag.
     *
     * @return the speedLimitFlag
     */
    public boolean isSpeedLimitFlag() {
        return speedLimitFlag;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Setter createdBy.
     *
     * @param createdBy the createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Getter updatedBy.
     *
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Setter updatedBy.
     *
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * /** Getter createdDate.
     *
     * @return the createdDate
     */
    public String getCreatedDate() {
        return createdDate;
    }

    /**
     * Getter genCycleProfiles.
     *
     * @return the genCycleProfiles
     */
    public List<GeneratedCycleProfile> getGenCycleProfiles() {
        return genCycleProfiles;
    }

    /**
     * Setter genCycleProfiles.
     *
     * @param genCycleProfiles the genCycleProfiles to set
     */
    public void setGenCycleProfiles(List<GeneratedCycleProfile> genCycleProfiles) {
        this.genCycleProfiles = genCycleProfiles;
    }

    /**
     * Setter createdDate.
     *
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * Getter updatedDate.
     *
     * @return the updatedDate
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Setter updatedDate.
     *
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
        result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
        result = prime * result + ((cycleCode == null) ? 0 : cycleCode.hashCode());
        result = prime * result + (downscaleFlag ? 1231 : 1237);
        result = prime * result + ((fdsc == null) ? 0 : fdsc.hashCode());
        result = prime * result + ((genCycleProfiles == null) ? 0 : genCycleProfiles.hashCode());
        result = prime * result + ((generatedCode == null) ? 0 : generatedCode.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((phase == null) ? 0 : phase.hashCode());
        result = prime * result + speedLimit;
        result = prime * result + (speedLimitFlag ? 1231 : 1237);
        result = prime * result + ((totalDistance == null) ? 0 : totalDistance.hashCode());
        result = prime * result + ((updatedBy == null) ? 0 : updatedBy.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        result = prime * result + ((vMax == null) ? 0 : vMax.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        GeneratedCycle other = (GeneratedCycle) obj;
        if (createdBy == null) {
            if (other.createdBy != null)
                return false;
        } else if (!createdBy.equals(other.createdBy))
            return false;
        if (createdDate == null) {
            if (other.createdDate != null)
                return false;
        } else if (!createdDate.equals(other.createdDate))
            return false;
        if (cycleCode == null) {
            if (other.cycleCode != null)
                return false;
        } else if (!cycleCode.equals(other.cycleCode))
            return false;
        if (downscaleFlag != other.downscaleFlag)
            return false;
        if (fdsc == null) {
            if (other.fdsc != null)
                return false;
        } else if (!fdsc.equals(other.fdsc))
            return false;
        if (genCycleProfiles == null) {
            if (other.genCycleProfiles != null)
                return false;
        } else if (!genCycleProfiles.equals(other.genCycleProfiles))
            return false;
        if (generatedCode == null) {
            if (other.generatedCode != null)
                return false;
        } else if (!generatedCode.equals(other.generatedCode))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (phase == null) {
            if (other.phase != null)
                return false;
        } else if (!phase.equals(other.phase))
            return false;
        if (speedLimit != other.speedLimit)
            return false;
        if (speedLimitFlag != other.speedLimitFlag)
            return false;
        if (totalDistance == null) {
            if (other.totalDistance != null)
                return false;
        } else if (!totalDistance.equals(other.totalDistance))
            return false;
        if (updatedBy == null) {
            if (other.updatedBy != null)
                return false;
        } else if (!updatedBy.equals(other.updatedBy))
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        if (vMax == null) {
            if (other.vMax != null)
                return false;
        } else if (!vMax.equals(other.vMax))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "GeneratedCycle [guid=" + guid + ", generatedCode=" + generatedCode + ", cycleCode=" + cycleCode + ", phase=" + phase + ", fdsc="
                + fdsc + ", speedLimit=" + speedLimit + ", totalDistance=" + totalDistance + ", vMax=" + vMax + ", downscaleFlag=" + downscaleFlag
                + ", speedLimitFlag=" + speedLimitFlag + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy
                + ", updatedDate=" + updatedDate + "]";
    }

}
