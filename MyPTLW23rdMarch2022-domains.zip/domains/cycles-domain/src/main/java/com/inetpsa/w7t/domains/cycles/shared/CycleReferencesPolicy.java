/*
 * Creation : 15 mars 2017
 */
package com.inetpsa.w7t.domains.cycles.shared;

import org.seedstack.business.domain.DomainPolicy;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

/**
 * The Interface CycleReferencesPolicy.
 */
@DomainPolicy
@FunctionalInterface
public interface CycleReferencesPolicy {

    /**
     * Checks if is valid.
     *
     * @param cycleDetails the cycle details
     * @return true, if is valid
     */
    boolean isValid(CycleDetails cycleDetails);
}
