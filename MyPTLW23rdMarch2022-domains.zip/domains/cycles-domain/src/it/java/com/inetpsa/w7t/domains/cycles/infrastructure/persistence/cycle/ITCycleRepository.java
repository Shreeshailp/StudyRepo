/*
 * Creation : 1 mars 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.javatuples.Pair;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.cycles.model.Cycle;

@RunWith(SeedITRunner.class)
public class ITCycleRepository {

    @Inject
    private CycleRepository cycleRepository;

    @Test
    public void allCycles() {
        Pair<String, String> filter = new Pair<>(null, null);

        List<Cycle> cycle = cycleRepository.all(filter);

        assertThat(cycle).isNotNull();

    }

    @Test
    public void cycleWithExistingCode() {
        Optional<Cycle> cycle = cycleRepository.byCode("STDLOW01");

        assertThat(cycle.isPresent()).isTrue();
        assertThat(cycle.get().getPhase()).isEqualToIgnoringCase("LOW");
        assertThat(cycle.get().getComment()).isEqualToIgnoringCase("Low Europe");
        assertThat(cycle.get().getGuid()).hasToString("7a703524-f79d-4e43-9574-dffd7c2bb9b0");
    }

    @Test
    public void cycleWithNonExistingCode() {
        Optional<Cycle> cycle = cycleRepository.byCode("STD02LO");

        assertThat(cycle.isPresent()).isFalse();
    }

    @Test
    public void cycleWithNullCode() {
        Optional<Cycle> cycle = cycleRepository.byCode(null);

        assertThat(cycle.isPresent()).isFalse();
    }

    @Test
    public void cycleExists() {
        boolean cycle = cycleRepository.exists("STDLOW01");

        assertThat(cycle).isTrue();
    }

    @Test
    public void cycleNotExists() {
        boolean cycle = cycleRepository.exists("STD02CIT");

        assertThat(cycle).isFalse();
    }
}
