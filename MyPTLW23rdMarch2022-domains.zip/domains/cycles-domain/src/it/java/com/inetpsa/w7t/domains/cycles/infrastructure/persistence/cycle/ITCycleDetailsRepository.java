/*
 * Creation : 30 mai 2017
 */
package com.inetpsa.w7t.domains.cycles.infrastructure.persistence.cycle;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.google.inject.Inject;
import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

@RunWith(SeedITRunner.class)
public class ITCycleDetailsRepository {

    @Inject
    private CycleDetailsRepository cycleDetailsRepository;

    @Test
    public void cycleWithExistingCode() {
        Optional<CycleDetails> cycle = cycleDetailsRepository.byCode("STDLOW01");

        assertThat(cycle.isPresent()).isTrue();
        assertThat(cycle.get().getPhase()).isEqualToIgnoringCase("LOW");
        assertThat(cycle.get().getComment()).isEqualToIgnoringCase("Low Europe");
        assertThat(cycle.get().getGuid()).hasToString("7a703524-f79d-4e43-9574-dffd7c2bb9b0");
    }

    @Test
    public void cycleWithNonExistingCode() {
        Optional<CycleDetails> cycle = cycleDetailsRepository.byCode("STD02LO");

        assertThat(cycle.isPresent()).isFalse();
    }

    @Test
    public void cycleExists() {
        boolean cycle = cycleDetailsRepository.exists("STDLOW01");

        assertThat(cycle).isTrue();
    }

    @Test
    public void cycleNotExists() {
        boolean cycle = cycleDetailsRepository.exists("STD02CIT");

        assertThat(cycle).isFalse();
    }
}
