/*
 * Creation : 31 mars 2017
 */
package com.inetpsa.w7t.domains.cycles.shared;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.cycles.model.CycleDetails;

@RunWith(SeedITRunner.class)
public class ITCycleReferencesPolicy {

    @Inject
    private CycleReferencesPolicy cycleReferencesPolicy;

    @Test
    public void testThatIsValidMethodRunsSuccessfully() {
        CycleDetails cyc = new CycleDetails();

        cyc.setPhase("MID");

        boolean testOfCycle = cycleReferencesPolicy.isValid(cyc);
        assertThat(testOfCycle).isEqualTo(true);
    }

}
