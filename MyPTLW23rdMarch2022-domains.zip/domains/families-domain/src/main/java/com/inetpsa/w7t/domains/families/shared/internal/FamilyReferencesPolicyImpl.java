/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.domains.families.shared.internal;

import javax.inject.Inject;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.shared.FamilyErrorCode;
import com.inetpsa.w7t.domains.families.shared.FamilyReferencesPolicy;
import com.inetpsa.w7t.domains.families.shared.FamilyValidationException;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.RoadLoadTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.VehicleTypeRepository;

/**
 * The Class FamilyReferencesPolicyImpl. Implementation of the {@link FamilyReferencesPolicy}.
 */
public class FamilyReferencesPolicyImpl implements FamilyReferencesPolicy {

    @Inject
    private VehicleTypeRepository vehicleTypeRepository;

    @Inject
    private RoadLoadTypeRepository roadLoadTypeRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.shared.FamilyReferencesPolicy#isValid(FamilyDetails)
     */
    @Override
    public boolean isValid(FamilyDetails fam) {

        boolean success = true;
        /** RG41 **/
        if (!vehicleTypeRepository.exists(fam.getType())) {
            Integer[] lineNum = { fam.getLineNumber() != null ? fam.getLineNumber() : 0 };
            throw new FamilyValidationException(FamilyErrorCode.VEHICLE_TYPE_NOT_EXISTS, lineNum);
        }

        /** RG42 **/
        if (!roadLoadTypeRepository.exists(fam.getRoadLoad())) {
            Integer[] lineNum = { fam.getLineNumber() != null ? fam.getLineNumber() : 1 };
            throw new FamilyValidationException(FamilyErrorCode.VEHICLE_ROADLOAD_NOT_EXISTS, lineNum);
        }

        return success;

    }

}
