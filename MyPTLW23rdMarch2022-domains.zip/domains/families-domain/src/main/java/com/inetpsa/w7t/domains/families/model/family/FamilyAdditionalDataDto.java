/*
 * Creation : 21 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.families.model.family;

import java.util.UUID;

import org.seedstack.business.assembler.DtoOf;

/**
 * The Class FamilyAdditionalDataDto.
 *
 * @author E569186
 */
@DtoOf(FamilyAdditionalData.class)
public class FamilyAdditionalDataDto {

    /** The id. */
    private UUID id;

    /** The t8c. */
    private String t8c;

    /** The t8d. */
    private String t8d;

    /** The vehicle families. */
    private String vehicleFamilies;

    /** The motor B 0 F. */
    private String motorB0F;

    // /** The gearbox B 0 G. */
    // private String gearboxB0G;

    /** The gear box. */
    private String gearBox;

    /** The motor dkc. */
    private String motorDkc;

    /** The dld date. */
    private String dldDate;

    /** The dll date. */
    private String dllDate;

    /** The first reg date. */
    private String firstRegDate;

    /** The rce date. */
    private String rceDate;

    /** The window. */
    private String window;

    /** The url dossier. */
    private String urlDossier;

    /** The url pv. */
    private String urlPv;

    /** The url import file. */
    private String urlImportFile;

    /** The fam id. */
    private String famId;

    /** The family. */
    private Family family;

    /**
     * Getter id.
     *
     * @return the id
     */
    public UUID getId() {
        return id;
    }

    /**
     * Setter id.
     *
     * @param id the id to set
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Getter t8c.
     *
     * @return the t8c
     */
    public String getT8c() {
        return t8c;
    }

    /**
     * Setter t8c.
     *
     * @param t8c the t8c to set
     */
    public void setT8c(String t8c) {
        this.t8c = t8c;
    }

    /**
     * Getter t8d.
     *
     * @return the t8d
     */
    public String getT8d() {
        return t8d;
    }

    /**
     * Setter t8d.
     *
     * @param t8d the t8d to set
     */
    public void setT8d(String t8d) {
        this.t8d = t8d;
    }

    /**
     * Getter vehicleFamilies.
     *
     * @return the vehicleFamilies
     */
    public String getVehicleFamilies() {
        return vehicleFamilies;
    }

    /**
     * Setter vehicleFamilies.
     *
     * @param vehicleFamilies the vehicleFamilies to set
     */
    public void setVehicleFamilies(String vehicleFamilies) {
        this.vehicleFamilies = vehicleFamilies;
    }

    /**
     * Getter motorB0F.
     *
     * @return the motorB0F
     */
    public String getMotorB0F() {
        return motorB0F;
    }

    /**
     * Setter motorB0F.
     *
     * @param motorB0F the motorB0F to set
     */
    public void setMotorB0F(String motorB0F) {
        this.motorB0F = motorB0F;
    }

    // /**
    // * Getter gearboxB0G
    // *
    // * @return the gearboxB0G
    // */
    // public String getGearboxB0G() {
    // return gearboxB0G;
    // }
    //
    // /**
    // * Setter gearboxB0G
    // *
    // * @param gearboxB0G the gearboxB0G to set
    // */
    // public void setGearboxB0G(String gearboxB0G) {
    // this.gearboxB0G = gearboxB0G;
    // }

    /**
     * Getter motorDkc.
     *
     * @return the motorDkc
     */
    public String getMotorDkc() {
        return motorDkc;
    }

    /**
     * Gets the gear box.
     *
     * @return the gear box
     */
    public String getGearBox() {
        return gearBox;
    }

    /**
     * Sets the gear box.
     *
     * @param gearBox the new gear box
     */
    public void setGearBox(String gearBox) {
        this.gearBox = gearBox;
    }

    /**
     * Setter motorDkc.
     *
     * @param motorDkc the motorDkc to set
     */
    public void setMotorDkc(String motorDkc) {
        this.motorDkc = motorDkc;
    }

    /**
     * Getter dldDate.
     *
     * @return the dldDate
     */
    public String getDldDate() {
        return dldDate;
    }

    /**
     * Setter dldDate.
     *
     * @param dldDate the dldDate to set
     */
    public void setDldDate(String dldDate) {
        this.dldDate = dldDate;
    }

    /**
     * Getter dllDate.
     *
     * @return the dllDate
     */
    public String getDllDate() {
        return dllDate;
    }

    /**
     * Setter dllDate.
     *
     * @param dllDate the dllDate to set
     */
    public void setDllDate(String dllDate) {
        this.dllDate = dllDate;
    }

    /**
     * Getter firstRegDate.
     *
     * @return the firstRegDate
     */
    public String getFirstRegDate() {
        return firstRegDate;
    }

    /**
     * Setter firstRegDate.
     *
     * @param firstRegDate the firstRegDate to set
     */
    public void setFirstRegDate(String firstRegDate) {
        this.firstRegDate = firstRegDate;
    }

    /**
     * Getter rceDate.
     *
     * @return the rceDate
     */
    public String getRceDate() {
        return rceDate;
    }

    /**
     * Setter rceDate.
     *
     * @param rceDate the rceDate to set
     */
    public void setRceDate(String rceDate) {
        this.rceDate = rceDate;
    }

    /**
     * Getter urlDossier.
     *
     * @return the urlDossier
     */
    public String getUrlDossier() {
        return urlDossier;
    }

    /**
     * Setter urlDossier.
     *
     * @param urlDossier the urlDossier to set
     */
    public void setUrlDossier(String urlDossier) {
        this.urlDossier = urlDossier;
    }

    /**
     * Getter urlPv.
     *
     * @return the urlPv
     */
    public String getUrlPv() {
        return urlPv;
    }

    /**
     * Setter urlPv.
     *
     * @param urlPv the urlPv to set
     */
    public void setUrlPv(String urlPv) {
        this.urlPv = urlPv;
    }

    /**
     * Getter urlImportFile.
     *
     * @return the urlImportFile
     */
    public String getUrlImportFile() {
        return urlImportFile;
    }

    /**
     * Setter urlImportFile.
     *
     * @param urlImportFile the urlImportFile to set
     */
    public void setUrlImportFile(String urlImportFile) {
        this.urlImportFile = urlImportFile;
    }

    /**
     * Getter window.
     *
     * @return the window
     */
    public String getWindow() {
        return window;
    }

    /**
     * Setter window.
     *
     * @param window the window to set
     */
    public void setWindow(String window) {
        this.window = window;
    }

    /**
     * Getter famId.
     *
     * @return the famId
     */
    public String getFamId() {
        return famId;
    }

    /**
     * Setter famId.
     *
     * @param famId the famId to set
     */
    public void setFamId(String famId) {
        this.famId = famId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "FamilyAdditionalDataDto [id=" + id + ", t8c=" + t8c + ", t8d=" + t8d + ", vehicleFamilies=" + vehicleFamilies + ", motorB0F="
                + motorB0F + ", gearBox=" + gearBox + ", motorDkc=" + motorDkc + ", dldDate=" + dldDate + ", dllDate=" + dllDate + ", firstRegDate="
                + firstRegDate + ", rceDate=" + rceDate + ", window=" + window + ", urlDossier=" + urlDossier + ", urlPv=" + urlPv
                + ", urlImportFile=" + urlImportFile + ", famId=" + famId + "]";
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public Family getFamily() {
        return family;
    }

    /**
     * Sets the family.
     *
     * @param family the new family
     */
    public void setFamily(Family family) {
        this.family = family;
    }

}
