/*
 * Creation : 25 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;

/**
 * @author E569186
 */
@Transactional
public interface FamilyAdditionalDataRepository extends GenericRepository<FamilyAdditionalData, UUID> {

    /**
     * By code and index details.
     *
     * @param code the code
     * @param index the index
     * @return the optional
     */
    @Read
    Optional<FamilyAdditionalData> byCodeAndIndexDetails(String code, String index);

    /**
     * Exists.
     *
     * @param code the code
     * @param index the index
     * @return true, if successful
     */
    @Read
    boolean exists(String code, String index);

    /**
     * Gets the family additional data.
     *
     * @param t8c the t 8 c
     * @param t8d the t 8 d
     * @return the family additional data
     * @throws SQLException the SQL exception
     */
    FamilyAdditionalData getFamilyAdditionalData(String t8c, String t8d) throws SQLException;

    int updateByT8cT8DAndFamilyId(String t8c, String t8d, FamilyAdditionalData familyAdditionalData);
}
