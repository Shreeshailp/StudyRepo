/*
 * Creation : 30 mars 2017
 */
package com.inetpsa.w7t.domains.families.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum FamilyErrorCode.
 */
public enum FamilyErrorCode implements ErrorCode {

    /** The first column empty check. */
    FIRST_COLUMN_EMPTY_CHECK(100, "At least one line of the file is not recognized, the import has not been performed", "RG37"),
    /** The atleast one metadata check. */
    ATLEAST_ONE_METADATA_CHECK(101, "At least one line of the file is not recognized, the import has not been performed", "RG37"),
    /** The line m d couple exists. */
    LINE_M_D_COUPLE_EXISTS(102, "Line {0} At least one data is not in the defined format, the import was not carried out", "RG39"),

    /** The family index already exists. */
    FAMILY_INDEX_ALREADY_EXISTS(103, "{0}/{1}", "RG40"),
    /** The vehicle type not exists. */
    VEHICLE_TYPE_NOT_EXISTS(104, "Line {0} Vehicle type unknown, the import has not been carried out", "RG41"),
    /** The vehicle category not exists. */
    VEHICLE_ROADLOAD_NOT_EXISTS(105, "Line {0} RoadLoadType unknown, the import was not carried out", "RG42"),

    /** The vehicle type ess not exists. */
    VEHICLE_TYPE_ESS_NOT_EXISTS(106, "Line {0} Vehicle test type unknown , import has not been carried out", "RG43"),
    /** The calc type not exists. */
    CALC_TYPE_NOT_EXISTS(107, "Line {0} Calculation type unknown , the import was not carried out", "RG44"),
    /** The ref profile not exists. */
    REF_PROFILE_NOT_EXISTS(108, "Line {0} Ref profile unknown, the import was not carried out", "RG45"),
    /** The unknown exception. */
    UNKNOWN_EXCEPTION(109, "Unknown Technical Exception", "RGXX"),
    /** The PMAX_NOT_EXISTS exception. */
    VEHICLE_PMAX_NOT_EXISTS(110, "Line {0} Pmax unknown, the import was not carried out", "RG42"),
    /** The DOUBLE_NOT_EXISTS exception. */
    LINE_DOUBLE_NOT_EXISTS(111, "Line {0} The Pmax value must be blank or must be a float", "RG39"),
    /** The data missing. */
    DATA_MISSING(112, "Line {0} error ERRW402:data missing for road load computation", "RG39"),

    /** The someone importing data. */
    SOMEONE_IMPORTING_DATA(132, "Someone else is importing data. Please try again later", "RG52"),

    /** The family validated error. */
    FAMILY_VALIDATED_ERROR(133, "The import is about a validated family, import cancelled.", "RG53"),

    /** The family blocked error. */
    FAMILY_BLOCKED_ERROR(134, "The import is about a blocked family, import cancelled.", "RG54"),

    /** The same user tab check error. */
    SAME_USER_TAB_CHECK_ERROR(135, "Import and check can not be done by same user", "RG55"),

    /** The family status not exists. */
    FAMILY_STATUS_NOT_EXISTS(136, "Unknown Family Status", "RG56"),

    /** The cycle not found. */
    CYCLE_NOT_FOUND(137, "missing generated cycles: {0}", "RG39"),

    /** The down scale err. */
    DOWN_SCALE_ERR(138, "error during downscale calculation", "RG39"),

    INDUS_MAINTAINANCE_ERROR(620, "Maintenance is in progress, this treatment can not be done. Please try again in a few minutes.", "ERRT103"),

    /** The energy calcul err. */
    ENERGY_CALCUL_ERR(139, "error during energy calculation", "RG39");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new family error code.
     *
     * @param code        the code
     * @param description the description
     * @param ruleCode    the rule code
     */
    FamilyErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }
}
