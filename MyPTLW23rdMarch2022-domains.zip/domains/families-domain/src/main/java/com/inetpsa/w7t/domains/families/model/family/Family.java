/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.domains.families.model.family;

import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;
import com.inetpsa.w7t.domains.references.validation.VehicleTypeCode;

/**
 * The Class Family. This represents the summary of a WLTP family.
 * 
 * @see FamilyDetails
 */
@Entity
@Table(name = "W7TQTFAM")
public class Family extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The family code. */
    @FamilyCode
    @Column(name = "CODE")
    private String code;

    /** The index. */
    @FamilyIndex
    @Column(name = "IND")
    private Integer index;

    /** The label. */
    @Size(max = 30)
    @Column(name = "LABEL")
    private String label;

    /** The vehicle type code. */
    @VehicleTypeCode
    @Column(name = "TYPE")
    private String type;

    /** The vehicle RoadLoad code. */
    @VehicleRoadLoadType
    @Column(name = "ROADLOAD")
    private String roadLoad;

    /** The vehicle pmax code. */
    @Column(name = "PMAX")
    private String pmax;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /** The blocked. */
    @Column(name = "BLOCKED")
    private Boolean blocked;

    /** The blocking reason. */
    @Column(name = "BLOCKING_REASON")
    private String blockingReason;

    /** The created by. */
    @Column(name = "CREATED_BY")
    private String createdBy;

    /** The created on. */
    @Column(name = "CREATED_ON")
    private String createdOn;

    @OneToOne(mappedBy = "family", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
    @JsonManagedReference
    private FamilyAdditionalData familyAdditionalData;

    public FamilyAdditionalData getFamilyAdditionalData() {
        return familyAdditionalData;
    }

    public void setFamilyAdditionalData(FamilyAdditionalData familyAdditionalData) {
        this.familyAdditionalData = familyAdditionalData;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the created on.
     *
     * @return the created on
     */
    public String getCreatedOn() {
        return createdOn;
    }

    /**
     * Sets the created on.
     *
     * @param createdOn the new created on
     */
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the blocked.
     *
     * @return the blocked
     */
    public Boolean getBlocked() {
        return blocked;
    }

    /**
     * Sets the blocked.
     *
     * @param blocked the new blocked
     */
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    /**
     * Gets the blocking reason.
     *
     * @return the blocking reason
     */
    public String getBlockingReason() {
        return blockingReason;
    }

    /**
     * Sets the blocking reason.
     *
     * @param blockingReason the new blocking reason
     */
    public void setBlockingReason(String blockingReason) {
        this.blockingReason = blockingReason;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return guid;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object o) {
        if (!super.equals(o) || !(o instanceof Family))
            return false;

        Family other = (Family) o;
        String hash = new StringBuilder(code).append(index).append(type).append(roadLoad).append(pmax).append(status).append(blocked).toString();
        String otherHash = new StringBuilder(other.code).append(other.index).append(other.type).append(other.roadLoad).append(other.pmax)
                .append(other.status).toString();
        return hash.equals(otherHash);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        int hashcode = super.hashCode();
        hashcode = hashcode * 31 + code.hashCode();
        hashcode = hashcode * 31 + index.hashCode();
        hashcode = hashcode * 31 + type.hashCode();
        hashcode = hashcode * 31 + roadLoad.hashCode();
        hashcode = hashcode * 31 + pmax.hashCode();
        return hashcode * 31 + status.hashCode();
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the family code.
     *
     * @return the family code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the family code.
     *
     * @param code the new family code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the index.
     *
     * @return the index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Sets the index.
     *
     * @param index the new index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * Getter label.
     * 
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Setter label.
     * 
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the vehicle type code.
     *
     * @return the vehicle type code
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the vehicle type code.
     *
     * @param type the new vehicle type code
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the vehicle roadLoad code.
     *
     * @return roadLoad
     */
    public String getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the roadLoad type.
     *
     * @param roadLoad the new road load
     */
    public void setRoadLoad(String roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Gets the vehicle pmax code.
     *
     * @return pmax
     */
    public String getPmax() {
        return pmax;
    }

    /**
     * Sets the vehicle pmax.
     *
     * @param pmax the new pmax
     */
    public void setPmax(String pmax) {
        this.pmax = pmax;
    }

}
