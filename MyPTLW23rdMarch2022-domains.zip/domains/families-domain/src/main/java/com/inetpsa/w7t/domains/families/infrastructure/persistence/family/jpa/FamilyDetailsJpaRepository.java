/*
 * Creation : 24 avr. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.util.UUID;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyDetailsRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

/**
 * The Class FamilyDetailsJpaRepository.
 */
public class FamilyDetailsJpaRepository extends BaseJpaRepository<FamilyDetails, UUID> implements FamilyDetailsRepository {

}
