/*
 * Creation : 7 févr. 2017
 */
package com.inetpsa.w7t.domains.families.model.details;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import com.inetpsa.w7t.domains.references.model.CyclePhase;
import com.inetpsa.w7t.domains.references.model.MeasureType;

/**
 * The Class MeasureValue. This entity represents a particular measure value of a {@link MeasureType}, made by a {@link TestVehicle} and during a
 * {@link CyclePhase}.
 * 
 * @see TestVehicle
 */
@Embeddable
public class MeasureValue {

    // TODO remove this guid, no need in a Embeddable
    /** The guid. */
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /**
     * The measure type.
     * 
     * @see MeasureType
     */
    @Type(type = "uuid-char")
    @Column(name = "TYPE")
    private UUID type;

    /**
     * The phase code.
     * 
     * @see CyclePhase
     */
    @Type(type = "uuid-char")
    @Column(name = "PHASE")
    private UUID phase;

    /** The value. */
    @NotNull
    @Column(name = "VALUE")
    private Double value;

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the measure type.
     *
     * @return the measure type
     */
    public UUID getType() {
        return type;
    }

    /**
     * Sets the measure type.
     *
     * @param type the new measure type
     */
    public void setType(UUID type) {
        this.type = type;
    }

    /**
     * Gets the phase code.
     *
     * @return the phase code
     */
    public UUID getPhase() {
        return phase;
    }

    /**
     * Sets the phase code.
     *
     * @param phase the new phase code
     */
    public void setPhase(UUID phase) {
        this.phase = phase;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Double getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Double value) {
        this.value = value;
    }
}
