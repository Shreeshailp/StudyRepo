/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.domains.families.shared;

import org.seedstack.business.domain.DomainPolicy;


/**
 * The Interface FamilyPolicy.
 */
@DomainPolicy
@FunctionalInterface
public interface FamilyPolicy {

    /**
     * Validate.
     */
    void validate();
}
