/*
 * Creation : 21 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.families.model.family;

import java.sql.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class FamilyAdditionalData.
 *
 * @author E569186
 */
@Entity
@Table(name = "W7TQTFAD")
public class FamilyAdditionalData extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID id;

    /** The t8c. */
    @Size(max = 2)
    @Column(name = "T8C")
    private String t8c;

    /** The t8d. */
    @Size(max = 2)
    @Column(name = "T8D")
    private String t8d;

    /** The vehicle families. */
    @Size(max = 50)
    @Column(name = "VEHICLE_FAMILIES")
    private String vehicleFamilies;

    /** The motor B 0 F. */
    @Size(max = 2)
    @Column(name = "MOTOR_B0F")
    private String motorB0F;

    // /** The gearbox B 0 G. */
    // @Size(max = 2)
    // @Column(name = "GEARBOX_B0G")
    // private String gearboxB0G;

    /** The motor dkc. */
    @Size(max = 50)
    @Column(name = "MOTOR_DKC")
    private String motorDkc;

    /** The dld date. */
    @Column(name = "DLD_DATE")
    private Date dldDate;

    /** The dll date. */
    @Column(name = "DLL_DATE")
    private Date dllDate;

    /** The first reg date. */
    @Column(name = "FIRST_REG_DATE")
    private Date firstRegDate;

    /** The rce date. */
    @Column(name = "RCE_DATE")
    private Date rceDate;

    /** The window. */
    @Size(max = 50)
    @Column(name = "WINDOW")
    private String window;

    /** The url dossier. */
    @Size(max = 500)
    @Column(name = "URL_DOSSIER")
    private String urlDossier;

    /** The url pv. */
    @Size(max = 500)
    @Column(name = "URL_PV")
    private String urlPv;

    /** The url import file. */
    @Size(max = 500)
    @Column(name = "URL_IMPORT_FILE")
    private String urlImportFile;

    @Size(max = 2)
    @Column(name = "GEARBOX_B0G")
    private String gearBox;

    // /** The fam id. */
    // @Size(max = 36)
    // @Column(name = "FAM_ID")
    // private String famId;

    @OneToOne
    @JoinColumn(name = "FAM_ID", nullable = true, referencedColumnName = "ID")
    @JsonBackReference
    Family family;

    /**
     * Getter id.
     *
     * @return the id
     */
    public UUID getId() {
        return id;
    }

    /**
     * Setter id.
     *
     * @param id the id to set
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Getter t8c.
     *
     * @return the t8c
     */
    public String getT8c() {
        return t8c;
    }

    /**
     * Setter t8c.
     *
     * @param t8c the t8c to set
     */
    public void setT8c(String t8c) {
        this.t8c = t8c;
    }

    /**
     * Getter t8d.
     *
     * @return the t8d
     */
    public String getT8d() {
        return t8d;
    }

    /**
     * Setter t8d.
     *
     * @param t8d the t8d to set
     */
    public void setT8d(String t8d) {
        this.t8d = t8d;
    }

    /**
     * Getter vehicleFamilies.
     *
     * @return the vehicleFamilies
     */
    public String getVehicleFamilies() {
        return vehicleFamilies;
    }

    /**
     * Setter vehicleFamilies.
     *
     * @param vehicleFamilies the vehicleFamilies to set
     */
    public void setVehicleFamilies(String vehicleFamilies) {
        this.vehicleFamilies = vehicleFamilies;
    }

    /**
     * Getter motorB0F.
     *
     * @return the motorB0F
     */
    public String getMotorB0F() {
        return motorB0F;
    }

    /**
     * Setter motorB0F.
     *
     * @param motorB0F the motorB0F to set
     */
    public void setMotorB0F(String motorB0F) {
        this.motorB0F = motorB0F;
    }

    // /**
    // * Getter gearboxB0G.
    // *
    // * @return the gearboxB0G
    // */
    // public String getGearboxB0G() {
    // return gearboxB0G;
    // }
    //
    // /**
    // * Setter gearboxB0G.
    // *
    // * @param gearboxB0G the gearboxB0G to set
    // */
    // public void setGearboxB0G(String gearboxB0G) {
    // this.gearboxB0G = gearboxB0G;
    // }

    /**
     * Getter motorDkc.
     *
     * @return the motorDkc
     */
    public String getMotorDkc() {
        return motorDkc;
    }

    /**
     * Setter motorDkc.
     *
     * @param motorDkc the motorDkc to set
     */
    public void setMotorDkc(String motorDkc) {
        this.motorDkc = motorDkc;
    }

    /**
     * Getter dldDate.
     *
     * @return the dldDate
     */
    public Date getDldDate() {
        return dldDate;
    }

    /**
     * Setter dldDate.
     *
     * @param dldDate the dldDate to set
     */
    public void setDldDate(Date dldDate) {
        this.dldDate = dldDate;
    }

    /**
     * Getter dllDate.
     *
     * @return the dllDate
     */
    public Date getDllDate() {
        return dllDate;
    }

    /**
     * Setter dllDate.
     *
     * @param dllDate the dllDate to set
     */
    public void setDllDate(Date dllDate) {
        this.dllDate = dllDate;
    }

    /**
     * Getter firstRegDate.
     *
     * @return the firstRegDate
     */
    public Date getFirstRegDate() {
        return firstRegDate;
    }

    /**
     * Setter firstRegDate.
     *
     * @param firstRegDate the firstRegDate to set
     */
    public void setFirstRegDate(Date firstRegDate) {
        this.firstRegDate = firstRegDate;
    }

    /**
     * Getter rceDate.
     *
     * @return the rceDate
     */
    public Date getRceDate() {
        return rceDate;
    }

    /**
     * Setter rceDate.
     *
     * @param rceDate the rceDate to set
     */
    public void setRceDate(Date rceDate) {
        this.rceDate = rceDate;
    }

    /**
     * Getter urlDossier.
     *
     * @return the urlDossier
     */
    public String getUrlDossier() {
        return urlDossier;
    }

    /**
     * Setter urlDossier.
     *
     * @param urlDossier the urlDossier to set
     */
    public void setUrlDossier(String urlDossier) {
        this.urlDossier = urlDossier;
    }

    /**
     * Getter urlPv.
     *
     * @return the urlPv
     */
    public String getUrlPv() {
        return urlPv;
    }

    /**
     * Setter urlPv.
     *
     * @param urlPv the urlPv to set
     */
    public void setUrlPv(String urlPv) {
        this.urlPv = urlPv;
    }

    /**
     * Getter urlImportFile.
     *
     * @return the urlImportFile
     */
    public String getUrlImportFile() {
        return urlImportFile;
    }

    /**
     * Setter urlImportFile.
     *
     * @param urlImportFile the urlImportFile to set
     */
    public void setUrlImportFile(String urlImportFile) {
        this.urlImportFile = urlImportFile;
    }

    /**
     * Getter window.
     *
     * @return the window
     */
    public String getWindow() {
        return window;
    }

    /**
     * Setter window.
     *
     * @param window the window to set
     */
    public void setWindow(String window) {
        this.window = window;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    @JsonIgnore
    public UUID getEntityId() {
        return this.id;
    }

    public Family getFamily() {
        return family;
    }

    public void setFamily(Family family) {
        this.family = family;
    }

    public String getGearBox() {
        return gearBox;
    }

    public void setGearBox(String gearBox) {
        this.gearBox = gearBox;
    }

    // /**
    // * Getter famId.
    // *
    // * @return the famId
    // */
    // public String getFamId() {
    // return famId;
    // }
    //
    // /**
    // * Setter famId.
    // *
    // * @param famId the famId to set
    // */
    // public void setFamId(String famId) {
    // this.famId = famId;
    // }

}
