package com.inetpsa.w7t.domains.families.shared;

import org.seedstack.shed.exception.BaseException;

public class FamilyValidationException extends BaseException {

    /** The context. */
    private final transient Object[] context;

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3707368711775150080L;

    /**
     * Instantiates a new family validation exception.
     *
     * @param errorCode the error code
     * @param context the context
     */
    public FamilyValidationException(FamilyErrorCode errorCode, Object[] context) {
        super(errorCode);
        this.context = context;
    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {
        String description = ((FamilyErrorCode) this.getErrorCode()).getDescription();

        if (context != null && context.length > 0) {
            for (int i = 0; i < context.length; i++) {
                description = description.replace("{" + i + "}", context[i].toString());
            }
        }

        return description;
    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((FamilyErrorCode) this.getErrorCode()).getRuleCode();
    }
}
