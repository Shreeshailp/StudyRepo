/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.javatuples.Pair;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;

import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;

/**
 * The Class FamilyJpaRepository. JPA Implementation of the {@link FamilyRepository}.
 * 
 * @see FamilyRepository
 */
@JpaUnit("wltp-domain-jpa-unit")
public class FamilyJpaRepository extends BaseJpaRepository<Family, UUID> implements FamilyRepository {

    /** The Constant CODE. */
    private static final String CODE = "code";

    /** The Constant INDEX. */
    private static final String INDEX = "index";

    /** The Constant ROADLOAD. */
    private static final String ROADLOAD = "roadLoad";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#all(Pair)
     */
    @Override
    public List<Family> all(Pair<String, String> filter) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Family> criteriaQuery = cb.createQuery(aggregateRootClass);
        Root<Family> root = criteriaQuery.from(aggregateRootClass);

        Optional<String> code = Optional.ofNullable(filter.getValue0());
        Optional<String> roadLoad = Optional.ofNullable(filter.getValue1());

        List<Predicate> filters = new ArrayList<>();
        code.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(CODE)), cb.parameter(String.class, CODE))));
        roadLoad.ifPresent(c -> filters.add(cb.like(cb.lower(root.get(ROADLOAD)), cb.parameter(String.class, ROADLOAD))));

        criteriaQuery.where(filters.toArray(new Predicate[] {}));

        TypedQuery<Family> q = entityManager.createQuery(criteriaQuery);

        code.ifPresent(c -> q.setParameter(CODE, new StringBuilder().append("%").append(c).append("%").toString()));
        roadLoad.ifPresent(c -> q.setParameter(ROADLOAD, new StringBuilder().append("%").append(c).append("%").toString()));

        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#byRoadLoad(String)
     */
    @Override
    public List<Family> byRoadLoad(@VehicleRoadLoadType String roadLoadId) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Family> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<Family> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.where(criteriaBuilder.equal(root.get(ROADLOAD), criteriaBuilder.parameter(String.class, ROADLOAD)));

        TypedQuery<Family> q = entityManager.createQuery(criteriaQuery);
        q.setParameter(ROADLOAD, roadLoadId);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#byRoadLoad(java.lang.String)
     */
    @Override
    public List<Family> byCode(@FamilyCode String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Family> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<Family> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.where(criteriaBuilder.equal(root.get(CODE), criteriaBuilder.parameter(String.class, CODE)));

        TypedQuery<Family> q = entityManager.createQuery(criteriaQuery);
        q.setParameter(CODE, code);
        return q.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#byCodeAndIndex(java.lang.String, java.lang.Integer)
     */
    @Override
    public Optional<Family> byCodeAndIndex(@FamilyCode String code, @FamilyIndex Integer index) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Family> q = cb.createQuery(aggregateRootClass);
        Root<Family> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)), cb.equal(root.get(INDEX), cb.parameter(Integer.class, INDEX)));
        TypedQuery<Family> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        query.setParameter(INDEX, index);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#byCodeAndIndexDetails(java.lang.String,
     *      java.lang.Integer)
     */
    @Override
    public Optional<FamilyDetails> byCodeAndIndexDetails(@FamilyCode String code, @FamilyIndex Integer index) {
        TypedQuery<FamilyDetails> query = entityManager.createQuery("FROM FamilyDetails where CODE =:CODE and IND =:IND", FamilyDetails.class);
        query.setParameter("CODE", code);
        query.setParameter("IND", index);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#exists(java.lang.String, int)
     */
    @Override
    /* @CacheResult(cacheName = "wltpFamilyExistenceCache") */
    public boolean exists(String code, int index) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<Family> root = q.from(aggregateRootClass);
        q.select(root.get(GUID));
        q.where(cb.equal(root.get(CODE), cb.parameter(String.class, CODE)), cb.equal(root.get(INDEX), cb.parameter(Integer.class, INDEX)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(CODE, code);
        query.setParameter(INDEX, index);

        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#getVehicleCharacteristics(java.lang.String, int)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Object[]> getVehicleCharacteristics(@FamilyCode String code, @FamilyIndex int index) {
        Query query = entityManager.createNativeQuery(
                "SELECT T.code,T.value,T.TVTCODE,T.ROADLOAD FROM (SELECT pqt.code,pqv.value,tvt.code as TVTCODE,fam.ROADLOAD as ROADLOAD FROM W7TQTPQV pqv \r\n"
                        + "INNER JOIN  W7TQTPQT pqt ON pqt.id=pqv.type \r\n" + "INNER JOIN W7TQTTVH tvh ON pqv.vehicle_id=tvh.id\r\n"
                        + "INNER JOIN W7TQTFAM fam ON tvh.family_id= fam.id \r\n"
                        + "INNER JOIN W7TQTTVT tvt ON tvt.id=tvh.type and tvt.code IN(SELECT CODE FROM W7TQTTVT) where fam.code=? and fam.ind=? order by tvt.SORT)  T group by T.TVTCODE, T.CODE, T.VALUE,T.ROADLOAD");
        query.setParameter(1, code);
        query.setParameter(2, index);
        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository#getVehicleTestResults(java.lang.String, int)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<Object[]> getVehicleTestResults(@FamilyCode String code, @FamilyIndex int index) {
        Query query = entityManager.createNativeQuery(
                "SELECT cph.code as phaseCode,mtp.code as MeasureCode, mvl.value as MeasureValue,tvt.code as VehicleTypeCode FROM W7TQTMVL mvl\r\n"
                        + "INNER JOIN W7TQTMTP mtp ON mtp.id=mvl.type\r\n"
                        + "INNER JOIN W7TQTCPH cph ON mvl.phase=cph.id and cph.code IN(SELECT CODE FROM W7TQTCPH order by sort)\r\n"
                        + "INNER JOIN W7TQTTVH tvh ON mvl.vehicle_id=tvh.id\r\n" + "INNER JOIN W7TQTFAM fam ON tvh.family_id= fam.id\r\n"
                        + "INNER JOIN W7TQTTVT tvt ON tvt.id=tvh.type where fam.code=? and fam.ind=? and tvt.code in('VLOW','VMED','VHIGH') group by cph.code, mvl.value,mtp.code,tvt.code");
        query.setParameter(1, code);
        query.setParameter(2, index);
        return query.getResultList();
    }

}
