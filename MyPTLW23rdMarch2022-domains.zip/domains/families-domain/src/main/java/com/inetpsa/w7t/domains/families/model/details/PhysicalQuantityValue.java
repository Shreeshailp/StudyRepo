/*
 * Creation : 31 janv. 2017
 */
package com.inetpsa.w7t.domains.families.model.details;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.annotations.Type;

import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;

/**
 * The Class PhysicalQuantityValue. This entity represents a physical quantity value of a certain type belonging to a certain test vehicle.
 * 
 * @see TestVehicle
 */
@Embeddable
public class PhysicalQuantityValue {

    /**
     * The type.
     * 
     * @see PhysicalQuantityType
     */
    @Type(type = "uuid-char")
    @Column(name = "TYPE")
    private UUID type;

    /** The value. */
    @Column(name = "VALUE")
    private Double value;

    /**
     * Gets the type.
     *
     * @return the type
     */
    public UUID getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(UUID type) {
        this.type = type;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public Double getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(Double value) {
        this.value = value;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PhysicalQuantityValue other = (PhysicalQuantityValue) obj;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        } else if (!value.equals(other.value))
            return false;
        return true;
    }

}
