/*
 * Creation : 21 Feb 2020
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.util.Optional;
import java.util.UUID;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlag;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;

// TODO: Auto-generated Javadoc
/**
 * The Class FamilyTabCheckFlagJpaRepository.
 */
public class FamilyTabCheckFlagJpaRepository extends BaseJpaRepository<FamilyTabCheckFlag, UUID> implements FamilyTabCheckFlagRepository {

    /** The Constant T8C. */
    private static final String T8C = "t8C";

    /** The Constant T8D. */
    private static final String T8D = "t8D";

    /** The Constant TABID. */
    private static final String TABID = "tabId";

    /** The Constant GUID. */
    private static final String GUID = "guid";

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.jpa.BaseJpaRepository#exists(java.lang.Object)
     */
    @Override
    public boolean exists(UUID id) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<UUID> q = cb.createQuery(UUID.class);
        Root<FamilyTabCheckFlag> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(GUID), cb.parameter(String.class, GUID)));

        TypedQuery<UUID> query = entityManager.createQuery(q);
        query.setParameter(GUID, id);

        return query.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyTabCheckFlagRepository#byCodeAndIndexDetails(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public Optional<FamilyTabCheckFlag> byCodeAndIndexDetails(@FamilyCode String code, @FamilyIndex String index, String tabId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyTabCheckFlag> q = cb.createQuery(aggregateRootClass);
        Root<FamilyTabCheckFlag> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(T8C), cb.parameter(String.class, T8C)), cb.equal(root.get(T8D), cb.parameter(String.class, T8D)),
                cb.equal(root.get(TABID), cb.parameter(String.class, TABID)));

        TypedQuery<FamilyTabCheckFlag> query = entityManager.createQuery(q);
        query.setParameter(T8C, code);
        query.setParameter(T8D, index);
        query.setParameter(TABID, tabId);
        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyTabCheckFlagRepository#exists(java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public boolean exists(@FamilyCode String code, @FamilyIndex String index, String tabId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyTabCheckFlag> q = cb.createQuery(aggregateRootClass);
        Root<FamilyTabCheckFlag> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(T8C), cb.parameter(String.class, T8C)), cb.equal(root.get(T8D), cb.parameter(String.class, T8D)),
                cb.equal(root.get(TABID), cb.parameter(String.class, TABID)));

        TypedQuery<FamilyTabCheckFlag> query = entityManager.createQuery(q);
        query.setParameter(T8C, code);
        query.setParameter(T8D, index);
        query.setParameter(TABID, tabId);
        return query.getResultList().stream().findFirst().isPresent();
    }

}
