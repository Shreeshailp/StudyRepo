/*
 * Creation : 24 avr. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family;

import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

/**
 * The Interface FamilyDetailsRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyDetailsRepository extends GenericRepository<FamilyDetails, UUID> {

}
