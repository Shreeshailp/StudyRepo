/*
 * Creation : 21 Feb 2020
 */
package com.inetpsa.w7t.domains.families.model.details;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * The Class FamilyTabCheckFlag.
 */
@Entity
@Table(name = "W7TQTCHK")
public class FamilyTabCheckFlag extends BaseAggregateRoot<UUID> {
    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The t 8 C. */
    @Column(name = "T8C")
    private String t8C;

    /** The t 8 D. */
    @Column(name = "T8D")
    private String t8D;

    /** The tab id. */
    @Column(name = "TAB_ID")
    private String tabId;

    /** The check flag. */
    @Column(name = "CHECK_FLAG")
    private boolean checkFlag;

    /** The family details. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FAMILY_ID")
    private FamilyDetails familyDetails;

    /**
     * Gets the family details.
     *
     * @return the family details
     */
    public FamilyDetails getFamilyDetails() {
        return familyDetails;
    }

    /**
     * Sets the family details.
     *
     * @param familyDetails the new family details
     */
    public void setFamilyDetails(FamilyDetails familyDetails) {
        this.familyDetails = familyDetails;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the t8c.
     *
     * @return the t8c
     */
    public String getT8C() {
        return t8C;
    }

    /**
     * Sets the t8c.
     *
     * @param t8c the new t8c
     */
    public void setT8C(String t8c) {
        t8C = t8c;
    }

    /**
     * Gets the t8d.
     *
     * @return the t8d
     */
    public String getT8D() {
        return t8D;
    }

    /**
     * Sets the t8d.
     *
     * @param t8d the new t8d
     */
    public void setT8D(String t8d) {
        t8D = t8d;
    }

    /**
     * Gets the tab id.
     *
     * @return the tab id
     */
    public String getTabId() {
        return tabId;
    }

    /**
     * Sets the tab id.
     *
     * @param tabId the new tab id
     */
    public void setTabId(String tabId) {
        this.tabId = tabId;
    }

    /**
     * Gets the check flag.
     *
     * @return the check flag
     */
    public boolean getCheckFlag() {
        return checkFlag;
    }

    /**
     * Sets the check flag.
     *
     * @param checkFlag the new check flag
     */
    public void setCheckFlag(boolean checkFlag) {
        this.checkFlag = checkFlag;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + (checkFlag ? 1231 : 1237);
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((t8C == null) ? 0 : t8C.hashCode());
        result = prime * result + ((t8D == null) ? 0 : t8D.hashCode());
        result = prime * result + ((tabId == null) ? 0 : tabId.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        FamilyTabCheckFlag other = (FamilyTabCheckFlag) obj;
        if (checkFlag != other.checkFlag)
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (t8C == null) {
            if (other.t8C != null)
                return false;
        } else if (!t8C.equals(other.t8C))
            return false;
        if (t8D == null) {
            if (other.t8D != null)
                return false;
        } else if (!t8D.equals(other.t8D))
            return false;
        if (tabId == null) {
            if (other.tabId != null)
                return false;
        } else if (!tabId.equals(other.tabId))
            return false;
        return true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#toString()
     */
    @Override
    public String toString() {
        return "FamilyTabCheckFlag [guid=" + guid + ", t8C=" + t8C + ", t8D=" + t8D + ", tabId=" + tabId + ", checkFlag=" + checkFlag + "]";
    }

    /**
     * Instantiates a new family tab check flag.
     */
    public FamilyTabCheckFlag() {
        super();
    }

}
