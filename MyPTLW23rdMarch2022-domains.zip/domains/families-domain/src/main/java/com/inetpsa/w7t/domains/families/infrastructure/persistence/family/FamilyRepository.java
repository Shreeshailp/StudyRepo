/*
 * Creation : 6 janv. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.javatuples.Pair;
import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;

/**
 * The Interface FamilyRepository. This repository is used to get and save entities from and to the database.
 */
@Transactional
public interface FamilyRepository extends GenericRepository<Family, UUID> {

    /**
     * Read all families from the database.
     *
     * @param filter the filter
     * @return the list of families read.
     */
    @Read
    List<Family> all(Pair<String, String> filter);

    /**
     * Read all families having a specific category.
     *
     * @param RoadLoadId the RoadLoad Id
     * @return the family read.
     */
    @Read
    List<Family> byRoadLoad(@VehicleRoadLoadType String RoadLoadId);

    /**
     * Read all families having a specific code.
     *
     * @param code the family code
     * @return a list of families having this code or an empty list if there is none.
     */

    /**
     * Read all families having a specific code.
     *
     * @param code the family code
     * @return a list of families having this code or an empty list if there is none.
     */

    @Read
    List<Family> byCode(@FamilyCode String code);

    /**
     * Read the family aggregate identified by the specified code and index.
     *
     * @param code the family code
     * @param index the family index
     * @return an optional containing the family
     */
    @Read
    Optional<Family> byCodeAndIndex(@FamilyCode String code, @FamilyIndex Integer index);

    /**
     * Check that the family identified by the specified key exists.
     *
     * @param code the family code
     * @param index the family index
     * @return true if the family exists, false otherwise.
     */
    @Read
    Optional<FamilyDetails> byCodeAndIndexDetails(@FamilyCode String code, @FamilyIndex Integer index);

    /**
     * Check that the family exists.
     *
     * @param code the family code
     * @param index the family index
     * @return true if the family exists, false otherwise.
     */
    @Read
    boolean exists(@FamilyCode String code, @FamilyIndex int index);

    /**
     * Gets the vehicle characteristics.
     *
     * @param code  the code
     * @param index the index
     * @return the vehicle characteristics
     */
    List<Object[]> getVehicleCharacteristics(@FamilyCode String code, @FamilyIndex int index);

    /**
     * Gets the vehicle test results.
     *
     * @param code  the code
     * @param index the index
     * @return the vehicle test results
     */
    List<Object[]> getVehicleTestResults(@FamilyCode String code, @FamilyIndex int index);
}
