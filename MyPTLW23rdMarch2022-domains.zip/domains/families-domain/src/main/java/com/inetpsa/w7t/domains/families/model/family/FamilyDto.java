/*
 * Creation : 9 mars 2017
 */
package com.inetpsa.w7t.domains.families.model.family;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;

import org.apache.commons.collections.MultiMap;

import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;

/**
 * The Class FamilyDto.
 */
public class FamilyDto {
    /** The family code. */
    @FamilyCode
    @Column(name = "CODE")
    private String code;

    /** The index. */
    @FamilyIndex
    @Column(name = "INDEX")
    private Integer index;

    /** The quantities. */
    private MultiMap quantities;

    /** The cycles. */
    private Set<String> cycles;

    /** The test vehicles. */
    private List<Map<String, Object>> testVehicles;

    /** The road load. */
    private String roadLoad;

    /** The pmax. */
    private Float pmax;

    /** The label. */
    private String label;

    /** The vehicle type. */
    private String vehicleType;

    /** The status. */
    private String status;

    /** The blocking reason. */
    private String blockingReason;

    /** The blocked. */
    private Boolean blocked;

    /** The created by. */
    private String createdBy;

    /** The created on. */
    private String createdOn;

    /** The line number. */
    private Integer lineNumber;

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the created on.
     *
     * @return the created on
     */
    public String getCreatedOn() {
        return createdOn;
    }

    /**
     * Sets the created on.
     *
     * @param createdOn the new created on
     */
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the blocking reason.
     *
     * @return the blocking reason
     */
    public String getBlockingReason() {
        return blockingReason;
    }

    /**
     * Sets the blocking reason.
     *
     * @param blockingReason the new blocking reason
     */
    public void setBlockingReason(String blockingReason) {
        this.blockingReason = blockingReason;
    }

    /**
     * Gets the blocked.
     *
     * @return the blocked
     */
    public Boolean getBlocked() {
        return blocked;
    }

    /**
     * Sets the blocked.
     *
     * @param blocked the new blocked
     */
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the index.
     *
     * @return the index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Sets the index.
     *
     * @param index the new index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * Gets the quantities.
     *
     * @return the quantities
     */
    public MultiMap getQuantities() {
        return quantities;
    }

    /**
     * Sets the quantities.
     *
     * @param quantities the new quantities
     */
    public void setQuantities(MultiMap quantities) {
        this.quantities = quantities;
    }

    /**
     * Gets the cycles.
     *
     * @return the cycles
     */
    public Set<String> getCycles() {
        return cycles;
    }

    /**
     * Sets the cycles.
     *
     * @param cycles the new cycles
     */
    public void setCycles(Set<String> cycles) {
        this.cycles = cycles;
    }

    /**
     * Gets the test vehicles.
     *
     * @return the test vehicles
     */
    public List<Map<String, Object>> getTestVehicles() {
        return testVehicles;
    }

    /**
     * Sets the test vehicles.
     *
     * @param list the list
     */
    public void setTestVehicles(List<Map<String, Object>> list) {
        this.testVehicles = list;
    }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    public String getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the road load.
     *
     * @param roadLoad the new road load
     */
    public void setRoadLoad(String roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Gets the pmax.
     *
     * @return the pmax
     */
    public Float getPmax() {
        return pmax;
    }

    /**
     * Sets the pmax.
     *
     * @param pmax the new pmax
     */
    public void setPmax(Float pmax) {
        this.pmax = pmax;
    }

    /**
     * Gets the label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Sets the label.
     *
     * @param label the new label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the vehicle type.
     *
     * @return the vehicle type
     */
    public String getVehicleType() {
        return vehicleType;
    }

    /**
     * Sets the vehicle type.
     *
     * @param vehicleType the new vehicle type
     */
    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    /**
     * Gets the line number.
     *
     * @return the line number
     */
    public Integer getLineNumber() {
        return lineNumber;
    }

    /**
     * Sets the line number.
     *
     * @param lineNumber the new line number
     */
    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }

}
