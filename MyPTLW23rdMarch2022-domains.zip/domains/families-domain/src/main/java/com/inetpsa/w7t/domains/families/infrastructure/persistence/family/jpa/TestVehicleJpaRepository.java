/*
 * Creation : 20 avr. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.util.List;
import java.util.UUID;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;

import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.TestVehicleRepository;
import com.inetpsa.w7t.domains.families.model.details.TestVehicle;

@JpaUnit("wltp-domain-jpa-unit")
public class TestVehicleJpaRepository extends BaseJpaRepository<TestVehicle, UUID> implements TestVehicleRepository {
    @Override
    @SuppressWarnings("unchecked")
    public List<TestVehicle> byFamilyId(String familyId) {

        String query = "select w.* from W7TQTTVH w where w.family_id = ?1";

        List<TestVehicle> tv = entityManager.createNativeQuery(query, TestVehicle.class).setParameter(1, familyId).getResultList();

        return tv;

    }

}
