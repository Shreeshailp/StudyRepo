/*
 * Creation : 20 avr. 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family;

import java.util.List;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.details.TestVehicle;

/**
 * The Interface TestVehicleRepository.
 */
@Transactional
public interface TestVehicleRepository extends GenericRepository<TestVehicle, UUID> {

    /**
     * By family id.
     *
     * @param familyId the family id
     * @return the list
     */
    public List<TestVehicle> byFamilyId(String familyId);

}
