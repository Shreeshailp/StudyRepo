/*
 * Creation : 25 Feb 2020
 */
/**
 * 
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.families.model.family.FamilyAdditionalData;

/**
 * The Class FamilyAdditionalDataJpaRepository.
 *
 * @author E569186
 */
@JpaUnit("wltp-domain-jpa-unit")
public class FamilyAdditionalDataJpaRepository extends BaseJpaRepository<FamilyAdditionalData, UUID> implements FamilyAdditionalDataRepository {

    /** The Constant T8C. */
    private static final String T8C = "t8c";

    /** The Constant T8D. */
    private static final String T8D = "t8d";

    Logger logger = LoggerFactory.getLogger(FamilyAdditionalDataJpaRepository.class);

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyAdditionalDataRepository#byCodeAndIndexDetails(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public Optional<FamilyAdditionalData> byCodeAndIndexDetails(String code, String index) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyAdditionalData> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<FamilyAdditionalData> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.where(criteriaBuilder.equal(root.get(T8C), criteriaBuilder.parameter(String.class, T8C)),
                criteriaBuilder.equal(root.get(T8D), criteriaBuilder.parameter(String.class, T8D)));

        TypedQuery<FamilyAdditionalData> q = entityManager.createQuery(criteriaQuery);
        q.setParameter(T8C, code);
        q.setParameter(T8D, index);
        return q.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyAdditionalDataRepository#exists(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public boolean exists(String code, String index) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyAdditionalData> criteriaQuery = criteriaBuilder.createQuery(aggregateRootClass);
        Root<FamilyAdditionalData> root = criteriaQuery.from(aggregateRootClass);
        criteriaQuery.where(criteriaBuilder.equal(root.get(T8C), criteriaBuilder.parameter(String.class, T8C)),
                criteriaBuilder.equal(root.get(T8D), criteriaBuilder.parameter(String.class, T8D)));

        TypedQuery<FamilyAdditionalData> q = entityManager.createQuery(criteriaQuery);
        q.setParameter(T8C, code);
        q.setParameter(T8D, index);
        return q.getResultList().stream().findFirst().isPresent();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa.FamilyAdditionalDataRepository#getFamilyAdditionalData(java.lang.String,
     *      java.lang.String)
     */
    @Override
    public FamilyAdditionalData getFamilyAdditionalData(String t8c, String t8d) throws SQLException {
        FamilyAdditionalData additionalData = null;
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FamilyAdditionalData> criteria = builder.createQuery(FamilyAdditionalData.class);
        Root<FamilyAdditionalData> root = criteria.from(FamilyAdditionalData.class);
        criteria.select(root).where(builder.equal(root.get(T8C), builder.parameter(String.class, T8C)),
                builder.equal(root.get(T8D), builder.parameter(String.class, T8D)));
        TypedQuery<FamilyAdditionalData> q = entityManager.createQuery(criteria);
        q.setParameter(T8C, t8c);
        q.setParameter(T8D, t8d);
        try {
            Optional<FamilyAdditionalData> optAdditionalData = q.getResultList().stream().findFirst();
            if (optAdditionalData.isPresent()) {
                additionalData = optAdditionalData.get();
            }

        } catch (Exception e) {
            logger.info("Exception executing query :{} ", e);
            return additionalData;
        }

        return additionalData;

    }

    @Override
    public int updateByT8cT8DAndFamilyId(String t8c, String t8d, FamilyAdditionalData familyAdditionalData) {
        Query query = entityManager
                .createNativeQuery("UPDATE W7TQTFAD fad SET fad.VEHICLE_FAMILIES = ?, fad.MOTOR_B0F = ?, fad.MOTOR_DKC = ? , fad.DLD_DATE = ?"
                        + " , fad.DLL_DATE = ?, fad.FIRST_REG_DATE = ?, fad.RCE_DATE = ?, fad.WINDOW = ?, fad.URL_DOSSIER = ?, fad.URL_PV = ?"
                        + " , fad.URL_IMPORT_FILE = ?, fad.GEARBOX_B0G = ? where fad.T8C = ? AND fad.T8D = ? AND fad.FAM_ID = ?");
        query.setParameter(1, familyAdditionalData.getVehicleFamilies());
        query.setParameter(2, familyAdditionalData.getMotorB0F());
        query.setParameter(3, familyAdditionalData.getMotorDkc());
        query.setParameter(4, familyAdditionalData.getDldDate());
        query.setParameter(5, familyAdditionalData.getDllDate());
        query.setParameter(6, familyAdditionalData.getFirstRegDate());
        query.setParameter(7, familyAdditionalData.getRceDate());
        query.setParameter(8, familyAdditionalData.getWindow());
        query.setParameter(9, familyAdditionalData.getUrlDossier());
        query.setParameter(10, familyAdditionalData.getUrlPv());
        query.setParameter(11, familyAdditionalData.getUrlImportFile());
        query.setParameter(12, familyAdditionalData.getGearBox());
        query.setParameter(13, familyAdditionalData.getT8c());
        query.setParameter(14, familyAdditionalData.getT8d());
        query.setParameter(15, familyAdditionalData.getFamily().getGuid());

        return query.executeUpdate();
    }
}
