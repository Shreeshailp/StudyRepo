/*
 * Creation : 31 janv. 2017
 */
package com.inetpsa.w7t.domains.families.model.details;

import java.util.List;
import java.util.UUID;

import javax.persistence.Cacheable;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;
import com.inetpsa.w7t.domains.references.validation.VehicleRoadLoadType;
import com.inetpsa.w7t.domains.references.validation.VehicleTypeCode;

/**
 * The Aggregate FamilyDetails. Used to display the details of a WLTP {@link Family} when seeking a singular family in the REST API.
 */
@Entity
@Table(name = "W7TQTFAM")
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class FamilyDetails extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    /** The code. */
    @FamilyCode
    @Column(name = "CODE")
    private String code;

    /** The index. */
    @FamilyIndex
    @Column(name = "IND")
    private Integer index;

    /** The label. */
    @Size(max = 30)
    @Column(name = "LABEL")
    private String label;

    /** The vehicle type. */
    @VehicleTypeCode
    @Column(name = "TYPE")
    private String type;

    /** The vehicle roadload. */
    @VehicleRoadLoadType
    @Column(name = "ROADLOAD")
    private String roadLoad;

    /** The vehicle pmax. */
    @Column(name = "PMAX")
    private Float pmax;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /** The blocked. */
    @Column(name = "BLOCKED")
    private Boolean blocked;

    /** The blocking reason. */
    @Column(name = "BLOCKING_REASON")
    private String blockingReason;

    /** The created by. */
    @Column(name = "CREATED_BY")
    private String createdBy;

    /** The created on. */
    @Column(name = "CREATED_ON")
    private String createdOn;

    /** The cycles. */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "W7TQTCYF", joinColumns = @JoinColumn(name = "FAMILY_ID", referencedColumnName = "ID"))
    @Column(name = "CYCLE_ID")
    @Type(type = "uuid-char")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<UUID> cycles;

    /** The test vehicles. */

    @OneToMany(mappedBy = "familyDetails", fetch = FetchType.LAZY)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<TestVehicle> vehicles;

    /** The family tabs. */
    @OneToMany(mappedBy = "familyDetails", fetch = FetchType.LAZY)
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    private List<FamilyTabCheckFlag> familyTabs;

    /** The line number. */
    private transient Integer lineNumber;

    /**
     * Getter familyTabs
     * 
     * @return the familyTabs
     */
    public List<FamilyTabCheckFlag> getFamilyTabs() {
        return familyTabs;
    }

    /**
     * Setter familyTabs
     * 
     * @param familyTabs the familyTabs to set
     */
    public void setFamilyTabs(List<FamilyTabCheckFlag> familyTabs) {
        this.familyTabs = familyTabs;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public UUID getEntityId() {
        return this.guid;
    }

    /**
     * Gets the guid.
     *
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Sets the guid.
     *
     * @param guid the new guid
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the index.
     *
     * @return the index
     */
    public Integer getIndex() {
        return index;
    }

    /**
     * Sets the index.
     *
     * @param index the new index
     */
    public void setIndex(Integer index) {
        this.index = index;
    }

    /**
     * Getter label
     * 
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Setter label
     * 
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the cycles.
     *
     * @return the cycles
     */
    public List<UUID> getCycles() {
        return cycles;
    }

    /**
     * Sets the cycles.
     *
     * @param cycles the new cycles
     */
    public void setCycles(List<UUID> cycles) {
        this.cycles = cycles;
    }

    /**
     * Gets the vehicles.
     *
     * @return the vehicles
     */
    public List<TestVehicle> getVehicles() {
        return vehicles;
    }

    public void setVehicles(List<TestVehicle> vehicles) {
        this.vehicles = vehicles;
    }

    public Integer getLineNumber() {
        return lineNumber;
    }

    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * Gets the roadLoad.
     *
     * @return the roadLoad
     */
    public String getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the roadLoad.
     *
     * @param roadLoad the new cycles
     */
    public void setRoadLoad(String roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Gets the pmax.
     *
     * @return the pmax
     */
    public Float getPmax() {
        return pmax;
    }

    /**
     * Sets the pmax.
     *
     * @param pmax the new cycles
     */
    public void setPmax(Float pmax) {
        this.pmax = pmax;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the blocked.
     *
     * @return the blocked
     */
    public Boolean getBlocked() {
        return blocked;
    }

    /**
     * Sets the blocked.
     *
     * @param blocked the new blocked
     */
    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    /**
     * Gets the blocking reason.
     *
     * @return the blocking reason
     */
    public String getBlockingReason() {
        return blockingReason;
    }

    /**
     * Sets the blocking reason.
     *
     * @param blockingReason the new blocking reason
     */
    public void setBlockingReason(String blockingReason) {
        this.blockingReason = blockingReason;
    }

    /**
     * Gets the created by.
     *
     * @return the created by
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the created by.
     *
     * @param createdBy the new created by
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the created on.
     *
     * @return the created on
     */
    public String getCreatedOn() {
        return createdOn;
    }

    /**
     * Sets the created on.
     *
     * @param createdOn the new created on
     */
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((roadLoad == null) ? 0 : roadLoad.hashCode());
        result = prime * result + ((pmax == null) ? 0 : pmax.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((cycles == null) ? 0 : cycles.hashCode());
        result = prime * result + ((guid == null) ? 0 : guid.hashCode());
        result = prime * result + ((index == null) ? 0 : index.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        result = prime * result + ((vehicles == null) ? 0 : vehicles.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        FamilyDetails other = (FamilyDetails) obj;
        if (roadLoad == null) {
            if (other.roadLoad != null)
                return false;
        } else if (!roadLoad.equals(other.roadLoad))
            return false;

        if (pmax == null) {
            if (other.pmax != null)
                return false;
        } else if (!pmax.equals(other.pmax))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (cycles == null) {
            if (other.cycles != null)
                return false;
        } else if (!cycles.equals(other.cycles))
            return false;
        if (guid == null) {
            if (other.guid != null)
                return false;
        } else if (!guid.equals(other.guid))
            return false;
        if (index == null) {
            if (other.index != null)
                return false;
        } else if (!index.equals(other.index))
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        if (vehicles == null) {
            if (other.vehicles != null)
                return false;
        } else if (!vehicles.equals(other.vehicles))
            return false;
        return true;
    }

}
