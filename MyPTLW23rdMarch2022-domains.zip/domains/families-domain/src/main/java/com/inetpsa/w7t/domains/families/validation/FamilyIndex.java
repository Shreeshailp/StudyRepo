/*
 * Creation : 8 févr. 2017
 */
package com.inetpsa.w7t.domains.families.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;

/**
 * The Interface FamilyIndex. Used to validate {@link Family#getIndex()} and {@link FamilyDetails#getIndex()}.
 */
@NotNull
@Digits(integer = 2, fraction = 0)
@Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.TYPE_USE })
@Constraint(validatedBy = {})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface FamilyIndex {

    /**
     * Message.
     *
     * @return the message
     */
    String message() default "{com.inetpsa.w7t.validation.constraints.FamilyIndex.message}";

    /**
     * Groups.
     *
     * @return the groups
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the payload
     */
    Class<? extends Payload>[] payload() default {};
}
