/*
 * Creation : 5 janv. 2017
 */
package com.inetpsa.w7t.domains.families.shared.internal;

import com.inetpsa.w7t.domains.families.shared.FamilyPolicy;

/**
 * The Class FamilyPolicyImpl.
 */
public class FamilyPolicyImpl implements FamilyPolicy {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.domains.families.shared.FamilyPolicy#validate()
     */
    @Override
    public void validate() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException();
    }

}
