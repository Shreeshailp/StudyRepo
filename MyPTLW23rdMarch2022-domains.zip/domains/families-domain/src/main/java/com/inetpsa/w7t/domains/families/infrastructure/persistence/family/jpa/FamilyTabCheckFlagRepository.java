/*
 * Creation : 21 Feb 2020
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family.jpa;

import java.util.Optional;
import java.util.UUID;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domains.families.model.details.FamilyTabCheckFlag;
import com.inetpsa.w7t.domains.families.validation.FamilyCode;
import com.inetpsa.w7t.domains.families.validation.FamilyIndex;

// TODO: Auto-generated Javadoc
/**
 * The Interface FamilyTabCheckFlagRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public interface FamilyTabCheckFlagRepository extends GenericRepository<FamilyTabCheckFlag, UUID> {

    /**
     * Check that the family identified by the specified key exists.
     *
     * @param code the family code
     * @param index the family index
     * @param tabId the tab id
     * @return true if the family exists, false otherwise.
     */
    @Read
    Optional<FamilyTabCheckFlag> byCodeAndIndexDetails(@FamilyCode String code, @FamilyIndex String index, String tabId);

    /**
     * Exists.
     *
     * @param code the code
     * @param index the index
     * @param tabId the tab id
     * @return true, if successful
     */
    @Read
    boolean exists(@FamilyCode String code, @FamilyIndex String index, String tabId);
}
