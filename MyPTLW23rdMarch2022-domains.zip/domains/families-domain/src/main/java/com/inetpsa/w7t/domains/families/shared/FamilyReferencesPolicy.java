/*
 * Creation : 11 janv. 2017
 */
package com.inetpsa.w7t.domains.families.shared;

import org.seedstack.business.domain.DomainPolicy;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

/**
 * The Interface FamilyReferencesPolicy. Used to validate a WLTP family.
 */
@DomainPolicy
@FunctionalInterface
public interface FamilyReferencesPolicy {

    /**
     * Checks if the family is valid against all the functional rules.
     *
     * @param fam the fam
     * @return true, if the family is valid
     */
    boolean isValid(FamilyDetails fam);
}
