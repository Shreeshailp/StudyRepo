/*
 * Creation : 31 mai 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.families.model.details.TestVehicle;

@RunWith(SeedITRunner.class)
public class ITTestVehicleRepository {

    @Inject
    private TestVehicleRepository testVehicleRepository;

    @Test
    public void testVehicleWithExistingCode() {
        List<TestVehicle> families = testVehicleRepository.byFamilyId("ea7bc041-609a-445d-b97f-cab8cf48bf1e");

        assertThat(families).isNotEmpty();

    }

    @Test
    public void testVehicleWithNonExistingCode() {
        List<TestVehicle> families = testVehicleRepository.byFamilyId("ea7bc041-609a-445d-b97f-cab8cf48eeee");

        assertThat(families).isEmpty();
    }
}
