/*
 * Creation : 31 mai 2017
 */
package com.inetpsa.w7t.domains.families.infrastructure.persistence.family;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.javatuples.Pair;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;
import com.inetpsa.w7t.domains.families.model.family.Family;

@RunWith(SeedITRunner.class)
public class ITFamilyRepository {

    @Inject
    private FamilyRepository familyRepository;

    @Test
    public void allCycles() {
        Pair<String, String> filter = new Pair<>(null, null);

        List<Family> families = familyRepository.all(filter);

        assertThat(families).isNotEmpty();

    }

    @Test
    public void familyWithExistingRoadLoad() {
        List<Family> families = familyRepository.byRoadLoad("IRL");

        assertThat(families).isNotEmpty();

    }

    @Test
    public void familyWithNonExistingRoadLoad() {
        List<Family> families = familyRepository.byRoadLoad("IRL");

        assertThat(families).isEmpty();
    }

    @Test
    public void familyWithExistingCode() {
        List<Family> families = familyRepository.byCode("LD");

        assertThat(families).isNotEmpty();

    }

    @Test
    public void familyWithNonExistingCode() {
        List<Family> families = familyRepository.byCode("DL");

        assertThat(families).isEmpty();
    }

    @Test
    public void familyWithExistingCodeAndIndex() {
        Optional<Family> family = familyRepository.byCodeAndIndex("LD", 10);

        assertThat(family.isPresent()).isTrue();

    }

    @Test
    public void familyWithNonExistingCodeAndIndex() {
        Optional<Family> family = familyRepository.byCodeAndIndex("DL", 66);

        assertThat(family.isPresent()).isFalse();
    }

    @Test
    public void familyWithExists() {
        boolean familyExists = familyRepository.exists("01", 1);

        assertThat(familyExists).isTrue();

    }

    @Test
    public void familyWithNotExists() {
        boolean familyExists = familyRepository.exists("DL", 1);

        assertThat(familyExists).isFalse();
    }

    @Test
    public void familyWithExistingCodeAndIndexDetails() {
        Optional<FamilyDetails> familyDetail = familyRepository.byCodeAndIndexDetails("LD", 10);

        assertThat(familyDetail.isPresent()).isTrue();

    }

    @Test
    public void familyWithNonExistingCodeAndIndexDetails() {
        Optional<FamilyDetails> familyDetail = familyRepository.byCodeAndIndexDetails("DL", 66);

        assertThat(familyDetail.isPresent()).isFalse();
    }
}
