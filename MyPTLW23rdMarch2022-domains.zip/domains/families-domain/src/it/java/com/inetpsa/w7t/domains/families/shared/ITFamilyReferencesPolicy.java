/*
 * Creation : 31 mai 2017
 */
package com.inetpsa.w7t.domains.families.shared;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.util.UUID;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.domains.families.model.details.FamilyDetails;

@RunWith(SeedITRunner.class)
public class ITFamilyReferencesPolicy {

    @Inject
    private FamilyReferencesPolicy familyReferencesPolicy;

    @Test
    public void testForInvalidVehicleType() {
        FamilyDetails fam = new FamilyDetails();

        fam.setRoadLoad("IRL");
        fam.setPmax(0f);
        fam.setType("CONT");

        Throwable testOfFamily = catchThrowable(() -> familyReferencesPolicy.isValid(fam));
        assertThat(testOfFamily).as("Vehicle type not exists").isInstanceOf(FamilyValidationException.class).extracting("errorCode")
                .containsExactly(FamilyErrorCode.VEHICLE_TYPE_NOT_EXISTS);
    }

    @Test
    public void testForInvalidVehicleRoadLoad() {
        FamilyDetails fam = new FamilyDetails();

        fam.setRoadLoad("IRL");
        fam.setPmax(0f);
        fam.setType("CONV");

        Throwable testOfFamily = catchThrowable(() -> familyReferencesPolicy.isValid(fam));
        assertThat(testOfFamily).as("Category unknown").isInstanceOf(FamilyValidationException.class).extracting("errorCode")
                .containsExactly(FamilyErrorCode.VEHICLE_ROADLOAD_NOT_EXISTS);
    }

    @Test
    public void testThatIsValidMethodRunsSuccessfully() {
        FamilyDetails fam = new FamilyDetails();
        fam.setCode("03");
        fam.setIndex(5);
        fam.setRoadLoad("RoadLoad");
        fam.setType("CONV");
        fam.setGuid(UUID.fromString("8a0e8307-0995-45f4-8a5e-8fc03c7a2d9c"));

        boolean testOfFam = familyReferencesPolicy.isValid(fam);
        assertThat(testOfFam).isEqualTo(true);
    }
}
