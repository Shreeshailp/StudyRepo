export class Order {
    orderId:number;
    deletedOrderItemIds:string;
    orderNo:string;
    customerId:number;
    pMethod:string;
    gTotal:number;
    
}
