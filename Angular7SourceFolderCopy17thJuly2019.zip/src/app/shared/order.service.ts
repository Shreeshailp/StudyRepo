import { Injectable } from '@angular/core';
import { Order } from './order.model';
import { OrderItem } from './order-item.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class OrderService {
  
  formData:Order;
  orderItems:OrderItem[];
  constructor(private http:HttpClient) { }
  saveOrUpdateOrders(){
    var body={
      ...this.formData,
      orderItems : this.orderItems
    };
    return this.http.post(environment.apiUrl +'/order',body);
  }

  getOrdersList(){
    return this.http.get(environment.apiUrl + '/orders').toPromise();
  }
  getOrderById(id:number){
    return this.http.get(environment.apiUrl + '/order/'+id).toPromise();
  }

  deleteOrder(id: number) {
    return this.http.delete(environment.apiUrl + '/order/'+id).toPromise();
  }


}
