import {OrderService} from './../../shared/order.service'
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { from } from 'rxjs';
import { MatDialog,MatDialogConfig } from '@angular/material/dialog';
import { OrderItemsComponent } from '../order-items/order-items.component';
import { CustomerService } from 'src/app/shared/customer.service';
import { Customer } from 'src/app/shared/customer.model';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Order } from 'src/app/shared/order.model';
import { OrderItem } from 'src/app/shared/order-item.model';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styles: []
})
export class OrderComponent implements OnInit {
customerList:Customer[];
isValid:boolean = true;
orderItemsDeletedIds:string;
  constructor(private service: OrderService,
              private dialog:MatDialog,
              private customerService:CustomerService,
              private router:Router,
              private toaster:ToastrService,
              private currentRoute:ActivatedRoute) { }

  ngOnInit() {
    let orderId = this.currentRoute.snapshot.paramMap.get('id');
   if(orderId==null){
    this.resetForm();
   }else{
     this.service.getOrderById(parseInt(orderId)).then(res =>{
      this.service.formData=res as Order;
      let orderItemsArray = res["orderItems"];
      this.service.orderItems=orderItemsArray as OrderItem[];
      });
   }
   
   this.customerService.getCustomersList().then(res => { 
    this.customerList = res as Customer[];
  });
  }
resetForm(form?:NgForm){
if(form=null)
  form.resetForm();
  this.service.formData={
    orderId:null,
    orderNo:Math.floor(10000*Math.random() *90000).toString(),
    customerId:0,
    pMethod:'',
    gTotal:0,
    deletedOrderItemIds:''
  };
  this.service.orderItems=[];
}
AddOrEditItem(orderItemIndex,orderId){
  const dialogConfig= new MatDialogConfig();
  dialogConfig.autoFocus=true;
  dialogConfig.disableClose=true;
  dialogConfig.width= "50%";
  dialogConfig.data={orderItemIndex,orderId};
  this.dialog.open(OrderItemsComponent,dialogConfig).afterClosed().subscribe(res=>{
    this.updateGrandTotal();
  });
}
onDeleteOrderItem(orderItemId:number, i:number){
  if(orderItemId !=null){
    if (this.service.formData.deletedOrderItemIds === undefined)
    {
      this.service.formData.deletedOrderItemIds="";
    }
    this.service.formData.deletedOrderItemIds +=orderItemId +",";
  }
this.service.orderItems.splice(i,1);
this.updateGrandTotal();
}

updateGrandTotal(){
  this.service.formData.gTotal= this.service.orderItems.reduce((prev,curr)=>{
    return prev + curr.total;
  },0);
  this.service.formData.gTotal= parseFloat(this.service.formData.gTotal.toFixed(2));
}
validateForm(){
  this.isValid=true;
  if(this.service.formData.customerId == 0)
  this.isValid=false;
  else if(this.service.orderItems.length == 0)
  this.isValid=false;
  return this.isValid;
}
onSubmit(form:NgForm){
 if(this.validateForm()){
   this.service.saveOrUpdateOrders().subscribe(res =>{
     this.resetForm();
     let orderId = this.currentRoute.snapshot.paramMap.get('id');
     if(orderId==null){
       this.toaster.success("Order saved successfully","MyCart App.");
   }else{
     this.toaster.success("Order updated successfully","MyCart App.");
    }
     this.router.navigate(['/orders']);
   });
 }
  }
  

}
