/*
 * Creation : 17 Jan 2020
 */
package com.inetpsa.w7t.provider.batch;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;

/**
 * The Class CorvetAnswerRowMapper.
 */
public class CorvetAnswerRowMapper implements RowMapper<Request> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public Request mapRow(ResultSet rs, int rowNum) throws SQLException {
        Request request = new Request();
        request.setRequestId(rs.getString("REQUEST_ID"));
        request.setInternalFileId(rs.getString("INTERNAL_FILE_ID"));
        request.setRequestBatchId(UUID.fromString(rs.getString("BATCH_ID")));
        request.setRequestType(RequestType.valueOf(rs.getString("REQUEST_TYPE")));
        request.setVin(rs.getString("VIN"));
        request.setExtendedTitle(rs.getString("EXTENDED_TITLE"));
        request.setFileId(rs.getString("FILE_ID"));
        request.setAnswerCode(rs.getString("ANSWER_CODE"));
        request.setAnswerDesignation(rs.getString("ANSWER_DESIGNATION"));
        request.setStatus(RequestStatus.of(rs.getInt("STATUS")));
        request.setTvv(rs.getString("TVV_DESIGNATION"));
        Date ecomDate = rs.getDate("ECOM_Date");
        if (ecomDate != null) {
            request.setEcomDate(convertToLocateDate(ecomDate));
        }
        Timestamp reqDateTime = rs.getTimestamp("REQUEST_DATE");

        if (reqDateTime != null) {
            request.setRequestDate(convertToLocalDateTime(reqDateTime));
        }

        return request;
    }

    /**
     * Convert to local date time.
     *
     * @param timeStamp the time stamp
     * @return the local date time
     */
    private LocalDateTime convertToLocalDateTime(Timestamp timeStamp) {
        return timeStamp.toLocalDateTime();
    }

    /**
     * Convert to locate date.
     *
     * @param date the date
     * @return the local date
     */
    public static LocalDate convertToLocateDate(Date date) {
        return date.toLocalDate();
    }

}
