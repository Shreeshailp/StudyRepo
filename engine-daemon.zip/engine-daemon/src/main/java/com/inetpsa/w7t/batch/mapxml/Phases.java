/*
 * Creation : 26 avr. 2017
 */
package com.inetpsa.w7t.batch.mapxml;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

/**
 * The Class Phases.
 */
public class Phases {

    /** The code. */
    private String code;

    /** The phase result list. */
    private List<PhaseResult> phaseResultList;

    /**
     * Gets the code.
     *
     * @return the code
     */
    @XmlAttribute
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the phase result list.
     *
     * @return the phase result list
     */
    @XmlElement(name = "result")
    public List<PhaseResult> getPhaseResultList() {
        return phaseResultList;
    }

    /**
     * Sets the phase result list.
     *
     * @param phaseResultList the new phase result list
     */
    public void setPhaseResultList(List<PhaseResult> phaseResultList) {
        this.phaseResultList = phaseResultList;
    }

}
