package com.inetpsa.w7t.mq.listener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.seedstack.jms.DestinationType;
import org.seedstack.jms.JmsMessageListener;
import org.seedstack.jms.pollers.SimpleMessagePoller;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The listener interface for receiving MQMessage events. The class that is interested in processing a MQMessage event implements this interface, and
 * the object created with that class is registered with a component using the component's <code>addMQMessageListener<code> method. When the MQMessage
 * event occurs, that object's appropriate method is invoked.
 *
 * @see MQMessageEvent
 */
@JmsMessageListener(connection = "wltpJmsConnection", destinationType = DestinationType.QUEUE, destinationName = "R3P.TO.W7T.01", poller = SimpleMessagePoller.class)
public class MQMessageListener implements javax.jms.MessageListener {

    /** The Constant BUFFER_SIZE. */
    private static final int BUFFER_SIZE = 1024 * 512;

    /** The Constant FILE_CONFIG_ENTRY. */
    private static final String FILE_CONFIG_ENTRY = "fileConfig";

    /** The g logger. */
    Logger gLogger = LoggerFactory.getLogger("com.inetpsa.genome");

    /** The genome in dir. */
    @Configuration("daemon.providers.genome.inputDirectory")
    private String genomeInDir;

    /** The genome backup dir. */
    @Configuration("daemon.providers.genome.backupDirectory")
    private String genomeBackupDir;

    /**
     * {@inheritDoc}
     * 
     * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
     */
    @Override
    @Transactional
    public void onMessage(Message message) {
        try {

            if (message instanceof TextMessage) {
                /** ITJmsPollingTextMessage.text = ((TextMessage) message).getText(); **/
                gLogger.info("Genome Text Message '{}' received", ((TextMessage) message).getText());
            }

            if (message instanceof BytesMessage) {
                BytesMessage bytMsg = (BytesMessage) message;
                gLogger.info("Genome Byte Message '{}' received", bytMsg);
                processByteMessage(bytMsg);
                /** ITJmsPollingByteMessage.jmsMessageID = bytMsg.getJMSMessageID(); **/
            }

        } catch (JMSException e) {
            gLogger.error("Error reading jms message", e);
        } catch (Exception e) {
            gLogger.error("Error processing jms message", e);
        }
        gLogger.info("Method is completed: MQMessageListener : onMessage");
    }

    /**
     * Process byte message.
     *
     * @param byteMsg the byte msg
     * @throws Exception the exception
     */
    private void processByteMessage(BytesMessage byteMsg) throws Exception {

        File cached = backupMessage(byteMsg);

        try (FileInputStream fileIn = new FileInputStream(cached)) {
            processZipInputStream(fileIn, byteMsg.getJMSTimestamp());
        } catch (Exception e) {
            gLogger.error("Error processing zip file", e);
        }
    }

    /**
     * Backup message.
     *
     * @param byteMessage the byte message
     * @return the file
     * @throws Exception the exception
     */
    protected File backupMessage(BytesMessage byteMessage) throws Exception {

        try {
            gLogger.info("Backup of the message...... {}", genomeBackupDir);

            File msgRepository = new File(genomeBackupDir);
            if (!msgRepository.exists()) {
                msgRepository.mkdirs();
                msgRepository.mkdir();
            }

            File f = new File(msgRepository, "" + byteMessage.getJMSTimestamp() + ".zip");
            int suffix = 0;
            while (f.exists()) {
                suffix++;
                f = new File(msgRepository, "" + byteMessage.getJMSTimestamp() + "_" + suffix + ".zip");
            }

            if (!f.createNewFile()) {
                throw new Exception("Can not create the MQ message backup file...... ");
            }

            try (FileOutputStream fos = new FileOutputStream(f)) {
                // Saving a message
                byte[] buffer = new byte[BUFFER_SIZE];
                int nbLecture;
                while ((nbLecture = byteMessage.readBytes(buffer)) != -1) {
                    fos.write(buffer, 0, nbLecture);
                }

                buffer = (byte[]) null;
                fos.flush();
            } catch (Exception e) {
                gLogger.error("Error in writing to backup file", e);
            }
            return f;

        } catch (Exception e) {
            throw new Exception("Exception when saving byte message received..... ", e);
        }

    }

    /**
     * Process zip input stream.
     *
     * @param fileIn the file in
     * @param jmsTime the jms time
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void processZipInputStream(FileInputStream fileIn, long jmsTime) throws IOException {
        gLogger.info("Message processing - processZipInputStream ...");
        ZipInputStream zipIn = new ZipInputStream(fileIn);

        // Writing the data file to disk
        try {
            ZipEntry entry;
            while ((entry = zipIn.getNextEntry()) != null) {

                int count;
                byte data[] = new byte[BUFFER_SIZE];

                ByteArrayOutputStream dest = new ByteArrayOutputStream();
                while ((count = zipIn.read(data, 0, BUFFER_SIZE)) != -1) {
                    dest.write(data, 0, count);
                }

                if (!entry.getName().equals(FILE_CONFIG_ENTRY)) {
                    String fPath = new StringBuilder(genomeInDir).append(File.separator).append("genome_").append(jmsTime).append("_")
                            .append(entry.getName()).toString();
                    FileOutputStream fosNew = new FileOutputStream(new File(fPath));
                    dest.writeTo(fosNew);
                }

                dest.flush();
                dest.close();
            }
        } catch (IOException ex) {
            gLogger.error("Error processing zip file", ex);
        } finally {
            zipIn.close();
        }

    }
}