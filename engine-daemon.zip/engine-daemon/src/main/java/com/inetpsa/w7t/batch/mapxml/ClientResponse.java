/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.batch.mapxml;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ClientResponse.
 */
@XmlRootElement(name = "request")
@XmlType(propOrder = { "vin", "ecomDate", "extendedTitle", "clientAnswer" })
public class ClientResponse {

    private String requestNumber;

    private String requestType;

    private String vin;

    private LocalDate ecomDate;

    private String extendedTitle;

    private ClientAnswer clientAnswer;

    @XmlAttribute(name = "number")
    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    @XmlAttribute(name = "type")
    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    @XmlElement(name = "vin")
    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    @XmlElement(name = "ecom_date")
    public LocalDate getEcomDate() {
        return ecomDate;
    }

    public void setEcomDate(LocalDate ecomDate) {
        this.ecomDate = ecomDate;
    }

    @XmlElement(name = "extended_title")
    public String getExtendedTitle() {
        return extendedTitle;
    }

    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    public void setClientAnswer(ClientAnswer clientAnswer) {
        this.clientAnswer = clientAnswer;
    }

    @XmlElement(name = "answer")
    public ClientAnswer getClientAnswer() {
        return clientAnswer;
    }

}
