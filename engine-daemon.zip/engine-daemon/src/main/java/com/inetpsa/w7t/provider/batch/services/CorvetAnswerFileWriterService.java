/*
 * Creation : 24 Jan 2020
 */
package com.inetpsa.w7t.provider.batch.services;

import java.io.File;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;

/**
 * The Interface CorvetAnswerFileWriterService.
 */
@Service
public interface CorvetAnswerFileWriterService {

    /**
     * Write corvet answer.
     *
     * @param request the request
     * @param requestBatch the request batch
     */
    void writeCorvetAnswer(Request request, RequestBatch requestBatch);

    /**
     * Convert toxml file.
     *
     * @param destinationFilePath the destination file path
     * @param internalFileId the internal file id
     */
    void convertToxmlFile(File destinationFilePath, String internalFileId);
}
