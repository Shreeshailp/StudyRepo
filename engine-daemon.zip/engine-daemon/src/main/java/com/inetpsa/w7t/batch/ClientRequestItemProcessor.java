package com.inetpsa.w7t.batch;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.batch.model.ClientRequest;
import com.inetpsa.w7t.daemon.services.MaturityCheckBeanService;
import com.inetpsa.w7t.domains.client.prd.services.ClientPRDService;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.enginesettings.infrastructure.persistence.destination.DestinationDetailsRepository;
import com.inetpsa.w7t.domains.wltphub.answer.services.WltpHubAnswerService;
import com.inetpsa.w7t.provider.batch.services.EngineDaemonWltpHubService;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class ClientRequestItemProcessor.
 */
public class ClientRequestItemProcessor implements ItemProcessor<ClientRequest, ClientRequest> {

    /** The Constant NUM_ZERO. */
    public static final int NUM_ZERO = 0;

    /** The Constant NUM_THREE. */
    public static final int NUM_THREE = 3;

    /** The Constant NUM_FOUR. */
    public static final int NUM_FOUR = 4;

    /** The Constant NUM_FIVE. */
    public static final int NUM_FIVE = 5;

    /** The Constant CORVET. */
    private static final String CORVET = "CORVET";

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The common file id. */
    String commonFileId;

    /** The common batch id. */
    String commonBatchId;

    String commonInternalFileId;

    @Inject
    private MaturityCheckBeanService maturityCheckBean;

    @Inject
    private ClientPRDService clientPRDService;

    /** The destination details repository. */
    @Inject
    private DestinationDetailsRepository destinationDetailsRepository;

    /** The engine daemon wltp hub service. */
    @Inject
    private EngineDaemonWltpHubService engineDaemonWltpHubService;

    @Inject
    private WltpHubAnswerService wltpHubAnswerService;

    /**
     * Retrieve interstep data.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void retrieveInterstepData(StepExecution stepExecution) {
        this.commonFileId = stepExecution.getJobExecution().getExecutionContext().get("FILE_ID").toString();
        this.commonBatchId = stepExecution.getJobExecution().getExecutionContext().get("BATCH_ID").toString();
        this.commonInternalFileId = stepExecution.getJobExecution().getExecutionContext().get("INTERNAL_FILE_ID").toString();
    }

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */

    @Override
    public ClientRequest process(ClientRequest item) {

        boolean error = false;
        String requestNumber = item.getRequestNumber();
        String requestType = item.getRequestType();
        String vin = item.getVin();
        LocalDate ecomDate = item.getEcomDate();
        String extendedTitle = item.getExtendedTitle();
        item.setFileId(commonFileId);
        item.setInternalFileId(commonInternalFileId);
        item.setStatus(RequestStatus.VALID_REQUEST);

        // fixed Jira-547
        logger.info("Request ID[{}] : VIN : [{}], {}", requestNumber, item.getVin(), item);
        String client = "";
        try {

            if (item.getFileId() != null && !item.getFileId().isEmpty()) {
                String prd = item.getFileId().substring(0, 3);
                client = clientPRDService.getClientByPRD(prd);
            }
            if (!client.isEmpty()) {
                maturityCheckBean.maturityCheckForCorvetAndCompTool(item, client);
            } else {
                logger.warn("Request ID[{}] : Client name is missing", requestNumber);
            }
        } catch (SeedException se) {
            error = true;
            item.setStatus(RequestStatus.REQUEST_REJECTED);
            if (se.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
            } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
            }

            if (item.getAnswerDesignation().contains("Draft")) {
                item.setMaturity("D");
            } else if (item.getAnswerDesignation().contains("Obsolete")) {
                item.setMaturity("O");
            } else if (item.getAnswerDesignation().contains("Checked")) {
                item.setMaturity("C");
            } else if (item.getAnswerDesignation().contains("Unknown")) {
                item.setMaturity("U");
            } else if (item.getAnswerDesignation().contains("Captive fleet")) {
                item.setMaturity("F");
            }

        }

        try {
            if (CORVET.equalsIgnoreCase(client)) {// Hub Lot2 Changes -Start here
                Version version = new Version(ecomDate, extendedTitle, RequestType.valueOf(requestType), "GG8");
                if (!destinationDetailsRepository
                        .byCountryAndDate(version.getProgramCountry(requestNumber), version.getCharacteristic(), version.getEcomDate()).isPresent()) {
                    item.setStatus(RequestStatus.REQUEST_REJECTED);
                    item.setAnswerCode("ERRW" + WltpEngineCalculatorErrorCode.NO_DESTINATION_FOUND.getRuleCode());
                    item.setAnswerDesignation(WltpEngineCalculatorErrorCode.NO_DESTINATION_FOUND.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, item.getAnswerCode(), item.getAnswerDesignation());
                    error = true;
                }
            } // Hub Lot2 Changes -Ends here

            if (commonFileId == null || commonFileId.isEmpty()) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                item.setAnswerCode(RequestErrorCode.FILE_ID_INCORRECT.getRuleCode());
                item.setAnswerDesignation(RequestErrorCode.FILE_ID_INCORRECT.getDescription());
                LogErrorUtility.logTheError(logger, requestNumber, item.getAnswerCode(), item.getAnswerDesignation());
                error = true;
            }
            List<String> errorNamesList = item.validate();
            if (errorNamesList != null && !errorNamesList.isEmpty()) {
                boolean isInvalidFile = false;
                boolean isInvalidRequest = false;
                boolean isInvalidVin = false;
                boolean isInvalidExtTtl = false;
                for (String errorName : errorNamesList) {
                    RequestErrorCode valError = RequestErrorCode.valueOf(errorName);
                    switch (valError) {
                    case FILE_ID_INCORRECT:
                        isInvalidFile = true;
                        break;
                    case REQUEST_NUMBER_INCORRECT:
                        isInvalidRequest = true;
                        break;
                    case VIN_INCORRECT:
                        isInvalidVin = true;
                        break;
                    case EXTENDED_TITLE_INCORRECT:
                        isInvalidExtTtl = true;
                        break;
                    default:
                        break;
                    }
                }
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                if (!error) {
                    if (isInvalidFile) {
                        item.setAnswerCode(RequestErrorCode.FILE_ID_INCORRECT.getRuleCode());
                        item.setAnswerDesignation(RequestErrorCode.FILE_ID_INCORRECT.getDescription());
                    } else if (isInvalidRequest) {
                        item.setAnswerCode(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode());
                        item.setAnswerDesignation(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
                    } else if (isInvalidVin) {
                        item.setAnswerCode(RequestErrorCode.VIN_INCORRECT.getRuleCode());
                        item.setAnswerDesignation(RequestErrorCode.VIN_INCORRECT.getDescription());
                    } else if (isInvalidExtTtl) {
                        item.setAnswerCode(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode());
                        item.setAnswerDesignation(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
                    }
                    LogErrorUtility.logTheError(logger, requestNumber, item.getAnswerCode(), item.getAnswerDesignation());
                }
                error = true;
            }

            if (requestNumber == null || requestNumber.isEmpty()) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                if (!error) {
                    item.setAnswerCode(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode(),
                            RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
                }
                error = true;
            }

            if (vin == null || vin.isEmpty()) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                if (!error) {
                    item.setAnswerCode(RequestErrorCode.VIN_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.VIN_INCORRECT.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.VIN_INCORRECT.getRuleCode(),
                            RequestErrorCode.VIN_INCORRECT.getDescription());
                }
                error = true;
            }

            if (extendedTitle == null || extendedTitle.isEmpty()) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                if (!error) {
                    item.setAnswerCode(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                            RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
                }
                error = true;
            }

            if (!eNumContains(requestType)) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                item.setRequestType(RequestType.UNKNOWN.name());
                if (!error) {
                    item.setAnswerCode(RequestErrorCode.UNKNOWN_REQUEST_TYPE.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.UNKNOWN_REQUEST_TYPE.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_REQUEST_TYPE.getRuleCode(),
                            RequestErrorCode.UNKNOWN_REQUEST_TYPE.getDescription());
                }
                error = true;
            }

            if (ecomDate == null) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
                if (!error) {
                    item.setAnswerCode(RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode());
                    item.setAnswerDesignation(RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
                    LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(),
                            RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
                }
                error = true;
            }
            // Call WLTPHUB-only for corvet
            if (!error && CORVET.equalsIgnoreCase(client)) {
                // item.setCountry("FR");
                WltpHubResponseRepresentation response = engineDaemonWltpHubService.callWltpHubWebService(item);
                if (response.getAnswer().getCode().startsWith("OK")) {
                    error = false;
                    item.setStatus(RequestStatus.CALCULATION_OK);
                    item.setAnswerCode(response.getAnswer().getCode());
                    if (StringUtils.isNotEmpty(response.getAnswer().getDesignation())) {
                        item.setAnswerDesignation("WLTP " + response.getAnswer().getDesignation().toLowerCase());
                    }
                    wltpHubAnswerService.saveWltpHubAnswer(item.getRequestNumber(), item.getInternalFileId(), response);
                } else if (response.getAnswer().getCode().contains("ERRW700") || response.getAnswer().getCode().contains("ERRW701")
                        || response.getAnswer().getCode().contains("ERRW702") || response.getAnswer().getCode().contains("ERRWH01")
                        || response.getAnswer().getCode().contains("ERRWH02")) {
                    int maxRetryCount = 3;
                    int count = 1;
                    while (count < maxRetryCount) {
                        logger.info("Request ID[{}]: As we have an Technical issue and we are re-calling Hub webservice !", item.getRequestNumber());
                        response = engineDaemonWltpHubService.callWltpHubWebService(item);
                        if (response.getAnswer().getCode().startsWith("OK")) {
                            item.setStatus(RequestStatus.CALCULATION_OK);
                            item.setAnswerCode(response.getAnswer().getCode());
                            item.setAnswerDesignation(response.getAnswer().getDesignation());
                            wltpHubAnswerService.saveWltpHubAnswer(item.getRequestNumber(), item.getInternalFileId(), response);
                            break;
                        }
                        count++;
                        if (count == maxRetryCount) {
                            item.setStatus(RequestStatus.WLTP_HUB_CALCULATION_KO);
                        }
                    }

                } else {
                    item.setStatus(RequestStatus.WLTP_HUB_CALCULATION_KO);
                }
            }
            // Receive the response "OK" from the HUB and will set the status as 70 else we don't do anything
            if (!error && !item.getStatus().equals(RequestStatus.CALCULATION_OK) && !titleIsValid(item)) {
                item.setStatus(RequestStatus.REQUEST_REJECTED);
            }

            logger.info("{} {} Old Status = BLANK, New Status = {}({})", requestNumber, LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS),
                    item.getStatus().getStatusCode(), item.getStatus());
        } catch (RuntimeException e) {
            item.setStatus(RequestStatus.REQUEST_REJECTED);
            item.setAnswerCode(RequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode());
            item.setAnswerDesignation(RequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
            LogErrorUtility.logTheError(logger, requestNumber, item.getAnswerCode(), item.getAnswerDesignation());
            logger.info("{} {} Old Status = BLANK, New Status = {}({})", requestNumber, LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS),
                    item.getStatus().getStatusCode(), item.getStatus());
        }
        return item;
    }

    /**
     * E num contains.
     *
     * @param requestType the request type
     * @return true, if successful
     */
    public static boolean eNumContains(String requestType) {

        for (RequestType r : RequestType.values()) {
            if (r.name().equals(requestType)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Title is valid.
     *
     * @param item the item
     * @return true, if successful
     */
    public boolean titleIsValid(ClientRequest item) {
        String title = item.getExtendedTitle();

        Matcher vehicleFamilyMatch = Pattern.compile("(....).{20}(?:.{7})*").matcher(title);
        Matcher wltpFamilyCodeMatch = Pattern.compile(".{24}(?:.{7})*(?:T8C(..)(..))(?:.{7})*").matcher(title);
        Matcher wltpFamilyIndexMatch = Pattern.compile(".{24}(?:.{7})*(?:T8D(..)(..))(?:.{7})*").matcher(title);
        Matcher countryMatch = Pattern.compile(".{24}(?:.{7})*(?:GG8(..)(..))(?:.{7})*").matcher(title);
        Matcher gvmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3N(..)(..))(?:.{7})*").matcher(title);
        Matcher fomMatch = Pattern.compile(".{24}(?:.{7})*(?:T3S(..)(..))(?:.{7})*").matcher(title);
        Matcher emmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3M(..)(..))(?:.{7})*").matcher(title);
        Matcher coherenceIndexMatch = Pattern.compile(".{24}(?:.{7})*(?:T8E(..)(..))(?:.{7})*").matcher(title);
        Matcher tvvT1AMatch = Pattern.compile(".{24}(?:.{7})*(?:T1A(..)(..))(?:.{7})*").matcher(title);
        Matcher tvvT1BMatch = Pattern.compile(".{24}(?:.{7})*(?:T1B(..)(..))(?:.{7})*").matcher(title);
        String t1aValue = "";
        String t1bValue = "";

        String tvvDesignation = "";

        if (item.getTvvDesignation() != null && !item.getTvvDesignation().isEmpty()) {
            tvvDesignation = item.getTvvDesignation();
        }

        if (tvvT1AMatch.matches()) {
            t1aValue = tvvT1AMatch.group(1);
        }
        if (tvvT1BMatch.matches()) {
            t1bValue = tvvT1BMatch.group(1);
        }
        String requestNumber = item.getRequestNumber();
        boolean t1AT1BMatch = tvvT1AMatch.matches() && tvvT1BMatch.matches();
        WltpErrorCode wltpErrorCode = new WltpErrorCode();
        RequestErrorCode error;
        boolean tvvErrorFlag = false;
        logger.info("Request ID[{}]: T1A & T1B Match[{}]", requestNumber, t1AT1BMatch);
        if (!wltpFamilyCodeMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FAMILY_CODE_MISSING.getRuleCode(),
                    RequestErrorCode.FAMILY_CODE_MISSING.getDescription());
            error = RequestErrorCode.FAMILY_CODE_MISSING;
        } else if (!wltpFamilyIndexMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FAMILY_INDEX_MISSING.getRuleCode(),
                    RequestErrorCode.FAMILY_INDEX_MISSING.getDescription());
            error = RequestErrorCode.FAMILY_INDEX_MISSING;
        } else if (jdbcTemplate
                .queryForList("SELECT * FROM W7TQTFAM AS f where f.CODE= ? AND f.IND= ?", wltpFamilyCodeMatch.group(1), wltpFamilyIndexMatch.group(1))
                .isEmpty()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getRuleCode(),
                    RequestErrorCode.UNKNOWN_FAMILY_COUPLE.getDescription());
            error = RequestErrorCode.UNKNOWN_FAMILY_COUPLE;
        } else if (!countryMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.PROGRAM_COUNTRY_MISSING.getRuleCode(),
                    RequestErrorCode.PROGRAM_COUNTRY_MISSING.getDescription());
            error = RequestErrorCode.PROGRAM_COUNTRY_MISSING;
        } else if (jdbcTemplate.queryForList("SELECT * FROM W7TQTCTY where CODE= ? AND CHARACTERISTIC= ?", countryMatch.group(1), "GG8").isEmpty()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY.getRuleCode(),
                    RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY.getDescription());
            error = RequestErrorCode.UNKNOWN_PROGRAM_COUNTRY;
        } else if (!coherenceIndexMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING.getRuleCode(),
                    RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING.getDescription());
            error = RequestErrorCode.PHYS_COHERENCE_INDEX_MISSING;
        } else if (!vehicleFamilyMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                    RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            error = RequestErrorCode.EXTENDED_TITLE_INCORRECT;
        } else if (!tvvDesignation.isEmpty() && !t1AT1BMatch && vehicleFamilyMatch.matches()
                && jdbcTemplate.queryForList("SELECT * FROM W7TQTTVV AS t where t.VEHICLE_FAMILY= ? AND t.TVV_DESIGNATION=?",
                        vehicleFamilyMatch.group(1), item.getTvvDesignation()).isEmpty()) {
            logger.info("Request ID[{}]: T1A[{}] : T1B[{}] : TVV Designation[{}]", requestNumber, t1aValue, t1bValue, tvvDesignation);
            // fixed jira-535 starts here
            wltpErrorCode.setStrRuleCode(RequestErrorCode.UNKNOWN_TVV.getRuleCode());
            wltpErrorCode.setDescription(
                    RequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + vehicleFamilyMatch.group(1) + ", " + item.getTvvDesignation() + "]");
            LogErrorUtility.logTheError(logger, requestNumber, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());

            tvvErrorFlag = true;
            error = null;
            // fixed jira-535 ends here
        } else if (!tvvDesignation.isEmpty() && !t1AT1BMatch && vehicleFamilyMatch.matches()
                && jdbcTemplate.queryForList("SELECT * FROM W7TQTTVV AS t where t.VEHICLE_FAMILY= ? AND t.TVV_DESIGNATION=?",
                        vehicleFamilyMatch.group(1), item.getTvvDesignation()).size() > 1) {
            logger.info("Request ID[{}]: T1A[{}] : T1B[{}] : TVV Designation[{}]", requestNumber, t1aValue, t1bValue, tvvDesignation);
            wltpErrorCode.setStrRuleCode(RequestErrorCode.SEVERAL_TVV.getRuleCode());
            wltpErrorCode.setDescription(
                    RequestErrorCode.SEVERAL_TVV.getDescription() + "[" + vehicleFamilyMatch.group(1) + ", " + item.getTvvDesignation() + "]");
            tvvErrorFlag = true;
            error = null;
            // JIRA-535 Fix Ends Here
            LogErrorUtility.logTheError(logger, requestNumber, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
        } else if (t1AT1BMatch && vehicleFamilyMatch.matches() && tvvDesignation.isEmpty()
                && jdbcTemplate.queryForList("SELECT * FROM W7TQTTVV AS t where t.VEHICLE_FAMILY= ? AND t.T1A_VALUE= ? AND t.T1B_VALUE= ?",
                        vehicleFamilyMatch.group(1), tvvT1AMatch.group(1), tvvT1BMatch.group(1)).isEmpty()) {
            logger.info("Request ID[{}]: T1A[{}] : T1B[{}]", requestNumber, t1aValue, t1bValue);
            // fixed jira-535 starts here
            wltpErrorCode.setStrRuleCode(RequestErrorCode.UNKNOWN_TVV.getRuleCode());
            wltpErrorCode.setDescription(RequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + vehicleFamilyMatch.group(1) + ", T1A" + t1aValue
                    + ", T1B" + t1bValue + "]");
            LogErrorUtility.logTheError(logger, requestNumber, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
            tvvErrorFlag = true;
            error = null;
            // fixed jira-535 ends here
        } else if (t1AT1BMatch && vehicleFamilyMatch.matches() && tvvDesignation.isEmpty()
                && jdbcTemplate.queryForList("SELECT * FROM W7TQTTVV AS t where t.VEHICLE_FAMILY= ? AND t.T1A_VALUE= ? AND t.T1B_VALUE= ?",
                        vehicleFamilyMatch.group(1), tvvT1AMatch.group(1), tvvT1BMatch.group(1)).size() > 1) {
            logger.info("Request ID[{}]: T1A[{}] : T1B[{}]", requestNumber, t1aValue, t1bValue);
            wltpErrorCode.setStrRuleCode(RequestErrorCode.SEVERAL_TVV.getRuleCode());
            wltpErrorCode.setDescription(RequestErrorCode.SEVERAL_TVV.getDescription() + "[" + vehicleFamilyMatch.group(1) + ", T1A" + t1aValue
                    + ", T1B" + t1bValue + "]");
            tvvErrorFlag = true;
            error = null;
            // JIRA-535 Fix Ends Here
            LogErrorUtility.logTheError(logger, requestNumber, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
        } else if ((!t1AT1BMatch && tvvDesignation.isEmpty()) && (!t1aValue.isEmpty() || !t1bValue.isEmpty())) {
            logger.info("Request ID[{}]: T1A[{}] : T1B[{}] : TVV Designation[{}]", requestNumber, t1aValue, t1bValue, tvvDesignation);
            String t1aStrValue = "";
            String t1bStrValue = "";
            if (!t1aValue.isEmpty()) {
                t1aStrValue = "T1A" + t1aValue;
            }
            if (!t1bValue.isEmpty()) {
                t1bStrValue = "T1B" + t1bValue;
            }
            wltpErrorCode.setStrRuleCode(RequestErrorCode.UNKNOWN_TVV.getRuleCode());
            wltpErrorCode.setDescription(RequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + vehicleFamilyMatch.group(1) + ", " + t1aStrValue + ", "
                    + t1bStrValue + "]");
            tvvErrorFlag = true;
            error = null;
            LogErrorUtility.logTheError(logger, requestNumber, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
        } else if (!gvmMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.MTAC_MISSING.getRuleCode(),
                    RequestErrorCode.MTAC_MISSING.getDescription());
            error = RequestErrorCode.MTAC_MISSING;
        } else if (!fomMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.FOM_MISSING.getRuleCode(),
                    RequestErrorCode.FOM_MISSING.getDescription());
            error = RequestErrorCode.FOM_MISSING;
        } else if (!emmMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.EMM_MISSING.getRuleCode(),
                    RequestErrorCode.EMM_MISSING.getDescription());
            error = RequestErrorCode.EMM_MISSING;
        } else if (!validMassValue(gvmMatch.group(1), vehicleFamilyMatch.group(1), "T3N")) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_MTAC_VALUE.getRuleCode(),
                    RequestErrorCode.UNKNOWN_MTAC_VALUE.getDescription());
            error = RequestErrorCode.UNKNOWN_MTAC_VALUE;
        } else if (!validMassValue(fomMatch.group(1), vehicleFamilyMatch.group(1), "T3S")) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_FOM_VALUE.getRuleCode(),
                    RequestErrorCode.UNKNOWN_FOM_VALUE.getDescription());
            error = RequestErrorCode.UNKNOWN_FOM_VALUE;
        } else if (!validMassValue(emmMatch.group(1), vehicleFamilyMatch.group(1), "T3M")) {
            LogErrorUtility.logTheError(logger, requestNumber, RequestErrorCode.UNKNOWN_EMM_VALUE.getRuleCode(),
                    RequestErrorCode.UNKNOWN_EMM_VALUE.getDescription());
            error = RequestErrorCode.UNKNOWN_EMM_VALUE;
        } else {
            return true;
        }
        if (tvvErrorFlag) {
            item.setAnswerCode(wltpErrorCode.getStrRuleCode());
            item.setAnswerDesignation(wltpErrorCode.getDescription());
        } else {
            if (error != null) {
                item.setAnswerCode(error.getRuleCode());
                item.setAnswerDesignation(error.getDescription());
            }
        }
        return false;
    }

    /**
     * Checks the validity of the particular mass value.
     *
     * @param code           the code
     * @param family         the family
     * @param characteristic the characteristic
     * @return true, if successful
     */
    private boolean validMassValue(String code, String family, String characteristic) {
        List<Map<String, Object>> result = jdbcTemplate.queryForList("SELECT * FROM W7TQTGVM where CODE= ? AND FAMILY= ? AND CHARACTERISTIC= ?", code,
                family, characteristic);
        Optional<Integer> value = result.stream().map(row -> row.get("VALUE")).map(o -> (String) o).map(s -> {
            try {
                return new Integer(s);
            } catch (NumberFormatException e) {
                logger.debug("Parsing of Mass value failed", e);
                return null;
            }
        }).filter(Objects::nonNull).findFirst();

        boolean flag = false;
        if (value.isPresent()) {
            if ("T3S".equals(characteristic))
                flag = value.get() >= 0;
            else
                flag = value.get() > 0;
        }
        return flag;
    }

}
