package com.inetpsa.w7t.batch;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class LocalDateAdapter.
 */
public class LocalDateAdapter extends XmlAdapter<String, LocalDate> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    /** The Constant DEFAULT_DATE. */
    private static final LocalDate DEFAULT_DATE = LocalDate.parse("1900-01-01");

    /**
     * {@inheritDoc}
     * 
     * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
     */
    @Override
    public LocalDate unmarshal(String v) {

        LocalDate date = null;
        try {
            date = LocalDate.parse(v.trim(), DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (DateTimeParseException e) {
            logger.error(e.getMessage(), e);
            return DEFAULT_DATE;
        }
        return date;

    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
     */
    @Override
    public String marshal(LocalDate v) throws Exception {
        return v.toString();
    }

}