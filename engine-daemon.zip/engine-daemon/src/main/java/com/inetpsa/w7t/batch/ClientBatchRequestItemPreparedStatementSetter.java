package com.inetpsa.w7t.batch;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.inetpsa.w7t.batch.model.ClientServiceRequest;
import com.inetpsa.w7t.batch.util.FsFlagFileResource;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;
import com.inetpsa.w7t.domains.client.prd.services.ClientPRDService;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;

/**
 * The Class ClientBatchRequestItemPreparedStatementSetter.
 */
public class ClientBatchRequestItemPreparedStatementSetter implements ItemPreparedStatementSetter<ClientServiceRequest> {
    /** The Constant NUM_FOUR. */
    private static final int NUM_FOUR = 4;

    /** The Constant NUM_THREE. */
    private static final int NUM_THREE = 3;

    /** The Constant NUM_TWO. */
    private static final int NUM_TWO = 2;

    /** The Constant NUM_ONE. */
    private static final int NUM_ONE = 1;

    // Change for CFT- HA
    private static final int NUM_FIVE = 5;

    private static final int NUM_SIX = 6;

    private static final int NUM_SEVEN = 7;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Inject
    private ClientPRDService clientPRDService;

    private FsFlagFileResource resource;

    @Inject
    private FsFlagFileService fsFlagFileService;

    public FsFlagFileResource getResource() {
        return this.resource;
    }

    public void setResource(FsFlagFileResource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.ItemPreparedStatementSetter#setValues(java.lang.Object, java.sql.PreparedStatement)
     */
    @Override
    public void setValues(ClientServiceRequest batch, PreparedStatement ps) throws SQLException {
        logger.info("Here--- ClientBatchRequestItemPreparedStatementSetter ---");
        String client = "";
        if (clientPRDService != null && (batch.getFileId() != null && !batch.getFileId().isEmpty())) {
            String prd = batch.getFileId().substring(0, 3);
            client = clientPRDService.getClientByPRD(prd);
        }
        ps.setString(NUM_ONE, batch.getBatchId());
        ps.setString(NUM_TWO, batch.getFileId());
        // ps.setString(NUM_THREE, "CORVET");
        ps.setString(NUM_THREE, client);

        if (batch.getRequestDate() == null) {
            logger.info("Request Date missing or incorrect format. Setting current date as the request date.");
            ps.setTimestamp(NUM_FOUR, new Timestamp(new Date().getTime()));
        } else {
            ps.setTimestamp(NUM_FOUR, new Timestamp(batch.getRequestDate().getTime()));
        }

        // Change for CFT- HA
        ps.setString(NUM_FIVE, DaemonConfig.getReqMachine());
        ps.setString(NUM_SIX, null);
        ps.setString(NUM_SEVEN, batch.getInternalFileId());

        // save jira-660 fix
        if (resource != null && !resource.getFsFlagFileName().isEmpty()) {

            fsFlagFileService.saveFsFlagEntity(client, resource.getFsFlagFileName(), batch.getInternalFileId());
        }
    }

}