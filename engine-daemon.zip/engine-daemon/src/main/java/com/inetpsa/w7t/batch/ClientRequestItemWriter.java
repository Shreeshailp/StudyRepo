/*
 * Creation : 10 avr. 2017
 */
package com.inetpsa.w7t.batch;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.database.JdbcBatchItemWriter;

import com.inetpsa.w7t.batch.model.ClientRequest;

/**
 * The Class ClientRequestItemWriter.
 */
public class ClientRequestItemWriter extends JdbcBatchItemWriter<ClientRequest> {

    /** The file id. */
    private String fileId;

    /** The batch id. */
    private String batchId;

    private String internalFileId;

    /**
     * Retrieve interstep data.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void retrieveInterstepData(StepExecution stepExecution) {
        this.fileId = stepExecution.getJobExecution().getExecutionContext().get("FILE_ID").toString();
        this.batchId = stepExecution.getJobExecution().getExecutionContext().get("BATCH_ID").toString();
        this.internalFileId = stepExecution.getJobExecution().getExecutionContext().get("INTERNAL_FILE_ID").toString();
        stepExecution.getJobExecution().getExecutionContext().put("BATCH_ID", batchId);
        stepExecution.getJobExecution().getExecutionContext().put("INTERNAL_FILE_ID", internalFileId);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JdbcBatchItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends ClientRequest> items) throws Exception {
        items.forEach(item -> {
            item.setFileId(this.fileId);
            item.setBatchid(this.batchId);
            item.setInternalFileId(this.internalFileId);
        });

        int retries = 0;
        do {
            try {
                super.write(items);
                retries = 0;
            } catch (Exception e) {
                retries++;
                logger.warn("Exception while executing write query", e);
                if (retries == 5)
                    throw e;
            }
        } while (retries > 0);
    }
}
