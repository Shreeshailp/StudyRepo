/*
 * Creation : 6 nov. 2017
 */
package com.inetpsa.w7t.dictionary.listener.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * The Class DictionaryConstants.
 */
public final class DictionaryConstants {

    /**
     * The Constant CHARACTERISTICS_TO_READ. This list contains the characteristics read from the dictionary. Add or remove characteristic here to be
     * handled by genome processing for future enhancements.
     */
    public static final List<String> CHARACTERISTICS_TO_READ = Collections.unmodifiableList(Arrays.asList("GG8", "GA1", "B0F", "B0G"));

    /**
     * The Constant LANGUAGE_TO_READ. This variable contains the 'LANGUE' value to be read from the dictionaries. Change language code to be read from
     * dictionary for future enhancements.
     */
    public static final String LANGUAGE_TO_READ = "FR";

    /** The Constant MASS_CHARACTERISTICS_TO_READ. */
    public static final List<String> MASS_CHARACTERISTICS_TO_READ = Collections.unmodifiableList(Arrays.asList("T3N", "T3S", "T3M"));

    /**
     * Instantiates a new dictionary constants.
     */
    private DictionaryConstants() {
    }

}
