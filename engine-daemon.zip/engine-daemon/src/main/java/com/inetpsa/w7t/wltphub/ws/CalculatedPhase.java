/*
 * Creation : 23 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CalculatedPhase {
    private String phaseCode;

    private List<CalculatedMeasure> emissions;

    public void addEmission(String measureTypeCode, BigDecimal value) {
        if (emissions == null)
            emissions = new ArrayList<>();
        emissions.add(new CalculatedMeasure(measureTypeCode, value));
    }

    public CalculatedPhase(String phaseCode) {
        super();
        this.phaseCode = phaseCode;
    }

    public String getPhaseCode() {
        return phaseCode;
    }

    public List<CalculatedMeasure> getEmissions() {
        return this.emissions;
    }

}
