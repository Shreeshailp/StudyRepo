/*
 * Creation : 6 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service.internal;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREFAMILLEType;
import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREGENERALType;
import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREType;
import com.inetpsa.w7t.dictionary.listener.model.DictionaryConstants;
import com.inetpsa.w7t.dictionary.listener.service.DictionaryParserService;
import com.inetpsa.w7t.dictionary.listener.service.FamilyDictionaryService;
import com.inetpsa.w7t.dictionary.listener.service.GeneralDictionaryService;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class DictionaryParserServiceImpl implements DictionaryParserService {

    @Inject
    FamilyDictionaryService gvmUpdater;

    @Inject
    GeneralDictionaryService ctyUpdater;

    @Configuration("daemon.providers.genome.dictionaryEncoding")
    private String dictionaryEncoding;

    Logger genomeLogger = LoggerFactory.getLogger("com.inetpsa.genome");

    @Override
    public void parse(String fileLocation) {
        StringBuilder batchReport = new StringBuilder();

        if (dictionaryEncoding == null || dictionaryEncoding.isEmpty())
            dictionaryEncoding = "ISO-8859-1";
        InputStream fis = null;
        try {
            XMLInputFactory xif = XMLInputFactory.newFactory();

            fis = new FileInputStream(fileLocation);
            genomeLogger.info("File picked up to be read and parsed. File moved to : {}", fileLocation);
            XMLStreamReader xsr = xif.createXMLStreamReader(fis, dictionaryEncoding);

            xsr.nextTag();
            while (xsr.hasNext()) {
                if (xsr.isStartElement() && ("DICTIONNAIRE").equals(xsr.getLocalName())) {
                    break;
                }
                xsr.next();
            }
            JAXBContext jc = JAXBContext.newInstance(DICTIONNAIREType.class);
            Unmarshaller unmarshaller = jc.createUnmarshaller();
            JAXBElement<DICTIONNAIREType> jb = unmarshaller.unmarshal(xsr, DICTIONNAIREType.class);
            xsr.close();
            genomeLogger.info("File parsing completed");

            DICTIONNAIREType dictionary = jb.getValue();
            if (!dictionary.getDICTIONNAIREFAMILLE().isEmpty()) {
                int[] charCount = new int[DictionaryConstants.MASS_CHARACTERISTICS_TO_READ.size()];
                for (DICTIONNAIREFAMILLEType dft : dictionary.getDICTIONNAIREFAMILLE()) {
                    int[] chars = gvmUpdater.mtacUpdate(dft);
                    for (int i = 0; i <= charCount.length - 1; i++) {
                        charCount[i] = charCount[i] + chars[i];
                    }
                }
                batchReport.append("Batch Report: Family Dictionary");
                for (int i = 0; i <= charCount.length - 1; i++) {
                    batchReport.append(" - Number of characteristic ").append(DictionaryConstants.MASS_CHARACTERISTICS_TO_READ.get(i))
                            .append(" found = ").append(charCount[i]);
                }
            } else {
                DICTIONNAIREGENERALType dg = dictionary.getDICTIONNAIREGENERAL();
                int[] charCount = ctyUpdater.countryUpdate(dg);
                batchReport.append("Batch Report: General Dictionary");
                for (int i = 0; i <= charCount.length - 1; i++) {
                    batchReport.append(" - Number of characteristic ").append(DictionaryConstants.CHARACTERISTICS_TO_READ.get(i)).append(" found = ")
                            .append(charCount[i]);
                }
            }

            genomeLogger.info("File operations completed");
            genomeLogger.info(batchReport.toString());
        } catch (JAXBException | XMLStreamException | FileNotFoundException e) {
            genomeLogger.error("Error in parsing the file! " + e.getMessage(), e);
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    genomeLogger.error("Error in parsing the file! " + e.getMessage(), e);
                }
            }
        }
    }

}
