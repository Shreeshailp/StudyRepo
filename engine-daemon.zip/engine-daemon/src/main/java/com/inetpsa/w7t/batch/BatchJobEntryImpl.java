/*
 * Creation : 28 avr. 2017
 */
package com.inetpsa.w7t.batch;

import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.CLIENT_REQ_JOB_NAM;
import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.COMPTOOL_ANSWER_JOB_NAM;
import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.CORVET_ANSWER_JOB_NAM;
import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.PROVIDER_REQ_JOB_NAM;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;

import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;

/**
 * The Class BatchJobEntryImpl.
 */
public class BatchJobEntryImpl implements BatchJobEntry {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The daemon file config util service. */
    @Inject
    private DaemonFileConfigUtilService daemonFileConfigUtilService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.BatchJobEntry#runJob(java.lang.String, java.lang.String)
     */
    private static final String FILE_LOCATION = "file_location";

    @Override
    public void runJob(String jobName, String fileLoc, String fsFlagFileName) {

        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);
        // JIRA-323 Fix -Starts Here
        JobParameters jobParams = null;
        String path = null;
        if (jobName.equalsIgnoreCase(CORVET_ANSWER_JOB_NAM) || jobName.equalsIgnoreCase(COMPTOOL_ANSWER_JOB_NAM)) {
            jobParams = new JobParametersBuilder().addString(FILE_LOCATION, fileLoc).addLong("time", System.currentTimeMillis())
                    .addString("machineId", DaemonConfig.getBcvResMachine()).toJobParameters();

        } else if (jobName.equalsIgnoreCase(PROVIDER_REQ_JOB_NAM)) {
            path = new StringBuilder(fileLoc).append(File.separator).append("newton_").append(new Date().getTime()).append(".dat").append(".part")
                    .toString();
            jobParams = new JobParametersBuilder().addString(FILE_LOCATION, path).addLong("time", System.currentTimeMillis()).toJobParameters();
            logger.info("Newton Request File Path : [{}] ", path);
            // JIRA-323 Fix -Ends Here
        } else {
            jobParams = new JobParametersBuilder().addString(FILE_LOCATION, fileLoc).addLong("time", System.currentTimeMillis())
                    .addString("fs_flag_file_name", fsFlagFileName).toJobParameters();
        }

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : {}", execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {
                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                BatchUtils.moveFileToError(fileLoc);
                if (jobName.equalsIgnoreCase(CLIENT_REQ_JOB_NAM)) {
                    deleteFsFlagFile(fsFlagFileName);
                }

            }

            // JIRA-323 Fix -Starts Here
            if (path != null) {
                File sourceFile = new File(path);
                Path newFile = Paths.get(sourceFile.getAbsolutePath());
                if (sourceFile.isFile()) {
                    int lastIndex = sourceFile.getName().lastIndexOf('.');
                    String newFileName = sourceFile.getName().substring(0, lastIndex);
                    Files.move(newFile, newFile.resolveSibling(newFileName));
                }
            }
            // JIRA-323 Fix -Ends Here
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }

    }

    private void deleteFsFlagFile(String fsFlagFileName) {
        if (daemonFileConfigUtilService != null) {
            String fsFlagPath = daemonFileConfigUtilService.getFsFlagPath();
            File dir = new File(fsFlagPath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                for (File file : dirContents) {
                    try {
                        if (file.getName().contains(fsFlagFileName)) {
                            FileUtils.forceDelete(file);
                            logger.info("Fs Flag File [{}] has been deleted from the location {}", fsFlagFileName, fsFlagPath);
                            break;
                        }
                    } catch (IOException e) {
                        logger.error("Exception while deleting the file : {}", e);
                    }
                }
            }
        }
    }

}
