/*
 * Creation : 22 Feb 2021
 */
package com.inetpsa.w7t.batch;

import javax.inject.Inject;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Cache;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import com.inetpsa.w7t.daemon.services.MaturityCheckBeanService;

public class HibernateClearCacheListener implements JobExecutionListener {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(HibernateClearCacheListener.class);
    /** The entity manager factory. */
    private EntityManagerFactory entityManagerFactory;

    @Inject
    private MaturityCheckBeanService maturityCheckBeanService;

    public EntityManagerFactory getEntityManagerFactory() {
        return entityManagerFactory;
    }

    public void setEntityManagerFactory(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        // Nothing to do here

    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        try {
            org.springframework.batch.core.BatchStatus batchStatus = jobExecution.getStatus();
            if (org.springframework.batch.core.BatchStatus.COMPLETED == batchStatus) {
                if (this.entityManagerFactory != null) {
                    this.entityManagerFactory.getCache().evictAll();

                    SessionFactory sessionFactory = this.entityManagerFactory.unwrap(SessionFactory.class);

                    // Session session = sessionFactory.openSession();
                    //
                    // if (session != null) {
                    // session.clear(); // internal cache clear
                    // }

                    maturityCheckBeanService.clearSession();
                    Cache cache = sessionFactory.getCache();

                    if (cache != null) {
                        cache.evictAllRegions(); // Evict data from all query regions.
                    }

                    logger.info("After job [ {} ] all hibernate cache has been removed successfully ! ", jobExecution.getJobInstance().getJobName());
                }
            }
        } catch (Exception e) {
            logger.error("ERROR : {}", e);
        }

    }

}
