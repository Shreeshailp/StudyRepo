/*
 * Creation : 18 mai 2017
 */
package com.inetpsa.w7t.provider.batch;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.inetpsa.w7t.batch.util.BatchUtils;

/**
 * The Class NewtonAnswerFileMoveTasklet.
 */
public class NewtonAnswerFileMoveTasklet implements Tasklet, InitializingBean {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The filepath. */
    private String filepath;

    /**
     * Instantiates a new newton answer file move tasklet.
     *
     * @param path the path
     */
    public NewtonAnswerFileMoveTasklet(String path) {
        this.filepath = path;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(filepath, "File Path cannot be null");

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution,
     *      org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        try {

            BatchUtils.moveProcessedFile(filepath);

        } catch (IOException e) {
            logger.error("Failed to copy file to processed dir ", e);
        }

        return RepeatStatus.FINISHED;
    }

}
