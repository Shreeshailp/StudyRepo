/*
 * Creation : 5 sept. 2017
 */
package com.inetpsa.w7t.batch;

import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * The Class InterceptingJobExecution.
 */
public class InterceptingJobExecution implements JobExecutionListener {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.JobExecutionListener#beforeJob(org.springframework.batch.core.JobExecution)
     */
    @Override
    public void beforeJob(JobExecution jobExecution) {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.JobExecutionListener#afterJob(org.springframework.batch.core.JobExecution)
     */
    @Override
    public void afterJob(JobExecution jobExecution) {
        org.springframework.batch.core.BatchStatus batchStatus = jobExecution.getStatus();
        if (org.springframework.batch.core.BatchStatus.STOPPED != batchStatus) {
            try {
                String batchId = jobExecution.getExecutionContext().getString("BATCH_ID");
                String updateSql = "UPDATE W7TQTRQB SET status = ? WHERE id = ?";
                Object[] params = { "C", batchId };
                int[] types = { Types.VARCHAR, Types.VARCHAR };
                jdbcTemplate.update(updateSql, params, types);
            } catch (RuntimeException e) {
                logger.error("Error in spring batch while updating batch final status " + e.getMessage(), e);
            }
        }
    }

}
