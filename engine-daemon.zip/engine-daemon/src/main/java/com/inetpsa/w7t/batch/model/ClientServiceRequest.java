package com.inetpsa.w7t.batch.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.inetpsa.w7t.batch.DateAdapter;

/**
 * The Class ClientServiceRequest.
 */
@XmlRootElement(name = "wltp_service")
public class ClientServiceRequest {

    /** The file id. */
    private String fileId;

    /** The request date. */
    private Date requestDate;

    /** The batch id. */
    private String batchId;

    private String internalFileId;

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    @XmlAttribute(name = "file_id")
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    @XmlAttribute(name = "request_date")
    @XmlJavaTypeAdapter(type = Date.class, value = DateAdapter.class)
    public Date getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the batch id.
     *
     * @return the batch id
     */
    public String getBatchId() {
        return batchId;
    }

    /**
     * Sets the batch id.
     *
     * @param batchId the new batch id
     */
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getInternalFileId() {
        return internalFileId;
    }

    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

}
