/*
 * Creation : 8 Sep 2019
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.model.ClientRequest;

/**
 * The Interface MaturityCheckBeanService.
 */
@Service
public interface MaturityCheckBeanService {

    /**
     * Maturity check for corvet.
     *
     * @param item the item
     */
    void maturityCheckForCorvet(ClientRequest item);

    /**
     * Maturity check for corvet and comp tool.
     *
     * @param item the item
     * @param client the client
     */
    void maturityCheckForCorvetAndCompTool(ClientRequest item, String client);

    /**
     * Clear session.
     */
    void clearSession();
}
