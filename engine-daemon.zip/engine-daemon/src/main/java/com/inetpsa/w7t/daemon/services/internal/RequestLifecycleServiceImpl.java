/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import static com.inetpsa.w7t.daemon.services.misc.DaemonServiceConstants.PROVIDER_REQ_JOB_NAM;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.time.StopWatch;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.BatchJobEntry;
import com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService;
import com.inetpsa.w7t.cli.EngineDaemonCommandLineHandler;
import com.inetpsa.w7t.daemon.services.EngineDaemonService;
import com.inetpsa.w7t.daemon.services.FileWriter;
import com.inetpsa.w7t.daemon.services.RequestLifecycleService;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestBatchRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.RequestRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.StepRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.ThreadPoolMasterRepository;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.NewtonEntity;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.shared.NewtonAnswerErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;

/**
 * The Class RequestLifecycleServiceImpl.
 */
public class RequestLifecycleServiceImpl implements RequestLifecycleService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The refresh interval. */
    @Configuration("daemon.lifecycleRefreshInterval")
    private int refreshInterval;

    /** The step count. */
    @Configuration("daemon.lifecycleStepCount")
    private int stepCount;

    /** The corvet timeout. */
    @Configuration("daemon.clients.corvet.timeout")
    private int corvetTimeout;

    /** The newton out dir. */
    @Configuration("daemon.providers.newton.outputDirectory")
    private String newtonOutDir;

    /** The process interval. */
    @Configuration("daemon.providers.newton.processInterval")
    private long processInterval;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The newton jpa repository. */
    @Inject
    private NewtonRepository newtonJpaRepository;

    /** The request batch repository. */
    @Inject
    private RequestBatchRepository requestBatchRepository;

    /** The request repository. */
    @Inject
    private RequestRepository requestRepository;

    /** The step repository. */
    @Inject
    private StepRepository stepRepository;

    /** The engine daemon service. */
    @Inject
    private EngineDaemonService engineDaemonService;

    /** The engine calculator service. */
    @Inject
    private EngineCalculatorService engineCalculatorService;

    /** The fork join pool. */
    private ForkJoinPool forkJoinPool;

    /** The bcv res mac name. */
    @Configuration("daemon.bcvResMacName")
    private static String bcvResMacName;

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The Constant CLASS_NAME. */
    private static final String CLASS_NAME = "RequestLifecycleServiceImpl";

    /** The simulation xlsx is active. */
    @Configuration("daemon.simulationXlsxIsActive")
    private boolean simulationXlsxIsActive;// fixed jira-582

    /** The daemon file config util service. */
    @Inject
    private DaemonFileConfigUtilService daemonFileConfigUtilService;

    /** The cal map. */
    // jira-755 fix
    private Map<String, Calculation> calMap = new ConcurrentHashMap<>();

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.RequestLifecycleService#run()
     */
    @Override
    public void run() {
        Thread.currentThread().setName("request-lifecycle");
        logger.info("Lifecycle service started");
        Instant newtonInterval = Instant.now().minus(processInterval + 1, ChronoUnit.SECONDS);
        forkJoinPool = new ForkJoinPool();
        while (!EngineDaemonCommandLineHandler.isSigintRequested()) {
            long start = System.currentTimeMillis();
            logger.debug("Lifecycle service loop started");
            try {
                this.timedOutBatch().ifPresent(batches -> batches.stream().forEach(this::error));

                if (newtonInterval.until(Instant.now(), ChronoUnit.SECONDS) > processInterval) {
                    batchJobEntry.runJob(PROVIDER_REQ_JOB_NAM, newtonOutDir, "");
                    newtonInterval = Instant.now();
                }
                // fixed jira-582
                if (simulationXlsxIsActive) {
                    this.steps().ifPresent(this::processSteps);
                    logger.debug("Requests handled");
                    this.completedBatch().ifPresent(batches -> batches.stream().forEach(this::answer));
                }

                logger.debug("Completed batches handled");

                engineDaemonService.getProviderWriter("newton").ifPresent(fw -> fw.publish(null));

                logger.debug("Newton requests published");

            } catch (RuntimeException e) {
                logger.error("Engine daemon request lifecycle service error caused by", e);
            }

            long end = System.currentTimeMillis();
            long delta = end - start;
            try {
                TimeUnit.MILLISECONDS.sleep(Math.max(refreshInterval - delta, 0));
            } catch (InterruptedException e) {
                logger.error("Engine daemon request lifecycle service interrupted !", e);
                Thread.currentThread().interrupt();
            }
            logger.debug("Lifecycle service loop ended");
        }
        forkJoinPool.shutdown();
        logger.info("Lifecycle service stopped");

    }

    /**
     * Delete fs flag file.
     *
     * @param clientName the client name
     */
    private void deleteFsFlagFile(String clientName) {
        if (daemonFileConfigUtilService != null) {
            String fsFlagPath = daemonFileConfigUtilService.getFsFlagPath();
            File dir = new File(fsFlagPath);
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                Arrays.sort(dirContents, Comparator.comparingLong(File::lastModified));
                for (File file : dirContents) {
                    try {
                        if (file.getName().contains(clientName)) {
                            FileUtils.forceDelete(file);
                            logger.info("Fs Flag File [{}] has been deleted from the location {}", file.getName(), fsFlagPath);
                            break;
                        }
                    } catch (IOException e) {
                        logger.error("Exception while deleting the file : {}", e);
                    }
                }
            }
        }
    }

    /**
     * Process steps.
     *
     * @param steps the steps
     */
    private void processSteps(List<Request> steps) {
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(CLASS_NAME);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        try {
            List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
            steps.forEach(request -> {
                Future<Integer> future = executorService.submit(() -> {

                    Request requestNew = process(request);
                    requestRepository.save(requestNew);

                    return 1;
                });
                futuresList.add(future);
            });

            for (Future<Integer> future : futuresList) {
                future.get();
            }
        } catch (Exception e) {
            logger.error("error when executing step processing", e);
        } finally {
            deleteFsFlagFile("manual");
            executorService.shutdown();
        }
    }

    /**
     * Prepare the answer of the provided request batch with the according {@link FileWriter}.
     *
     * @param requestBatch the request batch to be answered
     */
    private void answer(RequestBatch requestBatch) {
        // Check if the provided requestBatch is really completed ?
        this.engineDaemonService.getClientWriters().stream().filter(writer -> writer.name().equalsIgnoreCase(requestBatch.clientName())).findFirst()
                .ifPresent(writer -> writer.publish(requestBatch));
    }

    /**
     * Pass all associated {@link Request}s to an error state.
     *
     * @param requestBatch the request batch
     */
    private void error(RequestBatch requestBatch) {
        // Fetch the corresponding Requests with this RequestBatch guid and for every one that are not in a completed status
        requestRepository.byRequestBatchId(requestBatch.getGuid(), RequestStatus.timeoutables()).ifPresent(rl -> {
            try {
                forkJoinPool.submit(() -> rl.stream().parallel().map(this::writeError).forEach(requestRepository::save)).get();
            } catch (Exception e) {
                logger.error("error when executing error processing", e);
            }
        });
    }

    /**
     * Write error.
     *
     * @param request the request
     * @return the request
     */
    private Request writeError(Request request) {
        logger.debug("writeError() :[IN]");
        request.useAnswer(LocalDateTime.now(), NewtonAnswerErrorCode.TIMEOUT.getRuleCode(), NewtonAnswerErrorCode.TIMEOUT.getDescription());
        LogErrorUtility.logTheError(logger, request.getRequestId(), NewtonAnswerErrorCode.TIMEOUT.getRuleCode(),
                NewtonAnswerErrorCode.TIMEOUT.getDescription());
        stepRepository.persist(request.toErrorStatus(RequestStatus.REQUEST_REJECTED));
        logger.debug("REQUEST_ID[{}] : Wltp Is Timed Out And Request Is Rejected !", request.getRequestId());
        logger.debug("writeError() :[OUT]");
        return request;
    }

    /**
     * Returns an {@link Optional} list of {@link RequestBatch}s that are in timeout.
     *
     * @return the optional list of request batches
     */
    private Optional<List<RequestBatch>> timedOutBatch() {
        // Retrieve RequestBatches that are in Recieved status and requestDate over the timeout limit and only that
        Optional<List<RequestBatch>> timedOutRequestBatchList = Optional.empty();
        int timeout = 0;
        try {
            if (corvetTimeout > 0) {
                timeout = corvetTimeout;
                logger.debug("Corvet TimeOut is set as [{}]", timeout);
            } else if (daemonFileConfigUtilService.getCompToolTimeOut() > 0) {
                timeout = daemonFileConfigUtilService.getCompToolTimeOut();
                logger.debug("CompTool TimeOut is set as [{}]", timeout);
            } else {
                timeout = 3600;
                logger.debug("Default TimeOut is set as [{}]", timeout);
            }
            timedOutRequestBatchList = requestBatchRepository.getTimeOutRequestBatches(timeout, daemonFileConfigUtilService.getReqMacName());
        } catch (Exception e) {
            logger.error("Error while fetching timeOut batches", e);
        }
        return timedOutRequestBatchList;
    }

    /**
     * Returns an {@link Optional} list of {@link RequestBatch}s that have all their {@link Request} in a completed state (either success or error).
     *
     * @return the optional list of request batches
     */
    private Optional<List<RequestBatch>> completedBatch() {

        Optional<List<RequestBatch>> completeRequestBatchList = Optional.empty();
        try {
            completeRequestBatchList = requestBatchRepository.getCompletedRequestBatches();
        } catch (Exception e) {
            logger.error("Error while fetching Completed Request Batches", e);
        }
        return completeRequestBatchList;
    }

    /**
     * Steps.
     *
     * @return the optional
     */
    private Optional<List<Request>> steps() {
        // Change for CFT- HA
        return requestRepository.getSteps(stepCount, DaemonConfig.getReqMachine());
    }

    /**
     * Process the provided request.
     *
     * @param request the request
     * @return the request
     */
    @SuppressWarnings("unused")
    private Request process(Request request) {

        StopWatch sw = new StopWatch();
        sw.start();

        Optional<NewtonEntity> newtonEntity = newtonJpaRepository.getLatestNewtonEntity(request);
        if (newtonEntity.isPresent()) {
            if (newtonEntity.get().getStatus().equals(RequestStatus.NEWTON_OK) && request.getStatus().equals(RequestStatus.REQUEST_SENT)) {
                stepRepository.persist(request.nextStep());
            }
            if (newtonEntity.get().getStatus().equals(RequestStatus.NEWTON_KO) && request.getStatus().equals(RequestStatus.REQUEST_SENT)) {
                stepRepository.persist(request.toErrorStatus(RequestStatus.NEWTON_KO));
            }
        }
        String requestNo = request.getFileId() + "-" + request.getRequestId();
        switch (request.getStatus()) {
        case REQUEST_TO_SEND:
            logger.debug("Request ID[{}]: To send to NEWTON", requestNo);
            engineDaemonService.getProviderWriter("newton").ifPresent(fw -> fw.serialize(request));
            stepRepository.persist(request.nextStep());
            break;
        case NEWTON_OK:
            logger.debug("Request ID[{}]: To be calculated", requestNo);
            try {
                List<EnginePhysicalQuantity> enginePhysicalQuantities = getNewtonPhysicalQuantity(
                        newtonJpaRepository.getNewtonEntity(request).orElse(null), true);
                if (enginePhysicalQuantities != null && !enginePhysicalQuantities.isEmpty()) {
                    request.updatePhysicalQuantities(enginePhysicalQuantities);
                    // Calculation calculation = engineCalculatorService.calculate(request);//As part of jira-755 fix commented this line
                    Calculation calculation = engineCalculatorService.calculate(request);
                    // jira-755 fix
                    calMap.put(request.getRequestId(), calculation);
                    request.update(calculation.getCalculatedData());
                    stepRepository.persist(request.nextStep());
                }

            } catch (SeedException se) {
                // JIRA-445 Fix Starts Here
                if (se.getErrorCode() instanceof WltpErrorCode) {
                    WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                    WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                    request.useAnswer(LocalDateTime.now(), String.format("ERRW%s", ec.getRuleCode()), ec.getDescription());
                }
                // JIRA-445 Fix Ends Here
                stepRepository.persist(request.toErrorStatus(RequestStatus.CALCULATION_KO));
            } catch (RuntimeException e) {
                LogErrorUtility.logTheError(logger, requestNo, "ERRW400", "Illegal calculation state error, check engine logs");
                request.useAnswer(LocalDateTime.now(), "ERRW400", "Illegal calculation state error, check engine logs");
                stepRepository.persist(request.toErrorStatus(RequestStatus.CALCULATION_KO));
            }
            break;
        case REQUEST_REJECTED:
        case NEWTON_KO:
        case CALCULATION_KO:
        case CALCULATION_OK:
            if (!request.getStatus().equals(RequestStatus.REQUEST_REJECTED)) {
                if (request.getStatus().equals(RequestStatus.CALCULATION_OK)) {
                    request.useAnswer(LocalDateTime.now(), NewtonAnswerErrorCode.CALCULATION_SUCCESS.getRuleCode(),
                            NewtonAnswerErrorCode.CALCULATION_SUCCESS.getDescription());
                }
                newtonJpaRepository.getNewtonEntity(request).ifPresent(n -> {
                    if (request.getStatus().equals(RequestStatus.NEWTON_KO))
                        request.useAnswer(LocalDateTime.now(), n.getAnswerCode(), n.getAnswerDesignation());
                    request.updatePhysicalQuantities(getNewtonPhysicalQuantity(n, false));
                    Map<String, Double> phyQuantityMap = new HashMap<>();
                    request.getPhysicalQuantities().forEach(phyQuantity -> phyQuantityMap.put(phyQuantity.getCode(), phyQuantity.getValue()));
                    if (!calMap.isEmpty() && calMap.containsKey(request.getRequestId())) {
                        Calculation calObj = calMap.get(request.getRequestId());
                        if (calObj != null && CollectionUtils.isNotEmpty(calObj.getPhysicalQuantities())) {
                            calObj.getPhysicalQuantities()
                                    .forEach(calPhyQuantity -> phyQuantityMap.put(calPhyQuantity.getCode(), calPhyQuantity.getValue()));
                            calMap.remove(request.getRequestId());
                        }
                        List<EnginePhysicalQuantity> uniquePhyQuantities = new ArrayList<>();
                        phyQuantityMap.keySet().forEach(code -> uniquePhyQuantities.add(new EnginePhysicalQuantity(code, phyQuantityMap.get(code))));
                        request.updatePhysicalQuantities(uniquePhyQuantities);
                    }

                });
            }
            logger.debug("Request ID[{}]: Completed, serializing", requestNo);
            logger.debug("Request ID[{}]: Size of Writer {}", requestNo, engineDaemonService.getClientWriters().size());
            String clientName = requestBatchRepository.clientName(request.getRequestBatchId());

            engineDaemonService.getClientWriters().stream().filter(writer -> writer.name().equalsIgnoreCase(clientName)).findFirst()
                    .ifPresent(fw -> fw.serialize(request));
            stepRepository.persist(request.nextStep());
            break;
        case REQUEST_RECEIVED:
        case VALID_REQUEST:
        case REQUEST_SENT:
        case ANSWER_SENT:
            logger.debug("Request ID[{}]: Nothing to do", requestNo);
            break;
        }

        sw.stop();

        logger.debug("StopWatch - Request Lifecycle (Request ID:{}, Status:{}) - Process took {}ms", requestNo, request.getStatus(), sw.getTime());

        return request;

    }

    /**
     * Gets the newton physical quantity.
     *
     * @param newtonEntity the newton entity
     * @param forCalculation the for calculation
     * @return the newton physical quantity
     */
    private List<EnginePhysicalQuantity> getNewtonPhysicalQuantity(NewtonEntity newtonEntity, boolean forCalculation) {
        List<EnginePhysicalQuantity> enginePhysicalQuantityList = new ArrayList<>();

        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.MASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleMass())));
        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.SCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleSCx())));
        enginePhysicalQuantityList
                .add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, getPrimitiveTypeForNULL(newtonEntity.getVehicleCRR())));
        if (!forCalculation) {
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.UMASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getUnladenMass())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.EMASS_CODE, getPrimitiveTypeForNULL(newtonEntity.getEquipmentMass())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.ESCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getEquipmentSCx())));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.USCX_CODE, getPrimitiveTypeForNULL(newtonEntity.getUnladenSCx())));
        }
        return enginePhysicalQuantityList;
    }

    /**
     * Gets the primitive type for null.
     *
     * @param value the value
     * @return the primitive type for null
     */
    private double getPrimitiveTypeForNULL(Double value) {
        if (value == null)
            return 0.0;
        return value.doubleValue();
    }
}
