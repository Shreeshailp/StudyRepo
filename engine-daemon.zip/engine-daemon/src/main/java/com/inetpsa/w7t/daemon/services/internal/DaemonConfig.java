/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.seedstack.coffig.Config;

/**
 * The Class DaemonConfig.
 */
@Config("daemon")
public class DaemonConfig {

    /** The file listener refresh interval. */
    private int fileListenerRefreshInterval;

    /** The lifecycle refresh interval. */
    private int lifecycleRefreshInterval;

    /** The lifecycle step count. */
    private int lifecycleStepCount;

    /** The temp directory. */
    private File tempDirectory;

    /** The bcv res mac name. */
    private String bcvResMacName;

    /** The req mac name. */
    private String reqMacName;

    /** The bcv res machine. */
    private static String bcvResMachine = "";

    /** The req machine. */
    private static String reqMachine = "";

    /** The indus fs flag path. */
    private String indusFsFlagPath;

    /**
     * Gets the indus fs flag path.
     *
     * @return the indus fs flag path
     */
    public String getIndusFsFlagPath() {
        return indusFsFlagPath;
    }

    /**
     * Sets the indus fs flag path.
     *
     * @param indusFsFlagPath the new indus fs flag path
     */
    public void setIndusFsFlagPath(String indusFsFlagPath) {
        this.indusFsFlagPath = indusFsFlagPath;
    }

    /** The clients. */
    private Map<String, DaemonClientConfig> clients = new HashMap<>();

    /** The providers. */
    private Map<String, DaemonProviderConfig> providers = new HashMap<>();

    /**
     * Sets the bcv res machine.
     *
     * @param bcvResMacName the new bcv res machine
     */
    public static void setBcvResMachine(String bcvResMacName) {
        bcvResMachine = bcvResMacName;

    }

    /**
     * Sets the req machine.
     *
     * @param reqMacName the new req machine
     */
    public static void setReqMachine(String reqMacName) {
        reqMachine = reqMacName;
    }

    /**
     * Sets the bcv res mac name.
     *
     * @param bcvResMacName the new bcv res mac name
     */
    public void setBcvResMacName(String bcvResMacName) {
        DaemonConfig.setBcvResMachine(bcvResMacName);
    }

    /**
     * Sets the req mac name.
     *
     * @param reqMacName the new req mac name
     */
    public void setReqMacName(String reqMacName) {
        DaemonConfig.setReqMachine(reqMacName);
    }

    /**
     * Gets the bcv res machine.
     *
     * @return the bcv res machine
     */
    public static String getBcvResMachine() {
        return bcvResMachine;
    }

    /**
     * Gets the req machine.
     *
     * @return the req machine
     */
    public static String getReqMachine() {
        return reqMachine;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DaemonConfig [fileListenerRefreshInterval=" + fileListenerRefreshInterval + ", lifecycleRefreshInterval=" + lifecycleRefreshInterval
                + ", lifecycleStepCount=" + lifecycleStepCount + ", tempDirectory=" + tempDirectory + ", clients=" + clients + ", providers="
                + providers + ", reqMacName=" + reqMacName + ", bcvResMacName=" + bcvResMacName + "]";
    }

    /**
     * Gets the file listener refresh interval.
     *
     * @return the file listener refresh interval
     */
    public int getFileListenerRefreshInterval() {
        return fileListenerRefreshInterval;
    }

    /**
     * Sets the file listener refresh interval.
     *
     * @param fileListenerRefreshInterval the new file listener refresh interval
     */
    public void setFileListenerRefreshInterval(int fileListenerRefreshInterval) {
        this.fileListenerRefreshInterval = fileListenerRefreshInterval;
    }

    /**
     * Gets the lifecycle refresh interval.
     *
     * @return the lifecycle refresh interval
     */
    public int getLifecycleRefreshInterval() {
        return lifecycleRefreshInterval;
    }

    /**
     * Sets the lifecycle refresh interval.
     *
     * @param lifecycleRefreshInterval the new lifecycle refresh interval
     */
    public void setLifecycleRefreshInterval(int lifecycleRefreshInterval) {
        this.lifecycleRefreshInterval = lifecycleRefreshInterval;
    }

    /**
     * Gets the lifecycle step count.
     *
     * @return the lifecycle step count
     */
    public int getLifecycleStepCount() {
        return lifecycleStepCount;
    }

    /**
     * Sets the lifecycle step count.
     *
     * @param lifecycleStepCount the new lifecycle step count
     */
    public void setLifecycleStepCount(int lifecycleStepCount) {
        this.lifecycleStepCount = lifecycleStepCount;
    }

    /**
     * Gets the temp directory.
     *
     * @return the temp directory
     */
    public File getTempDirectory() {
        return tempDirectory;
    }

    /**
     * Sets the temp directory.
     *
     * @param tempDirectory the new temp directory
     */
    public void setTempDirectory(File tempDirectory) {
        this.tempDirectory = tempDirectory;
    }

    /**
     * Gets the clients.
     *
     * @return the clients
     */
    public Map<String, DaemonClientConfig> getClients() {
        return clients;
    }

    /**
     * Sets the clients.
     *
     * @param clients the clients
     */
    public void setClients(Map<String, DaemonClientConfig> clients) {
        this.clients = clients;
    }

    /**
     * Gets the providers.
     *
     * @return the providers
     */
    public Map<String, DaemonProviderConfig> getProviders() {
        return providers;
    }

    /**
     * Sets the providers.
     *
     * @param providers the providers
     */
    public void setProviders(Map<String, DaemonProviderConfig> providers) {
        this.providers = providers;
    }

    /**
     * Gets the req mac name.
     *
     * @return the req mac name
     */
    public String getReqMacName() {
        return reqMacName;
    }

    /**
     * Gets the bcv res mac name.
     *
     * @return the bcv res mac name
     */
    public String getBcvResMacName() {
        return bcvResMacName;
    }

    /**
     * The Class DaemonClientConfig.
     */
    public static class DaemonClientConfig {

        /** The input directory. */
        private File inputDirectory;

        /** The output directory. */
        private File outputDirectory;

        /** The filename pattern. */
        private String filenamePattern;

        /** The timeout. */
        private int timeout;

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "DaemonClientConfig [inputDirectory=" + inputDirectory + ", outputDirectory=" + outputDirectory + ", filenamePattern="
                    + filenamePattern + ", timeout=" + timeout + "]";
        }

        /**
         * Gets the input directory.
         *
         * @return the input directory
         */
        public File getInputDirectory() {
            return inputDirectory;
        }

        /**
         * Sets the input directory.
         *
         * @param inputDirectory the new input directory
         */
        public void setInputDirectory(File inputDirectory) {
            this.inputDirectory = inputDirectory;
        }

        /**
         * Gets the output directory.
         *
         * @return the output directory
         */
        public File getOutputDirectory() {
            return outputDirectory;
        }

        /**
         * Sets the output directory.
         *
         * @param outputDirectory the new output directory
         */
        public void setOutputDirectory(File outputDirectory) {
            this.outputDirectory = outputDirectory;
        }

        /**
         * Gets the filename pattern.
         *
         * @return the filename pattern
         */
        public String getFilenamePattern() {
            return filenamePattern;
        }

        /**
         * Sets the filename pattern.
         *
         * @param filenamePattern the new filename pattern
         */
        public void setFilenamePattern(String filenamePattern) {
            this.filenamePattern = filenamePattern;
        }

        /**
         * Gets the timeout.
         *
         * @return the timeout
         */
        public int getTimeout() {
            return timeout;
        }

        /**
         * Sets the timeout.
         *
         * @param timeout the new timeout
         */
        public void setTimeout(int timeout) {
            this.timeout = timeout;
        }
    }

    /**
     * The Class DaemonProviderConfig.
     */
    public static class DaemonProviderConfig {

        /** The output directory. */
        private File outputDirectory;

        /** The input directory. */
        private File inputDirectory;

        /** The process interval. */
        private int processInterval;

        /** The filename pattern. */
        private String filenamePattern;

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "DaemonProviderConfig [outputDirectory=" + outputDirectory + ", inputDirectory=" + inputDirectory + ", processInterval="
                    + processInterval + ", filenamePattern=" + filenamePattern + "]";
        }

        /**
         * Gets the output directory.
         *
         * @return the output directory
         */
        public File getOutputDirectory() {
            return outputDirectory;
        }

        /**
         * Sets the output directory.
         *
         * @param outputDirectory the new output directory
         */
        public void setOutputDirectory(File outputDirectory) {
            this.outputDirectory = outputDirectory;
        }

        /**
         * Gets the input directory.
         *
         * @return the input directory
         */
        public File getInputDirectory() {
            return inputDirectory;
        }

        /**
         * Sets the input directory.
         *
         * @param inputDirectory the new input directory
         */
        public void setInputDirectory(File inputDirectory) {
            this.inputDirectory = inputDirectory;
        }

        /**
         * Gets the process interval.
         *
         * @return the process interval
         */
        public int getProcessInterval() {
            return processInterval;
        }

        /**
         * Sets the process interval.
         *
         * @param processInterval the new process interval
         */
        public void setProcessInterval(int processInterval) {
            this.processInterval = processInterval;
        }

        /**
         * Gets the filename pattern.
         *
         * @return the filename pattern
         */
        public String getFilenamePattern() {
            return filenamePattern;
        }

        /**
         * Sets the filename pattern.
         *
         * @param filenamePattern the new filename pattern
         */
        public void setFilenamePattern(String filenamePattern) {
            this.filenamePattern = filenamePattern;
        }

    }
}
