/*
 * Creation : 11 mai 2017
 */
package com.inetpsa.w7t.provider.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;

/**
 * The Class NewtonRequestTasklet.
 */
public class NewtonRequestTasklet implements Tasklet {

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(NewtonRequestTasklet.class);

    /** The Constant POLL_REQ_TABLE. */
    private static final String POLL_REQ_TABLE = "select count(*) from W7TQTRQB B where B.status = 'C' and B.REQ_MAC_NAME=? and exists (select 1 from W7TQTREQ R where R.BATCH_ID = B.ID AND R.status IN ('20','25')) ";

    /** The Constant CORVET_REQS. */
    private static final String CORVET_REQS = "INSERT INTO W7TQTNEW (FILE_ID, EXTENDED_TITLE, STATUS, REQ_DATE, REQ_ID) "
            + " select distinct r.INTERNAL_FILE_ID, r.extended_title,'30',r.REQUEST_DATE, r.REQUEST_ID from W7TQTREQ as r, W7TQTRQB as b where r.file_id = b.file_id "
            + " and b.manual=0 " + " and b.status='C' and b.REQ_MAC_NAME=? and r.status IN('20','25') ";// Hub Lot2 changes included for the status
                                                                                                        // 20,25

    /** The Constant UPDATE_STATUS. */
    private static final String UPDATE_STATUS = "UPDATE  W7TQTREQ set status = '30' where status IN ('20','25') "
            + " and INTERNAL_FILE_ID in (select file_id from W7TQTNEW where status = '30') ";// Hub Lot2 changes included for the status 20,25

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution,
     *      org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        Integer count = jdbcTemplate.queryForObject(POLL_REQ_TABLE, new Object[] { DaemonConfig.getReqMachine() }, Integer.class);
        if (count > 0) {
            int updated = jdbcTemplate.update(CORVET_REQS, new Object[] { DaemonConfig.getReqMachine() });
            if (updated > 0)
                logger.info("Newton requests are created");
            jdbcTemplate.execute(UPDATE_STATUS);
            logger.info("Corvet requests are updated");
        }
        return RepeatStatus.FINISHED;
    }

}
