/*
 * Creation : 8 Sep 2019
 */
package com.inetpsa.w7t.daemon.services.internal;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.model.ClientRequest;
import com.inetpsa.w7t.daemon.services.MaturityCheckBeanService;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * The Class MaturityCheckBeanServiceImpl.
 */
public class MaturityCheckBeanServiceImpl implements MaturityCheckBeanService {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /** The Constant CLIENT. */
    private static final String CLIENT = "CORVET";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MaturityCheckBeanService#maturityCheckForCorvet(com.inetpsa.w7t.batch.model.ClientRequest)
     */
    @Override
    public void maturityCheckForCorvet(ClientRequest request) {

        String statusMatched = MaturityCheckUtility.determineMaturityCheckForCorvet(request.getRequestNumber(), request.getRequestType(),
                request.getExtendedTitle(), maturityRepository, clientMaturityRepository, logger, CLIENT);
        if (statusMatched != null) {
            request.setMaturity(statusMatched);
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MaturityCheckBeanService#maturityCheckForCorvetAndCompTool(com.inetpsa.w7t.batch.model.ClientRequest,
     *      java.lang.String)
     */
    @Override
    public void maturityCheckForCorvetAndCompTool(ClientRequest request, String client) {
        String statusMatched = MaturityCheckUtility.determineMaturityCheckForCorvet(request.getRequestNumber(), request.getRequestType(),
                request.getExtendedTitle(), maturityRepository, clientMaturityRepository, logger, client);
        if (statusMatched != null) {
            request.setMaturity(statusMatched);
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MaturityCheckBeanService#clearSession()
     */
    @Override
    public void clearSession() {
        maturityRepository.clearSession();
    }

}
