package com.inetpsa.w7t.batch.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.inetpsa.w7t.batch.LocalDateAdapter;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;

/**
 * The Class ClientRequest.
 */
@XmlRootElement(name = "request")
public class ClientRequest {

    /** The file id. */
    @Pattern(regexp = "\\w{3}\\d{1,10}", message = "FILE_ID_INCORRECT")
    @Size(min = 4, max = 13, message = "FILE_ID_INCORRECT")
    private String fileId;

    /** The request number. */
    @Pattern(regexp = "\\w{3}\\d{1,17}", message = "REQUEST_NUMBER_INCORRECT")
    @Size(min = 4, max = 20, message = "REQUEST_NUMBER_INCORRECT")
    private String requestNumber;

    /** The request type. */
    private String requestType;

    /** The ecom date. */
    private LocalDate ecomDate;

    /** The extended title. */
    @Size(min = 1, max = 3524, message = "EXTENDED_TITLE_INCORRECT")
    @Pattern(regexp = ".{24}(?:.{7})*", message = "EXTENDED_TITLE_INCORRECT")
    private String extendedTitle;

    /** The vin. */
    @Size(min = 17, max = 17, message = "VIN_INCORRECT")
    private String vin;

    /** The batchid. */
    private String batchid;

    /** The status. */
    private RequestStatus status;

    /** The answer code. */
    private String answerCode;

    /** The answer designation. */
    private String answerDesignation;

    /** The tvv designation. */
    private String tvvDesignation;

    private String internalFileId;

    private String maturity;

    private String country;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * Gets the request number.
     *
     * @return the request number
     */
    @XmlAttribute(name = "number")
    public String getRequestNumber() {
        return requestNumber;
    }

    /**
     * Sets the request number.
     *
     * @param requestNumber the new request number
     */
    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    @XmlAttribute(name = "type")
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    @XmlElement(name = "vin")
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    @XmlElement(name = "ecom_date")
    @XmlJavaTypeAdapter(type = LocalDate.class, value = LocalDateAdapter.class)
    public LocalDate getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(LocalDate ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    @XmlElement(name = "extended_title")
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    /**
     * Gets the batchid.
     *
     * @return the batchid
     */
    public String getBatchid() {
        return batchid;
    }

    /**
     * Sets the batchid.
     *
     * @param batchid the new batchid
     */
    public void setBatchid(String batchid) {
        this.batchid = batchid;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    @XmlElement(name = "tvv")
    public String getTvvDesignation() {
        return tvvDesignation;
    }

    /**
     * Sets the tvv designation.
     *
     * @param tvvDesignation the new tvv designation
     */
    public void setTvvDesignation(String tvvDesignation) {
        this.tvvDesignation = tvvDesignation;
    }

    public String getInternalFileId() {
        return internalFileId;
    }

    public void setInternalFileId(String internalFileId) {
        this.internalFileId = internalFileId;
    }

    public List<String> validate() {
        Set<ConstraintViolation<ClientRequest>> violations = Validation.buildDefaultValidatorFactory().getValidator().validate(this);
        return violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return "ClientRequest [fileId=" + fileId + ", requestNumber=" + requestNumber + ", requestType=" + requestType + ", ecomDate=" + ecomDate
                + ", extendedTitle=" + extendedTitle + ", vin=" + vin + ", batchid=" + batchid + ", status=" + status + ", answerCode=" + answerCode
                + ", answerDesignation=" + answerDesignation + ", tvvDesignation=" + tvvDesignation + ", internalFileId=" + internalFileId
                + ", maturity=" + maturity + "]";
    }

}
