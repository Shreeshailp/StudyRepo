/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.time.LocalDateTime;

import javax.cache.annotation.CacheKey;
import javax.cache.annotation.CacheRemoveAll;
import javax.cache.annotation.CacheResult;
import javax.inject.Named;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonProviderConfig;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.jpa.NewtonEntity;
import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;

@Named("provider")
public class ProviderFileWriter extends DefaultFileWriter {

    public ProviderFileWriter() {
        super();
    }

    public ProviderFileWriter(String name, DaemonProviderConfig config) {
        super(name, config.getOutputDirectory(), config.getFilenamePattern());
    }

    @Override
    public void serialize(Request request) {

        // TODO Serialize one request into a file in the temporary directory
    }

    @Override
    @CacheRemoveAll(cacheName = "newtonIndividualVehicle")
    public void publish(RequestBatch requestBatch) {
        // TODO handle the temporary file in the temporary directory and move it to the publish directory
    }

    @CacheResult(cacheName = "newtonIndividualVehicle")
    private NewtonEntity createIndVehicle(@CacheKey LocalDateTime requestDate, @CacheKey String extendedTitle, Request request) {

        // create entity

        // write in file here

        return null;
    }
}
