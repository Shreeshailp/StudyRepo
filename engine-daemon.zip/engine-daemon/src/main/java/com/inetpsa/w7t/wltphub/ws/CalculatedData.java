/*
 * Creation : 23 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class CalculatedData {

    private List<CalculatedPhase> calculatedPhases;

    public CalculatedData() {
        // Nothing to initialise
    }

    public Optional<List<CalculatedPhase>> getCalculatedPhases() {
        if (calculatedPhases == null)
            return Optional.empty();
        return Optional.ofNullable(Collections.unmodifiableList(calculatedPhases));
    }

    public void setCalculatedPhases(List<CalculatedPhase> calculatedPhases) {
        this.calculatedPhases = calculatedPhases;
    }

}
