/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.domain.GenericFactory;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonProviderConfig;

/**
 * A factory for creating FileWriter objects.
 */
public interface FileWriterFactory extends GenericFactory<FileWriter> {

    /**
     * Creates a new FileWriter object.
     *
     * @param name the name
     * @param config the config
     * @return the file writer
     */
    FileWriter createClientFileWriter(String name, DaemonClientConfig config);

    /**
     * Creates a new FileWriter object.
     *
     * @param name the name
     * @param config the config
     * @return the file writer
     */
    FileWriter createProviderFileWriter(String name, DaemonProviderConfig config);

}
