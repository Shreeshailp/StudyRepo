/*
 * Creation : 17 Jan 2020
 */
package com.inetpsa.w7t.provider.batch;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class CorvetAnswerFileResource.
 */
public class CorvetAnswerFileResource extends FileSystemResource {

    /**
     * Instantiates a new corvet answer file resource.
     *
     * @param path the path
     */
    public CorvetAnswerFileResource(String path) {
        super(path);
    }

}
