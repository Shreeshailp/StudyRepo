/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Singleton;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.daemon.services.EngineDaemonService;
import com.inetpsa.w7t.daemon.services.FileListener;
import com.inetpsa.w7t.daemon.services.FileListenerFactory;
import com.inetpsa.w7t.daemon.services.FileWriter;
import com.inetpsa.w7t.daemon.services.FileWriterFactory;
import com.inetpsa.w7t.daemon.services.RequestLifecycleService;

/**
 * The Class EngineDaemonServiceImpl. This is the implementation of {@link EngineDaemonService} and act as a singleton throughout the daemon's life.
 */
@Singleton
public class EngineDaemonServiceImpl implements EngineDaemonService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The daemon config. */
    @Configuration
    private DaemonConfig daemonConfig;

    /** The request lifecycle service. */
    @Inject
    private RequestLifecycleService requestLifecycleService;

    /** The file listener factory. */
    @Inject
    private FileListenerFactory fileListenerFactory;

    /** The file writer factory. */
    @Inject
    private FileWriterFactory fileWriterFactory;

    /** The client listeners. */
    private List<FileListener> clientListeners = new ArrayList<>();

    /** The client writers. */
    private List<FileWriter> clientWriters = new ArrayList<>();

    /** The client futures. */
    private List<CompletableFuture<Void>> clientFutures = new ArrayList<>();

    /** The provider listeners. */
    private List<FileListener> providerListeners = new ArrayList<>();

    /** The provider writers. */
    private List<FileWriter> providerWriters = new ArrayList<>();

    /** The provider futures. */
    private List<CompletableFuture<Void>> providerFutures = new ArrayList<>();

    /** The lifecycle future. */
    private CompletableFuture<Void> lifecycleFuture;

    /** The running. */
    private Boolean running = false;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#run()
     */
    @Override
    public void run() {
        logger.trace("Running engine daemon service");

        ExecutorService clientExecutor = Executors.newFixedThreadPool(daemonConfig.getClients().size());
        this.clientFutures = daemonConfig.getClients().entrySet().stream().map(entry -> {
            FileListener client = fileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.daemonConfig.getFileListenerRefreshInterval());
            this.clientListeners.add(client);
            this.clientWriters.add(fileWriterFactory.createClientFileWriter(entry.getKey(), entry.getValue()));
            return client;
        }).map(client -> CompletableFuture.runAsync(client::run, clientExecutor)).collect(Collectors.toList());

        ExecutorService providerExecutor = Executors.newFixedThreadPool(daemonConfig.getProviders().size());
        this.providerFutures = daemonConfig.getProviders().entrySet().stream().map(entry -> {
            FileListener provider = fileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.daemonConfig.getFileListenerRefreshInterval());
            this.providerListeners.add(provider);
            this.providerWriters.add(fileWriterFactory.createProviderFileWriter(entry.getKey(), entry.getValue()));
            return provider;
        }).map(provider -> CompletableFuture.runAsync(provider::run, providerExecutor)).collect(Collectors.toList());

        this.lifecycleFuture = CompletableFuture.runAsync(requestLifecycleService::run, Executors.newSingleThreadExecutor());

        this.running = true;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getRunningThreads()
     */
    @Override
    public Integer getRunningThreads() {
        return (int) Stream.concat(Stream.concat(this.clientFutures.stream(), this.providerFutures.stream()), Stream.of(this.lifecycleFuture))
                .filter(f -> !f.isDone()).count();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getTotalThreads()
     */
    @Override
    public Integer getTotalThreads() {
        return (int) Stream.concat(Stream.concat(this.clientFutures.stream(), this.providerFutures.stream()), Stream.of(this.lifecycleFuture))
                .count();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#isRunning()
     */
    @Override
    public Boolean isRunning() {
        return this.running;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getClientWriters()
     */
    @Override
    public List<FileWriter> getClientWriters() {
        return this.clientWriters;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getProviderWriters()
     */
    @Override
    public List<FileWriter> getProviderWriters() {
        return this.providerWriters;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getClientWriter(java.lang.String)
     */
    @Override
    public Optional<FileWriter> getClientWriter(String name) {
        return this.getClientWriters().stream().filter(writer -> writer.name().equalsIgnoreCase(name)).findFirst();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.EngineDaemonService#getProviderWriter(java.lang.String)
     */
    @Override
    public Optional<FileWriter> getProviderWriter(String name) {
        return this.getProviderWriters().stream().filter(fw -> Objects.equals(fw.name(), name)).findFirst();
    }
}
