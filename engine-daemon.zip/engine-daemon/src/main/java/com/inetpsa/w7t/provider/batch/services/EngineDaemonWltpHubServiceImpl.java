/*
 * Creation : 5 Feb 2021
 */
package com.inetpsa.w7t.provider.batch.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.Base64;
import java.util.Optional;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.seed.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.inetpsa.w7t.batch.model.ClientRequest;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.wltphub.ws.WSAnswer;
import com.inetpsa.w7t.wltphub.ws.WSPhysicalResult;
import com.inetpsa.w7t.wltphub.ws.WltpHubRequest;
import com.inetpsa.w7t.wltphub.ws.WltpHubRequestRepresentation;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class EngineDaemonWltpHubServiceImpl.
 */
public class EngineDaemonWltpHubServiceImpl implements EngineDaemonWltpHubService {

    /** The Constant TOO_MANY_REQUESTS. */
    private static final String TOO_MANY_REQUESTS = "429";

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The url. */
    @Configuration("wltphubWebService.url")
    private static String url;

    /** The username. */
    @Configuration("wltphubWebService.credentials.wltphub.username")
    private static String username;

    /** The code. */
    @Configuration("wltphubWebService.credentials.wltphub.password")
    private static String code;

    /** The timeout. */
    @Configuration("wltphubWebService.timeout")
    private static int timeout;

    /** The creds BASE 64. */
    private String credsBASE64;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.provider.batch.services.EngineDaemonWltpHubService#callWltpHubWebService(com.inetpsa.w7t.batch.model.ClientRequest)
     */
    @Override
    public WltpHubResponseRepresentation callWltpHubWebService(ClientRequest request) {
        WltpHubResponseRepresentation wltpHubResponseRepresentation = null;
        WltpHubRequest wltpHubRequest = null;

        if (this.credsBASE64 == null)
            credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());
        WltpHubRequestRepresentation wltpHubRequestRepresentation = new WltpHubRequestRepresentation();
        wltpHubRequest = new WltpHubRequest();

        wltpHubRequest.setRequestID(request.getRequestNumber());

        String extendedTitle = request.getExtendedTitle();
        wltpHubRequest.setVersion16C(extendedTitle.substring(0, 16));
        wltpHubRequest.setColorExtInt(extendedTitle.substring(16, 24));
        wltpHubRequest.setRequestType(request.getRequestType());
        // wltpHubRequest.setEcomDate(request.getEcomDate().toString());
        wltpHubRequest.setEcomDate("");
        wltpHubRequest.setTradingCountry(request.getCountry());
        wltpHubRequest.setNbOptions("");
        wltpHubRequest.setOptions5C("");
        wltpHubRequest.setOptions7C("");
        wltpHubRequest.setNbGestion("");
        wltpHubRequest.setGestion5C("");
        wltpHubRequest.setGestion7C("");
        String extendedTitleSentToHub = extendedTitle.substring(24, extendedTitle.length());
        wltpHubRequest.setExtendedTitleAttributes(extendedTitleSentToHub);// extendedTitle.substring(24)
        wltpHubRequest.setExtensionDate("");
        wltpHubRequest.setMountingCenter("");
        wltpHubRequest.setVin("");
        wltpHubRequest.setTvv("");
        wltpHubRequestRepresentation.setRequest(wltpHubRequest);

        try {
            HttpClient httpClient = HttpClientBuilder.create().build();
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
            logger.info("Request ID[{}]: Calling HUB WebService on URL - {}", wltpHubRequest.getRequestID(), url);
            logger.info("Request ID[{}]: Request Sent To WltpHub is:[{}]", wltpHubRequest.getRequestID(), wltpHubRequestRepresentation);
            HttpPost postRequest = new HttpPost(url);
            postRequest.setConfig(requestConfig);
            postRequest.addHeader("Content-Type", "application/json");
            postRequest.addHeader("Authorization", "Basic " + credsBASE64);
            postRequest.setEntity(new StringEntity(new Gson().toJson(wltpHubRequestRepresentation)));
            HttpResponse response = httpClient.execute(postRequest);
            if (response != null) {
                logger.info("WLTPHUB HTTP Response code :[{}] and Reason:[{}]", response.getStatusLine().getStatusCode(),
                        response.getStatusLine().getReasonPhrase());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
            String output;
            if (!String.valueOf(response.getStatusLine().getStatusCode()).equals(String.valueOf(HttpStatus.SC_OK))
                    && !String.valueOf(response.getStatusLine().getStatusCode()).equals(String.valueOf(HttpStatus.SC_BAD_REQUEST))
                    && !String.valueOf(response.getStatusLine().getStatusCode()).equals(TOO_MANY_REQUESTS)) {
                wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
                WSAnswer answer = new WSAnswer();
                answer.setCode(RequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getRuleCode());
                answer.setDesignation(RequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getDescription());
                wltpHubResponseRepresentation.setRequest(wltpHubRequest);
                wltpHubResponseRepresentation.setAnswer(answer);
            } else if (String.valueOf(response.getStatusLine().getStatusCode()).equals(TOO_MANY_REQUESTS)) {
                wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
                WSAnswer answer = new WSAnswer();
                answer.setCode(RequestErrorCode.TOO_MANY_REQUESTS.getRuleCode());
                answer.setDesignation(RequestErrorCode.TOO_MANY_REQUESTS.getDescription());
                wltpHubResponseRepresentation.setRequest(wltpHubRequest);
                wltpHubResponseRepresentation.setAnswer(answer);
            } else {
                StringBuilder answer = new StringBuilder();
                while ((output = br.readLine()) != null) {
                    answer.append(output);
                }
                wltpHubResponseRepresentation = new Gson().fromJson(answer.toString(), WltpHubResponseRepresentation.class);

                // Answer designation length issue fixed
                if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getAnswer()
                        && StringUtils.isNotBlank(wltpHubResponseRepresentation.getAnswer().getDesignation())
                        && wltpHubResponseRepresentation.getAnswer().getDesignation().length() > 50) {
                    wltpHubResponseRepresentation.getAnswer()
                            .setDesignation(wltpHubResponseRepresentation.getAnswer().getDesignation().substring(0, 50));
                }
            }
            logger.info("Request ID[{}]: Hub Web Service response : {}", wltpHubRequest.getRequestID(), wltpHubResponseRepresentation);
            if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getRequest()
                    && StringUtils.isNotBlank(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes())) {
                logger.info("Request ID[{}]: ExtendedTitle : {}", wltpHubRequest.getRequestID(),
                        wltpHubResponseRepresentation.getRequest().getVersion16C() + wltpHubResponseRepresentation.getRequest().getColorExtInt()
                                + wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
            }
            if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getPhysResult()) {
                Optional<WSPhysicalResult> optPhyResult = wltpHubResponseRepresentation.getPhysResult().parallelStream()
                        .filter(phyResult -> phyResult.getCode().equals(CalculationConstants.MATURITY)).findFirst();
                if (optPhyResult.isPresent()) {
                    logger.info("Request ID[{}]: Maturity : {}", wltpHubRequest.getRequestID(), optPhyResult.get().getValue());
                }

            }

        } catch (SocketTimeoutException e) {
            logger.error("Request ID[{}]: Error occurred in HUB web service is {}: {}", request.getRequestNumber(), e.getMessage(), e);
            LogErrorUtility.logTheError(logger, request.getRequestNumber(), RequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode(),
                    RequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription());
            wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
            WSAnswer answer = new WSAnswer();
            answer.setCode(RequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode());
            answer.setDesignation(RequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription());
            wltpHubResponseRepresentation.setRequest(wltpHubRequest);
            wltpHubResponseRepresentation.setAnswer(answer);
        } catch (Exception e) {
            logger.error("Request ID[{}]: Error occurred in HUB web service is {}: {}", request.getRequestNumber(), e.getMessage(), e);
            wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
            WSAnswer answer = new WSAnswer();
            answer.setCode(RequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getRuleCode());
            answer.setDesignation(RequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getDescription());
            wltpHubResponseRepresentation.setRequest(wltpHubRequest);
            wltpHubResponseRepresentation.setAnswer(answer);
        }

        return wltpHubResponseRepresentation;
    }

}
