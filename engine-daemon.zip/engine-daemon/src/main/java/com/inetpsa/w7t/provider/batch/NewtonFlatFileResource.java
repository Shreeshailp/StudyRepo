/*
 * Creation : 2 mai 2017
 */
package com.inetpsa.w7t.provider.batch;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class NewtonFlatFileResource.
 */
public class NewtonFlatFileResource extends FileSystemResource {

    /**
     * Instantiates a new newton flat file resource.
     *
     * @param path the path
     */
    public NewtonFlatFileResource(String path) {
        super(path);// JIRA-323 Fix
        // super(new StringBuilder(path).append(File.separator).append("newton_").append(new Date().getTime()).append(".dat").toString());
    }

}
