/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.domain.GenericFactory;

import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig.DaemonProviderConfig;

/**
 * A factory for creating FileListener objects.
 */
public interface FileListenerFactory extends GenericFactory<FileListener> {

    /**
     * Creates a new FileListener object.
     *
     * @param name the name
     * @param config the config
     * @param refreshInterval the refresh interval
     * @return the file listener
     */
    public FileListener createClientFileListener(String name, DaemonClientConfig config, Integer refreshInterval);

    /**
     * Creates a new FileListener object.
     *
     * @param name the name
     * @param config the config
     * @param refreshInterval the refresh interval
     * @return the file listener
     */
    public FileListener createProviderFileListener(String name, DaemonProviderConfig config, Integer refreshInterval);
}
