/*
 * Creation : 2 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

/**
 * The Class WSPhysicalResult.
 */
public class WSPhysicalResult {
    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Instantiates a new WS physical result.
     */
    public WSPhysicalResult() {
        // default
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "HubPhysicalResult [code=" + code + ", value=" + value + "]";
    }

}
