/*
 * Creation : 20 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import org.seedstack.business.Service;

/**
 * The Interface DictionaryParserService.
 */
@Service
public interface DictionaryParserService {

    /**
     * Parses the.
     *
     * @param fileLocation the file location
     */
    void parse(String fileLocation);

}
