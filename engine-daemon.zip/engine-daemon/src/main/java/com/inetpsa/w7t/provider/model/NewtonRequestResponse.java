/*
 * Creation : 11 avr. 2017
 */
package com.inetpsa.w7t.provider.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class NewtonRequestResponse.
 */
@Entity
@Table(name = "W7TQTNEW")
public class NewtonRequestResponse {

    /** The request no. */
    @Id
    @Column(name = "REQ_NO")
    private String requestNo;

    /** The file id. */
    @Column(name = "FILE_ID")
    private String fileId;

    /** The request date. */
    @Column(name = "REQ_DATE")
    private Date requestDate;

    /** The answer date. */
    @Column(name = "ANSWER_DATE")
    private Date answerDate;

    /** The answer code. */
    @Column(name = "ANSWER_CODE")
    private String answerCode;

    /** The answer designation. */
    @Column(name = "ANSWER_DESIG")
    private String answerDesignation;

    /** The unladen mass. */
    @Column(name = "UNLADEN_MASS")
    private Double unladenMass;

    /** The equipment mass. */
    @Column(name = "EQUIPMENT_MASS")
    private Double equipmentMass;

    /** The vehicle mass. */
    @Column(name = "VEHICLE_MASS")
    private Double vehicleMass;

    /** The unladen s cx. */
    @Column(name = "UNLADEN_SCX")
    private Double unladenSCx;

    /** The equipment s cx. */
    @Column(name = "EQUIPMENT_SCX")
    private Double equipmentSCx;

    /** The vehicle s cx. */
    @Column(name = "VEHICLE_SCX")
    private Double vehicleSCx;

    /** The vehicle crr. */
    @Column(name = "VEHICLE_CRR")
    private Double vehicleCRR;

    /** The extended title. */
    @Column(name = "EXTENDED_TITLE")
    private String extendedTitle;

    /** The status. */
    @Column(name = "STATUS")
    private String status;

    /** The isRequestSent. */
    @Column(name = "IS_REQUEST_SENT")
    private boolean isRequestSent;

    /** The req id. */
    @Column(name = "REQ_ID")
    private String reqId;

    /**
     * Gets the req id.
     *
     * @return the req id
     */
    public String getReqId() {
        return reqId;
    }

    /**
     * Sets the req id.
     *
     * @param reqId the new req id
     */
    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    /**
     * Checks if is request sent.
     *
     * @return true, if is request sent
     */
    public boolean isRequestSent() {
        return isRequestSent;
    }

    /**
     * Sets the request sent.
     *
     * @param isRequestSent the new request sent
     */
    public void setRequestSent(boolean isRequestSent) {
        this.isRequestSent = isRequestSent;
    }

    /**
     * Gets the request no.
     *
     * @return the request no
     */
    public String getRequestNo() {
        return requestNo;
    }

    /**
     * Sets the request no.
     *
     * @param requestNo the new request no
     */
    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public Date getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the answer date.
     *
     * @return the answer date
     */
    public Date getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the answer date.
     *
     * @param answerDate the new answer date
     */
    public void setAnswerDate(Date answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the unladen mass.
     *
     * @return the unladen mass
     */
    public Double getUnladenMass() {
        return unladenMass;
    }

    /**
     * Sets the unladen mass.
     *
     * @param unladenMass the new unladen mass
     */
    public void setUnladenMass(Double unladenMass) {
        this.unladenMass = unladenMass;
    }

    /**
     * Gets the equipment mass.
     *
     * @return the equipment mass
     */
    public Double getEquipmentMass() {
        return equipmentMass;
    }

    /**
     * Sets the equipment mass.
     *
     * @param equipmentMass the new equipment mass
     */
    public void setEquipmentMass(Double equipmentMass) {
        this.equipmentMass = equipmentMass;
    }

    /**
     * Gets the vehicle mass.
     *
     * @return the vehicle mass
     */
    public Double getVehicleMass() {
        return vehicleMass;
    }

    /**
     * Sets the vehicle mass.
     *
     * @param vehicleMass the new vehicle mass
     */
    public void setVehicleMass(Double vehicleMass) {
        this.vehicleMass = vehicleMass;
    }

    /**
     * Gets the unladen s cx.
     *
     * @return the unladen s cx
     */
    public Double getUnladenSCx() {
        return unladenSCx;
    }

    /**
     * Sets the unladen s cx.
     *
     * @param unladenSCx the new unladen s cx
     */
    public void setUnladenSCx(Double unladenSCx) {
        this.unladenSCx = unladenSCx;
    }

    /**
     * Gets the equipment s cx.
     *
     * @return the equipment s cx
     */
    public Double getEquipmentSCx() {
        return equipmentSCx;
    }

    /**
     * Sets the equipment s cx.
     *
     * @param equipmentSCx the new equipment s cx
     */
    public void setEquipmentSCx(Double equipmentSCx) {
        this.equipmentSCx = equipmentSCx;
    }

    /**
     * Gets the vehicle s cx.
     *
     * @return the vehicle s cx
     */
    public Double getVehicleSCx() {
        return vehicleSCx;
    }

    /**
     * Sets the vehicle s cx.
     *
     * @param vehicleSCx the new vehicle s cx
     */
    public void setVehicleSCx(Double vehicleSCx) {
        this.vehicleSCx = vehicleSCx;
    }

    /**
     * Gets the vehicle crr.
     *
     * @return the vehicle crr
     */
    public Double getVehicleCRR() {
        return vehicleCRR;
    }

    /**
     * Sets the vehicle crr.
     *
     * @param vehicleCRR the new vehicle crr
     */
    public void setVehicleCRR(Double vehicleCRR) {
        this.vehicleCRR = vehicleCRR;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param string the new status
     */
    public void setStatus(String string) {
        this.status = string;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NewtonRequestResponse [requestNo=" + requestNo + ", fileId=" + fileId + ", requestDate=" + requestDate + ", answerDate=" + answerDate
                + ", answerCode=" + answerCode + ", answerDesignation=" + answerDesignation + ", unladenMass=" + unladenMass + ", equipmentMass="
                + equipmentMass + ", vehicleMass=" + vehicleMass + ", unladenSCx=" + unladenSCx + ", equipmentSCx=" + equipmentSCx + ", vehicleSCx="
                + vehicleSCx + ", vehicleCRR=" + vehicleCRR + ", extendedTitle=" + extendedTitle + ", status=" + status + ", isRequestSent="
                + isRequestSent + ", reqId=" + reqId + "]";
    }

}
