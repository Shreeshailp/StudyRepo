/*
 * Creation : 13 Jan 2020
 */
package com.inetpsa.w7t.batch.util;

import org.seedstack.seed.Configuration;

/**
 * The Class DaemonFileConfigUtilServiceImpl.
 */
public class DaemonFileConfigUtilServiceImpl implements DaemonFileConfigUtilService {

    /** The indus flag path. */
    @Configuration("daemon.indusFsFlagPath")
    private String indusFlagPath;

    /** The fs flag path. */
    @Configuration("daemon.fsFlagPath")
    private String fsFlagPath;

    /** The file prefix. */
    @Configuration("daemon.filePrefix")
    private String filePrefix;

    /** The file suffix. */
    @Configuration("daemon.fileSuffix")
    private String fileSuffix;

    /** The req machine name. */
    @Configuration("daemon.reqMacName")
    private String reqMachineName;

    /** The res machine name. */
    @Configuration("daemon.bcvResMacName")
    private String resMachineName;

    @Configuration("daemon.clients.comptool.timeout")
    private int compToolTimeOut;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getIndusFsFlagPath()
     */
    @Override
    public String getIndusFsFlagPath() {
        return this.indusFlagPath;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getFsFlagPath()
     */
    @Override
    public String getFsFlagPath() {
        return this.fsFlagPath;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getFilePrefix()
     */
    @Override
    public String getFilePrefix() {
        return this.filePrefix;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getFileSuffix()
     */
    @Override
    public String getFileSuffix() {
        return this.fileSuffix;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getReqMacName()
     */
    @Override
    public String getReqMacName() {
        return this.reqMachineName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.DaemonFileConfigUtilService#getResMacName()
     */
    @Override
    public String getResMacName() {
        return this.resMachineName;
    }

    public int getCompToolTimeOut() {
        return this.compToolTimeOut;
    }

}
