/*
 * Creation : 10 Jun 2019
 */

package com.inetpsa.w7t.provider.batch;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManagerFactory;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.daemon.services.internal.DaemonConfig;
import com.inetpsa.w7t.domains.engine.infrastructure.persistence.NewtonRepository;
import com.inetpsa.w7t.domains.engine.model.request.RequestStatus;
import com.inetpsa.w7t.provider.model.NewtonRequestResponse;

/**
 * The Class NewtonRequestFileWriterTasklet.
 *
 * @author E534811
 */
public class NewtonRequestFileWriterTasklet implements Tasklet {
    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(NewtonRequestFileWriterTasklet.class);

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /** The resource. */
    private NewtonFlatFileResource resource;

    /** The entity manager factory. */
    private EntityManagerFactory entityManagerFactory;

    /** The newton jpa repository. */
    @Inject
    private NewtonRepository newtonJpaRepository;

    /**
     * Gets the entity manager factory.
     *
     * @return the entity manager factory
     */
    public EntityManagerFactory getEntityManagerFactory() {
        return entityManagerFactory;
    }

    /**
     * Sets the entity manager factory.
     *
     * @param entityManagerFactory the new entity manager factory
     */
    public void setEntityManagerFactory(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
    }

    /**
     * Gets the jdbc template.
     *
     * @return the jdbc template
     */
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public NewtonFlatFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(NewtonFlatFileResource resource) {
        this.resource = resource;
    }

    /** The Constant selectFileId. */
    final static String selectFileId = "SELECT INTERNAL_FILE_ID FROM W7TQTRQB WHERE STATUS=? AND MANUAL=false and REQ_MAC_NAME=? ORDER BY CREATED_DATE DESC";

    /** The Constant selectNewtonRequests. */
    final static String selectNewtonRequests = "SELECT * FROM W7TQTNEW WHERE STATUS = ? AND FILE_ID = ? AND IS_REQUEST_SENT = ?";

    /** The Constant REQUEST_ID_LENGTH. */
    // final static String updateNewtonRequests = "UPDATE W7TQTNEW SET IS_REQUEST_SENT = ?, STATUS=? WHERE AND FILE_ID = ?";
    private static final int REQUEST_ID_LENGTH = 20;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution,
     *      org.springframework.batch.core.scope.context.ChunkContext)
     */
    @SuppressWarnings({ "unchecked" })
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        List<NewtonRequestResponse> newtonRequestResponseList = new ArrayList<>();
        List<Long> reqNos = new ArrayList<>();
        try {

            List<String> fileIds = jdbcTemplate.query(selectFileId, new Object[] { "C", DaemonConfig.getReqMachine() }, new FileIdRowMapper());
            Set<String> uniqueFileIds = new HashSet<>(fileIds);

            for (String fileId : uniqueFileIds) {
                newtonRequestResponseList = jdbcTemplate.query(selectNewtonRequests,
                        new Object[] { String.valueOf(RequestStatus.REQUEST_TO_SEND.getStatusCode()), fileId, false },
                        new NewtonRequestResponseRowMapper());
                if (!newtonRequestResponseList.isEmpty())
                    break;

            }

            if (!newtonRequestResponseList.isEmpty()) {

                newtonRequestResponseList.forEach(newtonRequest -> reqNos.add(Long.valueOf(newtonRequest.getRequestNo())));

                // int updatedResult = newtonJpaRepository.updateNewtonRequestByFileID(RequestStatus.REQUEST_SENT, true, validFileId);
                int updatedResult = newtonJpaRepository.updateAllNewtonRequestByFileID(RequestStatus.REQUEST_SENT, true, reqNos);
                if (updatedResult > 0) {
                    logger.info("Newtown Request sent status updated successfully");
                }

                createNewtonRequestFile(newtonRequestResponseList);

            }
        } catch (Exception e) {
            if (!newtonRequestResponseList.isEmpty()) {
                int updatedResult = newtonJpaRepository.updateAllNewtonRequestByFileID(RequestStatus.REQUEST_TO_SEND, false, reqNos);
                if (updatedResult > 0) {
                    logger.info("Newtown Request to send status updated.");
                }

                createNewtonRequestFile(newtonRequestResponseList);

            }
            logger.error("Exception : {} ", e);
        }

        return RepeatStatus.FINISHED;
    }

    /**
     * Creates the newton request file.
     *
     * @param newtonRequestResponseList the newton request response list
     * @throws Exception the exception
     */
    private void createNewtonRequestFile(List<NewtonRequestResponse> newtonRequestResponseList) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(getResource().getFile(), true))) {
            for (NewtonRequestResponse newtonReq : newtonRequestResponseList) {
                String record = createRecordToWrite(newtonReq);
                writer.append(record);
            }
            logger.info("Newton file created successfully !");
        } catch (Exception e) {
            logger.error("Exception while creating newton file : {} ", e);
            throw e;
        }
    }

    /**
     * Creates the record to write.
     *
     * @param nreq the nreq
     * @return the string
     */
    private String createRecordToWrite(NewtonRequestResponse nreq) {
        StringBuilder sb = new StringBuilder(3696);
        sb.append(StringUtils.rightPad(nreq.getReqId(), REQUEST_ID_LENGTH));
        // sb.append("W7T" + String.format("%17s", nreq.getRequestNo()).replace(' ', '0'));
        sb.append(String.format("%-19s", BatchUtils.getFileFormatDate(new Date())));

        sb.append(String.format("%-19s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-50s", ""));

        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));
        sb.append(String.format("%-8s", ""));

        sb.append(String.format("%-3524s", nreq.getExtendedTitle()));
        sb.append("\n");
        return sb.toString();
    }

    // private boolean isNUll(String data) {
    // return data == null ? true : false;
    // }

}

class FileIdRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        String fileId = rs.getString("INTERNAL_FILE_ID");
        return fileId;
    }

}

class NewtonRequestResponseRowMapper implements RowMapper {
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        NewtonRequestResponse newtonRequestResponse = new NewtonRequestResponse();
        newtonRequestResponse.setFileId(rs.getString("FILE_ID"));
        newtonRequestResponse.setRequestNo(rs.getString("REQ_NO"));
        newtonRequestResponse.setExtendedTitle(rs.getString("EXTENDED_TITLE"));
        newtonRequestResponse.setStatus(rs.getString("STATUS"));
        newtonRequestResponse.setReqId(rs.getString("REQ_ID"));
        return newtonRequestResponse;
    }

}
