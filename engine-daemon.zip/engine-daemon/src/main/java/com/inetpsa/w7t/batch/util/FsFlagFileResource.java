package com.inetpsa.w7t.batch.util;

/**
 * The Class FsFlagFileResource.
 */
public class FsFlagFileResource {

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Instantiates a new fs flag file resource.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public FsFlagFileResource(String fsFlagFileName) {
        super();
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name
     */
    public String getFsFlagFileName() {
        return this.fsFlagFileName;
    }

}
