/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.jdbc.core.JdbcTemplate;

import com.inetpsa.w7t.batch.mapxml.ClientAnswer;
import com.inetpsa.w7t.batch.mapxml.ClientResponse;
import com.inetpsa.w7t.batch.mapxml.PhaseResult;
import com.inetpsa.w7t.batch.mapxml.Phases;
import com.inetpsa.w7t.batch.mapxml.PhysicalResult;
import com.inetpsa.w7t.batch.mapxml.WltpData;
import com.inetpsa.w7t.provider.model.RequestRowMapper;

/**
 * The Class ClientResponseItemProcessor.
 */
public class ClientResponseItemProcessor implements ItemProcessor<RequestRowMapper, ClientResponse> {

    /** The Constant NUM_FOUR. */
    public static final int NUM_FOUR = 4;

    /** The jdbc template. */
    private JdbcTemplate jdbcTemplate;

    /**
     * Sets the jdbc template.
     *
     * @param jdbcTemplate the new jdbc template
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public ClientResponse process(RequestRowMapper item) throws Exception {

        ClientResponse clientResponse = new ClientResponse();
        clientResponse.setRequestNumber(item.getRequestId());
        clientResponse.setVin(nullAsSpace(item.getVin()));
        getCalculatedData(item.getRequestId());

        ClientAnswer clientAnswer = new ClientAnswer();
        clientAnswer.setCode("OKW00001");
        clientAnswer.setDesignation("Calcul effectué avec succès");

        WltpData wltpData = new WltpData();
        wltpData.setVehType("CONV");
        wltpData.setCategory("M1");
        wltpData.setDestination("Europe EURO6.2");
        clientAnswer.setWltpData(wltpData);

        List<PhysicalResult> physResultList = new ArrayList<>();
        for (Integer i = 1; i <= NUM_FOUR; i++) {
            PhysicalResult physResult = new PhysicalResult();
            physResult.setCode(i.toString());
            physResult.setValue(i.toString());
            physResultList.add(physResult);
        }
        clientAnswer.setPhysResultList(physResultList);

        List<Phases> phasesList = new ArrayList<>();

        Phases phases = new Phases();
        phases.setCode("LOW");
        phases.setPhaseResultList(getPhaseResults());
        phasesList.add(phases);

        phases = new Phases();
        phases.setCode("MID");
        phases.setPhaseResultList(getPhaseResults());
        phasesList.add(phases);

        phases = new Phases();
        phases.setCode("HIGH");
        phases.setPhaseResultList(getPhaseResults());
        phasesList.add(phases);

        clientAnswer.setPhasesList(phasesList);

        return clientResponse;
    }

    /**
     * Gets the phase results.
     *
     * @return the phase results
     */
    private List<PhaseResult> getPhaseResults() {
        List<PhaseResult> phaseResultList = new ArrayList<>();
        PhaseResult phaseResult = new PhaseResult();
        phaseResult.setCode("CE");
        phaseResult.setValue("1432,002");
        phaseResultList.add(phaseResult);
        return phaseResultList;
    }

    /**
     * Null as space.
     *
     * @param str the str
     * @return the string
     */
    private String nullAsSpace(Object str) {
        if (str == null) {
            return "";
        }
        return StringUtils.defaultString(str.toString());
    }

    /**
     * Gets the calculated data.
     *
     * @param requestId the request id
     * @return the calculated data
     */
    private void getCalculatedData(String requestId) {

        String sqlSelect = "SELECT ID FROM W7TQTCLD where REQUEST_ID= ?";
        String calcId = jdbcTemplate.queryForObject(sqlSelect, new Object[] { requestId }, String.class);

        sqlSelect = "SELECT * FROM W7TQTCRL where DATA_ID= ?";
        // sqlSelect = sqlSelect.replace("?", "'" + calcId + "'");
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sqlSelect, calcId);
        for (Map<String, Object> row : rows) {
            row.get("CODE");
        }

        sqlSelect = "SELECT * FROM W7TQTCLP where DATA_ID= ?";
        // sqlSelect = sqlSelect.replace("?", "'" + calcId + "'");
        rows = jdbcTemplate.queryForList(sqlSelect, calcId);
        for (Map<String, Object> row : rows) {
            PhysicalResult physicalResult = new PhysicalResult();
            physicalResult.setCode(nullAsSpace(row.get("PHASE_CODE")));
        }

    }
}
