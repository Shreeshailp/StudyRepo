/*
 * Creation : 27 avr. 2017
 */
package com.inetpsa.w7t.daemon.services.util;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;

import com.inetpsa.w7t.daemon.services.misc.WLTPFileFilter;

/**
 * The Class DaemonServiceUtils.
 */
public final class DaemonServiceUtils {

    private DaemonServiceUtils() {
        // Not to be initialized.
    }

    /**
     * Get the oldest file for a specific name and ext.
     *
     * @param filePath the file path
     * @param pattern the pattern
     * @return the the oldest file
     */
    public static File getTheOldestFile(File filePath, String pattern) {
        if (filePath != null && pattern != null) {
            FileFilter fileFilter = new WLTPFileFilter(pattern);
            File[] files = filePath.listFiles(fileFilter);

            if (files != null && files.length > 0) {
                return getSortResult(files);
            }
        }
        return null;
    }

    private static File getSortResult(File[] files) {
        Arrays.sort(files, (File f1, File f2) -> {
            if (f2.lastModified() > f1.lastModified())
                return 1;
            if (f2.lastModified() == f1.lastModified())
                return 0;
            return -1;
        });
        return files[0];
    }

}
