/*
 * Creation : 26 avr. 2017
 */
package com.inetpsa.w7t.batch.mapxml;

import javax.xml.bind.annotation.XmlAttribute;

/**
 * The Class PhysicalResult.
 */
public class PhysicalResult {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Gets the code.
     *
     * @return the code
     */
    @XmlAttribute
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    @XmlAttribute
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

}
