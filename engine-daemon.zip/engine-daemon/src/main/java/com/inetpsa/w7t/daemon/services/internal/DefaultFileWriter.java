/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.io.File;

import org.seedstack.seed.Configuration;

import com.inetpsa.w7t.daemon.services.FileWriter;

public abstract class DefaultFileWriter implements FileWriter {

    @Configuration("daemon.tempDirectory")
    public File tempDirectory;

    protected String name;

    protected File publishDirectory;

    protected String filenamePattern;

    public DefaultFileWriter() {
    }

    public DefaultFileWriter(String name, File publishDirectory, String filenamePattern) {
        super();
        this.name = name;
        this.publishDirectory = publishDirectory;
        this.filenamePattern = filenamePattern;
    }

    public String name() {
        return this.name;
    }

}
