/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import org.seedstack.business.Producible;
import org.seedstack.business.Service;
import org.seedstack.business.domain.DomainObject;

import com.inetpsa.w7t.domains.engine.model.request.Request;
import com.inetpsa.w7t.domains.engine.model.requestbatch.RequestBatch;

/**
 * The Interface FileWriter.
 */
@Service
public interface FileWriter extends DomainObject, Producible {

    /**
     * Serialize a {@link Request} in a temporary file.
     *
     * @param request the request to be serialized
     */
    void serialize(Request request);

    /**
     * Publish a {@link RequestBatch} by taking all its {@link Request}s in a file and moving it to the publishDirectory.
     *
     * @param requestBatch the request batch to be published
     */
    void publish(RequestBatch requestBatch);

    /**
     * Get the writer name;
     *
     * @return the name of the writer
     */
    String name();

}
