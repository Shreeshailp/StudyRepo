/*
 * Creation : 14 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREFAMILLEType;
import com.inetpsa.w7t.dictionary.listener.model.DictionaryConstants;
import com.inetpsa.w7t.dictionary.listener.service.FamilyDictionaryService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.references.model.GrossVehicleMass;

@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class FamilyDictionaryServiceImpl implements FamilyDictionaryService {

    @Inject
    Factory<GrossVehicleMass> grossVehicleMassfactory;

    @Inject
    private GrossVehicleMassRepository grossVehicleMassRepository;

    Logger genomeLogger = LoggerFactory.getLogger("com.inetpsa.genome");

    @Override
    public int[] mtacUpdate(DICTIONNAIREFAMILLEType dft) {

        List<String> characteristics = DictionaryConstants.MASS_CHARACTERISTICS_TO_READ;
        int[] massesCount = new int[characteristics.size()];

        // genomeLogger.info("Family Dictionary processing started");
        try {
            dft.getCARACTERISTIQUES().forEach(car -> {
                int charPosition = characteristics.indexOf(car.getNOMCARACTERISTIQUE());
                if (charPosition > -1) {
                    massesCount[charPosition]++;
                    car.getVALEURCARACTERISTIQUE().forEach(valcar -> {
                        valcar.getTEXTE().forEach(text -> {
                            if (DictionaryConstants.LANGUAGE_TO_READ.equalsIgnoreCase(text.getLANGUE())) {
                                gvmUpdate(dft.getCLASSEDIFFUSEE(), valcar.getNOMVALEUR(), text.getDESIGNATION(), car.getNOMCARACTERISTIQUE());
                            }
                        });
                    });
                }
            });
            // genomeLogger.info("Family Dictionary processing completed");
        } catch (

        RuntimeException e) {
            genomeLogger.error("Error in reading contents of file after parsing! ", e);
        }
        return massesCount;
    }

    private void gvmUpdate(String family, String code, String value, String characteristic) {
        try {
            boolean famFlag = family.length() != 4;
            boolean codeFlag = code.length() != 2;
            boolean valFlag = value.length() > 30;
            if (famFlag || codeFlag || valFlag) {
                List<String> errorsList = new ArrayList<>();
                if (famFlag)
                    errorsList.add("Family size should be 4");
                if (codeFlag)
                    errorsList.add("Code size should be 2");
                if (valFlag)
                    errorsList.add("Value size should be less than or equal to 30");

                genomeLogger.info("MTAC not created for Family[{}], Code[{}] and Value[{}] as {}", family, code, value, errorsList);
                return;
            }
            Optional<GrossVehicleMass> existingGVM = grossVehicleMassRepository.byFamilyCodeAndCharacteristic(family, code, characteristic);

            if (!existingGVM.isPresent()) {
                GrossVehicleMass newGVM = grossVehicleMassfactory.create();
                newGVM.setFamily(family);
                newGVM.setCode(code);
                newGVM.setValue(value);
                newGVM.setCharacteristic(characteristic);
                grossVehicleMassRepository.persist(newGVM);
                genomeLogger.info("MTAC created {} {} [{}] FR [{}]", family, characteristic, code, value);

            } else if (!(existingGVM.get().getValue().equalsIgnoreCase(value))) {
                existingGVM.get().setValue(value);
                grossVehicleMassRepository.save(existingGVM.get());
                genomeLogger.info("MTAC value updated {} {} [{}] FR [{}]", family, characteristic, code, value);
            }

        } catch (RuntimeException e) {
            genomeLogger.error("Error in persistence operations! ", e);
        }
    }
}
