/*
 * Creation : 6 mai 2017
 */
package com.inetpsa.w7t.provider.batch;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.batch.item.database.JpaItemWriter;

/**
 * The Class NewtonStatusUpdateWriter.
 */
public class NewtonStatusUpdateWriter extends JpaItemWriter<Object> {

    /** The Constant NUM_THREE. */
    public static final int NUM_THREE = 3;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {
        // not used anywhere
    }

}
