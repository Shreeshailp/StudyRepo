package com.inetpsa.w7t.batch;

import java.text.ParseException;
import java.time.format.DateTimeParseException;
import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.util.BatchUtils;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;

/**
 * The Class DateAdapter.
 */
public class DateAdapter extends XmlAdapter<String, Date> {

    /** The logger. */
    @Logging
    private Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
     */
    @Override
    public Date unmarshal(String inDate) {

        Date date = null;
        try {
            date = BatchUtils.getDateFromFile(inDate);
        } catch (DateTimeParseException | ParseException e) {
            LogErrorUtility.logTheError(logger, RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(),
                    RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
        }
        return date;

    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
     */
    @Override
    public String marshal(Date v) throws Exception {
        return v.toString();
    }

}