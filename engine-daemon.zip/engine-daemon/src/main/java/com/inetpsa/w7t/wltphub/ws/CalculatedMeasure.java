/*
 * Creation : 23 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

import java.math.BigDecimal;

public class CalculatedMeasure {

    private String measureTypeCode;
    private BigDecimal value;

    public CalculatedMeasure() {

    }

    public CalculatedMeasure(String measureTypeCode, BigDecimal value) {
        super();
        this.measureTypeCode = measureTypeCode;
        this.value = value;
    }

    public String getMeasureTypeCode() {
        return measureTypeCode;
    }

    public BigDecimal getValue() {
        return value;
    }

}
