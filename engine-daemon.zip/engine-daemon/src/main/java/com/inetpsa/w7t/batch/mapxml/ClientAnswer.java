/*
 * Creation : 25 avr. 2017
 */
package com.inetpsa.w7t.batch.mapxml;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ClientAnswer.
 */
@XmlType(propOrder = { "wltpData", "physResultList", "phasesList" })
public class ClientAnswer {

    private String code;

    private String designation;

    private WltpData wltpData;

    private List<PhysicalResult> physResultList;

    private List<Phases> phasesList;

    @XmlAttribute
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @XmlAttribute
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    @XmlElement(name = "wltp_data")
    public WltpData getWltpData() {
        return wltpData;
    }

    public void setWltpData(WltpData wltpData) {
        this.wltpData = wltpData;
    }

    @XmlElement(name = "phys_result")
    public List<PhysicalResult> getPhysResultList() {
        return physResultList;
    }

    public void setPhysResultList(List<PhysicalResult> physResultList) {
        this.physResultList = physResultList;
    }

    @XmlElement(name = "phase")
    public List<Phases> getPhasesList() {
        return phasesList;
    }

    public void setPhasesList(List<Phases> phasesList) {
        this.phasesList = phasesList;
    }

}
