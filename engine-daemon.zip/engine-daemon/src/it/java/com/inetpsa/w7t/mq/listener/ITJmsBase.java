package com.inetpsa.w7t.mq.listener;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.jms.Connection;
import javax.jms.JMSException;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;

/**
 * The Class JmsBaseIT.
 */
@RunWith(SeedITRunner.class)
public class ITJmsBase {

    /** The test sender. */
    @Inject
    ITMQTextMessageListener testSender;

    /** The injector. */
    @Inject
    Injector injector;

    /** The managed. */
    public static CountDownLatch managed = new CountDownLatch(1);

    /** The unmanaged. */
    public static CountDownLatch unmanaged = new CountDownLatch(1);

    /** The text managed. */
    public static String textManaged = null;

    /** The text unmanaged. */
    public static String textUnmanaged = null;

    /**
     * Managed_send_and_receive_is_working.
     *
     * @throws JMSException the JMS exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Test
    public void managed_send_and_receive_is_working() throws JMSException, IOException {
        testSender.send("MANAGED");

        try {
            managed.await(1, TimeUnit.SECONDS);

            Assertions.assertThat(textManaged).isEqualTo("MANAGED");
        } catch (InterruptedException e) {
            fail("Thread interrupted");
        }
    }

    /**
     * Connections_are_singletons.
     *
     * @throws JMSException the JMS exception
     */
    @Test
    public void connections_are_singletons() throws JMSException {
        Assertions.assertThat(injector.getInstance(Key.get(Connection.class, Names.named("wltpJmsConnection"))))
                .isSameAs(injector.getInstance(Key.get(Connection.class, Names.named("wltpJmsConnection"))));
    }
}
