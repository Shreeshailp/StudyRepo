/*
 * Creation : 20 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

import com.inetpsa.w7t.dictionary.listener.model.CARACTERISTIQUESGENERALType;
import com.inetpsa.w7t.dictionary.listener.model.DICTIONNAIREGENERALType;
import com.inetpsa.w7t.dictionary.listener.model.TEXTEType;
import com.inetpsa.w7t.dictionary.listener.model.VALEURCARACTERISTIQUEGENERALType;

@RunWith(SeedITRunner.class)
public class ITGeneralDictionaryService {

    @Inject
    private GeneralDictionaryService ct;

    @Test
    public void testGVMService() {
        DICTIONNAIREGENERALType dgt = new DICTIONNAIREGENERALType();
        CARACTERISTIQUESGENERALType car = new CARACTERISTIQUESGENERALType();
        car.setNOMCARACTERISTIQUE("GG8");
        VALEURCARACTERISTIQUEGENERALType valcar1 = new VALEURCARACTERISTIQUEGENERALType();
        VALEURCARACTERISTIQUEGENERALType valcar2 = new VALEURCARACTERISTIQUEGENERALType();
        TEXTEType t1 = new TEXTEType();
        TEXTEType t2 = new TEXTEType();

        valcar1.setNOMVALEUR("AI");
        valcar2.setNOMVALEUR("AG");

        t1.setLANGUE("FR");
        t1.setDESIGNATION("INDIE");
        valcar1.getTEXTE().add(t1);

        t2.setLANGUE("FR");
        t2.setDESIGNATION("AUSTRALIE");
        valcar2.getTEXTE().add(t2);

        car.getVALEURCARACTERISTIQUE().add(valcar1);
        car.getVALEURCARACTERISTIQUE().add(valcar2);
        dgt.getCARACTERISTIQUES().add(car);

        int[] noOfItems = ct.countryUpdate(dgt);
        assertThat(noOfItems[0]).isEqualTo(1);
    }
}
