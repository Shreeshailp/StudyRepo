/*
 * Creation : 20 juil. 2017
 */
package com.inetpsa.w7t.mq.listener;

import java.io.File;
import java.io.FileOutputStream;

import javax.inject.Inject;
import javax.jms.BytesMessage;
import javax.jms.Session;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jms.JmsConnection;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.it.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

@RunWith(SeedITRunner.class)
public class ITMQMessageBackup {

    @Inject
    private Session session;

    @Logging
    public Logger logger;

    @Configuration("daemon.providers.genome.inputDirectory")
    private String genomeInDir;

    @Configuration("daemon.providers.genome.backupDirectory")
    private String genomeBackupDir;

    static private final int BUFFER_SIZE = 1024 * 512;

    @Test
    @Transactional
    @JmsConnection("wltpJmsConnection")
    public void testBackupMessage() throws Exception {

        byte[] buf = FileUtils.readFileToByteArray(new File("P:\\document\\WLTP\\WLTP - GENOME\\sample files\\genome_family_test.zip"));
        BytesMessage message2 = session.createBytesMessage();
        message2.writeBytes(buf);
        backupMessage(message2);
    }

    protected File backupMessage(BytesMessage byteMessage) throws Exception {
        FileOutputStream fos = null;
        try {
            logger.info("Backup of the message...... {}", genomeBackupDir);
            byteMessage.reset();
            File msgRepository = new File(genomeBackupDir);

            if (!msgRepository.exists()) {
                msgRepository.mkdirs();
                msgRepository.mkdir();
            }

            File f = new File(msgRepository, "" + byteMessage.getJMSTimestamp() + ".zip");
            int suffix = 0;
            while (f.exists()) {
                suffix++;
                f = new File(msgRepository, "" + byteMessage.getJMSTimestamp() + "_" + suffix + ".zip");
            }

            if (!f.createNewFile()) {
                throw new Exception("Can not create the MQ message backup file...... ");
            }

            fos = new FileOutputStream(f);
            // Enregistrement d'un message
            byte buffer[] = new byte[BUFFER_SIZE];
            int nbLecture;
            while ((nbLecture = byteMessage.readBytes(buffer)) != -1) {
                fos.write(buffer, 0, nbLecture);
            }

            buffer = (byte[]) null;
            /*
             * fos.flush(); fos.close();
             */

            return f;

        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Exception when saving byte message received..... ", e);
        } finally {
            if (fos != null) {
                fos.flush();
                fos.close();
            }
        }

    }
}
