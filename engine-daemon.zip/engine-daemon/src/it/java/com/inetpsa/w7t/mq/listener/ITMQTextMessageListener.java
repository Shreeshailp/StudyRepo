package com.inetpsa.w7t.mq.listener;

import java.io.IOException;

import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.seedstack.jms.JmsConnection;
import org.seedstack.seed.it.ITBind;
import org.seedstack.seed.transaction.Transactional;

@ITBind
public class ITMQTextMessageListener {
    @Inject
    private Session session;

    @Transactional
    @JmsConnection("wltpJmsConnection")
    public void send(String stringMessage) throws JMSException, IOException {

        Destination queue = session.createQueue("R3P.TO.W7T.01");

        /** Text Message **/
        TextMessage message = session.createTextMessage();
        message.setText(stringMessage);

        MessageProducer producer = session.createProducer(queue);
        producer.send(message);

    }
}
