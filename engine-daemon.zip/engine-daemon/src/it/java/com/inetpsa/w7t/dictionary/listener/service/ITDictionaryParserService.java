/*
 * Creation : 20 juil. 2017
 */
package com.inetpsa.w7t.dictionary.listener.service;

import java.io.File;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.it.SeedITRunner;

@RunWith(SeedITRunner.class)
public class ITDictionaryParserService {

    @Inject
    DictionaryParserService dictionaryReader;

    @Test
    public void testDictionaryParserForFamilyDictionary() {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("genome_singleFamilyTest.xml").getFile());
        dictionaryReader.parse(file.getAbsolutePath());
    }

    @Test
    public void testDictionaryParserForGeneralDictionary() {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("genome_singleCountryTest.xml").getFile());
        dictionaryReader.parse(file.getAbsolutePath());
    }
}
