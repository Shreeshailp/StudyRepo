/soft/tom70/fileso/bin/tbtom.sh stop_all /users/w7t00/tom70/w7t01.xml
/soft/tom70/fileso/bin/tbtom.sh delete_all /users/w7t00/tom70/w7t01.xml
/soft/tom70/fileso/bin/tbtom.sh define_all /users/w7t00/tom70/w7t01.xml
/soft/tom70/fileso/bin/tbtom.sh start_all /users/w7t00/tom70/w7t01.xml