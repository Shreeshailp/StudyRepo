printf "Launching WLTP engine micro service..."

if [[ $(echo $1 | grep dev | wc -l) -eq 1 ]]
    then
        cd /usersdev2/w7t

        PIDS=$( ps aux | grep engine-micro-service | grep java | awk '{print $2}' )
        
        echo killing $PIDS
        kill -15 $PIDS
        while kill -0 $PIDS 2> /dev/null; do sleep 1; done;
        
        rm -rf ./data/engine-micro-service/*
        rm -rf ./J2EE/*

        tar -xf /usersdev2/w7t/w7t00etuind/$1
        
        #mv ./J2EE/*.war /users/w7t00/tom70/installableApps/
        #mv ./J2EE/w7t01.xml /users/w7t00/tom70/
                
        #/usersdev2/w7t/delivery/w7t-engine-micro-service.sh &
        nohup /usr/java/jdk1.8.0_77/bin/java -Xms256m -Xmx10G -Xdebug -jar /usersdev2/w7t/data/engine-micro-service/engine-micro-service-${pom.version}-capsule.jar &
        
        echo Launched engine micro service
        
    else
        printf "No deployment for this release (deploy only for *dev.tar)"
fi