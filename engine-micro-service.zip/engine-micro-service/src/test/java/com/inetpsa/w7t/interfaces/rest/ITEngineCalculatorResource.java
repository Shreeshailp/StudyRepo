/*
- * Creation : 21 août 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import static io.restassured.RestAssured.given;

import java.net.URL;
import java.time.LocalDate;

import javax.ws.rs.core.Response;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;

import com.inetpsa.w7t.domains.engine.model.request.RequestType;

@RunWith(Arquillian.class)
public class ITEngineCalculatorResource {

    @ArquillianResource
    private URL baseURL;

    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap.create(WebArchive.class);
    }

    @Configuration("auth.username")
    private String userName;

    @Configuration("auth.password")
    private String passWord;

    @Test
    @RunAsClient
    public void testEngineCalculatorRequest() {
        WSRequestRepresentation wsRequest = new WSRequestRepresentation();

        wsRequest.setVersion16C("1CXAADS6ER1234562");
        wsRequest.setColorExtInt("0RFY0NWP");
        wsRequest.setNbOptions(String.valueOf(100));
        wsRequest.setOptions5C("DD401DJY02DUB09DWL0V2");
        wsRequest.setOptions7C("DD401CPDJY02CPDUB09CPDWL0VCP2");
        wsRequest.setMountingCenter("892");
        wsRequest.setRequestType(RequestType.FULL.toString());
        wsRequest.setVin("VF3ADS6ER12345678");
        wsRequest.setTradingCountry("IT");
        wsRequest.setExtendedTitleAttributes("DAB00CDDAE06CDDAF01CDDAJ01CDDAK01CDDAL04CDDAO00CDDAP02CDDAQ00CDDAT24CDDAZ18CDDA301CD");
        LocalDate extensionDate = LocalDate.of(2017, 8, 10);
        wsRequest.setExtensionDate(extensionDate.toString());
        LocalDate ecomDate = LocalDate.of(2017, 8, 11);
        wsRequest.setEcomDate(ecomDate.toString());

        given().auth().basic(userName, passWord).contentType("application/json").body(wsRequest).when().post(baseURL.toString() + "v1/emissions")
                .then().assertThat().statusCode(Response.Status.BAD_REQUEST.getStatusCode());

    }
}
