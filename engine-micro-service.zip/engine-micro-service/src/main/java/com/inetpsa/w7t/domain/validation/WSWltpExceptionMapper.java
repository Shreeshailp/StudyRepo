/*
 * Creation : 22 août 2017
 */
package com.inetpsa.w7t.domain.validation;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domain.model.WSAnswer;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.interfaces.rest.WSResponseRepresentation;

/**
 * The Class WSWltpExceptionMapper.
 */
@Provider
public class WSWltpExceptionMapper implements ExceptionMapper<WSWltpException> {

    /** The logger. */
    @Logging
    private static Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
     */
    @Override
    public Response toResponse(WSWltpException exception) {
        return Response.status(Response.Status.BAD_REQUEST).entity(configureError(exception)).build();
    }

    /**
     * Configure error.
     *
     * @param exception the exception
     * @return the WS response representation
     */
    private WSResponseRepresentation configureError(WSWltpException exception) {

        WSResponseRepresentation errResponseObj = new WSResponseRepresentation();
        WSAnswer answer = new WSAnswer();

        if (exception.getContextErrorCode() != null) {
            answer.setCode(exception.getContextErrorCode());
            answer.setDesignation(exception.getContextMesage());
        } else if (exception.getMessage() != null) {
            String[] errorMsg = exception.getMessage().split(":");
            answer.setCode(errorMsg[0]);
            if (errorMsg.length > 1)
                answer.setDesignation(errorMsg[1]);
        }
        errResponseObj.setAnswer(answer);
        logger.error("Error in CALCUL webservice request [{}]", answer.toString());
        LogErrorUtility.logTheError(logger, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
        return errResponseObj;
    }

}
