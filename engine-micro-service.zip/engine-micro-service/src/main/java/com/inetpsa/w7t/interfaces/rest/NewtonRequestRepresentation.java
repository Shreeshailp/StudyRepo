/*
 * Creation : 7 sept. 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import java.util.Arrays;

/**
 * The Class NewtonRequestRepresentation.
 */
public class NewtonRequestRepresentation {

    /** The extended title. */
    private String extendedTitle;

    /** The physical objects. */
    private String[] physicalObjects;

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Gets the physical objects.
     *
     * @return the physical objects
     */
    public String[] getPhysicalObjects() {
        return physicalObjects;
    }

    /**
     * Sets the physical objects.
     *
     * @param physicalObjects the new physical objects
     */
    public void setPhysicalObjects(String[] physicalObjects) {
        this.physicalObjects = physicalObjects;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NewtonRequestRepresentation [extendedTitle=" + extendedTitle + ", physicalObjects=" + Arrays.toString(physicalObjects) + "]";
    }

}
