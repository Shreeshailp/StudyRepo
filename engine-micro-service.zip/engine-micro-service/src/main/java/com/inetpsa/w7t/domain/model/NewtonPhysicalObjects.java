/*
 * Creation : 24 oct. 2017
 */
package com.inetpsa.w7t.domain.model;

/**
 * The Class NewtonPhysicalObjects.
 */
public class NewtonPhysicalObjects {

    /** The property name. */
    private String propertyName;

    /** The value. */
    private String value;

    /**
     * Instantiates a new newton physical objects.
     */
    public NewtonPhysicalObjects() {
        // Default constructor for Jackson
    }

    /**
     * Instantiates a new newton physical objects.
     *
     * @param propertyName the property name
     * @param value the value
     */
    public NewtonPhysicalObjects(String propertyName, String value) {
        super();
        this.propertyName = propertyName;
        this.value = value;
    }

    /**
     * Gets the property name.
     *
     * @return the property name
     */
    public String getPropertyName() {
        return propertyName;
    }

    /**
     * Sets the property name.
     *
     * @param propertyName the new property name
     */
    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NewtonPhysicalObjects [propertyName=" + propertyName + ", value=" + value + "]";
    }

}
