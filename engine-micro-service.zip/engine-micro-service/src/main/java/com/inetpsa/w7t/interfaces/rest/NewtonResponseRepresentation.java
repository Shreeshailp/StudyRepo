/*
 * Creation : 9 août 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.w7t.domain.model.NewtonPhysicalObjects;

/**
 * The Class NewtonResponseRepresentation.
 */
public class NewtonResponseRepresentation {

    /** The newton answer code. */
    @JsonProperty("newtonAnswerCode")
    private String newtonAnswerCode;

    /** The newton answer designation. */
    @JsonProperty("newtonAnswerDesignation")
    private String newtonAnswerDesignation;

    /** The physicals objects. */
    @JsonProperty("physicalObjects")
    private List<NewtonPhysicalObjects> physicalObjects;

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return newtonAnswerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return newtonAnswerDesignation;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.newtonAnswerCode = answerCode;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.newtonAnswerDesignation = answerDesignation;
    }

    /**
     * Gets the physicals objects.
     *
     * @return the physicals objects
     */
    public List<NewtonPhysicalObjects> getPhysicalObjects() {
        return physicalObjects;
    }

    /**
     * Sets the physicals objects.
     *
     * @param physicalsObjects the new physicals objects
     */
    public void setPhysicalObjects(List<NewtonPhysicalObjects> physicalObjects) {
        this.physicalObjects = physicalObjects;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NewtonResponseRepresentation [newtonAnswerCode=" + newtonAnswerCode + ", newtonAnswerDesignation=" + newtonAnswerDesignation
                + ", physicalObjects=" + physicalObjects + "]";
    }

}
