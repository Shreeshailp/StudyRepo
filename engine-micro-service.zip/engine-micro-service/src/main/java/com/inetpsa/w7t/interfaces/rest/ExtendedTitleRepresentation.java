/*
 * Creation : 2 juin 2016
 */
package com.inetpsa.w7t.interfaces.rest;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.inetpsa.w7t.domain.validation.WSRequestErrorCodeConstant;

/**
 * The Class ExtendedTitleRepresentation.
 */
public class ExtendedTitleRepresentation {

    /** The identity. */
    private String identity;

    /** The cm. */
    private String cm;

    /** The version16. */
    private String version16;

    /** The habill. */
    private String habill;

    /** The situ. */
    private String situ;

    /** The attributes. */
    @NotNull(message = WSRequestErrorCodeConstant.BCV_ANSWER_INCORRECT)
    @Pattern(regexp = "(?:.{7})+", message = WSRequestErrorCodeConstant.BCV_ANSWER_INCORRECT)
    private String attributes;

    /** The attributes false. */
    @Pattern(regexp = "(?:.{7})*", message = WSRequestErrorCodeConstant.BCV_ANSWER_INCORRECT)
    private String attributesFalse;

    /** The code ano. */
    private String codeAno;

    /** The msg ano. */
    private String msgAno;

    /** The date ext. */
    private String dateExt;

    /**
     * Gets the identity.
     *
     * @return the identity
     */
    public String getIdentity() {
        return identity;
    }

    /**
     * Sets the identity.
     *
     * @param identity the new identity
     */
    public void setIdentity(String identity) {
        this.identity = identity;
    }

    /**
     * Gets the cm.
     *
     * @return the cm
     */
    public String getCm() {
        return cm;
    }

    /**
     * Sets the cm.
     *
     * @param cm the new cm
     */
    public void setCm(String cm) {
        this.cm = cm;
    }

    /**
     * Gets the version16.
     *
     * @return the version16
     */
    public String getVersion16() {
        return version16;
    }

    /**
     * Sets the version16.
     *
     * @param version16 the new version16
     */
    public void setVersion16(String version16) {
        this.version16 = version16;
    }

    /**
     * Gets the habill.
     *
     * @return the habill
     */
    public String getHabill() {
        return habill;
    }

    /**
     * Sets the habill.
     *
     * @param habill the new habill
     */
    public void setHabill(String habill) {
        this.habill = habill;
    }

    /**
     * Gets the situ.
     *
     * @return the situ
     */
    public String getSitu() {
        return situ;
    }

    /**
     * Sets the situ.
     *
     * @param situ the new situ
     */
    public void setSitu(String situ) {
        this.situ = situ;
    }

    /**
     * Gets the attributes.
     *
     * @return the attributes
     */
    public String getAttributes() {
        return attributes;
    }

    /**
     * Sets the attributes.
     *
     * @param attributes the new attributes
     */
    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    /**
     * Gets the attributes false.
     *
     * @return the attributes false
     */
    public String getAttributesFalse() {
        return attributesFalse;
    }

    /**
     * Sets the attributes false.
     *
     * @param attributesFalse the new attributes false
     */
    public void setAttributesFalse(String attributesFalse) {
        this.attributesFalse = attributesFalse;
    }

    /**
     * Gets the code ano.
     *
     * @return the code ano
     */
    public String getCodeAno() {
        return codeAno;
    }

    /**
     * Sets the code ano.
     *
     * @param codeAno the new code ano
     */
    public void setCodeAno(String codeAno) {
        this.codeAno = codeAno;
    }

    /**
     * Gets the msg ano.
     *
     * @return the msg ano
     */
    public String getMsgAno() {
        return msgAno;
    }

    /**
     * Sets the msg ano.
     *
     * @param msgAno the new msg ano
     */
    public void setMsgAno(String msgAno) {
        this.msgAno = msgAno;
    }

    /**
     * Gets the date ext.
     *
     * @return the date ext
     */
    public String getDateExt() {
        return dateExt;
    }

    /**
     * Sets the date ext.
     *
     * @param dateExt the new date ext
     */
    public void setDateExt(String dateExt) {
        this.dateExt = dateExt;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ExtendedTitleRepresentation [identity=" + identity + ", cm=" + cm + ", version16=" + version16 + ", habill=" + habill + ", situ="
                + situ + ", attributes=" + attributes + ", attributesFalse=" + attributesFalse + ", codeAno=" + codeAno + ", msgAno=" + msgAno
                + ", dateExt=" + dateExt + "]";
    }

}
