/*
 * Creation : 23 août 2017
 */
package com.inetpsa.w7t.domain.validation;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;

public class WSDateFormatValidator implements ConstraintValidator<WSDateFormat, String> {

    @Logging
    private static Logger logger = LoggerFactory.getLogger(WSDateFormatValidator.class);;

    @Override
    public void initialize(WSDateFormat constraintAnnotation) {
        // This method is intentionally empty because there is nothing to initialize.
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (value == null || value.isEmpty())
            return true;

        try {
            LocalDate.parse(value);
            return true;
        } catch (DateTimeParseException e) {
            // logger.error("Error in date format ", e);
            LogErrorUtility.logTheError(logger, WSRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                    WSRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
            return false;
        }
    }

}
