/*
 * Creation : 12 Mar 2019
 */
package com.inetpsa.w7t.interfaces.rest;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * The Class Host.
 */
public class Host {

    /** The ip. */
    private InetAddress ip = null;

    /** The hostname. */
    private String hostname = null;

    /**
     * Instantiates a new host.
     *
     * @throws UnknownHostException the unknown host exception
     */
    public Host() throws UnknownHostException {
        try {
            this.setIp(InetAddress.getLocalHost());
            this.setHostname(ip.getHostName());
        } catch (UnknownHostException e) {
            throw e;
        }

    }

    /**
     * Gets the ip.
     *
     * @return the ip
     */
    public InetAddress getIp() {
        return ip;
    }

    /**
     * Sets the ip.
     *
     * @param ip the new ip
     */
    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    /**
     * Gets the hostname.
     *
     * @return the hostname
     */
    public String getHostname() {
        return hostname;
    }

    /**
     * Sets the hostname.
     *
     * @param hostname the new hostname
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

}
