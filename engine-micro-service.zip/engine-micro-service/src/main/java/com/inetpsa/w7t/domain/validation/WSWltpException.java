/*
 * Creation : 1 sept. 2017
 */
package com.inetpsa.w7t.domain.validation;

import org.seedstack.seed.SeedException;

/**
 * The Class WSWltpException.
 */
public class WSWltpException extends SeedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3360223550460382294L;

    /**
     * Instantiates a new WS wltp exception.
     *
     * @param errorCode the error code
     */
    public WSWltpException(WSRequestErrorCode errorCode) {
        super(errorCode);
    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {
        return ((WSRequestErrorCode) this.getErrorCode()).getDescription();
    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((WSRequestErrorCode) this.getErrorCode()).getRuleCode();
    }
}
