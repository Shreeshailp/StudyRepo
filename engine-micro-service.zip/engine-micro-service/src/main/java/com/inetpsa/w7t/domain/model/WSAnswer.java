/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.domain.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class WSAnswer.
 */
@ApiModel
public class WSAnswer {

	/** The code. */
	@ApiModelProperty(example = "OKW00001, ERRW600...", value = "answer code OK or error code")
	private String code;

	/** The designation. */
	@ApiModelProperty(example = "calculation successful", value = "success or error message designation")
	private String designation;

	/**
	 * Instantiates a new WS answer.
	 */
	public WSAnswer() {
		super();
	}

	/**
	 * Instantiates a new WS answer.
	 *
	 * @param code
	 *            the code
	 * @param designation
	 *            the designation
	 */
	public WSAnswer(String code, String designation) {
		super();
		this.code = code;
		this.designation = designation;
	}

	/**
	 * Gets the code.
	 *
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Sets the code.
	 *
	 * @param code
	 *            the new code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Gets the designation.
	 *
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * Sets the designation.
	 *
	 * @param designation
	 *            the new designation
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Answer [code=" + code + ", designation=" + designation + "]";
	}

}
