/*
 * Creation : 3 oct. 2017
 */
package com.inetpsa.w7t.domain.validation;

/**
 * The Class WSRequestErrorCodeConstant.
 */
public class WSRequestErrorCodeConstant {

    /** The Constant VERSION_16C_INCORRECT. */
    public static final String VERSION_16C_INCORRECT = "ERRW601:Version 16C missing or incorrect";

    /** The Constant COLOR_EXT_INT_INCORRECT. */
    public static final String COLOR_EXT_INT_INCORRECT = "ERRW602:Color exterior and interior missing or incorrect";

    /** The Constant NB_OPTIONS_INCORRECT. */
    public static final String NB_OPTIONS_INCORRECT = "ERRW603:Number of options missing or incorrect";

    /** The Constant OPTIONS_5C_INCORRECT. */
    public static final String OPTIONS_5C_INCORRECT = "ERRW604:Options5C incorrect";

    /** The Constant OPTIONS_7C_INCORRECT. */
    public static final String OPTIONS_7C_INCORRECT = "ERRW605:Options7C incorrect";

    /** The Constant NB_GESTION_INCORRECT. */
    public static final String NB_GESTION_INCORRECT = "ERRW616:Number of gestion attributes missing or incorrect";

    /** The Constant GESTION_5C_INCORRECT. */
    public static final String GESTION_5C_INCORRECT = "ERRW617:Gestion5C incorrect";

    /** The Constant GESTION_7C_INCORRECT. */
    public static final String GESTION_7C_INCORRECT = "ERRW618:Gestion7C incorrect";

    /** The Constant EXTENSION_DATE_INCORRECT. */
    public static final String EXTENSION_DATE_INCORRECT = "ERRW606:Incorrect extension date";

    /** The Constant MOUNTING_CENTER_INCORRECT. */
    public static final String MOUNTING_CENTER_INCORRECT = "ERRW607:Incorrect mounting center";

    /** The Constant REQUEST_TYPE_INCORRECT. */
    public static final String REQUEST_TYPE_INCORRECT = "ERRW103:Unknown request type";

    /** The Constant VIN_INCORRECT. */
    public static final String VIN_INCORRECT = "ERRW608:VIN not correct";

    /** The Constant ECOM_DATE_INCORRECT. */
    public static final String ECOM_DATE_INCORRECT = "ERRW609:Incorrect ecom date";

    /** The Constant TRADING_COUNTRY_INCORRECT. */
    public static final String TRADING_COUNTRY_INCORRECT = "ERRW610:Incorrect trading country";

    /** The Constant EXTENDED_TITLE_ATTRIBUTES_INCORRECT. */
    public static final String EXTENDED_TITLE_ATTRIBUTES_INCORRECT = "ERRW611:Incorrect extended title attributes";

    /** The Constant BCV_ANSWER_INCORRECT. */
    public static final String BCV_ANSWER_INCORRECT = "ERRW612:Incorrect answer from BCV";

    /**
     * Instantiates a new WS request error code constant.
     */
    private WSRequestErrorCodeConstant() {
    }

}
