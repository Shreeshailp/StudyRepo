/*
 * Creation : 9 août 2017
 */
package com.inetpsa.w7t.interfaces.rest;

import org.seedstack.seed.rest.hal.HalRepresentation;

/**
 * The Class RequestRepresentation.
 */
public class RequestRepresentation extends HalRepresentation {

    /** The request. */
    private WSRequestRepresentation request;

    /**
     * Gets the request.
     *
     * @return the request
     */
    public WSRequestRepresentation getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(WSRequestRepresentation request) {
        this.request = request;
    }

}
