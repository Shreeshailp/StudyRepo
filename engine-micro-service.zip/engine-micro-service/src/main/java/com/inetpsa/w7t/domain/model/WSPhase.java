/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.domain.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class WSPhase.
 */
@ApiModel
public class WSPhase {

    /** The code. */
    @ApiModelProperty(example = "COMB", value = "Phase code of results")
    private String code;

    /** The result. */
    @ApiModelProperty(value = "List of results")
    private List<Result> result;

    /**
     * The Class Result.
     */
    @ApiModel
    public class Result {

        /** The code. */
        @ApiModelProperty(example = "CO2", value = "Measure Type code of the result")
        private String code;

        /** The value. */
        @ApiModelProperty(example = "141", value = "Result value")
        private String value;

        /**
         * Instantiates a new result.
         *
         * @param code the code
         * @param value the value
         */
        public Result(String code, String value) {
            super();
            this.code = code;
            this.value = value;
        }

        /**
         * Gets the code.
         *
         * @return the code
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the code.
         *
         * @param code the new code
         */
        public void setCode(String code) {
            this.code = code;
        }

        /**
         * Gets the value.
         *
         * @return the value
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value.
         *
         * @param value the new value
         */
        public void setValue(String value) {
            this.value = value;
        }

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "Result [code=" + code + ", value=" + value + "]";
        }
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the result.
     *
     * @return the result
     */
    public List<Result> getResult() {
        return result;
    }

    /**
     * Sets the result.
     *
     * @param result the new result
     */
    public void setResult(List<Result> result) {
        this.result = result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WSPhase [code=" + code + ", result=" + result + "]";
    }

}