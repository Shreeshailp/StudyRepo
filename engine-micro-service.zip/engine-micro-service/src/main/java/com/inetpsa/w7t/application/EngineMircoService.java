/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.application;

import java.util.Optional;

import javax.validation.Valid;

import org.seedstack.business.Service;

import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;
import com.inetpsa.w7t.interfaces.rest.WSResponseRepresentation;

/**
 * The Interface EngineMircoService.
 */
@Service
@FunctionalInterface
public interface EngineMircoService {

    /**
     * Process request.
     *
     * @param wsRequestObject the ws request object
     * @param requestId the request id
     * @return the optional
     */
    Optional<WSResponseRepresentation> processRequest(@Valid WSRequestRepresentation wsRequestObject, String requestId);
}
