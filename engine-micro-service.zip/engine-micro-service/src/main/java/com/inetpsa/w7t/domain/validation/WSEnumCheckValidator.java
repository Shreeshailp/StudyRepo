/*
 * Creation : 23 août 2017
 */
package com.inetpsa.w7t.domain.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * The Class WSEnumCheckValidator.
 */
public class WSEnumCheckValidator implements ConstraintValidator<WSEnumCheck, String> {

    /** The constraint annotation. */
    private WSEnumCheck constraintAnnotation;

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#initialize(java.lang.annotation.Annotation)
     */
    @Override
    public void initialize(WSEnumCheck constraintAnnotation) {
        this.constraintAnnotation = constraintAnnotation;
    }

    /**
     * {@inheritDoc}
     * 
     * @see javax.validation.ConstraintValidator#isValid(java.lang.Object, javax.validation.ConstraintValidatorContext)
     */
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        Object[] enumValues = this.constraintAnnotation.enumClass().getEnumConstants();

        if (value == null) {
            return false;
        }

        if (enumValues != null) {
            for (Object enumValue : enumValues) {
                if (value.equals(enumValue.toString()))
                    return true;
            }
        }
        return false;
    }

}
