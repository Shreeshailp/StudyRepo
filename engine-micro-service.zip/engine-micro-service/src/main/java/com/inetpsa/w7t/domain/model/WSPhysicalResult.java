/*
 * Creation : 15 déc. 2017
 */
package com.inetpsa.w7t.domain.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * The Class WSPhysicalResult.
 */
@ApiModel
public class WSPhysicalResult {

    /** The code. */
    @ApiModelProperty(example = "COMPL, CRREC, ROADLOAD, TMASSE, MASSE, F0,...", value = "COMPL - Flag complete/incomplete, CRREC - CRR efficiency class, ROADLOAD - Road load type,...")
    private String code;

    /** The value. */
    @ApiModelProperty(value = "COMPL - C(complete) or I(incomplete), CRREC - One letter corresponding to the CRR class value, ROADLOAD -  IRL = Interpolation road load, MRL = Matrix law, DRL = Default road load,...")
    private String value;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WSPhysicalResult [code=" + code + ", value=" + value + "]";
    }

}
