/*
 * Creation : 7 sept. 2017
 */
package com.inetpsa.w7t.application.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.inject.Inject;

import org.apache.commons.lang.time.StopWatch;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.SeedException;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.inetpsa.w7t.application.NewtonService;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCode;
import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.GrossVehicleMassRepository;
import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.interfaces.rest.NewtonRequestRepresentation;
import com.inetpsa.w7t.interfaces.rest.NewtonResponseRepresentation;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Class NewtonServiceImpl.
 */
public class NewtonServiceImpl implements NewtonService {

    /** The Constant THIRTY_SEVEN. */
    private static final int THIRTY_SEVEN = 37;

    /** The username. */
    @Configuration("webService.newton.credentials.username")
    private static String username;

    /** The password. */
    @Configuration("webService.newton.credentials.password")
    private static String code;

    /** The url. */
    @Configuration("webService.newton.url")
    private static String url;

    /** The timeout. */
    @Configuration("webService.newton.timeout")
    private static int timeout;

    /** The creds bas e64. */
    private String credsBASE64;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The gross vehicle mass repository. */
    @Inject
    private GrossVehicleMassRepository grossVehicleMassRepository;

    /** The tvv repository. */
    @Inject
    private TVVRepository tvvRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.NewtonService#getNewtonPhysicalData(com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation)
     */
    @Override
    public List<EnginePhysicalQuantity> getNewtonPhysicalData(WSRequestRepresentation wsRequestObject, String requestId) {

        if (this.credsBASE64 == null)
            this.credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());

        NewtonRequestRepresentation newtonRequest = new NewtonRequestRepresentation();

        String extendedTitle = wsRequestObject.getVersion16C() + wsRequestObject.getColorExtInt() + wsRequestObject.getExtendedTitleAttributes();
        validExtendedTitle(extendedTitle, wsRequestObject.getTvv(), requestId);
        newtonRequest.setExtendedTitle(extendedTitle);
        String[] phyObjects = { "VehicleMass", "UnladenMass", "EquipmentMass", "VehicleSCx", "UnladenSCx", "EquipmentSCx", "VehicleCRR" };
        newtonRequest.setPhysicalObjects(phyObjects);

        NewtonResponseRepresentation newtonResponse = newtonCall(newtonRequest, requestId);

        if (newtonResponse != null && newtonResponse.getAnswerCode() != null && !newtonResponse.getAnswerCode().startsWith("OK")) {
            WSRequestErrorCode wsec = WSRequestErrorCode.NEWTON_INCORRECT_ANSWER;
            wsec.setRuleCode(newtonResponse.getAnswerCode());
            if (!newtonResponse.getAnswerDesignation().isEmpty())
                wsec.setDescription(newtonResponse.getAnswerDesignation());
            else
                wsec.setDescription("Incorrect answer from Newton");
            throw new WSWltpException(wsec);
        }

        List<EnginePhysicalQuantity> physicalData = new ArrayList<>();
        if (newtonResponse != null) {
            newtonResponse.getPhysicalObjects().forEach(obj -> {
                EnginePhysicalQuantity e = new EnginePhysicalQuantity(obj.getPropertyName(), getPrimitiveTypeForNULL(obj.getValue()));
                physicalData.add(e);
            });
        }

        return physicalData;
    }

    /**
     * Newton call.
     *
     * @param newtonRequest the newton request
     * @param requestId the request id
     * @return the newton response representation
     */
    private NewtonResponseRepresentation newtonCall(NewtonRequestRepresentation newtonRequest, String requestId) {
        logger.info("Request ID[{}]: Newton webservice request = [{}]", requestId, newtonRequest);
        NewtonResponseRepresentation newtonResponse = null;
        boolean retryFlag = false;
        int maxRetryCount = 3;
        int count = 1;
        while (!retryFlag && count <= maxRetryCount) {
            try {
                StopWatch sw = new StopWatch();
                sw.start();
                HttpClient httpClient = HttpClientBuilder.create().build();

                RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
                logger.info("Request ID[{}]: Calling Newton WebService on URL - {}", requestId, url);
                HttpPost postRequest = new HttpPost(url);
                postRequest.setConfig(requestConfig);
                postRequest.addHeader("Content-Type", "application/json");
                postRequest.addHeader("Authorization", "Basic " + credsBASE64);
                postRequest.setEntity(new StringEntity(new Gson().toJson(newtonRequest)));

                HttpResponse response = httpClient.execute(postRequest);

                BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
                String output;
                StringBuilder answer = new StringBuilder();
                while ((output = br.readLine()) != null) {
                    answer.append(output);
                }
                newtonResponse = new Gson().fromJson(answer.toString(), NewtonResponseRepresentation.class);
                logger.debug("Request ID[{}]: StopWatch - Newton WebService Call - Took {}ms", requestId, sw.getTime());
                retryFlag = true;
            } catch (ConnectTimeoutException | SocketTimeoutException e) {
                logger.error("Exception While calling Newton webservice: [{}]", e);
                if (count != maxRetryCount) {
                    logger.info("Request ID[{}]: As we have an time out exception and we are re-calling Newton webservice !", requestId);
                }
                if (count == maxRetryCount) {
                    LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.NEWTON_TIMEOUT_EXCEPTION.getRuleCode(),
                            WSRequestErrorCode.NEWTON_TIMEOUT_EXCEPTION.getDescription());
                    throw new WSWltpException(WSRequestErrorCode.NEWTON_TIMEOUT_EXCEPTION);
                }
            } catch (RuntimeException | IOException e) {
                logger.error("Exception While calling Newton webservice: [{}]", e);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.NEWTON_NO_ANSWER.getRuleCode(),
                        WSRequestErrorCode.NEWTON_NO_ANSWER.getDescription());
                throw new WSWltpException(WSRequestErrorCode.NEWTON_NO_ANSWER);
            }
            count++;
        }

        logger.info("Request ID[{}]: Newton webservice response = [{}]", requestId, newtonResponse);
        return newtonResponse;

    }

    /**
     * Gets the primitive type for null.
     *
     * @param value the value
     * @return the primitive type for null
     */
    private double getPrimitiveTypeForNULL(String value) {
        if (value == null || value.trim().isEmpty())
            return 0.0;
        return Double.parseDouble(value.replace(",", "."));
    }

    /**
     * Valid physical data. Checks the presence of few essential attributes in the extended title.
     *
     * @param extndTitle the extnd title
     * @param tvv the tvv
     * @param requestId the request id
     */
    private void validExtendedTitle(String extndTitle, String tvv, String requestId) {
        Matcher vehicleFamilyMatch = Pattern.compile("(....).{20}(?:.{7})*").matcher(extndTitle);
        Matcher coherenceIndexMatch = Pattern.compile(".{24}(?:.{7})*(?:T8E(..)(..))(?:.{7})*").matcher(extndTitle);
        Matcher gvmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3N(..)(..))(?:.{7})*").matcher(extndTitle);
        Matcher fomMatch = Pattern.compile(".{24}(?:.{7})*(?:T3S(..)(..))(?:.{7})*").matcher(extndTitle);
        Matcher emmMatch = Pattern.compile(".{24}(?:.{7})*(?:T3M(..)(..))(?:.{7})*").matcher(extndTitle);
        Matcher tvvT1AMatch = Pattern.compile(".{24}(?:.{7})*(?:T1A(..)(..))(?:.{7})*").matcher(extndTitle);
        Matcher tvvT1BMatch = Pattern.compile(".{24}(?:.{7})*(?:T1B(..)(..))(?:.{7})*").matcher(extndTitle);
        boolean t1AT1BMatch = tvvT1AMatch.matches() && tvvT1BMatch.matches();

        String t1aValue = "";
        String t1bValue = "";

        if (tvvT1AMatch.matches()) {
            t1aValue = tvvT1AMatch.group(1);
        }
        if (tvvT1BMatch.matches()) {
            t1bValue = tvvT1BMatch.group(1);
        }
        if (!coherenceIndexMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.NEWTON_PHYSICAL_INDEX_NOT_PRESENT.getRuleCode(),
                    WSRequestErrorCode.NEWTON_PHYSICAL_INDEX_NOT_PRESENT.getDescription());
            throw new WSWltpException(WSRequestErrorCode.NEWTON_PHYSICAL_INDEX_NOT_PRESENT);
        }
        if (!vehicleFamilyMatch.matches()) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                    WSRequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            throw new WSWltpException(WSRequestErrorCode.EXTENDED_TITLE_INCORRECT);
        }
        String vehicleFamily = vehicleFamilyMatch.group(1);
        if (gvmMatch.matches()) {
            String mtacCode = gvmMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, mtacCode, "T3N")) {
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.UNKNOWN_MTAC.getRuleCode(),
                        WSRequestErrorCode.UNKNOWN_MTAC.getDescription());
                throw new WSWltpException(WSRequestErrorCode.UNKNOWN_MTAC);
            }
        } else {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.MTAC_MISSING.getRuleCode(),
                    WSRequestErrorCode.MTAC_MISSING.getDescription());
            throw new WSWltpException(WSRequestErrorCode.MTAC_MISSING);
        }
        if (fomMatch.matches()) {
            String fomCode = fomMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, fomCode, "T3S")) {
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.UNKNOWN_FOM.getRuleCode(),
                        WSRequestErrorCode.UNKNOWN_FOM.getDescription());
                throw new WSWltpException(WSRequestErrorCode.UNKNOWN_FOM);
            }
        } else {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.FOM_MISSING.getRuleCode(),
                    WSRequestErrorCode.FOM_MISSING.getDescription());
            throw new WSWltpException(WSRequestErrorCode.FOM_MISSING);
        }
        if (emmMatch.matches()) {
            String emmCode = emmMatch.group(1);
            if (!grossVehicleMassRepository.isDefined(vehicleFamily, emmCode, "T3M")) {
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.UNKNOWN_EMM.getRuleCode(),
                        WSRequestErrorCode.UNKNOWN_EMM.getDescription());
                throw new WSWltpException(WSRequestErrorCode.UNKNOWN_EMM);
            }
        } else {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.EMM_MISSING.getRuleCode(),
                    WSRequestErrorCode.EMM_MISSING.getDescription());
            throw new WSWltpException(WSRequestErrorCode.EMM_MISSING);
        }

        if (tvv != null && !tvv.isEmpty()) {
            List<TVV> tvvDesignationList = tvvRepository.tvvByUniqueFields(vehicleFamily, tvv);
            if (!t1AT1BMatch && vehicleFamilyMatch.matches() && tvvDesignationList.isEmpty()) {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setStrRuleCode(WSRequestErrorCode.UNKNOWN_TVV.getRuleCode());
                // fixed jira-573
                if (tvv.length() >= THIRTY_SEVEN) {
                    tvv = tvv.substring(0, THIRTY_SEVEN);
                    wltpErrorCode.setDescription(WSRequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + tvv + "]");
                } else {
                    wltpErrorCode.setDescription(WSRequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + tvv + "]");
                }
                // JIRA-535 Fix Ends Here
                LogErrorUtility.logTheError(logger, requestId, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            } else if (!t1AT1BMatch && vehicleFamilyMatch.matches() && tvvDesignationList.size() > 1) {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setStrRuleCode(WSRequestErrorCode.SEVERAL_TVV.getRuleCode());
                wltpErrorCode.setDescription(WSRequestErrorCode.SEVERAL_TVV.getDescription());
                // JIRA-535 Fix Ends Here
                LogErrorUtility.logTheError(logger, requestId, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            }
        } else if (t1AT1BMatch) {
            String t1a = tvvT1AMatch.group(1);
            String t1b = tvvT1BMatch.group(1);
            List<TVV> tvv1 = tvvRepository.tvvByUniqueFields(vehicleFamily, t1a, t1b);
            if (vehicleFamilyMatch.matches() && tvv1.isEmpty()) {
                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setStrRuleCode(WSRequestErrorCode.UNKNOWN_TVV.getRuleCode());
                wltpErrorCode
                        .setDescription(WSRequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + vehicleFamily + ", T1A" + t1a + ", T1B" + t1b + "]");
                // JIRA-535 Fix Ends Here
                LogErrorUtility.logTheError(logger, requestId, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            } else if (vehicleFamilyMatch.matches() && tvv1.size() > 1) {

                // JIRA-535 Fix Starts Here
                WltpErrorCode wltpErrorCode = new WltpErrorCode();
                wltpErrorCode.setStrRuleCode(WSRequestErrorCode.SEVERAL_TVV.getRuleCode());
                wltpErrorCode
                        .setDescription(WSRequestErrorCode.SEVERAL_TVV.getDescription() + "[" + vehicleFamily + ", T1A" + t1a + ", T1B" + t1b + "]");
                // JIRA-535 Fix Ends Here
                LogErrorUtility.logTheError(logger, requestId, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
                throw SeedException.createNew(wltpErrorCode);
            }
        } else if ((!t1aValue.isEmpty() || !t1bValue.isEmpty())) {
            String t1aStrValue = "";
            String t1bStrValue = "";
            if (!t1aValue.isEmpty()) {
                t1aStrValue = "T1A" + t1aValue;
            }
            if (!t1bValue.isEmpty()) {
                t1bStrValue = "T1B" + t1bValue;
            }
            WltpErrorCode wltpErrorCode = new WltpErrorCode();
            wltpErrorCode.setStrRuleCode(WSRequestErrorCode.UNKNOWN_TVV.getRuleCode());
            wltpErrorCode.setDescription(
                    WSRequestErrorCode.UNKNOWN_TVV.getDescription() + "[" + vehicleFamily + ", " + t1aStrValue + ", " + t1bStrValue + "]");
            LogErrorUtility.logTheError(logger, requestId, wltpErrorCode.getStrRuleCode(), wltpErrorCode.getDescription());
            throw SeedException.createNew(wltpErrorCode);
        }

    }
}
