/*
 * Creation : 23 août 2017
 */
package com.inetpsa.w7t.domain.validation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.constraints.NotNull;

/**
 * The Interface WSEnumCheck.
 */
@NotNull
@Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD })
@Documented
@Constraint(validatedBy = { WSEnumCheckValidator.class })
@Retention(RetentionPolicy.RUNTIME)
public @interface WSEnumCheck {

    /**
     * Message.
     *
     * @return the string
     */
    String message() default "Unknown enum value";

    /**
     * Groups.
     *
     * @return the class[]
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the class<? extends payload>[]
     */
    Class<? extends Payload>[] payload() default {};

    /**
     * Enum class.
     *
     * @return the class<? extends java.lang. enum<?>>
     */
    Class<? extends java.lang.Enum<?>> enumClass();

}
