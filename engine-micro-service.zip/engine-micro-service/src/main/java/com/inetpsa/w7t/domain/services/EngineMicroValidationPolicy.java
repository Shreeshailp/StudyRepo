/*
 * Creation : 18 août 2017
 */
package com.inetpsa.w7t.domain.services;

import org.seedstack.business.domain.DomainPolicy;

import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Interface EngineMicroValidationPolicy.
 */
@DomainPolicy
@FunctionalInterface
public interface EngineMicroValidationPolicy {

    /**
     * Checks if is ws request valid.
     *
     * @param requestObject the request object
     * @param requestId the request id
     */
    void isWSRequestValid(WSRequestRepresentation requestObject, String requestId);

}
