/*
 * Creation : 24 août 2017
 */
package com.inetpsa.w7t.application.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.lang.time.StopWatch;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.inetpsa.r3pi.transcolcdv.TranscoManager57;
import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.application.BCVService;
import com.inetpsa.w7t.domain.validation.WSRequestErrorCode;
import com.inetpsa.w7t.domain.validation.WSWltpException;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.interfaces.rest.ExtendedTitleRepresentation;
import com.inetpsa.w7t.interfaces.rest.TitleRepresentation;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Class BCVServiceImpl.
 */
public class BCVServiceImpl implements BCVService {

    /** The Constant FIVE. */
    private static final int FIVE = 5;

    /** The username. */
    @Configuration("webService.bcv.credentials.username")
    private static String username;

    /** The password. */
    @Configuration("webService.bcv.credentials.password")
    private static String code;

    /** The url. */
    @Configuration("webService.bcv.url")
    private static String url;

    /** The timeout. */
    @Configuration("webService.bcv.timeout")
    private static int timeout;

    /** The creds bas e64. */
    private String credsBASE64;

    /** The logger. */
    @Logging
    private Logger logger;

    /** The Constant BASIC. */
    private static final String AUTH_VALUE = "Basic ";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.BCVService#getCompleteExtendedTitle(com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation)
     */
    @Override
    public String getCompleteExtendedTitle(WSRequestRepresentation wsRequestObject, String requestId) {

        if (this.credsBASE64 == null)
            this.credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());

        TitleRepresentation title = new TitleRepresentation();
        DateTimeFormatter bcvDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");
        DateTimeFormatter wltpDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        title.setIdentity("");
        title.setSitu("");
        title.setNbGest(wsRequestObject.getNbGestion());
        title.setVersion16(wsRequestObject.getVersion16C());
        title.setHabill(wsRequestObject.getColorExtInt());
        title.setNbPers(wsRequestObject.getNbOptions());

        if (!wsRequestObject.getExtensionDate().isEmpty())
            title.setDateExt(LocalDate.parse(wsRequestObject.getExtensionDate()).format(bcvDateFormat));

        String persValue = get7cValue(wsRequestObject.getOptions5C(), wsRequestObject.getOptions7C(), requestId);
        title.setPers(persValue);
        String gestValue = get7cValue(wsRequestObject.getGestion5C(), wsRequestObject.getGestion7C(), requestId);
        title.setGest(gestValue);
        title.setCm(wsRequestObject.getMountingCenter());
        ExtendedTitleRepresentation extTitle = bcvCall(title, requestId);
        validateBcvAnswer(requestId, extTitle);
        if (wsRequestObject.getExtensionDate() == null || wsRequestObject.getExtensionDate().isEmpty()) {
            wsRequestObject.setExtensionDate(LocalDate.parse(extTitle.getDateExt(), bcvDateFormat).format(wltpDateFormat));
        }

        if (wsRequestObject.getMountingCenter() == null || wsRequestObject.getMountingCenter().isEmpty()) {
            wsRequestObject.setMountingCenter(extTitle.getCm());
        }
        if (wsRequestObject.getOptions7C() == null || wsRequestObject.getOptions7C().isEmpty()) {
            wsRequestObject.setOptions7C(title.getPers());
        }
        if (wsRequestObject.getGestion7C() == null || wsRequestObject.getGestion7C().isEmpty()) {
            wsRequestObject.setGestion7C(title.getGest());
        }
        return extTitle.getAttributes();
    }

    /**
     * Bcv call.
     *
     * @param title the title
     * @param requestId the request id
     * @return the extended title representation
     */
    private ExtendedTitleRepresentation bcvCall(TitleRepresentation title, String requestId) {
        logger.info("Request ID[{}]: BCV webservice request =  [{}]", requestId, title);
        ExtendedTitleRepresentation extTitle = null;
        boolean retryFlag = false;
        int maxRetryCount = 3;
        int count = 1;
        while (!retryFlag && count <= maxRetryCount) {
            try {
                StopWatch sw = new StopWatch();
                sw.start();
                HttpClient httpClient = HttpClientBuilder.create().build();

                RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
                logger.info("Request ID[{}]: Calling BCV WebService on URL - {}", requestId, url);
                HttpPost postRequest = new HttpPost(url);
                postRequest.setConfig(requestConfig);
                postRequest.addHeader("Content-Type", "application/json");
                postRequest.addHeader("Authorization", AUTH_VALUE + credsBASE64);
                postRequest.setEntity(new StringEntity(new Gson().toJson(title)));

                HttpResponse response = httpClient.execute(postRequest);

                BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
                String output;
                StringBuilder answer = new StringBuilder();
                while ((output = br.readLine()) != null) {
                    answer.append(output);
                }
                extTitle = new Gson().fromJson(answer.toString(), ExtendedTitleRepresentation.class);
                sw.stop();
                retryFlag = true;
                logger.debug("Request ID[{}]: StopWatch - BCV WebService Call - Took {}ms", requestId, sw.getTime());
            } catch (ConnectTimeoutException | SocketTimeoutException e) {
                logger.error("Exception While calling BCV webservice: [{}]", e);
                if (count != maxRetryCount) {
                    logger.info("Request ID[{}]: As we have an time out exception and we are re-calling BCV webservice !", requestId);
                }
                if (count == maxRetryCount) {
                    LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.BCV_TIMEOUT_EXCEPTION.getRuleCode(),
                            WSRequestErrorCode.BCV_TIMEOUT_EXCEPTION.getDescription());
                    throw new WSWltpException(WSRequestErrorCode.BCV_TIMEOUT_EXCEPTION);
                }
            } catch (RuntimeException | IOException e) {
                logger.error("Exception While calling BCV webservice: [{}]", e);
                LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.BCV_NO_ANSWER.getRuleCode(),
                        WSRequestErrorCode.BCV_NO_ANSWER.getDescription());
                throw new WSWltpException(WSRequestErrorCode.BCV_NO_ANSWER);
            }
            count++;
        }

        logger.info("Request ID[{}]: BCV web service response =  [{}]", requestId, extTitle);
        return extTitle;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.application.BCVService#get7cValue(java.lang.String, java.lang.String)
     */
    @Override
    public String get7cValue(String value5c, String value7c, String requestId) {
        String persValue = value7c;
        if (persValue.isEmpty() && !value5c.isEmpty())
            persValue = transcodify(value5c, requestId);
        return persValue;
    }

    /**
     * Transcodify.
     *
     * @param option5C the option5 c
     * @param requestId the request id
     * @return the string
     */
    private String transcodify(String option5C, String requestId) {
        TranscoManager57 tm57 = TranscoManager57.getInstance();
        StringBuilder persValue = new StringBuilder();

        List<String> lcdvList = new ArrayList<>();
        int index = 0;
        while (index < option5C.length()) {
            lcdvList.add(" " + option5C.substring(index, index + FIVE));
            index += FIVE;
        }
        logger.info("Request ID[{}]: Transcodification module request =  [{}]", requestId, option5C);
        try {
            for (String lcdv : lcdvList)
                persValue.append(tm57.transco(lcdv));
        } catch (TranscoNotFoundException e) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.FIVE_C_VALUE_INCORRECT.getRuleCode(),
                    WSRequestErrorCode.FIVE_C_VALUE_INCORRECT.getDescription());
            throw new WSWltpException(WSRequestErrorCode.FIVE_C_VALUE_INCORRECT);
        }
        logger.info("Request ID[{}]: Transcodification module response =  [{}]", requestId, persValue);

        return persValue.toString();
    }

    /**
     * Validate bcv answer.
     *
     * @param requestId the request id
     * @param extTitle the ext title
     */
    private void validateBcvAnswer(String requestId, @Valid ExtendedTitleRepresentation extTitle) {
        if (!(extTitle.getCodeAno().isEmpty() || ("N").equals(extTitle.getCodeAno()))) {
            WSRequestErrorCode wsec = WSRequestErrorCode.BCV_ERROR;
            wsec.setRuleCode(extTitle.getCodeAno());
            if (!extTitle.getMsgAno().isEmpty())
                wsec.setDescription(extTitle.getMsgAno());
            else {
                wsec.setRuleCode(WSRequestErrorCode.BCV_INCORRECT_ANSWER.getRuleCode());
                wsec.setDescription(WSRequestErrorCode.BCV_INCORRECT_ANSWER.getDescription());
            }
            LogErrorUtility.logTheError(logger, requestId, wsec.getRuleCode(), wsec.getDescription());
            throw new WSWltpException(wsec);
        }

        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<ExtendedTitleRepresentation>> errors = validator.validate(extTitle);
        if (!errors.isEmpty()) {
            LogErrorUtility.logTheError(logger, requestId, WSRequestErrorCode.BCV_INCORRECT_ANSWER.getRuleCode(),
                    WSRequestErrorCode.BCV_INCORRECT_ANSWER.getDescription());
            throw new WSWltpException(WSRequestErrorCode.BCV_INCORRECT_ANSWER);
        }
    }
}
