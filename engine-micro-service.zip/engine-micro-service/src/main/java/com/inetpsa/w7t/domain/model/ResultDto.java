/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.w7t.domain.model;

public class ResultDto implements Comparable<ResultDto> {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    private Integer sort;

    public ResultDto(String code, String value, Integer sort) {
        super();
        this.code = code;
        this.value = value;
        this.sort = sort;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        return "ResultDto [code=" + code + ", value=" + value + ", sort=" + sort + "]";
    }

    @Override
    public int compareTo(ResultDto o) {
        return this.getSort().compareTo(o.getSort());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((sort == null) ? 0 : sort.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ResultDto other = (ResultDto) obj;
        if (sort == null) {
            if (other.sort != null)
                return false;
        } else if (!sort.equals(other.sort))
            return false;
        return true;
    }

}
