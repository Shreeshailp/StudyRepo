/*
 * Creation : 7 sept. 2017
 */
package com.inetpsa.w7t.application;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.interfaces.rest.WSRequestRepresentation;

/**
 * The Interface NewtonService.
 */
@Service
@FunctionalInterface
public interface NewtonService {

    /**
     * Gets the newton physical data.
     *
     * @param wsRequestObject the ws request object
     * @param requestId the request id
     * @return the newton physical data
     */
    List<EnginePhysicalQuantity> getNewtonPhysicalData(WSRequestRepresentation wsRequestObject, String requestId);
}