/*
 * Creation : 22 août 2017
 */
package com.inetpsa.w7t.domain.validation;

import java.util.Optional;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.domain.model.WSAnswer;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.interfaces.rest.WSResponseRepresentation;

/**
 * The Class WSConstraintViolationExceptionMapper.
 */
@Provider
public class WSConstraintViolationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

    /** The logger. */
    @Logging
    private static Logger logger;

    /**
     * {@inheritDoc}
     * 
     * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
     */
    @Override
    public Response toResponse(ConstraintViolationException exception) {
        Optional<ConstraintViolation<?>> error = exception.getConstraintViolations().stream().findFirst();
        if (error.isPresent()) {
            String[] errorMsg = error.get().getMessage().split(":");
            WSResponseRepresentation responseObject = new WSResponseRepresentation();
            WSAnswer answer = new WSAnswer();
            answer.setCode(errorMsg[0]);
            if (errorMsg.length > 1)
                answer.setDesignation(errorMsg[1]);
            responseObject.setAnswer(answer);
            logger.error("Error in CALCUL webservice request [{}]", answer.toString());
            LogErrorUtility.logTheError(logger, WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getRuleCode(),
                    WSRequestErrorCode.WEB_SERVICE_EXCEPTION.getDescription());
            return Response.status(Response.Status.BAD_REQUEST).entity(responseObject).build();
        }
        return null;
    }

}
