/*
 * Creation : 29 sept. 2017
 */
package com.inetpsa.w7t.domain.validation;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum WSRequestErrorCode.
 */
public enum WSRequestErrorCode implements ErrorCode {

    /** The progr country missing. */
    PROGR_COUNTRY_MISSING(204, "Program country missing in the extended title", "ERRW204"),

    /** The bcv exception. */
    WEB_SERVICE_EXCEPTION(600, "An exception occured, check webservice logs", "ERRW600"),

    /** The incorrect trade country. */
    INCORRECT_TRADE_COUNTRY(610, "Incorrect trading country", "ERRW610"),

    /** The bcv incorrect answer. */
    BCV_INCORRECT_ANSWER(612, "Incorrect answer from BCV", "ERRW612"),

    /** The bcv no answer. */
    BCV_NO_ANSWER(622, "No answer from BCV Web Service", "ERRW619"),

    /** The newton incorrect answer. */
    NEWTON_INCORRECT_ANSWER(613, "Incorrect answer from NEWTON", "ERRW613"),

    /** The newton no answer. */
    NEWTON_NO_ANSWER(615, "No answer from NEWTON Web Service", "ERRW615"),

    /** The Newton timeout exception. */
    NEWTON_TIMEOUT_EXCEPTION(623, "Newton Timeout exception occured", "ERRW620"),

    /** The bcv error. */
    BCV_ERROR(620, "Incorrect answer from BCV", "ERRW612"),

    /** The unknown web service exception. */
    CALCULATOR_EXCEPTION(650, "An exception occured, check webservice logs", "ERRW600"),

    /** The bcv timeout exception. */
    BCV_TIMEOUT_EXCEPTION(614, "BCV Timeout exception occured", "ERRW614"),

    /** The newton physical index not present. */
    NEWTON_PHYSICAL_INDEX_NOT_PRESENT(621, "The extended title does not contain the physical data index", "ERRW621"),

    /** The five c value incorrect. */
    FIVE_C_VALUE_INCORRECT(604, "Options5C or Gestion5C incorrect", "ERRW604"),

    /** The mtac missing. */
    MTAC_MISSING(207, "MTAC missing in the extended title", "ERRW207"),

    /** The fom missing. */
    FOM_MISSING(216, "Full options mass missing in the extended title", "ERRW216"),

    /** The emm missing. */
    EMM_MISSING(214, "Empty mass missing in the extended title", "ERRW214"),

    /** The unknown mtac. */
    UNKNOWN_MTAC(208, "MTAC value unknown", "ERRW208"),

    /** The unknown fom. */
    UNKNOWN_FOM(217, "Full options mass value unknown", "ERRW217"),

    /** The unknown emm. */
    UNKNOWN_EMM(215, "Empty mass value unknown", "ERRW215"),

    /** The extended title incorrect. */
    EXTENDED_TITLE_INCORRECT(104, "Extended title missing or incorrect", "ERRW104"),

    /** The unknown tvv. */
    UNKNOWN_TVV(218, "Unknown TVV", "ERRW218"),

    /** several TVV found. */
    SEVERAL_TVV(219, "Several TVV found", "ERRW219"),

    /** The incorrect conversion data. */
    INCORRECT_CONVERSION_DATA(649, "Incorrect conversion data", "ERRW649"),

    /** The missing mtac cc. */
    MISSING_MTACTR_CC(650, "MTAC of converted car missing or incorrect", "ERRW650"),
    /** The missing mopt cc. */
    MISSING_MOPTTR_CC(651, "Full option mass of converted car missing or incorrect", "ERRW651"),
    /** The missing cattr cc. */
    MISSING_CATTR_CC(652, "Category of converted car missing or incorrect", "ERRW652"),
    /** The missing mcor cc. */
    MISSING_MCOR_CC(653, "Corvet Mass of converted car missing or incorrect", "ERRW653"),
    /** The missing dmtr cc. */
    MISSING_DMTR_CC(654, "Delta Mass of converted car missing or incorrect", "ERRW654"),
    /** The missing crrtr cc. */
    MISSING_CRRTR_CC(656, "CRR of converted car missing or incorrect", "ERRW656"),

    /** The unknown request type. */
    UNKNOWN_REQUEST_TYPE(103, "Unknown request type", "ERRW103"),

    /** The ext date incorrect. */
    EXT_DATE_INCORRECT(606, "extension date incorrect", "ERRW606"),

    /** The missing depol. */
    MISSING_DEPOL(657, "DEPOL flag missing or incorrect", "ERRW657"),

    /** The missing special. */
    MISSING_SPECIAL(658, "SPECIAL flag missing or incorrect (DEPOL)", "ERRW658"),

    /** The missing real crr. */
    MISSING_REAL_CRR(659, "real CRR missing for converted car (DEPOL)", "ERRW659"),

    /** The incorrect cool str. */
    INCORRECT_COOL_STR(660, "incorrect cooling surface for converted car (DEPOL)", "ERRW660"),

    /** The incorrect str. */
    INCORRECT_STR(667, "incorrect frontal area for converted car (DEPOL)", "ERRW667"),

    /** The missing mass in running order. */
    MISSING_MASS_IN_RUNNING_ORDER(668, "mass in running order missing for converted car", "ERRW668");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new WS request error code.
     *
     * @param code the code
     * @param description the description
     * @param ruleCode the rule code
     */
    WSRequestErrorCode(int code, String description, String ruleCode) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Sets the rule code.
     *
     * @param ruleCode the new rule code
     */
    public void setRuleCode(String ruleCode) {
        this.ruleCode = ruleCode;
    }

}
