/*
 * Creation : 18 Feb 2019
 */
package com.inetpsa.w7t.batch.shared;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.seedstack.seed.SeedException;
import org.seedstack.shed.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.wltphub.ws.CalculatedData;
import com.inetpsa.w7t.wltphub.ws.CalculatedMeasure;
import com.inetpsa.w7t.wltphub.ws.CalculatedPhase;
import com.inetpsa.w7t.wltphub.ws.Calculation;
import com.inetpsa.w7t.wltphub.ws.Result;
import com.inetpsa.w7t.wltphub.ws.WSPhase;
import com.inetpsa.w7t.wltphub.ws.WSPhysicalResult;
import com.inetpsa.w7t.wltphub.ws.WSWltpData;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class MarketinDaemonCalculatorServiceImpl.
 */
public class MarketinDaemonCalculatorServiceImpl implements MarketingDaemonCalculatorService {
    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */

    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The Constant MASS_CODE. */
    public static final String MASS_CODE = "MASSE";

    /** The marketing daemon wltp hub service. */
    @Inject
    private MarketingDaemonWltpHubService marketingDaemonWltpHubService;

    /** The movement code 30 service. */
    @Inject
    private MovementCode30Service movementCode30Service;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#calculateAoGeosCronosEliade(com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto)
     */
    public AoCronosEliadeDto calculateAoGeosCronosEliade(AoCronosEliadeDto request) {
        AoCronosEliadeDto aoGeosDto = request;
        if (aoGeosDto != null) {
            try {

                if (aoGeosDto.getEcomDate() == null || aoGeosDto.getEcomDate().isEmpty())
                    aoGeosDto.setEcomDate(LocalDate.now().toString());

                MarketingRequest marketingRequest = new MarketingRequest();
                marketingRequest.setRequestID(aoGeosDto.getRequestId());
                marketingRequest.setStatus(aoGeosDto.getStatus());
                marketingRequest.setFileId(aoGeosDto.getFileId());

                Calculation calculation = null;
                StopWatch sw = new StopWatch();
                sw.start();
                WltpHubResponseRepresentation wltpHubResponseRepresentation = marketingDaemonWltpHubService.callWltpHubWebService(aoGeosDto);

                if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getRequest()
                        && StringUtils.isNotBlank(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes())) {
                    aoGeosDto.setExtAttr(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
                    movementCode30Service.mapW30Data(aoGeosDto);
                }

                calculation = convertToCalculationObject(wltpHubResponseRepresentation);
                sw.stop();
                logger.info("Request ID[{}]: Time took to call HUB web service {}ms", aoGeosDto.getRequestId(), sw.getTime());
                if (wltpHubResponseRepresentation != null && wltpHubResponseRepresentation.getWltpData() != null) {
                    WSWltpData wltpData = wltpHubResponseRepresentation.getWltpData();
                    aoGeosDto.setVehicleType(wltpData.getVehType());
                }

                if (wltpHubResponseRepresentation != null && wltpHubResponseRepresentation.getPhysResult() != null
                        && !wltpHubResponseRepresentation.getPhysResult().isEmpty()) {
                    String massValue = wltpHubResponseRepresentation.getPhysResult().stream().filter(x -> MASS_CODE.equals(x.getCode()))
                            .map(WSPhysicalResult::getValue) // convert stream to String
                            .findAny().orElse("");
                    aoGeosDto.setMasse(getNumericAnswerInFormat(MASS_CODE, Double.valueOf(massValue)));
                }
                // Jira-720 starts here
                if (wltpHubResponseRepresentation != null && wltpHubResponseRepresentation.getPhysResult() != null
                        && !wltpHubResponseRepresentation.getPhysResult().isEmpty()) {
                    String mtacValue = wltpHubResponseRepresentation.getPhysResult().stream()
                            .filter(x -> CalculationConstants.MTAC.equals(x.getCode())).map(WSPhysicalResult::getValue) // convert stream to String
                            .findAny().orElse("");
                    aoGeosDto.setW20MTACFiller(mtacValue);
                }
                if (wltpHubResponseRepresentation != null && wltpHubResponseRepresentation.getPhysResult() != null
                        && !wltpHubResponseRepresentation.getPhysResult().isEmpty()) {
                    String moptValue = wltpHubResponseRepresentation.getPhysResult().stream()
                            .filter(x -> CalculationConstants.MOPT.equals(x.getCode())).map(WSPhysicalResult::getValue) // convert stream to String
                            .findAny().orElse("");
                    aoGeosDto.setW20MOPTFiller(moptValue);
                }
                if (wltpHubResponseRepresentation != null && wltpHubResponseRepresentation.getPhysResult() != null
                        && !wltpHubResponseRepresentation.getPhysResult().isEmpty()) {
                    String emptymValue = wltpHubResponseRepresentation.getPhysResult().stream()
                            .filter(x -> CalculationConstants.EMPTYM.equals(x.getCode())).map(WSPhysicalResult::getValue) // convert stream to String
                            .findAny().orElse("");
                    aoGeosDto.setW20EMPTYMFiller(emptymValue);
                }
                // Jira-720 ends here

                if (calculation != null && calculation.getCalculatedData() != null
                        && calculation.getCalculatedData().getCalculatedPhases().isPresent()) {
                    Optional<List<CalculatedPhase>> optionalCalculatedPhasesList = calculation.getCalculatedData().getCalculatedPhases();
                    if (optionalCalculatedPhasesList.isPresent()) {

                        // Jira-719 and Jira-720 CR fix starts here.
                        if (aoGeosDto.getVehicleType().equalsIgnoreCase(AoCronoEliadeCalculationConstants.HYRE_VEHICLE_TYPE)
                                || aoGeosDto.getVehicleType().equalsIgnoreCase(AoCronoEliadeCalculationConstants.ELEC_VEHICLE_TYPE)) {
                            Optional<CalculatedPhase> cityPhaseResult = optionalCalculatedPhasesList.get().stream()
                                    .filter(cp -> "CITY".equals(cp.getPhaseCode())).findFirst();
                            aoGeosDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));

                            if (cityPhaseResult.isPresent()) {
                                List<CalculatedMeasure> emissions = cityPhaseResult.get().getEmissions();
                                emissions.forEach(calculatedMeasure -> {
                                    logger.debug("MeasureTypeCode :{} and Measure Value :{}", calculatedMeasure.getMeasureTypeCode(),
                                            calculatedMeasure.getValue());
                                    if (aoGeosDto.getVehicleType().equalsIgnoreCase(AoCronoEliadeCalculationConstants.HYRE_VEHICLE_TYPE)
                                            && calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.EAER)) {
                                        aoGeosDto.setW20EAERFiller(
                                                getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, calculatedMeasure.getValue())
                                                        .replace(".", ","));
                                    }
                                    if (aoGeosDto.getVehicleType().equalsIgnoreCase(AoCronoEliadeCalculationConstants.HYRE_VEHICLE_TYPE)
                                            && calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.AER)) {
                                        aoGeosDto.setW20AERFiller(
                                                getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, calculatedMeasure.getValue())
                                                        .replace(".", ","));
                                    }
                                    if (aoGeosDto.getVehicleType().equalsIgnoreCase(AoCronoEliadeCalculationConstants.ELEC_VEHICLE_TYPE)
                                            && calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.PER)) {
                                        aoGeosDto.setW20PERFiller(
                                                getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, calculatedMeasure.getValue())
                                                        .replace(".", ","));
                                    }
                                });
                            }
                        }
                        // Jira-719 and Jira-720 CR fix ends here.
                        Optional<CalculatedPhase> combinedPhaseResult = optionalCalculatedPhasesList.get().stream()
                                .filter(cp -> cp.getPhaseCode().equals(RequestType.COMB.name())).findFirst();
                        aoGeosDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));

                        if (combinedPhaseResult.isPresent()) {
                            List<CalculatedMeasure> emissions = combinedPhaseResult.get().getEmissions();
                            emissions.forEach(calculatedMeasure -> {
                                logger.debug("MeasureTypeCode :{} and Measure Value :{}", calculatedMeasure.getMeasureTypeCode(),
                                        calculatedMeasure.getValue());
                                if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CO2)) {
                                    aoGeosDto.setCalculatedCombCo2(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                    logger.info("Request ID[{}]: Emissions - Calcul - COMB - CO2 - {}", aoGeosDto.getRequestId(),
                                            aoGeosDto.getCalculatedCombCo2());
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.FC)) {
                                    aoGeosDto.setCalculatedCombFc(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FC, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.WCCO2)) {
                                    aoGeosDto.setWltpCondHybrideCombWCCO2(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCCO2, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.WCFC)) {
                                    aoGeosDto.setWltpCondHybridCombWCFC(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCFC, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.UFEC)) {
                                    aoGeosDto.setWltpElectricEnergyConsumptionCombUFEC(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFEC, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.EAER)) {
                                    aoGeosDto.setWltpAllElectricRangeCombEAER(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CO2B)) {
                                    aoGeosDto.setWltpInj2CondCombCO2B(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2B, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.FCB)) {
                                    aoGeosDto.setWltpInj2CondCombFCB(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCB, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CO2G)) {
                                    aoGeosDto.setWltpGazCondCombCO2G(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2G, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.FCG)) {
                                    aoGeosDto.setWltpGazCondCombFCG(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCG, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.EC)) {

                                    aoGeosDto.setWltpElectricEnergyConsumptionCombEC(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EC, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.PER)) {
                                    aoGeosDto.setWltpElectricRangeCombPER(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.FCCD)) {
                                    aoGeosDto.setWltpCombFCCD(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCCD, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CRCD)) {
                                    aoGeosDto.setWltpCombCRCD(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CRCD, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.AERCD)) {
                                    aoGeosDto.setWltpCombAERCD(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AERCD, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.FCCS)) {
                                    aoGeosDto.setWltpCombFCCS(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCCS, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CO2CD)) {
                                    aoGeosDto.setWltpCombCO2CD(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2CD, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CO2CS)) {

                                    aoGeosDto.setWltpCombCO2CS(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2CS, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.CE)) {
                                    aoGeosDto.setWltpCombCE(getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CE, calculatedMeasure.getValue())
                                            .replace(".", ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.UFECC)) {
                                    aoGeosDto.setWltpCombUFECC(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFECC, calculatedMeasure.getValue()).replace(".",
                                                    ","));

                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.AER)) {
                                    aoGeosDto.setWltpCombAER(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                } else if (calculatedMeasure.getMeasureTypeCode().equalsIgnoreCase(AoCronoEliadeCalculationConstants.ECCD)) {
                                    aoGeosDto.setWltpCombECCD(
                                            getPhaseResultInFormat(AoCronoEliadeCalculationConstants.ECCD, calculatedMeasure.getValue()).replace(".",
                                                    ","));
                                }

                            });

                        }

                    }

                } else if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getAnswer()
                        && StringUtils.isNotBlank(wltpHubResponseRepresentation.getAnswer().getCode())
                        && !wltpHubResponseRepresentation.getAnswer().getCode().startsWith("OK")) {
                    aoGeosDto.setValidityDate("");
                    aoGeosDto.setCalculatedCombCo2("");
                    aoGeosDto.setCalculatedCombFc("");
                    if (wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW700")
                            || wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW701")
                            || wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW702")) {
                        aoGeosDto.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    } else {
                        aoGeosDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()));
                    }
                    aoGeosDto.setAnswerCode(wltpHubResponseRepresentation.getAnswer().getCode());
                    aoGeosDto.setAnswerDesignation(wltpHubResponseRepresentation.getAnswer().getDesignation());
                    aoGeosDto.setAnswerDate(MarketingDateUtil.getTodaysDate());
                }

            } catch (SeedException se) {

                ErrorCode errorCode = se.getErrorCode();
                String ruleCode = "";
                String errordescription = "";
                if (errorCode instanceof WltpErrorCode) {
                    WltpErrorCode wltpErrorCode = (WltpErrorCode) errorCode;
                    ruleCode = ERRW + wltpErrorCode.getRuleCode();
                    errordescription = wltpErrorCode.getDescription();

                } else if (errorCode instanceof WltpEngineCalculatorErrorCode) {
                    WltpEngineCalculatorErrorCode engineCalculatorErrorCode = (WltpEngineCalculatorErrorCode) errorCode;
                    ruleCode = ERRW + engineCalculatorErrorCode.getRuleCode();
                    errordescription = engineCalculatorErrorCode.getDescription();
                }

                aoGeosDto.setValidityDate("");
                aoGeosDto.setCalculatedCombCo2("");
                aoGeosDto.setCalculatedCombFc("");
                aoGeosDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()));
                aoGeosDto.setAnswerCode(ruleCode);
                aoGeosDto.setAnswerDesignation(errordescription);
                aoGeosDto.setAnswerDate(MarketingDateUtil.getTodaysDate());
                return aoGeosDto;
            }

        }
        return aoGeosDto;

    }

    /**
     * Convert to calculation object.
     *
     * @param wltpHubResponseRepresentation the wltp hub response representation
     * @return the calculation
     */
    private Calculation convertToCalculationObject(WltpHubResponseRepresentation wltpHubResponseRepresentation) {
        Calculation calculation = new Calculation();
        CalculatedData calculatedData = new CalculatedData();
        if (wltpHubResponseRepresentation != null) {
            List<WSPhase> list = wltpHubResponseRepresentation.getPhase();
            List<CalculatedPhase> calculatedPhases = new ArrayList<>();
            if (list != null && !list.isEmpty()) {
                for (WSPhase wsPhase : list) {
                    CalculatedPhase phase = new CalculatedPhase(wsPhase.getCode());
                    List<Result> resultList = wsPhase.getResult();
                    for (Result result : resultList) {

                        phase.addEmission(result.getCode(), new BigDecimal(result.getValue()));
                    }
                    calculatedPhases.add(phase);

                }
                calculatedData.setCalculatedPhases(calculatedPhases);
            }
            calculation.setCalculatedData(calculatedData);
        }
        return calculation;
    }

    /**
     * Gets the phase result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, BigDecimal value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        BigDecimal roundedValue = value.setScale(roundingDigit, RoundingMode.HALF_UP);
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the numeric answer in format.
     *
     * @param code the code
     * @param value the value
     * @return the numeric answer in format
     */
    private String getNumericAnswerInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.FRANCE);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = 0;
        if (pattern.length() < 2)
            scale = 0;
        else
            scale = pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateMarketingRequestCalculationStatus(java.lang.String, java.lang.String,
     *      java.lang.String, java.lang.String, java.lang.String)
     */
    public void updateMarketingRequestCalculationStatus(String requestId, String answerCode, String answerDesig, String previousStatus,
            String status) {
        MarketingRequest marketingRequest = new MarketingRequest();
        marketingRequest.setRequestID(requestId);

        updatedMRQCalculationDetails(requestId, answerCode, answerDesig, status, previousStatus);

    }

    /**
     * Updated MRQ calculation details.
     *
     * @param requestId the request id
     * @param answerCode the answer code
     * @param answerDesig the answer desig
     * @param status the status
     * @param previousStatus the previous status
     */
    private void updatedMRQCalculationDetails(String requestId, String answerCode, String answerDesig, String status, String previousStatus) {
        int updatedDetailsInMRQ = marketingRequestRepository.updateMarketingRequestCalculationDetails(requestId, answerCode, answerDesig, status);
        if (updatedDetailsInMRQ > 0) {
            logger.info(MARKETING_STATUS_CHANGE_LOG, requestId, previousStatus, status);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateAnswerSentStatus(com.inetpsa.w7t.domain.model.dto.BcvNewtonRequestDto)
     */
    public void updateAnswerSentStatus(MarketingRequestDto answerDto) {
        if (answerDto != null) {
            // updatedBRQ(answerDto, String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
            updatedMRQ(answerDto, String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), true);
        }

    }

    /**
     * Updated MRQ.
     *
     * @param answerDto the answer dto
     * @param status the status
     * @param isAnsSent the is ans sent
     */
    private void updatedMRQ(MarketingRequestDto answerDto, String status, boolean isAnsSent) {
        int updatedMRQ = marketingRequestRepository.updateAnswerSentStatusInMRQ(answerDto.getRequestID(), status, isAnsSent);
        if (updatedMRQ > 0) {
            logger.info(MARKETING_STATUS_CHANGE_LOG, answerDto.getRequestID(), answerDto.getStatus(), status);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateAnswerSentStatus(java.util.List)
     */
    @Override
    public void updateAnswerSentStatus(List<MarketingRequest> marketingRequestList) {
        marketingRequestRepository.updateAnswerSentStatus(marketingRequestList);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateAnswerDetails(java.util.List)
     */
    @Override
    public void updateAnswerDetails(List<MarketingRequestDto> marketingRequestDtosList) {
        marketingRequestRepository.updateAnswerDetailsMRQ(marketingRequestDtosList);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateStatusCalculationStatusInMRQBRQ(java.util.List)
     */
    @Override
    public void updateStatusCalculationStatusInMRQBRQ(List<CalculationStatusDto> calculationStatusDtoList) {
        marketingRequestRepository.updateCalculationStatusDetailsInMRQ(calculationStatusDtoList);

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService#updateStatusCalculationStatusInMRQ(java.util.List)
     */
    @Override
    public void updateStatusCalculationStatusInMRQ(List<CalculationStatusDto> calculationStatusOKList) {
        marketingRequestRepository.updateCalculationStatusDetailsInMRQ(calculationStatusOKList);

    }

}
