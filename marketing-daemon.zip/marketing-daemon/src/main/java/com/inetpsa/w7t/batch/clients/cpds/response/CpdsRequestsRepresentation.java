/*
 * Creation : 27 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

/**
 * The Class CpdsRequestsRepresentation.
 */
public class CpdsRequestsRepresentation {

    /** The request. */
    private CpdsRequestRepresentation request;

    /**
     * Instantiates a new cpds requests representation.
     */
    public CpdsRequestsRepresentation() {
        super();
    }

    /**
     * Gets the request.
     *
     * @return the request
     */
    public CpdsRequestRepresentation getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(CpdsRequestRepresentation request) {
        this.request = request;
    }

}
