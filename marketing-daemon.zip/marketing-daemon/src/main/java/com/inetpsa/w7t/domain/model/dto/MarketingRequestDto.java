/*
 * Creation : 24 Feb 2021
 */
package com.inetpsa.w7t.domain.model.dto;

import org.seedstack.business.assembler.DtoOf;

import com.inetpsa.w7t.batch.clients.cfgmot2.response.CfgMot2JsonResponse;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaXmlAnswerResponse;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * The Class MarketingRequestDto.
 */
@DtoOf(MarketingRequest.class)
public class MarketingRequestDto {

    /** The internal req id. */
    private String internalReqId = "";

    /** The request ID. */
    private String requestID = "";

    /** The answer date. */
    private String answerDate = "";

    /** The answer code. */
    private String answerCode = "";

    /** The answer desig. */
    private String answerDesig = "";

    /** The Version 16. */
    private String Version16;

    /** The color ext int. */
    private String colorExtInt = "";

    /** The options. */
    private String options = "";

    /** The options 5 C. */
    private String options5C = "";

    /** The options 7 C. */
    private String options7C = "";

    /** The gestion 5 C. */
    private String gestion5C = "";

    /** The gestion 7 C. */
    private String gestion7C = "";

    /** The trading country. */
    private String tradingCountry = "";

    /** The brand. */
    private String brand = "";

    /** The extension date. */
    private String extensionDate = "";

    /** The request type. */
    private String requestType = "";

    /** The request date. */
    private String requestDate = "";

    /** The mounting center. */
    private String mountingCenter = "";

    /** The gestion. */
    private String gestion = "";

    /** The status. */
    private String status = "";

    /** The is answer sent. */
    private Boolean isAnswerSent = false;

    /** The client. */
    private String client = "";

    /** The file id. */
    private String fileId = "";

    /** The sending site. */
    private String sendingSite = "";

    /** The sending application. */
    private String sendingApplication = "";

    /** The lot number. */
    private String lotNumber = "";

    /** The lot date. */
    private String lotDate = "";

    /** The maturity. */
    private String maturity = "";

    /** The cfg mot 2 json response. */
    private CfgMot2JsonResponse cfgMot2JsonResponse;

    /** The toyota xml answer response. */
    private ToyotaXmlAnswerResponse toyotaXmlAnswerResponse;

    /**
     * Gets the toyota xml answer response.
     *
     * @return the toyota xml answer response
     */
    public ToyotaXmlAnswerResponse getToyotaXmlAnswerResponse() {
        return toyotaXmlAnswerResponse;
    }

    /**
     * Sets the toyota xml answer response.
     *
     * @param toyotaXmlAnswerResponse the new toyota xml answer response
     */
    public void setToyotaXmlAnswerResponse(ToyotaXmlAnswerResponse toyotaXmlAnswerResponse) {
        this.toyotaXmlAnswerResponse = toyotaXmlAnswerResponse;
    }

    /**
     * Gets the cfg mot 2 json response.
     *
     * @return the cfg mot 2 json response
     */
    public CfgMot2JsonResponse getCfgMot2JsonResponse() {
        return cfgMot2JsonResponse;
    }

    /**
     * Gets the maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Sets the maturity.
     *
     * @param maturity the new maturity
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * Gets the internal req id.
     *
     * @return the internal req id
     */
    public String getInternalReqId() {
        return internalReqId;
    }

    /**
     * Sets the internal req id.
     *
     * @param internalReqId the new internal req id
     */
    public void setInternalReqId(String internalReqId) {
        this.internalReqId = internalReqId;
    }

    /**
     * Gets the sending site.
     *
     * @return the sending site
     */
    public String getSendingSite() {
        return sendingSite;
    }

    /**
     * Sets the sending site.
     *
     * @param sendingSite the new sending site
     */
    public void setSendingSite(String sendingSite) {
        this.sendingSite = sendingSite;
    }

    /**
     * Gets the sending application.
     *
     * @return the sending application
     */
    public String getSendingApplication() {
        return sendingApplication;
    }

    /**
     * Sets the sending application.
     *
     * @param sendingApplication the new sending application
     */
    public void setSendingApplication(String sendingApplication) {
        this.sendingApplication = sendingApplication;
    }

    /**
     * Gets the lot number.
     *
     * @return the lot number
     */
    public String getLotNumber() {
        return lotNumber;
    }

    /**
     * Sets the lot number.
     *
     * @param lotNumber the new lot number
     */
    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    /**
     * Gets the lot date.
     *
     * @return the lot date
     */
    public String getLotDate() {
        return lotDate;
    }

    /**
     * Sets the lot date.
     *
     * @param lotDate the new lot date
     */
    public void setLotDate(String lotDate) {
        this.lotDate = lotDate;
    }

    /**
     * Gets the request ID.
     *
     * @return the request ID
     */
    public String getRequestID() {
        return requestID;
    }

    /**
     * Sets the request ID.
     *
     * @param requestID the new request ID
     */
    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    /**
     * Gets the version 16.
     *
     * @return the version 16
     */
    public String getVersion16() {
        return Version16;
    }

    /**
     * Sets the version 16.
     *
     * @param version16 the new version 16
     */
    public void setVersion16(String version16) {
        Version16 = version16;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public String getOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(String options) {
        this.options = options;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options 7 C.
     *
     * @return the options 7 C
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options 7 C.
     *
     * @param options7c the new options 7 C
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the gestion 5 C.
     *
     * @return the gestion 5 C
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion 5 C.
     *
     * @param gestion5c the new gestion 5 C
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion 7 C.
     *
     * @return the gestion 7 C
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion 7 C.
     *
     * @param gestion7c the new gestion 7 C
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the brand.
     *
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the brand.
     *
     * @param brand the new brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the mounting center.
     *
     * @return the mounting center
     */
    public String getMountingCenter() {
        return mountingCenter;
    }

    /**
     * Sets the mounting center.
     *
     * @param mountingCenter the new mounting center
     */
    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    /**
     * Gets the gestion.
     *
     * @return the gestion
     */
    public String getGestion() {
        return gestion;
    }

    /**
     * Sets the gestion.
     *
     * @param gestion the new gestion
     */
    public void setGestion(String gestion) {
        this.gestion = gestion;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Checks if is answer sent.
     *
     * @return true, if is answer sent
     */
    public boolean isAnswerSent() {
        return isAnswerSent;
    }

    /**
     * Sets the answer sent.
     *
     * @param isAnswerSent the new answer sent
     */
    public void setAnswerSent(boolean isAnswerSent) {
        this.isAnswerSent = isAnswerSent;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Instantiates a new marketing request dto.
     */
    public MarketingRequestDto() {

    }

    /**
     * Getter answerDate.
     *
     * @return the answerDate
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Setter answerDate.
     *
     * @param answerDate the answerDate to set
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Getter answerCode.
     *
     * @return the answerCode
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Setter answerCode.
     *
     * @param answerCode the answerCode to set
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Getter answerDesig.
     *
     * @return the answerDesig
     */
    public String getAnswerDesig() {
        return answerDesig;
    }

    /**
     * Setter answerDesig.
     *
     * @param answerDesig the answerDesig to set
     */
    public void setAnswerDesig(String answerDesig) {
        this.answerDesig = answerDesig;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MarketingRequestDto [internalReqId=" + internalReqId + ", requestID=" + requestID + ", answerDate=" + answerDate + ", answerCode="
                + answerCode + ", answerDesig=" + answerDesig + ", Version16=" + Version16 + ", colorExtInt=" + colorExtInt + ", options=" + options
                + ", options5C=" + options5C + ", options7C=" + options7C + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C
                + ", tradingCountry=" + tradingCountry + ", brand=" + brand + ", extensionDate=" + extensionDate + ", requestType=" + requestType
                + ", requestDate=" + requestDate + ", mountingCenter=" + mountingCenter + ", gestion=" + gestion + ", status=" + status
                + ", isAnswerSent=" + isAnswerSent + ", client=" + client + ", fileId=" + fileId + ", sendingSite=" + sendingSite
                + ", sendingApplication=" + sendingApplication + ", lotNumber=" + lotNumber + ", lotDate=" + lotDate + ", maturity=" + maturity + "]";
    }

}
