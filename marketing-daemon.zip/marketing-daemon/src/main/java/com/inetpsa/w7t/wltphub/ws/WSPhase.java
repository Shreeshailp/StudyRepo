/*
 * Creation : 2 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

import java.util.List;

/**
 * The Class WSPhase.
 */
public class WSPhase {
    /** The code. */
    private String code;

    /** The result. */
    private List<Result> result;

    /**
     * The Class Result.
     */

    public WSPhase() {
        // default
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the result.
     *
     * @return the result
     */
    public List<Result> getResult() {
        return result;
    }

    /**
     * Sets the result.
     *
     * @param result the new result
     */
    public void setResult(List<Result> result) {
        this.result = result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "HubPhase [code=" + code + ", result=" + result + "]";
    }

}
