/*
 * Creation : 2 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.infrastructure;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.business.domain.Read;

import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;

/**
 * The Interface MarketingRequestRepository.
 *
 * @author E534811
 */
public interface MarketingRequestRepository extends GenericRepository<MarketingRequest, String> {

    /**
     * Bytoday last request.
     *
     * @param today the today
     * @param clientName the client name
     * @return the optional
     */
    @Read
    Optional<MarketingRequest> bytodayLastRequest(String today, String clientName);

    /**
     * By semi extende title.
     *
     * @param version16c the version 16 c
     * @param colorExtInt the color ext int
     * @param extensionDate the extension date
     * @param options7c the options 7 c
     * @param today the today
     * @return the list
     */
    @Read
    List<MarketingRequest> bySemiExtendeTitle(String version16c, String colorExtInt, String extensionDate, String options7c, String today);

    /**
     * By request id.
     *
     * @param requestId the request id
     * @return the marketing request
     */
    MarketingRequest byRequestId(String requestId);

    /**
     * Save entity.
     *
     * @param marketingRequest the marketing request
     */
    void saveEntity(MarketingRequest marketingRequest);

    /**
     * Save records batchwise.
     *
     * @param marketingRequestList the marketing request list
     */
    void saveRecordsBatchwise(List<MarketingRequest> marketingRequestList);

    /**
     * By file id.
     *
     * @param fileId the file id
     * @return the optional
     */
    @Read
    Optional<MarketingRequest> byFileId(String fileId);

    /**
     * By client request id.
     *
     * @param requestId the request id
     * @param clientName the client name
     * @return the optional
     */
    @Read
    Optional<MarketingRequest> byClientRequestId(String requestId, String clientName);

    /**
     * By status code.
     *
     * @param status the status
     * @return the list
     */
    @Read
    List<MarketingRequest> byStatusCode(String status);

    /**
     * By client and status.
     *
     * @param client the client
     * @param status the status
     * @return the list
     */
    @Read
    List<MarketingRequest> byClientAndStatus(String client, String status);

    /**
     * By client and status and file id.
     *
     * @param client the client
     * @param status the status
     * @param fileId the file id
     * @return the list
     */
    @Read
    List<MarketingRequest> byClientAndStatusAndFileId(String client, String status, String fileId);

    /**
     * Update status by internal request id.
     *
     * @param status the status
     * @param internalRequestId the internal request id
     * @return the int
     */
    int updateStatusByInternalRequestId(String status, String internalRequestId);

    /**
     * Update by request id.
     *
     * @param valueOf the value of
     * @param requestId the request id
     * @param b the b
     * @param todaysDate the todays date
     * @return the int
     */
    int updateByRequestId(String valueOf, String requestId, boolean b, String todaysDate);

    /**
     * Update by req id.
     *
     * @param valueOf the value of
     * @param requestId the request id
     * @param b the b
     * @param todaysDate the todays date
     * @return the int
     */
    int updateByReqId(String valueOf, String requestId, boolean b, String todaysDate);

    /**
     * By file id and status and bcv req count and limit.
     *
     * @param fileId the file id
     * @param statusList the status list
     * @param brqCount the brq count
     * @param startPosition the start position
     * @param limit the limit
     * @return the list
     */
    @Read
    List<MarketingRequest> byFileIdAndStatusAndBcvReqCountAndLimit(String fileId, List<String> statusList, Long brqCount, int startPosition,
            int limit);

    /**
     * Update answer sent status in MRQ.
     *
     * @param requestId the request id
     * @param status the status
     * @param isAnswerSent the is answer sent
     * @return the int
     */
    int updateAnswerSentStatusInMRQ(String requestId, String status, boolean isAnswerSent);

    /**
     * Update marketing request calculation details.
     *
     * @param requestId the request id
     * @param answerCode the answer code
     * @param answerDesig the answer desig
     * @param status the status
     * @return the int
     */
    int updateMarketingRequestCalculationDetails(String requestId, String answerCode, String answerDesig, String status);

    /**
     * Gets the marketing requests by file id.
     *
     * @param client the client
     * @param fileId the file id
     * @return the marketing requests by file id
     */
    @Read
    List<MarketingRequest> getMarketingRequestsByFileId(String client, String fileId);

    /**
     * By request id with native.
     *
     * @param requestId the request id
     * @return true, if successful
     */
    @Read
    boolean byRequestIdWithNative(String requestId);

    /**
     * Persist entity.
     *
     * @param marketingRequest the marketing request
     */
    void persistEntity(MarketingRequest marketingRequest);

    /**
     * By internal request id.
     *
     * @param internalRequestId the internal request id
     * @return the marketing request
     */
    public MarketingRequest byInternalRequestId(String internalRequestId);

    /**
     * Update by req id.
     *
     * @param status the status
     * @param requestId the request id
     * @return the int
     */
    int updateByReqId(String status, String requestId);

    /**
     * Save marketing request.
     *
     * @param marketingRequestList the marketing request list
     * @param threadPoolMasterRepository the thread pool master repository
     */
    void saveMarketingRequest(List<MarketingRequest> marketingRequestList, ThreadPoolMasterRepository threadPoolMasterRepository);

    /**
     * Update by request.
     *
     * @param list the list
     * @param string the string
     */
    void updateByRequest(List<MarketingRequest> list, String string);

    /**
     * Persist entity batch.
     *
     * @param list the list
     */
    void persistEntityBatch(List<MarketingRequest> list);

    /**
     * Update status calculation ok in MRQ.
     *
     * @param mrqIdsStatus the mrq ids status
     * @param status the status
     * @param answerCode the answer code
     * @param answerDesig the answer desig
     */
    void updateStatusCalculationOkInMRQ(List<String[]> mrqIdsStatus, String status, String answerCode, String answerDesig);

    /**
     * Update answer sent status.
     *
     * @param marketingRequestList the marketing request list
     */
    void updateAnswerSentStatus(List<MarketingRequest> marketingRequestList);

    /**
     * Update answer details MRQ.
     *
     * @param marketingRequestDtosList the marketing request dtos list
     */
    void updateAnswerDetailsMRQ(List<MarketingRequestDto> marketingRequestDtosList);

    /**
     * Update calculation status details in MRQ.
     *
     * @param calculationStatusDtoList the calculation status dto list
     */
    void updateCalculationStatusDetailsInMRQ(List<CalculationStatusDto> calculationStatusDtoList);

    /**
     * By file ID request id.
     *
     * @param reqId the req id
     * @param fileId the file id
     * @return the marketing request
     */
    MarketingRequest byFileIDRequestId(String reqId, String fileId);

    /**
     * By file id and status and mrq count and limit.
     *
     * @param fileId the file id
     * @param statusList the status list
     * @param mrqCount the mrq count
     * @param offset the offset
     * @param chunkSize the chunk size
     * @return the list
     */
    @Read
    List<MarketingRequest> byFileIdAndStatusAndMrqCountAndLimit(String fileId, List<String> statusList, long mrqCount, int offset, int chunkSize);

}
