/*
 * Creation : 19 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.validations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * The Interface AcceptedValues.
 *
 * @author E534811
 */
@Documented
@Constraint(validatedBy = AcceptedValidator.class)
@Target({ ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface AcceptedValues {

    /**
     * Accept values.
     *
     * @return the string[]
     */
    String[] acceptValues();

    /**
     * Message.
     *
     * @return the string
     */
    String message() default "Not allowded value";

    /**
     * Groups.
     *
     * @return the class[]
     */
    Class<?>[] groups() default {};

    /**
     * Payload.
     *
     * @return the class<? extends payload>[]
     */
    Class<? extends Payload>[] payload() default {};
}
