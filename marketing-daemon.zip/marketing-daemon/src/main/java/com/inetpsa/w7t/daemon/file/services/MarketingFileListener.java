/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services;

import org.seedstack.business.Producible;
import org.seedstack.business.Service;
import org.seedstack.business.domain.DomainObject;

/**
 * The listener interface for receiving marketingFile events. The class that is interested in processing a marketingFile event implements this
 * interface, and the object created with that class is registered with a component using the component's <code>addMarketingFileListener<code> method.
 * When the marketingFile event occurs, that object's appropriate method is invoked.
 *
 * @see MarketingFileEvent
 */
@Service
@FunctionalInterface
public interface MarketingFileListener extends Runnable, DomainObject, Producible {
}
