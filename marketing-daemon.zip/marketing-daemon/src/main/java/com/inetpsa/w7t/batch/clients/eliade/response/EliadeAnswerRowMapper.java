/*
 * Creation : 21 Apr 2020
 */
package com.inetpsa.w7t.batch.clients.eliade.response;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.domain.model.MarketingRequestTracker;

/**
 * The Class EliadeAnswerRowMapper.
 */
public class EliadeAnswerRowMapper implements RowMapper<MarketingRequestTracker> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public MarketingRequestTracker mapRow(ResultSet rs, int rowNum) throws SQLException {
        MarketingRequestTracker request = new MarketingRequestTracker();
        request.setClient(rs.getString("CLIENT"));
        request.setFileId(rs.getString("FILE_ID"));
        request.setMrqCount(rs.getLong("MRQ_COUNT"));
        request.setValidReqCount(rs.getLong("VALID_REQ_COUNT"));
        return request;
    }

}
