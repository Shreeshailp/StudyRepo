/*
 * Creation : 13 Feb 2019
 */
package com.inetpsa.w7t.batch.common;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

/**
 * class using for common methods.
 */
public final class CommonUtil {

    /**
     * Instantiates a new common util.
     */
    private CommonUtil() {

    }

    /**
     * method for date converting string to time stamp format.
     */

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Date conversion from string.
     *
     * @param date the date
     * @return the timestamp
     * @throws ParseException the parse exception
     */
    public static Timestamp dateConversionFromString(String date) throws ParseException {
        return new Timestamp((new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSSSSS").parse(date)).getTime());
    }

    /**
     * method for date converting string to time stamp format.
     *
     * @param date the date
     * @return the timestamp
     * @throws ParseException the parse exception
     */
    public static Timestamp dateConversionFromStringForLMNMDL(String date) throws ParseException {
        return new Timestamp((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS").parse(date)).getTime());
    }

    /**
     * method for date converting date to time stamp format.
     *
     * @return today date
     */
    public static Timestamp getCreatedDate() {
        return new Timestamp(new java.util.Date().getTime());
    }

    /**
     * Gets the today date.
     *
     * @return the today date
     */
    public static Date getTodayDate() {
        return new java.sql.Date(new java.util.Date().getTime());
    }

    /**
     * Gets the today date as string.
     *
     * @return the today date as string
     */
    public static String getTodayDateAsString() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    /**
     * method return next date in sql farmat.
     *
     * @return the date
     */
    public static Date nextDay() {
        Calendar c = Calendar.getInstance();
        c.setTime(new java.util.Date());
        c.add(Calendar.DATE, 1);
        java.util.Date date1 = c.getTime();
        return convertUtilToSql(date1);
    }

    /**
     * method converts util date to sql date.
     *
     * @param uDate the u date
     * @return the java.sql. date
     */
    public static java.sql.Date convertUtilToSql(java.util.Date uDate) {
        java.sql.Date sDate = null;
        if (uDate != null) {
            sDate = new java.sql.Date(uDate.getTime());
        }
        return sDate;
    }

    /**
     * convet sql date to util date.
     *
     * @param sqlDate the sql date
     * @return the java.util. date
     */
    public static java.util.Date convertSqlToUtil(java.sql.Date sqlDate) {
        java.util.Date uDate = null;
        if (sqlDate != null) {
            uDate = new java.util.Date(sqlDate.getTime());
        }
        return uDate;
    }

    /**
     * convert localdate format to util date format.
     *
     * @param date the date
     * @return the java.util. date
     */
    public static java.util.Date fromLocalDate(LocalDate date) {
        Instant instant = date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
        return java.util.Date.from(instant);
    }

    /**
     * return only date part from util date.
     *
     * @param utilDate the util date
     * @return the date part only
     */
    public static java.util.Date getDatePartOnly(java.util.Date utilDate) {

        Calendar cal = Calendar.getInstance();
        cal.setTime(utilDate);

        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        utilDate = cal.getTime();
        return utilDate;
    }
}
