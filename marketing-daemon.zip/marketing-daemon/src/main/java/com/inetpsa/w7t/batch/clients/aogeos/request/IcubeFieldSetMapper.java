/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

/**
 * The Class IcubeFieldSetMapper.
 */
public class IcubeFieldSetMapper implements FieldSetMapper<IcubeRequestDTO> {
    /** The file id. */
    private String fileId;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Retrieve interstep data.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void retrieveInterstepData(StepExecution stepExecution) {
        this.fileId = stepExecution.getJobExecution().getExecutionContext().get("FILE_ID").toString();
        this.uniqueIdentifier = stepExecution.getJobExecution().getExecutionContext().get("UNIQUE_IDENTIFIER").toString();
        // jira-660 fix
        this.fsFlagFileName = stepExecution.getJobExecution().getExecutionContext().get("FS_FLAG_FILE_NAME").toString();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.file.mapping.FieldSetMapper#mapFieldSet(org.springframework.batch.item.file.transform.FieldSet)
     */
    @Override
    public IcubeRequestDTO mapFieldSet(FieldSet fieldSet) throws BindException {

        IcubeRequestDTO icubeRequestResponse = new IcubeRequestDTO();
        icubeRequestResponse.setMovementCode(fieldSet.readRawString("movementCode"));
        icubeRequestResponse.setLotNumber(fieldSet.readRawString("lotNumber"));
        icubeRequestResponse.setLineNumber(fieldSet.readRawString("lineNumber"));
        icubeRequestResponse.setPrd(fieldSet.readRawString("prd"));
        icubeRequestResponse.setBrand(fieldSet.readRawString("brand"));
        icubeRequestResponse.setExtensionDate(fieldSet.readRawString("extensionDate").trim());
        icubeRequestResponse.setHabillage_Ext(fieldSet.readRawString("habillage_Ext"));
        String options7c = fieldSet.readRawString("options7c").trim();
        String gestion7c = fieldSet.readRawString("gestion");
        icubeRequestResponse.setOptions7c(options7c);
        icubeRequestResponse.setGestion7c(gestion7c);
        icubeRequestResponse.setVersion(fieldSet.readRawString("version"));
        icubeRequestResponse.setHabillage_Int(fieldSet.readRawString("habillage_Int"));
        icubeRequestResponse.setCountry(fieldSet.readRawString("country"));
        icubeRequestResponse.setFiller(fieldSet.readRawString("filler").trim());
        String requestId = icubeRequestResponse.getPrd() + icubeRequestResponse.getLotNumber() + icubeRequestResponse.getLineNumber();
        icubeRequestResponse.setRequestId(requestId);
        icubeRequestResponse.setFileId(this.fileId);
        icubeRequestResponse.setUniqueIdentifier(this.uniqueIdentifier);
        // jira-660 fix
        icubeRequestResponse.setFsFlagFileName(this.fsFlagFileName);
        return icubeRequestResponse;
    }

}
