package com.inetpsa.w7t.batch.clients.eliade.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class EliadeFlatFileResource.
 */
public class EliadeFlatFileResource extends FileSystemResource {

    /**
     * Instantiates a new eliade flat file resource.
     *
     * @param path the path
     * @param eliadeFileName the eliade file name
     */
    public EliadeFlatFileResource(String path, String eliadeFileName) {
        super(path + File.separator + eliadeFileName);
    }
}
