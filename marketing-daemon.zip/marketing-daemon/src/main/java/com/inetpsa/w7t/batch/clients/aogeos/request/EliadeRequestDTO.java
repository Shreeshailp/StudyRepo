/*
 * Creation : 5 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The Class AoGeosRequestResponseDTO.
 */
public class EliadeRequestDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The movement code. */
    private String movementCode;

    /** The prd. */
    @NotNull(message = AoCronoRequestErrorCode.PRD_CODE_INCORRECT)
    @Size(min = 3, max = 3, message = AoCronoRequestErrorCode.PRD_CODE_INCORRECT)
    private String prd;

    /** The lot number. */
    @NotNull(message = AoCronoRequestErrorCode.LOTNUMBER_INCORRECT)
    @Size(min = 5, max = 5, message = AoCronoRequestErrorCode.LOTNUMBER_INCORRECT)
    private String lotNumber;

    /** The line number. */
    @NotNull(message = AoCronoRequestErrorCode.LINENUMBER_INCORRECT)
    @Size(min = 12, max = 12, message = AoCronoRequestErrorCode.LINENUMBER_INCORRECT)
    private String lineNumber;

    /** The brand. */
    @NotNull(message = AoCronoRequestErrorCode.BRAND_INCORRECT)
    @Size(min = 2, max = 2, message = AoCronoRequestErrorCode.BRAND_INCORRECT)
    private String brand;

    /** The country. */
    @NotNull(message = AoCronoRequestErrorCode.COUNTRY_CODE_INCORRECT)
    @Size(min = 2, max = 2, message = AoCronoRequestErrorCode.COUNTRY_CODE_INCORRECT)
    private String country;

    /** The version. */
    private String version;

    /** The habillage ext. */
    @NotNull(message = AoCronoRequestErrorCode.HABILLAGE_EXT_INCORRECT)
    @Size(min = 4, max = 4, message = AoCronoRequestErrorCode.HABILLAGE_EXT_INCORRECT)
    private String habillage_Ext;

    /** The habillage int. */
    @NotNull(message = AoCronoRequestErrorCode.HABILLAGE_INT_INCORRECT)
    @Size(min = 4, max = 4, message = AoCronoRequestErrorCode.HABILLAGE_INT_INCORRECT)
    private String habillage_Int;

    /** The options 7 C. */
    private String options7c;
    /** The gestion. */
    private String gestion;
    /** The extension date. */
    private String extensionDate;

    /** The filler. */
    private String filler;

    /** The status. */
    private String status;

    /** The answer code. */
    private String answerCode;

    /** The answer designation. */
    private String answerDesignation;

    /** The answer Date. */
    private String answerDate;

    /** The is answer sent. */
    private boolean isAnswerSent = false;

    /** The options. */
    private String options;
    /** The gestion. */

    /** The gestion 7 c. */
    private String gestion7c;

    /** The gestion 5 c. */
    private String gestion5c;

    /** The options 5 C. */
    private String options5C;

    /** The client. */
    private String client;

    /** The file id. */
    private String fileId;
    /** The requestId. */
    private String requestId;

    /** The sending site. */
    private String sendingSite;

    /** The sending application. */
    private String sendingApplication;

    /** The header lot number. */
    private String headerLotNumber;

    /** The lot date. */
    private String lotDate;

    /** The maturity. */
    private String maturity;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Sets the maturity.
     *
     * @param maturity the new maturity
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the sending site.
     *
     * @return the sending site
     */
    public String getSendingSite() {
        return sendingSite;
    }

    /**
     * Sets the sending site.
     *
     * @param sendingSite the new sending site
     */
    public void setSendingSite(String sendingSite) {
        this.sendingSite = sendingSite;
    }

    /**
     * Gets the shipping application.
     *
     * @return the shipping application
     */
    public String getShippingApplication() {
        return sendingApplication;
    }

    /**
     * Gets the sending application.
     *
     * @return the sending application
     */
    public String getSendingApplication() {
        return sendingApplication;
    }

    /**
     * Sets the sending application.
     *
     * @param sendingApplication the new sending application
     */
    public void setSendingApplication(String sendingApplication) {
        this.sendingApplication = sendingApplication;
    }

    /**
     * Gets the header lot number.
     *
     * @return the header lot number
     */
    public String getHeaderLotNumber() {
        return headerLotNumber;
    }

    /**
     * Sets the header lot number.
     *
     * @param headerLotNumber the new header lot number
     */
    public void setHeaderLotNumber(String headerLotNumber) {
        this.headerLotNumber = headerLotNumber;
    }

    /**
     * Gets the lot date.
     *
     * @return the lot date
     */
    public String getLotDate() {
        return lotDate;
    }

    /**
     * Sets the lot date.
     *
     * @param lotDate the new lot date
     */
    public void setLotDate(String lotDate) {
        this.lotDate = lotDate;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the answer date.
     *
     * @return the answer date
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the answer date.
     *
     * @param answerDate the new answer date
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the movement code.
     *
     * @return the movement code
     */
    public String getMovementCode() {
        return movementCode;
    }

    /**
     * Sets the movement code.
     *
     * @param movementCode the new movement code
     */
    public void setMovementCode(String movementCode) {
        this.movementCode = movementCode;
    }

    /**
     * Gets the prd.
     *
     * @return the prd
     */
    public String getPrd() {
        return prd;
    }

    /**
     * Sets the prd.
     *
     * @param prd the new prd
     */
    public void setPrd(String prd) {
        this.prd = prd;
    }

    /**
     * Gets the lot number.
     *
     * @return the lot number
     */
    public String getLotNumber() {
        return lotNumber;
    }

    /**
     * Sets the lot number.
     *
     * @param lotNumber the new lot number
     */
    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    /**
     * Gets the gestion 7 c.
     *
     * @return the gestion 7 c
     */
    public String getGestion7c() {
        return gestion7c;
    }

    /**
     * Sets the gestion 7 c.
     *
     * @param gestion7c the new gestion 7 c
     */
    public void setGestion7c(String gestion7c) {
        this.gestion7c = gestion7c;
    }

    /**
     * Gets the gestion 5 c.
     *
     * @return the gestion 5 c
     */
    public String getGestion5c() {
        return gestion5c;
    }

    /**
     * Sets the gestion 5 c.
     *
     * @param gestion5c the new gestion 5 c
     */
    public void setGestion5c(String gestion5c) {
        this.gestion5c = gestion5c;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the brand.
     *
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the brand.
     *
     * @param brand the new brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Gets the version.
     *
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the version.
     *
     * @param version the new version
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * Gets the habillage ext.
     *
     * @return the habillage ext
     */
    public String getHabillage_Ext() {
        return habillage_Ext;
    }

    /**
     * Sets the habillage ext.
     *
     * @param habillage_Ext the new habillage ext
     */
    public void setHabillage_Ext(String habillage_Ext) {
        this.habillage_Ext = habillage_Ext;
    }

    /**
     * Gets the habillage int.
     *
     * @return the habillage int
     */
    public String getHabillage_Int() {
        return habillage_Int;
    }

    /**
     * Sets the habillage int.
     *
     * @param habillage_Int the new habillage int
     */
    public void setHabillage_Int(String habillage_Int) {
        this.habillage_Int = habillage_Int;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public String getOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(String options) {
        this.options = options;
    }

    /**
     * Gets the gestion.
     *
     * @return the gestion
     */
    public String getGestion() {
        return gestion;
    }

    /**
     * Sets the gestion.
     *
     * @param gestion the new gestion
     */
    public void setGestion(String gestion) {
        this.gestion = gestion;
    }

    /**
     * Gets the line number.
     *
     * @return the line number
     */
    public String getLineNumber() {
        return lineNumber;
    }

    /**
     * Sets the line number.
     *
     * @param lineNumber the new line number
     */
    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the filler.
     *
     * @return the filler
     */
    public String getFiller() {
        return filler;
    }

    /**
     * Sets the filler.
     *
     * @param filler the new filler
     */
    public void setFiller(String filler) {
        this.filler = filler;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Checks if is answer sent.
     *
     * @return true, if is answer sent
     */
    public boolean isAnswerSent() {
        return isAnswerSent;
    }

    /**
     * Sets the answer sent.
     *
     * @param isAnswerSent the new answer sent
     */
    public void setAnswerSent(boolean isAnswerSent) {
        this.isAnswerSent = isAnswerSent;
    }

    /**
     * Gets the client.
     *
     * @return the client
     */
    public String getClient() {
        return client;
    }

    /**
     * Gets the options 7 c.
     *
     * @return the options 7 c
     */
    public String getOptions7c() {
        return options7c;
    }

    /**
     * Sets the options 7 c.
     *
     * @param options7c the new options 7 c
     */
    public void setOptions7c(String options7c) {
        this.options7c = options7c;
    }

    /**
     * Sets the client.
     *
     * @param client the new client
     */
    public void setClient(String client) {
        this.client = client;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */

    /**
     * Validate.
     *
     * @return the list
     */
    public List<String> validate() {
        Set<ConstraintViolation<EliadeRequestDTO>> violations = Validation.buildDefaultValidatorFactory().getValidator().validate(this);
        return violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "EliadeRequestDTO [requestId=" + requestId + ",movementCode=" + movementCode + ", prd=" + prd + ", lotNumber=" + lotNumber
                + ", lineNumber=" + lineNumber + ", brand=" + brand + ", country=" + country + ", version=" + version + ", habillage_Ext="
                + habillage_Ext + ", habillage_Int=" + habillage_Int + ", options7c=" + options7c + ", gestion=" + gestion + ", extensionDate="
                + extensionDate + ", filler=" + filler + ", status=" + status + ", answerCode=" + answerCode + ", answerDesignation="
                + answerDesignation + ", answerDate=" + answerDate + ", isAnswerSent=" + isAnswerSent + ", options=" + options + ", gestion7c="
                + gestion7c + ", gestion5c=" + gestion5c + ", options5C=" + options5C + ", client=" + client + ", fileId=" + fileId
                + ",  sendingSite=" + sendingSite + ", sendingApplication=" + sendingApplication + ", headerLotNumber=" + headerLotNumber
                + ", lotDate=" + lotDate + "]";
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EliadeRequestDTO other = (EliadeRequestDTO) obj;
        if (requestId == null) {
            if (other.requestId != null)
                return false;
        } else if (!requestId.equals(other.requestId))
            return false;
        return true;
    }

}
