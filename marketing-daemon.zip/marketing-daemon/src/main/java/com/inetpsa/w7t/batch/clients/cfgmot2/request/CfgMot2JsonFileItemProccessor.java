/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import com.inetpsa.r3pi.transcolcdv.TranscoManager57;
import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.JsonRequestErrorCodeConstant;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.shared.WltpBatchException;
import com.inetpsa.w7t.batch.shared.WltpBtachExceptionObject;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * @author E534811
 */
public class CfgMot2JsonFileItemProccessor implements ItemProcessor<WltpJsonBatchObject, WltpJsonBatchObject> {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(CfgMot2JsonFileItemProccessor.class);

    /** The Constant LINE. */
    public static final String LINE = "line number";

    private static final int FIVE = 5;

    /** The line number. */
    private int lineNumber;

    public static final String ERROR_LOG = "Marketing Request ({}) - {}";

    private static final String STATUS_CHANGE_LOG = "Marketing Request =[{}], Old status=[{}], New status=[{}]";

    @Inject
    private CountryRepository countryRepository;

    @Inject
    private DestinationCountryRepository destinationCountryRepository;

    private org.springframework.validation.Validator validator;

    private static List<String> validCountryWithDestinations = new ArrayList<>();
    private static Map<UUID, String> countryMap = new HashMap<>();
    private static final String CLASS_NAME = "CfgMot2JsonFileItemProccessor";

    public void setValidator(org.springframework.validation.Validator validator) {
        this.validator = validator;
    }

    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    @Inject
    private MaturityRepository maturityRepository;

    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    @Override
    public WltpJsonBatchObject process(@Valid WltpJsonBatchObject item) throws Exception {
        // fixed jira-551
        logger.info("Marketing Request =[{}]", item);
        ++lineNumber;
        if (lineNumber == 1) {
            countryMap = MarkertingDaemonUtility.getAllCountries(countryRepository);
            validCountryWithDestinations = MarkertingDaemonUtility.getAllCountiresHavingDestinations(countryMap, destinationCountryRepository);
            logger.info("getAllCountries() & getAllCountiresHavingDestinations() only first time");
        }

        BindingResult results = BindAndValidate(item);
        WltpJsonBatchObject wltpJsonBatchObject = new WltpJsonBatchObject();
        List<WltpJsonBatchRequestObject> wltpJsonBatchRequestObjectList = new ArrayList<>();
        try {
            wltpJsonBatchRequestObjectList = validateBatchObjetcData(results, item);
            wltpJsonBatchObject.setWltpJsonBatchRequestObjectList(wltpJsonBatchRequestObjectList);
            return wltpJsonBatchObject;
        } catch (WltpBatchException | ConstraintViolationException e) {
            logger.error("Error in the file", e);
            buildErrorResponse(e);
        } catch (EmptyResultDataAccessException e) {
            logger.error("ERROR - Incorrect Json file {}", e);
        } catch (Exception e) {
            logger.error("Exception parsing at line . Failed record from file: {} ", e);
        }
        return null;
    }

    private List<WltpJsonBatchRequestObject> validateBatchObjetcData(BindingResult results, WltpJsonBatchObject item) {
        List<WltpJsonBatchRequestObject> batchRequestObjectList = new CopyOnWriteArrayList<>();

        if (results.hasErrors())
            buildValidationException(results, item);

        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(CLASS_NAME);
        logger.info("CfgMot2JsonFileItemProccessor thread pool size : [{}]", threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);

        try {
            List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
            item.getWltpJsonBatchRequestObjectList().forEach(request -> {
                Future<Integer> future = executorService.submit(() -> parallelProcess(request, batchRequestObjectList));
                futuresList.add(future);
            });

            for (Future<Integer> future : futuresList) {

                future.get();

            }
        } catch (Exception e) {
            logger.error("ERROR in CfgMot2JsonFileItemProccessor : [{}]", e);
        } finally {
            executorService.shutdown();
        }

        return batchRequestObjectList;
    }

    private int parallelProcess(WltpJsonBatchRequestObject batchRequestObject, List<WltpJsonBatchRequestObject> batchRequestObjectList) {
        WltpJsonBatchRequestObject wltpJsonBatchRequestObject = validateRequest(batchRequestObject);
        batchRequestObjectList.add(wltpJsonBatchRequestObject);
        return 1;
    }

    private WltpJsonBatchRequestObject validateRequest(WltpJsonBatchRequestObject request) {
        if (request.getRequest().getStatus() == null && isValidRequest(request.getRequest())) {
            logger.info(STATUS_CHANGE_LOG, request.getRequest(), MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode(),
                    MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());
            request.getRequest().setStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
        } else {
            logger.info(STATUS_CHANGE_LOG, request.getRequest(), MarketingRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                    MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
            request.getRequest().setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
        }
        return request;
    }

    private boolean maturityCheck(WltpJsonRequest wltpJsonRequest) {
        boolean proceed = true;
        try {
            String maturity = MaturityCheckUtility.determineMaturityCheckForMarketingClients(wltpJsonRequest.getRequestId(),
                    wltpJsonRequest.getVersion16C(), maturityRepository, clientMaturityRepository, logger,
                    MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase());
            wltpJsonRequest.setMaturity(maturity);
        } catch (SeedException se) {
            proceed = false;
            wltpJsonRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            if (se.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                wltpJsonRequest.setAnswerCode("ERRW" + ec.getRuleCode());
                wltpJsonRequest.setAnswerDesig(ec.getDescription());
                wltpJsonRequest.setAnswerDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));
            } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                wltpJsonRequest.setAnswerCode("ERRW" + ec.getRuleCode());
                wltpJsonRequest.setAnswerDesig(ec.getDescription());
                wltpJsonRequest.setAnswerDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));
            }

            if (wltpJsonRequest.getAnswerDesig().contains("Draft")) {
                wltpJsonRequest.setMaturity("D");
            } else if (wltpJsonRequest.getAnswerDesig().contains("Obsolete")) {
                wltpJsonRequest.setMaturity("O");
            } else if (wltpJsonRequest.getAnswerDesig().contains("Unknown")) {
                wltpJsonRequest.setMaturity("U");
            } else if (wltpJsonRequest.getAnswerDesig().contains("Captive fleet")) {
                wltpJsonRequest.setMaturity("F");
            }
        }
        return proceed;
    }

    private boolean isValidRequest(@Valid WltpJsonRequest wltpJsonRequest) {
        if (!maturityCheck(wltpJsonRequest)) {
            return false;
        }

        /** transcodify */
        if (wltpJsonRequest.getOptions7C().isEmpty() && !wltpJsonRequest.getOptions5C().isEmpty()) {
            String options7c = transcodify(wltpJsonRequest.getOptions5C());
            wltpJsonRequest.setOptions7C(options7c);
            if (options7c == null)
                return false;
        }

        /** manage nbOptions */
        if (!wltpJsonRequest.getNbOptions().isEmpty() && Integer.valueOf(wltpJsonRequest.getNbOptions()) > 40) {
            setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.NB_OPTIONS_INCORRECT);
            logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.NB_OPTIONS_INCORRECT);
            return false;
        }

        /** validate country, Characteristic and destination */
        // Country country = null;
        // List<DestinationCountry> destinationCountryList = new ArrayList<>();

        if (!wltpJsonRequest.getTradingCountry().isEmpty()) {

            // country = findByTradingCountry(wltpJsonRequest.getTradingCountry());
            // if (country != null) {
            // destinationCountryList = findByCountry(country.getGuid());
            // if (destinationCountryList.isEmpty()) {
            // setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.DESTINATION_INCORRECT);
            // logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.DESTINATION_INCORRECT);
            // return false;
            // }
            // } else {
            // setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
            // logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
            // return false;
            // }

            if (countryMap.containsValue(wltpJsonRequest.getTradingCountry())) {
                if (!validCountryWithDestinations.contains(wltpJsonRequest.getTradingCountry())) {
                    wltpJsonRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.DESTINATION_INCORRECT);
                    logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.DESTINATION_INCORRECT);
                    return false;
                }
            } else {
                wltpJsonRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
                logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
                return false;
            }

        } else {
            wltpJsonRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
            logger.error(ERROR_LOG, wltpJsonRequest, JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT);
            return false;
        }

        logger.info(STATUS_CHANGE_LOG, wltpJsonRequest, MarketingRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());

        /**
         * Step M4: Constitution of the list of individual marketing vehicles
         */
        // isAnswerSentAlready(wltpJsonRequest, destinationCountryList);

        return true;
    }

    private void setErrorDetails(WltpJsonRequest wltpJsonRequest, String errorMsg) {
        // fixed jira-551
        logger.info("Marketing Request =[{}]", wltpJsonRequest);
        wltpJsonRequest.setAnswerCode(errorMsg.split(":")[0]);
        wltpJsonRequest.setAnswerDesig(errorMsg.split(":")[1]);
        wltpJsonRequest.setAnswerDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));
    }

    // private void isAnswerSentAlready(WltpJsonRequest wltpJsonRequest, List<DestinationCountry> destinationCountries) {
    //
    // List<MarketingRequest> marketingRequestList = findBySemiExtendeTitle(wltpJsonRequest.getVersion16C(), wltpJsonRequest.getColorExtInt(),
    // wltpJsonRequest.getExtensionDate(), wltpJsonRequest.getOptions7C(), LocalDate.now().toString());
    // if (!marketingRequestList.isEmpty()) {
    // List<DestinationCountry> currentRequestDestinationCountries = destinationCountries;
    // marketingRequestList.forEach(marketingRequest -> {
    // if (!wltpJsonRequest.getTradingCountry().equals(marketingRequest.getTradingCountry())) {
    // /** continue if answer sent already to bcv */
    // if (wltpJsonRequest.isAnswerSent())
    // return;
    //
    // Country newCountry = findByTradingCountry(marketingRequest.getTradingCountry());
    // List<DestinationCountry> newDestinationCountry = findByCountry(newCountry.getGuid());
    // if (!newDestinationCountry.isEmpty() && newDestinationCountry.retainAll(currentRequestDestinationCountries)) {
    // wltpJsonRequest.setAnswerSent(true);
    // }
    // } else {
    // wltpJsonRequest.setAnswerSent(true);
    // }
    // });
    // }
    // }

    /*
     * private List<DestinationCountry> findByCountry(UUID guid) { return destinationCountryRepository.byCountryId(guid); }
     * 
     * private List<MarketingRequest> findBySemiExtendeTitle(String version16c, String colorExtInt, String extensionDate, String options7c, String
     * today) { return marketingRequestRepository.bySemiExtendeTitle(version16c, colorExtInt, extensionDate, options7c, today); }
     * 
     * private Country findByTradingCountry(String tradingCountry) { return countryRepository.byCodeAndCharacteristic(tradingCountry, "GA1"); }
     */

    /**
     * Transcodify.
     *
     * @param option5C the option5 c
     * @return the string
     */
    private String transcodify(String option5C) {
        TranscoManager57 tm57 = TranscoManager57.getInstance();
        StringBuilder persValue = new StringBuilder();

        List<String> lcdvList = new ArrayList<>();
        int index = 0;
        while (index < option5C.length()) {
            lcdvList.add(" " + option5C.substring(index, index + FIVE));
            index += FIVE;
        }
        logger.info("Transcodification module request =  [{}]", option5C);
        try {
            for (String lcdv : lcdvList)
                persValue.append(tm57.transco(lcdv));
        } catch (TranscoNotFoundException e) {
            logger.error("Exception thrown by Transcodification module", e);
            LogUtility.logTheError(logger, WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
                    WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
            return null;
        }
        logger.info("Transcodification module response =  [{}]", persValue);

        return persValue.toString();
    }

    private void buildValidationException(BindingResult results, WltpJsonBatchObject item) {
        for (ObjectError error : results.getAllErrors()) {

            FieldError fe = (FieldError) error;
            String errorObjectDetails = fe.getField().split("\\.")[0];

            String index = errorObjectDetails.substring(errorObjectDetails.indexOf('[') + 1);
            index = index.substring(0, index.indexOf(']'));

            item.getWltpJsonBatchRequestObjectList().get(Integer.parseInt(index)).getRequest()
                    .setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));

            setErrorDetails(item.getWltpJsonBatchRequestObjectList().get(Integer.parseInt(index)).getRequest(), error.getDefaultMessage());

            logger.error(ERROR_LOG, item.getWltpJsonBatchRequestObjectList().get(Integer.parseInt(index)).getRequest(), error.getDefaultMessage());
        }
    }

    private BindingResult BindAndValidate(WltpJsonBatchObject item) {
        DataBinder binder = new DataBinder(item);
        binder.setValidator(validator);
        binder.validate();
        return binder.getBindingResult();
    }

    private void buildErrorResponse(RuntimeException e) {
        WltpBtachExceptionObject responseObject = new WltpBtachExceptionObject();
        try {
            if (e instanceof WltpBatchException) {
                responseObject.setCode(((WltpBatchException) e).getContextErrorCode());
                responseObject.setDesignation(((WltpBatchException) e).getContextMesage());
            } else if (e instanceof ConstraintViolationException) {
                Optional<ConstraintViolation<?>> error = ((ConstraintViolationException) e).getConstraintViolations().stream().findFirst();
                if (error.isPresent()) {
                    String[] errorMsg = error.get().getMessage().split(":");
                    responseObject.setCode(errorMsg[0]);
                    responseObject.setDesignation(errorMsg.length > 1 ? errorMsg[1] : "");
                }
            } else {
                responseObject.setCode(WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode());
                responseObject.setDesignation(WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
            }
            logger.info("Exception in parsing line = [{}]", responseObject);
        } catch (Exception e1) {
            logger.error("Unexpected exception", e1);
            LogUtility.logTheError(logger, WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
                    WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
            throw new WltpBatchException(WltpRequestErrorCode.UNKNOWN_EXCEPTION);
        }
    }

}
