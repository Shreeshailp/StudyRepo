/*
 * Creation : 10 août 2017
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

import java.io.Serializable;
import java.util.List;

import com.inetpsa.w7t.domains.engine.model.calculation.ConversionData;

/**
 * The Class CpdsRequestsRepresentations.
 */
public class CpdsRequestsRepresentations implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2543347433982476574L;

    /** The version16 c. */
    private String version16C;

    /** The color ext int. */
    private String colorExtInt;

    /** The nb options. */
    private String nbOptions;

    /** The options5 c. */
    private String options5C = "";

    /** The options7 c. */
    private String options7C = "";

    /** The nb gestion. */
    private String nbGestion;

    /** The gestion5 c. */
    private String gestion5C = "";

    /** The gestion7 c. */
    private String gestion7C = "";

    /** The extension date. */
    private String extensionDate = "";

    /** The mounting center. */
    private String mountingCenter = "";

    /** The request type. */
    private String requestType;

    /** The vin. */
    private String vin = "";

    /** The ecom date. */
    private String ecomDate = "";

    /** The trading country. */
    private String tradingCountry = "";

    /** The extended title attributes. */
    private String extendedTitleAttributes = "";

    /** The tvv. */
    private String tvv = "";

    /** The conversion data. */
    List<ConversionData> conversionData;

    /**
     * Instantiates a new cpds requests representations.
     */
    public CpdsRequestsRepresentations() { // NOSONAR No validation on empty
        // constructor
    }

    /**
     * Instantiates a new cpds requests representations.
     *
     * @param version16c the version 16 c
     * @param colorExtInt the color ext int
     * @param nbOptions the nb options
     * @param options5c the options 5 c
     * @param options7c the options 7 c
     * @param nbGestion the nb gestion
     * @param gestion5c the gestion 5 c
     * @param gestion7c the gestion 7 c
     * @param extensionDate the extension date
     * @param mountingCenter the mounting center
     * @param requestType the request type
     * @param vin the vin
     * @param ecomDate the ecom date
     * @param tradingCountry the trading country
     * @param extendedTitleAttributes the extended title attributes
     * @param tvv the tvv
     */
    public CpdsRequestsRepresentations(String version16c, String colorExtInt, String nbOptions, String options5c, String options7c, String nbGestion,
            String gestion5c, String gestion7c, String extensionDate, String mountingCenter, String requestType, String vin, String ecomDate,
            String tradingCountry, String extendedTitleAttributes, String tvv) {
        super();
        version16C = version16c;
        this.colorExtInt = colorExtInt;
        this.nbOptions = nbOptions;
        options5C = options5c;
        options7C = options7c;
        this.nbGestion = nbGestion;
        gestion5C = gestion5c;
        gestion7C = gestion7c;
        this.extensionDate = extensionDate;
        this.mountingCenter = mountingCenter;
        this.requestType = requestType;
        this.vin = vin;
        this.ecomDate = ecomDate;
        this.tradingCountry = tradingCountry;
        this.extendedTitleAttributes = extendedTitleAttributes;
        this.tvv = tvv;
    }

    /**
     * Gets the conversion data.
     *
     * @return the conversion data
     */
    public List<ConversionData> getConversionData() {
        return conversionData;
    }

    /**
     * Sets the conversion data.
     *
     * @param conversionData the new conversion data
     */
    public void setConversionData(List<ConversionData> conversionData) {
        this.conversionData = conversionData;
    }

    /**
     * Gets the nb gestion.
     *
     * @return the nb gestion
     */
    public String getNbGestion() {
        return nbGestion;
    }

    /**
     * Sets the nb gestion.
     *
     * @param nbGestion the new nb gestion
     */
    public void setNbGestion(String nbGestion) {
        this.nbGestion = nbGestion;
    }

    /**
     * Gets the gestion5 c.
     *
     * @return the gestion5 c
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion5 c.
     *
     * @param gestion5c the new gestion5 c
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion7 c.
     *
     * @return the gestion7 c
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion7 c.
     *
     * @param gestion7c the new gestion7 c
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the version16 c.
     *
     * @return the version16 c
     */
    public String getVersion16C() {
        return version16C;
    }

    /**
     * Sets the version16 c.
     *
     * @param version16c the new version16 c
     */
    public void setVersion16C(String version16c) {
        version16C = version16c;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the nb options.
     *
     * @return the nb options
     */
    public String getNbOptions() {
        return nbOptions;
    }

    /**
     * Sets the nb options.
     *
     * @param nbOptions the new nb options
     */
    public void setNbOptions(String nbOptions) {
        this.nbOptions = nbOptions;
    }

    /**
     * Gets the options5 c.
     *
     * @return the options5 c
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options5 c.
     *
     * @param options5c the new options5 c
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options7 c.
     *
     * @return the options7 c
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options7 c.
     *
     * @param options7c the new options7 c
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the extended title attributes.
     *
     * @return the extended title attributes
     */
    public String getExtendedTitleAttributes() {
        return extendedTitleAttributes;
    }

    /**
     * Sets the extended title attributes.
     *
     * @param extendedTitleAttributes the new extended title attributes
     */
    public void setExtendedTitleAttributes(String extendedTitleAttributes) {
        this.extendedTitleAttributes = extendedTitleAttributes;
    }

    /**
     * Gets the mounting center.
     *
     * @return the mounting center
     */
    public String getMountingCenter() {
        return mountingCenter;
    }

    /**
     * Sets the mounting center.
     *
     * @param mountingCenter the new mounting center
     */
    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    /**
     * Gets the tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Sets the tvv.
     *
     * @param tvv the new tvv
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CpdsRequestsRepresentations [version16C=" + version16C + ", colorExtInt=" + colorExtInt + ", nbOptions=" + nbOptions + ", options5C="
                + options5C + ", options7C=" + options7C + ", nbGestion=" + nbGestion + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C
                + ", extensionDate=" + extensionDate + ", mountingCenter=" + mountingCenter + ", requestType=" + requestType + ", vin=" + vin
                + ", ecomDate=" + ecomDate + ", tradingCountry=" + tradingCountry + ", extendedTitleAttributes=" + extendedTitleAttributes + ", tvv="
                + tvv + ", conversionData=" + conversionData + "]";
    }

}