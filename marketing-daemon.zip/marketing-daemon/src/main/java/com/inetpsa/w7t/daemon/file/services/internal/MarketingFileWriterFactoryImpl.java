/*
 * Creation : 20 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;

import com.google.inject.Injector;
import com.inetpsa.w7t.daemon.file.services.MarketingFileWriter;
import com.inetpsa.w7t.daemon.file.services.MarketingFileWriterFactory;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;

/**
 * @author E534811
 */
public class MarketingFileWriterFactoryImpl extends BaseFactory<MarketingFileWriter>
		implements MarketingFileWriterFactory {

	@Inject
	private Injector injector;

	@Override
	public MarketingFileWriter createClientFileWriter(String name, MarketingDaemonClientConfig config) {
		MarketingClientFileWriter client = new MarketingClientFileWriter(name, config);
		injector.injectMembers(client);
		return client;
	}

	@Override
	public MarketingFileWriter createProviderFileWriter(String name, MarketingDaemonProviderConfig config) {
		MarketingProviderFileWriter provider = new MarketingProviderFileWriter(name, config);
		injector.injectMembers(provider);
		return provider;
	}

}
