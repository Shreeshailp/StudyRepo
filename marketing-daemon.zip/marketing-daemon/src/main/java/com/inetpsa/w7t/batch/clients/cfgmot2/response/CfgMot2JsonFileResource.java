/*
 * Creation : 24 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class CfgMot2JsonFileResource.
 *
 * @author E539598
 */
public class CfgMot2JsonFileResource extends FileSystemResource {

    /**
     * Instantiates a new cfgMot2 json file resource.
     *
     * @param path the path
     * @param cfgmot2OtputFilename the cfgmot 2 otput filename
     */
    public CfgMot2JsonFileResource(String path, String cfgmot2OtputFilename) {
        super(path + File.separator + cfgmot2OtputFilename);
    }
}
