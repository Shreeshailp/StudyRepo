/*
 * Creation : 15 déc. 2017
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

/**
 * The Class CpdsPhysicalResult.
 */
public class CpdsPhysicalResult {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Instantiates a new cpds physical result.
     */
    public CpdsPhysicalResult() {
        super();
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "PhysicalResult [code=" + code + ", value=" + value + "]";
    }

}
