package com.inetpsa.w7t.daemon.services.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Singleton;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.daemon.file.services.MarketingFileListener;
import com.inetpsa.w7t.daemon.file.services.MarketingFileListenerFactory;
import com.inetpsa.w7t.daemon.file.services.MarketingFileWriter;
import com.inetpsa.w7t.daemon.file.services.MarketingFileWriterFactory;
import com.inetpsa.w7t.daemon.services.MarketingDaemonService;
import com.inetpsa.w7t.daemon.services.MarketingRequestLifecycleService;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;

/**
 * The Class MarketingDaemonServiceImpl. This is the implementation of {@link MarketingDaemonService} and act as a singleton throughout the daemon's
 * life.
 */
/**
 * @author E539596
 */
@Singleton
public class MarketingDaemonServiceImpl implements MarketingDaemonService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The daemon config. */
    @Configuration
    private MarketingDaemonConfig marketingDaemonConfig;

    /** The request lifecycle service. */
    @Inject
    private MarketingRequestLifecycleService marketingRequestLifecycleService;

    /** The file listener factory. */
    @Inject
    private MarketingFileListenerFactory marketingFileListenerFactory;

    /** The file writer factory. */
    @Inject
    private MarketingFileWriterFactory marketingFileWriterFactory;

    /** The client listeners. */
    private List<MarketingFileListener> marketingClientListeners = new ArrayList<>();

    /** The client writers. */
    private List<MarketingFileWriter> marketingClientWriters = new ArrayList<>();

    /** The client futures. */
    private List<CompletableFuture<Void>> clientFutures = new ArrayList<>();

    /** The provider listeners. */
    private List<MarketingFileListener> providerListeners = new ArrayList<>();

    /** The provider writers. */
    private List<MarketingFileWriter> providerWriters = new ArrayList<>();

    /** The lifecycle future. */
    private CompletableFuture<Void> lifecycleFuture;

    /** The running. */
    private Boolean running = false;

    /** The Constant CONFIGMOT2. */
    public static final String CONFIGMOT2 = "configMot2";

    /** The Constant BCVNEWTON. */
    public static final String BCVNEWTON = "bcvNewton";

    /** The Constant TOYOTA. */
    public static final String TOYOTA = "toyota";

    /** The Constant AOGEOS. */
    public static final String AOGEOS = "aoGeos";

    /** The Constant CRONOS. */
    public static final String CRONOS = "cronos";

    /** The Constant ELIADE. */
    public static final String ELIADE = "eliade";

    /** The Constant CPDS. */
    public static final String CPDS = "cpds";

    /** The Constant ICUBE. */
    public static final String ICUBE = "icube";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#run()
     */
    @Override
    public void run() {
        logger.trace("Running marketing daemon service");

        ExecutorService clientExecutor = Executors.newFixedThreadPool(marketingDaemonConfig.getClients().size());
        this.clientFutures = marketingDaemonConfig.getClients().entrySet().stream().map(entry -> {
            MarketingFileListener client = getMarketingClient(entry);
            this.marketingClientListeners.add(client);
            this.marketingClientWriters.add(marketingFileWriterFactory.createClientFileWriter(entry.getKey(), entry.getValue()));
            return client;
        }).map(client -> CompletableFuture.runAsync(client::run, clientExecutor)).collect(Collectors.toList());

        ExecutorService providerExecutor = Executors.newFixedThreadPool(marketingDaemonConfig.getProviders().size());
        marketingDaemonConfig.getProviders().entrySet().stream().map(entry -> {
            MarketingFileListener provider = getProviders(entry);
            this.providerListeners.add(provider);
            this.providerWriters.add(marketingFileWriterFactory.createProviderFileWriter(entry.getKey(), entry.getValue()));
            return provider;
        }).map(provider -> CompletableFuture.runAsync(provider::run, providerExecutor)).collect(Collectors.toList());

        this.lifecycleFuture = CompletableFuture.runAsync(marketingRequestLifecycleService::run, Executors.newSingleThreadExecutor());

        this.running = true;
    }

    /**
     * The below method is added as part of JIRA-455 Fix - Gets the marketing client.
     *
     * @param entry the entry
     * @return the marketing client
     */
    private MarketingFileListener getMarketingClient(Entry<String, MarketingDaemonClientConfig> entry) {
        String marketingClient = entry.getKey();
        MarketingFileListener client = null;
        if (marketingClient != null && marketingClient.equalsIgnoreCase(CONFIGMOT2)) {
            MarketingFileListener clientConfigMot2 = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForConfigMot2());
            client = clientConfigMot2;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(TOYOTA)) {
            MarketingFileListener clientToyota = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForToyota());
            client = clientToyota;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(AOGEOS)) {
            MarketingFileListener clientAoGeos = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForAoGeos());
            client = clientAoGeos;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(CRONOS)) {
            MarketingFileListener clientCronos = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForCronos());
            client = clientCronos;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(ELIADE)) {
            MarketingFileListener clientEliade = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForEliade());
            client = clientEliade;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(ICUBE)) {
            MarketingFileListener clientIcube = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForIcube());
            client = clientIcube;
        } else if (marketingClient != null && marketingClient.equalsIgnoreCase(CPDS)) {
            MarketingFileListener clientCpds = marketingFileListenerFactory.createClientFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getFileListenerRefreshIntervalForCpds());
            client = clientCpds;
        }
        return client;
    }

    /**
     * The below method is added as part of JIRA-455 Fix - Gets the providers.
     *
     * @param entry the entry
     * @return the providers
     */
    private MarketingFileListener getProviders(Entry<String, MarketingDaemonProviderConfig> entry) {

        String marketingProvider = entry.getKey();
        MarketingFileListener provider = null;
        if (marketingProvider != null && marketingProvider.equalsIgnoreCase(CONFIGMOT2)) {
            MarketingFileListener providerConfigMot2 = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForConfigMot2());
            provider = providerConfigMot2;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(TOYOTA)) {
            MarketingFileListener providerToyota = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForToyota());
            provider = providerToyota;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(AOGEOS)) {
            MarketingFileListener providerAoGeos = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForAoGeos());
            provider = providerAoGeos;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(CRONOS)) {
            MarketingFileListener providerCronos = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForCronos());
            provider = providerCronos;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(ELIADE)) {
            MarketingFileListener providerEliade = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForEliade());
            provider = providerEliade;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(ICUBE)) {
            MarketingFileListener providerIcube = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForIcube());
            provider = providerIcube;
        } else if (marketingProvider != null && marketingProvider.equalsIgnoreCase(CPDS)) {
            MarketingFileListener providerCpds = marketingFileListenerFactory.createProviderFileListener(entry.getKey(), entry.getValue(),
                    this.marketingDaemonConfig.getProviderFileListenerRefreshIntervalForCpds());
            provider = providerCpds;
        }

        return provider;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getRunningThreads()
     */
    @Override
    public Integer getRunningThreads() {
        return (int) Stream.concat(this.clientFutures.stream(), Stream.of(this.lifecycleFuture)).filter(f -> !f.isDone()).count();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getTotalThreads()
     */
    @Override
    public Integer getTotalThreads() {
        return (int) Stream.concat(this.clientFutures.stream(), Stream.of(this.lifecycleFuture)).count();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#isRunning()
     */
    @Override
    public Boolean isRunning() {
        return this.running;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getClientWriters()
     */
    @Override
    public List<MarketingFileWriter> getClientWriters() {
        return this.marketingClientWriters;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getClientWriter(java.lang.String)
     */
    @Override
    public Optional<MarketingFileWriter> getClientWriter(String name) {
        return this.getClientWriters().stream().filter(writer -> writer.name().equalsIgnoreCase(name)).findFirst();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getProviderWriters()
     */
    @Override
    public List<MarketingFileWriter> getProviderWriters() {
        return this.providerWriters;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.MarketingDaemonService#getProviderWriter(java.lang.String)
     */
    @Override
    public Optional<MarketingFileWriter> getProviderWriter(String name) {
        return this.getProviderWriters().stream().filter(fw -> Objects.equals(fw.name(), name)).findFirst();
    }

}
