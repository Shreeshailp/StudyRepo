/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ToyotaFamilyDetails.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaAttribute", "testVehiclesCharacteristics", "toyotaTestVehicleResults" })
@XmlRootElement(name = "family_dataset")
public class ToyotaFamilyDetails {

    /** The attribute. */
    @XmlElement(name = "attribute", required = true)
    protected List<ToyotaAttribute> toyotaAttribute;

    /** The test vehicles characteristics. */
    @XmlElement(name = "TEST_VEHICLE_CHARACTERISTICS", required = true)
    protected ToyotaTestVehiclesCharacteristics testVehiclesCharacteristics;

    /** The toyota test vehicle results. */
    @XmlElement(name = "TEST_VEHICLE_RESULTS", required = true)
    protected ToyotaTestVehicleResults toyotaTestVehicleResults;

    /**
     * Instantiates a new toyota family details.
     */
    public ToyotaFamilyDetails() {
        super();
    }

    /**
     * Getter toyotaAttribute
     * 
     * @return the toyotaAttribute
     */
    public List<ToyotaAttribute> getToyotaAttribute() {
        return toyotaAttribute;
    }

    /**
     * Setter toyotaAttribute
     * 
     * @param toyotaAttribute the toyotaAttribute to set
     */
    public void setToyotaAttribute(List<ToyotaAttribute> toyotaAttribute) {
        this.toyotaAttribute = toyotaAttribute;
    }

    /**
     * Getter toyotaTestVehicleResults
     * 
     * @return the toyotaTestVehicleResults
     */
    public ToyotaTestVehicleResults getToyotaTestVehicleResults() {
        return toyotaTestVehicleResults;
    }

    /**
     * Setter toyotaTestVehicleResults
     * 
     * @param toyotaTestVehicleResults the toyotaTestVehicleResults to set
     */
    public void setToyotaTestVehicleResults(ToyotaTestVehicleResults toyotaTestVehicleResults) {
        this.toyotaTestVehicleResults = toyotaTestVehicleResults;
    }

    /**
     * Getter testVehiclesCharacteristics
     * 
     * @return the testVehiclesCharacteristics
     */
    public ToyotaTestVehiclesCharacteristics getTestVehiclesCharacteristics() {
        return testVehiclesCharacteristics;
    }

    /**
     * Setter testVehiclesCharacteristics
     * 
     * @param testVehiclesCharacteristics the testVehiclesCharacteristics to set
     */
    public void setTestVehiclesCharacteristics(ToyotaTestVehiclesCharacteristics testVehiclesCharacteristics) {
        this.testVehiclesCharacteristics = testVehiclesCharacteristics;
    }

}
