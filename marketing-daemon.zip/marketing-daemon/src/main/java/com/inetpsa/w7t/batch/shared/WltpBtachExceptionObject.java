/*
 * Creation : 18 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.io.Serializable;

/**
 * The Class WltpBtachExceptionObject.
 *
 * @author E534811
 */
public class WltpBtachExceptionObject implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8033385658493393388L;

    /** The code. */
    private String code;

    /** The designation. */
    private String designation;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the designation.
     *
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Sets the designation.
     *
     * @param designation the new designation
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "WltpBtachExceptionObject [code=" + code + ", designation=" + designation + "]";
    }

}
