/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVMediumPhysicalResult" })
@XmlRootElement(name = "VMED")
public class ToyotaVMediumPhysicalResult {
    @XmlElement(name = "phys_result", required = true)
    protected List<ToyotaPhysicalResult> toyotaVMediumPhysicalResult;

    public ToyotaVMediumPhysicalResult() {
        super();
    }

    public ToyotaVMediumPhysicalResult(List<ToyotaPhysicalResult> toyotaVMediumPhysicalResult) {
        super();
        this.toyotaVMediumPhysicalResult = toyotaVMediumPhysicalResult;
    }

    public List<ToyotaPhysicalResult> getToyotaVMediumPhysicalResult() {
        return toyotaVMediumPhysicalResult;
    }

    public void setToyotaVMediumPhysicalResult(List<ToyotaPhysicalResult> toyotaVMediumPhysicalResult) {
        this.toyotaVMediumPhysicalResult = toyotaVMediumPhysicalResult;
    }

}
