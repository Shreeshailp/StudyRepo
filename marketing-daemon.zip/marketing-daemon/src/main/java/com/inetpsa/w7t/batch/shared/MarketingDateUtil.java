/*
 * Creation : 1 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author E534811
 */
public class MarketingDateUtil {

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static DateTimeFormatter newDateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");

    private MarketingDateUtil() {

    }

    public static String getTodaysDate() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateTimeFormatter);
    }

    public static String getTodaysDateWithoutTime() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(dateFormatter);
    }

    public static String getTodaysDateforCo2MinMax() {
        LocalDateTime now = LocalDateTime.now();
        return now.format(newDateTimeFormatter);
    }
}
