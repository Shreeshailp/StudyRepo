/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.daemon.services.internal;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhase;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhysicalResult;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaResult;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaVehicleTestResultDto;
import com.inetpsa.w7t.daemon.services.ToyotaFamilyDetailsService;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;

/**
 * The Class ToyotaFamilyDetailsServiceImpl.
 */
@JpaUnit("wltp-domain-jpa-unit")
@Transactional
public class ToyotaFamilyDetailsServiceImpl implements ToyotaFamilyDetailsService {
    /** The family details repository. */
    @Inject
    private FamilyRepository familyRepository;

    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.ToyotaFamilyDetailsService#getFamilyForToyota(java.util.UUID)
     */
    @Override
    public Map<String, List<ToyotaPhysicalResult>> getVehicleCharacteristics(String code, int index) {
        Map<String, List<ToyotaPhysicalResult>> vehCharacteristicMap = new LinkedHashMap<>();
        List<ToyotaPhysicalResult> vlowList = new ArrayList<>();
        List<ToyotaPhysicalResult> vhighList = new ArrayList<>();
        List<ToyotaPhysicalResult> vrefList = new ArrayList<>();
        List<ToyotaPhysicalResult> vmedList = new ArrayList<>();
        List<Object[]> vehCharacteristics = familyRepository.getVehicleCharacteristics(code, index);
        for (Object[] character : vehCharacteristics) {
            if (character[2] != null && character[2].toString().equalsIgnoreCase("VLOW")) {
                ToyotaPhysicalResult phyResult = new ToyotaPhysicalResult();
                setCharacteristicsCodeByRoadLoad(character, phyResult);
                vlowList.add(phyResult);
            }
            if (character[2] != null && character[2].toString().equalsIgnoreCase("VHIGH")) {
                ToyotaPhysicalResult phyResult = new ToyotaPhysicalResult();
                setCharacteristicsCodeByRoadLoad(character, phyResult);
                vhighList.add(phyResult);
            }
            if (character[2] != null && character[2].toString().equalsIgnoreCase("VMED")) {
                ToyotaPhysicalResult phyResult = new ToyotaPhysicalResult();
                setCharacteristicsCodeByRoadLoad(character, phyResult);
                vmedList.add(phyResult);
            }
            if (character[2] != null && character[2].toString().equalsIgnoreCase("VREF")) {
                ToyotaPhysicalResult phyResult = new ToyotaPhysicalResult();
                setCharacteristicsCodeByRoadLoad(character, phyResult);
                vrefList.add(phyResult);
            }

        }
        if (CollectionUtils.isNotEmpty(vlowList)) {
            vehCharacteristicMap.put("VLOW", vlowList);
        }
        if (CollectionUtils.isNotEmpty(vhighList)) {
            vehCharacteristicMap.put("VHIGH", vhighList);
        }
        if (CollectionUtils.isNotEmpty(vmedList)) {
            vehCharacteristicMap.put("VMED", vmedList);
        }
        if (CollectionUtils.isNotEmpty(vrefList)) {
            vehCharacteristicMap.put("VREF", vrefList);
        }
        return vehCharacteristicMap;
    }

    private void setCharacteristicsCodeByRoadLoad(Object[] character, ToyotaPhysicalResult phyResult) {
        if (character[3] != null && character[3].toString().equalsIgnoreCase("DRL")) {
            if ("SCX".equalsIgnoreCase(character[0].toString())) {
                phyResult.setCode("Heigth");
                phyResult.setValue(character[1].toString());
            } else if ("CRR".equalsIgnoreCase(character[0].toString())) {
                phyResult.setCode("Width");
                phyResult.setValue(character[1].toString());
            } else {
                setOtherCharacteristics(character, phyResult);
            }

        } else if (character[3] != null && character[3].toString().equalsIgnoreCase("MRL")) {
            if ("SCX".equalsIgnoreCase(character[0].toString())) {
                phyResult.setCode("Frontal Area");
                phyResult.setValue(character[1].toString());
            } else if ("CRR".equalsIgnoreCase(character[0].toString())) {
                setOtherCharacteristics(character, phyResult);
            } else {
                setOtherCharacteristics(character, phyResult);
            }

        } else {
            setOtherCharacteristics(character, phyResult);
        }

    }

    private void setOtherCharacteristics(Object[] character, ToyotaPhysicalResult phyResult) {
        phyResult.setCode(character[0].toString());
        phyResult.setValue(character[1].toString());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.ToyotaFamilyDetailsService#getVehicleTestResults(java.lang.String, int)
     */
    @Override
    public Map<String, List<ToyotaPhase>> getVehicleTestResults(String code, int index) {
        Map<String, List<ToyotaPhase>> vehTestResultsMap = new LinkedHashMap<>();
        List<ToyotaVehicleTestResultDto> dtoList = new ArrayList<>();

        List<Object[]> vehTestResults = familyRepository.getVehicleTestResults(code, index);
        for (Object[] testResult : vehTestResults) {
            ToyotaVehicleTestResultDto phaseResult = new ToyotaVehicleTestResultDto();
            phaseResult.setVehicleCode(testResult[3].toString());
            phaseResult.setPhaseCode(testResult[0].toString());
            phaseResult.setResultCode(testResult[1].toString());
            phaseResult.setResultValue(testResult[2].toString());

            dtoList.add(phaseResult);
        }
        List<ToyotaVehicleTestResultDto> vLowList = dtoList.stream().filter(dto -> dto.getVehicleCode().equalsIgnoreCase("VLOW"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> vMedList = dtoList.stream().filter(dto -> dto.getVehicleCode().equalsIgnoreCase("VMED"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> vHighList = dtoList.stream().filter(dto -> dto.getVehicleCode().equalsIgnoreCase("VHIGH"))
                .collect(Collectors.toList());

        vehTestResultsMap.put("VLOW", getPhaseResults(vLowList));
        vehTestResultsMap.put("VMED", getPhaseResults(vMedList));
        vehTestResultsMap.put("VHIGH", getPhaseResults(vHighList));
        return vehTestResultsMap;

    }

    /**
     * Gets the phase results.
     *
     * @param vLowList the v low list
     * @return the phase results
     */
    private List<ToyotaPhase> getPhaseResults(List<ToyotaVehicleTestResultDto> vLowList) {
        List<ToyotaPhase> phaseList = new ArrayList<>();
        List<ToyotaVehicleTestResultDto> lowList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("LOW"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> midList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("MID"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> highList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("HIGH"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> ehighList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("EHIGH"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> cityList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("CITY"))
                .collect(Collectors.toList());
        List<ToyotaVehicleTestResultDto> combList = vLowList.stream().filter(dto -> dto.getPhaseCode().equalsIgnoreCase("COMB"))
                .collect(Collectors.toList());

        if (!lowList.isEmpty()) {
            ToyotaPhase low = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            low.setCode("LOW");
            for (ToyotaVehicleTestResultDto dto : lowList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }

                resultList.add(result);
            }
            low.setResult(resultList);
            phaseList.add(low);
        }
        if (!midList.isEmpty()) {
            ToyotaPhase mid = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            mid.setCode("MID");
            for (ToyotaVehicleTestResultDto dto : midList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }
                resultList.add(result);
            }
            mid.setResult(resultList);
            phaseList.add(mid);
        }
        if (!highList.isEmpty()) {
            ToyotaPhase high = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            high.setCode("HIGH");
            for (ToyotaVehicleTestResultDto dto : highList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }
                resultList.add(result);
            }
            high.setResult(resultList);
            phaseList.add(high);
        }
        if (!ehighList.isEmpty()) {
            ToyotaPhase ehigh = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            ehigh.setCode("EHIGH");
            for (ToyotaVehicleTestResultDto dto : ehighList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }
                resultList.add(result);
            }
            ehigh.setResult(resultList);
            phaseList.add(ehigh);
        }
        if (!cityList.isEmpty()) {
            ToyotaPhase city = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            city.setCode("CITY");
            for (ToyotaVehicleTestResultDto dto : cityList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }
                resultList.add(result);
            }
            city.setResult(resultList);
            phaseList.add(city);
        }
        if (!combList.isEmpty()) {
            ToyotaPhase comb = new ToyotaPhase();
            List<ToyotaResult> resultList = new ArrayList<>();
            comb.setCode("COMB");

            for (ToyotaVehicleTestResultDto dto : combList) {
                ToyotaResult result = new ToyotaResult();
                if ("CE".equalsIgnoreCase(dto.getResultCode())) {
                    result.setCode(dto.getResultCode());
                    Double dblValue = Double.parseDouble(dto.getResultValue());
                    result.setValue(getPhaseResultInFormat(dto.getResultCode(), dblValue));
                } else {
                    result.setCode(dto.getResultCode());
                    result.setValue(dto.getResultValue());
                }
                resultList.add(result);
            }
            comb.setResult(resultList);
            phaseList.add(comb);
        }
        return phaseList;

    }

    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

}
