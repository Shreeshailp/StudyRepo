/*
 * Creation : 25 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.request;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.ToyotaFileRequestXML;

/**
 * ToyotaParentXMLFileItemWriter
 * 
 * @author E534812
 */
public class ToyotaParentXMLFileItemWriter implements ItemWriter<ToyotaFileRequestXML> {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(ToyotaFileRequestXML.class);

    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The step execution. */
    private StepExecution stepExecution;

    /**
     * Save step execution.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void saveStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    /** The line number. */
    private int lineNumber;

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends ToyotaFileRequestXML> items) throws Exception {

        lineNumber++;
        try {
            String fileId = items.get(0).getFileId();
            String requestDate = items.get(0).getRequestDate();

            // Check file Id and Request date present in file
            if (ToyotaUtility.getInstance().checkParentRootValidation(fileId, requestDate, lineNumber, items.get(0))) {

                logger.info("Reading Marketing toyota file ID : {}", fileId);
                Optional<MarketingRequest> toyotaReqEntity = getToyotaReqByFileId(fileId);

                if (toyotaReqEntity.isPresent()) {
                    logger.error("{} : Marketing toyota {}. at line : {} . Failed record from file : {}",
                            WltpRequestErrorCode.FILEID_NOT_UNIQUE.getRuleCode(), WltpRequestErrorCode.FILEID_NOT_UNIQUE.getDescription(), lineNumber,
                            items);
                    LogUtility.logTheError(logger, WltpRequestErrorCode.FILEID_NOT_UNIQUE.getRuleCode(),
                            WltpRequestErrorCode.FILEID_NOT_UNIQUE.getDescription());
                    // Terminate batch
                    stepExecution.setTerminateOnly();
                }
                this.stepExecution.getExecutionContext().put("FILE_ID", fileId);
                this.stepExecution.getExecutionContext().put("REQUEST_DATE", requestDate);

            } else {
                // Terminate batch
                stepExecution.setTerminateOnly();
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            logger.error("Exception parsing . Failed record from file: {} ", items);
        }
    }

    /**
     * Getv file id from database
     * 
     * @param reqId
     * @return
     * @throws Exception
     */
    private Optional<MarketingRequest> getToyotaReqByFileId(String fileId) throws Exception {
        return marketingRequestRepository.byFileId(fileId);
    }

}
