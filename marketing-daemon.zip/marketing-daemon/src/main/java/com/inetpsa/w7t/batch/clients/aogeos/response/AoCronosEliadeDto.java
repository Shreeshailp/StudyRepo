/*
 * Creation : 25 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.response;

import java.util.List;
import java.util.Optional;

import org.hibernate.validator.constraints.NotEmpty;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * The Class AoGeosDto.
 */
public class AoCronosEliadeDto {

    /** The moment code 20. */
    private String momentCode20 = "";

    /** The file id. */
    private String fileId = "";

    /** The moment code 30. */
    private String momentCode30 = "";

    /** The prd. */
    private String prd = "";

    /** The brand. */
    private String brand = "";

    /** The trading country. */
    private String tradingCountry = "";

    /** The version 16. */
    private String version16 = "";

    /** The color ext int. */
    private String colorExtInt = "";

    /** The options. */
    private String options = "";

    /** The gestion. */
    private String gestion = "";

    /** The request type. */
    private String requestType = "";

    /** The extension date. */
    private String extensionDate = "";

    /** The status. */
    private String status = "";

    /** The answer code. */
    private String answerCode = "";

    /** The answer designation. */
    private String answerDesignation = "";

    /** The answer designation. */
    private String answerDate = "";

    /** The filler. */
    private String filler = "";

    /** The lot number. */
    private String lotNumber = "";

    /** The line number. */
    private String lineNumber = "";

    /** The vehicle type. */
    private String vehicleType = "";

    /** The end date. */
    private String endDate = "";

    /** The options 5 C. */
    private String options5C = "";

    /** The options 7 C. */
    private String options7C = "";

    /** The gestion 5 C. */
    private String gestion5C = "";

    /** The gestion 7 C. */
    private String gestion7C = "";

    /** The extended title. */
    private String extendedTitle = "";

    /** The ext attr. */
    private String extAttr = "";

    /** The mass socle. */
    private String massSocle = "";

    /** The mass equip. */
    private String massEquip = "";

    /** The mass vehic. */
    private String massVehic = "";

    /** The scx socle. */
    private String scxSocle = "";

    /** The scx equip. */
    private String scxEquip = "";

    /** The scx vehic. */
    private String scxVehic = "";

    /** The crr vehic. */
    private String crrVehic = "";

    /** The request id. */
    private String requestId = "";

    /** The internal request id. */
    private String internalRequestId = "";

    /** The family. */
    private String family = "";

    /** The code. */
    private String code = "";

    /** The ecom date. */
    private String ecomDate = "";

    /** The road load. */
    private String roadLoad = "";

    /** The avoid cache. */
    private Boolean avoidCache;

    /** The v low. */
    private String vLow = "";

    /** The v high. */
    private String vHigh = "";

    /** The v low fuel consumption. */
    private String vLowFuelConsumption = "";
    /** The v low cycle energy. */
    private String vLowCycleEnergy = "";

    /** The calculated comb co 2. */
    private String calculatedCombCo2 = "";

    /** The calculated comb fc. */
    private String calculatedCombFc = "";

    /** The mini cond hybride WCCO 2. */
    private String miniCondHybrideWCCO2 = "";

    /** The mini cond hybride WCFC. */
    private String miniCondHybrideWCFC = "";

    /** The mini inj 2 cond mixte CO 2 B. */
    private String miniInj2CondMixteCO2B = "";

    /** The mini inj 2 cond mixte FCB. */
    private String miniInj2CondMixteFCB = "";

    /** The mini gaz cond mixtes CO 2 G. */
    private String miniGazCondMixtesCO2G = "";

    /** The mini gaz cond mixtes FCG. */
    private String miniGazCondMixtesFCG = "";

    /** The mini electric energy consumption EC. */
    private String miniElectricEnergyConsumptionEC = "";

    /** The mini electric range PER. */
    private String miniElectricRangePER = "";

    /** The mini electric energy consumption UFEC. */
    private String miniElectricEnergyConsumptionUFEC = "";

    /** The mini electric range EAER. */
    private String miniElectricRangeEAER = "";

    /** The min all electric range AER. */
    // JIRA-454- Added below property as part of this JRA fix
    private String minAllElectricRangeAER = "";
    /** The v high fuel consumption. */
    private String vHighFuelConsumption = "";
    /** The v high cycle energy. */
    private String vHighCycleEnergy = "";

    /** The max cond hybride WCCO 2. */
    private String maxCondHybrideWCCO2 = "";

    /** The max cond hybride WCFC. */
    private String maxCondHybrideWCFC = "";

    /** The max inj 2 cond mixte CO 2 B. */
    private String maxInj2CondMixteCO2B = "";

    /** The max inj 2 cond mixte FCB. */
    private String maxInj2CondMixteFCB = "";

    /** The max gaz cond mixtes CO 2 G. */
    private String maxGazCondMixtesCO2G = "";

    /** The max gaz cond mixtes FCG. */
    private String maxGazCondMixtesFCG = "";

    /** The max electric energy consumption EC. */
    private String maxElectricEnergyConsumptionEC = "";

    /** The max electric range PER. */
    private String maxElectricRangePER = "";

    /** The max electric energy consumption UFEC. */
    private String maxElectricEnergyConsumptionUFEC = "";

    /** The max electric range EAER. */
    private String maxElectricRangeEAER = "";

    /** The max all electric range AER. */
    // JIRA-454- Added below property as part of this JRA fix
    private String maxAllElectricRangeAER = "";

    /** The masse. */
    // JIRA-665- Added below property as part of this JIRA fix
    private String masse = "";

    // JIRA-719- Added below property as part of this JIRA fix
    private String w20EAERFiller = "";

    // JIRA-720- Added below property as part of this JIRA fix starts here
    private String w20AERFiller = "";
    private String w20PERFiller = "";
    private String w20MTACFiller = "";
    private String w20MOPTFiller = "";
    private String w20EMPTYMFiller = "";
    // JIRA-720- Added below property as part of this JIRA fix ends here

    /** The filler W 030. */
    private String fillerW030 = "";

    /** The validity date. */
    private String validityDate = "";

    /** The nedc cond mix co 2. */
    private String nedcCondMixCo2 = "";

    /** The nedc C cond mix fc. */
    private String nedcCCondMixFc = "";

    /** The wltp cond hybride comb WCCO 2. */
    private String wltpCondHybrideCombWCCO2 = "";

    /** The wltp cond hybrid comb WCFC. */
    private String wltpCondHybridCombWCFC = "";

    /** The nedc cond hybride mix WCCO 2. */
    private String nedcCondHybrideMixWCCO2 = "";

    /** The nedc cond hybride mix WCFC. */
    private String nedcCondHybrideMixWCFC = "";

    /** The wltp electric energy consumption comb UFEC. */
    private String wltpElectricEnergyConsumptionCombUFEC = "";

    /** The wltp all electric range comb EAER. */
    private String wltpAllElectricRangeCombEAER = "";

    /** The nedc electric energy consumption mix UFEC. */
    private String nedcElectricEnergyConsumptionMixUFEC = "";

    /** The nedc all electric range mix EAER. */
    private String nedcAllElectricRangeMixEAER = "";

    /** The wltp inj 2 cond comb CO 2 B. */
    private String wltpInj2CondCombCO2B = "";

    /** The wltp inj 2 cond comb FCB. */
    private String wltpInj2CondCombFCB = "";

    /** The nedc inj 2 cond mix CO 2 B. */
    private String nedcInj2CondMixCO2B = "";

    /** The nedc inj 2 cond mix FCB. */
    private String nedcInj2CondMixFCB = "";

    /** The wltp gaz cond comb CO 2 G. */
    private String wltpGazCondCombCO2G = "";

    /** The wltp gaz cond comb FCG. */
    private String wltpGazCondCombFCG = "";

    /** The nedc gaz cond mix CO 2 G. */
    private String nedcGazCondMixCO2G = "";

    /** The nedc gaz cond mix FCG. */
    private String nedcGazCondMixFCG = "";

    /** The wltp electric energy consumption comb EC. */
    private String wltpElectricEnergyConsumptionCombEC = "";

    /** The wltp electric range comb PER. */
    private String wltpElectricRangeCombPER = "";

    /** The nedc electric energy consumption mix EC. */
    private String nedcElectricEnergyConsumptionMixEC = "";

    /** The nedc electric range mix PER. */
    private String nedcElectricRangeMixPER = "";

    /** The wltp comb FCCD. */
    private String wltpCombFCCD = "";

    /** The wltp comb CRCD. */
    private String wltpCombCRCD = "";

    /** The wltp comb AERCD. */
    private String wltpCombAERCD = "";

    /** The wltp comb FCCS. */
    private String wltpCombFCCS = "";

    /** The wltp comb CO 2 CD. */
    private String wltpCombCO2CD = "";

    /** The wltp comb CO 2 CS. */
    private String wltpCombCO2CS = "";

    /** The wltp comb CE. */
    private String wltpCombCE = "";

    /** The wltp comb UFECC. */
    private String wltpCombUFECC = "";

    /** The wltp comb AER. */
    private String wltpCombAER = "";

    /** The wltp comb ECCD. */
    private String wltpCombECCD = "";

    /** The sending site. */
    private String sendingSite;

    /** The sending application. */
    private String sendingApplication;

    /** The header lot number. */
    private String headerLotNumber;

    /** The lot date. */
    private String lotDate;

    /** The maturity. */
    private String maturity;

    /**
     * Gets the maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Sets the maturity.
     *
     * @param maturity the new maturity
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * Gets the min all electric range AER.
     *
     * @return the min all electric range AER
     */
    public String getMinAllElectricRangeAER() {
        return minAllElectricRangeAER;
    }

    /**
     * Sets the min all electric range AER.
     *
     * @param miniAllElectricRangeAER the new min all electric range AER
     */
    public void setMinAllElectricRangeAER(String miniAllElectricRangeAER) {
        this.minAllElectricRangeAER = miniAllElectricRangeAER;
    }

    /**
     * Gets the max all electric range AER.
     *
     * @return the max all electric range AER
     */
    public String getMaxAllElectricRangeAER() {
        return maxAllElectricRangeAER;
    }

    /**
     * Sets the max all electric range AER.
     *
     * @param maxAllElectricRangeAER the new max all electric range AER
     */
    public void setMaxAllElectricRangeAER(String maxAllElectricRangeAER) {
        this.maxAllElectricRangeAER = maxAllElectricRangeAER;
    }

    /**
     * Gets the sending site.
     *
     * @return the sending site
     */
    public String getSendingSite() {
        return sendingSite;
    }

    /**
     * Sets the sending site.
     *
     * @param sendingSite the new sending site
     */
    public void setSendingSite(String sendingSite) {
        this.sendingSite = sendingSite;
    }

    /**
     * Gets the sending application.
     *
     * @return the sending application
     */
    public String getSendingApplication() {
        return sendingApplication;
    }

    /**
     * Sets the sending application.
     *
     * @param sendingApplication the new sending application
     */
    public void setSendingApplication(String sendingApplication) {
        this.sendingApplication = sendingApplication;
    }

    /**
     * Gets the header lot number.
     *
     * @return the header lot number
     */
    public String getHeaderLotNumber() {
        return headerLotNumber;
    }

    /**
     * Sets the header lot number.
     *
     * @param headerLotNumber the new header lot number
     */
    public void setHeaderLotNumber(String headerLotNumber) {
        this.headerLotNumber = headerLotNumber;
    }

    /**
     * Gets the lot date.
     *
     * @return the lot date
     */
    public String getLotDate() {
        return lotDate;
    }

    /**
     * Sets the lot date.
     *
     * @param lotDate the new lot date
     */
    public void setLotDate(String lotDate) {
        this.lotDate = lotDate;
    }

    /**
     * Gets the answer date.
     *
     * @return the answer date
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Gets the wltp comb FCCD.
     *
     * @return the wltp comb FCCD
     */
    public String getWltpCombFCCD() {
        return wltpCombFCCD;
    }

    /**
     * Sets the wltp comb FCCD.
     *
     * @param wltpCombFCCD the new wltp comb FCCD
     */
    public void setWltpCombFCCD(String wltpCombFCCD) {
        this.wltpCombFCCD = wltpCombFCCD;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the wltp comb CRCD.
     *
     * @return the wltp comb CRCD
     */
    public String getWltpCombCRCD() {
        return wltpCombCRCD;
    }

    /**
     * Sets the wltp comb CRCD.
     *
     * @param wltpCombCRCD the new wltp comb CRCD
     */
    public void setWltpCombCRCD(String wltpCombCRCD) {
        this.wltpCombCRCD = wltpCombCRCD;
    }

    /**
     * Gets the wltp comb AERCD.
     *
     * @return the wltp comb AERCD
     */
    public String getWltpCombAERCD() {
        return wltpCombAERCD;
    }

    /**
     * Sets the wltp comb AERCD.
     *
     * @param wltpCombAERCD the new wltp comb AERCD
     */
    public void setWltpCombAERCD(String wltpCombAERCD) {
        this.wltpCombAERCD = wltpCombAERCD;
    }

    /**
     * Gets the wltp comb FCCS.
     *
     * @return the wltp comb FCCS
     */
    public String getWltpCombFCCS() {
        return wltpCombFCCS;
    }

    /**
     * Sets the wltp comb FCCS.
     *
     * @param wltpCombFCCS the new wltp comb FCCS
     */
    public void setWltpCombFCCS(String wltpCombFCCS) {
        this.wltpCombFCCS = wltpCombFCCS;
    }

    /**
     * Gets the wltp comb CO 2 CD.
     *
     * @return the wltp comb CO 2 CD
     */
    public String getWltpCombCO2CD() {
        return wltpCombCO2CD;
    }

    /**
     * Sets the wltp comb CO 2 CD.
     *
     * @param wltpCombCO2CD the new wltp comb CO 2 CD
     */
    public void setWltpCombCO2CD(String wltpCombCO2CD) {
        this.wltpCombCO2CD = wltpCombCO2CD;
    }

    /**
     * Gets the wltp comb CO 2 CS.
     *
     * @return the wltp comb CO 2 CS
     */
    public String getWltpCombCO2CS() {
        return wltpCombCO2CS;
    }

    /**
     * Sets the wltp comb CO 2 CS.
     *
     * @param wltpCombCO2CS the new wltp comb CO 2 CS
     */
    public void setWltpCombCO2CS(String wltpCombCO2CS) {
        this.wltpCombCO2CS = wltpCombCO2CS;
    }

    /**
     * Gets the wltp comb CE.
     *
     * @return the wltp comb CE
     */
    public String getWltpCombCE() {
        return wltpCombCE;
    }

    /**
     * Sets the wltp comb CE.
     *
     * @param wltpCombCE the new wltp comb CE
     */
    public void setWltpCombCE(String wltpCombCE) {
        this.wltpCombCE = wltpCombCE;
    }

    /**
     * Gets the wltp comb UFECC.
     *
     * @return the wltp comb UFECC
     */
    public String getWltpCombUFECC() {
        return wltpCombUFECC;
    }

    /**
     * Sets the wltp comb UFECC.
     *
     * @param wltpCombUFECC the new wltp comb UFECC
     */
    public void setWltpCombUFECC(String wltpCombUFECC) {
        this.wltpCombUFECC = wltpCombUFECC;
    }

    /**
     * Gets the wltp comb AER.
     *
     * @return the wltp comb AER
     */
    public String getWltpCombAER() {
        return wltpCombAER;
    }

    /**
     * Sets the wltp comb AER.
     *
     * @param wltpCombAER the new wltp comb AER
     */
    public void setWltpCombAER(String wltpCombAER) {
        this.wltpCombAER = wltpCombAER;
    }

    /**
     * Gets the wltp comb ECCD.
     *
     * @return the wltp comb ECCD
     */
    public String getWltpCombECCD() {
        return wltpCombECCD;
    }

    /**
     * Sets the wltp comb ECCD.
     *
     * @param wltpCombECCD the new wltp comb ECCD
     */
    public void setWltpCombECCD(String wltpCombECCD) {
        this.wltpCombECCD = wltpCombECCD;
    }

    /**
     * Sets the answer date.
     *
     * @param answerDate the new answer date
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Gets the calculated comb co 2.
     *
     * @return the calculated comb co 2
     */
    public String getCalculatedCombCo2() {
        return calculatedCombCo2;
    }

    /**
     * Sets the calculated comb co 2.
     *
     * @param calculatedCombCo2 the new calculated comb co 2
     */
    public void setCalculatedCombCo2(String calculatedCombCo2) {
        this.calculatedCombCo2 = calculatedCombCo2;
    }

    /**
     * Gets the calculated comb fc.
     *
     * @return the calculated comb fc
     */
    public String getCalculatedCombFc() {
        return calculatedCombFc;
    }

    /**
     * Gets the mini cond hybride WCCO 2.
     *
     * @return the mini cond hybride WCCO 2
     */
    public String getMiniCondHybrideWCCO2() {
        return miniCondHybrideWCCO2;
    }

    /**
     * Sets the mini cond hybride WCCO 2.
     *
     * @param miniCondHybrideWCCO2 the new mini cond hybride WCCO 2
     */
    public void setMiniCondHybrideWCCO2(String miniCondHybrideWCCO2) {
        this.miniCondHybrideWCCO2 = miniCondHybrideWCCO2;
    }

    /**
     * Gets the mini cond hybride WCFC.
     *
     * @return the mini cond hybride WCFC
     */
    public String getMiniCondHybrideWCFC() {
        return miniCondHybrideWCFC;
    }

    /**
     * Sets the mini cond hybride WCFC.
     *
     * @param miniCondHybrideWCFC the new mini cond hybride WCFC
     */
    public void setMiniCondHybrideWCFC(String miniCondHybrideWCFC) {
        this.miniCondHybrideWCFC = miniCondHybrideWCFC;
    }

    /**
     * Gets the mini inj 2 cond mixte CO 2 B.
     *
     * @return the mini inj 2 cond mixte CO 2 B
     */
    public String getMiniInj2CondMixteCO2B() {
        return miniInj2CondMixteCO2B;
    }

    /**
     * Sets the mini inj 2 cond mixte CO 2 B.
     *
     * @param miniInj2CondMixteCO2B the new mini inj 2 cond mixte CO 2 B
     */
    public void setMiniInj2CondMixteCO2B(String miniInj2CondMixteCO2B) {
        this.miniInj2CondMixteCO2B = miniInj2CondMixteCO2B;
    }

    /**
     * Gets the mini inj 2 cond mixte FCB.
     *
     * @return the mini inj 2 cond mixte FCB
     */
    public String getMiniInj2CondMixteFCB() {
        return miniInj2CondMixteFCB;
    }

    /**
     * Sets the mini inj 2 cond mixte FCB.
     *
     * @param miniInj2CondMixteFCB the new mini inj 2 cond mixte FCB
     */
    public void setMiniInj2CondMixteFCB(String miniInj2CondMixteFCB) {
        this.miniInj2CondMixteFCB = miniInj2CondMixteFCB;
    }

    /**
     * Gets the mini gaz cond mixtes CO 2 G.
     *
     * @return the mini gaz cond mixtes CO 2 G
     */
    public String getMiniGazCondMixtesCO2G() {
        return miniGazCondMixtesCO2G;
    }

    /**
     * Sets the mini gaz cond mixtes CO 2 G.
     *
     * @param miniGazCondMixtesCO2G the new mini gaz cond mixtes CO 2 G
     */
    public void setMiniGazCondMixtesCO2G(String miniGazCondMixtesCO2G) {
        this.miniGazCondMixtesCO2G = miniGazCondMixtesCO2G;
    }

    /**
     * Gets the mini gaz cond mixtes FCG.
     *
     * @return the mini gaz cond mixtes FCG
     */
    public String getMiniGazCondMixtesFCG() {
        return miniGazCondMixtesFCG;
    }

    /**
     * Sets the mini gaz cond mixtes FCG.
     *
     * @param miniGazCondMixtesFCG the new mini gaz cond mixtes FCG
     */
    public void setMiniGazCondMixtesFCG(String miniGazCondMixtesFCG) {
        this.miniGazCondMixtesFCG = miniGazCondMixtesFCG;
    }

    /**
     * Gets the mini electric energy consumption EC.
     *
     * @return the mini electric energy consumption EC
     */
    public String getMiniElectricEnergyConsumptionEC() {
        return miniElectricEnergyConsumptionEC;
    }

    /**
     * Sets the mini electric energy consumption EC.
     *
     * @param miniElectricEnergyConsumptionEC the new mini electric energy consumption EC
     */
    public void setMiniElectricEnergyConsumptionEC(String miniElectricEnergyConsumptionEC) {
        this.miniElectricEnergyConsumptionEC = miniElectricEnergyConsumptionEC;
    }

    /**
     * Gets the mini electric range PER.
     *
     * @return the mini electric range PER
     */
    public String getMiniElectricRangePER() {
        return miniElectricRangePER;
    }

    /**
     * Sets the mini electric range PER.
     *
     * @param miniElectricRangePER the new mini electric range PER
     */
    public void setMiniElectricRangePER(String miniElectricRangePER) {
        this.miniElectricRangePER = miniElectricRangePER;
    }

    /**
     * Gets the mini electric energy consumption UFEC.
     *
     * @return the mini electric energy consumption UFEC
     */
    public String getMiniElectricEnergyConsumptionUFEC() {
        return miniElectricEnergyConsumptionUFEC;
    }

    /**
     * Sets the mini electric energy consumption UFEC.
     *
     * @param miniElectricEnergyConsumptionUFEC the new mini electric energy consumption UFEC
     */
    public void setMiniElectricEnergyConsumptionUFEC(String miniElectricEnergyConsumptionUFEC) {
        this.miniElectricEnergyConsumptionUFEC = miniElectricEnergyConsumptionUFEC;
    }

    /**
     * Gets the mini electric range EAER.
     *
     * @return the mini electric range EAER
     */
    public String getMiniElectricRangeEAER() {
        return miniElectricRangeEAER;
    }

    /**
     * Sets the mini electric range EAER.
     *
     * @param miniElectricRangeEAER the new mini electric range EAER
     */
    public void setMiniElectricRangeEAER(String miniElectricRangeEAER) {
        this.miniElectricRangeEAER = miniElectricRangeEAER;
    }

    /**
     * Gets the max cond hybride WCCO 2.
     *
     * @return the max cond hybride WCCO 2
     */
    public String getMaxCondHybrideWCCO2() {
        return maxCondHybrideWCCO2;
    }

    /**
     * Sets the max cond hybride WCCO 2.
     *
     * @param maxCondHybrideWCCO2 the new max cond hybride WCCO 2
     */
    public void setMaxCondHybrideWCCO2(String maxCondHybrideWCCO2) {
        this.maxCondHybrideWCCO2 = maxCondHybrideWCCO2;
    }

    /**
     * Gets the max cond hybride WCFC.
     *
     * @return the max cond hybride WCFC
     */
    public String getMaxCondHybrideWCFC() {
        return maxCondHybrideWCFC;
    }

    /**
     * Sets the max cond hybride WCFC.
     *
     * @param maxCondHybrideWCFC the new max cond hybride WCFC
     */
    public void setMaxCondHybrideWCFC(String maxCondHybrideWCFC) {
        this.maxCondHybrideWCFC = maxCondHybrideWCFC;
    }

    /**
     * Gets the max inj 2 cond mixte CO 2 B.
     *
     * @return the max inj 2 cond mixte CO 2 B
     */
    public String getMaxInj2CondMixteCO2B() {
        return maxInj2CondMixteCO2B;
    }

    /**
     * Sets the max inj 2 cond mixte CO 2 B.
     *
     * @param maxInj2CondMixteCO2B the new max inj 2 cond mixte CO 2 B
     */
    public void setMaxInj2CondMixteCO2B(String maxInj2CondMixteCO2B) {
        this.maxInj2CondMixteCO2B = maxInj2CondMixteCO2B;
    }

    /**
     * Gets the max inj 2 cond mixte FCB.
     *
     * @return the max inj 2 cond mixte FCB
     */
    public String getMaxInj2CondMixteFCB() {
        return maxInj2CondMixteFCB;
    }

    /**
     * Sets the max inj 2 cond mixte FCB.
     *
     * @param maxInj2CondMixteFCB the new max inj 2 cond mixte FCB
     */
    public void setMaxInj2CondMixteFCB(String maxInj2CondMixteFCB) {
        this.maxInj2CondMixteFCB = maxInj2CondMixteFCB;
    }

    /**
     * Gets the max gaz cond mixtes CO 2 G.
     *
     * @return the max gaz cond mixtes CO 2 G
     */
    public String getMaxGazCondMixtesCO2G() {
        return maxGazCondMixtesCO2G;
    }

    /**
     * Sets the max gaz cond mixtes CO 2 G.
     *
     * @param maxGazCondMixtesCO2G the new max gaz cond mixtes CO 2 G
     */
    public void setMaxGazCondMixtesCO2G(String maxGazCondMixtesCO2G) {
        this.maxGazCondMixtesCO2G = maxGazCondMixtesCO2G;
    }

    /**
     * Gets the max gaz cond mixtes FCG.
     *
     * @return the max gaz cond mixtes FCG
     */
    public String getMaxGazCondMixtesFCG() {
        return maxGazCondMixtesFCG;
    }

    /**
     * Sets the max gaz cond mixtes FCG.
     *
     * @param maxGazCondMixtesFCG the new max gaz cond mixtes FCG
     */
    public void setMaxGazCondMixtesFCG(String maxGazCondMixtesFCG) {
        this.maxGazCondMixtesFCG = maxGazCondMixtesFCG;
    }

    /**
     * Gets the max electric energy consumption EC.
     *
     * @return the max electric energy consumption EC
     */
    public String getMaxElectricEnergyConsumptionEC() {
        return maxElectricEnergyConsumptionEC;
    }

    /**
     * Sets the max electric energy consumption EC.
     *
     * @param maxElectricEnergyConsumptionEC the new max electric energy consumption EC
     */
    public void setMaxElectricEnergyConsumptionEC(String maxElectricEnergyConsumptionEC) {
        this.maxElectricEnergyConsumptionEC = maxElectricEnergyConsumptionEC;
    }

    /**
     * Gets the max electric range PER.
     *
     * @return the max electric range PER
     */
    public String getMaxElectricRangePER() {
        return maxElectricRangePER;
    }

    /**
     * Sets the max electric range PER.
     *
     * @param maxElectricRangePER the new max electric range PER
     */
    public void setMaxElectricRangePER(String maxElectricRangePER) {
        this.maxElectricRangePER = maxElectricRangePER;
    }

    /**
     * Gets the max electric energy consumption UFEC.
     *
     * @return the max electric energy consumption UFEC
     */
    public String getMaxElectricEnergyConsumptionUFEC() {
        return maxElectricEnergyConsumptionUFEC;
    }

    /**
     * Sets the max electric energy consumption UFEC.
     *
     * @param maxElectricEnergyConsumptionUFEC the new max electric energy consumption UFEC
     */
    public void setMaxElectricEnergyConsumptionUFEC(String maxElectricEnergyConsumptionUFEC) {
        this.maxElectricEnergyConsumptionUFEC = maxElectricEnergyConsumptionUFEC;
    }

    /**
     * Gets the max electric range EAER.
     *
     * @return the max electric range EAER
     */
    public String getMaxElectricRangeEAER() {
        return maxElectricRangeEAER;
    }

    /**
     * Sets the max electric range EAER.
     *
     * @param maxElectricRangeEAER the new max electric range EAER
     */
    public void setMaxElectricRangeEAER(String maxElectricRangeEAER) {
        this.maxElectricRangeEAER = maxElectricRangeEAER;
    }

    /**
     * Gets the filler W 030.
     *
     * @return the filler W 030
     */
    public String getFillerW030() {
        return fillerW030;
    }

    /**
     * Sets the filler W 030.
     *
     * @param fillerW030 the new filler W 030
     */
    public void setFillerW030(String fillerW030) {
        this.fillerW030 = fillerW030;
    }

    /**
     * Sets the calculated comb fc.
     *
     * @param calculatedCombFc the new calculated comb fc
     */
    public void setCalculatedCombFc(String calculatedCombFc) {
        this.calculatedCombFc = calculatedCombFc;
    }

    /** The physical quantities. */
    private List<EnginePhysicalQuantity> physicalQuantities;

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<EnginePhysicalQuantity> getPhysicalQuantities() {
        return physicalQuantities;
    }

    /**
     * Sets the physical quantities.
     *
     * @param physicalQuantities the new physical quantities
     */
    public void setPhysicalQuantities(List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
    }

    /**
     * Gets the prd.
     *
     * @return the prd
     */
    public String getPrd() {
        return prd;
    }

    /**
     * Sets the prd.
     *
     * @param prd the new prd
     */
    public void setPrd(String prd) {
        this.prd = prd;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the v low fuel consumption.
     *
     * @return the v low fuel consumption
     */
    public String getvLowFuelConsumption() {
        return vLowFuelConsumption;
    }

    /**
     * Gets the validity date.
     *
     * @return the validity date
     */
    public String getValidityDate() {
        return validityDate;
    }

    /**
     * Sets the validity date.
     *
     * @param validityDate the new validity date
     */
    public void setValidityDate(String validityDate) {
        this.validityDate = validityDate;
    }

    /**
     * Gets the nedc cond mix co 2.
     *
     * @return the nedc cond mix co 2
     */
    public String getNedcCondMixCo2() {
        return nedcCondMixCo2;
    }

    /**
     * Sets the nedc cond mix co 2.
     *
     * @param nedcCondMixCo2 the new nedc cond mix co 2
     */
    public void setNedcCondMixCo2(String nedcCondMixCo2) {
        this.nedcCondMixCo2 = nedcCondMixCo2;
    }

    /**
     * Gets the nedc C cond mix fc.
     *
     * @return the nedc C cond mix fc
     */
    public String getNedcCCondMixFc() {
        return nedcCCondMixFc;
    }

    /**
     * Sets the nedc C cond mix fc.
     *
     * @param nedcCCondMixFc the new nedc C cond mix fc
     */
    public void setNedcCCondMixFc(String nedcCCondMixFc) {
        this.nedcCCondMixFc = nedcCCondMixFc;
    }

    /**
     * Gets the wltp cond hybride comb WCCO 2.
     *
     * @return the wltp cond hybride comb WCCO 2
     */
    public String getWltpCondHybrideCombWCCO2() {
        return wltpCondHybrideCombWCCO2;
    }

    /**
     * Sets the wltp cond hybride comb WCCO 2.
     *
     * @param wltpCondHybrideCombWCCO2 the new wltp cond hybride comb WCCO 2
     */
    public void setWltpCondHybrideCombWCCO2(String wltpCondHybrideCombWCCO2) {
        this.wltpCondHybrideCombWCCO2 = wltpCondHybrideCombWCCO2;
    }

    /**
     * Gets the wltp cond hybrid comb WCFC.
     *
     * @return the wltp cond hybrid comb WCFC
     */
    public String getWltpCondHybridCombWCFC() {
        return wltpCondHybridCombWCFC;
    }

    /**
     * Sets the wltp cond hybrid comb WCFC.
     *
     * @param wltpCondHybridCombWCFC the new wltp cond hybrid comb WCFC
     */
    public void setWltpCondHybridCombWCFC(String wltpCondHybridCombWCFC) {
        this.wltpCondHybridCombWCFC = wltpCondHybridCombWCFC;
    }

    /**
     * Gets the nedc cond hybride mix WCCO 2.
     *
     * @return the nedc cond hybride mix WCCO 2
     */
    public String getNedcCondHybrideMixWCCO2() {
        return nedcCondHybrideMixWCCO2;
    }

    /**
     * Sets the nedc cond hybride mix WCCO 2.
     *
     * @param nedcCondHybrideMixWCCO2 the new nedc cond hybride mix WCCO 2
     */
    public void setNedcCondHybrideMixWCCO2(String nedcCondHybrideMixWCCO2) {
        this.nedcCondHybrideMixWCCO2 = nedcCondHybrideMixWCCO2;
    }

    /**
     * Gets the nedc cond hybride mix WCFC.
     *
     * @return the nedc cond hybride mix WCFC
     */
    public String getNedcCondHybrideMixWCFC() {
        return nedcCondHybrideMixWCFC;
    }

    /**
     * Sets the nedc cond hybride mix WCFC.
     *
     * @param nedcCondHybrideMixWCFC the new nedc cond hybride mix WCFC
     */
    public void setNedcCondHybrideMixWCFC(String nedcCondHybrideMixWCFC) {
        this.nedcCondHybrideMixWCFC = nedcCondHybrideMixWCFC;
    }

    /**
     * Gets the wltp electric energy consumption comb UFEC.
     *
     * @return the wltp electric energy consumption comb UFEC
     */
    public String getWltpElectricEnergyConsumptionCombUFEC() {
        return wltpElectricEnergyConsumptionCombUFEC;
    }

    /**
     * Sets the wltp electric energy consumption comb UFEC.
     *
     * @param wltpElectricEnergyConsumptionCombUFEC the new wltp electric energy consumption comb UFEC
     */
    public void setWltpElectricEnergyConsumptionCombUFEC(String wltpElectricEnergyConsumptionCombUFEC) {
        this.wltpElectricEnergyConsumptionCombUFEC = wltpElectricEnergyConsumptionCombUFEC;
    }

    /**
     * Gets the wltp all electric range comb EAER.
     *
     * @return the wltp all electric range comb EAER
     */
    public String getWltpAllElectricRangeCombEAER() {
        return wltpAllElectricRangeCombEAER;
    }

    /**
     * Sets the wltp all electric range comb EAER.
     *
     * @param wltpAllElectricRangeCombEAER the new wltp all electric range comb EAER
     */
    public void setWltpAllElectricRangeCombEAER(String wltpAllElectricRangeCombEAER) {
        this.wltpAllElectricRangeCombEAER = wltpAllElectricRangeCombEAER;
    }

    /**
     * Gets the nedc electric energy consumption mix UFEC.
     *
     * @return the nedc electric energy consumption mix UFEC
     */
    public String getNedcElectricEnergyConsumptionMixUFEC() {
        return nedcElectricEnergyConsumptionMixUFEC;
    }

    /**
     * Sets the nedc electric energy consumption mix UFEC.
     *
     * @param nedcElectricEnergyConsumptionMixUFEC the new nedc electric energy consumption mix UFEC
     */
    public void setNedcElectricEnergyConsumptionMixUFEC(String nedcElectricEnergyConsumptionMixUFEC) {
        this.nedcElectricEnergyConsumptionMixUFEC = nedcElectricEnergyConsumptionMixUFEC;
    }

    /**
     * Gets the nedc all electric range mix EAER.
     *
     * @return the nedc all electric range mix EAER
     */
    public String getNedcAllElectricRangeMixEAER() {
        return nedcAllElectricRangeMixEAER;
    }

    /**
     * Sets the nedc all electric range mix EAER.
     *
     * @param nedcAllElectricRangeMixEAER the new nedc all electric range mix EAER
     */
    public void setNedcAllElectricRangeMixEAER(String nedcAllElectricRangeMixEAER) {
        this.nedcAllElectricRangeMixEAER = nedcAllElectricRangeMixEAER;
    }

    /**
     * Gets the wltp inj 2 cond comb CO 2 B.
     *
     * @return the wltp inj 2 cond comb CO 2 B
     */
    public String getWltpInj2CondCombCO2B() {
        return wltpInj2CondCombCO2B;
    }

    /**
     * Sets the wltp inj 2 cond comb CO 2 B.
     *
     * @param wltpInj2CondCombCO2B the new wltp inj 2 cond comb CO 2 B
     */
    public void setWltpInj2CondCombCO2B(String wltpInj2CondCombCO2B) {
        this.wltpInj2CondCombCO2B = wltpInj2CondCombCO2B;
    }

    /**
     * Gets the wltp inj 2 cond comb FCB.
     *
     * @return the wltp inj 2 cond comb FCB
     */
    public String getWltpInj2CondCombFCB() {
        return wltpInj2CondCombFCB;
    }

    /**
     * Sets the wltp inj 2 cond comb FCB.
     *
     * @param wltpInj2CondCombFCB the new wltp inj 2 cond comb FCB
     */
    public void setWltpInj2CondCombFCB(String wltpInj2CondCombFCB) {
        this.wltpInj2CondCombFCB = wltpInj2CondCombFCB;
    }

    /**
     * Gets the nedc inj 2 cond mix CO 2 B.
     *
     * @return the nedc inj 2 cond mix CO 2 B
     */
    public String getNedcInj2CondMixCO2B() {
        return nedcInj2CondMixCO2B;
    }

    /**
     * Sets the nedc inj 2 cond mix CO 2 B.
     *
     * @param nedcInj2CondMixCO2B the new nedc inj 2 cond mix CO 2 B
     */
    public void setNedcInj2CondMixCO2B(String nedcInj2CondMixCO2B) {
        this.nedcInj2CondMixCO2B = nedcInj2CondMixCO2B;
    }

    /**
     * Gets the nedc inj 2 cond mix FCB.
     *
     * @return the nedc inj 2 cond mix FCB
     */
    public String getNedcInj2CondMixFCB() {
        return nedcInj2CondMixFCB;
    }

    /**
     * Sets the nedc inj 2 cond mix FCB.
     *
     * @param nedcInj2CondMixFCB the new nedc inj 2 cond mix FCB
     */
    public void setNedcInj2CondMixFCB(String nedcInj2CondMixFCB) {
        this.nedcInj2CondMixFCB = nedcInj2CondMixFCB;
    }

    /**
     * Gets the wltp gaz cond comb CO 2 G.
     *
     * @return the wltp gaz cond comb CO 2 G
     */
    public String getWltpGazCondCombCO2G() {
        return wltpGazCondCombCO2G;
    }

    /**
     * Sets the wltp gaz cond comb CO 2 G.
     *
     * @param wltpGazCondCombCO2G the new wltp gaz cond comb CO 2 G
     */
    public void setWltpGazCondCombCO2G(String wltpGazCondCombCO2G) {
        this.wltpGazCondCombCO2G = wltpGazCondCombCO2G;
    }

    /**
     * Gets the wltp gaz cond comb FCG.
     *
     * @return the wltp gaz cond comb FCG
     */
    public String getWltpGazCondCombFCG() {
        return wltpGazCondCombFCG;
    }

    /**
     * Sets the wltp gaz cond comb FCG.
     *
     * @param wltpGazCondCombFCG the new wltp gaz cond comb FCG
     */
    public void setWltpGazCondCombFCG(String wltpGazCondCombFCG) {
        this.wltpGazCondCombFCG = wltpGazCondCombFCG;
    }

    /**
     * Gets the nedc gaz cond mix CO 2 G.
     *
     * @return the nedc gaz cond mix CO 2 G
     */
    public String getNedcGazCondMixCO2G() {
        return nedcGazCondMixCO2G;
    }

    /**
     * Sets the nedc gaz cond mix CO 2 G.
     *
     * @param nedcGazCondMixCO2G the new nedc gaz cond mix CO 2 G
     */
    public void setNedcGazCondMixCO2G(String nedcGazCondMixCO2G) {
        this.nedcGazCondMixCO2G = nedcGazCondMixCO2G;
    }

    /**
     * Gets the nedc gaz cond mix FCG.
     *
     * @return the nedc gaz cond mix FCG
     */
    public String getNedcGazCondMixFCG() {
        return nedcGazCondMixFCG;
    }

    /**
     * Sets the nedc gaz cond mix FCG.
     *
     * @param nedcGazCondMixFCG the new nedc gaz cond mix FCG
     */
    public void setNedcGazCondMixFCG(String nedcGazCondMixFCG) {
        this.nedcGazCondMixFCG = nedcGazCondMixFCG;
    }

    /**
     * Gets the wltp electric energy consumption comb EC.
     *
     * @return the wltp electric energy consumption comb EC
     */
    public String getWltpElectricEnergyConsumptionCombEC() {
        return wltpElectricEnergyConsumptionCombEC;
    }

    /**
     * Sets the wltp electric energy consumption comb EC.
     *
     * @param wltpElectricEnergyConsumptionCombEC the new wltp electric energy consumption comb EC
     */
    public void setWltpElectricEnergyConsumptionCombEC(String wltpElectricEnergyConsumptionCombEC) {
        this.wltpElectricEnergyConsumptionCombEC = wltpElectricEnergyConsumptionCombEC;
    }

    /**
     * Gets the wltp electric range comb PER.
     *
     * @return the wltp electric range comb PER
     */
    public String getWltpElectricRangeCombPER() {
        return wltpElectricRangeCombPER;
    }

    /**
     * Sets the wltp electric range comb PER.
     *
     * @param wltpElectricRangeCombPER the new wltp electric range comb PER
     */
    public void setWltpElectricRangeCombPER(String wltpElectricRangeCombPER) {
        this.wltpElectricRangeCombPER = wltpElectricRangeCombPER;
    }

    /**
     * Gets the nedc electric energy consumption mix EC.
     *
     * @return the nedc electric energy consumption mix EC
     */
    public String getNedcElectricEnergyConsumptionMixEC() {
        return nedcElectricEnergyConsumptionMixEC;
    }

    /**
     * Sets the nedc electric energy consumption mix EC.
     *
     * @param nedcElectricEnergyConsumptionMixEC the new nedc electric energy consumption mix EC
     */
    public void setNedcElectricEnergyConsumptionMixEC(String nedcElectricEnergyConsumptionMixEC) {
        this.nedcElectricEnergyConsumptionMixEC = nedcElectricEnergyConsumptionMixEC;
    }

    /**
     * Gets the nedc electric range mix PER.
     *
     * @return the nedc electric range mix PER
     */
    public String getNedcElectricRangeMixPER() {
        return nedcElectricRangeMixPER;
    }

    /**
     * Sets the nedc electric range mix PER.
     *
     * @param nedcElectricRangeMixPER the new nedc electric range mix PER
     */
    public void setNedcElectricRangeMixPER(String nedcElectricRangeMixPER) {
        this.nedcElectricRangeMixPER = nedcElectricRangeMixPER;
    }

    /**
     * Sets the v low fuel consumption.
     *
     * @param vLowFuelConsumption the new v low fuel consumption
     */
    public void setvLowFuelConsumption(String vLowFuelConsumption) {
        this.vLowFuelConsumption = vLowFuelConsumption;
    }

    /**
     * Gets the v high fuel consumption.
     *
     * @return the v high fuel consumption
     */
    public String getvHighFuelConsumption() {
        return vHighFuelConsumption;
    }

    /**
     * Sets the v high fuel consumption.
     *
     * @param vHighFuelConsumption the new v high fuel consumption
     */
    public void setvHighFuelConsumption(String vHighFuelConsumption) {
        this.vHighFuelConsumption = vHighFuelConsumption;
    }

    /**
     * Gets the v low cycle energy.
     *
     * @return the v low cycle energy
     */
    public String getvLowCycleEnergy() {
        return vLowCycleEnergy;
    }

    /**
     * Sets the v low cycle energy.
     *
     * @param vLowCycleEnergy the new v low cycle energy
     */
    public void setvLowCycleEnergy(String vLowCycleEnergy) {
        this.vLowCycleEnergy = vLowCycleEnergy;
    }

    /**
     * Gets the v high cycle energy.
     *
     * @return the v high cycle energy
     */
    public String getvHighCycleEnergy() {
        return vHighCycleEnergy;
    }

    /**
     * Sets the v high cycle energy.
     *
     * @param vHighCycleEnergy the new v high cycle energy
     */
    public void setvHighCycleEnergy(String vHighCycleEnergy) {
        this.vHighCycleEnergy = vHighCycleEnergy;
    }

    /**
     * Gets the ext attr.
     *
     * @return the ext attr
     */
    public String getExtAttr() {
        return extAttr;
    }

    /**
     * Sets the ext attr.
     *
     * @param extAttr the new ext attr
     */
    public void setExtAttr(String extAttr) {
        this.extAttr = extAttr;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the mass socle.
     *
     * @return the mass socle
     */
    public String getMassSocle() {
        return massSocle;
    }

    /**
     * Sets the mass socle.
     *
     * @param massSocle the new mass socle
     */
    public void setMassSocle(String massSocle) {
        this.massSocle = massSocle;
    }

    /**
     * Gets the mass equip.
     *
     * @return the mass equip
     */
    public String getMassEquip() {
        return massEquip;
    }

    /**
     * Sets the mass equip.
     *
     * @param massEquip the new mass equip
     */
    public void setMassEquip(String massEquip) {
        this.massEquip = massEquip;
    }

    /**
     * Gets the mass vehic.
     *
     * @return the mass vehic
     */
    public String getMassVehic() {
        return massVehic;
    }

    /**
     * Sets the mass vehic.
     *
     * @param massVehic the new mass vehic
     */
    public void setMassVehic(String massVehic) {
        this.massVehic = massVehic;
    }

    /**
     * Gets the scx socle.
     *
     * @return the scx socle
     */
    public String getScxSocle() {
        return scxSocle;
    }

    /**
     * Sets the scx socle.
     *
     * @param scxSocle the new scx socle
     */
    public void setScxSocle(String scxSocle) {
        this.scxSocle = scxSocle;
    }

    /**
     * Gets the scx equip.
     *
     * @return the scx equip
     */
    public String getScxEquip() {
        return scxEquip;
    }

    /**
     * Sets the scx equip.
     *
     * @param scxEquip the new scx equip
     */
    public void setScxEquip(String scxEquip) {
        this.scxEquip = scxEquip;
    }

    /**
     * Gets the scx vehic.
     *
     * @return the scx vehic
     */
    public String getScxVehic() {
        return scxVehic;
    }

    /**
     * Sets the scx vehic.
     *
     * @param scxVehic the new scx vehic
     */
    public void setScxVehic(String scxVehic) {
        this.scxVehic = scxVehic;
    }

    /**
     * Gets the crr vehic.
     *
     * @return the crr vehic
     */
    public String getCrrVehic() {
        return crrVehic;
    }

    /**
     * Sets the crr vehic.
     *
     * @param crrVehic the new crr vehic
     */
    public void setCrrVehic(String crrVehic) {
        this.crrVehic = crrVehic;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the internal request id.
     *
     * @return the internal request id
     */
    public String getInternalRequestId() {
        return internalRequestId;
    }

    /**
     * Sets the internal request id.
     *
     * @param internalRequestId the new internal request id
     */
    public void setInternalRequestId(String internalRequestId) {
        this.internalRequestId = internalRequestId;
    }

    /**
     * Gets the version 16.
     *
     * @return the version 16
     */
    public String getVersion16() {
        return version16;
    }

    /**
     * Gets the road load.
     *
     * @return the road load
     */
    public String getRoadLoad() {
        return roadLoad;
    }

    /**
     * Sets the road load.
     *
     * @param roadLoad the new road load
     */
    public void setRoadLoad(String roadLoad) {
        this.roadLoad = roadLoad;
    }

    /**
     * Sets the version 16.
     *
     * @param version16 the new version 16
     */
    public void setVersion16(String version16) {
        this.version16 = version16;
    }

    /**
     * Gets the brand.
     *
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Sets the brand.
     *
     * @param brand the new brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public String getOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(String options) {
        this.options = options;
    }

    /**
     * Gets the gestion.
     *
     * @return the gestion
     */
    public String getGestion() {
        return gestion;
    }

    /**
     * Sets the gestion.
     *
     * @param gestion the new gestion
     */
    public void setGestion(String gestion) {
        this.gestion = gestion;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Gets the v low.
     *
     * @return the v low
     */
    public String getvLow() {
        return vLow;
    }

    /**
     * Sets the v low.
     *
     * @param vLow the new v low
     */
    public void setvLow(String vLow) {
        this.vLow = vLow;
    }

    /**
     * Gets the v high.
     *
     * @return the v high
     */
    public String getvHigh() {
        return vHigh;
    }

    /**
     * Sets the v high.
     *
     * @param vHigh the new v high
     */
    public void setvHigh(String vHigh) {
        this.vHigh = vHigh;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the filler.
     *
     * @return the filler
     */
    public String getFiller() {
        return filler;
    }

    /**
     * Sets the filler.
     *
     * @param filler the new filler
     */
    public void setFiller(String filler) {
        this.filler = filler;
    }

    /**
     * Instantiates a new ao geos dto.
     */
    public AoCronosEliadeDto() {
        super();
    }

    /**
     * Gets the end date.
     *
     * @return the end date
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date.
     *
     * @param endDate the new end date
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * Gets the lot number.
     *
     * @return the lot number
     */
    public String getLotNumber() {
        return lotNumber;
    }

    /**
     * Sets the lot number.
     *
     * @param lotNumber the new lot number
     */
    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    /**
     * Gets the line number.
     *
     * @return the line number
     */
    public String getLineNumber() {
        return lineNumber;
    }

    /**
     * Sets the line number.
     *
     * @param lineNumber the new line number
     */
    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * Gets the vehicle type.
     *
     * @return the vehicle type
     */
    public String getVehicleType() {
        return vehicleType;
    }

    /**
     * Sets the vehicle type.
     *
     * @param vehicleType the new vehicle type
     */
    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the moment code 20.
     *
     * @return the moment code 20
     */
    public String getMomentCode20() {
        return momentCode20;
    }

    /**
     * Sets the moment code 20.
     *
     * @param momentCode20 the new moment code 20
     */
    public void setMomentCode20(String momentCode20) {
        this.momentCode20 = momentCode20;
    }

    /**
     * Gets the moment code 30.
     *
     * @return the moment code 30
     */
    public String getMomentCode30() {
        return momentCode30;
    }

    /**
     * Sets the moment code 30.
     *
     * @param momentCode30 the new moment code 30
     */
    public void setMomentCode30(String momentCode30) {
        this.momentCode30 = momentCode30;
    }

    /**
     * Gets the options 7 C.
     *
     * @return the options 7 C
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options 7 C.
     *
     * @param options7c the new options 7 C
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the gestion 5 C.
     *
     * @return the gestion 5 C
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion 5 C.
     *
     * @param gestion5c the new gestion 5 C
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion 7 C.
     *
     * @return the gestion 7 C
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion 7 C.
     *
     * @param gestion7c the new gestion 7 C
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Getter avoidCache
     * 
     * @return the avoidCache
     */
    public Boolean getAvoidCache() {
        return avoidCache;
    }

    /**
     * Setter avoidCache
     * 
     * @param avoidCache the avoidCache to set
     */
    public void setAvoidCache(Boolean avoidCache) {
        this.avoidCache = avoidCache;
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * Sets the family.
     *
     * @param family the new family
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * Gets the extended title.
     *
     * @return the extended title
     */
    public String getExtendedTitle() {
        return extendedTitle;
    }

    /**
     * Sets the extended title.
     *
     * @param extendedTitle the new extended title
     */
    public void setExtendedTitle(String extendedTitle) {
        this.extendedTitle = extendedTitle;
    }

    /**
     * Physical quantities.
     *
     * @return the optional
     */
    public Optional<List<EnginePhysicalQuantity>> physicalQuantities() {
        if (this.physicalQuantities == null)
            return Optional.empty();
        return Optional.of(this.physicalQuantities);
    }

    /**
     * Update physical quantities.
     *
     * @param physicalQuantities the physical quantities
     * @return the ao geos dto
     */
    public AoCronosEliadeDto updatePhysicalQuantities(
            @NotEmpty(message = "When updating the physical quantities, the list must neither be null nor empty") List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
        return this;
    }

    /**
     * Gets the masse.
     *
     * @return the masse
     */
    public String getMasse() {
        return masse;
    }

    /**
     * Sets the masse.
     *
     * @param masse the new masse
     */
    public void setMasse(String masse) {
        this.masse = masse;
    }

    /**
     * Getter w20EAERFiller
     * 
     * @return the w20EAERFiller
     */
    public String getW20EAERFiller() {
        return w20EAERFiller;
    }

    /**
     * Setter w20EAERFiller
     * 
     * @param w20eaerFiller the w20EAERFiller to set
     */
    public void setW20EAERFiller(String w20eaerFiller) {
        w20EAERFiller = w20eaerFiller;
    }

    /**
     * Getter w20AERFiller
     * 
     * @return the w20AERFiller
     */
    public String getW20AERFiller() {
        return w20AERFiller;
    }

    /**
     * Setter w20AERFiller
     * 
     * @param w20aerFiller the w20AERFiller to set
     */
    public void setW20AERFiller(String w20aerFiller) {
        w20AERFiller = w20aerFiller;
    }

    /**
     * Getter w20PERFiller
     * 
     * @return the w20PERFiller
     */
    public String getW20PERFiller() {
        return w20PERFiller;
    }

    /**
     * Setter w20PERFiller
     * 
     * @param w20perFiller the w20PERFiller to set
     */
    public void setW20PERFiller(String w20perFiller) {
        w20PERFiller = w20perFiller;
    }

    /**
     * Getter w20MTACFiller
     * 
     * @return the w20MTACFiller
     */
    public String getW20MTACFiller() {
        return w20MTACFiller;
    }

    /**
     * Setter w20MTACFiller
     * 
     * @param w20mtacFiller the w20MTACFiller to set
     */
    public void setW20MTACFiller(String w20mtacFiller) {
        w20MTACFiller = w20mtacFiller;
    }

    /**
     * Getter w20MOPTFiller
     * 
     * @return the w20MOPTFiller
     */
    public String getW20MOPTFiller() {
        return w20MOPTFiller;
    }

    /**
     * Setter w20MOPTFiller
     * 
     * @param w20moptFiller the w20MOPTFiller to set
     */
    public void setW20MOPTFiller(String w20moptFiller) {
        w20MOPTFiller = w20moptFiller;
    }

    /**
     * Getter w20EMPTYMFiller
     * 
     * @return the w20EMPTYMFiller
     */
    public String getW20EMPTYMFiller() {
        return w20EMPTYMFiller;
    }

    /**
     * Setter w20EMPTYMFiller
     * 
     * @param w20emptymFiller the w20EMPTYMFiller to set
     */
    public void setW20EMPTYMFiller(String w20emptymFiller) {
        w20EMPTYMFiller = w20emptymFiller;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        this.momentCode20 = this.momentCode20 + "    ";
        this.momentCode20 = this.momentCode20.substring(0, 4);

        this.prd = this.prd + "   ";
        this.prd = this.prd.substring(0, 3);

        this.brand = this.brand + "  ";
        this.brand = this.brand.substring(0, 2);

        this.tradingCountry = this.tradingCountry + "  ";
        this.tradingCountry = this.tradingCountry.substring(0, 2);

        this.version16 = this.version16 + "                ";
        if (!version16.isEmpty())
            this.version16 = this.version16.substring(0, 16);

        this.colorExtInt = this.colorExtInt + "        ";
        if (!colorExtInt.isEmpty())
            this.colorExtInt = this.colorExtInt.substring(0, 8);
        this.options7C = this.options7C
                + "                                                                                                                                                                                                                                                                                        ";
        if (!options7C.isEmpty())
            this.options7C = this.options7C.substring(0, 280);

        this.gestion7C = this.gestion7C
                + "                                                                                                                                                                                                                                                                                                                                                              ";
        if (!gestion7C.isEmpty())
            this.gestion7C = this.gestion7C.substring(0, 350);

        this.masse = this.masse + "        ";// Added as part of JIRA-665

        if (!masse.isEmpty())
            this.masse = this.masse.substring(0, 8);// Added as part of JIRA-665

        this.w20EAERFiller = "        " + this.w20EAERFiller;// Added as part of JIRA-719
        if (!w20EAERFiller.isEmpty())
            this.w20EAERFiller = this.w20EAERFiller.substring(w20EAERFiller.length() - 8);// Added as part of JIRA-719

        // Added as part of JIRA-720 starts here
        this.w20AERFiller = "        " + this.w20AERFiller;
        if (!w20AERFiller.isEmpty())
            this.w20AERFiller = this.w20AERFiller.substring(w20AERFiller.length() - 8);

        this.w20PERFiller = "        " + this.w20PERFiller;
        if (!w20PERFiller.isEmpty())
            this.w20PERFiller = this.w20PERFiller.substring(w20PERFiller.length() - 8);

        this.w20MTACFiller = "        " + this.w20MTACFiller;
        if (!w20MTACFiller.isEmpty())
            this.w20MTACFiller = this.w20MTACFiller.substring(w20MTACFiller.length() - 8);

        this.w20MOPTFiller = "        " + this.w20MOPTFiller;
        if (!w20MOPTFiller.isEmpty())
            this.w20MOPTFiller = this.w20MOPTFiller.substring(w20MOPTFiller.length() - 8);

        this.w20EMPTYMFiller = "        " + this.w20EMPTYMFiller;
        if (!w20EMPTYMFiller.isEmpty())
            this.w20EMPTYMFiller = this.w20EMPTYMFiller.substring(w20EMPTYMFiller.length() - 8);

        // Added as part of JIRA-720 ends here

        this.filler = this.filler
                + "                                                                                                                                        ";
        if (!filler.isEmpty())
            this.filler = this.filler.substring(0, 80); // Modified the filler length 136 to 128 as part of JIRA-665 and length 128 to 120 as part of
        // Jira-719 and from 120 to 80 as a part of JIRA-720

        // this.filler = this.filler
        // + " ";
        // if (!filler.isEmpty())
        // this.filler = this.filler.substring(0, 120); // Modified the filler length 136 to 128 as part of JIRA-665 and length 128 to 120 as part of
        // Jira-719

        // this.filler = this.filler
        // + " ";
        // if (!filler.isEmpty())
        // this.filler = this.filler.substring(0, 136);

        this.answerCode = this.answerCode + "        ";
        if (!answerCode.isEmpty())
            this.answerCode = this.answerCode.substring(0, 8);

        this.answerDesignation = this.answerDesignation + "                                                  ";
        if (!answerDesignation.isEmpty())
            this.answerDesignation = this.answerDesignation.substring(0, 50);

        this.lotNumber = this.lotNumber + "     ";
        if (!lotNumber.isEmpty())
            this.lotNumber = this.lotNumber.substring(0, 5);

        this.lineNumber = this.lineNumber + "            ";
        if (!lineNumber.isEmpty())
            this.lineNumber = this.lineNumber.substring(0, 12);

        this.vehicleType = this.vehicleType + "     ";
        if (!vehicleType.isEmpty())
            this.vehicleType = this.vehicleType.substring(0, 5);

        this.family = this.family + "     ";
        this.family = this.family.substring(0, 5);
        this.code = this.code + "     ";
        this.code = this.code.substring(0, 5);
        this.calculatedCombCo2 = "        " + this.calculatedCombCo2;
        if (!calculatedCombCo2.isEmpty())
            this.calculatedCombCo2 = this.calculatedCombCo2.substring(calculatedCombCo2.length() - 8);
        this.calculatedCombFc = "        " + this.calculatedCombFc;
        if (!calculatedCombFc.isEmpty())
            this.calculatedCombFc = this.calculatedCombFc.substring(calculatedCombFc.length() - 8);

        this.validityDate = this.validityDate + "        ";
        if (!validityDate.isEmpty())
            this.validityDate = this.validityDate.substring(0, 8);

        this.nedcCondMixCo2 = "        " + this.nedcCondMixCo2;
        if (!nedcCondMixCo2.isEmpty())
            this.nedcCondMixCo2 = this.nedcCondMixCo2.substring(nedcCondMixCo2.length() - 8);

        this.nedcCCondMixFc = "        " + this.nedcCCondMixFc;
        if (!nedcCCondMixFc.isEmpty())
            this.nedcCCondMixFc = this.nedcCCondMixFc.substring(nedcCCondMixFc.length() - 8);

        this.wltpCondHybrideCombWCCO2 = "        " + this.wltpCondHybrideCombWCCO2;
        if (!wltpCondHybrideCombWCCO2.isEmpty())
            this.wltpCondHybrideCombWCCO2 = this.wltpCondHybrideCombWCCO2.substring(wltpCondHybrideCombWCCO2.length() - 8);

        this.wltpCondHybridCombWCFC = "        " + this.wltpCondHybridCombWCFC;
        if (!wltpCondHybridCombWCFC.isEmpty())
            this.wltpCondHybridCombWCFC = this.wltpCondHybridCombWCFC.substring(wltpCondHybridCombWCFC.length() - 8);

        this.nedcCondHybrideMixWCCO2 = "        " + this.nedcCondHybrideMixWCCO2;
        if (!nedcCondHybrideMixWCCO2.isEmpty())
            this.nedcCondHybrideMixWCCO2 = this.nedcCondHybrideMixWCCO2.substring(nedcCondHybrideMixWCCO2.length() - 8);

        this.nedcCondHybrideMixWCFC = "        " + this.nedcCondHybrideMixWCFC;
        if (!nedcCondHybrideMixWCFC.isEmpty())
            this.nedcCondHybrideMixWCFC = this.nedcCondHybrideMixWCFC.substring(nedcCondHybrideMixWCFC.length() - 8);

        this.wltpElectricEnergyConsumptionCombUFEC = "        " + this.wltpElectricEnergyConsumptionCombUFEC;
        if (!wltpElectricEnergyConsumptionCombUFEC.isEmpty())
            this.wltpElectricEnergyConsumptionCombUFEC = this.wltpElectricEnergyConsumptionCombUFEC
                    .substring(wltpElectricEnergyConsumptionCombUFEC.length() - 8);

        this.wltpAllElectricRangeCombEAER = "        " + this.wltpAllElectricRangeCombEAER;
        if (!wltpAllElectricRangeCombEAER.isEmpty())
            this.wltpAllElectricRangeCombEAER = this.wltpAllElectricRangeCombEAER.substring(wltpAllElectricRangeCombEAER.length() - 8);

        this.nedcElectricEnergyConsumptionMixUFEC = "        " + this.nedcElectricEnergyConsumptionMixUFEC;
        if (!nedcElectricEnergyConsumptionMixUFEC.isEmpty())
            this.nedcElectricEnergyConsumptionMixUFEC = this.nedcElectricEnergyConsumptionMixUFEC
                    .substring(nedcElectricEnergyConsumptionMixUFEC.length() - 8);

        this.nedcAllElectricRangeMixEAER = "        " + this.nedcAllElectricRangeMixEAER;
        if (!nedcAllElectricRangeMixEAER.isEmpty())
            this.nedcAllElectricRangeMixEAER = this.nedcAllElectricRangeMixEAER.substring(nedcAllElectricRangeMixEAER.length() - 8);

        this.wltpInj2CondCombCO2B = "        " + this.wltpInj2CondCombCO2B;
        if (!wltpInj2CondCombCO2B.isEmpty())
            this.wltpInj2CondCombCO2B = this.wltpInj2CondCombCO2B.substring(wltpInj2CondCombCO2B.length() - 8);

        this.wltpInj2CondCombFCB = "        " + this.wltpInj2CondCombFCB;
        if (!wltpInj2CondCombFCB.isEmpty())
            this.wltpInj2CondCombFCB = this.wltpInj2CondCombFCB.substring(wltpInj2CondCombFCB.length() - 8);

        this.nedcInj2CondMixCO2B = "        " + this.nedcInj2CondMixCO2B;
        if (!nedcInj2CondMixCO2B.isEmpty())
            this.nedcInj2CondMixCO2B = this.nedcInj2CondMixCO2B.substring(nedcInj2CondMixCO2B.length() - 8);

        this.nedcInj2CondMixFCB = "        " + this.nedcInj2CondMixFCB;
        if (!nedcInj2CondMixFCB.isEmpty())
            this.nedcInj2CondMixFCB = this.nedcInj2CondMixFCB.substring(nedcInj2CondMixFCB.length() - 8);

        this.extensionDate = this.extensionDate + "        ";
        if (!extensionDate.isEmpty())
            this.extensionDate = this.extensionDate.substring(0, 8);

        this.wltpGazCondCombCO2G = "        " + this.wltpGazCondCombCO2G;
        if (!wltpGazCondCombCO2G.isEmpty())
            this.wltpGazCondCombCO2G = this.wltpGazCondCombCO2G.substring(wltpGazCondCombCO2G.length() - 8);

        this.wltpGazCondCombFCG = "        " + this.wltpGazCondCombFCG;
        if (!wltpGazCondCombFCG.isEmpty())
            this.wltpGazCondCombFCG = this.wltpGazCondCombFCG.substring(wltpGazCondCombFCG.length() - 8);

        this.nedcGazCondMixCO2G = "        " + this.nedcGazCondMixCO2G;
        if (!nedcGazCondMixCO2G.isEmpty())
            this.nedcGazCondMixCO2G = this.nedcGazCondMixCO2G.substring(nedcGazCondMixCO2G.length() - 8);

        this.nedcGazCondMixFCG = "        " + this.nedcGazCondMixFCG;
        if (!nedcGazCondMixFCG.isEmpty())
            this.nedcGazCondMixFCG = this.nedcGazCondMixFCG.substring(nedcGazCondMixFCG.length() - 8);

        this.wltpElectricEnergyConsumptionCombEC = "        " + this.wltpElectricEnergyConsumptionCombEC;
        if (!wltpElectricEnergyConsumptionCombEC.isEmpty())
            this.wltpElectricEnergyConsumptionCombEC = this.wltpElectricEnergyConsumptionCombEC
                    .substring(wltpElectricEnergyConsumptionCombEC.length() - 8);

        this.wltpElectricRangeCombPER = "        " + this.wltpElectricRangeCombPER;
        if (!wltpElectricRangeCombPER.isEmpty())
            this.wltpElectricRangeCombPER = this.wltpElectricRangeCombPER.substring(wltpElectricRangeCombPER.length() - 8);

        this.nedcElectricEnergyConsumptionMixEC = "        " + this.nedcElectricEnergyConsumptionMixEC;
        if (!nedcElectricEnergyConsumptionMixEC.isEmpty())
            this.nedcElectricEnergyConsumptionMixEC = this.nedcElectricEnergyConsumptionMixEC
                    .substring(nedcElectricEnergyConsumptionMixEC.length() - 8);

        this.nedcElectricRangeMixPER = "        " + this.nedcElectricRangeMixPER;
        if (!nedcElectricRangeMixPER.isEmpty())
            this.nedcElectricRangeMixPER = this.nedcElectricRangeMixPER.substring(nedcElectricRangeMixPER.length() - 8);
        this.wltpCombAER = "        " + this.wltpCombAER;
        if (!wltpCombAER.isEmpty())
            this.wltpCombAER = this.wltpCombAER.substring(wltpCombAER.length() - 8);

        return this.momentCode20 + this.prd + this.lotNumber + this.lineNumber + this.brand + this.tradingCountry + this.version16 + this.colorExtInt
                + this.options7C + this.gestion7C + this.extensionDate + this.answerCode + this.answerDesignation + this.validityDate
                + this.vehicleType + this.calculatedCombCo2 + this.calculatedCombFc + this.nedcCondMixCo2 + this.nedcCCondMixFc
                + this.wltpCondHybrideCombWCCO2 + this.wltpCondHybridCombWCFC + this.nedcCondHybrideMixWCCO2 + this.nedcCondHybrideMixWCFC
                + this.wltpElectricEnergyConsumptionCombUFEC + this.wltpAllElectricRangeCombEAER + this.nedcElectricEnergyConsumptionMixUFEC
                + this.nedcAllElectricRangeMixEAER + this.wltpInj2CondCombCO2B + this.wltpInj2CondCombFCB + this.nedcInj2CondMixCO2B
                + this.nedcInj2CondMixFCB + this.wltpGazCondCombCO2G + this.wltpGazCondCombFCG + this.nedcGazCondMixCO2G + this.nedcGazCondMixFCG
                + this.wltpElectricEnergyConsumptionCombEC + this.wltpElectricRangeCombPER + this.nedcElectricEnergyConsumptionMixEC
                + this.nedcElectricRangeMixPER + this.wltpCombAER + this.masse + this.w20EAERFiller + this.w20AERFiller + this.w20PERFiller
                + this.w20MTACFiller + this.w20MOPTFiller + this.w20EMPTYMFiller + this.filler + "\n";
    }

    /**
     * Write W 030.
     *
     * @return the string
     */
    public String writeW030() {
        this.momentCode30 = this.momentCode30 + "    ";
        this.momentCode30 = this.momentCode30.substring(0, 4);

        this.brand = this.brand + "  ";
        this.brand = this.brand.substring(0, 2);

        this.tradingCountry = this.tradingCountry + "  ";
        this.tradingCountry = this.tradingCountry.substring(0, 2);

        this.vehicleType = this.vehicleType + "     ";
        this.vehicleType = this.vehicleType.substring(0, 5);

        this.endDate = this.endDate + "        ";
        this.endDate = this.endDate.substring(0, 8);

        this.family = this.family + "     ";
        this.family = this.family.substring(0, 5);

        this.code = this.code + "     ";
        this.code = this.code.substring(0, 5);

        this.vLow = "        " + this.vLow;
        if (!vLow.isEmpty())
            this.vLow = this.vLow.substring(vLow.length() - 8);

        this.vHigh = "        " + this.vHigh;
        if (!vHigh.isEmpty())
            this.vHigh = this.vHigh.substring(vHigh.length() - 8);
        this.filler = this.filler + "                                                                                     ";
        if (!filler.isEmpty())
            this.filler = this.filler.substring(0, 85);
        this.vLowFuelConsumption = "        " + this.vLowFuelConsumption;
        if (!vLowFuelConsumption.isEmpty())
            this.vLowFuelConsumption = this.vLowFuelConsumption.substring(vLowFuelConsumption.length() - 8);

        this.vHighFuelConsumption = "        " + this.vHighFuelConsumption;
        if (!vHighFuelConsumption.isEmpty())
            this.vHighFuelConsumption = this.vHighFuelConsumption.substring(vHighFuelConsumption.length() - 8);

        this.vLowCycleEnergy = "        " + this.vLowCycleEnergy;
        if (!vLowCycleEnergy.isEmpty())
            this.vLowCycleEnergy = this.vLowCycleEnergy.substring(vLowCycleEnergy.length() - 8);

        this.miniCondHybrideWCCO2 = "        " + this.miniCondHybrideWCCO2;
        if (!miniCondHybrideWCCO2.isEmpty())
            this.miniCondHybrideWCCO2 = this.miniCondHybrideWCCO2.substring(miniCondHybrideWCCO2.length() - 8);

        this.miniCondHybrideWCFC = "        " + this.miniCondHybrideWCFC;
        if (!miniCondHybrideWCFC.isEmpty())
            this.miniCondHybrideWCFC = this.miniCondHybrideWCFC.substring(miniCondHybrideWCFC.length() - 8);

        this.miniInj2CondMixteCO2B = "        " + this.miniInj2CondMixteCO2B;
        if (!miniInj2CondMixteCO2B.isEmpty())
            this.miniInj2CondMixteCO2B = this.miniInj2CondMixteCO2B.substring(miniInj2CondMixteCO2B.length() - 8);

        this.miniInj2CondMixteFCB = "        " + this.miniInj2CondMixteFCB;
        if (!miniInj2CondMixteFCB.isEmpty())
            this.miniInj2CondMixteFCB = this.miniInj2CondMixteFCB.substring(miniInj2CondMixteFCB.length() - 8);

        this.miniGazCondMixtesCO2G = "        " + this.miniGazCondMixtesCO2G;
        if (!miniGazCondMixtesCO2G.isEmpty())
            this.miniGazCondMixtesCO2G = this.miniGazCondMixtesCO2G.substring(miniGazCondMixtesCO2G.length() - 8);

        this.miniGazCondMixtesFCG = "        " + this.miniGazCondMixtesFCG;
        if (!miniGazCondMixtesFCG.isEmpty())
            this.miniGazCondMixtesFCG = this.miniGazCondMixtesFCG.substring(miniGazCondMixtesFCG.length() - 8);

        this.miniElectricEnergyConsumptionEC = "        " + this.miniElectricEnergyConsumptionEC;
        if (!miniElectricEnergyConsumptionEC.isEmpty())
            this.miniElectricEnergyConsumptionEC = this.miniElectricEnergyConsumptionEC.substring(miniElectricEnergyConsumptionEC.length() - 8);

        this.miniElectricRangePER = "        " + this.miniElectricRangePER;
        if (!miniElectricRangePER.isEmpty())
            this.miniElectricRangePER = this.miniElectricRangePER.substring(miniElectricRangePER.length() - 8);

        this.miniElectricEnergyConsumptionUFEC = "        " + this.miniElectricEnergyConsumptionUFEC;
        if (!miniElectricEnergyConsumptionUFEC.isEmpty())
            this.miniElectricEnergyConsumptionUFEC = this.miniElectricEnergyConsumptionUFEC.substring(miniElectricEnergyConsumptionUFEC.length() - 8);

        this.miniElectricRangeEAER = "        " + this.miniElectricRangeEAER;
        if (!miniElectricRangeEAER.isEmpty())
            this.miniElectricRangeEAER = this.miniElectricRangeEAER.substring(miniElectricRangeEAER.length() - 8);

        this.minAllElectricRangeAER = "        " + this.minAllElectricRangeAER;
        if (!minAllElectricRangeAER.isEmpty())
            this.minAllElectricRangeAER = this.minAllElectricRangeAER.substring(minAllElectricRangeAER.length() - 8);

        this.maxCondHybrideWCCO2 = "        " + this.maxCondHybrideWCCO2;
        if (!maxCondHybrideWCCO2.isEmpty())
            this.maxCondHybrideWCCO2 = this.maxCondHybrideWCCO2.substring(maxCondHybrideWCCO2.length() - 8);

        this.maxCondHybrideWCFC = "        " + this.maxCondHybrideWCFC;
        if (!maxCondHybrideWCFC.isEmpty())
            this.maxCondHybrideWCFC = this.maxCondHybrideWCFC.substring(maxCondHybrideWCFC.length() - 8);

        this.maxInj2CondMixteCO2B = "        " + this.maxInj2CondMixteCO2B;
        if (!maxInj2CondMixteCO2B.isEmpty())
            this.maxInj2CondMixteCO2B = this.maxInj2CondMixteCO2B.substring(maxInj2CondMixteCO2B.length() - 8);

        this.maxInj2CondMixteFCB = "        " + this.maxInj2CondMixteFCB;
        if (!maxInj2CondMixteFCB.isEmpty())
            this.maxInj2CondMixteFCB = this.maxInj2CondMixteFCB.substring(maxInj2CondMixteFCB.length() - 8);

        this.maxGazCondMixtesCO2G = "        " + this.maxGazCondMixtesCO2G;
        if (!maxGazCondMixtesCO2G.isEmpty())
            this.maxGazCondMixtesCO2G = this.maxGazCondMixtesCO2G.substring(maxGazCondMixtesCO2G.length() - 8);

        this.maxGazCondMixtesFCG = "        " + this.maxGazCondMixtesFCG;
        if (!maxGazCondMixtesFCG.isEmpty())
            this.maxGazCondMixtesFCG = this.maxGazCondMixtesFCG.substring(maxGazCondMixtesFCG.length() - 8);

        this.maxElectricEnergyConsumptionEC = "        " + this.maxElectricEnergyConsumptionEC;
        if (!maxElectricEnergyConsumptionEC.isEmpty())
            this.maxElectricEnergyConsumptionEC = this.maxElectricEnergyConsumptionEC.substring(maxElectricEnergyConsumptionEC.length() - 8);

        this.maxElectricRangePER = "        " + this.maxElectricRangePER;
        if (!maxElectricRangePER.isEmpty())
            this.maxElectricRangePER = this.maxElectricRangePER.substring(maxElectricRangePER.length() - 8);

        this.maxElectricEnergyConsumptionUFEC = "        " + this.maxElectricEnergyConsumptionUFEC;
        if (!maxElectricEnergyConsumptionUFEC.isEmpty())
            this.maxElectricEnergyConsumptionUFEC = this.maxElectricEnergyConsumptionUFEC.substring(maxElectricEnergyConsumptionUFEC.length() - 8);

        this.maxElectricRangeEAER = "        " + this.maxElectricRangeEAER;
        if (!maxElectricRangeEAER.isEmpty())
            this.maxElectricRangeEAER = this.maxElectricRangeEAER.substring(maxElectricRangeEAER.length() - 8);

        this.maxAllElectricRangeAER = "        " + this.maxAllElectricRangeAER;
        if (!maxAllElectricRangeAER.isEmpty())
            this.maxAllElectricRangeAER = this.maxAllElectricRangeAER.substring(maxAllElectricRangeAER.length() - 8);

        this.fillerW030 = this.fillerW030 + "                                                                     ";
        this.fillerW030 = this.fillerW030.substring(0, 69);

        return this.momentCode30 + this.tradingCountry + this.brand + this.family + this.code + this.vehicleType + this.vLow
                + this.vLowFuelConsumption + this.miniCondHybrideWCCO2 + this.miniCondHybrideWCFC + this.miniInj2CondMixteCO2B
                + this.miniInj2CondMixteFCB + this.miniGazCondMixtesCO2G + this.miniGazCondMixtesFCG + this.miniElectricEnergyConsumptionEC
                + this.miniElectricRangePER + this.miniElectricEnergyConsumptionUFEC + this.miniElectricRangeEAER + this.vHigh
                + this.vHighFuelConsumption + this.maxCondHybrideWCCO2 + this.maxCondHybrideWCFC + this.maxInj2CondMixteCO2B
                + this.maxInj2CondMixteFCB + this.maxGazCondMixtesCO2G + this.maxGazCondMixtesFCG + this.maxElectricEnergyConsumptionEC
                + this.maxElectricRangePER + this.maxElectricEnergyConsumptionUFEC + this.maxElectricRangeEAER + this.minAllElectricRangeAER
                + this.maxAllElectricRangeAER + this.fillerW030 + "\n";
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((validityDate == null) ? 0 : validityDate.hashCode());
        result = prime * result + ((answerCode == null) ? 0 : answerCode.hashCode());
        result = prime * result + ((answerDate == null) ? 0 : answerDate.hashCode());
        result = prime * result + ((answerDesignation == null) ? 0 : answerDesignation.hashCode());
        result = prime * result + ((brand == null) ? 0 : brand.hashCode());
        result = prime * result + ((calculatedCombCo2 == null) ? 0 : calculatedCombCo2.hashCode());
        result = prime * result + ((calculatedCombFc == null) ? 0 : calculatedCombFc.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((colorExtInt == null) ? 0 : colorExtInt.hashCode());
        result = prime * result + ((crrVehic == null) ? 0 : crrVehic.hashCode());
        result = prime * result + ((ecomDate == null) ? 0 : ecomDate.hashCode());
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        result = prime * result + ((extAttr == null) ? 0 : extAttr.hashCode());
        result = prime * result + ((extendedTitle == null) ? 0 : extendedTitle.hashCode());
        result = prime * result + ((extensionDate == null) ? 0 : extensionDate.hashCode());
        result = prime * result + ((family == null) ? 0 : family.hashCode());
        result = prime * result + ((filler == null) ? 0 : filler.hashCode());
        result = prime * result + ((fillerW030 == null) ? 0 : fillerW030.hashCode());
        result = prime * result + ((gestion == null) ? 0 : gestion.hashCode());
        result = prime * result + ((gestion5C == null) ? 0 : gestion5C.hashCode());
        result = prime * result + ((gestion7C == null) ? 0 : gestion7C.hashCode());
        result = prime * result + ((lineNumber == null) ? 0 : lineNumber.hashCode());
        result = prime * result + ((lotNumber == null) ? 0 : lotNumber.hashCode());
        result = prime * result + ((massEquip == null) ? 0 : massEquip.hashCode());
        result = prime * result + ((massSocle == null) ? 0 : massSocle.hashCode());
        result = prime * result + ((massVehic == null) ? 0 : massVehic.hashCode());
        result = prime * result + ((maxCondHybrideWCCO2 == null) ? 0 : maxCondHybrideWCCO2.hashCode());
        result = prime * result + ((maxCondHybrideWCFC == null) ? 0 : maxCondHybrideWCFC.hashCode());
        result = prime * result + ((maxElectricEnergyConsumptionEC == null) ? 0 : maxElectricEnergyConsumptionEC.hashCode());
        result = prime * result + ((maxElectricEnergyConsumptionUFEC == null) ? 0 : maxElectricEnergyConsumptionUFEC.hashCode());
        result = prime * result + ((maxElectricRangeEAER == null) ? 0 : maxElectricRangeEAER.hashCode());
        result = prime * result + ((maxElectricRangePER == null) ? 0 : maxElectricRangePER.hashCode());
        result = prime * result + ((maxGazCondMixtesCO2G == null) ? 0 : maxGazCondMixtesCO2G.hashCode());
        result = prime * result + ((maxGazCondMixtesFCG == null) ? 0 : maxGazCondMixtesFCG.hashCode());
        result = prime * result + ((maxInj2CondMixteCO2B == null) ? 0 : maxInj2CondMixteCO2B.hashCode());
        result = prime * result + ((maxInj2CondMixteFCB == null) ? 0 : maxInj2CondMixteFCB.hashCode());
        result = prime * result + ((miniCondHybrideWCCO2 == null) ? 0 : miniCondHybrideWCCO2.hashCode());
        result = prime * result + ((miniCondHybrideWCFC == null) ? 0 : miniCondHybrideWCFC.hashCode());
        result = prime * result + ((miniElectricEnergyConsumptionEC == null) ? 0 : miniElectricEnergyConsumptionEC.hashCode());
        result = prime * result + ((miniElectricEnergyConsumptionUFEC == null) ? 0 : miniElectricEnergyConsumptionUFEC.hashCode());
        result = prime * result + ((miniElectricRangeEAER == null) ? 0 : miniElectricRangeEAER.hashCode());
        result = prime * result + ((miniElectricRangePER == null) ? 0 : miniElectricRangePER.hashCode());
        result = prime * result + ((miniGazCondMixtesCO2G == null) ? 0 : miniGazCondMixtesCO2G.hashCode());
        result = prime * result + ((miniGazCondMixtesFCG == null) ? 0 : miniGazCondMixtesFCG.hashCode());
        result = prime * result + ((miniInj2CondMixteCO2B == null) ? 0 : miniInj2CondMixteCO2B.hashCode());
        result = prime * result + ((miniInj2CondMixteFCB == null) ? 0 : miniInj2CondMixteFCB.hashCode());
        result = prime * result + ((momentCode20 == null) ? 0 : momentCode20.hashCode());
        result = prime * result + ((momentCode30 == null) ? 0 : momentCode30.hashCode());
        result = prime * result + ((nedcAllElectricRangeMixEAER == null) ? 0 : nedcAllElectricRangeMixEAER.hashCode());
        result = prime * result + ((nedcCCondMixFc == null) ? 0 : nedcCCondMixFc.hashCode());
        result = prime * result + ((nedcCondHybrideMixWCCO2 == null) ? 0 : nedcCondHybrideMixWCCO2.hashCode());
        result = prime * result + ((nedcCondHybrideMixWCFC == null) ? 0 : nedcCondHybrideMixWCFC.hashCode());
        result = prime * result + ((nedcCondMixCo2 == null) ? 0 : nedcCondMixCo2.hashCode());
        result = prime * result + ((nedcElectricEnergyConsumptionMixEC == null) ? 0 : nedcElectricEnergyConsumptionMixEC.hashCode());
        result = prime * result + ((nedcElectricEnergyConsumptionMixUFEC == null) ? 0 : nedcElectricEnergyConsumptionMixUFEC.hashCode());
        result = prime * result + ((nedcElectricRangeMixPER == null) ? 0 : nedcElectricRangeMixPER.hashCode());
        result = prime * result + ((nedcGazCondMixCO2G == null) ? 0 : nedcGazCondMixCO2G.hashCode());
        result = prime * result + ((nedcGazCondMixFCG == null) ? 0 : nedcGazCondMixFCG.hashCode());
        result = prime * result + ((nedcInj2CondMixCO2B == null) ? 0 : nedcInj2CondMixCO2B.hashCode());
        result = prime * result + ((nedcInj2CondMixFCB == null) ? 0 : nedcInj2CondMixFCB.hashCode());
        result = prime * result + ((options == null) ? 0 : options.hashCode());
        result = prime * result + ((options5C == null) ? 0 : options5C.hashCode());
        result = prime * result + ((options7C == null) ? 0 : options7C.hashCode());
        result = prime * result + ((physicalQuantities == null) ? 0 : physicalQuantities.hashCode());
        result = prime * result + ((prd == null) ? 0 : prd.hashCode());
        result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
        result = prime * result + ((requestType == null) ? 0 : requestType.hashCode());
        result = prime * result + ((roadLoad == null) ? 0 : roadLoad.hashCode());
        result = prime * result + ((scxEquip == null) ? 0 : scxEquip.hashCode());
        result = prime * result + ((scxSocle == null) ? 0 : scxSocle.hashCode());
        result = prime * result + ((scxVehic == null) ? 0 : scxVehic.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((tradingCountry == null) ? 0 : tradingCountry.hashCode());
        result = prime * result + ((vHigh == null) ? 0 : vHigh.hashCode());
        result = prime * result + ((vHighCycleEnergy == null) ? 0 : vHighCycleEnergy.hashCode());
        result = prime * result + ((vHighFuelConsumption == null) ? 0 : vHighFuelConsumption.hashCode());
        result = prime * result + ((vLow == null) ? 0 : vLow.hashCode());
        result = prime * result + ((vLowCycleEnergy == null) ? 0 : vLowCycleEnergy.hashCode());
        result = prime * result + ((vLowFuelConsumption == null) ? 0 : vLowFuelConsumption.hashCode());
        result = prime * result + ((vehicleType == null) ? 0 : vehicleType.hashCode());
        result = prime * result + ((version16 == null) ? 0 : version16.hashCode());
        result = prime * result + ((wltpAllElectricRangeCombEAER == null) ? 0 : wltpAllElectricRangeCombEAER.hashCode());
        result = prime * result + ((wltpCondHybridCombWCFC == null) ? 0 : wltpCondHybridCombWCFC.hashCode());
        result = prime * result + ((wltpCondHybrideCombWCCO2 == null) ? 0 : wltpCondHybrideCombWCCO2.hashCode());
        result = prime * result + ((wltpElectricEnergyConsumptionCombEC == null) ? 0 : wltpElectricEnergyConsumptionCombEC.hashCode());
        result = prime * result + ((wltpElectricEnergyConsumptionCombUFEC == null) ? 0 : wltpElectricEnergyConsumptionCombUFEC.hashCode());
        result = prime * result + ((wltpElectricRangeCombPER == null) ? 0 : wltpElectricRangeCombPER.hashCode());
        result = prime * result + ((wltpGazCondCombCO2G == null) ? 0 : wltpGazCondCombCO2G.hashCode());
        result = prime * result + ((wltpGazCondCombFCG == null) ? 0 : wltpGazCondCombFCG.hashCode());
        result = prime * result + ((wltpInj2CondCombCO2B == null) ? 0 : wltpInj2CondCombCO2B.hashCode());
        result = prime * result + ((wltpInj2CondCombFCB == null) ? 0 : wltpInj2CondCombFCB.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AoCronosEliadeDto other = (AoCronosEliadeDto) obj;
        if (validityDate == null) {
            if (other.validityDate != null)
                return false;
        } else if (!validityDate.equals(other.validityDate))
            return false;
        if (answerCode == null) {
            if (other.answerCode != null)
                return false;
        } else if (!answerCode.equals(other.answerCode))
            return false;
        if (answerDate == null) {
            if (other.answerDate != null)
                return false;
        } else if (!answerDate.equals(other.answerDate))
            return false;
        if (answerDesignation == null) {
            if (other.answerDesignation != null)
                return false;
        } else if (!answerDesignation.equals(other.answerDesignation))
            return false;
        if (brand == null) {
            if (other.brand != null)
                return false;
        } else if (!brand.equals(other.brand))
            return false;
        if (calculatedCombCo2 == null) {
            if (other.calculatedCombCo2 != null)
                return false;
        } else if (!calculatedCombCo2.equals(other.calculatedCombCo2))
            return false;
        if (calculatedCombFc == null) {
            if (other.calculatedCombFc != null)
                return false;
        } else if (!calculatedCombFc.equals(other.calculatedCombFc))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (colorExtInt == null) {
            if (other.colorExtInt != null)
                return false;
        } else if (!colorExtInt.equals(other.colorExtInt))
            return false;
        if (crrVehic == null) {
            if (other.crrVehic != null)
                return false;
        } else if (!crrVehic.equals(other.crrVehic))
            return false;
        if (ecomDate == null) {
            if (other.ecomDate != null)
                return false;
        } else if (!ecomDate.equals(other.ecomDate))
            return false;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (extAttr == null) {
            if (other.extAttr != null)
                return false;
        } else if (!extAttr.equals(other.extAttr))
            return false;
        if (extendedTitle == null) {
            if (other.extendedTitle != null)
                return false;
        } else if (!extendedTitle.equals(other.extendedTitle))
            return false;
        if (extensionDate == null) {
            if (other.extensionDate != null)
                return false;
        } else if (!extensionDate.equals(other.extensionDate))
            return false;
        if (family == null) {
            if (other.family != null)
                return false;
        } else if (!family.equals(other.family))
            return false;
        if (filler == null) {
            if (other.filler != null)
                return false;
        } else if (!filler.equals(other.filler))
            return false;
        if (fillerW030 == null) {
            if (other.fillerW030 != null)
                return false;
        } else if (!fillerW030.equals(other.fillerW030))
            return false;
        if (gestion == null) {
            if (other.gestion != null)
                return false;
        } else if (!gestion.equals(other.gestion))
            return false;
        if (gestion5C == null) {
            if (other.gestion5C != null)
                return false;
        } else if (!gestion5C.equals(other.gestion5C))
            return false;
        if (gestion7C == null) {
            if (other.gestion7C != null)
                return false;
        } else if (!gestion7C.equals(other.gestion7C))
            return false;
        if (lineNumber == null) {
            if (other.lineNumber != null)
                return false;
        } else if (!lineNumber.equals(other.lineNumber))
            return false;
        if (lotNumber == null) {
            if (other.lotNumber != null)
                return false;
        } else if (!lotNumber.equals(other.lotNumber))
            return false;
        if (massEquip == null) {
            if (other.massEquip != null)
                return false;
        } else if (!massEquip.equals(other.massEquip))
            return false;
        if (massSocle == null) {
            if (other.massSocle != null)
                return false;
        } else if (!massSocle.equals(other.massSocle))
            return false;
        if (massVehic == null) {
            if (other.massVehic != null)
                return false;
        } else if (!massVehic.equals(other.massVehic))
            return false;
        if (maxCondHybrideWCCO2 == null) {
            if (other.maxCondHybrideWCCO2 != null)
                return false;
        } else if (!maxCondHybrideWCCO2.equals(other.maxCondHybrideWCCO2))
            return false;
        if (maxCondHybrideWCFC == null) {
            if (other.maxCondHybrideWCFC != null)
                return false;
        } else if (!maxCondHybrideWCFC.equals(other.maxCondHybrideWCFC))
            return false;
        if (maxElectricEnergyConsumptionEC == null) {
            if (other.maxElectricEnergyConsumptionEC != null)
                return false;
        } else if (!maxElectricEnergyConsumptionEC.equals(other.maxElectricEnergyConsumptionEC))
            return false;
        if (maxElectricEnergyConsumptionUFEC == null) {
            if (other.maxElectricEnergyConsumptionUFEC != null)
                return false;
        } else if (!maxElectricEnergyConsumptionUFEC.equals(other.maxElectricEnergyConsumptionUFEC))
            return false;
        if (maxElectricRangeEAER == null) {
            if (other.maxElectricRangeEAER != null)
                return false;
        } else if (!maxElectricRangeEAER.equals(other.maxElectricRangeEAER))
            return false;
        if (maxElectricRangePER == null) {
            if (other.maxElectricRangePER != null)
                return false;
        } else if (!maxElectricRangePER.equals(other.maxElectricRangePER))
            return false;
        if (maxGazCondMixtesCO2G == null) {
            if (other.maxGazCondMixtesCO2G != null)
                return false;
        } else if (!maxGazCondMixtesCO2G.equals(other.maxGazCondMixtesCO2G))
            return false;
        if (maxGazCondMixtesFCG == null) {
            if (other.maxGazCondMixtesFCG != null)
                return false;
        } else if (!maxGazCondMixtesFCG.equals(other.maxGazCondMixtesFCG))
            return false;
        if (maxInj2CondMixteCO2B == null) {
            if (other.maxInj2CondMixteCO2B != null)
                return false;
        } else if (!maxInj2CondMixteCO2B.equals(other.maxInj2CondMixteCO2B))
            return false;
        if (maxInj2CondMixteFCB == null) {
            if (other.maxInj2CondMixteFCB != null)
                return false;
        } else if (!maxInj2CondMixteFCB.equals(other.maxInj2CondMixteFCB))
            return false;
        if (miniCondHybrideWCCO2 == null) {
            if (other.miniCondHybrideWCCO2 != null)
                return false;
        } else if (!miniCondHybrideWCCO2.equals(other.miniCondHybrideWCCO2))
            return false;
        if (miniCondHybrideWCFC == null) {
            if (other.miniCondHybrideWCFC != null)
                return false;
        } else if (!miniCondHybrideWCFC.equals(other.miniCondHybrideWCFC))
            return false;
        if (miniElectricEnergyConsumptionEC == null) {
            if (other.miniElectricEnergyConsumptionEC != null)
                return false;
        } else if (!miniElectricEnergyConsumptionEC.equals(other.miniElectricEnergyConsumptionEC))
            return false;
        if (miniElectricEnergyConsumptionUFEC == null) {
            if (other.miniElectricEnergyConsumptionUFEC != null)
                return false;
        } else if (!miniElectricEnergyConsumptionUFEC.equals(other.miniElectricEnergyConsumptionUFEC))
            return false;
        if (miniElectricRangeEAER == null) {
            if (other.miniElectricRangeEAER != null)
                return false;
        } else if (!miniElectricRangeEAER.equals(other.miniElectricRangeEAER))
            return false;
        if (miniElectricRangePER == null) {
            if (other.miniElectricRangePER != null)
                return false;
        } else if (!miniElectricRangePER.equals(other.miniElectricRangePER))
            return false;
        if (miniGazCondMixtesCO2G == null) {
            if (other.miniGazCondMixtesCO2G != null)
                return false;
        } else if (!miniGazCondMixtesCO2G.equals(other.miniGazCondMixtesCO2G))
            return false;
        if (miniGazCondMixtesFCG == null) {
            if (other.miniGazCondMixtesFCG != null)
                return false;
        } else if (!miniGazCondMixtesFCG.equals(other.miniGazCondMixtesFCG))
            return false;
        if (miniInj2CondMixteCO2B == null) {
            if (other.miniInj2CondMixteCO2B != null)
                return false;
        } else if (!miniInj2CondMixteCO2B.equals(other.miniInj2CondMixteCO2B))
            return false;
        if (miniInj2CondMixteFCB == null) {
            if (other.miniInj2CondMixteFCB != null)
                return false;
        } else if (!miniInj2CondMixteFCB.equals(other.miniInj2CondMixteFCB))
            return false;
        if (momentCode20 == null) {
            if (other.momentCode20 != null)
                return false;
        } else if (!momentCode20.equals(other.momentCode20))
            return false;
        if (momentCode30 == null) {
            if (other.momentCode30 != null)
                return false;
        } else if (!momentCode30.equals(other.momentCode30))
            return false;
        if (nedcAllElectricRangeMixEAER == null) {
            if (other.nedcAllElectricRangeMixEAER != null)
                return false;
        } else if (!nedcAllElectricRangeMixEAER.equals(other.nedcAllElectricRangeMixEAER))
            return false;
        if (nedcCCondMixFc == null) {
            if (other.nedcCCondMixFc != null)
                return false;
        } else if (!nedcCCondMixFc.equals(other.nedcCCondMixFc))
            return false;
        if (nedcCondHybrideMixWCCO2 == null) {
            if (other.nedcCondHybrideMixWCCO2 != null)
                return false;
        } else if (!nedcCondHybrideMixWCCO2.equals(other.nedcCondHybrideMixWCCO2))
            return false;
        if (nedcCondHybrideMixWCFC == null) {
            if (other.nedcCondHybrideMixWCFC != null)
                return false;
        } else if (!nedcCondHybrideMixWCFC.equals(other.nedcCondHybrideMixWCFC))
            return false;
        if (nedcCondMixCo2 == null) {
            if (other.nedcCondMixCo2 != null)
                return false;
        } else if (!nedcCondMixCo2.equals(other.nedcCondMixCo2))
            return false;
        if (nedcElectricEnergyConsumptionMixEC == null) {
            if (other.nedcElectricEnergyConsumptionMixEC != null)
                return false;
        } else if (!nedcElectricEnergyConsumptionMixEC.equals(other.nedcElectricEnergyConsumptionMixEC))
            return false;
        if (nedcElectricEnergyConsumptionMixUFEC == null) {
            if (other.nedcElectricEnergyConsumptionMixUFEC != null)
                return false;
        } else if (!nedcElectricEnergyConsumptionMixUFEC.equals(other.nedcElectricEnergyConsumptionMixUFEC))
            return false;
        if (nedcElectricRangeMixPER == null) {
            if (other.nedcElectricRangeMixPER != null)
                return false;
        } else if (!nedcElectricRangeMixPER.equals(other.nedcElectricRangeMixPER))
            return false;
        if (nedcGazCondMixCO2G == null) {
            if (other.nedcGazCondMixCO2G != null)
                return false;
        } else if (!nedcGazCondMixCO2G.equals(other.nedcGazCondMixCO2G))
            return false;
        if (nedcGazCondMixFCG == null) {
            if (other.nedcGazCondMixFCG != null)
                return false;
        } else if (!nedcGazCondMixFCG.equals(other.nedcGazCondMixFCG))
            return false;
        if (nedcInj2CondMixCO2B == null) {
            if (other.nedcInj2CondMixCO2B != null)
                return false;
        } else if (!nedcInj2CondMixCO2B.equals(other.nedcInj2CondMixCO2B))
            return false;
        if (nedcInj2CondMixFCB == null) {
            if (other.nedcInj2CondMixFCB != null)
                return false;
        } else if (!nedcInj2CondMixFCB.equals(other.nedcInj2CondMixFCB))
            return false;
        if (options == null) {
            if (other.options != null)
                return false;
        } else if (!options.equals(other.options))
            return false;
        if (options5C == null) {
            if (other.options5C != null)
                return false;
        } else if (!options5C.equals(other.options5C))
            return false;
        if (options7C == null) {
            if (other.options7C != null)
                return false;
        } else if (!options7C.equals(other.options7C))
            return false;
        if (physicalQuantities == null) {
            if (other.physicalQuantities != null)
                return false;
        } else if (!physicalQuantities.equals(other.physicalQuantities))
            return false;
        if (prd == null) {
            if (other.prd != null)
                return false;
        } else if (!prd.equals(other.prd))
            return false;
        if (requestId == null) {
            if (other.requestId != null)
                return false;
        } else if (!requestId.equals(other.requestId))
            return false;
        if (requestType == null) {
            if (other.requestType != null)
                return false;
        } else if (!requestType.equals(other.requestType))
            return false;
        if (roadLoad == null) {
            if (other.roadLoad != null)
                return false;
        } else if (!roadLoad.equals(other.roadLoad))
            return false;
        if (scxEquip == null) {
            if (other.scxEquip != null)
                return false;
        } else if (!scxEquip.equals(other.scxEquip))
            return false;
        if (scxSocle == null) {
            if (other.scxSocle != null)
                return false;
        } else if (!scxSocle.equals(other.scxSocle))
            return false;
        if (scxVehic == null) {
            if (other.scxVehic != null)
                return false;
        } else if (!scxVehic.equals(other.scxVehic))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        } else if (!status.equals(other.status))
            return false;
        if (tradingCountry == null) {
            if (other.tradingCountry != null)
                return false;
        } else if (!tradingCountry.equals(other.tradingCountry))
            return false;
        if (vHigh == null) {
            if (other.vHigh != null)
                return false;
        } else if (!vHigh.equals(other.vHigh))
            return false;
        if (vHighCycleEnergy == null) {
            if (other.vHighCycleEnergy != null)
                return false;
        } else if (!vHighCycleEnergy.equals(other.vHighCycleEnergy))
            return false;
        if (vHighFuelConsumption == null) {
            if (other.vHighFuelConsumption != null)
                return false;
        } else if (!vHighFuelConsumption.equals(other.vHighFuelConsumption))
            return false;
        if (vLow == null) {
            if (other.vLow != null)
                return false;
        } else if (!vLow.equals(other.vLow))
            return false;
        if (vLowCycleEnergy == null) {
            if (other.vLowCycleEnergy != null)
                return false;
        } else if (!vLowCycleEnergy.equals(other.vLowCycleEnergy))
            return false;
        if (vLowFuelConsumption == null) {
            if (other.vLowFuelConsumption != null)
                return false;
        } else if (!vLowFuelConsumption.equals(other.vLowFuelConsumption))
            return false;
        if (vehicleType == null) {
            if (other.vehicleType != null)
                return false;
        } else if (!vehicleType.equals(other.vehicleType))
            return false;
        if (version16 == null) {
            if (other.version16 != null)
                return false;
        } else if (!version16.equals(other.version16))
            return false;
        if (wltpAllElectricRangeCombEAER == null) {
            if (other.wltpAllElectricRangeCombEAER != null)
                return false;
        } else if (!wltpAllElectricRangeCombEAER.equals(other.wltpAllElectricRangeCombEAER))
            return false;
        if (wltpCondHybridCombWCFC == null) {
            if (other.wltpCondHybridCombWCFC != null)
                return false;
        } else if (!wltpCondHybridCombWCFC.equals(other.wltpCondHybridCombWCFC))
            return false;
        if (wltpCondHybrideCombWCCO2 == null) {
            if (other.wltpCondHybrideCombWCCO2 != null)
                return false;
        } else if (!wltpCondHybrideCombWCCO2.equals(other.wltpCondHybrideCombWCCO2))
            return false;
        if (wltpElectricEnergyConsumptionCombEC == null) {
            if (other.wltpElectricEnergyConsumptionCombEC != null)
                return false;
        } else if (!wltpElectricEnergyConsumptionCombEC.equals(other.wltpElectricEnergyConsumptionCombEC))
            return false;
        if (wltpElectricEnergyConsumptionCombUFEC == null) {
            if (other.wltpElectricEnergyConsumptionCombUFEC != null)
                return false;
        } else if (!wltpElectricEnergyConsumptionCombUFEC.equals(other.wltpElectricEnergyConsumptionCombUFEC))
            return false;
        if (wltpElectricRangeCombPER == null) {
            if (other.wltpElectricRangeCombPER != null)
                return false;
        } else if (!wltpElectricRangeCombPER.equals(other.wltpElectricRangeCombPER))
            return false;
        if (wltpGazCondCombCO2G == null) {
            if (other.wltpGazCondCombCO2G != null)
                return false;
        } else if (!wltpGazCondCombCO2G.equals(other.wltpGazCondCombCO2G))
            return false;
        if (wltpGazCondCombFCG == null) {
            if (other.wltpGazCondCombFCG != null)
                return false;
        } else if (!wltpGazCondCombFCG.equals(other.wltpGazCondCombFCG))
            return false;
        if (wltpInj2CondCombCO2B == null) {
            if (other.wltpInj2CondCombCO2B != null)
                return false;
        } else if (!wltpInj2CondCombCO2B.equals(other.wltpInj2CondCombCO2B))
            return false;
        if (wltpInj2CondCombFCB == null) {
            if (other.wltpInj2CondCombFCB != null)
                return false;
        } else if (!wltpInj2CondCombFCB.equals(other.wltpInj2CondCombFCB))
            return false;
        return true;
    }

}
