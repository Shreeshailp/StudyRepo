/*
 * Creation : 19 Feb 2020
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class ToyotaDepol.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "depolCode", "depolStatus", "depolMessage", "depolResult" })
@XmlRootElement(name = "depol_dataset")
public class ToyotaDepol {

    /** The depol code. */
    @XmlElement(name = "depol_code", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String depolCode;

    /** The depol status. */
    @XmlElement(name = "depol_status", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String depolStatus;

    /** The depol message. */
    @XmlElement(name = "depol_message", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String depolMessage;

    /** The depol result. */
    @XmlElement(name = "limit", required = true)
    protected List<ToyotaDepolLimitCode> depolResult;

    /**
     * Instantiates a new toyota depol.
     *
     * @param depolCode the depol code
     * @param depolStatus the depol status
     * @param depolMessage the depol message
     * @param depolResult the depol result
     */
    public ToyotaDepol(String depolCode, String depolStatus, String depolMessage, List<ToyotaDepolLimitCode> depolResult) {
        super();
        this.depolCode = depolCode;
        this.depolStatus = depolStatus;
        this.depolMessage = depolMessage;
        this.depolResult = depolResult;
    }

    /**
     * Instantiates a new toyota depol.
     */
    public ToyotaDepol() {
        super();
    }

    /**
     * Gets the depol code.
     *
     * @return the depol code
     */
    public String getDepolCode() {
        return depolCode;
    }

    /**
     * Sets the depol code.
     *
     * @param depolCode the new depol code
     */
    public void setDepolCode(String depolCode) {
        this.depolCode = depolCode;
    }

    /**
     * Gets the depol status.
     *
     * @return the depol status
     */
    public String getDepolStatus() {
        return depolStatus;
    }

    /**
     * Sets the depol status.
     *
     * @param depolStatus the new depol status
     */
    public void setDepolStatus(String depolStatus) {
        this.depolStatus = depolStatus;
    }

    /**
     * Gets the depol message.
     *
     * @return the depol message
     */
    public String getDepolMessage() {
        return depolMessage;
    }

    /**
     * Sets the depol message.
     *
     * @param depolMessage the new depol message
     */
    public void setDepolMessage(String depolMessage) {
        this.depolMessage = depolMessage;
    }

    /**
     * Gets the depol result.
     *
     * @return the depol result
     */
    public List<ToyotaDepolLimitCode> getDepolResult() {
        return depolResult;
    }

    /**
     * Sets the depol result.
     *
     * @param depolResult the new depol result
     */
    public void setDepolResult(List<ToyotaDepolLimitCode> depolResult) {
        this.depolResult = depolResult;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaDepol [depolCode=" + depolCode + ", depolStatus=" + depolStatus + ", depolMessage=" + depolMessage + ", depolResult="
                + depolResult + "]";
    }

}
