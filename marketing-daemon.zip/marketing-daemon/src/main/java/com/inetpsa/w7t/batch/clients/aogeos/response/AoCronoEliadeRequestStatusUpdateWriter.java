/*
 * Creation : 24 Jul 2018
 */

package com.inetpsa.w7t.batch.clients.aogeos.response;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.database.JpaItemWriter;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;

/**
 * The Class CfgMot2RequestStatusUpdateWriter.
 */
public class AoCronoEliadeRequestStatusUpdateWriter extends JpaItemWriter<Object> {

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */
    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The count number. */
    private int count = 1;

    /**
     * Reset count number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.count = 1;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @SuppressWarnings("unchecked")
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {
        logger.info("inside doWrite()[START]");
        for (Object object : items) {
            if (object instanceof AoCronosEliadeDto) {
                AoCronosEliadeDto aoCronosEliadeDto = (AoCronosEliadeDto) object;

                // Added for Performance improvement
                int mrqUpdatedCount = marketingRequestRepository.updateByReqId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                        aoCronosEliadeDto.getRequestId(), true, MarketingDateUtil.getTodaysDate());

                if (mrqUpdatedCount > 0) {
                    logger.info(MARKETING_STATUS_CHANGE_LOG, aoCronosEliadeDto.getRequestId(), aoCronosEliadeDto.getStatus(),
                            MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
                }

            }
        }
        logger.info("inside doWrite()[END]");
    }
}
