/*
 * Creation : 27 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

import java.io.Serializable;
import java.util.List;

/**
 * The Class CpdsRequestRepresentation.
 */
public class CpdsRequestRepresentation implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2543347433982476574L;

    /** The request id. */
    private String requestId;

    /** The version16 c. */
    private String version16C;

    /** The color ext int. */
    private String colorExtInt;

    /** The request type. */
    private String requestType;

    /** The ecom date. */
    private String ecomDate = "";

    /** The trading country. */
    private String country = "";

    /** The extended title attributes. */
    private String extendedTitleAttributes = "";

    /** The physical objects. */
    private List<PhysicalObjects> physicalObjects;

    /**
     * Instantiates a new cpds request representation.
     */
    public CpdsRequestRepresentation() { // NOSONAR No validation on empty
        // constructor
    }

    /**
     * Instantiates a new cpds request representation.
     *
     * @param requestId the request id
     * @param version16c the version 16 c
     * @param colorExtInt the color ext int
     * @param requestType the request type
     * @param ecomDate the ecom date
     * @param country the country
     * @param extendedTitleAttributes the extended title attributes
     * @param physicalObjects the physical objects
     */
    public CpdsRequestRepresentation(String requestId, String version16c, String colorExtInt, String requestType, String ecomDate, String country,
            String extendedTitleAttributes, List<PhysicalObjects> physicalObjects) {
        super();
        this.requestId = requestId;
        version16C = version16c;
        this.colorExtInt = colorExtInt;
        this.requestType = requestType;
        this.ecomDate = ecomDate;
        this.country = country;
        this.extendedTitleAttributes = extendedTitleAttributes;
        this.physicalObjects = physicalObjects;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the version16 c.
     *
     * @return the version16 c
     */
    public String getVersion16C() {
        return version16C;
    }

    /**
     * Sets the version16 c.
     *
     * @param version16c the new version16 c
     */
    public void setVersion16C(String version16c) {
        version16C = version16c;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the extended title attributes.
     *
     * @return the extended title attributes
     */
    public String getExtendedTitleAttributes() {
        return extendedTitleAttributes;
    }

    /**
     * Sets the extended title attributes.
     *
     * @param extendedTitleAttributes the new extended title attributes
     */
    public void setExtendedTitleAttributes(String extendedTitleAttributes) {
        this.extendedTitleAttributes = extendedTitleAttributes;
    }

    /**
     * Getter physicalObjects.
     *
     * @return the physicalObjects
     */
    public List<PhysicalObjects> getPhysicalObjects() {
        return physicalObjects;
    }

    /**
     * Setter physicalObjects.
     *
     * @param physicalObjects the physicalObjects to set
     */
    public void setPhysicalObjects(List<PhysicalObjects> physicalObjects) {
        this.physicalObjects = physicalObjects;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CpdsRequestRepresentation [requestId=" + requestId + ", version16C=" + version16C + ", colorExtInt=" + colorExtInt + ", requestType="
                + requestType + ", ecomDate=" + ecomDate + ", country=" + country + ", extendedTitleAttributes=" + extendedTitleAttributes
                + ", physicalObjects=" + physicalObjects + "]";
    }

}
