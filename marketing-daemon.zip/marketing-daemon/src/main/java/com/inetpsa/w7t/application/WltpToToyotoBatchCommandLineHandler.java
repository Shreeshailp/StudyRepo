/*
 * Creation : 24 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.application;

import java.io.File;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import javax.inject.Inject;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.cli.CliCommand;
import org.seedstack.seed.cli.CommandLineHandler;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.util.BatchJobEntry;

/**
 * The Class WltpToToyotoBatchCommandLineHandler.
 *
 * @author E534811
 */
@CliCommand("wltp-marketing-to-toyota-batch")
public class WltpToToyotoBatchCommandLineHandler implements CommandLineHandler {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The toyota out dir. */
    @Configuration("marketingDaemon.providers.toyota.outputDirectory")
    private File toyotaOutDir;

    /** The toyota out put filename. */
    @Configuration("marketingDaemon.providers.toyota.outPutFilename")
    private static String toyotaOutPutFilename;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "toyotaXmlFileAnswerJob";

    /**
     * {@inheritDoc}
     * 
     * @see java.util.concurrent.Callable#call()
     */
    @Override
    public Integer call() throws Exception {
        logger.info("*****GO*****");

        LocalDateTime startTime = LocalDateTime.now();
        logger.info("Starting send request to toyota writer job : {}", startTime);
        batchJobEntry.runJob(JOB_NAME, toyotaOutDir.getAbsolutePath(), toyotaOutPutFilename);
        LocalDateTime endTime = LocalDateTime.now();
        logger.info("Spring Parsing End Time : {}", endTime);
        long minutes = ChronoUnit.SECONDS.between(startTime, endTime);
        logger.info("Spring Total time taken : {}", minutes);

        logger.info("*****FIN*****");
        return 0;
    }

}
