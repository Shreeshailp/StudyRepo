/*
 * Creation : 29 Aug 2019
 */
package com.inetpsa.w7t.batch.common;

/**
 * The Class CalculationStatusDto.
 */
public class CalculationStatusDto {

    /** The request id. */
    private String requestId;

    /** The current status. */
    private String currentStatus;

    /** The previous status. */
    private String previousStatus;

    /** The answer code. */
    private String answerCode;

    /** The answer designation. */
    private String answerDesignation;

    /** The answer date. */
    private String answerDate;

    private String fileId;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public String getAnswerCode() {
        return answerCode;
    }

    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    public String getAnswerDesignation() {
        return answerDesignation;
    }

    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    public String getAnswerDate() {
        return answerDate;
    }

    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

}
