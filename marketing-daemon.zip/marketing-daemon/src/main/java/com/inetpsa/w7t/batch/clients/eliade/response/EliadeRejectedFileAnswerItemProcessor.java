/*
 * Creation : 21 Apr 2020
 */
package com.inetpsa.w7t.batch.clients.eliade.response;

import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.domain.model.MarketingRequestTracker;

/**
 * The Class EliadeRejectedFileAnswerItemProcessor.
 */
public class EliadeRejectedFileAnswerItemProcessor implements ItemProcessor<MarketingRequestTracker, MarketingRequestTracker> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public MarketingRequestTracker process(MarketingRequestTracker item) throws Exception {
        return item;
    }

}
