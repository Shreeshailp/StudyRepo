/*
 * Creation : 2 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.validations;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author E534811
 */
public class JsonDateFormatValidator implements ConstraintValidator<JsonDateFormat, String> {

    @Logging
    private static Logger logger = LoggerFactory.getLogger(JsonDateFormatValidator.class);;

    @Override
    public void initialize(JsonDateFormat constraintAnnotation) {
        // This method is intentionally empty because there is nothing to initialize.
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {

        if (value == null || value.isEmpty())
            return true;

        try {
            LocalDate.parse(value);
            return true;
        } catch (DateTimeParseException e) {
            logger.error("Error in date format ", e);
            return false;
        }
    }
}
