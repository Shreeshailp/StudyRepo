/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

/**
 * The Class CfgMot2Request.
 */
public class CfgMot2Request {

    /** The request. */
    private CfgMot2JsonAnswerRequest request;

    /**
     * Gets the request.
     *
     * @return the request
     */
    public CfgMot2JsonAnswerRequest getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(CfgMot2JsonAnswerRequest request) {
        this.request = request;
    }

    @Override
    public String toString() {
        return "CfgMot2Request [request=" + request + "]";
    }

}
