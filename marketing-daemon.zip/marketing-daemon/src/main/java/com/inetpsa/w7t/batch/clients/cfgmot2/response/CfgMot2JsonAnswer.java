/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

/**
 * The Class CfgMot2JsonAnswer.
 */
public class CfgMot2JsonAnswer {

    /** The code. */
    private String code;

    /** The designation. */
    private String designation;

    /**
     * Instantiates a new cfg mot 2 json answer.
     */
    public CfgMot2JsonAnswer() {
    }

    /**
     * Instantiates a new cfg mot 2 json answer.
     *
     * @param code the code
     * @param designation the designation
     */
    public CfgMot2JsonAnswer(String code, String designation) {
        super();
        this.code = code;
        this.designation = designation;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the designation.
     *
     * @return the designation
     */
    public String getDesignation() {
        return designation;
    }

    /**
     * Sets the designation.
     *
     * @param designation the new designation
     */
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Answer [code=" + code + ", designation=" + designation + "]";
    }

}
