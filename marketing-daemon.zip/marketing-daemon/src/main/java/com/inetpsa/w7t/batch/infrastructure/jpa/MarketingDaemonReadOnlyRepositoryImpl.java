/*
 * Creation : 6 Sep 2019
 */
package com.inetpsa.w7t.batch.infrastructure.jpa;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;
import com.inetpsa.w7t.batch.infrastructure.MarketingDaemonReadOnlyRepository;

import edu.emory.mathcs.backport.java.util.Collections;

/**
 * @author E534811
 */
public class MarketingDaemonReadOnlyRepositoryImpl implements MarketingDaemonReadOnlyRepository {

    @Inject
    EntityManager entityManager;
    @Logging
    private Logger logger;

    @SuppressWarnings("unchecked")
    @Override
    public Set<String> findFileIDsByReqestIds(Set<String> requestIds) {
        String q = "SELECT DISTINCT FILE_ID from W7TQTMRQ WHERE REQUEST_ID  IN (:requestIds)";
        Query query = entityManager.createNativeQuery(q);
        query.setParameter("requestIds", requestIds);

        if (!query.getResultList().isEmpty())
            return new HashSet<>(query.getResultList());

        return Collections.emptySet();
    }

}
