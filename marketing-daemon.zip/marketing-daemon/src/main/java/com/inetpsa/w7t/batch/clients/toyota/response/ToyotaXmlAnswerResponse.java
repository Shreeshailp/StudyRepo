/*
 * Creation : 24 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class ToyotaXmlAnswerResponse.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "fileId", "requestDate", "answerDate", "toyotaLCDV" })
@XmlRootElement(name = "Mktg")
public class ToyotaXmlAnswerResponse {

    /** The file id. */
    @XmlElement(name = "file_id", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String fileId;

    /** The request date. */
    @XmlElement(name = "request_date", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NMTOKEN")
    protected String requestDate;

    /** The answer date. */
    @XmlElement(name = "answer_date", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NMTOKEN")
    protected String answerDate;

    /** The request. */
    @XmlElement(name = "LCDV", required = true)
    protected List<ToyotaLCDV> toyotaLCDV;

    /**
     * Gets the value of the fileId property.
     * 
     * @return possible object is {@link String }
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the value of the fileId property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setFileId(String value) {
        this.fileId = value;
    }

    /**
     * Gets the value of the requestDate property.
     * 
     * @return possible object is {@link String }
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the value of the requestDate property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setRequestDate(String value) {
        this.requestDate = value;
    }

    /**
     * Gets the value of the answerDate property.
     * 
     * @return possible object is {@link String }
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Sets the value of the answerDate property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setAnswerDate(String value) {
        this.answerDate = value;
    }

    /**
     * Getter toyotaLCDV
     * 
     * @return the toyotaLCDV
     */
    public List<ToyotaLCDV> getToyotaLCDV() {
        return toyotaLCDV;
    }

    /**
     * Setter toyotaLCDV
     * 
     * @param toyotaLCDV the toyotaLCDV to set
     */
    public void setToyotaLCDV(List<ToyotaLCDV> toyotaLCDV) {
        this.toyotaLCDV = toyotaLCDV;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaXmlAnswerResponse [fileId=" + fileId + ", requestDate=" + requestDate + ", answerDate=" + answerDate + ", toyotaLCDV="
                + toyotaLCDV + "]";
    }

    /**
     * Instantiates a new toyota xml answer response.
     */
    public ToyotaXmlAnswerResponse() {
        super();
    }

}
