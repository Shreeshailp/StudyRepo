/*
 * Creation : 14 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.validation.Valid;

import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;

import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.shared.TranscodificationUtility;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.model.ClientParameter;
import com.inetpsa.w7t.domains.references.model.Country;

/**
 * The Class AoGeosItemProcessor.
 */
public class EliadeItemProcessor implements ItemProcessor<EliadeRequestDTO, EliadeRequestDTO>, StepExecutionListener {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /** The line number. */
    private volatile int lineNumber;

    /** The Constant FIVE. */
    private static final int FIVE = 5;

    /** The last movement code. */
    private String lastMovementCode;

    /** The Constant STATUS_CHANGE_LOG. */
    private static final String STATUS_CHANGE_LOG = "Marketing Request =[{}], Old status=[{}], New status=[{}]";

    /** The Constant ERROR_LOG. */
    public static final String ERROR_LOG = "Marketing Request ({}) - {}";

    /** The Constant EXTENTION_DATE_FORMAT. */
    public static final String EXTENTION_DATE_FORMAT = "yyyyMMdd";

    /** The Constant OPTION7C. */
    public static final String OPTION7C = "Y";

    /** The Constant OPTION5C. */
    public static final String OPTION5C = "N";

    /** The Constant GESTION7C. */
    public static final String GESTION7C = "Y";

    /** The Constant GESTION5C. */
    public static final String GESTION5C = "N";

    /** The Constant SEVEN. */
    public static final int SEVEN = 7;

    /** The Constant EMPTY. */
    private static final String EMPTY = "";

    /** The Constant ONE. */
    private static final int ONE = 1;

    /** The job execution status. */
    Boolean jobExecutionStatus = true;

    /** The valid country with destinations. */
    private List<String> validCountryWithDestinations = new ArrayList<>();

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /** The client parameter repository. */
    @Inject
    private ClientParameterFinder clientPrameterFinder;

    /** The destination country repository. */
    @Inject
    private DestinationCountryRepository destinationCountryRepository;

    /** The thread local line number. */
    private static ThreadLocal<Integer> threadLocalLineNumber = new ThreadLocal<>();

    /** The Constant MARKETING_REQ_LOG. */
    private static final String MARKETING_REQ_LOG = "Marketing Request =[{}]";

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public EliadeRequestDTO process(@Valid EliadeRequestDTO item) throws Exception {
        this.lastMovementCode = item.getMovementCode();

        if (jobExecutionStatus) {
            lineNumber++;
            threadLocalLineNumber.set(lineNumber);
            try {
                if (!isEmptyLine(item)) {
                    if (lineNumber == ONE) {
                        validCountryWithDestinations = MarkertingDaemonUtility.initializeValidCountries(countryRepository,
                                destinationCountryRepository);
                        logger.info("Header Line : {}", lineNumber);
                    }
                    if (("0000").equalsIgnoreCase(item.getMovementCode())) {
                        readEliadeHeaderLine(item);
                    } else if (("W010").equalsIgnoreCase(item.getMovementCode())) {
                        return w010Movement(item);
                    } else if (("9999").equalsIgnoreCase(item.getMovementCode())) {
                        logger.info("Footer Line : {}", lineNumber);
                    } else if (!item.getMovementCode().equalsIgnoreCase("0000") && !("9999").equalsIgnoreCase(item.getMovementCode().trim())
                            && !("W010").equalsIgnoreCase(item.getMovementCode().trim())) {
                        setIncorrectMovementCode(item);
                    }
                } else if (lineNumber == ONE) {
                    setInCorrectFile(item);
                }
            } catch (EmptyResultDataAccessException e) {
                // fixed jira-551
                logger.info(MARKETING_REQ_LOG, item);
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(),
                        WltpRequestErrorCode.INCORRECT_FILE.getDescription());

            } catch (Exception e) {
                logger.error("Exception parsing at line {}. Failed record from file: {} ", lineNumber, item, e);
            }
        }
        return null;
    }

    /**
     * W 010 movement.
     *
     * @param item the item
     * @return the eliade request DTO
     */
    private EliadeRequestDTO w010Movement(EliadeRequestDTO item) {
        if (MarketingDaemonServiceUtils.getEliadeHeader(item.getFileId()) != null) {
            setEliadeHeaderDetails(item);
            // CR-648
            MaturityCheckUtility.insertUnknownPattern(logger, item.getVersion(), MarketingDaemonServiceConstants.ELIADE.toUpperCase(),
                    maturityRepository);
        } else
            logger.info("Eliade header details are empty for File Id : {}", item.getFileId());

        return validateRequest(item, lineNumber);
    }

    /**
     * Sets the in correct file.
     *
     * @param item the new in correct file
     */
    private void setInCorrectFile(EliadeRequestDTO item) {
        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
        setErrorDetails(item, WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(), WltpRequestErrorCode.INCORRECT_FILE.getDescription());
        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(),
                WltpRequestErrorCode.INCORRECT_FILE.getDescription());
    }

    /**
     * Sets the incorrect movement code.
     *
     * @param item the new incorrect movement code
     */
    private void setIncorrectMovementCode(EliadeRequestDTO item) {
        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
        setErrorDetails(item, WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getRuleCode(), WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getDescription());
        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getRuleCode(),
                WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getDescription());
    }

    /**
     * Sets the eliade header details.
     *
     * @param item the new eliade header details
     */
    private void setEliadeHeaderDetails(EliadeRequestDTO item) {
        EliadeHeaderDTO eliadeHeaderDTO = MarketingDaemonServiceUtils.getEliadeHeader(item.getFileId());
        item.setSendingSite(eliadeHeaderDTO.getSendingSite());
        item.setSendingApplication(eliadeHeaderDTO.getSendingApplication());
        item.setHeaderLotNumber(eliadeHeaderDTO.getBatchNumber());
        item.setLotDate(eliadeHeaderDTO.getBatchCreationDate());
    }

    /**
     * Read header line.
     *
     * @param item the item
     */
    private void readEliadeHeaderLine(EliadeRequestDTO item) {
        String header = item.getMovementCode() + item.getPrd() + item.getLotNumber() + item.getLineNumber() + item.getBrand() + item.getCountry()
                + item.getVersion() + item.getHabillage_Ext() + item.getHabillage_Int();

        EliadeHeaderDTO headerDTO = new EliadeHeaderDTO();
        headerDTO.setSendingSite(header.substring(21, 30));
        headerDTO.setSendingApplication(header.substring(30, 38));
        headerDTO.setBatchNumber(header.substring(38, 43));
        headerDTO.setBatchCreationDate(header.substring(43, 51));
        logger.info("Header with details== SendingSite : {}, SendingApplication : {}, BatchNumber : {}, BatchCreationDate : {}",
                headerDTO.getSendingSite(), headerDTO.getSendingApplication(), headerDTO.getBatchNumber(), headerDTO.getBatchCreationDate());
        MarketingDaemonServiceUtils.setEliadeHeader(item.getFileId(), headerDTO);

    }

    /**
     * Maturity check.
     *
     * @param item the item
     * @return true, if successful
     */
    private boolean maturityCheck(EliadeRequestDTO item) {
        // fixed jira-551
        logger.info(MARKETING_REQ_LOG, item);
        boolean proceed = true;
        try {
            String maturity = MaturityCheckUtility.determineMaturityCheckForMarketingClients(item.getRequestId(), item.getVersion(),
                    maturityRepository, clientMaturityRepository, logger, MarketingDaemonServiceConstants.ELIADE.toUpperCase());
            item.setMaturity(maturity);
        } catch (SeedException se) {
            proceed = false;
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            if (se.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
                item.setAnswerDate(MarketingDateUtil.getTodaysDate());
            } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
                item.setAnswerDate(MarketingDateUtil.getTodaysDate());
            }

            if (item.getAnswerDesignation().contains("Draft")) {
                item.setMaturity("D");
            } else if (item.getAnswerDesignation().contains("Obsolete")) {
                item.setMaturity("O");
            } else if (item.getAnswerDesignation().contains("Unknown")) {
                item.setMaturity("U");
            } else if (item.getAnswerDesignation().contains("Captive fleet")) {
                item.setMaturity("F");
            }
        }
        return proceed;
    }

    /**
     * Validate request.
     *
     * @param eliadeRequestResponseDTO the ao geos request response DTO
     * @param lineNumber               the line number
     * @return the ao geos request response DTO
     */
    private EliadeRequestDTO validateRequest(EliadeRequestDTO eliadeRequestResponseDTO, int lineNumber) {
        if (eliadeRequestResponseDTO.getStatus() == null && isValidRequest(eliadeRequestResponseDTO, lineNumber)) {
            eliadeRequestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
            logger.info("REQUEST ID [{}] - Status Code changed to :{} ", eliadeRequestResponseDTO.getRequestId(),
                    MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());
        } else {
            eliadeRequestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            logger.info("REQUEST ID [{}] - Status Code changed to :{} ", eliadeRequestResponseDTO.getRequestId(),
                    MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
        }
        return eliadeRequestResponseDTO;
    }

    /**
     * Checks if is valid request.
     *
     * @param eliadeRequestResponseDTO the ao geos request response DTO
     * @param lineNumber               the line number
     * @return true, if is valid request
     */
    private boolean isValidRequest(@Valid EliadeRequestDTO eliadeRequestResponseDTO, int lineNumber) {

        EliadeRequestDTO requestResponseDTO = verifyAoGeosData(eliadeRequestResponseDTO, lineNumber);

        if (requestResponseDTO.getStatus() != null
                && requestResponseDTO.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode())))
            return false;

        /** validate country, Characteristic and destination */
        try {
            if (!requestResponseDTO.getCountry().isEmpty()) {

                if (!validCountryWithDestinations.contains(requestResponseDTO.getCountry())) {
                    requestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(requestResponseDTO, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                    LogUtility.logTheError(logger, eliadeRequestResponseDTO.getRequestId(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                    return false;
                }
            } else {
                requestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(requestResponseDTO, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                logger.error(ERROR_LOG, requestResponseDTO, AoCronoRequestErrorCode.COUNTRY_CODE_INCORRECT);
                return false;
            }
        } catch (Exception e) {
            logger.error("Excpetion : {}", e);
        }

        logger.info(STATUS_CHANGE_LOG, requestResponseDTO, MarketingRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());
        return true;
    }

    /**
     * Verify ao geos data.
     *
     * @param item       the item
     * @param lineNumber the line number
     * @return the ao geos request response DTO
     */
    private EliadeRequestDTO verifyAoGeosData(EliadeRequestDTO item, int lineNumber) {
        String gestion7c = null;

        try {
            validateConditions1(item, lineNumber);

            validateConditions2(item);

            validateOption7cAnd5c(item);
            ClientParameter gestion7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), GESTION7C);

            if (gestion7CFlagObj != null && "Y".equals(gestion7CFlagObj.getFlag7c())) {
                gestion7c = validateConditions5(item);
            } else {
                gestion7c = validateConditions6(item);

            }

            if ((!is_NULL_EMPTY(gestion7c) && gestion7c.length() % SEVEN == 0)) {
                item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
            } else {
                item.setGestion(EMPTY);
            }

            if (item.getCountry() == null || item.getCountry().isEmpty() || item.getCountry().length() != 2) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());

            }
        } catch (Exception e) {
            logger.error("Request ID[{}]: Error in AoCronoEliade Processor : {}", item.getRequestId(), e);
        }
        return item;
    }

    private void validateOption7cAnd5c(EliadeRequestDTO item) {
        ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
        if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
            if (!is_NULL_EMPTY(item.getOptions7c())) {
                if (item.getOptions7c().length() % SEVEN == 0) {
                    item.setOptions(String.valueOf(item.getOptions7c().length() / SEVEN));
                    item.setOptions7c(item.getOptions7c());

                } else {
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                    LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                }

            }
        } else {
            option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
            if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !is_NULL_EMPTY(item.getOptions7c())) {
                item.setOptions5C(item.getOptions7c().replace(" ", ""));
                if (item.getOptions5C().length() % FIVE == 0) {
                    item.setOptions5C(item.getOptions5C());
                    item.setOptions(String.valueOf(item.getOptions5C().length() / FIVE));
                    item.setOptions7c("");
                } else {
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                    LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                }
            }

        }
        // Commented the below code as part of JIRA-782 Fix

//        item.setOptions((!is_NULL_EMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
//                ? String.valueOf(item.getOptions7c().length() / SEVEN)
//                : "");
    }

    /**
     * Validate conditions 6.
     *
     * @param item the item
     * @return the string
     */
    private String validateConditions6(EliadeRequestDTO item) {
        ClientParameter gestion7CFlagObj;
        gestion7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), GESTION5C);
        String gestion7c = null;
        if (gestion7CFlagObj != null && "N".equals(gestion7CFlagObj.getFlag7c())) {
            String gestion5c = TranscodificationUtility.getGestionAsBlockOf5(item.getGestion7c());
            if (!is_NULL_EMPTY(gestion5c)) {
                item.setGestion5c(gestion5c);
                if (gestion5c.length() % 5 == 0) {
                    try {
                        gestion7c = TranscodificationUtility.transcodify(gestion5c, item.getRequestId());
                        if (gestion7c != null) {
                            item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
                            item.setGestion7c(gestion7c);
                        }
                    } catch (TranscoNotFoundException e) {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                    }

                } else {
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                    LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                            WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                }
            }
        }
        return gestion7c;
    }

    /**
     * Validate conditions 5.
     *
     * @param item the item
     * @return the string
     */
    private String validateConditions5(EliadeRequestDTO item) {
        String gestion7c;
        gestion7c = TranscodificationUtility.getGestionAsBlockOf7(item.getGestion7c());
        if (!is_NULL_EMPTY(gestion7c)) {

            if (gestion7c.length() % SEVEN == 0) {
                item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
            } else {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.GESTION_7C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.GESTION_7C_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_7C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.GESTION_7C_INCORRECT.getDescription());
            }
        }
        return gestion7c;
    }

    /**
     * Validate conditions 2.
     *
     * @param item the item
     */
    private void validateConditions2(EliadeRequestDTO item) {
        if (item.getBrand() == null || item.getBrand().isEmpty() || item.getBrand().length() != 2) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.BRAND_INCORRECT.getRuleCode(), WltpRequestErrorCode.BRAND_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.BRAND_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.BRAND_INCORRECT.getDescription());
        }

        if (item.getVersion() == null || item.getVersion().isEmpty() || item.getVersion().length() != 16) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
        }
        if (item.getHabillage_Ext() == null || item.getHabillage_Ext().isEmpty() || item.getHabillage_Ext().length() != 4) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getDescription());

        }
        if (item.getHabillage_Int() == null || item.getHabillage_Int().isEmpty() || item.getHabillage_Int().length() != 4) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getDescription());
        }
        if (!item.getExtensionDate().isEmpty() && !item.getExtensionDate().matches("([0-9]{8})")) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(), WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
        }
    }

    /**
     * Validate conditions 1.
     *
     * @param item       the item
     * @param lineNumber the line number
     */
    private void validateConditions1(EliadeRequestDTO item, int lineNumber) {
        if (lineNumber == ONE && !("0000").equalsIgnoreCase(item.getMovementCode().trim())) {
            logger.info("REQUEST_ID[{}], Line Number[{}],  MovementCode[{}]", item.getRequestId(), lineNumber, item.getMovementCode());
            if (!("W010").equalsIgnoreCase(item.getMovementCode().trim())) {// Added this if block as part of JIRA-739 fix
                setIncorrectMovementCode(item);
            }

        }
        if (item.getPrd() == null || item.getPrd().isEmpty() || item.getPrd().length() != 3) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.PRD_CODE_INCORRECT.getRuleCode(), WltpRequestErrorCode.PRD_CODE_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.PRD_CODE_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.PRD_CODE_INCORRECT.getDescription());
        }
        if (item.getLotNumber() == null || item.getLotNumber().isEmpty() || item.getLotNumber().length() != 5) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            item.setLotNumber("");
            setErrorDetails(item, WltpRequestErrorCode.LOTNUMBER_INCORRECT.getRuleCode(), WltpRequestErrorCode.LOTNUMBER_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.LOTNUMBER_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.LOTNUMBER_INCORRECT.getDescription());
        }
        if (item.getLineNumber() == null || item.getLineNumber().isEmpty() || item.getLineNumber().length() != 12) {
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            setErrorDetails(item, WltpRequestErrorCode.LINENUMBER_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.LINENUMBER_INCORRECT.getDescription());
            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.LINENUMBER_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.LINENUMBER_INCORRECT.getDescription());
        }
    }

    /**
     * Checks if is null empty.
     *
     * @param value the value
     * @return true, if is null empty
     */
    private boolean is_NULL_EMPTY(String value) {
        if (value == null)
            return true;
        if (value.isEmpty())
            return true;
        return false;
    }

    /**
     * Gets the gestion as block of 7.
     *
     * @param str the str
     * @return the gestion as block of 7
     */
    private String getGestionAsBlockOf7(String str) {
        if (str == null || str.isEmpty())
            return str;
        int beginIndex = 0;
        int endIndex = 7;
        StringBuilder sb = new StringBuilder();
        final String _7BLANKS = "       ";
        while (beginIndex <= 349) {
            String tempStr = str.substring(beginIndex, endIndex);
            if (!tempStr.contains(_7BLANKS)) {
                sb.append(tempStr);
            }
            beginIndex = endIndex;
            endIndex += 7;

        }
        return sb.toString();
    }

    /**
     * Gets the gestion as block of 5.
     *
     * @param str the str
     * @return the gestion as block of 5
     */
    private String getGestionAsBlockOf5(String str) {
        if (str == null || str.isEmpty())
            return str;
        int beginIndex = 0;
        int endIndex = 5;
        StringBuilder sb = new StringBuilder();
        final String _5BLANKS = "     ";
        while (beginIndex <= 349) {
            String tempStr = str.substring(beginIndex, endIndex);
            if (!tempStr.contains(_5BLANKS)) {
                sb.append(tempStr);
            }
            beginIndex = endIndex;
            endIndex += 5;

        }
        return sb.toString();
    }

    /**
     * Sets the error details.
     *
     * @param mrq         the mrq
     * @param ruleCode    the rule code
     * @param description the description
     */
    private void setErrorDetails(EliadeRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        logger.info(MARKETING_REQ_LOG, mrq);
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Checks if is empty line.
     *
     * @param item the item
     * @return true, if is empty line
     */
    private boolean isEmptyLine(EliadeRequestDTO item) {
        return (item.getMovementCode() + item.getBrand() + item.getCountry() + item.getExtensionDate() + item.getGestion() + item.getHabillage_Ext()
                + item.getHabillage_Int() + item.getLineNumber() + item.getLineNumber() + item.getLotNumber() + item.getOptions() + item.getPrd()
                + item.getVersion() + item.getFiller()).length() == 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#beforeStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public void beforeStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#afterStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);
        if (stepExecution.getReadCount() == 0 || !("9999").equalsIgnoreCase(lastMovementCode))
            logger.error("Incorrect Eliade file");
        return null;
    }

    /**
     * Gets the country by code.
     *
     * @param countryCode the country code
     * @return the country by code
     */
    Optional<Country> getCountryByCode(String countryCode) {
        return countryRepository.byCode(countryCode);
    }

    /**
     * Transcodify.
     *
     * @param option5C  the option5 c
     * @param requestId the request id
     * @return the string
     */
    // private String transcodify(String option5C, String requestId) {
    // TranscoManager57 tm57 = TranscoManager57.getInstance();
    // StringBuilder persValue = new StringBuilder();
    //
    // List<String> lcdvList = new ArrayList<>();
    // int index = 0;
    // while (index < option5C.length()) {
    // lcdvList.add(" " + option5C.substring(index, index + FIVE));
    // index += FIVE;
    // }
    // logger.info("REQUEST ID [{}] ,Transcodification module request = [{}]", requestId, option5C);
    // try {
    // for (String lcdv : lcdvList)
    // persValue.append(tm57.transco(lcdv));
    // } catch (TranscoNotFoundException e) {
    // logger.error("REQUEST ID [{}] ,Exception thrown by Transcodification module", requestId, e);
    // LogUtility.logTheError(logger, requestId, WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
    // WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
    // return null;
    // }
    // logger.info("REQUEST ID [{}] ,Transcodification module response = [{}]", requestId, persValue);
    //
    // return persValue.toString();
    // }

}
