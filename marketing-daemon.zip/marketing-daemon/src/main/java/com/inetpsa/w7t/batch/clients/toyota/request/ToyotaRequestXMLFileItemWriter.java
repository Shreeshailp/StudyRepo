/*
 * Creation : 27 Nov 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.request;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaLCDV;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaXmlAnswerResponse;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaXmlFileResource;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;

/**
 * The Class ToyotaRequestXMLFileItemWriter.
 */
public class ToyotaRequestXMLFileItemWriter extends JpaItemWriter<Object> {

    /** The req number. */
    private long reqNumber;

    /** The prev req number. */
    private long prevReqNumber;

    /** The invalid req number. */
    private long invalidReqNumber;

    /** The is same day file. */
    private boolean isSameDayFile = false;

    /** The resource. */
    private ToyotaXmlFileResource resource;

    /** The original file id. */
    private String originalFileId = "";

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The Constant STATUS_CHANGE_LOG. */
    private static final String STATUS_CHANGE_LOG = "Marketing Toyota Request number =[{}], Old status=[{}], New status=[{}]";

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @SuppressWarnings("unchecked")
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {

        logger.info("===================Start Preparing Records to Insert - [{}] ", new Date());

        List<MarketingRequest> marketingRequestList = (List<MarketingRequest>) items;

        List<MarketingRequest> uniquemarketingRequestList = new ArrayList<>();
        logger.info("===================Start Preparing Records to Insert - [{}] ", new Date());
        Optional<MarketingRequest> sameDayMarketingRequest = marketingRequestRepository.bytodayLastRequest(LocalDate.now().toString(),
                MarketingDaemonServiceConstants.TOYOTA.toUpperCase());
        String toyotaFileId = MarkertingDaemonUtility.generateFileId(MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), sameDayMarketingRequest,
                this.uniqueIdentifier);
        logger.info("FILE ID : [{}]-------Ready To Insert ", toyotaFileId);

        synchronized (ToyotaRequestXMLFileItemWriter.class) {
            prevReqNumber = MarkertingDaemonUtility.getToyotaLastRequestNumberFromMRS(marketingRequestList, prevReqNumber, threadPoolMasterRepository,
                    MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), toyotaFileId);
        }

        Map<String, String> uniqueId = new HashMap<>();

        List<MarketingRequest> marketingRequestArrayList = new ArrayList<>(marketingRequestList);
        marketingRequestArrayList.forEach(objMarketingRequest -> {
            originalFileId = objMarketingRequest.getFileId();
            if (!uniqueId.containsKey(objMarketingRequest.getRequestID())) {
                uniqueId.put(objMarketingRequest.getRequestID(), objMarketingRequest.getRequestID());
                objMarketingRequest.setFileId(toyotaFileId);
                objMarketingRequest.setInternalReqId(
                        generateInternalRequestId(prevReqNumber, sameDayMarketingRequest, objMarketingRequest.getFileId(), isSameDayFile));
                // fixed jira-579
                logger.info("REQUEST_ID [{}] - INTERNAL_REQUEST_ID [{}]", objMarketingRequest.getRequestID(), objMarketingRequest.getInternalReqId());
                uniquemarketingRequestList.add(objMarketingRequest);

                if (objMarketingRequest.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                    ++invalidReqNumber;
                }
                ++reqNumber;
                ++prevReqNumber;
            }

        });
        logger.info("===================End Preparing Records to Insert - [{}] ", new Date());

        if (!uniquemarketingRequestList.isEmpty()) {
            MarkertingDaemonUtility.saveMarketingRequest(uniquemarketingRequestList, marketingRequestRepository, threadPoolMasterRepository);
            synchronized (ToyotaRequestXMLFileItemWriter.class) {
                MarkertingDaemonUtility.createMRQTracker(uniquemarketingRequestList.get(0).getFileId(),
                        MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), reqNumber, (reqNumber - invalidReqNumber),
                        marketingRequestTrackerRepository, MarketingDaemonConfig.getReqMachine(), MarketingDaemonConfig.getResMachine(),
                        originalFileId);
                logger.info("===================All Records Inserted - [{}] ", new Date());
                // save data to W7TQTFSF table
                // Added below code as part of jira-660 fix -- start
                fsFlagFileService.saveFsFlagEntity(MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), this.fsFlagFileName,
                        uniquemarketingRequestList.get(0).getFileId());
                // jira-660 fix -- end
            }
        }
        if (reqNumber != 0)
            sendOnlyRejecedRequestFile(uniquemarketingRequestList, originalFileId);
    }

    /**
     * Generate internal request id.
     *
     * @param prevReqNumber2 the prev req number
     * @param marketingRequest the marketing request
     * @param clientReqConst3 the client req const 3
     * @param isSameDayFile the is same day file
     * @return the string
     */
    public String generateInternalRequestId(long prevReqNumber2, Optional<MarketingRequest> marketingRequest, String clientReqConst3,
            boolean isSameDayFile) {
        String constant12 = clientReqConst3;
        StringBuilder constantOfZeros = new StringBuilder();
        int numOfZerosToBeConcat = 20 - constant12.length();
        for (int i = 1; i <= numOfZerosToBeConcat; i++) {
            constantOfZeros.append("0");
        }
        String constantZero = constantOfZeros.toString();

        return constant12 + constantZero.substring(0, constantZero.length() - String.valueOf(prevReqNumber2).length()) + prevReqNumber2;
    }

    /**
     * Send only rejeced request file.
     *
     * @param marketingRequestList the marketing request list
     * @param originalFileId the original file id
     */
    private void sendOnlyRejecedRequestFile(List<MarketingRequest> marketingRequestList, String originalFileId) {
        if (reqNumber == invalidReqNumber) {

            List<ToyotaLCDV> toyotaLCDVList = new ArrayList<>();

            ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();
            marketingRequestList.forEach(marketingRequest -> {
                toyotaLCDVList.addAll(setRejectedRequest(marketingRequest).getToyotaLCDV());
                marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequestRepository.updateStatusByInternalRequestId(marketingRequest.getStatus(), marketingRequest.getInternalReqId());
                logger.info(STATUS_CHANGE_LOG, marketingRequest.getRequestID(), MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(),
                        MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
            });
            toyotaXmlAnswerResponse.setToyotaLCDV(toyotaLCDVList);
            if (!marketingRequestList.isEmpty()) {
                // Added below 2 lines as part of the JIRA-528 FIX
                toyotaXmlAnswerResponse.setFileId(originalFileId);
                toyotaXmlAnswerResponse.setRequestDate(marketingRequestList.get(0).getRequestDate());
                toyotaXmlAnswerResponse.setAnswerDate(marketingRequestList.get(0).getAnswerDate());
                serialize(toyotaXmlAnswerResponse);
                logger.info("toyotaAnswer xml Response file generated");
                // fixed jira-625
                marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                        String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), marketingRequestList.get(0).getFileId());
                if (fileConfigUtilService != null && this.fsFlagFileName != null) {
                    // Added below code as part of jira-660 fix -- start
                    MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "toyota", this.fsFlagFileName);
                    int result = fsFlagFileService.deleteFsFlagFileByFileId(marketingRequestList.get(0).getFileId());
                    if (result > 0) {
                        logger.info("FsFlagFileName: [{}] deleted from database table ", this.fsFlagFileName);
                    }
                    // jira-660 fix -- end
                }
            }
        }
    }

    /**
     * Sets the rejected request.
     *
     * @param marketingRequest the marketing request
     * @return the toyota xml answer response
     */
    private ToyotaXmlAnswerResponse setRejectedRequest(MarketingRequest marketingRequest) {
        ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();

        ToyotaLCDV toyotaLCDV = new ToyotaLCDV();

        toyotaLCDV.setNumber(marketingRequest.getRequestID());
        toyotaLCDV.setWltpStatus(marketingRequest.getAnswerCode());
        toyotaLCDV.setWltpErrorMsg(marketingRequest.getAnswerDesig());

        toyotaXmlAnswerResponse.setToyotaLCDV(Arrays.asList(toyotaLCDV));

        return toyotaXmlAnswerResponse;
    }

    /**
     * Serialize.
     *
     * @param toyotaXmlAnswerResponse the toyota xml answer response
     */
    private void serialize(ToyotaXmlAnswerResponse toyotaXmlAnswerResponse) {
        logger.debug("Entering Toyota XML File Writer Serializer... ");
        try {
            JAXBContext contextObj = JAXBContext.newInstance(ToyotaXmlAnswerResponse.class);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            File sourceFile = new File(getResource().getFile().getAbsolutePath());
            logger.info("Removing the .part ");
            int lastIndex = sourceFile.getName().lastIndexOf('.');
            String newFileName = sourceFile.getName().substring(0, lastIndex) + MarketingDateUtil.getTodaysDateforCo2MinMax() + ".xml";
            StringBuilder tempFilePath = new StringBuilder(resource.getFile().getAbsolutePath());
            String newFilePath = "";
            if (tempFilePath.toString().contains("/")) {
                newFilePath = tempFilePath.substring(0, tempFilePath.lastIndexOf("/") + 1) + newFileName;
                logger.info("new file path : [{}]", newFilePath);
            } else if (tempFilePath.toString().contains("\\")) {
                newFilePath = tempFilePath.substring(0, tempFilePath.lastIndexOf("\\") + 1) + newFileName;
                logger.info("new file path : [{}]", newFilePath);
            }
            try (FileOutputStream fos = new FileOutputStream(new File(newFilePath), true)) {
                marshallerObj.marshal(toyotaXmlAnswerResponse, fos);
            }
            logger.info("WLTP answer written to Toyota file [{}]", tempFilePath);
        } catch (JAXBException | IOException e) {
            logger.error("Error Marshalling {} answer: ", e);
        }
    }

    /**
     * Gets the prev req number.
     *
     * @return the prev req number
     */
    public long getPrevReqNumber() {
        return prevReqNumber;
    }

    /**
     * Sets the prev req number.
     *
     * @param prevReqNumber the new prev req number
     */
    public void setPrevReqNumber(long prevReqNumber) {
        this.prevReqNumber = prevReqNumber;
    }

    /**
     * Checks if is same day file.
     *
     * @return true, if is same day file
     */
    public boolean isSameDayFile() {
        return isSameDayFile;
    }

    /**
     * Sets the same day file.
     *
     * @param isSameDayFile the new same day file
     */
    public void setSameDayFile(boolean isSameDayFile) {
        this.isSameDayFile = isSameDayFile;
    }

    /**
     * Getter resource.
     *
     * @return the resource
     */
    public ToyotaXmlFileResource getResource() {
        return resource;
    }

    /**
     * Setter resource.
     *
     * @param resource the resource to set
     */
    public void setResource(ToyotaXmlFileResource resource) {
        this.resource = resource;
    }

    /**
     * Gets the invalid req number.
     *
     * @return the invalid req number
     */
    public long getInvalidReqNumber() {
        return invalidReqNumber;
    }

    /**
     * Sets the invalid req number.
     *
     * @param invalidReqNumber the new invalid req number
     */
    public void setInvalidReqNumber(long invalidReqNumber) {
        this.invalidReqNumber = invalidReqNumber;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

}
