/*
 * Creation : 24 Jul 2018
 */

package com.inetpsa.w7t.batch.clients.toyota.response;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * The Class ToyotaXmlAnswerRowMapper.
 */
public class ToyotaXmlAnswerRowMapper implements RowMapper<ToyotaXmlAnswerDto> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public ToyotaXmlAnswerDto mapRow(ResultSet rs, int rowNum) throws SQLException {
        ToyotaXmlAnswerDto request = new ToyotaXmlAnswerDto();
        request.setColorExtInt(rs.getString("COLOR_EXT_INT"));
        request.setExtAttr(rs.getString("EXT_ATTR"));
        request.setExtensionDate(rs.getString("DATEXT"));
        request.setGestion5C(rs.getString("GESTION5C"));
        request.setGestion7C(rs.getString("GESTION7C"));
        request.setMountingCenter(rs.getString("MOUNTING_CENTER"));
        request.setOptions(rs.getString("OPTIONS"));
        request.setOptions5C(rs.getString("OPTIONS5C"));
        request.setOptions7C(rs.getString("OPTIONS7C"));
        request.setRequestType(rs.getString("REQUEST_TYPE"));
        request.setStatus(rs.getString("STATUS"));
        request.setTradingCountry(rs.getString("TRADING_COUNTRY"));
        request.setVersion16(rs.getString("VERSION16"));
        request.setGestion(rs.getString("GESTION"));
        request.setRequestId(rs.getString("REQUEST_ID"));
        request.setAnswerCode(rs.getString("ANSWER_CODE"));
        request.setAnswerDesignation(rs.getString("ANSWER_DESIG"));
        request.setAnswerDate(rs.getString("ANSWER_DATE"));
        request.setFileId(rs.getString("FILE_ID"));
        request.setRequestDate(rs.getString("REQUEST_DATE"));

        request.updatePhysicalQuantities(getNewtonPhysicalQuantity(rs));
        logger.info("REQUEST_ID =[{}] - all ResultSet values added to the ToyotaDto", request.getRequestId());
        return request;
    }

    /**
     * Gets the newton physical quantity.
     *
     * @param rs the rs
     * @return the newton physical quantity
     */
    List<EnginePhysicalQuantity> getNewtonPhysicalQuantity(ResultSet rs) {
        List<EnginePhysicalQuantity> enginePhysicalQuantityList = new ArrayList<>();

        try {
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.MASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_VEHIC"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.SCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_VEHIC"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, getPrimitiveTypeForNULL(rs.getDouble("CRR_VEHIC"))));

            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.UMASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_SOCLE"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.EMASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_EQUIP"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.ESCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_EQUIP"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.USCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_SOCLE"))));
            logger.info("REQUEST_ID =[{}] - all EnginePhysicalQuantity values setted from ResultSet", rs.getString("REQUEST_ID"),
                    enginePhysicalQuantityList);
        } catch (SQLException e) {
            logger.error("Sql Exception : {}", e);

        }

        return enginePhysicalQuantityList;
    }

    /**
     * Gets the primitive type for NULL.
     *
     * @param value the value
     * @return the primitive type for NULL
     */
    private double getPrimitiveTypeForNULL(Double value) {
        if (value == null)
            return 0.0;
        return value.doubleValue();
    }
}