/*
 * Creation : 12 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domain.model.dto;

import java.util.UUID;

/**
 * @author E534811
 */
public class MarketingRequestTrackerDTO {

    private UUID guid;

    private String client = "";

    private String fileId = "";

    private Long mrqCount;

    private Long validReqCount;

    private String answerGenerated;

    public UUID getGuid() {
        return guid;
    }

    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Long getMrqCount() {
        return mrqCount;
    }

    public void setMrqCount(Long mrqCount) {
        this.mrqCount = mrqCount;
    }

    /**
     * Getter validReqCount
     * 
     * @return the validReqCount
     */
    public Long getValidReqCount() {
        return validReqCount;
    }

    /**
     * Setter validReqCount
     * 
     * @param validReqCount the validReqCount to set
     */
    public void setValidReqCount(Long validReqCount) {
        this.validReqCount = validReqCount;
    }

    public String getAnswerGenerated() {
        return answerGenerated;
    }

    public void setAnswerGenerated(String answerGenerated) {
        this.answerGenerated = answerGenerated;
    }

    @Override
    public String toString() {
        return "MarketingRequestTrackerDTO [guid=" + guid + ", client=" + client + ", fileId=" + fileId + ", mrqCount=" + mrqCount
                + ", validReqCount=" + validReqCount + ", answerGenerated=" + answerGenerated + "]";
    }

}
