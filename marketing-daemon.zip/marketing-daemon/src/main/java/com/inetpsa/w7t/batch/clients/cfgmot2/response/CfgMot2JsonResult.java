/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

/**
 * The Class CfgMot2JsonResult.
 */
public class CfgMot2JsonResult {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Instantiates a new cfg mot 2 json result.
     *
     * @param code the code
     * @param value the value
     */
    public CfgMot2JsonResult(String code, String value) {
        super();
        this.code = code;
        this.value = value;
    }

    public CfgMot2JsonResult() {
        super();
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Result [code=" + code + ", value=" + value + "]";
    }
}
