package com.inetpsa.w7t.batch.clients.aogeos.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class AoGeosFileResource.
 */
public class AoGeosFileResource extends FileSystemResource {

    /**
     * Instantiates a new jato json file resource.
     *
     * @param path the path
     * @param aogeosFileName the aogeos file name
     */
    public AoGeosFileResource(String path, String aogeosFileName) {
        super(path + File.separator + aogeosFileName);
    }
}