/**
 * 
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import javax.inject.Named;

import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * @author E534811
 */
@Named(" marketingProvider")
public class MarketingProviderFileWriter extends DefaultMarketingFileWriter {

    public MarketingProviderFileWriter() {
        super();
    }

    public MarketingProviderFileWriter(String name, MarketingDaemonProviderConfig config) {
        super(name, config.getOutputDirectory(), config.getInputFilename());
    }

    @Override
    public void serialize(MarketingRequest request) {
        // TODO Auto-generated method stub

    }

    @Override
    public void publish() {
        // TODO Auto-generated method stub

    }

}
