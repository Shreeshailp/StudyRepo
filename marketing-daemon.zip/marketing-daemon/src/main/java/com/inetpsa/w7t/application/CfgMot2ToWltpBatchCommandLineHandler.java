/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.application;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.cli.CliCommand;
import org.seedstack.seed.cli.CommandLineHandler;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.clients.cfgmot2.request.WltpJsonFileFilter;
import com.inetpsa.w7t.batch.util.BatchJobEntry;

/**
 * The Class CfgMot2ToWltpBatchCommandLineHandler.
 *
 * @author E534811
 */
@CliCommand("cfgMot2-to-wltp-marketing-batch")
public class CfgMot2ToWltpBatchCommandLineHandler implements CommandLineHandler {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The config mo 2 in dir. */
    @Configuration("marketingDaemon.clients.configMot2.inputDirectory")
    private File configMo2InDir;

    /** The config mo 2 out dir. */
    @Configuration("marketingDaemon.providers.configMot2.outputDirectory")
    private File configMo2OutDir;

    /** The pattern. */
    @Configuration("marketingDaemon.clients.configMot2.filenamePattern")
    private String pattern;

    /** The Constant HISTORY_DIR. */
    private static final String HISTORY_DIR = "history";

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "cfgMot2JsonFileRequestJob";

    /**
     * {@inheritDoc}
     * 
     * @see java.util.concurrent.Callable#call()
     */
    @Override
    public Integer call() throws Exception {
        logger.info("*****GO*****");

        LocalDateTime startTime = LocalDateTime.now();
        logger.info("Starting configMot2 json reader job : {}", startTime);
        File inFile = getTheOldestFile(configMo2InDir, pattern);
        if (inFile != null) {
            batchJobEntry.runJob(JOB_NAME, inFile.getAbsolutePath(), configMo2OutDir);
        } else
            logger.info("No file availble to read");

        logger.info("File Directory {}", inFile);
        LocalDateTime endTime = LocalDateTime.now();
        logger.info("Spring Parsing End Time : {}", endTime);
        long minutes = ChronoUnit.SECONDS.between(startTime, endTime);
        logger.info("Spring Total time taken : {}", minutes);

        logger.info("*****FIN*****");
        return 0;
    }

    /**
     * Gets the the oldest file.
     *
     * @param filePath the file path
     * @param pattern the pattern
     * @return the the oldest file
     */
    public static File getTheOldestFile(File filePath, String pattern) {
        if (filePath != null && pattern != null) {
            FileFilter fileFilter = new WltpJsonFileFilter(pattern);
            File[] files = filePath.listFiles(fileFilter);

            if (files != null && files.length > 0) {
                return getSortResult(files);
            }
        }
        return null;
    }

    /**
     * Gets the sort result.
     *
     * @param files the files
     * @return the sort result
     */
    private static File getSortResult(File[] files) {
        Arrays.sort(files, (File f1, File f2) -> {
            if (f2.lastModified() > f1.lastModified())
                return 1;
            if (f2.lastModified() == f1.lastModified())
                return 0;
            return -1;
        });
        return files[0];
    }

    /**
     * Move file to history.
     *
     * @param infile the infile
     * @return the file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static File moveFileToHistory(File infile) throws IOException {
        if (infile != null && infile.isFile()) {
            StringBuilder newName = new StringBuilder(String.valueOf(System.nanoTime())).append("_").append(infile.getName());
            StringBuilder destFilePath = new StringBuilder(infile.getParent()).append(File.separator).append(HISTORY_DIR).append(File.separator)
                    .append(newName);
            File destfile = new File(destFilePath.toString());
            FileUtils.moveFile(infile, destfile);
            return destfile;
        }
        throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to move file to history folder");
    }
}
