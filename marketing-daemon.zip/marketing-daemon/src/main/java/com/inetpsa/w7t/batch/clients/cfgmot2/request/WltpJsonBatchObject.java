/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author E534811
 */
@XmlRootElement(name = "CFGMOT2-WLTP")
public class WltpJsonBatchObject implements Serializable {

    private static final long serialVersionUID = 5983205513314667652L;

    @Valid
    private List<WltpJsonBatchRequestObject> wltpJsonBatchRequestObjectList;

    public List<WltpJsonBatchRequestObject> getWltpJsonBatchRequestObjectList() {
        return wltpJsonBatchRequestObjectList;
    }

    public void setWltpJsonBatchRequestObjectList(List<WltpJsonBatchRequestObject> wltpJsonBatchRequestObjectList) {
        this.wltpJsonBatchRequestObjectList = wltpJsonBatchRequestObjectList;
    }

    @Override
    public String toString() {
        return "WltpJsonRequestBatchObject [wltpJsonBatchRequestObjectList=" + wltpJsonBatchRequestObjectList + "]";
    }

    public WltpJsonBatchObject(@JsonProperty("CFGMOT2-WLTP") List<WltpJsonBatchRequestObject> wltpJsonBatchRequestObjectList) {
        this.wltpJsonBatchRequestObjectList = wltpJsonBatchRequestObjectList;
    }

    public WltpJsonBatchObject() {
    }

}
