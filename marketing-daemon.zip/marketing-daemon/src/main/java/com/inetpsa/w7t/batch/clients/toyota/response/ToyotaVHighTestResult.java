/*
 * Creation : 1 Nov 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ToyotaVHighTestResult.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "vhighPhaseResults" })
@XmlRootElement(name = "VHIGH_TEST_RESULTS")
public class ToyotaVHighTestResult {

    /** The vhigh phase results. */
    @XmlElement(name = "phase_result", required = true)
    protected List<ToyotaPhase> vhighPhaseResults;

    /**
     * Getter vhighPhaseResults.
     *
     * @return the vhighPhaseResults
     */
    public List<ToyotaPhase> getVhighPhaseResults() {
        return vhighPhaseResults;
    }

    /**
     * Setter vhighPhaseResults.
     *
     * @param vhighPhaseResults the vhighPhaseResults to set
     */
    public void setVhighPhaseResults(List<ToyotaPhase> vhighPhaseResults) {
        this.vhighPhaseResults = vhighPhaseResults;
    }

    /**
     * Instantiates a new toyota V high test result.
     */
    public ToyotaVHighTestResult() {
        super();
    }

}
