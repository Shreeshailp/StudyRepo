/*
 * Creation : 24 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import java.util.List;

/**
 * The Class CfgMot2JsonResponse.
 */
public class CfgMot2JsonResponse extends CfgMot2Request {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The answer. */
    private CfgMot2JsonAnswer answer;

    /** The wltp data. */
    private CfgMot2JsonData wltpData;

    /** The phy result. */
    private List<CfgMot2JsonPhysicalResult> physResult;

    /** The phase. */
    private List<CfgMot2JsonPhase> phase;

    /**
     * Gets the answer.
     *
     * @return the answer
     */
    public CfgMot2JsonAnswer getAnswer() {
        return answer;
    }

    /**
     * Sets the answer.
     *
     * @param answer the new answer
     */
    public void setAnswer(CfgMot2JsonAnswer answer) {
        this.answer = answer;
    }

    /**
     * Gets the wltp data.
     *
     * @return the wltp data
     */
    public CfgMot2JsonData getWltpData() {
        return wltpData;
    }

    /**
     * Sets the wltp data.
     *
     * @param wltpData the new wltp data
     */
    public void setWltpData(CfgMot2JsonData wltpData) {
        this.wltpData = wltpData;
    }

    /**
     * Gets the phys result.
     *
     * @return the phys result
     */
    public List<CfgMot2JsonPhysicalResult> getPhysResult() {
        return physResult;
    }

    /**
     * Sets the phys result.
     *
     * @param physResult the new phys result
     */
    public void setPhysResult(List<CfgMot2JsonPhysicalResult> physResult) {
        this.physResult = physResult;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public List<CfgMot2JsonPhase> getPhase() {
        return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(List<CfgMot2JsonPhase> phase) {
        this.phase = phase;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CfgMot2JsonResponse [answer=" + answer + ", wltpData=" + wltpData + ", physResult=" + physResult + ", phase=" + phase + "]";
    }

}
