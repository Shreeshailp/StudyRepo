/*
 * Creation : 24 Jul 2018
 */

package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * The Class CfgMot2RequestStatusUpdateWriter.
 */
public class CfgMot2RequestStatusUpdateWriter extends JpaItemWriter<Object> {

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */
    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {
        for (Object object : items) {
            if (object instanceof CfgMot2AnswerDto) {
                CfgMot2AnswerDto cfgMot2AnswerDto = (CfgMot2AnswerDto) object;

                int mrqUpdatedCount = marketingRequestRepository.updateByRequestId(
                        String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), cfgMot2AnswerDto.getRequestId(), true,
                        MarketingDateUtil.getTodaysDate());

                if (mrqUpdatedCount > 0) {
                    logger.info(MARKETING_STATUS_CHANGE_LOG, cfgMot2AnswerDto.getRequestId(), cfgMot2AnswerDto.getStatus(),
                            MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
                }

            }
        }
        List<MarketingRequest> marketingRequestStatusWrongList = marketingRequestRepository.byClientAndStatus(
                MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase(),
                String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
        marketingRequestStatusWrongList.forEach(marketingRequest -> {
            try {
                marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequest.setAnswerSent(true);
                logger.info("Answer Sent for the Request ID: [{}]", marketingRequest.getRequestID());
                marketingRequestRepository.saveEntity(marketingRequest);
                logger.info(MARKETING_STATUS_CHANGE_LOG, marketingRequest, MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(),
                        MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
            } catch (Exception e) {

            }
        });

    }
}
