/**Creation:29 Nov 2019*/
package com.inetpsa.w7t.batch.clients.icube.response;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.inetpsa.w7t.batch.clients.aogeos.request.IcubeRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeUtility;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;

/*** The Class IcubeItemWriter. */

public class IcubeItemWriter extends JpaItemWriter<Object> {

    /** The resource. */
    private IcubeFileResource resource;

    /** The number of movements. */
    private static final String NUMBER_OF_MOVEMENTS = "00000000"; // 8 char

    /** The Constant EIGHT. */
    private static final int EIGHT = 8;

    /** The Constant THREE. */
    private static final int THREE = 3;

    /** The Constant TWENTY. */
    private static final int TWENTY = 20;

    /** The original file id. */
    private String originalFileId = "";

    /** The formatter. */
    DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The client parameter repository. */
    @Inject
    private ClientParameterFinder clientPrameterFinder;

    /**
     * {@inheritDoc}
     *
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @SuppressWarnings("unchecked")
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {
        long reqNumber = 0;
        long prevReqNumber = 0;
        long invalidReqNumber = 0;
        Set<IcubeRequestDTO> dtosList = new HashSet<>((List<IcubeRequestDTO>) items);
        List<IcubeRequestDTO> icubeDtoList = new ArrayList<>((List<IcubeRequestDTO>) items);
        List<MarketingRequest> responseToWrite = new ArrayList<>();
        synchronized (IcubeItemWriter.class) {
            if (!icubeDtoList.isEmpty()) {
                logger.info("In synchronized block, prevReqNumber==[{}], File_ID == [{}]", prevReqNumber, icubeDtoList.get(0).getFileId());
                prevReqNumber = MarkertingDaemonUtility.getIcubeLastRequestNumberFromMRS(dtosList, prevReqNumber, threadPoolMasterRepository,
                        MarketingDaemonServiceConstants.ICUBE.toUpperCase(), icubeDtoList.get(0).getFileId());
            }
            logger.info("===================Start Preparing Records to Insert - [{}] ", new Date());

            Set<IcubeRequestDTO> duplicateSet = findDuplicates(icubeDtoList);

            for (IcubeRequestDTO icubeRequestDTO : duplicateSet) {
                logger.info(" Duplicate REQUEST_ID : [{}] and FILE_ID : [{}] ", icubeRequestDTO.getRequestId(), icubeRequestDTO.getFileId());
            }
            String fsFlagFileName = "";
            for (IcubeRequestDTO dto : dtosList) {
                MarketingRequest entity = new MarketingRequest();
                String ext = dto.getHabillage_Ext() + dto.getHabillage_Int();
                entity.setExtensionDate(dto.getExtensionDate());
                entity.setRequestDate(MarketingDateUtil.getTodaysDate());

                fsFlagFileName = dto.getFsFlagFileName();

                String requestId = dto.getPrd() + dto.getLotNumber() + dto.getLineNumber();
                originalFileId = dto.getPrd() + dto.getLotNumber();
                entity.setBrand(dto.getBrand());
                entity.setRequestType("FULL");
                entity.setRequestID(requestId);
                logger.info("in foreach loop, prevReqNumber == [{}], File_ID== [{}]", prevReqNumber, dto.getFileId());
                entity.setInternalReqId(MarkertingDaemonUtility.generateInternalRequestId(prevReqNumber, dto.getFileId()));
                // fixed jira-579
                logger.info("REQUEST_ID [{}] - INTERNAL_REQUEST_ID [{}]", entity.getRequestID(), entity.getInternalReqId());
                entity.setColorExtInt(ext);
                String gestion = dto.getGestion();
                if (gestion == null) {
                    gestion = "00";
                } else if (gestion.length() == 1) {
                    gestion = "0" + gestion;
                }
                entity.setGestion(gestion);
                String option = dto.getOptions();
                if (option == null) {
                    option = "00";
                } else if (option.length() == 1) {
                    option = "0" + option;
                }
                entity.setOptions(option);
                entity.setVersion16(dto.getVersion());
                entity.setTradingCountry(dto.getCountry());
                entity.setStatus(dto.getStatus());
                entity.setOptions5C(dto.getOptions5C());
                entity.setOptions7C(dto.getOptions7c());
                entity.setGestion5C(dto.getGestion5c());
                entity.setGestion7C(dto.getGestion7c());
                entity.setClient(MarketingDaemonServiceConstants.ICUBE.toUpperCase());
                entity.setAnswerCode(dto.getAnswerCode());
                entity.setAnswerDesig(dto.getAnswerDesignation());
                entity.setAnswerDate(dto.getAnswerDate());
                entity.setSendingSite(dto.getSendingSite());
                entity.setSendingApplication(dto.getShippingApplication());
                entity.setLotNumber(dto.getHeaderLotNumber());
                entity.setLotDate(LocalDate.parse(dto.getLotDate(), formatter).toString());
                entity.setFileId(dto.getFileId());
                entity.setMaturity(dto.getMaturity());
                responseToWrite.add(entity);

                if (entity.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                    ++invalidReqNumber;
                }

                ++reqNumber;
                ++prevReqNumber;
            }

            if (!responseToWrite.isEmpty()) {
                MarkertingDaemonUtility.saveMarketingRequest(responseToWrite, marketingRequestRepository, threadPoolMasterRepository);
                MarkertingDaemonUtility.createMRQTracker(responseToWrite.get(0).getFileId(), MarketingDaemonServiceConstants.ICUBE.toUpperCase(),
                        reqNumber, (reqNumber - invalidReqNumber), marketingRequestTrackerRepository, MarketingDaemonConfig.getReqMachine(),
                        MarketingDaemonConfig.getResMachine(), originalFileId);
                // save data to W7TQTFSF table
                // Added below code as part of jira-660 fix -- start
                fsFlagFileService.saveFsFlagEntity(responseToWrite.get(0).getClient(), fsFlagFileName, responseToWrite.get(0).getFileId());
                // jira-660 fix -- end
                logger.info("===================All Records Inserted - [{}] ", new Date());
            }
            if (reqNumber != 0)
                sendOnlyRejecedRequestFile(responseToWrite, reqNumber, invalidReqNumber);
        }
    }

    /**
     * Send only rejeced request file.
     *
     * @param responseToWrite the response to write
     * @param reqNumber the req number
     * @param invalidReqNumber the invalid req number
     */
    private void sendOnlyRejecedRequestFile(List<MarketingRequest> responseToWrite, long reqNumber, long invalidReqNumber) {
        if (reqNumber == invalidReqNumber && !responseToWrite.isEmpty()) {
            int count = 0;

            try {
                File sourceFile = new File(getResource().getFile().getAbsolutePath());
                Path newFile = Paths.get(sourceFile.getAbsolutePath());
                FileUtils.writeStringToFile(getResource().getFile(), writeToHeader(responseToWrite.get(0)), StandardCharsets.UTF_8, true);

                List<MarketingRequest> sortedList = responseToWrite.stream().sorted(Comparator.comparing(MarketingRequest::getRequestID))
                        .collect(Collectors.toList());

                for (MarketingRequest marketingRequest : sortedList) {
                    AoCronosEliadeDto icubeDto = setMarketingRequestToIcubeDto(marketingRequest);

                    FileUtils.writeStringToFile(getResource().getFile(), icubeDto.toString(), StandardCharsets.UTF_8, true);
                    count++;
                    marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                    logger.info("RequestID:[{}] Old Status:[{}] New Status:[{}]", marketingRequest.getRequestID(),
                            MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(), marketingRequest.getStatus());
                    marketingRequestRepository.updateStatusByInternalRequestId(marketingRequest.getStatus(), marketingRequest.getInternalReqId());
                }

                FileUtils.writeStringToFile(getResource().getFile(), writeToFooter(count, responseToWrite.get(0)), StandardCharsets.UTF_8, true);
                logger.info("Removing the .part ");
                int lastIndex = sourceFile.getName().lastIndexOf('.');
                String newFileName = sourceFile.getName().substring(0, lastIndex) + MarketingDateUtil.getTodaysDateforCo2MinMax() + ".dat";
                Files.move(newFile, newFile.resolveSibling(newFileName));
                // fixed jira-625
                marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                        String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), responseToWrite.get(0).getFileId());
                String fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(responseToWrite.get(0).getFileId());
                if (fileConfigUtilService != null && fsFlagFileName != null) {
                    // Added below code as part of jira-660 fix -- start
                    MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "icube", fsFlagFileName);
                    int result = fsFlagFileService.deleteFsFlagFileByFileId(responseToWrite.get(0).getFileId());
                    if (result > 0) {
                        logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                    }
                    // jira-660 fix -- end
                }
            } catch (IOException e) {
                logger.error("ERROR: {}", e);
            }
        }
    }

    /**
     * Sets the marketing request to aogoes dto.
     *
     * @param marketingRequest the marketing request
     * @return the ao cronos eliade dto
     */
    private AoCronosEliadeDto setMarketingRequestToIcubeDto(MarketingRequest marketingRequest) {
        AoCronosEliadeDto icubeDto = new AoCronosEliadeDto();
        icubeDto.setMomentCode20("W020");
        icubeDto.setVehicleType("");
        if (marketingRequest.getVersion16() != null)
            icubeDto.setVersion16(marketingRequest.getVersion16());
        if (marketingRequest.getOptions() != null)
            icubeDto.setOptions(marketingRequest.getOptions());
        if (marketingRequest.getExtensionDate() != null)
            icubeDto.setExtensionDate(marketingRequest.getExtensionDate());
        if (marketingRequest.getBrand() != null)
            icubeDto.setBrand(marketingRequest.getBrand());
        if (marketingRequest.getColorExtInt() != null)
            icubeDto.setColorExtInt(marketingRequest.getColorExtInt());
        if (marketingRequest.getOptions7C() != null)
            icubeDto.setOptions7C(marketingRequest.getOptions7C());
        if (marketingRequest.getGestion7C() != null)
            icubeDto.setGestion7C(marketingRequest.getGestion7C());
        if (marketingRequest.getTradingCountry() != null)
            icubeDto.setTradingCountry(marketingRequest.getTradingCountry());
        if (marketingRequest.getAnswerCode() != null)
            icubeDto.setAnswerCode(marketingRequest.getAnswerCode());
        if (marketingRequest.getAnswerDesig() != null)
            icubeDto.setAnswerDesignation(marketingRequest.getAnswerDesig());
        // Jira Fix 287

        icubeDto.setPrd(setRejectedRequestPrd(marketingRequest.getRequestID()));
        logger.info("REJECTED REQUEST ID: [{}]", marketingRequest.getRequestID());
        icubeDto.setLotNumber(setRejectedRequestLotNumber(marketingRequest.getRequestID()));
        icubeDto.setLineNumber(setRejectedRequestLineNumber(marketingRequest.getRequestID()));
        return icubeDto;
    }

    /**
     * Sets the rejected request prd.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestPrd(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= THREE) {
                return reqId.substring(0, THREE);
            }
            return reqId.substring(0, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request lot number.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestLotNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= EIGHT) {
                return reqId.substring(THREE, EIGHT);
            }
            return reqId.substring(THREE, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request line number.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestLineNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= TWENTY) {
                return reqId.substring(EIGHT, TWENTY);
            }
            return reqId.substring(EIGHT, reqId.length());
        }
        return reqId;
    }

    /**
     * Write to header.
     *
     * @param marketingRequest the marketing request
     * @return the string
     */
    public String writeToHeader(MarketingRequest marketingRequest) {
        return AoCronoEliadeUtility.generateHeader(marketingRequest.getSendingSite(), marketingRequest.getSendingApplication(),
                marketingRequest.getLotNumber(), marketingRequest.getLotDate());

    }

    /**
     * Write to footer.
     *
     * @param count the count
     * @param marketingRequest the marketing request
     * @return the string
     */
    public String writeToFooter(int count, MarketingRequest marketingRequest) {
        String result = generateMovementCount(NUMBER_OF_MOVEMENTS, count);
        return AoCronoEliadeUtility.generateFooter(marketingRequest.getSendingSite(), marketingRequest.getSendingApplication(),
                marketingRequest.getLotNumber(), result);
    }

    /**
     * Generate movement count.
     *
     * @param noOfMovements the number of movements
     * @param count the count
     * @return the string
     */
    private String generateMovementCount(String noOfMovements, int count) {
        if (noOfMovements.length() >= Integer.toString(count).length()) {

            String movementCount = noOfMovements.substring(0, noOfMovements.length() - (Integer.toString(count).length()));

            return movementCount + count;
        }
        return noOfMovements;
    }

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public IcubeFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(IcubeFileResource resource) {
        this.resource = resource;
    }

    /**
     * Find duplicates.
     *
     * @param icubeDtoList the icube dto list
     * @return the sets the
     */
    private Set<IcubeRequestDTO> findDuplicates(List<IcubeRequestDTO> icubeDtoList) {
        Set<IcubeRequestDTO> duplicates = new LinkedHashSet<>();
        Set<IcubeRequestDTO> uniques = new HashSet<>();
        for (IcubeRequestDTO t : icubeDtoList) {
            if (!uniques.add(t)) {
                duplicates.add(t);
            }
        }
        return duplicates;
    }

}
