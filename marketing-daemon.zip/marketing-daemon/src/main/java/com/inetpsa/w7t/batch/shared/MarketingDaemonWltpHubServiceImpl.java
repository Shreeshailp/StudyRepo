/*
 * Creation : 5 Feb 2021
 */
package com.inetpsa.w7t.batch.shared;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.Base64;
import java.util.Optional;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.seedstack.seed.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.utilities.LogErrorUtility;
import com.inetpsa.w7t.wltphub.ws.WSAnswer;
import com.inetpsa.w7t.wltphub.ws.WSPhysicalResult;
import com.inetpsa.w7t.wltphub.ws.WltpHubRequest;
import com.inetpsa.w7t.wltphub.ws.WltpHubRequestRepresentation;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

public class MarketingDaemonWltpHubServiceImpl implements MarketingDaemonWltpHubService {

    /** The Constant TOO_MANY_REQUESTS. */
    private static final String TOO_MANY_REQUESTS = "429";

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The url. */
    @Configuration("wltphubWebService.url")
    private static String url;

    /** The username. */
    @Configuration("wltphubWebService.credentials.wltphub.username")
    private static String username;

    /** The password. */
    @Configuration("wltphubWebService.credentials.wltphub.password")
    private static String code;

    /** The timeout. */
    @Configuration("wltphubWebService.timeout")
    private static int timeout;

    /** The creds BASE 64. */
    private String credsBASE64;

    @Override
    public WltpHubResponseRepresentation callWltpHubWebService(AoCronosEliadeDto aoGeosDto) {
        WltpHubResponseRepresentation wltpHubResponseRepresentation = null;
        WltpHubRequest wltpHubRequest = null;
        try {

            if (this.credsBASE64 == null)
                credsBASE64 = Base64.getEncoder().encodeToString(String.format("%s:%s", username, code).getBytes());
            WltpHubRequestRepresentation wltpHubRequestRepresentation = new WltpHubRequestRepresentation();
            wltpHubRequest = new WltpHubRequest();

            wltpHubRequest.setRequestID(aoGeosDto.getRequestId());
            if (aoGeosDto.getAvoidCache()) {
                wltpHubRequest.setAvoidCache(aoGeosDto.getAvoidCache());
                logger.info("Request ID[{}]: AvoidCache: [{}]", wltpHubRequest.getRequestID(), wltpHubRequest.getAvoidCache());
            }
            wltpHubRequest.setVersion16C(aoGeosDto.getVersion16());
            wltpHubRequest.setColorExtInt(aoGeosDto.getColorExtInt());
            wltpHubRequest.setTradingCountry(aoGeosDto.getTradingCountry());
            wltpHubRequest.setRequestType(aoGeosDto.getRequestType());
            wltpHubRequest.setEcomDate("");
            wltpHubRequest.setNbOptions(aoGeosDto.getOptions());
            if (StringUtils.isNotBlank(aoGeosDto.getOptions5C())) {
                wltpHubRequest.setOptions5C(aoGeosDto.getOptions5C());
            } else
                wltpHubRequest.setOptions5C("");

            if (StringUtils.isNotBlank(aoGeosDto.getOptions7C())) {
                wltpHubRequest.setOptions7C(aoGeosDto.getOptions7C());
            } else
                wltpHubRequest.setOptions7C("");

            wltpHubRequest.setNbGestion("");
            wltpHubRequest.setGestion5C("");
            wltpHubRequest.setGestion7C("");
            wltpHubRequest.setExtendedTitleAttributes("");
            wltpHubRequest.setExtensionDate("");
            wltpHubRequest.setMountingCenter("");
            wltpHubRequest.setVin("");
            wltpHubRequest.setTvv("");

            wltpHubRequestRepresentation.setRequest(wltpHubRequest);
            HttpClient httpClient = HttpClientBuilder.create().build();
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(timeout).build();
            logger.info("Request ID[{}]: Calling HUB WebService on URL - {}", wltpHubRequest.getRequestID(), url);
            logger.info("Request ID[{}]: Request Sent To WltpHub is:[{}]", wltpHubRequest.getRequestID(), wltpHubRequestRepresentation);
            HttpPost postRequest = new HttpPost(url);
            postRequest.setConfig(requestConfig);
            postRequest.addHeader("Content-Type", "application/json");
            postRequest.addHeader("Authorization", "Basic " + credsBASE64);
            postRequest.setEntity(new StringEntity(new Gson().toJson(wltpHubRequestRepresentation)));
            HttpResponse response = httpClient.execute(postRequest);
            logger.info("Request ID[{}]: Hub Response code[{}]", wltpHubRequest.getRequestID(), response.getStatusLine().getStatusCode());
            BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
            String output;
            if (!String.valueOf(response.getStatusLine().getStatusCode()).equals(String.valueOf(HttpStatus.SC_OK))
                    && !String.valueOf(response.getStatusLine().getStatusCode()).equals(String.valueOf(HttpStatus.SC_BAD_REQUEST))
                    && !String.valueOf(response.getStatusLine().getStatusCode()).equals(TOO_MANY_REQUESTS)) {
                wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
                WSAnswer answer = new WSAnswer();
                answer.setCode(WltpRequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getRuleCode());
                answer.setDesignation(WltpRequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getDescription());
                wltpHubResponseRepresentation.setRequest(wltpHubRequest);
                wltpHubResponseRepresentation.setAnswer(answer);
            } else if (String.valueOf(response.getStatusLine().getStatusCode()).equals(TOO_MANY_REQUESTS)) {
                wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
                WSAnswer answer = new WSAnswer();
                answer.setCode(WltpRequestErrorCode.TOO_MANY_REQUESTS.getRuleCode());
                answer.setDesignation(WltpRequestErrorCode.TOO_MANY_REQUESTS.getDescription());
                wltpHubResponseRepresentation.setRequest(wltpHubRequest);
                wltpHubResponseRepresentation.setAnswer(answer);
            } else {
                StringBuilder answer = new StringBuilder();
                while ((output = br.readLine()) != null) {
                    answer.append(output);
                }
                wltpHubResponseRepresentation = new Gson().fromJson(answer.toString(), WltpHubResponseRepresentation.class);

                // Answer designation length issue fixed
                if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getAnswer()
                        && StringUtils.isNotBlank(wltpHubResponseRepresentation.getAnswer().getDesignation())
                        && wltpHubResponseRepresentation.getAnswer().getDesignation().length() > 50) {
                    wltpHubResponseRepresentation.getAnswer()
                            .setDesignation(wltpHubResponseRepresentation.getAnswer().getDesignation().substring(0, 50));
                }
            }
            logger.info("Request ID[{}]: Hub Web Service response : {}", wltpHubRequest.getRequestID(), wltpHubResponseRepresentation);
            if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getRequest()
                    && StringUtils.isNotBlank(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes())) {
                logger.info("Request ID[{}]: ExtendedTitle : {}", wltpHubRequest.getRequestID(),
                        wltpHubResponseRepresentation.getRequest().getVersion16C() + wltpHubResponseRepresentation.getRequest().getColorExtInt()
                                + wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
            }
            if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getPhysResult()) {
                Optional<WSPhysicalResult> optPhyResult = wltpHubResponseRepresentation.getPhysResult().parallelStream()
                        .filter(phyResult -> phyResult.getCode().equals(CalculationConstants.MATURITY)).findFirst();
                if (optPhyResult.isPresent()) {
                    logger.info("Request ID[{}]: Maturity : {}", wltpHubRequest.getRequestID(), optPhyResult.get().getValue());
                }

            }

        } catch (SocketTimeoutException e) {
            logger.error("Request ID[{}]: Error occurred in HUB web service is {}: {}", aoGeosDto.getRequestId(), e.getMessage(), e);
            LogErrorUtility.logTheError(logger, aoGeosDto.getRequestId(), WltpRequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode(),
                    WltpRequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription());
            wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
            WSAnswer answer = new WSAnswer();
            answer.setCode(WltpRequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getRuleCode());
            answer.setDesignation(WltpRequestErrorCode.WLTPHUB_TIMEOUT_EXCEPTION.getDescription());
            wltpHubResponseRepresentation.setRequest(wltpHubRequest);
            wltpHubResponseRepresentation.setAnswer(answer);
        } catch (Exception e) {
            logger.error("Request ID[{}]: Error occurred in HUB web service is {}: {}", aoGeosDto.getRequestId(), e.getMessage(), e);
            wltpHubResponseRepresentation = new WltpHubResponseRepresentation();
            WSAnswer answer = new WSAnswer();
            answer.setCode(WltpRequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getRuleCode());
            answer.setDesignation(WltpRequestErrorCode.UNKNOWN_TECHNICAL_EXCEPTION.getDescription());
            wltpHubResponseRepresentation.setRequest(wltpHubRequest);
            wltpHubResponseRepresentation.setAnswer(answer);
        }

        return wltpHubResponseRepresentation;
    }

}
