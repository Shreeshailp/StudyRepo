/*
 * Creation : 19 Mar 2021
 */
package com.inetpsa.w7t.batch.shared;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;

/**
 * The Interface MovementCode30Service.
 */
@Service
public interface MovementCode30Service {

    /**
     * Map W 30 data.
     *
     * @param dto the dto
     * @return the ao cronos eliade dto
     */
    AoCronosEliadeDto mapW30Data(AoCronosEliadeDto dto);
}
