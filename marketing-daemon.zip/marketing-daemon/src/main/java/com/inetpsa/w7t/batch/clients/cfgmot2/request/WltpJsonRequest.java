/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.inetpsa.w7t.batch.shared.JsonRequestErrorCodeConstant;
import com.inetpsa.w7t.batch.validations.AcceptedValues;
import com.inetpsa.w7t.batch.validations.JsonDateFormat;

/**
 * The Class WltpJsonRequest.
 *
 * @author E534811
 */
public class WltpJsonRequest implements Serializable {

    /** serialVersionUID. */
    private static final long serialVersionUID = 3246670474619406549L;

    /** The version 16 C. */
    @NotNull(message = JsonRequestErrorCodeConstant.VERSION_16C_INCORRECT)
    @Size(min = 16, max = 16, message = JsonRequestErrorCodeConstant.VERSION_16C_INCORRECT)
    private String version16C = "";

    /** The color ext int. */
    @NotNull(message = JsonRequestErrorCodeConstant.COLOR_EXT_INT_INCORRECT)
    @Size(min = 8, max = 8, message = JsonRequestErrorCodeConstant.COLOR_EXT_INT_INCORRECT)
    private String colorExtInt = "";

    /** The nb options. */
    @Pattern(regexp = "(?=(?:.{0,2})$)[0-9]*", message = JsonRequestErrorCodeConstant.NB_OPTIONS_INCORRECT)
    private String nbOptions;

    /** The options 5 C. */
    @Pattern(regexp = "(?:.{5})*", message = JsonRequestErrorCodeConstant.OPTIONS_5C_INCORRECT)
    private String options5C;

    /** The options 7 C. */
    @NotNull(message = JsonRequestErrorCodeConstant.OPTIONS_7C_INCORRECT)
    @Pattern(regexp = "(?:.{7})*", message = JsonRequestErrorCodeConstant.OPTIONS_7C_INCORRECT)
    private String options7C = "";

    /** The extension date. */
    @JsonDateFormat(message = JsonRequestErrorCodeConstant.EXTENSION_DATE_INCORRECT)
    private String extensionDate = "";

    /** The request type. */
    @NotNull(message = JsonRequestErrorCodeConstant.REQUEST_TYPE_INCORRECT)
    @AcceptedValues(acceptValues = { "FULL", "COMB" }, message = JsonRequestErrorCodeConstant.REQUEST_TYPE_INCORRECT)
    private String requestType = "";

    /** The trading country. */
    @NotNull(message = JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT)
    @Pattern(regexp = "(?=(?:.{0}|.{2})$)[0-9A-Z]*", message = JsonRequestErrorCodeConstant.COUNTRY_CODE_INCORRECT)
    private String tradingCountry = "";

    /** The status. */
    private String status;

    /** The is answer sent. */
    private boolean isAnswerSent = false;

    /** The answer date. */
    private String answerDate;

    /** The answer code. */
    private String answerCode;

    /** The answer desig. */
    private String answerDesig;

    /** The request id. */
    private String requestId;

    /** The maturity. */
    private String maturity;

    /**
     * Gets the maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Sets the maturity.
     *
     * @param maturity the new maturity
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Getter answerDate.
     *
     * @return the answerDate
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Setter answerDate.
     *
     * @param answerDate the answerDate to set
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Getter answerCode.
     *
     * @return the answerCode
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Setter answerCode.
     *
     * @param answerCode the answerCode to set
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Getter answerDesig.
     *
     * @return the answerDesig
     */
    public String getAnswerDesig() {
        return answerDesig;
    }

    /**
     * Setter answerDesig.
     *
     * @param answerDesig the answerDesig to set
     */
    public void setAnswerDesig(String answerDesig) {
        this.answerDesig = answerDesig;
    }

    /**
     * Gets the version 16 C.
     *
     * @return the version 16 C
     */
    public String getVersion16C() {
        return version16C;
    }

    /**
     * Sets the version 16 C.
     *
     * @param version16c the new version 16 C
     */
    public void setVersion16C(String version16c) {
        version16C = version16c;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the nb options.
     *
     * @return the nb options
     */
    public String getNbOptions() {
        return nbOptions;
    }

    /**
     * Sets the nb options.
     *
     * @param nbOptions the new nb options
     */
    public void setNbOptions(String nbOptions) {
        this.nbOptions = nbOptions;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options 7 C.
     *
     * @return the options 7 C
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options 7 C.
     *
     * @param options7c the new options 7 C
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Checks if is answer sent.
     *
     * @return true, if is answer sent
     */
    public boolean isAnswerSent() {
        return isAnswerSent;
    }

    /**
     * Sets the answer sent.
     *
     * @param isAnswerSent the new answer sent
     */
    public void setAnswerSent(boolean isAnswerSent) {
        this.isAnswerSent = isAnswerSent;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "[version16C=" + version16C + ", colorExtInt=" + colorExtInt + ", nbOptions=" + nbOptions + ", options5C=" + options5C + ", options7C="
                + options7C + ", extensionDate=" + extensionDate + ", requestType=" + requestType + ", tradingCountry=" + tradingCountry + ", status="
                + status + ", isAnswerSent=" + isAnswerSent + "]";
    }

    /**
     * Instantiates a new wltp json request.
     *
     * @param version16c the version 16 c
     * @param colorExtInt the color ext int
     * @param nbOptions the nb options
     * @param options5c the options 5 c
     * @param options7c the options 7 c
     * @param extensionDate the extension date
     * @param requestType the request type
     * @param tradingCountry the trading country
     * @param status the status
     * @param isAnswerSent the is answer sent
     */
    public WltpJsonRequest(String version16c, String colorExtInt, String nbOptions, String options5c, String options7c, String extensionDate,
            String requestType, String tradingCountry, String status, boolean isAnswerSent) {
        super();
        this.version16C = version16c;
        this.colorExtInt = colorExtInt;
        this.nbOptions = nbOptions;
        this.options5C = options5c;
        this.options7C = options7c;
        this.extensionDate = extensionDate;
        this.requestType = requestType;
        this.tradingCountry = tradingCountry;
        this.status = status;
        this.isAnswerSent = isAnswerSent;
    }

    /**
     * Instantiates a new wltp json request.
     */
    public WltpJsonRequest() {
    }

}
