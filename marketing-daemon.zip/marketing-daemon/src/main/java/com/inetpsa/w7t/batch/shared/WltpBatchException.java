/*
 * Creation : 18 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import org.seedstack.seed.SeedException;

/**
 * The Class WltpBatchException.
 */
public class WltpBatchException extends SeedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8632091435794213781L;

    /**
     * Instantiates a new wltp batch exception.
     *
     * @param errorCode the error code
     */
    public WltpBatchException(WltpRequestErrorCode errorCode) {
        super(errorCode);
    }

    /**
     * Gets the context mesage.
     *
     * @return the context mesage
     */
    public String getContextMesage() {
        return ((WltpRequestErrorCode) this.getErrorCode()).getDescription();
    }

    /**
     * Gets the context error code.
     *
     * @return the context error code
     */
    public String getContextErrorCode() {
        return ((WltpRequestErrorCode) this.getErrorCode()).getRuleCode();
    }
}
