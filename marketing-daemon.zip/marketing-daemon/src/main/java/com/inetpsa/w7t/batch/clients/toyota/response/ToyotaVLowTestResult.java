/*
 * Creation : 1 Nov 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ToyotaVLowTestResult.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "vlowPhaseResults" })
@XmlRootElement(name = "VLOW_TEST_RESULTS")
public class ToyotaVLowTestResult {

    /** The vlow phase results. */
    @XmlElement(name = "phase_result", required = true)
    protected List<ToyotaPhase> vlowPhaseResults;

    /**
     * Getter vlowPhaseResults.
     *
     * @return the vlowPhaseResults
     */
    public List<ToyotaPhase> getVlowPhaseResults() {
        return vlowPhaseResults;
    }

    /**
     * Setter vlowPhaseResults.
     *
     * @param vlowPhaseResults the vlowPhaseResults to set
     */
    public void setVlowPhaseResults(List<ToyotaPhase> vlowPhaseResults) {
        this.vlowPhaseResults = vlowPhaseResults;
    }

    /**
     * Instantiates a new toyota V low test result.
     */
    public ToyotaVLowTestResult() {
        super();
    }

}
