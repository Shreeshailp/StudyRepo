/*
 * Creation : 24 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class ToyotaXmlFileResource.
 *
 * @author E539598
 */
public class ToyotaXmlFileResource extends FileSystemResource {

    /**
     * Instantiates a new toyota xml file resource.
     *
     * @param path the path
     * @param outputFilename the output filename
     */
    public ToyotaXmlFileResource(String path, String outputFilename) {
        super(path + File.separator + outputFilename);
    }
}
