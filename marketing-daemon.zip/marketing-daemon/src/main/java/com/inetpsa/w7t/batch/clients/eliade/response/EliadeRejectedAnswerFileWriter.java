/*
 * Creation : 21 Apr 2020
 */
package com.inetpsa.w7t.batch.clients.eliade.response;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeUtility;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;

import edu.emory.mathcs.backport.java.util.concurrent.CopyOnWriteArrayList;

public class EliadeRejectedAnswerFileWriter implements ItemWriter<MarketingRequestTracker> {

    /** The resource. */
    private EliadeFlatFileResource resource;

    /** The number of movements. */
    private static final String NUMBER_OF_MOVEMENTS = "00000000"; // 8 char
    /** The Constant EIGHT. */
    private static final int EIGHT = 8;

    /** The Constant THREE. */
    private static final int THREE = 3;

    /** The Constant TWENTY. */
    private static final int TWENTY = 20;

    /** The formatter. */
    DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The response to write all. */
    @SuppressWarnings("unchecked")
    private List<MarketingRequest> responseToWriteAll = new CopyOnWriteArrayList();

    @Override
    public void write(List<? extends MarketingRequestTracker> items) throws Exception {
        if (items.get(0).getFileId() != null && !items.get(0).getFileId().isEmpty() && items.get(0).getClient() != null
                && !items.get(0).getClient().isEmpty()) {
            responseToWriteAll.addAll(marketingRequestRepository.getMarketingRequestsByFileId(items.get(0).getClient(), items.get(0).getFileId()));
        }
        logger.info("Thes count of records to be written in the list:{}==MRQ_Count:{}", responseToWriteAll.size(), items.get(0).getMrqCount());
        if (!responseToWriteAll.isEmpty() && responseToWriteAll.size() == items.get(0).getMrqCount()) {
            sendOnlyRejecedRequestFile(responseToWriteAll);
        }
    }

    private void sendOnlyRejecedRequestFile(List<MarketingRequest> responseToWrite) {
        int count = 0;

        try {
            Set<String> finalFileIds = new HashSet<>();
            finalFileIds.add(responseToWrite.get(0).getFileId());
            marketingRequestTrackerRepository.updateToMachineName_MRT(finalFileIds, fileConfigUtilService.getResMacName());
            File sourceFile = new File(getResource().getFile().getAbsolutePath());
            Path newFile = Paths.get(sourceFile.getAbsolutePath());
            FileUtils.writeStringToFile(getResource().getFile(), writeToHeader(responseToWrite.get(0)), StandardCharsets.UTF_8, true);

            List<MarketingRequest> sortedList = responseToWrite.stream().sorted(Comparator.comparing(MarketingRequest::getRequestID))
                    .collect(Collectors.toList());

            for (MarketingRequest marketingRequest : sortedList) {

                AoCronosEliadeDto eliadeDto = setDtoValuesBasedOnConditions(marketingRequest);
                // Jira Fix 287
                eliadeDto.setPrd(setRejectedRequestPrd(marketingRequest.getRequestID()));
                eliadeDto.setLotNumber(setRejectedRequestLotNumber(marketingRequest.getRequestID()));
                eliadeDto.setLineNumber(setRejectedRequestLineNumber(marketingRequest.getRequestID()));

                FileUtils.writeStringToFile(getResource().getFile(), eliadeDto.toString(), StandardCharsets.UTF_8, true);
                count++;
                marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                logger.info("RequestID:[{}] Old Status:[{}] New Status:[{}]", marketingRequest.getRequestID(),
                        MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(), marketingRequest.getStatus());
                marketingRequestRepository.updateStatusByInternalRequestId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                        marketingRequest.getInternalReqId());
            }

            FileUtils.writeStringToFile(getResource().getFile(), writeToFooter(count, responseToWrite.get(0)), StandardCharsets.UTF_8, true);
            logger.info("Removing the .part ");
            int lastIndex = sourceFile.getName().lastIndexOf('.');
            String newFileName = sourceFile.getName().substring(0, lastIndex);
            Files.move(newFile, newFile.resolveSibling(newFileName));
            // fixed jira-625
            marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                    responseToWrite.get(0).getFileId());
            String fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(responseToWrite.get(0).getFileId());
            if (fileConfigUtilService != null && fsFlagFileName != null) {
                // Added below code as part of jira-660 fix -- start
                MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "eliade", fsFlagFileName);
                int result = fsFlagFileService.deleteFsFlagFileByFileId(responseToWrite.get(0).getFileId());
                if (result > 0) {
                    logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                }
                // jira-660 fix -- end
            }
        } catch (IOException e) {
            logger.error("ERROR: {}", e);
        }
    }

    /**
     * Sets the dto values based on conditions.
     *
     * @param marketingRequest the marketing request
     * @return the ao cronos eliade dto
     */
    private AoCronosEliadeDto setDtoValuesBasedOnConditions(MarketingRequest marketingRequest) {
        AoCronosEliadeDto eliadeDto = new AoCronosEliadeDto();
        eliadeDto.setMomentCode20("W020");
        eliadeDto.setVehicleType("");
        if (marketingRequest.getVersion16() != null)
            eliadeDto.setVersion16(marketingRequest.getVersion16());
        if (marketingRequest.getOptions() != null)
            eliadeDto.setOptions(marketingRequest.getOptions());
        if (marketingRequest.getExtensionDate() != null)
            eliadeDto.setExtensionDate(marketingRequest.getExtensionDate());
        if (marketingRequest.getBrand() != null)
            eliadeDto.setBrand(marketingRequest.getBrand());
        if (marketingRequest.getColorExtInt() != null)
            eliadeDto.setColorExtInt(marketingRequest.getColorExtInt());
        if (marketingRequest.getOptions7C() != null)
            eliadeDto.setOptions7C(marketingRequest.getOptions7C());
        if (marketingRequest.getGestion7C() != null)
            eliadeDto.setGestion7C(marketingRequest.getGestion7C());
        if (marketingRequest.getTradingCountry() != null)
            eliadeDto.setTradingCountry(marketingRequest.getTradingCountry());
        if (marketingRequest.getAnswerCode() != null)
            eliadeDto.setAnswerCode(marketingRequest.getAnswerCode());
        if (marketingRequest.getAnswerDesig() != null)
            eliadeDto.setAnswerDesignation(marketingRequest.getAnswerDesig());
        return eliadeDto;
    }

    /**
     * Sets the rejected request prd.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestPrd(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= THREE) {
                return reqId.substring(0, THREE);
            }
            return reqId.substring(0, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request lot number.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestLotNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= EIGHT) {
                return reqId.substring(THREE, EIGHT);
            }
            return reqId.substring(THREE, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request line number.
     *
     * @param reqId the req id
     * @return the string
     */
    public String setRejectedRequestLineNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= TWENTY) {
                return reqId.substring(EIGHT, TWENTY);
            }
            return reqId.substring(EIGHT, reqId.length());
        }
        return reqId;
    }

    /**
     * Write to header.
     *
     * @param marketingRequest the marketing request
     * @return the string
     */
    public String writeToHeader(MarketingRequest marketingRequest) {
        return AoCronoEliadeUtility.generateHeader(marketingRequest.getSendingSite(), marketingRequest.getSendingApplication(),
                marketingRequest.getLotNumber(), marketingRequest.getLotDate());
    }

    /**
     * Write to footer.
     *
     * @param count            the count
     * @param marketingRequest the marketing request
     * @return the string
     */
    public String writeToFooter(int count, MarketingRequest marketingRequest) {
        String result = generateMovementCount(NUMBER_OF_MOVEMENTS, count);
        return AoCronoEliadeUtility.generateFooter(marketingRequest.getSendingSite(), marketingRequest.getSendingApplication(),
                marketingRequest.getLotNumber(), result);
    }

    /**
     * Generate movement count.
     *
     * @param numberOfMovement the number of movements
     * @param count            the count
     * @return the string
     */
    private String generateMovementCount(String numberOfMovement, int count) {
        if (numberOfMovement.length() >= Integer.toString(count).length()) {

            String movementCount = numberOfMovement.substring(0, numberOfMovement.length() - (Integer.toString(count).length()));

            return movementCount + count;
        }
        return numberOfMovement;
    }

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public EliadeFlatFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(EliadeFlatFileResource resource) {
        this.resource = resource;
    }

}
