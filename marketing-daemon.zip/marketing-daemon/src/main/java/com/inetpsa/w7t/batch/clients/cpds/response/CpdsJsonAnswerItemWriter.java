/*
 * Creation : 26 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

/**
 * The Class CpdsJsonAnswerItemWriter.
 */
public class CpdsJsonAnswerItemWriter implements ItemWriter<CpdsRequestsRepresentations> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends CpdsRequestsRepresentations> items) throws Exception {

    }

}
