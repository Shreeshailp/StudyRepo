/*
 * Creation : 27 avr. 2017
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.io.File;
import java.io.FileFilter;

import org.apache.commons.lang.StringUtils;

/**
 * The Class BPSFileFilter.
 */
public class WltpJsonFileFilter implements FileFilter {

    /** The file pattern. */
    private String filepattern;

    /**
     * Instantiates a new BPS file filter.
     *
     * @param extension the extension
     */
    public WltpJsonFileFilter(String extension) {
        this.filepattern = extension;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.io.FileFilter#accept(java.io.File)
     */
    @Override
    public boolean accept(File pathname) {
        return pathname.isFile() && StringUtils.containsIgnoreCase(pathname.getName(), filepattern) && pathname.getName().endsWith(".json");
    }

}
