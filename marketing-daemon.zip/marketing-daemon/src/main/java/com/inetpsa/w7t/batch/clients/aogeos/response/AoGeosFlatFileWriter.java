/*
 * Creation : 19 Oct 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.response;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeUtility;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository;

/**
 * The Class AoGeosFlatFileWriter.
 */
public class AoGeosFlatFileWriter implements ItemWriter<MarketingRequestAnswerDTO> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The number of movements. */
    private static final String NUMBER_OF_MOVEMENTS = "00000000"; // 8 char

    /** The MarketingDaemonCalculatorService. */
    @Inject
    private MarketingDaemonCalculatorService marketingDaemonCalculatorService;

    /** The final list to write in file. */
    private CopyOnWriteArrayList<AoCronosEliadeDto> finalListToWriteInFile = new CopyOnWriteArrayList<>();

    /** The final list to update status in MRQ. */
    private CopyOnWriteArrayList<MarketingRequest> finalListToUpdateStatusInMRQ = new CopyOnWriteArrayList<>();

    /** The records list. */
    private List<String> recordsList = new ArrayList<>();

    /** The total record count. */
    private volatile int totalRecordCount = 0;

    /** The record count. */
    private int recordCount = 0;

    /** The chunk size. */
    private int chunkSize = 500;

    /** MarketingRequestTrackerRepository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "aoGeosDatabaseToFlatFileJob";
    /** The resource. */
    AoGeosFileResource resource;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service. */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The avoid cache repository. */
    @Inject
    private AvoidCacheRepository avoidCacheRepository;

    /** The w 30 count. */
    private int w30Count = 0;

    // fix for big file issue
    /** The final list to update calculation status. */
    private CopyOnWriteArrayList<CalculationStatusDto> finalListToUpdateCalculationStatus = new CopyOnWriteArrayList<>();

    /** The thread pool log. */
    private static final String THREAD_POOL_LOG = "aoGeosDatabaseToFlatFileJob thread pool size : [{}]";

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public AoGeosFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(AoGeosFileResource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends MarketingRequestAnswerDTO> request) throws Exception {
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
        logger.debug(THREAD_POOL_LOG, threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        totalRecordCount = 0;
        recordCount = 0;
        int originalListCount = 0;
        int count = 0;
        String fsFlagFileName = null;
        boolean avoidCacheValue;
        AoCronosEliadeDto aoGeosHeaderFooterDto = null;
        List<AoCronosEliadeDto> aoGeosList = new CopyOnWriteArrayList<>(request.get(0).getAoCronoEliadeAnswerDto());
        if (!aoGeosList.isEmpty()) {
            avoidCacheValue = avoidCacheRepository.getAdcValueByClient(MarketingDaemonServiceConstants.AOGEOS.toUpperCase());
            List<AoCronosEliadeDto> newAogoesList = MarkertingDaemonUtility.getUniqueAoCronoEliadeList(aoGeosList);
            aoGeosHeaderFooterDto = newAogoesList.get(0);
            originalListCount = newAogoesList.size();
            logger.info("Total request count for calculation for the FILE ID [{}] is : [{}]", newAogoesList.get(0).getFileId(), originalListCount);
            try {
                logger.info("Parallel Processing Starts Here ...");

                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<AoCronosEliadeDto>> splitedList = ListUtils.partition(newAogoesList, chunkSize);

                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelList(list, avoidCacheValue));
                        futuresList.add(future);
                    });
                }
                for (Future<Integer> future : futuresList) {
                    future.get();
                }

            } catch (Exception e) {
                logger.debug("Error when executing parallel request processing for calcualtion", e);
            } finally {
                executorService.shutdown();
            }

            logger.info("Parallel Processing Ends Here ...");

            if (!finalListToWriteInFile.isEmpty()) {
                try {
                    logger.info("Calculated records count for the FILE ID [{}] is : [{}] and originoal count is : [{}]",
                            newAogoesList.get(0).getFileId(), totalRecordCount, originalListCount);
                    recordsList.add(writeToHeader(aoGeosHeaderFooterDto));
                    count = writeRecordsIntoFile(request.get(0).getAoCronoEliadeAnswerDto().get(0));

                    recordsList.add(writeToFooter(count, aoGeosHeaderFooterDto));
                    MarketingRequestTracker mrt = marketingRequestTrackerRepository.byFileId(aoGeosList.get(0).getFileId());
                    if (!recordsList.isEmpty() && null != mrt && recordsList.size() - w30Count - 2 == mrt.getMrqCount()) {
                        File sourceFile = new File(getResource().getFile().getAbsolutePath());
                        Path newFile = Paths.get(sourceFile.getAbsolutePath());

                        // added below method to fix big file issue
                        updateCalculationStatusInMRQ();

                        MarkertingDaemonUtility.writeIntoFile(sourceFile, recordsList);

                        updateFinalStatusInMRQ();

                        logger.info("Records written in the file for the FILE ID [{}] is : [{}]", newAogoesList.get(0).getFileId(), count);
                        logger.info("Removing the .part ");
                        int lastIndex = sourceFile.getName().lastIndexOf('.');
                        String newFileName = sourceFile.getName().substring(0, lastIndex);

                        Files.move(newFile, newFile.resolveSibling(newFileName));
                        marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                                String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                                request.get(0).getAoCronoEliadeAnswerDto().get(0).getFileId());

                        List<String> fileIds = marketingRequestTrackerRepository.get3DaysAnswerSentFileIds();
                        fileIds.forEach(fileId -> MarketingDaemonServiceUtils.resetAogeosHeader(fileId));

                        // Find FsFLagFileName by FileId
                        fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(newAogoesList.get(0).getFileId());
                        logger.info("FsFlagFileName: [{}]", fsFlagFileName);
                        if (fileConfigUtilService != null && fsFlagFileName != null) {
                            // Added below code as part of jira-660 fix -- start
                            MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "aoGeos", fsFlagFileName);
                            int result = fsFlagFileService.deleteFsFlagFileByFileId(newAogoesList.get(0).getFileId());
                            if (result > 0) {
                                logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                            }
                            // jira-660 fix -- end
                        }
                    }
                } catch (Exception e) {
                    logger.error("{} ", e);
                }
            } else {
                logger.info("Final List To Write In File is empty for FILE ID [{}]", aoGeosHeaderFooterDto.getFileId());
            }
        }
    }

    /**
     * Update calculation status in MRQ.
     */
    private void updateCalculationStatusInMRQ() {
        if (!finalListToUpdateCalculationStatus.isEmpty()) {
            Set<CalculationStatusDto> set = new HashSet<>(finalListToUpdateCalculationStatus);
            finalListToUpdateCalculationStatus.clear();
            finalListToUpdateCalculationStatus.addAll(set);
            int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
            logger.debug(THREAD_POOL_LOG, threadPoolSize);
            ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
            try {
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<CalculationStatusDto>> splitedList = ListUtils.partition(finalListToUpdateCalculationStatus, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateCalculationStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            } finally {
                executorService.shutdown();
            }

        }

    }

    /**
     * Process parallel list to update calculation status.
     *
     * @param marketingRequestList the marketing request list
     * @return the int
     */
    private int processParallelListToUpdateCalculationStatus(List<CalculationStatusDto> marketingRequestList) {
        marketingDaemonCalculatorService.updateStatusCalculationStatusInMRQ(marketingRequestList);
        return 1;
    }

    /**
     * Update final status in MRQ.
     */
    private void updateFinalStatusInMRQ() {

        if (!finalListToUpdateStatusInMRQ.isEmpty()) {

            int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
            logger.debug(THREAD_POOL_LOG, threadPoolSize);
            ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);

            try {

                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<MarketingRequest>> splitedList = ListUtils.partition(finalListToUpdateStatusInMRQ, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateStatus(list));
                        futuresList.add(future);
                    });
                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            } finally {
                executorService.shutdown();
            }

        }

    }

    /**
     * Process parallel list to update status.
     *
     * @param marketingRequestList the marketing request list
     * @return the int
     */
    private int processParallelListToUpdateStatus(List<MarketingRequest> marketingRequestList) {
        marketingDaemonCalculatorService.updateAnswerSentStatus(marketingRequestList);
        return 1;
    }

    /**
     * Process parallel list.
     *
     * @param list the list
     * @param avoidCacheValue the avoid cache value
     * @return the int
     */
    private int processParallelList(List<AoCronosEliadeDto> list, boolean avoidCacheValue) {
        AoCronosEliadeDto dto = null;
        for (AoCronosEliadeDto aoCronosEliadeDto : list) {
            aoCronosEliadeDto.setAvoidCache(avoidCacheValue);
            dto = process(aoCronosEliadeDto);
            if (dto != null) {
                AoCronosEliadeDto aogeosDto = dto;

                if (aogeosDto != null && (aogeosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()))
                        || aogeosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode())))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(aogeosDto.getFileId());
                    calculationStatusDto.setRequestId(aogeosDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(aogeosDto.getStatus());
                    calculationStatusDto.setAnswerDate(aogeosDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(aogeosDto.getAnswerCode());
                    calculationStatusDto.setAnswerDesignation(aogeosDto.getAnswerDesignation());
                    aogeosDto.setStatus(calculationStatusDto.getCurrentStatus());
                    aogeosDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    aogeosDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    aogeosDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);
                } else if (aogeosDto != null
                        && aogeosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(aogeosDto.getFileId());
                    calculationStatusDto.setRequestId(aogeosDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));
                    calculationStatusDto.setAnswerDate(aogeosDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_AOGEOS_CRONOS_ELIADE);
                    calculationStatusDto.setAnswerDesignation(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
                    calculationStatusDto.setAnswerDate(MarketingDateUtil.getTodaysDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);

                    aogeosDto.setStatus(calculationStatusDto.getCurrentStatus());
                    aogeosDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    aogeosDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    aogeosDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                }

                finalListToWriteInFile.add(aogeosDto);
                totalRecordCount++;
            }
        }

        return 1;
    }

    /**
     * Process.
     *
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the ao cronos eliade dto
     */
    private AoCronosEliadeDto process(AoCronosEliadeDto aoCronosEliadeDto) {
        AoCronosEliadeDto dto = null;
        try {
            dto = marketingDaemonCalculatorService.calculateAoGeosCronosEliade(aoCronosEliadeDto);
        } catch (Exception e) {
            logger.error("{}", e);
        }

        return dto;
    }

    /**
     * Write records into file.
     *
     * @param aogeosDto the aogeos dto
     * @return the int
     */
    private int writeRecordsIntoFile(AoCronosEliadeDto aogeosDto) {

        Set<AoGeosW30Dto> w30Set = new HashSet<>();
        List<AoCronosEliadeDto> rejectedRequestList = MarkertingDaemonUtility.getRejectedRequestList(marketingRequestRepository,
                MarketingDaemonServiceConstants.AOGEOS.toUpperCase(), String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()),
                true, aogeosDto.getFileId());
        if (rejectedRequestList != null && !rejectedRequestList.isEmpty()) {
            finalListToWriteInFile.addAll(rejectedRequestList);
        }

        List<AoCronosEliadeDto> sortedList = finalListToWriteInFile.stream().sorted(Comparator.comparing(AoCronosEliadeDto::getRequestId))
                .collect(Collectors.toList());

        sortedList.stream().forEach(aoGeosDto -> {
            MarketingRequest marketingRequest = new MarketingRequest();

            writeW20RecordsIntoFile(marketingRequest, w30Set, aoGeosDto);

            marketingRequest = null;
        });

        List<AoGeosW30Dto> w30List = convertToList(w30Set);
        this.w30Count = w30List.size();
        w30List.stream().forEach(aoGeosW30Dto -> {

            try {
                recordsList.add(aoGeosW30Dto.getW30Data());
            } catch (Exception e) {
                logger.error("{}", e);
            }

            recordCount++;
        });

        return recordCount;
    }

    /**
     * Write W 20 records into file.
     *
     * @param marketingRequest the marketing request
     * @param w30Set the w 30 set
     * @param aoGeosDto the ao geos dto
     */
    private void writeW20RecordsIntoFile(MarketingRequest marketingRequest, Set<AoGeosW30Dto> w30Set, AoCronosEliadeDto aoGeosDto) {

        if ((aoGeosDto.getvLow() != null && !aoGeosDto.getvLow().isEmpty()) && (aoGeosDto.getvHigh() != null && !aoGeosDto.getvHigh().isEmpty())) {
            AoGeosW30Dto aoGeosW30Dto = new AoGeosW30Dto(aoGeosDto.getFamily(), aoGeosDto.getCode(), aoGeosDto.writeW030());
            w30Set.add(aoGeosW30Dto);
        }

        if (!aoGeosDto.getAnswerCode().isEmpty() && (aoGeosDto.getAnswerCode().contains("ERR") || !aoGeosDto.getAnswerCode().startsWith("OK"))) {
            aoGeosDto.setVehicleType("");
            aoGeosDto.setValidityDate("");
        }

        try {
            recordsList.add(aoGeosDto.toString());
            recordCount++;

            marketingRequest.setRequestID(aoGeosDto.getRequestId());
            marketingRequest.setInternalReqId(aoGeosDto.getInternalRequestId());
            marketingRequest.setFileId(aoGeosDto.getFileId());
            finalListToUpdateStatusInMRQ.add(marketingRequest);
        } catch (Exception e) {
            logger.error("{}", e);

        }
    }

    /**
     * Write to header.
     *
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToHeader(AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        return AoCronoEliadeUtility.generateHeader(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), aoCronosEliadeDto.getLotDate());

    }

    /**
     * Write to footer.
     *
     * @param count the count
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToFooter(int count, AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        String result = generateMovementCount(NUMBER_OF_MOVEMENTS, count);
        return AoCronoEliadeUtility.generateFooter(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), result);
    }

    /**
     * Generate movement count.
     *
     * @param NUMBER_OF_MOVEMENTS the number of movements
     * @param count the count
     * @return the string
     */
    private String generateMovementCount(String NUMBER_OF_MOVEMENTS, int count) {
        if (NUMBER_OF_MOVEMENTS.length() >= Integer.toString(count).length()) {

            String movementCount = NUMBER_OF_MOVEMENTS.substring(0, NUMBER_OF_MOVEMENTS.length() - (Integer.toString(count).length()));

            return movementCount + count;
        }
        return NUMBER_OF_MOVEMENTS;
    }

    /**
     * Convert to list.
     *
     * @param <T> the generic type
     * @param set the set
     * @return the list
     */
    private static <T> List<T> convertToList(Set<T> set) {
        return set.stream().collect(Collectors.toList());
    }

}