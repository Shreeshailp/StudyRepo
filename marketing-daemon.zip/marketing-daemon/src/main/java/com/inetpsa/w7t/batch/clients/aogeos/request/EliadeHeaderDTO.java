/*
 * Creation : 23 Sep 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

/**
 * The Class EliadeHeaderDTO.
 *
 * @author E534811
 */
public class EliadeHeaderDTO {

    /** The sending site. */
    private String sendingSite;

    /** The sending application. */
    private String sendingApplication;

    /** The batch number. */
    private String batchNumber;

    /** The batch creation date. */
    private String batchCreationDate;

    /**
     * Gets the sending site.
     *
     * @return the sending site
     */
    public String getSendingSite() {
        return sendingSite;
    }

    /**
     * Sets the sending site.
     *
     * @param sendingSite the new sending site
     */
    public void setSendingSite(String sendingSite) {
        this.sendingSite = sendingSite;
    }

    /**
     * Gets the sending application.
     *
     * @return the sending application
     */
    public String getSendingApplication() {
        return sendingApplication;
    }

    /**
     * Sets the sending application.
     *
     * @param sendingApplication the new sending application
     */
    public void setSendingApplication(String sendingApplication) {
        this.sendingApplication = sendingApplication;
    }

    /**
     * Gets the batch number.
     *
     * @return the batch number
     */
    public String getBatchNumber() {
        return batchNumber;
    }

    /**
     * Sets the batch number.
     *
     * @param batchNumber the new batch number
     */
    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    /**
     * Gets the batch creation date.
     *
     * @return the batch creation date
     */
    public String getBatchCreationDate() {
        return batchCreationDate;
    }

    /**
     * Sets the batch creation date.
     *
     * @param batchCreationDate the new batch creation date
     */
    public void setBatchCreationDate(String batchCreationDate) {
        this.batchCreationDate = batchCreationDate;
    }

}
