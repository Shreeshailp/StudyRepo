/*
 * Creation : 17 Oct 2018
 */
package com.inetpsa.w7t.batch.infrastructure;

import java.util.List;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

/**
 * The Interface VlowVHighCombinedResultFinder.
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface VlowVHighCombinedResultFinder {

    /**
     * Gets the comb values.
     *
     * @param co2 the co 2
     * @param comb the comb
     * @param code the code
     * @param index the index
     * @return the comb values
     */
    String getCombValues(String co2, String comb, String code, String index);

    /**
     * Gets the comb values by code and index.
     *
     * @param code the code
     * @param index the index
     * @return the comb values by code and index
     */
    List<String[]> getCombValuesByCodeAndIndex(String code, String index);
}
