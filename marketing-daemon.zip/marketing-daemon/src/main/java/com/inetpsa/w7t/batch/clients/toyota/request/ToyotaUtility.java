/*
 * Creation : 25 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.request;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.ToyotaRequestStatusEnum;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.ToyotaFileRequestLstXML;
import com.inetpsa.w7t.domain.model.ToyotaFileRequestXML;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * Utility Singleton Class.
 *
 * @author E534812
 */
public final class ToyotaUtility {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(ToyotaUtility.class);

    /** The Constant STATUS_CHANGE_LOG. */
    private static final String STATUS_CHANGE_LOG = "Marketing Toyota Request number =[{}], Old status=[{}], New status=[{}]";

    /** The Constant TOYOTA_UTILITY_ERR. */
    public static final String TOYOTA_UTILITY_ERR = "{} : Marketing toyota {} at line : {} . Failed record from file : {}";

    /** The Constant DATE_FORMAT. */
    private static final String DATE_FORMAT = "yyyy-MM-dd-HH-mm-ss";

    /**
     * Private constructor of sinleton class.
     */
    private ToyotaUtility() {
    }

    private static class BillPughSingleton {
        private static final ToyotaUtility INSTANCE = new ToyotaUtility();
    }

    /**
     * Factory method of singleton class.
     *
     * @return single instance of ToyotaUtility
     */
    public static ToyotaUtility getInstance() {

        return BillPughSingleton.INSTANCE;
    }

    /**
     * Return Option7c.
     *
     * @param item the item
     * @return the option 7 c
     */
    public String getOption7c(ToyotaFileRequestLstXML item) {
        StringBuilder options7c = new StringBuilder();
        options7c.append(item.getPatt1());
        options7c.append(item.getPatt2());
        options7c.append(item.getPatt3());
        options7c.append(item.getPatt4());
        options7c.append(item.getPatt5());
        options7c.append(item.getPatt6());
        options7c.append(item.getPatt7());
        options7c.append(item.getPatt8());
        options7c.append(item.getPatt9());
        options7c.append(item.getPatt10());

        options7c.append(item.getPatt11());
        options7c.append(item.getPatt12());
        options7c.append(item.getPatt13());
        options7c.append(item.getPatt14());
        options7c.append(item.getPatt15());
        options7c.append(item.getPatt16());
        options7c.append(item.getPatt17());
        options7c.append(item.getPatt18());
        options7c.append(item.getPatt19());
        options7c.append(item.getPatt20());

        options7c.append(item.getPatt21());
        options7c.append(item.getPatt22());
        options7c.append(item.getPatt23());
        options7c.append(item.getPatt24());
        options7c.append(item.getPatt25());
        options7c.append(item.getPatt26());
        options7c.append(item.getPatt27());
        options7c.append(item.getPatt28());
        options7c.append(item.getPatt29());
        options7c.append(item.getPatt30());

        options7c.append(item.getPatt31());
        options7c.append(item.getPatt32());
        options7c.append(item.getPatt33());
        options7c.append(item.getPatt34());
        options7c.append(item.getPatt35());
        options7c.append(item.getPatt36());
        options7c.append(item.getPatt37());
        options7c.append(item.getPatt38());
        options7c.append(item.getPatt39());
        options7c.append(item.getPatt40());

        return options7c.toString();
    }

    /**
     * Check File Id and Request Date is not null or empty.
     *
     * @param fileId the file id
     * @param requestDate the request date
     * @param lineNumber the line number
     * @param items the items
     * @return true, if successful
     */
    public boolean checkParentRootValidation(String fileId, String requestDate, int lineNumber, ToyotaFileRequestXML items) {

        if (fileId == null || fileId.isEmpty()) {
            logger.error("{} : Marketing toyota {} at line : {}. Failed record from file : {}", WltpRequestErrorCode.FILE_ID_BLANK_NULL.getRuleCode(),
                    WltpRequestErrorCode.FILE_ID_BLANK_NULL.getDescription(), lineNumber, items);
            LogUtility.logTheError(logger, WltpRequestErrorCode.FILE_ID_BLANK_NULL.getRuleCode(),
                    WltpRequestErrorCode.FILE_ID_BLANK_NULL.getDescription());
            return false;
        } else if (requestDate == null || requestDate.isEmpty() || !requestDate.matches("([0-9]{4})-([0-9]{2})-([0-9]{2})")) {
            logger.error("ERRW : Marketing toyota request date blank, missing or incorrect at line : {}. Failed record from file : {}", lineNumber,
                    items);
            return false;
        }
        return true;
    }

    /**
     * This method createMarketingRequest from xml file each request.
     *
     * @param item the item
     * @param lineNumber the line number
     * @param commonFileId the common file id
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @return the marketing request
     * @throws ParseException the parse exception
     */
    public MarketingRequest createMarketingRequest(ToyotaFileRequestLstXML item, int lineNumber, String commonFileId,
            MaturityRepository maturityRepository, ClientMaturityRepository clientMaturityRepository) throws ParseException {

        String number = item.getNumber();
        MarketingRequest mrq = new MarketingRequest();

        if (validateInputValue(mrq, item, lineNumber, maturityRepository, clientMaturityRepository)) {
            mrq.setStatus(ToyotaRequestStatusEnum.VALID_REQUEST.getStatusCode());
            logger.info(STATUS_CHANGE_LOG, item.getNumber(), ToyotaRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                    ToyotaRequestStatusEnum.VALID_REQUEST.getStatusCode());
        } else {
            mrq.setStatus(ToyotaRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
            logger.info(STATUS_CHANGE_LOG, item.getNumber(), ToyotaRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                    ToyotaRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
        }

        mrq.setRequestID(number.trim());
        mrq.setFileId(commonFileId);
        mrq.setRequestDate(MarketingDateUtil.getTodaysDate());
        mrq.setAnswerSent(false);
        mrq.setClient(MarketingDaemonServiceConstants.TOYOTA.toUpperCase());
        mrq.setBrand("");
        mrq.setGestion("");
        mrq.setGestion5C("");
        mrq.setGestion7C("");
        mrq.setMountingCenter("");
        return mrq;
    }

    /**
     * This method is use for validate use input value.
     *
     * @param mrq the mrq
     * @param item the item
     * @param lineNumber the line number
     * @param maturityRepository the maturity repository
     * @param clientMaturityRepository the client maturity repository
     * @return true, if successful
     * @throws ParseException the parse exception
     */
    public boolean validateInputValue(MarketingRequest mrq, ToyotaFileRequestLstXML item, int lineNumber, MaturityRepository maturityRepository,
            ClientMaturityRepository clientMaturityRepository) throws ParseException {
        String country = item.getCountry();
        String extentionDate = item.getExtensionDate();
        String requestType = item.getRequestType();
        String lcdv24 = item.getVersionAndColor();
        boolean result = true;
        // CR-648
        MaturityCheckUtility.insertUnknownPattern(logger, item.getVersionAndColor().substring(0, 16),
                MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), maturityRepository);

        if (!validateCountry(mrq, country, item, lineNumber))
            result = false;
        if (!validateRequestType(mrq, requestType, item, lineNumber))
            result = false;
        if (!validateLcdv24(mrq, lcdv24, item, lineNumber))
            result = false;
        if (!validateExtentionDate(mrq, extentionDate, item, lineNumber))
            result = false;
        if (!validateOption7(mrq, item, lineNumber))
            result = false;

        return result;

    }

    /**
     * Validate option 7.
     *
     * @param mrq the mrq
     * @param item the item
     * @param lineNumber the line number
     * @return true, if successful
     */
    private boolean validateOption7(MarketingRequest mrq, ToyotaFileRequestLstXML item, int lineNumber) {
        boolean validRecord = true;

        StringBuilder options7c = new StringBuilder();

        if (!validPatternOneToTen(item, options7c) || !validPatternElevenToTwenty(item, options7c) || !validPatternTwentyOneToThirty(item, options7c)
                || !validPatternThirtyOneToFourty(item, options7c)) {
            logger.error(TOYOTA_UTILITY_ERR, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, mrq.getRequestID(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
            mrq.setAnswerCode(WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode());
            mrq.setAnswerDesig(WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
            mrq.setAnswerDate(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
            validRecord = false;
        }

        mrq.setOptions7C(options7c.toString());
        if (options7c.toString() != null && !options7c.toString().isEmpty()) {
            mrq.setOptions(String.valueOf(options7c.length() / 7));
        } else {
            mrq.setOptions("");
        }

        return validRecord;
    }

    private boolean validPatternThirtyOneToFourty(ToyotaFileRequestLstXML item, StringBuilder options7c) {
        boolean validRecord = true;
        if (!isPatternLengthSeven(item.getPatt31(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt32(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt33(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt34(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt35(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt36(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt37(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt38(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt39(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt40(), options7c))
            validRecord = false;
        return validRecord;
    }

    private boolean validPatternTwentyOneToThirty(ToyotaFileRequestLstXML item, StringBuilder options7c) {
        boolean validRecord = true;
        if (!isPatternLengthSeven(item.getPatt21(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt22(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt23(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt24(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt25(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt26(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt27(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt28(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt29(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt30(), options7c))
            validRecord = false;
        return validRecord;
    }

    private boolean validPatternElevenToTwenty(ToyotaFileRequestLstXML item, StringBuilder options7c) {
        boolean validRecord = true;
        if (!isPatternLengthSeven(item.getPatt11(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt12(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt13(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt14(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt15(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt16(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt17(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt18(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt19(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt20(), options7c))
            validRecord = false;
        return validRecord;
    }

    private boolean validPatternOneToTen(ToyotaFileRequestLstXML item, StringBuilder options7c) {
        boolean validRecord = true;
        if (!isPatternLengthSeven(item.getPatt1(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt2(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt3(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt4(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt5(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt6(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt7(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt8(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt9(), options7c))
            validRecord = false;
        if (!isPatternLengthSeven(item.getPatt10(), options7c))
            validRecord = false;
        return validRecord;
    }

    /**
     * Checks if is pattern length seven.
     *
     * @param str the str
     * @param options7c the options 7 c
     * @return true, if is pattern length seven
     */
    boolean isPatternLengthSeven(String str, StringBuilder options7c) {
        if (str != null && !str.isEmpty() && str.length() == 7) {
            options7c.append(str);
            return true;
        } else if (str == null || str.isEmpty()) {
            return true;
        }
        options7c.append(str);
        return false;
    }

    /**
     * validateExtentionDate.
     *
     * @param mrq the mrq
     * @param extentionDate the extention date
     * @param item the item
     * @param lineNumber the line number
     * @return true, if successful
     * @throws ParseException the parse exception
     */
    private boolean validateExtentionDate(MarketingRequest mrq, String extentionDate, ToyotaFileRequestLstXML item, int lineNumber)
            throws ParseException {
        boolean validRecord = true;
        if (!extentionDate.isEmpty() && !extentionDate.matches("([0-9]{4})-([0-9]{2})-([0-9]{2})")) {
            logger.error(TOYOTA_UTILITY_ERR, WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, mrq.getRequestID(), WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                    WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
            mrq.setExtensionDate(null);
            mrq.setAnswerCode(WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode());
            mrq.setAnswerDesig(WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
            mrq.setAnswerDate(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
            validRecord = false;
        } else {
            if (!extentionDate.isEmpty()) {
                mrq.setExtensionDate(extentionDate);
            } else {
                mrq.setExtensionDate(null);
            }
        }
        return validRecord;
    }

    /**
     * validateLcdv24.
     *
     * @param mrq the mrq
     * @param lcdv24 the lcdv 24
     * @param item the item
     * @param lineNumber the line number
     * @return true, if successful
     */
    private boolean validateLcdv24(MarketingRequest mrq, String lcdv24, ToyotaFileRequestLstXML item, int lineNumber) {
        boolean validRecord = true;
        if (lcdv24 == null || lcdv24.isEmpty() || lcdv24.length() != 24) {
            logger.error(TOYOTA_UTILITY_ERR, WltpRequestErrorCode.INCORRECT_LCDV24.getRuleCode(),
                    WltpRequestErrorCode.INCORRECT_LCDV24.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, mrq.getRequestID(), WltpRequestErrorCode.INCORRECT_LCDV24.getRuleCode(),
                    WltpRequestErrorCode.INCORRECT_LCDV24.getDescription());
            mrq.setVersion16("");
            mrq.setColorExtInt("");
            mrq.setAnswerCode(WltpRequestErrorCode.INCORRECT_LCDV24.getRuleCode());
            mrq.setAnswerDesig(WltpRequestErrorCode.INCORRECT_LCDV24.getDescription());
            mrq.setAnswerDate(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
            validRecord = false;
        } else {
            mrq.setVersion16(lcdv24.substring(0, 16));
            mrq.setColorExtInt(lcdv24.substring(16, 24));
        }
        return validRecord;
    }

    /**
     * validateRequestType.
     *
     * @param mrq the mrq
     * @param requestType the request type
     * @param item the item
     * @param lineNumber the line number
     * @return true, if successful
     */
    private boolean validateRequestType(MarketingRequest mrq, String requestType, ToyotaFileRequestLstXML item, int lineNumber) {
        boolean validRecord = true;
        if (requestType == null || requestType.isEmpty() || !(requestType.equals(ToyotaRequestStatusEnum.REQUEST_TYPE_FULL.getStatusCode())
                || requestType.equals(ToyotaRequestStatusEnum.REQUEST_TYPE_COMB.getStatusCode()))) {
            logger.error(TOYOTA_UTILITY_ERR, WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getRuleCode(),
                    WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, mrq.getRequestID(), WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getRuleCode(),
                    WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getDescription());
            mrq.setRequestType("");
            mrq.setAnswerCode(WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getRuleCode());
            mrq.setAnswerDesig(WltpRequestErrorCode.UNKONWN_REQUEST_TYPE.getDescription());
            mrq.setAnswerDate(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
            validRecord = false;
        } else {
            mrq.setRequestType(requestType);
        }
        return validRecord;
    }

    /**
     * validateCountry.
     *
     * @param mrq the mrq
     * @param country the country
     * @param item the item
     * @param lineNumber the line number
     * @return true, if successful
     */
    private boolean validateCountry(MarketingRequest mrq, String country, ToyotaFileRequestLstXML item, int lineNumber) {
        boolean validRecord = true;
        if (country == null || country.isEmpty() || country.length() != 2) {
            logger.error(TOYOTA_UTILITY_ERR, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                    WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, mrq.getRequestID(), WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                    WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
            mrq.setTradingCountry("");
            mrq.setAnswerCode(WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode());
            mrq.setAnswerDesig(WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
            mrq.setAnswerDate(new SimpleDateFormat(DATE_FORMAT).format(new Date()));
            validRecord = false;
        } else {
            mrq.setTradingCountry(country);
        }
        return validRecord;
    }

}
