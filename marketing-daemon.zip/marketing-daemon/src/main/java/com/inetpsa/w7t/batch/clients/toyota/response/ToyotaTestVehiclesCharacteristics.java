/*
 * Creation : 9 Nov 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ToyotaTestVehiclesCharacteristics.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVLowPhysicalResult", "toyotaVMediumPhysicalResult", "toyotaVHighPhysicalResult",
        "toyotaVRefPhysicalResult" })
@XmlRootElement(name = "TEST_VEHICLE_CHARACTERISTICS")
public class ToyotaTestVehiclesCharacteristics {
    /** The toyota V low physical result. */
    @XmlElement(name = "VLOW", required = true)
    protected ToyotaVLowPhysicalResult toyotaVLowPhysicalResult;

    /** The toyota V medium physical result. */
    @XmlElement(name = "VMED", required = true)
    protected ToyotaVMediumPhysicalResult toyotaVMediumPhysicalResult;

    /** The toyota V high physical result. */
    @XmlElement(name = "VHIGH", required = true)
    protected ToyotaVHighPhysicalResult toyotaVHighPhysicalResult;

    /** The toyota V ref physical result. */
    @XmlElement(name = "VREF", required = true)
    protected ToyotaVRefPhysicalResult toyotaVRefPhysicalResult;

    /**
     * Getter toyotaVLowPhysicalResult.
     *
     * @return the toyotaVLowPhysicalResult
     */
    public ToyotaVLowPhysicalResult getToyotaVLowPhysicalResult() {
        return toyotaVLowPhysicalResult;
    }

    /**
     * Setter toyotaVLowPhysicalResult.
     *
     * @param toyotaVLowPhysicalResult the toyotaVLowPhysicalResult to set
     */
    public void setToyotaVLowPhysicalResult(ToyotaVLowPhysicalResult toyotaVLowPhysicalResult) {
        this.toyotaVLowPhysicalResult = toyotaVLowPhysicalResult;
    }

    /**
     * Getter toyotaVMediumPhysicalResult.
     *
     * @return the toyotaVMediumPhysicalResult
     */
    public ToyotaVMediumPhysicalResult getToyotaVMediumPhysicalResult() {
        return toyotaVMediumPhysicalResult;
    }

    /**
     * Setter toyotaVMediumPhysicalResult.
     *
     * @param toyotaVMediumPhysicalResult the toyotaVMediumPhysicalResult to set
     */
    public void setToyotaVMediumPhysicalResult(ToyotaVMediumPhysicalResult toyotaVMediumPhysicalResult) {
        this.toyotaVMediumPhysicalResult = toyotaVMediumPhysicalResult;
    }

    /**
     * Getter toyotaVHighPhysicalResult.
     *
     * @return the toyotaVHighPhysicalResult
     */
    public ToyotaVHighPhysicalResult getToyotaVHighPhysicalResult() {
        return toyotaVHighPhysicalResult;
    }

    /**
     * Setter toyotaVHighPhysicalResult.
     *
     * @param toyotaVHighPhysicalResult the toyotaVHighPhysicalResult to set
     */
    public void setToyotaVHighPhysicalResult(ToyotaVHighPhysicalResult toyotaVHighPhysicalResult) {
        this.toyotaVHighPhysicalResult = toyotaVHighPhysicalResult;
    }

    /**
     * Getter toyotaVRefPhysicalResult.
     *
     * @return the toyotaVRefPhysicalResult
     */
    public ToyotaVRefPhysicalResult getToyotaVRefPhysicalResult() {
        return toyotaVRefPhysicalResult;
    }

    /**
     * Setter toyotaVRefPhysicalResult.
     *
     * @param toyotaVRefPhysicalResult the toyotaVRefPhysicalResult to set
     */
    public void setToyotaVRefPhysicalResult(ToyotaVRefPhysicalResult toyotaVRefPhysicalResult) {
        this.toyotaVRefPhysicalResult = toyotaVRefPhysicalResult;
    }

}
