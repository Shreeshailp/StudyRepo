/*
 * Creation : 13 avr. 2017
 */
package com.inetpsa.w7t.batch.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.input.BOMInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class MarketingDaemonBatchUtils.
 */
public final class MarketingDaemonBatchUtils {

    /** The log. */
    private static Logger log = LoggerFactory.getLogger(MarketingDaemonBatchUtils.class.getName());

    /** The Constant FILE_FORMAT_DATE. */
    private static final String FILE_FORMAT_DATE = "yyyy-MM-dd-HH-mm-ss";

    /** The Constant DATABASE_TS_FORMAT. */
    public static final String DATABASE_TS_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /** The Constant DATABASE_DATE_FORMAT. */
    public static final String DATABASE_DATE_FORMAT = "yyyy-MM-dd";

    /** The Constant COMPLETED_DIR. */
    public static final String COMPLETED_DIR = "processed";

    /** The Constant PROCESSING_DIR. */
    public static final String PROCESSING_DIR = "processing";

    /** The Constant ERROR_DIR. */
    private static final String ERROR_DIR = "error";

    /** The Constant HISTORY_DIR. */
    private static final String HISTORY_DIR = "history";

    /** The count. */
    private static int count;

    /**
     * Instantiates a new batch utils.
     */
    private MarketingDaemonBatchUtils() {
        // For Sonar
    }

    /**
     * Gets the file format date.
     *
     * @param inDate the in date
     * @return the file format date
     */
    public static String getFileFormatDate(java.util.Date inDate) {
        SimpleDateFormat sdf = new SimpleDateFormat(FILE_FORMAT_DATE);
        return sdf.format(inDate);
    }

    /**
     * Gets the file format date.
     *
     * @return the file format date
     */
    public static String getFileFormatLocalDate() {
        return DateTimeFormatter.ofPattern(FILE_FORMAT_DATE, Locale.ENGLISH).format(LocalDateTime.now());
    }

    /**
     * Gets the database timestamp.
     *
     * @param input the input
     * @return the database timestamp
     */
    public static Timestamp getDatabaseTimestamp(Object input) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATABASE_TS_FORMAT);
        try {
            return new Timestamp(sdf.parse(input.toString()).getTime());
        } catch (ParseException e) {
            log.error("Parse Error", e);
        }
        return null;
    }

    /**
     * Gets the database date.
     *
     * @param input the input
     * @return the database date
     */
    public static Date getDatabaseDate(Object input) {

        SimpleDateFormat sdf = new SimpleDateFormat(DATABASE_DATE_FORMAT);
        try {
            return new java.sql.Date(sdf.parse(input.toString()).getTime());
        } catch (ParseException e) {
            log.error("Parse Error", e);
        }
        return null;
    }

    /**
     * Gets the date from file.
     *
     * @param strdate the strdate
     * @return the date from file
     * @throws ParseException the parse exception
     */
    public static java.util.Date getDateFromFile(String strdate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(FILE_FORMAT_DATE);
        return sdf.parse(strdate);
    }

    /**
     * Gets the decimal format.
     *
     * @param input the input
     * @return the decimal format
     */
    public static Double getDecimalFormat(String input) {
        return new Double(input.replace(",", "."));
    }

    /**
     * Move file to error.
     *
     * @param filepath the filepath
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void moveFileToError(String filepath) throws IOException {
        File infile = FileUtils.getFile(filepath);
        if (infile != null && infile.isFile()) {
            log.error("Moving file to error ({}) ", filepath);
            StringBuilder destFilePath = new StringBuilder(infile.getParentFile().getParent()).append(File.separator).append(ERROR_DIR)
                    .append(File.separator).append(infile.getName());
            File destfile = new File(destFilePath.toString());
            FileUtils.moveFile(infile, destfile);
        }
    }

    /**
     * Move processed file.
     *
     * @param filepath the filepath
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void moveProcessedFile(String filepath) throws IOException {
        File infile = FileUtils.getFile(filepath);
        if (infile != null && infile.isFile()) {
            StringBuilder destFilePath = new StringBuilder(infile.getParentFile().getParent()).append(File.separator).append(COMPLETED_DIR)
                    .append(File.separator).append(infile.getName());
            File destfile = new File(destFilePath.toString());
            FileUtils.moveFile(infile, destfile);
        } else {
            throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to move file to processed folder");
        }
    }

    /**
     * Delete splitted files from prcessing.
     *
     * @param filepath the filepath
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void deleteSplittedFilesFromPrcessing(String filepath) throws IOException {
        File infile = FileUtils.getFile(filepath);
        if (infile != null && infile.isFile()) {
            StringBuilder destFilePath = new StringBuilder(infile.getParentFile().getParent()).append(File.separator).append(PROCESSING_DIR)
                    .append(File.separator).append(infile.getName());
            File destfile = new File(destFilePath.toString());
            FileUtils.forceDelete(destfile);
        } else {
            throw new FileNotFoundException(
                    "File path is invalid. Either null or not a file location. Failed to delete file from  processing folder");
        }
    }

    /**
     * Move file to history.
     *
     * @param infile the infile
     * @return the file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static File moveFileToHistory(File infile) throws IOException {
        if (infile != null && infile.isFile()) {
            StringBuilder newName = new StringBuilder(String.valueOf(System.nanoTime())).append("_").append(infile.getName());
            StringBuilder destFilePath = new StringBuilder(infile.getParent()).append(File.separator).append(HISTORY_DIR).append(File.separator)
                    .append(newName);
            File destfile = new File(destFilePath.toString());
            FileUtils.moveFile(infile, destfile);
            return destfile;
        }
        throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to move file to history folder");
    }

    /**
     * Move file for processing.
     *
     * @param infile the infile
     * @return the file
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static File moveFileForProcessing(File infile) throws IOException {
        if (infile != null && infile.isFile()) {
            checkUTF8BOM(infile);
            StringBuilder newName = new StringBuilder(String.valueOf(System.nanoTime())).append("_").append(infile.getName());
            StringBuilder destFilePath = new StringBuilder(infile.getParent()).append(File.separator).append(PROCESSING_DIR).append(File.separator)
                    .append(newName);
            File destfile = new File(destFilePath.toString());
            FileUtils.moveFile(infile, destfile);
            return destfile;
        }
        throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to move file for processing");
    }

    /**
     * Check utf8 bom.
     *
     * @param infile the infile
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private static void checkUTF8BOM(File infile) throws IOException {
        try (InputStream inputStream = new FileInputStream(infile); BOMInputStream bOMInputStream = new BOMInputStream(inputStream)) {
            if (bOMInputStream.hasBOM()) {
                removeUTFBOM(infile, bOMInputStream);
            }
        }
    }

    /**
     * Removes the utf8 bom.
     *
     * @param infile         the infile
     * @param bOMInputStream the b om input stream
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private static void removeUTFBOM(File infile, BOMInputStream bOMInputStream) throws IOException {
        StringBuilder fileOut = new StringBuilder();
        try (InputStreamReader reader = new InputStreamReader(new BufferedInputStream(bOMInputStream), StandardCharsets.UTF_8.name());
                BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line = br.readLine()) != null) {
                fileOut.append(line);
            }
        }
        FileUtils.writeStringToFile(infile, fileOut.toString(), StandardCharsets.UTF_8);
    }

    /**
     * Creates the new file.
     *
     * @param filePath the file path
     * @param fileName the file name
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public static void createNewFile(String filePath, String fileName) throws IOException {
        if (filePath != null && fileName != null) {
            File dir = new File(filePath);
            Path newFilePath = Paths.get(filePath + File.separator + fileName + ".txt");
            File[] dirContents = dir.listFiles();
            if (dirContents != null && dirContents.length > 0) {
                for (File file : dirContents) {
                    if (file.getName().equalsIgnoreCase(fileName)) {
                        Path sameFilePath = Paths.get(filePath + File.separator + fileName + "_" + ++count + ".txt");
                        java.nio.file.Files.createFile(sameFilePath);
                        break;
                    }
                    Path notSameFilePath = Paths.get(filePath + File.separator + fileName + ".txt");
                    java.nio.file.Files.createFile(notSameFilePath);
                    break;
                }
            } else {
                java.nio.file.Files.createFile(newFilePath);
            }

        } else {
            throw new FileNotFoundException("File path is invalid. Either null or not a file location. Failed to create a file in the location "
                    + filePath + " with the file name " + fileName);
        }
    }

    /**
     * Delete application fs flag file.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param clientName     the client name
     */
    public static void deleteApplicationFsFlagFile(String fsFlagFilePath, String clientName) {
        if (fsFlagFilePath != null && !fsFlagFilePath.isEmpty()) {
            File dir = new File(fsFlagFilePath);
            File[] dirContents = dir.listFiles();
            // fix jira-595
            deleteFile(fsFlagFilePath, clientName, dirContents);
        }
    }

    /**
     * Delete file.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param clientName     the client name
     * @param dirContents    the dir contents
     */
    private static void deleteFile(String fsFlagFilePath, String clientName, File[] dirContents) {
        if (dirContents != null && dirContents.length > 0) {
            Arrays.sort(dirContents, Comparator.comparingLong(File::lastModified));
            for (File file : dirContents) {
                try {
                    if (file.getName().contains(clientName)) {
                        FileUtils.forceDelete(file);
                        log.info("Fs Flag File [{}] has been deleted from the location {}", file.getName(), fsFlagFilePath);
                        break;
                    }

                } catch (IOException e) {
                    log.error("Exception while deleting the file : {}", e.getMessage());
                }
            }
        }
    }

    // Added below method as part of jira-660 fix
    /**
     * Delete application fs flag file.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param clientName     the client name
     * @param fsFlagFileName the fs flag file name
     */
    public static void deleteApplicationFsFlagFile(String fsFlagFilePath, String clientName, String fsFlagFileName) {
        if (fsFlagFilePath != null && !fsFlagFilePath.isEmpty()) {
            File dir = new File(fsFlagFilePath);
            File[] dirContents = dir.listFiles();
            deleteFile(fsFlagFilePath, clientName, dirContents, fsFlagFileName);
        }
    }

    // Added below method as part of jira-660 fix
    /**
     * Delete File.
     *
     * @param fsFlagFilePath the fs flag file path
     * @param clientName     the client name
     * @param dirContents    the dir contents
     * @param fsFlagFileName the fs flag file name
     */
    private static void deleteFile(String fsFlagFilePath, String clientName, File[] dirContents, String fsFlagFileName) {
        if (dirContents != null && dirContents.length > 0) {
            for (File file : dirContents) {
                try {
                    if (file.getName().contains(fsFlagFileName)) {
                        FileUtils.forceDelete(file);
                        log.info("Fs Flag File [{}] has been deleted from the location {}", file.getName(), fsFlagFilePath);
                        break;
                    }

                } catch (IOException e) {
                    log.error("Exception while deleting the file : {}", e.getMessage());
                }
            }
        }
    }

}
