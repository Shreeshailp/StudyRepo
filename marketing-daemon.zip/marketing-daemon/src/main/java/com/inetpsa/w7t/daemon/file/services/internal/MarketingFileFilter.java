/*
 * Creation : 27 avr. 2017
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import java.io.File;
import java.io.FileFilter;

/**
 * The Class WLTPFileFilter.
 */
public class MarketingFileFilter implements FileFilter {

    /** The file pattern. */
    private String filepattern;

    /**
     * Instantiates a new WLTP file filter.
     *
     * @param extension the extension
     */
    public MarketingFileFilter(String extension) {
        this.filepattern = extension;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.io.FileFilter#accept(java.io.File)
     */
    @Override
    public boolean accept(File pathname) {
        return pathname.isFile() && pathname.getName().equalsIgnoreCase(filepattern);
    }

}
