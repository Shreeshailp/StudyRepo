/*
 * Creation : 30 Apr 2019
 */
package com.inetpsa.w7t.batch.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import javax.annotation.CheckForNull;
import javax.annotation.Nullable;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

/**
 * The Class FileSplittingTasklet.
 */
public class FileSplittingTasklet implements Tasklet {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    /** The filePath. */
    private String filepath;

    /**
     * Instantiates a new file splitting tasklet.
     *
     * @param filepath the filepath
     */
    public FileSplittingTasklet(String filepath) {
        super();
        this.filepath = filepath;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.step.tasklet.Tasklet#execute(org.springframework.batch.core.StepContribution,
     *      org.springframework.batch.core.scope.context.ChunkContext)
     */
    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
        spiltFile();
        return RepeatStatus.FINISHED;
    }

    /**
     * Checks if is valid file path.
     *
     * @param path the path
     * @return true, if is valid file path
     */
    public static boolean isValidFilePath(String path) {
        // validated as per check-marx report
        File f = new File(path);
        try {
            f.getCanonicalPath();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Sanitize.
     *
     * @param path the path
     * @return the string
     */
    @CheckForNull
    public static String sanitize(@Nullable String path) {
        return FilenameUtils.normalize(path, true);
    }

    /**
     * Spilt file.
     */
    private void spiltFile() {
        // validated and sanitized as per check-marx report
        String sanitizedfilepath = sanitize(filepath);
        boolean proceed = isValidFilePath(sanitizedfilepath);
        if (proceed) {
            File file = new File(sanitizedfilepath);
            try (FileInputStream fstream = new FileInputStream(sanitizedfilepath);
                    DataInputStream in = new DataInputStream(fstream);
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    Scanner scanner = new Scanner(file);) {
                // Reading file and getting no. of files to be generated
                String inputfile = sanitizedfilepath; // Source File Name.

                Path path = Paths.get(inputfile);
                long lineCount = Files.lines(path).count();

                double nol = lineCount; // No. of lines to be split and saved in each output file.
                if (lineCount > 5)
                    nol = 5;

                int count = 0;
                while (scanner.hasNextLine()) {
                    scanner.nextLine();
                    count++;
                }
                logger.info("Lines in the file: {} ", count); // Displays no. of lines in the input file.

                double temp = (count / nol);
                int temp1 = (int) temp;
                int nof = 0;
                if (temp1 == temp) {
                    nof = temp1;
                } else {
                    nof = temp1 + 1;
                }
                logger.info("No. of files to be generated : {}", nof); // Displays no. of files to be generated.

                // ---------------------------------------------------------------------------------------------------------

                // Actual splitting of file into smaller files

                String strLine;

                for (int j = 1; j <= nof; j++) {
                    try (FileWriter fstream1 = new FileWriter(inputfile + j); BufferedWriter out = new BufferedWriter(fstream1);) { // Destination
                                                                                                                                    // File
                        for (int i = 1; i <= nol; i++) {
                            strLine = br.readLine();
                            if (strLine != null) {
                                out.write(strLine);
                                if (i != nol) {
                                    out.newLine();
                                }
                            }
                        }

                    } catch (Exception e) {
                        logger.error("Error: {}", e.getMessage());
                    }
                }

            } catch (Exception e) {
                logger.error("Error: {}", e.getMessage());
            }
        }
    }

}
