/*
 * Creation : 19 Mar 2021
 */
package com.inetpsa.w7t.batch.shared;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.infrastructure.VlowVHighCombinedResultFinder;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;

/**
 * The Class MovementCode30ServiceImpl.
 */
public class MovementCode30ServiceImpl implements MovementCode30Service {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The vlow V high combined result finder. */
    @Inject
    VlowVHighCombinedResultFinder vlowVHighCombinedResultFinder;

    /** The co 2. */
    String co2 = "CO2";

    /** The fc. */
    String fc = "FC";

    /** The comblow. */
    String comblow = "VLOW";

    /** The combhigh. */
    String combhigh = "VHIGH";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.shared.MovementCode30Service#mapW30Data(com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto)
     */
    @Override
    public AoCronosEliadeDto mapW30Data(AoCronosEliadeDto dto) {
        String extendedTitle = dto.getVersion16() + dto.getColorExtInt() + dto.getExtAttr();
        try {
            Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8C(?<family>..)(..))(?:.{7})*").matcher(extendedTitle);
            String code = "";
            if (m.matches()) {
                code = m.group("family").trim();
            }
            Matcher m1 = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
            String index = "";
            if (m1.matches()) {
                index = m1.group("index").trim();
            }

            String vLowCo2EmissionCombined = "";
            String vLowFuelConsumptionCombined = "";
            String miniCondHybrideWCCO2 = "";
            String miniCondHybrideWCFC = "";
            String miniInj2CondMixteCO2B = "";
            String miniInj2CondMixteFCB = "";
            String miniGazCondMixtesCO2G = "";
            String miniGazCondMixtesFCG = "";
            String miniElectricEnergyConsumptionEC = "";
            String miniElectricRangePER = "";
            String miniElectricEnergyConsumptionUFEC = "";
            String miniElectricRangeEAER = "";
            // Added below property as part of this JIRA-454
            String minAllElectricRangeAER = "";

            String vHighCo2EmissionCombined = "";
            String vHighFuelConsumptionCombined = "";
            String maxCondHybrideWCCO2 = "";
            String maxCondHybrideWCFC = "";
            String maxInj2CondMixteCO2B = "";
            String maxInj2CondMixteFCB = "";
            String maxGazCondMixtesCO2G = "";
            String maxGazCondMixtesFCG = "";
            String maxElectricEnergyConsumptionEC = "";
            String maxElectricRangePER = "";
            String maxElectricEnergyConsumptionUFEC = "";
            String maxElectricRangeEAER = "";
            // Added below property as part of this JIRA-454 fix
            String maxAllElectricRangeAER = "";

            Optional<Family> families = Optional.empty();

            if (!code.isEmpty() && !index.isEmpty()) {
                Map<String, String> vlowMapAndvHighMap = new ConcurrentHashMap<>();
                List<String[]> vLowAndvHighValues = vlowVHighCombinedResultFinder.getCombValuesByCodeAndIndex(code, index);
                String key = null;
                String str1 = null;
                String str2 = null;
                String str3 = null;
                String str4 = null;
                for (Object[] stringArray : vLowAndvHighValues) {
                    if (stringArray[1] != null) {
                        str1 = stringArray[1].toString();
                    }
                    if (stringArray[2] != null) {
                        str2 = stringArray[2].toString();
                    }
                    if (stringArray[3] != null) {
                        str3 = stringArray[3].toString();
                    }
                    if (stringArray[4] != null) {
                        str4 = stringArray[4].toString();
                    }

                    key = str1 + "_" + str2 + "_" + str3 + "_" + str4;
                    if (stringArray[0] != null) {
                        vlowMapAndvHighMap.put(key, stringArray[0].toString());
                        if (str4 != null && str4.length() < 2) {
                            key = str1 + "_" + str2 + "_" + str3 + "_0" + str4;
                            vlowMapAndvHighMap.put(key, stringArray[0].toString());
                        }
                    }
                }
                if (!vlowMapAndvHighMap.isEmpty()) {
                    vLowCo2EmissionCombined = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.CO2 + "_" + comblow + "_" + code + "_" + index);
                    vLowCo2EmissionCombined = vLowCo2EmissionCombined == null ? "" : vLowCo2EmissionCombined;

                    vHighCo2EmissionCombined = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.CO2 + "_" + combhigh + "_" + code + "_" + index);
                    vHighCo2EmissionCombined = vHighCo2EmissionCombined == null ? "" : vHighCo2EmissionCombined;

                    vLowFuelConsumptionCombined = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.FC + "_" + comblow + "_" + code + "_" + index);
                    vLowFuelConsumptionCombined = vLowFuelConsumptionCombined == null ? "" : vLowFuelConsumptionCombined;

                    vHighFuelConsumptionCombined = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.FC + "_" + combhigh + "_" + code + "_" + index);
                    vHighFuelConsumptionCombined = vHighFuelConsumptionCombined == null ? "" : vHighFuelConsumptionCombined;

                    miniCondHybrideWCCO2 = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.WCCO2 + "_" + comblow + "_" + code + "_" + index);
                    miniCondHybrideWCCO2 = miniCondHybrideWCCO2 == null ? "" : miniCondHybrideWCCO2;

                    maxCondHybrideWCCO2 = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.WCCO2 + "_" + combhigh + "_" + code + "_" + index);
                    maxCondHybrideWCCO2 = maxCondHybrideWCCO2 == null ? "" : maxCondHybrideWCCO2;

                    miniCondHybrideWCFC = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.WCFC + "_" + comblow + "_" + code + "_" + index);
                    miniCondHybrideWCFC = miniCondHybrideWCFC == null ? "" : miniCondHybrideWCFC;

                    maxCondHybrideWCFC = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.WCFC + "_" + combhigh + "_" + code + "_" + index);
                    maxCondHybrideWCFC = maxCondHybrideWCFC == null ? "" : maxCondHybrideWCFC;

                    miniInj2CondMixteCO2B = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.CO2B + "_" + comblow + "_" + code + "_" + index);
                    miniInj2CondMixteCO2B = miniInj2CondMixteCO2B == null ? "" : miniInj2CondMixteCO2B;

                    maxInj2CondMixteCO2B = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.CO2B + "_" + combhigh + "_" + code + "_" + index);
                    maxInj2CondMixteCO2B = maxInj2CondMixteCO2B == null ? "" : maxInj2CondMixteCO2B;

                    miniInj2CondMixteFCB = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.FCB + "_" + comblow + "_" + code + "_" + index);
                    miniInj2CondMixteFCB = miniInj2CondMixteFCB == null ? "" : miniInj2CondMixteFCB;

                    maxInj2CondMixteFCB = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.FCB + "_" + combhigh + "_" + code + "_" + index);
                    maxInj2CondMixteFCB = maxInj2CondMixteFCB == null ? "" : maxInj2CondMixteFCB;

                    miniGazCondMixtesCO2G = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.CO2G + "_" + comblow + "_" + code + "_" + index);
                    miniGazCondMixtesCO2G = miniGazCondMixtesCO2G == null ? "" : miniGazCondMixtesCO2G;

                    maxGazCondMixtesCO2G = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.CO2G + "_" + combhigh + "_" + code + "_" + index);
                    maxGazCondMixtesCO2G = maxGazCondMixtesCO2G == null ? "" : maxGazCondMixtesCO2G;

                    miniGazCondMixtesFCG = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.FCG + "_" + comblow + "_" + code + "_" + index);
                    miniGazCondMixtesFCG = miniGazCondMixtesFCG == null ? "" : miniGazCondMixtesFCG;

                    maxGazCondMixtesFCG = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.FCG + "_" + combhigh + "_" + code + "_" + index);
                    maxGazCondMixtesFCG = maxGazCondMixtesFCG == null ? "" : maxGazCondMixtesFCG;

                    miniElectricEnergyConsumptionEC = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.EC + "_" + comblow + "_" + code + "_" + index);
                    miniElectricEnergyConsumptionEC = miniElectricEnergyConsumptionEC == null ? "" : miniElectricEnergyConsumptionEC;

                    maxElectricEnergyConsumptionEC = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.EC + "_" + combhigh + "_" + code + "_" + index);
                    maxElectricEnergyConsumptionEC = maxElectricEnergyConsumptionEC == null ? "" : maxElectricEnergyConsumptionEC;

                    miniElectricRangePER = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.PER + "_" + comblow + "_" + code + "_" + index);
                    miniElectricRangePER = miniElectricRangePER == null ? "" : miniElectricRangePER;

                    maxElectricRangePER = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.PER + "_" + combhigh + "_" + code + "_" + index);
                    maxElectricRangePER = maxElectricRangePER == null ? "" : maxElectricRangePER;

                    miniElectricEnergyConsumptionUFEC = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.UFEC + "_" + comblow + "_" + code + "_" + index);
                    miniElectricEnergyConsumptionUFEC = miniElectricEnergyConsumptionUFEC == null ? "" : miniElectricEnergyConsumptionUFEC;

                    maxElectricEnergyConsumptionUFEC = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.UFEC + "_" + combhigh + "_" + code + "_" + index);
                    maxElectricEnergyConsumptionUFEC = maxElectricEnergyConsumptionUFEC == null ? "" : maxElectricEnergyConsumptionUFEC;

                    miniElectricRangeEAER = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.EAER + "_" + comblow + "_" + code + "_" + index);
                    miniElectricRangeEAER = miniElectricRangeEAER == null ? "" : miniElectricRangeEAER;

                    maxElectricRangeEAER = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.EAER + "_" + combhigh + "_" + code + "_" + index);
                    maxElectricRangeEAER = maxElectricRangeEAER == null ? "" : maxElectricRangeEAER;

                    // Added below setter methods as part of this JIRA-454 fix
                    minAllElectricRangeAER = vlowMapAndvHighMap.get(AoCronoEliadeCalculationConstants.AER + "_" + comblow + "_" + code + "_" + index);
                    minAllElectricRangeAER = minAllElectricRangeAER == null ? "" : minAllElectricRangeAER;

                    maxAllElectricRangeAER = vlowMapAndvHighMap
                            .get(AoCronoEliadeCalculationConstants.AER + "_" + combhigh + "_" + code + "_" + index);
                    maxAllElectricRangeAER = maxAllElectricRangeAER == null ? "" : maxAllElectricRangeAER;

                }

                if (org.apache.commons.lang.math.NumberUtils.isNumber(index))
                    families = familyRepository.byCodeAndIndex(code, Integer.parseInt(index));

            }

            String vehicleType = families.isPresent() ? families.get().getType().trim() : "";
            dto.setExtendedTitle(extendedTitle);
            dto.setCode(("T8D" + index) == null ? "" : ("T8D" + index));
            dto.setFamily((("T8C" + code) == null) ? "" : ("T8C" + code));

            dto.setvLow(vLowCo2EmissionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2, vLowCo2EmissionCombined).replace(".", ","));
            dto.setvHigh(vHighCo2EmissionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2, vHighCo2EmissionCombined).replace(".", ","));
            dto.setvLowFuelConsumption(vLowFuelConsumptionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FC, vLowFuelConsumptionCombined).replace(".", ","));
            dto.setvHighFuelConsumption(vHighFuelConsumptionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FC, vHighFuelConsumptionCombined).replace(".", ","));
            dto.setMiniCondHybrideWCCO2(miniCondHybrideWCCO2.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCCO2, miniCondHybrideWCCO2).replace(".", ","));
            dto.setMaxCondHybrideWCCO2(maxCondHybrideWCCO2.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCCO2, maxCondHybrideWCCO2).replace(".", ","));
            dto.setMiniCondHybrideWCFC(miniCondHybrideWCFC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCFC, miniCondHybrideWCFC).replace(".", ","));
            dto.setMaxCondHybrideWCFC(maxCondHybrideWCFC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCFC, maxCondHybrideWCFC).replace(".", ","));
            dto.setMiniInj2CondMixteCO2B(miniInj2CondMixteCO2B.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2B, miniInj2CondMixteCO2B).replace(".", ","));
            dto.setMaxInj2CondMixteCO2B(maxInj2CondMixteCO2B.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2B, maxInj2CondMixteCO2B).replace(".", ","));
            dto.setMiniInj2CondMixteFCB(miniInj2CondMixteFCB.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCB, miniInj2CondMixteFCB).replace(".", ","));
            dto.setMaxInj2CondMixteFCB(maxInj2CondMixteFCB.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCB, maxInj2CondMixteFCB).replace(".", ","));
            dto.setMiniGazCondMixtesCO2G(miniGazCondMixtesCO2G.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2G, miniGazCondMixtesCO2G).replace(".", ","));
            dto.setMaxGazCondMixtesCO2G(maxGazCondMixtesCO2G.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2G, maxGazCondMixtesCO2G).replace(".", ","));
            dto.setMiniGazCondMixtesFCG(miniGazCondMixtesFCG.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCG, miniGazCondMixtesFCG).replace(".", ","));
            dto.setMaxGazCondMixtesFCG(maxGazCondMixtesFCG.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCG, maxGazCondMixtesFCG).replace(".", ","));
            dto.setMiniElectricEnergyConsumptionEC(miniElectricEnergyConsumptionEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EC, miniElectricEnergyConsumptionEC).replace(".", ","));
            dto.setMaxElectricEnergyConsumptionEC(maxElectricEnergyConsumptionEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EC, maxElectricEnergyConsumptionEC).replace(".", ","));
            dto.setMiniElectricRangePER(miniElectricRangePER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, miniElectricRangePER).replace(".", ","));
            dto.setMaxElectricRangePER(maxElectricRangePER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, maxElectricRangePER).replace(".", ","));
            dto.setMiniElectricEnergyConsumptionUFEC(miniElectricEnergyConsumptionUFEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFEC, miniElectricEnergyConsumptionUFEC).replace(".", ","));
            dto.setMaxElectricEnergyConsumptionUFEC(maxElectricEnergyConsumptionUFEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFEC, maxElectricEnergyConsumptionUFEC).replace(".", ","));
            dto.setMiniElectricRangeEAER(miniElectricRangeEAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, miniElectricRangeEAER).replace(".", ","));
            dto.setMaxElectricRangeEAER(maxElectricRangeEAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, maxElectricRangeEAER).replace(".", ","));

            // Added below setter methods as part of this JIRA-454 fix
            dto.setMinAllElectricRangeAER(minAllElectricRangeAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, minAllElectricRangeAER).replace(".", ","));
            dto.setMaxAllElectricRangeAER(maxAllElectricRangeAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, maxAllElectricRangeAER).replace(".", ","));

            dto.setVehicleType(vehicleType);
        } catch (Exception e) {
            logger.error("REQUEST_ID: [{}] - Error in MovementCode30Service : request [{}], [{}]", dto.getRequestId(), dto, e);
            LogUtility.logTheError(logger, dto.getRequestId(), WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
                    WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
        }
        return dto;
    }

    /**
     * Gets the phase result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, String value) {
        Double newValue = Double.valueOf(value);
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(newValue).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

}
