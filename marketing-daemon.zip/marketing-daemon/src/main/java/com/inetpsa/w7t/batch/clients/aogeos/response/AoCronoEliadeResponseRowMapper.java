/*
 * Creation : 20 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.response;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;

import javax.inject.Inject;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.batch.infrastructure.VlowVHighCombinedResultFinder;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeCalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;

/**
 * The Class AoGeosResponseRowMapper.
 */
public class AoCronoEliadeResponseRowMapper implements RowMapper<AoCronosEliadeDto> {

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;
    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    /** The vlow V high combined result finder. */
    @Inject
    VlowVHighCombinedResultFinder vlowVHighCombinedResultFinder;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The Constant MOVE_CODE_W020. */
    private static final String MOVE_CODE_W020 = "W020";

    /** The co 2. */
    String co2 = "CO2";

    /** The fc. */
    String fc = "FC";

    /** The comblow. */
    String comblow = "VLOW";

    /** The combhigh. */
    String combhigh = "VHIGH";

    /** The Constant MOVE_CODE_W030. */
    private static final String MOVE_CODE_W030 = "W030";

    /** The Constant REQUEST_ID. */
    private static final String REQUEST_ID = "REQUEST_ID";

    /** The Constant VERSION16. */
    private static final String VERSION16 = "VERSION16";

    /** The Constant EXT_ATTR. */
    private static final String EXT_ATTR = "EXT_ATTR";

    /** The Constant COLOR_EXT_INT. */
    private static final String COLOR_EXT_INT = "COLOR_EXT_INT";
    /** The date formatter. */
    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");

    /** The ending date of calculation. */
    String endingDateOfCalculation = LocalDate.now().format(dateFormatter);

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
     */
    @Override
    public AoCronosEliadeDto mapRow(ResultSet rs, int rowNum) throws SQLException {

        if (rs == null) {
            return null;
        }
        AoCronosEliadeDto request = new AoCronosEliadeDto();
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            request.setValidityDate(dateFormat.format(date));

            String reqId = rs.getString(REQUEST_ID);
            String prd = reqId.substring(0, 3);
            String lotNumber = reqId.substring(3, 8);
            String lineNumber = reqId.substring(8, 20);
            if (rs.getString(VERSION16) == null) {
                request.setVersion16("");
            } else {
                request.setVersion16(rs.getString(VERSION16));
            }
            if (rs.getString(EXT_ATTR) == null) {
                request.setExtAttr("");
            } else {
                request.setExtAttr(rs.getString(EXT_ATTR));
            }
            if (rs.getString(COLOR_EXT_INT) == null) {
                request.setColorExtInt("");
            } else {
                request.setColorExtInt(rs.getString(COLOR_EXT_INT));
            }
            request.setMomentCode20(MOVE_CODE_W020);
            request.setPrd(prd == null ? "" : prd);
            request.setLotNumber(lotNumber == null ? "" : lotNumber);
            request.setLineNumber(lineNumber == null ? "" : lineNumber);
            request.setBrand(rs.getString("BRAND") == null ? "" : rs.getString("BRAND"));

            String extentionDate = rs.getString("datext");
            if (!extentionDate.isEmpty() && extentionDate.length() >= 8)
                request.setExtensionDate(extentionDate.replace("-", "").substring(0, 8).trim());
            else
                request.setExtensionDate(extentionDate.replace("-", "").substring(0, extentionDate.length()).trim());

            request.setGestion((rs.getString("GESTION") == null) ? "" : rs.getString("GESTION"));
            request.setGestion7C((rs.getString("GESTION7C") == null) ? "" : rs.getString("GESTION7C"));
            request.setOptions((rs.getString("OPTIONS") == null) ? "" : rs.getString("OPTIONS"));
            request.setOptions7C((rs.getString("OPTIONS7C") == null) ? "" : rs.getString("OPTIONS7C"));
            request.setTradingCountry((rs.getString("TRADING_COUNTRY") == null) ? "" : rs.getString("TRADING_COUNTRY"));
            request.setAnswerCode((rs.getString("ANSWER_CODE") == null) ? "" : rs.getString("ANSWER_CODE"));
            request.setAnswerDesignation((rs.getString("ANSWER_DESIG") == null) ? "" : rs.getString("ANSWER_DESIG"));
            request.setFiller((rs.getString("FILLER") == null) ? "" : rs.getString("FILLER"));
            request.setEndDate(endingDateOfCalculation == null ? "" : endingDateOfCalculation);
            if (rs.getString(REQUEST_ID) == null) {
                request.setRequestId("");
            } else {
                request.setRequestId(rs.getString(REQUEST_ID));
            }

            request.setMomentCode30(MOVE_CODE_W030.trim());
            request.updatePhysicalQuantities(getNewtonPhysicalQuantity(rs));

            request.setRequestType(rs.getString("REQUEST_TYPE"));
            String extendedTitle = rs.getString(VERSION16) + rs.getString(COLOR_EXT_INT) + rs.getString(EXT_ATTR);
            Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8C(?<family>..)(..))(?:.{7})*").matcher(extendedTitle);
            String code = "";
            if (m.matches()) {
                code = m.group("family").trim();
            }
            Matcher m1 = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
            String index = "";
            if (m1.matches()) {
                index = m1.group("index").trim();
            }

            request.setFileId(rs.getString("FILE_ID"));
            request.setSendingSite(rs.getString("SENDING_SITE"));
            request.setSendingApplication(rs.getString("SENDING_APPLICATION"));
            request.setHeaderLotNumber(rs.getString("LOT_NUMBER"));
            request.setLotDate(rs.getString("LOT_DATE"));

            String vLowCo2EmissionCombined = "";
            String vLowFuelConsumptionCombined = "";
            String miniCondHybrideWCCO2 = "";
            String miniCondHybrideWCFC = "";
            String miniInj2CondMixteCO2B = "";
            String miniInj2CondMixteFCB = "";
            String miniGazCondMixtesCO2G = "";
            String miniGazCondMixtesFCG = "";
            String miniElectricEnergyConsumptionEC = "";
            String miniElectricRangePER = "";
            String miniElectricEnergyConsumptionUFEC = "";
            String miniElectricRangeEAER = "";
            // Added below property as part of this JIRA-454 fix
            String miniAllElectricRangeAER = "";

            String vHighCo2EmissionCombined = "";
            String vHighFuelConsumptionCombined = "";
            String maxCondHybrideWCCO2 = "";
            String maxCondHybrideWCFC = "";
            String maxInj2CondMixteCO2B = "";
            String maxInj2CondMixteFCB = "";
            String maxGazCondMixtesCO2G = "";
            String maxGazCondMixtesFCG = "";
            String maxElectricEnergyConsumptionEC = "";
            String maxElectricRangePER = "";
            String maxElectricEnergyConsumptionUFEC = "";
            String maxElectricRangeEAER = "";
            // Added below property as part of this JIRA-454 fix
            String maxAllElectricRangeAER = "";

            Optional<Family> families = Optional.empty();

            if (!code.isEmpty() && !index.isEmpty()) {

                vLowCo2EmissionCombined = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2, comblow, code, index);
                vHighCo2EmissionCombined = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2, combhigh, code, index);

                vLowFuelConsumptionCombined = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FC, comblow, code, index);
                vHighFuelConsumptionCombined = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FC, combhigh, code,
                        index);

                miniCondHybrideWCCO2 = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.WCCO2, comblow, code, index);
                maxCondHybrideWCCO2 = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.WCCO2, combhigh, code, index);

                miniCondHybrideWCFC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.WCFC, comblow, code, index);
                maxCondHybrideWCFC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.WCFC, combhigh, code, index);

                miniInj2CondMixteCO2B = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2B, comblow, code, index);
                maxInj2CondMixteCO2B = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2B, combhigh, code, index);

                miniInj2CondMixteFCB = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FCB, comblow, code, index);
                maxInj2CondMixteFCB = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FCB, combhigh, code, index);

                miniGazCondMixtesCO2G = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2G, comblow, code, index);
                maxGazCondMixtesCO2G = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.CO2G, combhigh, code, index);

                miniGazCondMixtesFCG = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FCG, comblow, code, index);
                maxGazCondMixtesFCG = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.FCG, combhigh, code, index);

                miniElectricEnergyConsumptionEC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.EC, comblow, code,
                        index);
                maxElectricEnergyConsumptionEC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.EC, combhigh, code,
                        index);

                miniElectricRangePER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.PER, comblow, code, index);
                maxElectricRangePER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.PER, combhigh, code, index);

                miniElectricEnergyConsumptionUFEC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.UFEC, comblow, code,
                        index);
                maxElectricEnergyConsumptionUFEC = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.UFEC, combhigh, code,
                        index);

                miniElectricRangeEAER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.EAER, comblow, code, index);
                maxElectricRangeEAER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.EAER, combhigh, code, index);

                // Added below property as part of this JIRA-454 fix
                miniAllElectricRangeAER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.AER, comblow, code, index);
                maxAllElectricRangeAER = vlowVHighCombinedResultFinder.getCombValues(AoCronoEliadeCalculationConstants.AER, combhigh, code, index);

                if (NumberUtils.isNumber(index))
                    families = familyRepository.byCodeAndIndex(code, Integer.parseInt(index));

            }

            String vehicleType = families.isPresent() ? families.get().getType().trim() : "";
            request.setExtendedTitle(extendedTitle);
            request.setCode(("T8D" + index) == null ? "" : ("T8D" + index));
            request.setFamily((("T8C" + code) == null) ? "" : ("T8C" + code));
            request.setRequestId(rs.getString(REQUEST_ID));

            request.setvLow(vLowCo2EmissionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2, vLowCo2EmissionCombined).replace(".", ","));
            request.setvHigh(vHighCo2EmissionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2, vHighCo2EmissionCombined).replace(".", ","));

            request.setvLowFuelConsumption(vLowFuelConsumptionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FC, vLowFuelConsumptionCombined).replace(".", ","));
            request.setvHighFuelConsumption(vHighFuelConsumptionCombined.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FC, vHighFuelConsumptionCombined).replace(".", ","));

            request.setMiniCondHybrideWCCO2(miniCondHybrideWCCO2.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCCO2, miniCondHybrideWCCO2).replace(".", ","));
            request.setMaxCondHybrideWCCO2(maxCondHybrideWCCO2.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCCO2, maxCondHybrideWCCO2).replace(".", ","));

            request.setMiniCondHybrideWCFC(miniCondHybrideWCFC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCFC, miniCondHybrideWCFC).replace(".", ","));
            request.setMaxCondHybrideWCFC(maxCondHybrideWCFC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.WCFC, maxCondHybrideWCFC).replace(".", ","));

            request.setMiniInj2CondMixteCO2B(miniInj2CondMixteCO2B.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2B, miniInj2CondMixteCO2B).replace(".", ","));
            request.setMaxInj2CondMixteCO2B(maxInj2CondMixteCO2B.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2B, maxInj2CondMixteCO2B).replace(".", ","));

            request.setMiniInj2CondMixteFCB(miniInj2CondMixteFCB.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCB, miniInj2CondMixteFCB).replace(".", ","));
            request.setMaxInj2CondMixteFCB(maxInj2CondMixteFCB.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCB, maxInj2CondMixteFCB).replace(".", ","));

            request.setMiniGazCondMixtesCO2G(miniGazCondMixtesCO2G.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2G, miniGazCondMixtesCO2G).replace(".", ","));
            request.setMaxGazCondMixtesCO2G(maxGazCondMixtesCO2G.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.CO2G, maxGazCondMixtesCO2G).replace(".", ","));

            request.setMiniGazCondMixtesFCG(miniGazCondMixtesFCG.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCG, miniGazCondMixtesFCG).replace(".", ","));
            request.setMaxGazCondMixtesFCG(maxGazCondMixtesFCG.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.FCG, maxGazCondMixtesFCG).replace(".", ","));

            request.setMiniElectricEnergyConsumptionEC(miniElectricEnergyConsumptionEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EC, miniElectricEnergyConsumptionEC).replace(".", ","));
            request.setMaxElectricEnergyConsumptionEC(maxElectricEnergyConsumptionEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EC, maxElectricEnergyConsumptionEC).replace(".", ","));

            request.setMiniElectricRangePER(miniElectricRangePER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, miniElectricRangePER).replace(".", ","));
            request.setMaxElectricRangePER(maxElectricRangePER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.PER, maxElectricRangePER).replace(".", ","));

            request.setMiniElectricEnergyConsumptionUFEC(miniElectricEnergyConsumptionUFEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFEC, miniElectricEnergyConsumptionUFEC).replace(".", ","));
            request.setMaxElectricEnergyConsumptionUFEC(maxElectricEnergyConsumptionUFEC.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.UFEC, maxElectricEnergyConsumptionUFEC).replace(".", ","));

            request.setMiniElectricRangeEAER(miniElectricRangeEAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, miniElectricRangeEAER).replace(".", ","));
            request.setMaxElectricRangeEAER(maxElectricRangeEAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.EAER, maxElectricRangeEAER).replace(".", ","));
            // Added below properties as part of this JIRA-454 fix
            request.setMinAllElectricRangeAER(miniAllElectricRangeAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, miniAllElectricRangeAER).replace(".", ","));
            request.setMaxAllElectricRangeAER(maxAllElectricRangeAER.isEmpty() ? ""
                    : getPhaseResultInFormat(AoCronoEliadeCalculationConstants.AER, maxAllElectricRangeAER).replace(".", ","));

            request.setVehicleType(vehicleType);
        } catch (Exception e) {
            logger.error("REQUEST_ID: [{}] - Error in AoCronoEliadeResponseRowMapper : request [{}], [{}]", request.getRequestId(), request, e);
        }

        return request;
    }

    /**
     * Gets the newton physical quantity.
     *
     * @param rs the rs
     * @return the newton physical quantity
     */
    List<EnginePhysicalQuantity> getNewtonPhysicalQuantity(ResultSet rs) {
        List<EnginePhysicalQuantity> enginePhysicalQuantityList = new ArrayList<>();

        try {
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.MASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_VEHIC"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.SCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_VEHIC"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, getPrimitiveTypeForNULL(rs.getDouble("CRR_VEHIC"))));

            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.UMASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_SOCLE"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.EMASS_CODE, getPrimitiveTypeForNULL(rs.getDouble("MASS_EQUIP"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.ESCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_EQUIP"))));
            enginePhysicalQuantityList
                    .add(new EnginePhysicalQuantity(CalculationConstants.USCX_CODE, getPrimitiveTypeForNULL(rs.getDouble("SCX_SOCLE"))));
        } catch (SQLException e) {
            logger.error("Error : {}", e);
        }

        return enginePhysicalQuantityList;
    }

    /**
     * Gets the primitive type for NULL.
     * 
     * @param value the value
     * @return the primitive type for NULL
     */
    private double getPrimitiveTypeForNULL(Double value) {
        if (value == null)
            return 0.0;
        return value.doubleValue();
    }

    /**
     * Gets the phase result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, String value) {
        Double newValue = Double.valueOf(value);
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(newValue).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }
}
