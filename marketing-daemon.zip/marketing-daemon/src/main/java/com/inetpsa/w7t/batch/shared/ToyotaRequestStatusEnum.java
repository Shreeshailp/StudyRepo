/*
 * Creation : 26 Sep 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.util.stream.Stream;

/**
 * enum for TOYOTA
 * 
 * @author E534812
 */
public enum ToyotaRequestStatusEnum {

    /** The request received. */
    REQUEST_RECEIVED("10"),
    /** The valid request. */
    VALID_REQUEST("20"),
    /** The to be sent to BCV. */
    TO_BE_SENT_TO_BCV("22"),
    /** The request rejected. */
    REQUEST_REJECTED("60"),
    /** The request type full. */
    REQUEST_TYPE_FULL("FULL"),
    /** The request type comb. */
    REQUEST_TYPE_COMB("COMB");

    /** The status code. */
    private String statusCode;

    /**
     * Instantiates a new request status.
     *
     * @param statusCode the status code
     */
    ToyotaRequestStatusEnum(String statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Returns a RequestStatus corresponding to the specified status code, or else null.
     *
     * @param intStatusCode the status code
     * @return the request status
     */
    /**
     */
    public static ToyotaRequestStatusEnum of(String statusCode) {
        return Stream.of(ToyotaRequestStatusEnum.values()).filter(s -> s.statusCode.equals(statusCode)).findFirst().orElse(null);
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public String getStatusCode() {
        return this.statusCode;
    }
}
