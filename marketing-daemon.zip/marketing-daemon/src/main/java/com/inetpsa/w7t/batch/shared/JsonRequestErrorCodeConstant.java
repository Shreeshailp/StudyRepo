/*
 * Creation : 18 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

/**
 * The Class JsonRequestErrorCodeConstant.
 *
 * @author E534811
 */
public class JsonRequestErrorCodeConstant {

    /** The Constant VERSION_16C_INCORRECT. */
    public static final String VERSION_16C_INCORRECT = "ERRW601:Version 16C missing or incorrect";

    /** The Constant COLOR_EXT_INT_INCORRECT. */
    public static final String COLOR_EXT_INT_INCORRECT = "ERRW602:Color exterior and interior missing or incorrect";

    /** The Constant NB_OPTIONS_INCORRECT. */
    public static final String NB_OPTIONS_INCORRECT = "ERRW603:nbOptions incorrect";

    /** The Constant OPTIONS_5C_INCORRECT. */
    public static final String OPTIONS_5C_INCORRECT = "ERRW604:Options5C incorrect ";

    /** The Constant OPTIONS_7C_INCORRECT. */
    public static final String OPTIONS_7C_INCORRECT = "ERRW605:Options7C incorrect";

    /** The Constant REQUEST_TYPE_INCORRECT. */
    public static final String REQUEST_TYPE_INCORRECT = "ERRW103:unknown request type";

    /** The Constant COUNTRY_CODE_INCORRECT. */
    public static final String COUNTRY_CODE_INCORRECT = "ERRW610:incorrect trading country";

    /** The Constant EXTENSION_DATE_INCORRECT. */
    public static final String EXTENSION_DATE_INCORRECT = "ERRW606:Incorrect extension date";

    /** The Constant DESTINATION_INCORRECT. */
    public static final String DESTINATION_INCORRECT = "ERROR:destination not found";

    /**
     * Instantiates a new json request error code constant.
     */
    private JsonRequestErrorCodeConstant() {
    }

}
