/*
 * Creation : 12 Dec 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.response;

public class AoGeosW30Dto {

    private String familyCode;
    private String index;
    private String w30Data;

    public AoGeosW30Dto(String familyCode, String index, String w30Data) {
        this.familyCode = familyCode;
        this.index = index;
        this.w30Data = w30Data;
    }

    public String getFamilyCode() {
        return familyCode;
    }

    public void setFamilyCode(String familyCode) {
        this.familyCode = familyCode;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getW30Data() {
        return w30Data;
    }

    public void setW30Data(String w30Data) {
        this.w30Data = w30Data;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((familyCode == null) ? 0 : familyCode.hashCode());
        result = prime * result + ((index == null) ? 0 : index.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AoGeosW30Dto other = (AoGeosW30Dto) obj;
        if (familyCode == null) {
            if (other.familyCode != null)
                return false;
        } else if (!familyCode.equals(other.familyCode))
            return false;
        if (index == null) {
            if (other.index != null)
                return false;
        } else if (!index.equals(other.index))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "AoGeosW30Dto [familyCode=" + familyCode + ", index=" + index + ", w30Data=" + w30Data + "]";
    }

}
