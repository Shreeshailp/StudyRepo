/*
 * Creation : 18 Feb 2019
 */
package com.inetpsa.w7t.batch.shared;

import java.util.List;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;

/**
 * The Interface MarketingDaemonCalculatorService.
 */
@Service

public interface MarketingDaemonCalculatorService {

    public AoCronosEliadeDto calculateAoGeosCronosEliade(AoCronosEliadeDto aoCronosEliadeDto);

    /**
     * Update marketing request calculation status.
     *
     * @param requestId the request id
     * @param answerCode the answer code
     * @param answerDesig the answer desig
     * @param previousStatus the previous status
     * @param status the status
     */
    public void updateMarketingRequestCalculationStatus(String requestId, String answerCode, String answerDesig, String previousStatus,
            String status);

    /**
     * Update answer sent status.
     *
     * @param marketingRequestList the answer dto
     */
    public void updateAnswerSentStatus(List<MarketingRequest> marketingRequestList);

    /**
     * Update answer sent status.
     *
     * @param marketingRequestDtosList the marketing request dtos list
     */

    public void updateAnswerDetails(List<MarketingRequestDto> marketingRequestDtosList);

    /**
     * Update status calculation status in MRQBRQ.
     *
     * @param calculationStatusDtoList the calculation status dto list
     */
    public void updateStatusCalculationStatusInMRQBRQ(List<CalculationStatusDto> calculationStatusDtoList);

    /**
     * Update status calculation status in MRQ.
     *
     * @param calculationStatusOKList the calculation status OK list
     */
    public void updateStatusCalculationStatusInMRQ(List<CalculationStatusDto> calculationStatusOKList);

}
