/*
 * Creation : 19 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import javax.validation.Valid;

import org.springframework.batch.item.validator.ValidatingItemProcessor;

import com.inetpsa.w7t.batch.clients.cfgmot2.request.WltpJsonBatchObject;


/**
 * The Class ValidatingJsonItemProcessor.
 *
 * @author E534811
 */
public class ValidatingJsonItemProcessor extends ValidatingItemProcessor<WltpJsonBatchObject> {

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.validator.ValidatingItemProcessor#process(java.lang.Object)
     */
    @Override
    public WltpJsonBatchObject process(@Valid WltpJsonBatchObject wltpJsonBatchObject) {
        return wltpJsonBatchObject;
    }
}
