/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services;

import org.seedstack.business.domain.GenericFactory;

import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;

/**
 * A factory for creating MarketingFileListener objects.
 */
public interface MarketingFileListenerFactory extends GenericFactory<MarketingFileListener> {

    /**
     * Creates a new MarketingFileListener object.
     *
     * @param name the name
     * @param config the config
     * @param refreshInterval the refresh interval
     * @return the marketing file listener
     */
    MarketingFileListener createClientFileListener(String name, MarketingDaemonClientConfig config, Integer refreshInterval);

    /**
     * Creates a new MarketingFileListener object.
     *
     * @param name the name
     * @param config the config
     * @param refreshInterval the refresh interval
     * @return the marketing file listener
     */
    MarketingFileListener createProviderFileListener(String name, MarketingDaemonProviderConfig config, Integer refreshInterval);
}
