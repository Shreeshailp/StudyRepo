/*
 * Creation : 18 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import org.seedstack.shed.exception.ErrorCode;

/**
 * The Enum WltpRequestErrorCode.
 *
 * @author E534811
 */
public enum WltpRequestErrorCode implements ErrorCode {

    /** The version 16c incorrect. */
    VERSION_16C_INCORRECT(601, "ERRW601", "Version 16C missing or incorrect"),

    /** The color ext int incorrect. */
    COLOR_EXT_INT_INCORRECT(602, "ERRW602", "Color exterior and interior missing or incorrect"),

    /** The nb options incorrect. */
    NB_OPTIONS_INCORRECT(000, "ERRW", "nbOptions incorrect"),

    /** The options 5c incorrect. */
    OPTIONS_5C_INCORRECT(000, "ERRW", "Options5C incorrect"),

    /** The options 7c incorrect. */
    OPTIONS_7C_INCORRECT(605, "ERRW605", "Options7C incorrect"),

    /** The request type incorrect. */
    REQUEST_TYPE_INCORRECT(103, "ERRW103", "unknown request type"),

    /** The incorrect trade country. */
    INCORRECT_TRADE_COUNTRY(610, "ERRW610", "incorrect trading country"),

    /** The unknown exception. */
    UNKNOWN_EXCEPTION(255, "ERRW255", "An exception occured, check batch logs"),

    /** The five c value incorrect. */
    FIVE_C_VALUE_INCORRECT(604, "ERRW604", "Options5C or Gestion5C incorrect"),

    /** The answer already procced. */
    ANSWER_ALREADY_PROCCED(253, "ERRW253", "BCV-Newton Request Number already processed"),

    /** The incorrect answer bcvnewton. */
    INCORRECT_ANSWER_BCVNEWTON(612, "ERRW612", "Incorrect answer from BCV-Newton"),

    /** The request number missing. */
    REQUEST_NUMBER_MISSING(251, "ERRW251", "BCV-Newton Request Number missing"),

    /** The unknow bcv newton number. */
    UNKNOW_BCV_NEWTON_NUMBER(252, "ERRW252", "unknown BCV-Newton Request Number"),

    /** The unknow marketing request. */
    UNKNOW_MARKETING_REQUEST(302, "ERRW302", "unknown Request"),

    /** The fileid not unique. */
    FILEID_NOT_UNIQUE(108, "ERRW108", "file ID not unique"),

    /** The toyota request number missing. */
    TOYOTA_REQUEST_NUMBER_MISSING(101, "ERRW101", "request number missing"),

    /** The toyota request number not unique. */
    TOYOTA_REQUEST_NUMBER_NOT_UNIQUE(102, "ERRW102", "request number not unique"),

    /** The file id blank null. */
    FILE_ID_BLANK_NULL(100, "ERRW100", "file ID blank or missing"),

    /** The inncorrect trading country. */
    INNCORRECT_TRADING_COUNTRY(610, "ERRW610", "incorrect trading country"),

    /** The unkonwn request type. */
    UNKONWN_REQUEST_TYPE(103, "ERRW103", "unknown request type"),

    /** The unkonwn client parameter. */
    UNKONWN_CLIENT_PARAMETER(254, "ERRW254", "unknown client parameters"),

    /** The prd code incorrect. */
    PRD_CODE_INCORRECT(000, "ERRW", "unknown Prd code"),

    /** The lotnumber incorrect. */
    LOTNUMBER_INCORRECT(000, "ERRW", "lot number missing or incorrect"),

    /** The linenumber incorrect. */
    LINENUMBER_INCORRECT(000, "ERRW", "line number missing or incorrect"),

    /** The brand incorrect. */
    BRAND_INCORRECT(000, "ERRW", "brand missing or incorrect"),

    /** The habillage ext incorrect. */
    HABILLAGE_EXT_INCORRECT(602, "ERRW602", "Color exterior missing or incorrect"),

    /** The habillage int incorrect. */
    HABILLAGE_INT_INCORRECT(602, "ERRW602", "Color interior missing or incorrect"),

    /** The incorrect moment code. */
    INCORRECT_MOMENT_CODE(000, "ERRW103", "unknown movement code"),

    /** The incorrect file. */
    INCORRECT_FILE(000, "ERRW104", "Incorrect file"),

    /** The ext date incorrect. */
    EXT_DATE_INCORRECT(606, "ERRW606", "extension date incorrect"),

    /** The gestion 7c incorrect. */
    GESTION_7C_INCORRECT(618, "ERRW618", "Gestion7C missing or incorrect"),

    /** The gestion 5c incorrect. */
    GESTION_5C_INCORRECT(617, "ERRW617", "Gestion5C missing or incorrect"),

    /** The requestid unique. */
    REQUESTID_UNIQUE(000, "ERRW00", "Request ID  unique"),

    /** The incorrect lcdv24. */
    INCORRECT_LCDV24(622, "ERRW622", "Incorrect LCDV24"),

    /** The too many requests. */
    TOO_MANY_REQUESTS(700, "ERRW700", "Too many requests for CalculWLTP Interface"),

    /** The unknown technical exception. */
    UNKNOWN_TECHNICAL_EXCEPTION(701, "ERRW701", "Technical issue while calling WLTPHUB"),

    /** The wltphub timeout exception. */
    WLTPHUB_TIMEOUT_EXCEPTION(702, "ERRW702", "Timeout error while calling WLTPHUB");

    /** The code. */
    private int code;

    /** The description. */
    private String description;

    /** The rule code. */
    private String ruleCode;

    /**
     * Instantiates a new WS request error code.
     *
     * @param code the code
     * @param ruleCode the rule code
     * @param description the description
     */
    WltpRequestErrorCode(int code, String ruleCode, String description) {
        this.code = code;
        this.description = description;
        this.ruleCode = ruleCode;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public int getCode() {
        return this.code;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Gets the rule code.
     *
     * @return the rule code
     */
    public String getRuleCode() {
        return this.ruleCode;
    }

}
