/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

/**
 * The Class CfgMot2JsonData.
 */
public class CfgMot2JsonData {

    /** The veh type. */
    private String vehType;

    /** The destination. */
    private String destination;

    /** The category. */
    private String category;

    public CfgMot2JsonData() {
    }

    /**
     * Gets the veh type.
     *
     * @return the veh type
     */
    public String getVehType() {
        return vehType;
    }

    /**
     * Sets the veh type.
     *
     * @param vehType the new veh type
     */
    public void setVehType(String vehType) {
        this.vehType = vehType;
    }

    /**
     * Gets the destination.
     *
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination.
     *
     * @param destination the new destination
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */

}
