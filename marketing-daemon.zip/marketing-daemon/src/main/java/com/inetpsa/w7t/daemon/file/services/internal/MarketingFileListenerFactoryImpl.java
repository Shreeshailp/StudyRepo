/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import javax.inject.Inject;

import org.seedstack.business.domain.BaseFactory;

import com.google.inject.Injector;
import com.inetpsa.w7t.daemon.file.services.MarketingFileListener;
import com.inetpsa.w7t.daemon.file.services.MarketingFileListenerFactory;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;

public class MarketingFileListenerFactoryImpl extends BaseFactory<MarketingFileListener>
		implements MarketingFileListenerFactory {

	@Inject
	private Injector injector;

	@Override
	public MarketingClientFileListener createClientFileListener(String name, MarketingDaemonClientConfig config,
			Integer refreshInterval) {

		MarketingClientFileListener client = new MarketingClientFileListener(name, config,
				refreshInterval);
		injector.injectMembers(client);
		return client;
	}

	@Override
	public MarketingFileListener createProviderFileListener(String name, MarketingDaemonProviderConfig config,
			Integer refreshInterval) {
		MarketingProviderFileListener provider = new MarketingProviderFileListener(name, config,
				refreshInterval);
		injector.injectMembers(provider);
		return provider;
	}

}
