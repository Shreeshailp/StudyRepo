/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVlowPhysicalResult" })
@XmlRootElement(name = "VLOW")
public class ToyotaVLowPhysicalResult {

    @XmlElement(name = "phys_result", required = true)
    protected List<ToyotaPhysicalResult> toyotaVlowPhysicalResult;

    public ToyotaVLowPhysicalResult() {
        super();
    }

    public ToyotaVLowPhysicalResult(List<ToyotaPhysicalResult> toyotaVlowPhysicalResult) {
        super();
        this.toyotaVlowPhysicalResult = toyotaVlowPhysicalResult;
    }

    public List<ToyotaPhysicalResult> getToyotaVlowPhysicalResult() {
        return toyotaVlowPhysicalResult;
    }

    public void setToyotaVlowPhysicalResult(List<ToyotaPhysicalResult> toyotaVlowPhysicalResult) {
        this.toyotaVlowPhysicalResult = toyotaVlowPhysicalResult;
    }

}
