/*
 * Creation : 17 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.request;

import java.io.File;
import java.io.FileFilter;

import org.apache.commons.lang.StringUtils;

/**
 * ToyotaFileFilter
 * 
 * @author E534812
 */
public class ToyotaFileFilter implements FileFilter {

    /** The file pattern. */
    private String filepattern;

    /**
     * Instantiates a new BPS file filter.
     *
     * @param extension the extension
     */
    public ToyotaFileFilter(String extension) {
        this.filepattern = extension;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.io.FileFilter#accept(java.io.File)
     */
    @Override
    public boolean accept(File pathname) {
        return pathname.isFile() && StringUtils.containsIgnoreCase(pathname.getName(), filepattern) && pathname.getName().endsWith(".xml");
    }

}
