/*
 * Creation : 2 May 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.util;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;

/**
 * The Class MultiFileResourcePartitioner.
 */
public class MultiFileResourcePartitioner implements Partitioner {

    /** The inbound dir. */
    private String inboundDir;

    /** The no records per file. */
    private Long noRecordsPerFile;

    /** The client name. */
    private String clientName;

    /** The step execution. */
    private StepExecution stepExecution;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Save step execution.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void saveStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    /** The marketing request repository. */
    @Inject
    public MarketingRequestRepository marketingRequestRepository;

    /** The marketing request tracker repository. */
    @Inject
    public MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /**
     * Instantiates a new multi file resource partitioner.
     *
     * @param inboundDir       the inbound dir
     * @param noRecordsPerFile the no records per file
     * @param clientName       the client name
     * @param uniqueIdentifier the unique identifier
     * @param fsFlagFileName   the fs flag file name
     */
    public MultiFileResourcePartitioner(String inboundDir, Long noRecordsPerFile, String clientName, String uniqueIdentifier, String fsFlagFileName) {
        super();
        this.inboundDir = inboundDir;
        this.noRecordsPerFile = noRecordsPerFile;
        this.clientName = clientName.toUpperCase();
        this.uniqueIdentifier = uniqueIdentifier;
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.partition.support.Partitioner#partition(int)
     */
    @Override
    public Map<String, ExecutionContext> partition(int gridSize) {

        Map<String, ExecutionContext> partitionMap = new HashMap<>();
        List<File> files = null;
        if (clientName.equalsIgnoreCase(MarketingDaemonServiceConstants.ELIADE)) {
            files = MarketingDaemonServiceUtils.splitFileForEliade(inboundDir, noRecordsPerFile, clientName, marketingRequestRepository,
                    this.uniqueIdentifier, marketingRequestTrackerRepository);
        } else {
            files = MarketingDaemonServiceUtils.splitFile(inboundDir, noRecordsPerFile, clientName, marketingRequestRepository,
                    this.uniqueIdentifier);
        }
        if (files != null && !files.isEmpty()) {
            for (File file : files) {
                ExecutionContext context = new ExecutionContext();
                context.put("fileResource", file.getAbsolutePath());
                context.put("FILE_ID", file.getAbsolutePath().substring(file.getAbsolutePath().lastIndexOf('_') + 1));
                context.put("UNIQUE_IDENTIFIER", this.uniqueIdentifier);
                context.put("FS_FLAG_FILE_NAME", this.fsFlagFileName);
                partitionMap.put(file.getName(), context);
            }
        }

        return partitionMap;
    }

    /**
     * Gets the no records per file.
     *
     * @return the no records per file
     */
    public Long getNoRecordsPerFile() {
        return noRecordsPerFile;
    }

    /**
     * Sets the no records per file.
     *
     * @param noRecordsPerFile the new no records per file
     */
    public void setNoRecordsPerFile(Long noRecordsPerFile) {
        this.noRecordsPerFile = noRecordsPerFile;
    }

    /**
     * Gets the inbound dir.
     *
     * @return the inbound dir
     */
    public String getInboundDir() {
        return inboundDir;
    }

    /**
     * Sets the inbound dir.
     *
     * @param inboundDir the new inbound dir
     */
    public void setInboundDir(String inboundDir) {
        this.inboundDir = inboundDir;
    }

    /**
     * Gets the client name.
     *
     * @return the client name
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the client name.
     *
     * @param clientName the new client name
     */
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

}
