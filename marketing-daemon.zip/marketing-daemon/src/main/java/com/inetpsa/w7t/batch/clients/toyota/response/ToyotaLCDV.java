/*
 * Creation : 4 Oct 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class ToyotaLCDV.
 *
 * @author E534811
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "number", "lcdv24", "extendedAttribute", "wltpStatus", "wltpErrorMsg", "tvv", "type", "category", "toyotaAttribute",
        "toyotaPhysicalResult", "toyotaPhase", "depolDataSet", "toyotaFamilyDetails" })
@XmlRootElement(name = "LCDV")
public class ToyotaLCDV {

    /** The number. */
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String number;

    /** The lcdv 24. */
    @XmlElement(name = "lcdv24", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String lcdv24;

    /** The extended attribute. */
    @XmlElement(name = "ext_att", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String extendedAttribute;

    /** The status. */
    @XmlElement(name = "wltp_status", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String wltpStatus;

    /** The designation. */
    @XmlElement(name = "wltp_error_message", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String wltpErrorMsg;

    /** The tvv. */
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String tvv;

    /** The veh type. */
    @XmlElement(name = "type", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String type;

    /** The category. */
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String category;

    /** The attribute. */
    @XmlElement(name = "attribute", required = true)
    protected List<ToyotaAttribute> toyotaAttribute;

    /** The phys result. */
    @XmlElement(name = "phys_result", required = true)
    protected List<ToyotaPhysicalResult> toyotaPhysicalResult;

    /** The phase. */
    @XmlElement(name = "phase", required = true)
    protected List<ToyotaPhase> toyotaPhase;

    /** The depol data set. */
    @XmlElement(name = "depol_dataset", required = true)
    protected List<ToyotaDepol> depolDataSet;

    @XmlElement(name = "family_dataset", required = true)
    protected List<ToyotaFamilyDetails> toyotaFamilyDetails;

    /**
     * Gets the depol data set.
     *
     * @return the depol data set
     */
    public List<ToyotaDepol> getDepolDataSet() {
        return depolDataSet;
    }

    /**
     * Sets the depol data set.
     *
     * @param depolDataSet the new depol data set
     */
    public void setDepolDataSet(List<ToyotaDepol> depolDataSet) {
        this.depolDataSet = depolDataSet;
    }

    /**
     * Getter number.
     *
     * @return the number
     */
    public String getNumber() {
        return number;
    }

    /**
     * Setter number.
     *
     * @param number the number to set
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * Gets the lcdv 24.
     *
     * @return the lcdv 24
     */
    public String getLcdv24() {
        return lcdv24;
    }

    /**
     * Sets the lcdv 24.
     *
     * @param lcdv24 the new lcdv 24
     */
    public void setLcdv24(String lcdv24) {
        this.lcdv24 = lcdv24;
    }

    /**
     * Gets the extended attribute.
     *
     * @return the extended attribute
     */
    public String getExtendedAttribute() {
        return extendedAttribute;
    }

    /**
     * Sets the extended attribute.
     *
     * @param extendedAttribute the new extended attribute
     */
    public void setExtendedAttribute(String extendedAttribute) {
        this.extendedAttribute = extendedAttribute;
    }

    /**
     * Getter wltpStatus.
     *
     * @return the wltpStatus
     */
    public String getWltpStatus() {
        return wltpStatus;
    }

    /**
     * Setter wltpStatus.
     *
     * @param wltpStatus the wltpStatus to set
     */
    public void setWltpStatus(String wltpStatus) {
        this.wltpStatus = wltpStatus;
    }

    /**
     * Getter wltpErrorMsg.
     *
     * @return the wltpErrorMsg
     */
    public String getWltpErrorMsg() {
        return wltpErrorMsg;
    }

    /**
     * Setter wltpErrorMsg.
     *
     * @param wltpErrorMsg the wltpErrorMsg to set
     */
    public void setWltpErrorMsg(String wltpErrorMsg) {
        this.wltpErrorMsg = wltpErrorMsg;
    }

    /**
     * Getter tvv.
     *
     * @return the tvv
     */
    public String getTvv() {
        return tvv;
    }

    /**
     * Setter tvv.
     *
     * @param tvv the tvv to set
     */
    public void setTvv(String tvv) {
        this.tvv = tvv;
    }

    /**
     * Getter type.
     *
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * Setter type.
     *
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Getter category.
     *
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Setter category.
     *
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Getter toyotaAttribute.
     *
     * @return the toyotaAttribute
     */
    public List<ToyotaAttribute> getToyotaAttribute() {
        return toyotaAttribute;
    }

    /**
     * Setter toyotaAttribute.
     *
     * @param toyotaAttribute the toyotaAttribute to set
     */
    public void setToyotaAttribute(List<ToyotaAttribute> toyotaAttribute) {
        this.toyotaAttribute = toyotaAttribute;
    }

    /**
     * Getter toyotaPhysicalResult.
     *
     * @return the toyotaPhysicalResult
     */
    public List<ToyotaPhysicalResult> getToyotaPhysicalResult() {
        return toyotaPhysicalResult;
    }

    /**
     * Setter toyotaPhysicalResult.
     *
     * @param toyotaPhysicalResult the toyotaPhysicalResult to set
     */
    public void setToyotaPhysicalResult(List<ToyotaPhysicalResult> toyotaPhysicalResult) {
        this.toyotaPhysicalResult = toyotaPhysicalResult;
    }

    /**
     * Getter toyotaPhase.
     *
     * @return the toyotaPhase
     */
    public List<ToyotaPhase> getToyotaPhase() {
        return toyotaPhase;
    }

    /**
     * Setter toyotaPhase.
     *
     * @param toyotaPhase the toyotaPhase to set
     */
    public void setToyotaPhase(List<ToyotaPhase> toyotaPhase) {
        this.toyotaPhase = toyotaPhase;
    }

    /**
     * Getter toyotaFamilyDetails
     * 
     * @return the toyotaFamilyDetails
     */
    public List<ToyotaFamilyDetails> getToyotaFamilyDetails() {
        return toyotaFamilyDetails;
    }

    /**
     * Setter toyotaFamilyDetails
     * 
     * @param toyotaFamilyDetails the toyotaFamilyDetails to set
     */
    public void setToyotaFamilyDetails(List<ToyotaFamilyDetails> toyotaFamilyDetails) {
        this.toyotaFamilyDetails = toyotaFamilyDetails;
    }

    /**
     * Instantiates a new toyota LCDV.
     */
    public ToyotaLCDV() {
        super();
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaLCDV [number=" + number + ", lcdv24=" + lcdv24 + ", extendedAttribute=" + extendedAttribute + ", wltpStatus=" + wltpStatus
                + ", wltpErrorMsg=" + wltpErrorMsg + ", tvv=" + tvv + ", type=" + type + ", category=" + category + ", toyotaAttribute="
                + toyotaAttribute + ", toyotaPhysicalResult=" + toyotaPhysicalResult + ", toyotaPhase=" + toyotaPhase + ", depolDataSet="
                + depolDataSet + ", toyotaFamilyDetails=" + toyotaFamilyDetails + "]";
    }

}
