/**
 * 
 */
package com.inetpsa.w7t.domain.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * @author E534811
 */
@Entity
@Table(name = "W7TQT_MarketingRequestFile")
public class MarketingRequestFile extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "fileID")
    private String fileID;

    @Column(name = "prdcode")
    private String prdcode;

    public String getFileID() {
        return fileID;
    }

    public void setFileID(String fileID) {
        this.fileID = fileID;
    }

    public String getPrdcode() {
        return prdcode;
    }

    public void setPrdcode(String prdcode) {
        this.prdcode = prdcode;
    }

    @Override
    public UUID getEntityId() {
        return this.guid;
    }

}
