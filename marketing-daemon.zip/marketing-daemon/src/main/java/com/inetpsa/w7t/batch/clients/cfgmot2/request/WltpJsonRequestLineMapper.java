/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.util.List;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.MappingJsonFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.JsonLineMapper;

/**
 * The Class WltpJsonRequestLineMapper.
 *
 * @author E534811
 */
public class WltpJsonRequestLineMapper implements LineMapper<List<WltpJsonBatchRequestObject>> {
    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(WltpJsonRequestLineMapper.class);

    /** The delegate. */
    private JsonLineMapper delegate;

    /** The factory. */
    private MappingJsonFactory factory = new MappingJsonFactory();

    /**
     * Interpret the line as a Json object and create a Map from it.
     *
     * @param line the line
     * @param lineNumber the line number
     * @return the list
     * @throws Exception the exception
     * @see LineMapper#mapLine(String, int)
     */

    @SuppressWarnings("unchecked")
    @Override
    public List<WltpJsonBatchRequestObject> mapLine(String line, int lineNumber) throws Exception {
        List<WltpJsonBatchRequestObject> result = null;
        try (JsonParser parser = factory.createJsonParser(line);) {
            List<WltpJsonBatchRequestObject> token = parser.readValueAs(List.class);
            result = token;
        } catch (Exception e) {
            logger.error("Error : {}", e.getMessage());
        }
        return result;
    }

    /**
     * Gets the delegate.
     *
     * @return the delegate
     */
    public JsonLineMapper getDelegate() {
        return delegate;
    }

    /**
     * Sets the delegate.
     *
     * @param delegate the new delegate
     */
    public void setDelegate(JsonLineMapper delegate) {
        this.delegate = delegate;
    }

}
