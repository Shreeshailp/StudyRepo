/*
 * Creation : 24 Aug 2018
 */

package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import java.io.Serializable;

/**
 * The Class CfgMot2JsonAnswerRequest.
 *
 * @author E539598
 */
public class CfgMot2JsonAnswerRequest implements Serializable {

    /** serialVersionUID. */
    private static final long serialVersionUID = 3246670474619406549L;

    /** The version 16 C. */
    private String version16C = "";

    /** The color ext int. */
    private String colorExtInt = "";

    /** The nb options. */
    private String nbOptions = "";

    /** The options 5 C. */
    private String options5C = "";

    /** The options 7 C. */
    private String options7C = "";

    /** The nb gestion. */
    private String nbGestion = "";

    /** The gestion 5 C. */
    private String gestion5C = "";

    /** The gestion 7 C. */
    private String gestion7C = "";

    /** The extension date. */
    private String extensionDate = "";

    /** The mounting center. */
    private String mountingCenter = "";

    /** The request type. */
    private String requestType = "";

    /** The vin. */
    private String vin = "";

    /** The ecom date. */
    private String ecomDate = "";

    /** The trading country. */
    private String tradingCountry = "";

    /** The extended title attributes. */
    private String extendedTitleAttributes = "";

    /**
     * Gets the version 16 C.
     *
     * @return the version 16 C
     */
    public String getVersion16C() {
        return version16C;
    }

    /**
     * Sets the version 16 C.
     *
     * @param version16c the new version 16 C
     */
    public void setVersion16C(String version16c) {
        version16C = version16c;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the nb options.
     *
     * @return the nb options
     */
    public String getNbOptions() {
        return nbOptions;
    }

    /**
     * Sets the nb options.
     *
     * @param nbOptions the new nb options
     */
    public void setNbOptions(String nbOptions) {
        this.nbOptions = nbOptions;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options 7 C.
     *
     * @return the options 7 C
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options 7 C.
     *
     * @param options7c the new options 7 C
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the nb gestion.
     *
     * @return the nb gestion
     */
    public String getNbGestion() {
        return nbGestion;
    }

    /**
     * Sets the nb gestion.
     *
     * @param nbGestion the new nb gestion
     */
    public void setNbGestion(String nbGestion) {
        this.nbGestion = nbGestion;
    }

    /**
     * Gets the gestion 5 C.
     *
     * @return the gestion 5 C
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion 5 C.
     *
     * @param gestion5c the new gestion 5 C
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion 7 C.
     *
     * @return the gestion 7 C
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion 7 C.
     *
     * @param gestion7c the new gestion 7 C
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the mounting center.
     *
     * @return the mounting center
     */
    public String getMountingCenter() {
        return mountingCenter;
    }

    /**
     * Sets the mounting center.
     *
     * @param mountingCenter the new mounting center
     */
    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the vin.
     *
     * @return the vin
     */
    public String getVin() {
        return vin;
    }

    /**
     * Sets the vin.
     *
     * @param vin the new vin
     */
    public void setVin(String vin) {
        this.vin = vin;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the extended title attributes.
     *
     * @return the extended title attributes
     */
    public String getExtendedTitleAttributes() {
        return extendedTitleAttributes;
    }

    /**
     * Sets the extended title attributes.
     *
     * @param extendedTitleAttributes the new extended title attributes
     */
    public void setExtendedTitleAttributes(String extendedTitleAttributes) {
        this.extendedTitleAttributes = extendedTitleAttributes;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CfgMot2JsonAnswerRequest [version16C=" + version16C + ", colorExtInt=" + colorExtInt + ", nbOptions=" + nbOptions + ", options5C="
                + options5C + ", options7C=" + options7C + ", nbGestion=" + nbGestion + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C
                + ", extensionDate=" + extensionDate + ", mountingCenter=" + mountingCenter + ", requestType=" + requestType + ", vin=" + vin
                + ", ecomDate=" + ecomDate + ", tradingCountry=" + tradingCountry + ", extendedTitleAttributes=" + extendedTitleAttributes + "]";
    }

}
