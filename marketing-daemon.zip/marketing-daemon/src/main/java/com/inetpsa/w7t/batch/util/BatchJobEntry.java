/*
 * Creation : 8 juin 2017
 */
package com.inetpsa.w7t.batch.util;

import java.io.File;

import org.seedstack.business.Service;

/**
 * The Interface BatchJobEntry.
 */
@Service
public interface BatchJobEntry {

    /**
     * Run job.
     *
     * @param jobName the job name
     * @param fileLoc the file loc
     */
    public void runJob(String jobName, String fileLoc);

    /**
     * Run job.
     *
     * @param jobName        the job name
     * @param fileLoc        the file loc
     * @param outPutFilename the out put filename
     */
    public void runJob(String jobName, String fileLoc, String outPutFilename);

    /**
     * Run job.
     *
     * @param jobname         the jobname
     * @param absolutePath    the absolute path
     * @param configMo2OutDir the config mo 2 out dir
     */
    public void runJob(String jobname, String absolutePath, File configMo2OutDir);

    /**
     * Run job with file dir and file name.
     *
     * @param jobName           the job name
     * @param fileLoc           the file loc
     * @param outputDirectory   the output directory
     * @param outputfileName    the outputfile name
     * @param processChunkSize  the process chunk size
     * @param clientName        the client name
     * @param uniqueIdentifier  the unique identifier
     * @param fsFlagFileName
     * @param indusFsFlagPath
     * @param devFsFlagFileName
     * @param devFsFlagPath
     */
    public void runJobWithFileDirAndFileName(String jobName, String fileLoc, File outputDirectory, String outputfileName, Long processChunkSize,
            String clientName, String uniqueIdentifier, String fsFlagFileName);

    /**
     * Run job.
     *
     * @param jobName          the job name
     * @param fileLoc          the file loc
     * @param outPutFilename   the out put filename
     * @param clientName       the client name
     * @param processChunkSize the process chunk size
     */
    public void runJob(String jobName, String fileLoc, String outPutFilename, String clientName, Long processChunkSize);

}
