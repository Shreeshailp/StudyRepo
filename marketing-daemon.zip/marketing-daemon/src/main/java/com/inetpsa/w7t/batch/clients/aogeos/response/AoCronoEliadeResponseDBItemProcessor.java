/*
 * Creation : 20 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.response;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestTrackerDTO;

/**
 * The Class AoGeosResponseDBItemProcessor.
 */
public class AoCronoEliadeResponseDBItemProcessor implements ItemProcessor<MarketingRequestTrackerDTO, MarketingRequestAnswerDTO> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The Constant MOVE_CODE_W020. */
    private static final String MOVE_CODE_W020 = "W020";

    /** The Constant MOVE_CODE_W030. */
    private static final String MOVE_CODE_W030 = "W030";

    /** The chunk size. */
    private static final int CHUNK_SIZE = 100;

    /** The Constant jobName. */
    private static final String JOB_NAME = "aoGeosJob";

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public MarketingRequestAnswerDTO process(MarketingRequestTrackerDTO marketingRequestTrackerDTO) throws Exception {
        List<MarketingRequest> allMarketingRequestList = MarkertingDaemonUtility.getMarketingRequestByChunk(marketingRequestTrackerDTO,
                marketingRequestRepository);
        logger.info("The total valid request count for calculation is : {}", allMarketingRequestList.size());
        CopyOnWriteArrayList<AoCronosEliadeDto> aoCronoEliadeAnswerDtoList = new CopyOnWriteArrayList<>();
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);

        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        if (CollectionUtils.isNotEmpty(allMarketingRequestList) && allMarketingRequestList.size() == marketingRequestTrackerDTO.getValidReqCount()) {
            try {
                List<Future<AoCronosEliadeDto>> futuresList = new CopyOnWriteArrayList<>();
                List<List<MarketingRequest>> splitedList = ListUtils.partition(allMarketingRequestList, CHUNK_SIZE);

                for (List<MarketingRequest> list : splitedList) {

                    list.forEach(marketingRequest -> {
                        Future<AoCronosEliadeDto> future = executorService.submit(() -> mapProcess(marketingRequest));
                        futuresList.add(future);
                    });
                }

                for (Future<AoCronosEliadeDto> future : futuresList) {
                    AoCronosEliadeDto aoCronosEliadeDto = future.get();
                    aoCronoEliadeAnswerDtoList.add(aoCronosEliadeDto);
                }
            } catch (Exception e) {
                logger.error("Error when executing parallel request processing for calcualtion", e);
            } finally {
                executorService.shutdown();
            }

            if (!aoCronoEliadeAnswerDtoList.isEmpty()) {
                logger.info("After mapping to AoCronosEliadeDto,Total request count for the FILE ID[{}] is : [{}]",
                        aoCronoEliadeAnswerDtoList.get(0).getFileId(), aoCronoEliadeAnswerDtoList.size());
            }
        } else
            logger.info("Request list is empty");

        MarketingRequestAnswerDTO marketingRequestAnswerDTO = new MarketingRequestAnswerDTO();
        marketingRequestAnswerDTO.setAoCronoEliadeAnswerDto(aoCronoEliadeAnswerDtoList);

        return marketingRequestAnswerDTO;
    }

    private AoCronosEliadeDto mapProcess(MarketingRequest marketingRequest) {
        AoCronosEliadeDto request = new AoCronosEliadeDto();
        try {
            mapRequestRow(marketingRequest, request);
        } catch (Exception e) {
            logger.error("{} : ", e);
        }
        return request;
    }

    public AoCronosEliadeDto mapRequestRow(MarketingRequest marketingRequest, AoCronosEliadeDto request) {

        try {
            String reqId = marketingRequest.getRequestID();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
            Date date = new Date();
            request.setValidityDate(dateFormat.format(date));

            String prd = reqId.substring(0, 3);
            String lotNumber = reqId.substring(3, 8);
            String lineNumber = reqId.substring(8, 20);
            if (StringUtils.isNotBlank(marketingRequest.getRequestID())) {
                request.setRequestId(marketingRequest.getRequestID());
            }
            request.setInternalRequestId(marketingRequest.getInternalReqId());
            request.setVersion16(marketingRequest.getVersion16() == null ? "" : marketingRequest.getVersion16());
            request.setColorExtInt(marketingRequest.getColorExtInt() == null ? "" : marketingRequest.getColorExtInt());
            request.setMomentCode20(MOVE_CODE_W020);
            request.setPrd(prd == null ? "" : prd);
            request.setLotNumber(lotNumber == null ? "" : lotNumber);
            request.setLineNumber(lineNumber == null ? "" : lineNumber);
            request.setBrand(marketingRequest.getBrand() == null ? "" : marketingRequest.getBrand());

            String extentionDate = marketingRequest.getExtensionDate();
            if (!extentionDate.isEmpty() && extentionDate.length() >= 8)
                request.setExtensionDate(extentionDate.replace("-", "").substring(0, 8).trim());
            else
                request.setExtensionDate(extentionDate.replace("-", "").substring(0, extentionDate.length()).trim());

            request.setGestion((marketingRequest.getGestion() == null) ? "" : marketingRequest.getGestion());
            request.setGestion7C((marketingRequest.getGestion7C() == null) ? "" : marketingRequest.getGestion7C());
            request.setOptions((marketingRequest.getOptions() == null) ? "" : marketingRequest.getOptions());
            request.setOptions7C((marketingRequest.getOptions7C() == null) ? "" : marketingRequest.getOptions7C());
            request.setOptions5C((marketingRequest.getOptions5C() == null) ? "" : marketingRequest.getOptions5C());
            request.setTradingCountry((marketingRequest.getTradingCountry() == null) ? "" : marketingRequest.getTradingCountry());
            request.setAnswerCode((marketingRequest.getAnswerCode() == null) ? "" : marketingRequest.getAnswerCode());
            request.setAnswerDesignation((marketingRequest.getAnswerDesig() == null) ? "" : marketingRequest.getAnswerDesig());
            request.setEndDate(MarketingDateUtil.getTodaysDateWithoutTime() == null ? "" : MarketingDateUtil.getTodaysDateWithoutTime());
            request.setRequestId(reqId);
            request.setMomentCode30(MOVE_CODE_W030.trim());
            request.setFileId(marketingRequest.getFileId());
            request.setSendingSite(marketingRequest.getSendingSite());
            request.setSendingApplication(marketingRequest.getSendingApplication());
            request.setHeaderLotNumber(marketingRequest.getLotNumber());
            request.setLotDate(marketingRequest.getLotDate());
            request.setRequestType(marketingRequest.getRequestType());
            request.setStatus(marketingRequest.getStatus());
            request.setAnswerCode(marketingRequest.getAnswerCode());
            request.setAnswerDesignation(marketingRequest.getAnswerDesig());
            request.setAnswerDate(marketingRequest.getAnswerDate());

        } catch (Exception e) {
            logger.error("REQUEST_ID: [{}] - Error in AoCronoEliadeResponseRowMapper : request [{}], [{}]", request.getRequestId(), request, e);
            LogUtility.logTheError(logger, request.getRequestId(), WltpRequestErrorCode.UNKNOWN_EXCEPTION.getRuleCode(),
                    WltpRequestErrorCode.UNKNOWN_EXCEPTION.getDescription());
        }
        return request;
    }

}
