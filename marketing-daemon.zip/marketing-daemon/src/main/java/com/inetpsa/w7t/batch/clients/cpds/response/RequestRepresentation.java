/*
 * Creation : 9 août 2017
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

/**
 * The Class RequestRepresentation.
 */
public class RequestRepresentation {

    /** The request. */
    private CpdsRequestsRepresentations request;

    /**
     * Instantiates a new request representation.
     */
    public RequestRepresentation() {
        super();
    }

    /**
     * Gets the request.
     *
     * @return the request
     */
    public CpdsRequestsRepresentations getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(CpdsRequestsRepresentations request) {
        this.request = request;
    }

}
