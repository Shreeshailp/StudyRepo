/*
 * Creation : 10 Jul 2018
 */
package com.inetpsa.w7t.domain.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "LCDV")
public class ToyotaFileRequestLstXML {

    /** The number. */
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String number;

    /** The country. */
    @XmlElement(required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String country;

    /** The extension date. */
    @XmlElement(name = "extension_date", required = true)
    protected String extensionDate;

    /** The request type. */
    @XmlElement(name = "request_type", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String requestType;

    /** The version and color. */
    @XmlElement(required = true, name = "LCDV24")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NMTOKEN")
    protected String versionAndColor;

    @XmlElement(required = true, name = "PATT1")
    protected String patt1;
    @XmlElement(required = true, name = "PATT2")
    protected String patt2;
    @XmlElement(required = true, name = "PATT3")
    protected String patt3;
    @XmlElement(required = true, name = "PATT4")
    protected String patt4;
    @XmlElement(required = true, name = "PATT5")
    protected String patt5;
    @XmlElement(required = true, name = "PATT6")
    protected String patt6;
    @XmlElement(required = true, name = "PATT7")
    protected String patt7;
    @XmlElement(required = true, name = "PATT8")
    protected String patt8;
    @XmlElement(required = true, name = "PATT9")
    protected String patt9;
    @XmlElement(required = true, name = "PATT10")
    protected String patt10;

    @XmlElement(required = true, name = "PATT11")
    protected String patt11;
    @XmlElement(required = true, name = "PATT12")
    protected String patt12;
    @XmlElement(required = true, name = "PATT13")
    protected String patt13;
    @XmlElement(required = true, name = "PATT14")
    protected String patt14;
    @XmlElement(required = true, name = "PATT15")
    protected String patt15;
    @XmlElement(required = true, name = "PATT16")
    protected String patt16;
    @XmlElement(required = true, name = "PATT17")
    protected String patt17;
    @XmlElement(required = true, name = "PATT18")
    protected String patt18;
    @XmlElement(required = true, name = "PATT19")
    protected String patt19;
    @XmlElement(required = true, name = "PATT20")
    protected String patt20;

    @XmlElement(required = true, name = "PATT21")
    protected String patt21;
    @XmlElement(required = true, name = "PATT22")
    protected String patt22;
    @XmlElement(required = true, name = "PATT23")
    protected String patt23;
    @XmlElement(required = true, name = "PATT24")
    protected String patt24;
    @XmlElement(required = true, name = "PATT25")
    protected String patt25;
    @XmlElement(required = true, name = "PATT26")
    protected String patt26;
    @XmlElement(required = true, name = "PATT27")
    protected String patt27;
    @XmlElement(required = true, name = "PATT28")
    protected String patt28;
    @XmlElement(required = true, name = "PATT29")
    protected String patt29;
    @XmlElement(required = true, name = "PATT30")
    protected String patt30;

    @XmlElement(required = true, name = "PATT31")
    protected String patt31;
    @XmlElement(required = true, name = "PATT32")
    protected String patt32;
    @XmlElement(required = true, name = "PATT33")
    protected String patt33;
    @XmlElement(required = true, name = "PATT34")
    protected String patt34;
    @XmlElement(required = true, name = "PATT35")
    protected String patt35;
    @XmlElement(required = true, name = "PATT36")
    protected String patt36;
    @XmlElement(required = true, name = "PATT37")
    protected String patt37;
    @XmlElement(required = true, name = "PATT38")
    protected String patt38;
    @XmlElement(required = true, name = "PATT39")
    protected String patt39;
    @XmlElement(required = true, name = "PATT40")
    protected String patt40;

    /**
     * Gets the value of the number property.
     * 
     * @return possible object is {@link String }
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setNumber(String value) {
        this.number = value;
    }

    /**
     * Gets the version and color.
     *
     * @return the version and color
     */
    public String getVersionAndColor() {
        return versionAndColor;
    }

    /**
     * Sets the version and color.
     *
     * @param versionAndColor the new version and color
     */
    public void setVersionAndColor(String versionAndColor) {
        this.versionAndColor = versionAndColor;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return possible object is {@link String }
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the value of the extensionDate property.
     * 
     * @return possible object is {@link String }
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the value of the extensionDate property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setExtensionDate(String value) {
        this.extensionDate = value;
    }

    /**
     * Gets the value of the requestType property.
     * 
     * @return possible object is {@link String }
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     * @param value allowed object is {@link String }
     */
    public void setRequestType(String value) {
        this.requestType = value;
    }

    public String getPatt1() {
        return patt1;
    }

    public void setPatt1(String patt1) {
        this.patt1 = patt1;
    }

    public String getPatt2() {
        return patt2;
    }

    public void setPatt2(String patt2) {
        this.patt2 = patt2;
    }

    public String getPatt3() {
        return patt3;
    }

    public void setPatt3(String patt3) {
        this.patt3 = patt3;
    }

    public String getPatt4() {
        return patt4;
    }

    public void setPatt4(String patt4) {
        this.patt4 = patt4;
    }

    public String getPatt5() {
        return patt5;
    }

    public void setPatt5(String patt5) {
        this.patt5 = patt5;
    }

    public String getPatt6() {
        return patt6;
    }

    public void setPatt6(String patt6) {
        this.patt6 = patt6;
    }

    public String getPatt7() {
        return patt7;
    }

    public void setPatt7(String patt7) {
        this.patt7 = patt7;
    }

    public String getPatt8() {
        return patt8;
    }

    public void setPatt8(String patt8) {
        this.patt8 = patt8;
    }

    public String getPatt9() {
        return patt9;
    }

    public void setPatt9(String patt9) {
        this.patt9 = patt9;
    }

    public String getPatt10() {
        return patt10;
    }

    public void setPatt10(String patt10) {
        this.patt10 = patt10;
    }

    public String getPatt11() {
        return patt11;
    }

    public void setPatt11(String patt11) {
        this.patt11 = patt11;
    }

    public String getPatt12() {
        return patt12;
    }

    public void setPatt12(String patt12) {
        this.patt12 = patt12;
    }

    public String getPatt13() {
        return patt13;
    }

    public void setPatt13(String patt13) {
        this.patt13 = patt13;
    }

    public String getPatt14() {
        return patt14;
    }

    public void setPatt14(String patt14) {
        this.patt14 = patt14;
    }

    public String getPatt15() {
        return patt15;
    }

    public void setPatt15(String patt15) {
        this.patt15 = patt15;
    }

    public String getPatt16() {
        return patt16;
    }

    public void setPatt16(String patt16) {
        this.patt16 = patt16;
    }

    public String getPatt17() {
        return patt17;
    }

    public void setPatt17(String patt17) {
        this.patt17 = patt17;
    }

    public String getPatt18() {
        return patt18;
    }

    public void setPatt18(String patt18) {
        this.patt18 = patt18;
    }

    public String getPatt19() {
        return patt19;
    }

    public void setPatt19(String patt19) {
        this.patt19 = patt19;
    }

    public String getPatt20() {
        return patt20;
    }

    public void setPatt20(String patt20) {
        this.patt20 = patt20;
    }

    public String getPatt21() {
        return patt21;
    }

    public void setPatt21(String patt21) {
        this.patt21 = patt21;
    }

    public String getPatt22() {
        return patt22;
    }

    public void setPatt22(String patt22) {
        this.patt22 = patt22;
    }

    public String getPatt23() {
        return patt23;
    }

    public void setPatt23(String patt23) {
        this.patt23 = patt23;
    }

    public String getPatt24() {
        return patt24;
    }

    public void setPatt24(String patt24) {
        this.patt24 = patt24;
    }

    public String getPatt25() {
        return patt25;
    }

    public void setPatt25(String patt25) {
        this.patt25 = patt25;
    }

    public String getPatt26() {
        return patt26;
    }

    public void setPatt26(String patt26) {
        this.patt26 = patt26;
    }

    public String getPatt27() {
        return patt27;
    }

    public void setPatt27(String patt27) {
        this.patt27 = patt27;
    }

    public String getPatt28() {
        return patt28;
    }

    public void setPatt28(String patt28) {
        this.patt28 = patt28;
    }

    public String getPatt29() {
        return patt29;
    }

    public void setPatt29(String patt29) {
        this.patt29 = patt29;
    }

    public String getPatt30() {
        return patt30;
    }

    public void setPatt30(String patt30) {
        this.patt30 = patt30;
    }

    public String getPatt31() {
        return patt31;
    }

    public void setPatt31(String patt31) {
        this.patt31 = patt31;
    }

    public String getPatt32() {
        return patt32;
    }

    public void setPatt32(String patt32) {
        this.patt32 = patt32;
    }

    public String getPatt33() {
        return patt33;
    }

    public void setPatt33(String patt33) {
        this.patt33 = patt33;
    }

    public String getPatt34() {
        return patt34;
    }

    public void setPatt34(String patt34) {
        this.patt34 = patt34;
    }

    public String getPatt35() {
        return patt35;
    }

    public void setPatt35(String patt35) {
        this.patt35 = patt35;
    }

    public String getPatt36() {
        return patt36;
    }

    public void setPatt36(String patt36) {
        this.patt36 = patt36;
    }

    public String getPatt37() {
        return patt37;
    }

    public void setPatt37(String patt37) {
        this.patt37 = patt37;
    }

    public String getPatt38() {
        return patt38;
    }

    public void setPatt38(String patt38) {
        this.patt38 = patt38;
    }

    public String getPatt39() {
        return patt39;
    }

    public void setPatt39(String patt39) {
        this.patt39 = patt39;
    }

    public String getPatt40() {
        return patt40;
    }

    public void setPatt40(String patt40) {
        this.patt40 = patt40;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaFileRequestLstXML [number=" + number + ", country=" + country + ", extensionDate=" + extensionDate + ", requestType="
                + requestType + ", versionAndColor=" + versionAndColor + ", patt1=" + patt1 + ", patt2=" + patt2 + ", patt3=" + patt3 + ", patt4="
                + patt4 + ", patt5=" + patt5 + ", patt6=" + patt6 + ", patt7=" + patt7 + ", patt8=" + patt8 + ", patt9=" + patt9 + ", patt10="
                + patt10 + ", patt11=" + patt11 + ", patt12=" + patt12 + ", patt13=" + patt13 + ", patt14=" + patt14 + ", patt15=" + patt15
                + ", patt16=" + patt16 + ", patt17=" + patt17 + ", patt18=" + patt18 + ", patt19=" + patt19 + ", patt20=" + patt20 + ", patt21="
                + patt21 + ", patt22=" + patt22 + ", patt23=" + patt23 + ", patt24=" + patt24 + ", patt25=" + patt25 + ", patt26=" + patt26
                + ", patt27=" + patt27 + ", patt28=" + patt28 + ", patt29=" + patt29 + ", patt30=" + patt30 + ", patt31=" + patt31 + ", patt32="
                + patt32 + ", patt33=" + patt33 + ", patt34=" + patt34 + ", patt35=" + patt35 + ", patt36=" + patt36 + ", patt37=" + patt37
                + ", patt38=" + patt38 + ", patt39=" + patt39 + ", patt40=" + patt40 + "]";
    }

}
