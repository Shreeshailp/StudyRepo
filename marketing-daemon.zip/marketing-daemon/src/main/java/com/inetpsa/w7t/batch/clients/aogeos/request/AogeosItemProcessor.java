/*
 * Creation : 14 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;

import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.shared.TranscodificationUtility;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;
import com.inetpsa.w7t.domains.references.model.ClientParameter;
import com.inetpsa.w7t.domains.references.model.Country;

/**
 * The Class AoGeosItemProcessor.
 */
public class AogeosItemProcessor implements ItemProcessor<AogeosRequestDTO, AogeosRequestDTO>, StepExecutionListener {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /** The line number. */
    private volatile int lineNumber;

    /** The Constant FIVE. */
    private static final int FIVE = 5;

    /** The last movement code. */
    private String lastMovementCode;

    /** The Constant STATUS_CHANGE_LOG. */
    private static final String STATUS_CHANGE_LOG = "Marketing Request =[{}], Old status=[{}], New status=[{}]";

    /** The Constant ERROR_LOG. */
    public static final String ERROR_LOG = "Marketing Request ({}) - {}";

    /** The Constant lineLentgh. */
    public static final int LINE_LENGTH = 787;

    /** The Constant EXTENTION_DATE_FORMAT. */
    public static final String EXTENTION_DATE_FORMAT = "yyyyMMdd";

    /** The Constant OPTION7C. */
    public static final String OPTION7C = "Y";

    /** The Constant OPTION5C. */
    public static final String OPTION5C = "N";

    /** The Constant GESTION7C. */
    public static final String GESTION7C = "Y";

    /** The Constant GESTION5C. */
    public static final String GESTION5C = "N";

    /** The Constant TWENTY_ONE. */
    public static final int TWENTY_ONE = 21;

    /** The Constant THERTY. */
    public static final int THERTY = 30;

    /** The Constant THERTY_EIGHT. */
    public static final int THERTY_EIGHT = 38;

    /** The Constant FORTY_THREE. */
    public static final int FORTY_THREE = 43;

    /** The Constant FIFTY_ONE. */
    public static final int FIFTY_ONE = 51;

    /** The Constant SEVEN. */
    private static final int SEVEN = 7;

    /** The Constant TWO. */
    private static final int TWO = 2;

    /** The Constant SIXTEEN. */
    private static final int SIXTEEN = 16;

    /** The Constant FOUR. */
    private static final int FOUR = 4;

    /** The Constant THREE. */
    private static final int THREE = 3;

    /** The Constant TWELVE. */
    private static final int TWELVE = 12;

    /** The Constant ONE. */
    private static final int ONE = 1;

    /** The job execution status. */
    Boolean jobExecutionStatus = true;

    /** The valid country with destinations. */
    private List<String> validCountryWithDestinations = new ArrayList<>();

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /** The Constant MARKETING_REQ_LOG. */
    private static final String MARKETING_REQ_LOG = "Marketing Request =[{}]";

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /** The client parameter repository. */
    @Inject
    private ClientParameterFinder clientPrameterFinder;

    /** The destination country repository. */
    @Inject
    private DestinationCountryRepository destinationCountryRepository;

    /** The thread local line number. */
    private static ThreadLocal<Integer> threadLocalLineNumber = new ThreadLocal<>();

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public AogeosRequestDTO process(@Valid AogeosRequestDTO item) throws Exception {
        this.lastMovementCode = item.getMovementCode();

        if (jobExecutionStatus) {
            lineNumber++;
            threadLocalLineNumber.set(lineNumber);
            try {
                if (!isEmptyLine(item)) {

                    if (("0000").equalsIgnoreCase(item.getMovementCode())) {
                        String header = item.getMovementCode() + item.getPrd() + item.getLotNumber() + item.getLineNumber() + item.getBrand()
                                + item.getCountry() + item.getVersion() + item.getHabillage_Ext() + item.getHabillage_Int();

                        AogeosHeaderDTO headerDTO = new AogeosHeaderDTO();
                        headerDTO.setSendingSite(header.substring(TWENTY_ONE, THERTY));
                        headerDTO.setSendingApplication(header.substring(THERTY, THERTY_EIGHT));
                        headerDTO.setBatchNumber(header.substring(THERTY_EIGHT, FORTY_THREE));
                        headerDTO.setBatchCreationDate(header.substring(FORTY_THREE, FIFTY_ONE));
                        logger.info("Header with details== SendingSite : {}, SendingApplication : {}, BatchNumber : {}, BatchCreationDate : {}",
                                headerDTO.getSendingSite(), headerDTO.getSendingApplication(), headerDTO.getBatchNumber(),
                                headerDTO.getBatchCreationDate());
                        MarketingDaemonServiceUtils.setAogeosHeader(item.getFileId(), headerDTO);

                    }

                    if (lineNumber == ONE) {
                        validCountryWithDestinations = MarkertingDaemonUtility.initializeValidCountries(countryRepository,
                                destinationCountryRepository);
                        logger.info("Header Line : {}", lineNumber);
                    } else if (("W010").equalsIgnoreCase(item.getMovementCode())) {

                        if (MarketingDaemonServiceUtils.getAogeosHeader(item.getFileId()) != null) {
                            AogeosHeaderDTO aogeosHeaderDTO = MarketingDaemonServiceUtils.getAogeosHeader(item.getFileId());
                            item.setSendingSite(aogeosHeaderDTO.getSendingSite());
                            item.setSendingApplication(aogeosHeaderDTO.getSendingApplication());
                            item.setHeaderLotNumber(aogeosHeaderDTO.getBatchNumber());
                            item.setLotDate(aogeosHeaderDTO.getBatchCreationDate());
                            MaturityCheckUtility.insertUnknownPattern(logger, item.getVersion(), MarketingDaemonServiceConstants.AOGEOS.toUpperCase(),
                                    maturityRepository);

                        } else
                            logger.info("Aogeos header details are empty for File Id : {}", item.getFileId());

                        return validateRequest(item, lineNumber);

                    } else if (("9999").equalsIgnoreCase(item.getMovementCode())) {
                        logger.info("Footer Line : {}", lineNumber);
                    } else if (!item.getMovementCode().equalsIgnoreCase("0000") && !("9999").equalsIgnoreCase(item.getMovementCode())
                            && !("W010").equalsIgnoreCase(item.getMovementCode())) {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getRuleCode(),
                                WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getDescription());
                    }
                } else if (lineNumber == ONE) {
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(), WltpRequestErrorCode.INCORRECT_FILE.getDescription());
                }

            } catch (EmptyResultDataAccessException e) {
                // fixed jira-551
                logger.info(MARKETING_REQ_LOG, item);
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(),
                        WltpRequestErrorCode.INCORRECT_FILE.getDescription());

            } catch (Exception e) {
                logger.error("Exception parsing at line {}. Failed record from file: {} ", lineNumber, item, e);
            }
        }
        return null;
    }

    /**
     * Validate request.
     *
     * @param aoGeosRequestResponseDTO the ao geos request response DTO
     * @param lineNumber               the line number
     * @return the ao geos request response DTO
     */
    private AogeosRequestDTO validateRequest(AogeosRequestDTO aoGeosRequestResponseDTO, int lineNumber) {
        if (aoGeosRequestResponseDTO.getStatus() == null && isValidRequest(aoGeosRequestResponseDTO, lineNumber)) {
            aoGeosRequestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
            logger.info("REQUEST ID [{}] - Status Code changed to :{} ", aoGeosRequestResponseDTO.getRequestId(),
                    MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());
        } else {
            aoGeosRequestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            logger.info("REQUEST ID [{}] - Status Code changed to :{} ", aoGeosRequestResponseDTO.getRequestId(),
                    MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
        }
        return aoGeosRequestResponseDTO;
    }

    /**
     * Checks if is valid request.
     *
     * @param aoGeosRequestResponseDTO the ao geos request response DTO
     * @param lineNumber               the line number
     * @return true, if is valid request
     */
    private boolean isValidRequest(@Valid AogeosRequestDTO aoGeosRequestResponseDTO, int lineNumber) {

        AogeosRequestDTO requestResponseDTO = verifyAoGeosData(aoGeosRequestResponseDTO, lineNumber);

        if (requestResponseDTO.getStatus() != null
                && requestResponseDTO.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode())))
            return false;

        /** validate country, Characteristic and destination */
        try {
            if (!requestResponseDTO.getCountry().isEmpty()) {
                if (!validCountryWithDestinations.contains(requestResponseDTO.getCountry())) {
                    requestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(requestResponseDTO, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                    LogUtility.logTheError(logger, aoGeosRequestResponseDTO.getRequestId(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                            WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                    return false;
                }
            } else {
                requestResponseDTO.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(requestResponseDTO, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                logger.error(ERROR_LOG, requestResponseDTO, AoCronoRequestErrorCode.COUNTRY_CODE_INCORRECT);
                return false;
            }
        } catch (Exception e) {
            logger.error("Excpetion : {}", e);
        }

        logger.info(STATUS_CHANGE_LOG, requestResponseDTO, MarketingRequestStatusEnum.REQUEST_RECEIVED.getStatusCode(),
                MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode());
        /**
         * Step M4: Constitution of the list of individual marketing vehicles
         */

        return true;
    }

    /**
     * Verify ao geos data.
     *
     * @param item       the item
     * @param lineNumber the line number
     * @return the ao geos request response DTO
     */
    private AogeosRequestDTO verifyAoGeosData(AogeosRequestDTO item, int lineNumber) {
        String gestion7c = null;

        try {
            if (lineNumber == ONE && !("0000").equalsIgnoreCase(item.getMovementCode())) {
                logger.info("REQUEST_ID[{}], Line Number[{}],  MovementCode[{}]", item.getRequestId(), lineNumber, item.getMovementCode());
                if (!("W010").equalsIgnoreCase(item.getMovementCode().trim())) {// Added this if block as part of JIRA-739 fix
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getRuleCode(),
                            WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getDescription());
                    LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getRuleCode(),
                            WltpRequestErrorCode.INCORRECT_MOMENT_CODE.getDescription());
                }

            }
            if (item.getPrd() == null || item.getPrd().isEmpty() || item.getPrd().length() != THREE) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.PRD_CODE_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.PRD_CODE_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.PRD_CODE_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.PRD_CODE_INCORRECT.getDescription());
            }
            if (item.getLotNumber() == null || item.getLotNumber().isEmpty() || item.getLotNumber().length() != FIVE) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                item.setLotNumber("");
                setErrorDetails(item, WltpRequestErrorCode.LOTNUMBER_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.LOTNUMBER_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.LOTNUMBER_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.LOTNUMBER_INCORRECT.getDescription());
            }
            if (item.getLineNumber() == null || item.getLineNumber().isEmpty() || item.getLineNumber().length() != TWELVE) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.LINENUMBER_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.LINENUMBER_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.LINENUMBER_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.LINENUMBER_INCORRECT.getDescription());
            }

            if (item.getBrand() == null || item.getBrand().isEmpty() || item.getBrand().length() != TWO) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.BRAND_INCORRECT.getRuleCode(), WltpRequestErrorCode.BRAND_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.BRAND_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.BRAND_INCORRECT.getDescription());
            }

            if (item.getVersion() == null || item.getVersion().isEmpty() || item.getVersion().length() != SIXTEEN) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
            }
            if (item.getHabillage_Ext() == null || item.getHabillage_Ext().isEmpty() || item.getHabillage_Ext().length() != FOUR) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.HABILLAGE_EXT_INCORRECT.getDescription());

            }
            if (item.getHabillage_Int() == null || item.getHabillage_Int().isEmpty() || item.getHabillage_Int().length() != FOUR) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.HABILLAGE_INT_INCORRECT.getDescription());
            }
            if (!item.getExtensionDate().isEmpty() && !item.getExtensionDate().matches("([0-9]{8})")) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.EXT_DATE_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.EXT_DATE_INCORRECT.getDescription());
            }

            ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
            if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
                if (!isNullOrEMPTY(item.getOptions7c())) {
                    if (item.getOptions7c().length() % SEVEN == 0) {
                        item.setOptions(String.valueOf(item.getOptions7c().length() / SEVEN));
                        item.setOptions7c(item.getOptions7c());

                    } else {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                    }

                }
            } else {
                option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
                if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !isNullOrEMPTY(item.getOptions7c())) {
                    item.setOptions5C(item.getOptions7c().replace(" ", ""));
                    if (item.getOptions5C().length() % FIVE == 0) {
                        item.setOptions5C(item.getOptions5C());
                        item.setOptions(String.valueOf(item.getOptions5C().length() / FIVE));
                        item.setOptions7c("");
                    } else {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                    }
                }

            }
            // Commented the below code as part of JIRA-782 Fix

//            item.setOptions((!isNullOrEMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
//                    ? String.valueOf(item.getOptions7c().length() / SEVEN)
//                    : "");

            ClientParameter gestion7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), GESTION7C);

            if (gestion7CFlagObj != null && "Y".equals(gestion7CFlagObj.getFlag7c())) {
                gestion7c = TranscodificationUtility.getGestionAsBlockOf7(item.getGestion7c());
                if (!isNullOrEMPTY(gestion7c)) {

                    if (gestion7c.length() % SEVEN == 0) {
                        item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
                    } else {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.GESTION_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.GESTION_7C_INCORRECT.getDescription());
                        LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.GESTION_7C_INCORRECT.getDescription());
                    }
                }
            } else {
                gestion7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), GESTION5C);

                if (gestion7CFlagObj != null && "N".equals(gestion7CFlagObj.getFlag7c())) {
                    String gestion5c = TranscodificationUtility.getGestionAsBlockOf5(item.getGestion7c());
                    if (!isNullOrEMPTY(gestion5c)) {
                        item.setGestion5c(gestion5c);
                        if (gestion5c.length() % FIVE == 0) {
                            try {
                                gestion7c = TranscodificationUtility.transcodify(gestion5c, item.getRequestId());
                                if (gestion7c != null) {
                                    item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
                                    item.setGestion7c(gestion7c);
                                }
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.GESTION_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.GESTION_5C_INCORRECT.getDescription());
                        }
                    }
                }

            }
            if (!isNullOrEMPTY(gestion7c) && gestion7c.length() % SEVEN == 0) {
                item.setGestion(String.valueOf(gestion7c.length() / SEVEN));
            } else {
                item.setGestion("");
            }

            if (item.getCountry() == null || item.getCountry().isEmpty() || item.getCountry().length() != TWO) {
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());

            }

        } catch (Exception e) {
            logger.error("Request ID[{}]: Error in AoCronoEliade Processor : {}", item.getRequestId(), e.getMessage());
        }
        return item;
    }

    /**
     * Checks if is null or EMPTY.
     *
     * @param value the value
     * @return true, if is null or EMPTY
     */
    private boolean isNullOrEMPTY(String value) {
        boolean isInvalid = false;
        if (value == null || value.isEmpty()) {
            isInvalid = true;
        }
        return isInvalid;
    }

    /**
     * Sets the error details.
     *
     * @param mrq         the mrq
     * @param ruleCode    the rule code
     * @param description the description
     */
    private void setErrorDetails(AogeosRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        logger.info(MARKETING_REQ_LOG, mrq);
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Checks if is empty line.
     *
     * @param item the item
     * @return true, if is empty line
     */
    private boolean isEmptyLine(AogeosRequestDTO item) {
        return (item.getMovementCode() + item.getBrand() + item.getCountry() + item.getExtensionDate() + item.getGestion() + item.getHabillage_Ext()
                + item.getHabillage_Int() + item.getLineNumber() + item.getLineNumber() + item.getLotNumber() + item.getOptions() + item.getPrd()
                + item.getVersion() + item.getFiller()).length() == 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#beforeStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public void beforeStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#afterStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);
        if (stepExecution.getReadCount() == 0 || !("9999").equalsIgnoreCase(lastMovementCode))
            logger.error("Incorrect AoGeos file");
        return null;
    }

    /**
     * Gets the country by code.
     *
     * @param countryCode the country code
     * @return the country by code
     */
    Optional<Country> getCountryByCode(String countryCode) {
        return countryRepository.byCode(countryCode);
    }

}
