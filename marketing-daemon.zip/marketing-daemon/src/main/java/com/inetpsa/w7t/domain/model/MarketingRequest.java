/**
 * 
 */
package com.inetpsa.w7t.domain.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;

/**
 * @author E534811
 */
@Entity
@Table(name = "W7TQTMRQ")
public class MarketingRequest extends BaseAggregateRoot<String> implements Serializable {

    private static final long serialVersionUID = -5896575466967223262L;

    /** The guid. */
    // @Identity(handler = UUIDHandler.class)
    // @Id
    // @Type(type = "uuid-char")
    // @Column(name = "ID")
    // private UUID guid;

    @Id
    @Column(name = "INTERNAL_REQUEST_ID")
    private String internalReqId = "";

    @Column(name = "REQUEST_ID")
    private String requestID = "";

    @Column(name = "ANSWER_DATE")
    private String answerDate = "";

    @Column(name = "ANSWER_CODE")
    private String answerCode = "";

    @Column(name = "ANSWER_DESIG")
    private String answerDesig = "";

    @Column(name = "VERSION16")
    private String Version16 = "";

    @Column(name = "COLOR_EXT_INT")
    private String colorExtInt = "";

    @Column(name = "OPTIONS")
    private String options = "";

    @Column(name = "OPTIONS5C")
    private String options5C = "";

    @Column(name = "OPTIONS7C")
    private String options7C = "";

    @Column(name = "GESTION5C")
    private String gestion5C = "";

    @Column(name = "GESTION7C")
    private String gestion7C = "";

    @Column(name = "TRADING_COUNTRY")
    private String tradingCountry = "";

    @Column(name = "BRAND")
    private String brand = "";

    @Column(name = "EXTENSION_DATE")
    private String extensionDate = "";

    @Column(name = "REQUEST_TYPE")
    private String requestType = "";

    @Column(name = "REQUEST_DATE")
    private String requestDate = "";

    @Column(name = "MOUNTING_CENTER")
    private String mountingCenter = "";

    @Column(name = "GESTION")
    private String gestion = "";

    @Column(name = "STATUS")
    private String status = "";

    @Column(name = "IS_ANSWER_SENT", columnDefinition = "tinyint(1) default 0")
    private Boolean isAnswerSent = false;

    @Column(name = "CLIENT")
    private String client = "";

    @Column(name = "FILE_ID")
    private String fileId = "";

    @Column(name = "SENDING_SITE")
    private String sendingSite = "";

    @Column(name = "SENDING_APPLICATION")
    private String sendingApplication = "";

    @Column(name = "LOT_NUMBER")
    private String lotNumber = "";

    @Column(name = "LOT_DATE")
    private String lotDate = "";

    @Column(name = "MATURITY")
    private String maturity = "";

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    public String getInternalReqId() {
        return internalReqId;
    }

    public void setInternalReqId(String internalReqId) {
        this.internalReqId = internalReqId;
    }

    public String getSendingSite() {
        return sendingSite;
    }

    public void setSendingSite(String sendingSite) {
        this.sendingSite = sendingSite;
    }

    public String getSendingApplication() {
        return sendingApplication;
    }

    public void setSendingApplication(String sendingApplication) {
        this.sendingApplication = sendingApplication;
    }

    public String getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    public String getLotDate() {
        return lotDate;
    }

    public void setLotDate(String lotDate) {
        this.lotDate = lotDate;
    }

    public String getRequestID() {
        return requestID;
    }

    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    public String getVersion16() {
        return Version16;
    }

    public void setVersion16(String version16) {
        Version16 = version16;
    }

    public String getColorExtInt() {
        return colorExtInt;
    }

    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public String getOptions5C() {
        return options5C;
    }

    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    public String getOptions7C() {
        return options7C;
    }

    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    public String getGestion5C() {
        return gestion5C;
    }

    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    public String getGestion7C() {
        return gestion7C;
    }

    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    public String getTradingCountry() {
        return tradingCountry;
    }

    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getExtensionDate() {
        return extensionDate;
    }

    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getMountingCenter() {
        return mountingCenter;
    }

    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    public String getGestion() {
        return gestion;
    }

    public void setGestion(String gestion) {
        this.gestion = gestion;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isAnswerSent() {
        return isAnswerSent;
    }

    public void setAnswerSent(boolean isAnswerSent) {
        this.isAnswerSent = isAnswerSent;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public MarketingRequest() {

    }

    /**
     * Getter answerDate
     * 
     * @return the answerDate
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Setter answerDate
     * 
     * @param answerDate the answerDate to set
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Getter answerCode
     * 
     * @return the answerCode
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Setter answerCode
     * 
     * @param answerCode the answerCode to set
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Getter answerDesig
     * 
     * @return the answerDesig
     */
    public String getAnswerDesig() {
        return answerDesig;
    }

    /**
     * Setter answerDesig
     * 
     * @param answerDesig the answerDesig to set
     */
    public void setAnswerDesig(String answerDesig) {
        this.answerDesig = answerDesig;
    }

    public MarketingRequest(String internalReqId, String requestID, String answerDate, String answerCode, String answerDesig, String version16,
            String colorExtInt, String options, String options5c, String options7c, String gestion5c, String gestion7c, String tradingCountry,
            String brand, String extensionDate, String requestType, String requestDate, String mountingCenter, String gestion, String status,
            Boolean isAnswerSent, String client, String fileId, String sendingSite, String sendingApplication, String lotNumber, String lotDate,
            String maturity) {
        super();
        this.internalReqId = internalReqId;
        this.requestID = requestID;
        this.answerDate = answerDate;
        this.answerCode = answerCode;
        this.answerDesig = answerDesig;
        Version16 = version16;
        this.colorExtInt = colorExtInt;
        this.options = options;
        options5C = options5c;
        options7C = options7c;
        gestion5C = gestion5c;
        gestion7C = gestion7c;
        this.tradingCountry = tradingCountry;
        this.brand = brand;
        this.extensionDate = extensionDate;
        this.requestType = requestType;
        this.requestDate = requestDate;
        this.mountingCenter = mountingCenter;
        this.gestion = gestion;
        this.status = status;
        this.isAnswerSent = isAnswerSent;
        this.client = client;
        this.fileId = fileId;
        this.sendingSite = sendingSite;
        this.sendingApplication = sendingApplication;
        this.lotNumber = lotNumber;
        this.lotDate = lotDate;
        this.maturity = maturity;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MarketingRequest [internalReqId=" + internalReqId + ", requestID=" + requestID + ", answerDate=" + answerDate + ", answerCode="
                + answerCode + ", answerDesig=" + answerDesig + ", Version16=" + Version16 + ", colorExtInt=" + colorExtInt + ", options=" + options
                + ", options5C=" + options5C + ", options7C=" + options7C + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C
                + ", tradingCountry=" + tradingCountry + ", brand=" + brand + ", extensionDate=" + extensionDate + ", requestType=" + requestType
                + ", requestDate=" + requestDate + ", mountingCenter=" + mountingCenter + ", gestion=" + gestion + ", status=" + status
                + ", isAnswerSent=" + isAnswerSent + ", client=" + client + ", fileId=" + fileId + ", sendingSite=" + sendingSite
                + ", sendingApplication=" + sendingApplication + ", lotNumber=" + lotNumber + ", lotDate=" + lotDate + ", maturity=" + maturity + "]";
    }

    @Override
    public String getEntityId() {
        return this.requestID;
    }

}
