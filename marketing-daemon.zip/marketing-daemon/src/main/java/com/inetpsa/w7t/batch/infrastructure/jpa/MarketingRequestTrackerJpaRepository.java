/*
 * Creation : 7 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.infrastructure.jpa;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;

import edu.emory.mathcs.backport.java.util.Collections;

/**
 * The Class MarketingRequestTrackerJpaRepository.
 *
 * @author E534811
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MarketingRequestTrackerJpaRepository extends BaseJpaRepository<MarketingRequestTracker, String>
        implements MarketingRequestTrackerRepository {

    /** The Constant UPDATED_DATE. */
    private static final String UPDATED_DATE = "updatedDate";

    /** The Constant ANSWER_GENERATED. */
    private static final String ANSWER_GENERATED = "answerGenerated";

    /** The Constant FILE_ID. */
    private static final String FILE_ID = "fileId";

    /** The Constant VALID_REQ_COUNT. */
    private static final String VALID_REQ_COUNT = "validReqCount";

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#saveEntity(com.inetpsa.w7t.domain.model.MarketingRequestTracker)
     */
    @Override
    public void saveEntity(MarketingRequestTracker marketingRequestTracker) {
        entityManager.merge(marketingRequestTracker);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#updateEntity(com.inetpsa.w7t.domain.model.MarketingRequestTracker)
     */
    @Override
    public void updateEntity(MarketingRequestTracker marketingRequestTracker) {
        entityManager.merge(marketingRequestTracker);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#updateAnswerSentStatusByFileId(java.lang.String, java.lang.String)
     */
    public int updateAnswerSentStatusByFileId(String answerGeneratedStatus, String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaUpdate<MarketingRequestTracker> update = cb.createCriteriaUpdate(MarketingRequestTracker.class);

        Root<MarketingRequestTracker> root = update.from(MarketingRequestTracker.class);
        update.set(root.get(ANSWER_GENERATED), answerGeneratedStatus);
        update.set(root.get(UPDATED_DATE), MarketingDateUtil.getTodaysDate());
        update.where(cb.equal(root.get(FILE_ID), fileId));

        Query query = entityManager.createQuery(update);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#updateMRT_ValidReq_Count(java.lang.String, int)
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public int updateMRT_ValidReq_Count(String fileId, int count) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequestTracker> cq = cb.createQuery(MarketingRequestTracker.class);
        Root<MarketingRequestTracker> root = cq.from(MarketingRequestTracker.class);
        cq.where(cb.equal(root.get(FILE_ID), cb.parameter(String.class, FILE_ID)));

        TypedQuery<MarketingRequestTracker> typedQuery = entityManager.createQuery(cq);
        typedQuery.setParameter(FILE_ID, fileId);

        MarketingRequestTracker marketingRequestTracker = typedQuery.getResultList().isEmpty() ? null : typedQuery.getResultList().get(0);

        if (marketingRequestTracker != null) {

            long newCount = count + (marketingRequestTracker.getValidReqCount() == null ? 0 : marketingRequestTracker.getValidReqCount());

            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
            CriteriaUpdate update = criteriaBuilder.createCriteriaUpdate(MarketingRequestTracker.class);

            Root r = update.from(MarketingRequestTracker.class);
            update.set(r.get(VALID_REQ_COUNT), newCount);
            update.where(criteriaBuilder.equal(r.get(FILE_ID), fileId));

            Query query = entityManager.createQuery(update);
            return query.executeUpdate();
        }
        return 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#updateToMachineName_MRT(java.util.Set, java.lang.String)
     */
    @Override
    public int updateToMachineName_MRT(Set<String> finalFileIds, String bcvResMacName) {
        Query query = entityManager.createQuery("UPDATE MarketingRequestTracker mr SET mr.resMacName = :resMacName where mr.fileId IN (:fileId)");
        query.setParameter("resMacName", bcvResMacName);
        query.setParameter("fileId", finalFileIds);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#byFileId(java.lang.String)
     */
    @Override
    public MarketingRequestTracker byFileId(String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequestTracker> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequestTracker> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FILE_ID), cb.parameter(String.class, FILE_ID)));

        TypedQuery<MarketingRequestTracker> query = entityManager.createQuery(q);
        query.setParameter(FILE_ID, fileId);
        if (!query.getResultList().isEmpty())
            return query.getResultList().get(0);
        return null;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#bytodayLastRequestOnMachine(java.lang.String, java.lang.String,
     *      java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<MarketingRequestTracker> bytodayLastRequestOnMachine(String todayDate, String client, String reqMachine) {
        String sqlQuery = "SELECT max(substring(FILE_ID,4,length(FILE_ID))) as FILE_ID FROM W7TQTMRT WHERE CREATED_DATE LIKE ? AND CLIENT=? AND REQ_MAC_NAME=? ORDER BY CREATED_DATE DESC LIMIT 1";
        String internalReqId = null;
        MarketingRequestTracker marketingRequestTracker = null;
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, "%" + todayDate + "%");
        q.setParameter(2, client);
        q.setParameter(3, reqMachine);
        List<String> list = q.getResultList();
        internalReqId = (list.isEmpty() ? null : list.get(0));
        if (internalReqId != null) {
            marketingRequestTracker = new MarketingRequestTracker();
            marketingRequestTracker.setFileId(internalReqId);
        }
        return Optional.ofNullable(marketingRequestTracker);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#get3DaysAnswerSentFileIds()
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<String> get3DaysAnswerSentFileIds() {
        String sqlQuery = "SELECT FILE_ID FROM W7TQTMRT WHERE CREATED_DATE <= DATE(?) AND CREATED_DATE >= DATE(?) AND ANSWER_GENERATED=?";
        Query q = entityManager.createNativeQuery(sqlQuery);

        DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        final Calendar cal1 = Calendar.getInstance();
        final Calendar cal3 = Calendar.getInstance();
        cal1.add(Calendar.DATE, -1);
        cal3.add(Calendar.DATE, -3);
        String yesterday = dateFormat1.format(cal1.getTime());
        String before3days = dateFormat1.format(cal3.getTime());

        q.setParameter(1, yesterday);
        q.setParameter(2, before3days);
        q.setParameter(3, String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));

        List<String> fileIds = q.getResultList();

        if (!fileIds.isEmpty()) {
            return fileIds;
        }
        return Collections.emptyList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository#getToyotaOriginalFileId(java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public String getToyotaOriginalFileId(String fileId) {
        String sqlQuery = "SELECT ORIGINAL_FILE_ID FROM W7TQTMRT WHERE FILE_ID=?";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, fileId);
        List<String> originalFileIdList = q.getResultList();
        if (!originalFileIdList.isEmpty()) {
            return originalFileIdList.get(0);
        }
        return null;
    }

}
