/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.MarketingDaemonCommandLineHandler;
import com.inetpsa.w7t.batch.util.BatchJobEntry;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;

/**
 * The listener interface for receiving marketingClientFile events. The class that is interested in processing a marketingClientFile event implements
 * this interface, and the object created with that class is registered with a component using the component's
 * <code>addMarketingClientFileListener<code> method. When the marketingClientFile event occurs, that object's appropriate method is invoked.
 * 
 * @see MarketingClientFileEvent
 */
@Named("client")
public class MarketingClientFileListener extends DefaultMarketingFileListener {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The daemon config. */
    @Configuration
    private MarketingDaemonConfig marketingDaemonConfig;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /**
     * Instantiates a new marketing client file listener.
     */
    public MarketingClientFileListener() {
        super();
    }

    /**
     * Instantiates a new marketing client file listener.
     *
     * @param name            the name
     * @param config          the config
     * @param refreshInterval the refresh interval
     */
    public MarketingClientFileListener(String name, MarketingDaemonClientConfig config, Integer refreshInterval) {
        super(name, config.getInputDirectory(), config.getOutputDirectory(), config.getInputFilename(), refreshInterval, config.getOutputFilename(),
                config.getProcessChunkSize());
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        Thread.currentThread().setName("client-listener-".concat(name));
        logger.info("Client listener {} started", this.name);
        while (!MarketingDaemonCommandLineHandler.isSigintRequested()) {
            long start = System.currentTimeMillis();
            logger.debug("Client Listener {} loop started", this.name);

            try {
                String indusFlagPath = marketingDaemonConfig.getIndusFsFlagPath();
                if (indusFlagPath != null && !indusFlagPath.isEmpty()) {
                    File dir = new File(indusFlagPath);
                    File[] dirContents = dir.listFiles();
                    if (dirContents != null && dirContents.length > 0) {
                        logger.info("Indus FS Flag File Path: {}", indusFlagPath);
                        logger.info("Some Database cleanup operations are running, stopping the current job...");
                    } else {
                        this.retrieveFile().ifPresent(this::parseFile);
                    }
                }

            } catch (RuntimeException e) {
                logger.error(String.format("Client file listener '%s' error !", this.name), e);
            }

            long end = System.currentTimeMillis();
            long delta = end - start;
            try {
                TimeUnit.MILLISECONDS.sleep(Math.max(refreshInterval - delta, 0));
            } catch (InterruptedException e) {
                logger.error(String.format("Client file listener '%s' interrupted !", this.name), e);
                Thread.currentThread().interrupt();
            }
            logger.debug("Client Listener {} loop ended", this.name);
        }
        logger.info("Client Listener {} stopped", this.name);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.file.services.internal.DefaultMarketingFileListener#retrieveFile()
     */
    @Override
    protected Optional<File> retrieveFile() {
        return Optional.ofNullable(MarketingDaemonServiceUtils.getTheOldestFile(inputDirectory, inputFileNamePattern));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.file.services.internal.DefaultMarketingFileListener#parseFile(java.io.File)
     */
    @Override
    protected synchronized void parseFile(File file) {
        try {

            String jobName = "";
            if ((MarketingDaemonServiceConstants.CONFIG_MOT2).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_CFGMOT2_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.BCV_NEWTON).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_BCV_NEWTON_ANSWER_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.TOYOTA).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_TOYOTA_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.AOGEOS).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_AO_GEOS_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.CRONOS).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_CRONOS_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.ELIADE).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_ELIADE_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.ICUBE).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_ICUBE_JOB_NAME;
            } else if ((MarketingDaemonServiceConstants.CPDS.toLowerCase()).equalsIgnoreCase(this.name)) {
                jobName = MarketingDaemonServiceConstants.CLIENT_REQ_CPDS_JOB_NAME;
            }

            jobRunWithFileDirAndFileName(jobName, MarketingDaemonBatchUtils.moveFileForProcessing(file).getAbsolutePath(), this.outputDirectory,
                    this.outputfileNamePattern, this.processChunkSize, this.name, this.marketingDaemonConfig.getUniqueIdentifier());

        } catch (IOException e) {
            logger.error("Cound not parse file ", e);
        }
    }

    /**
     * Job run with file dir and file name.
     *
     * @param jobName           the job name
     * @param fileLoc           the file loc
     * @param outputDirectory   the output directory
     * @param outputfileName    the outputfile name
     * @param processChunkSize  the process chunk size
     * @param clientName        the client name
     * @param uniqueIdentifier  the unique identifier
     * @param indusFsFlagPath
     * @param devFsFlagFileName
     * @param devFsFlagPath
     */
    private void jobRunWithFileDirAndFileName(String jobName, String fileLoc, File outputDirectory, String outputfileName, Long processChunkSize,
            String clientName, String uniqueIdentifier) {
        String fsFlagFileName = null;
        if (this.name != null && !this.name.isEmpty() && !"bcvNewton".equalsIgnoreCase(this.name)) {
            fsFlagFileName = createFsFlag();
        }

        batchJobEntry.runJobWithFileDirAndFileName(jobName, fileLoc, outputDirectory, outputfileName, processChunkSize, clientName, uniqueIdentifier,
                fsFlagFileName);
    }

    private String createFsFlag() {
        String fsFlagFileName = null;
        if (fileConfigUtilService.getFsFlagPath() != null && !fileConfigUtilService.getFsFlagPath().isEmpty()) {
            if (fileConfigUtilService.getFilePrefix() != null && !fileConfigUtilService.getFilePrefix().isEmpty()
                    && fileConfigUtilService.getFileSuffix() != null && !fileConfigUtilService.getFileSuffix().isEmpty()) {
                try {
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS");
                    LocalDateTime now = LocalDateTime.now();
                    String dateStr = now.format(dateTimeFormatter);
                    String fileName = fileConfigUtilService.getFilePrefix() + "_" + this.name + "_" + dateStr + "_"
                            + fileConfigUtilService.getFileSuffix();
                    MarketingDaemonBatchUtils.createNewFile(fileConfigUtilService.getFsFlagPath(), fileName);
                    fsFlagFileName = fileName + ".txt";
                    logger.info("FS Flag File [{}] has been created successfully!", fsFlagFileName);
                } catch (IOException e) {
                    logger.error("Failed to create a file in {} : {}", fileConfigUtilService.getFsFlagPath(), e);
                }
            }
        }
        return fsFlagFileName;
    }

}
