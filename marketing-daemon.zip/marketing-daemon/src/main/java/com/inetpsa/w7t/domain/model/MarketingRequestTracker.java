/*
 * Creation : 7 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domain.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * @author E534811
 */
@Entity
@Table(name = "W7TQTMRT")
public class MarketingRequestTracker extends BaseAggregateRoot<String> {

    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "FILE_ID")
    private String fileId = "";

    @Column(name = "CLIENT")
    private String client = "";

    @Column(name = "MRQ_COUNT")
    private Long mrqCount;

    @Column(name = "VALID_REQ_COUNT")
    private Long validReqCount;

    @Column(name = "ANSWER_GENERATED")
    private String answerGenerated;

    @Column(name = "CREATED_DATE")
    private String createdDate;

    @Column(name = "UPDATED_DATE")
    private String updatedDate;

    @Column(name = "REQ_MAC_NAME")
    private String reqMacName;

    @Column(name = "RES_MAC_NAME")
    private String resMacName;

    @Column(name = "ORIGINAL_FILE_ID")
    private String OriginalFileId = "";

    public String getOriginalFileId() {
        return OriginalFileId;
    }

    public void setOriginalFileId(String originalFileId) {
        OriginalFileId = originalFileId;
    }

    public String getReqMacName() {
        return reqMacName;
    }

    public void setReqMacName(String reqMacName) {
        this.reqMacName = reqMacName;
    }

    public String getResMacName() {
        return resMacName;
    }

    public void setResMacName(String resMacName) {
        this.resMacName = resMacName;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Long getMrqCount() {
        return mrqCount;
    }

    public void setMrqCount(Long mrqCount) {
        this.mrqCount = mrqCount;
    }

    /**
     * Getter validReqCount
     * 
     * @return the validReqCount
     */
    public Long getValidReqCount() {
        return validReqCount;
    }

    /**
     * Setter validReqCount
     * 
     * @param validReqCount the validReqCount to set
     */
    public void setValidReqCount(Long validReqCount) {
        this.validReqCount = validReqCount;
    }

    public String getAnswerGenerated() {
        return answerGenerated;
    }

    public void setAnswerGenerated(String answerGenerated) {
        this.answerGenerated = answerGenerated;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Getter guid
     * 
     * @return the guid
     */
    public UUID getGuid() {
        return guid;
    }

    /**
     * Setter guid
     * 
     * @param guid the guid to set
     */
    public void setGuid(UUID guid) {
        this.guid = guid;
    }

    @Override
    public String getEntityId() {
        return this.guid.toString();
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "MarketingRequestTracker [guid=" + guid + ", fileId=" + fileId + ", client=" + client + ", mrqCount=" + mrqCount + ", validReqCount="
                + validReqCount + ", answerGenerated=" + answerGenerated + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
                + ", reqMacName=" + reqMacName + ", resMacName=" + resMacName + ", OriginalFileId=" + OriginalFileId + "]";
    }

}
