/*
 * Creation : 13 Jan 2020
 */
package com.inetpsa.w7t.batch.util;

import org.seedstack.seed.Configuration;

/**
 * The Class FileConfigUtilServiceImpl.
 */
public class FileConfigUtilServiceImpl implements FileConfigUtilService {

    /** The indus flag path. */
    @Configuration("marketingDaemon.indusFsFlagPath")
    private String indusFlagPath;

    /** The fs flag path. */
    @Configuration("marketingDaemon.fsFlagPath")
    private String fsFlagPath;

    /** The file prefix. */
    @Configuration("marketingDaemon.filePrefix")
    private String filePrefix;

    /** The file suffix. */
    @Configuration("marketingDaemon.fileSuffix")
    private String fileSuffix;

    /** The req machine name. */
    @Configuration("marketingDaemon.reqMacName")
    private String reqMachineName;

    /** The res machine name. */
    @Configuration("marketingDaemon.resMacName")
    private String resMachineName;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getIndusFsFlagPath()
     */
    @Override
    public String getIndusFsFlagPath() {
        return this.indusFlagPath;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getFsFlagPath()
     */
    @Override
    public String getFsFlagPath() {
        return this.fsFlagPath;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getFilePrefix()
     */
    @Override
    public String getFilePrefix() {
        return this.filePrefix;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getFileSuffix()
     */
    @Override
    public String getFileSuffix() {
        return this.fileSuffix;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getReqMacName()
     */
    @Override
    public String getReqMacName() {
        return this.reqMachineName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.FileConfigUtilService#getResMacName()
     */
    @Override
    public String getResMacName() {
        return this.resMachineName;
    }

}
