/*
 * Creation : 12 juin 2017
 */
package com.inetpsa.w7t.daemon.services.misc;

/**
 * The Class DaemonServiceConstants.
 */
public final class MarketingDaemonServiceConstants {

    /** The Constant CONFIG_MOT2_REQ_RESP_JOB_NAM defined in job-context.xml */
    public static final String CONFIG_MOT2 = "configMot2";

    /** The Constant CLIENT_REQ_CFGMOT2_JOB_NAME. */
    public static final String CLIENT_REQ_CFGMOT2_JOB_NAME = "cfgMot2JsonFileRequestJob";

    /** The Constant WLTP_CFG_MOT2_JSON_ANSWER_JOB_NAME. */
    public static final String WLTP_CFG_MOT2_JSON_ANSWER_JOB_NAME = "cfgMot2JsonFileAnswerJob";

    /** The Constant BCV_NEWTON_REQ_RESP_JOB_NAME defined in job-context.xml */
    public static final String BCV_NEWTON = "bcvNewton";

    /** The Constant CLIENT_REQ_BCV_NEWTON_ANSWER_JOB_NAME. */
    public static final String CLIENT_REQ_BCV_NEWTON_ANSWER_JOB_NAME = "bcvNewtonFlatFileAnswerJob";

    /** The Constant PROVIDER_REQ_BCV_NEWTON_JOB_NAME. */
    public static final String PROVIDER_REQ_BCV_NEWTON_JOB_NAME = "bcvNewtonFlatFileRequestJob";

    /** The Constant TOYOTA_REQ_RESP_JOB_NAME defined in job-context.xml */
    public static final String TOYOTA = "toyota";

    /** The Constant CLIENT_REQ_TOYOTA_JOB_NAME. */
    public static final String CLIENT_REQ_TOYOTA_JOB_NAME = "toyotaRequestXMLFileToDatabaseJob";

    /** The Constant WLTP_TOYOTA_XML_ANSWER_JOB_NAME. */
    public static final String WLTP_TOYOTA_XML_ANSWER_JOB_NAME = "toyotaXmlFileAnswerJob";

    /** The Constant AOGEOS_REQ_RESP_JOB_NAME defined in job-context.xml */
    public static final String AOGEOS = "aoGeos";

    /** The Constant CLIENT_REQ_AO_GEOS_JOB_NAME. */
    public static final String CLIENT_REQ_AO_GEOS_JOB_NAME = "aoGeosJob";

    /** The Constant PROVIDER_REQ_AOGEOS_JOB_NAME. */
    public static final String PROVIDER_REQ_AOGEOS_JOB_NAME = "aoGeosDatabaseToFlatFileJob";

    /** The Constant CRONOS_REQ_RESP_JOB_NAME defined in job-context.xml */
    public static final String CRONOS = "cronos";

    /** The Constant CLIENT_REQ_CRONOS_JOB_NAME. */
    public static final String CLIENT_REQ_CRONOS_JOB_NAME = "cronosJob";

    /** The Constant PROVIDER_REQ_CRONOS_JOB_NAME. */
    public static final String PROVIDER_REQ_CRONOS_JOB_NAME = "cronosDatabaseToFlatFileJob";

    /** The Constant ELIADE_REQ_RESP_JOB_NAME defined in job-context.xml */
    public static final String ELIADE = "eliade";

    /** The Constant CLIENT_REQ_ELIADE_JOB_NAME. */
    public static final String CLIENT_REQ_ELIADE_JOB_NAME = "eliadeJob";

    /** The Constant PROVIDER_REQ_ELIADE_JOB_NAME. */
    public static final String PROVIDER_REQ_ELIADE_JOB_NAME = "eliadeDatabaseToFlatFileJob";

    /** The Constant ICUBE. */
    public static final String ICUBE = "icube";

    /** The Constant CLIENT_REQ_ICUBE_JOB_NAME. */
    public static final String CLIENT_REQ_ICUBE_JOB_NAME = "icubeJob";

    /** The Constant PROVIDER_REQ_ICUBE_JOB_NAME. */
    public static final String PROVIDER_REQ_ICUBE_JOB_NAME = "icubeDatabaseToFlatFileJob";

    /** The Constant CLIENT_REQ_CPDS_JOB_NAME. */
    public static final String CLIENT_REQ_CPDS_JOB_NAME = "cpdsJob";

    /** The Constant CPDS. */
    public static final String CPDS = "CPDS";

    /** Other Constants. */
    public static final String REQ_CONST9 = "000000000";

    /** The Constant CFG_REQ_CONST2. */
    public static final String CFG_REQ_CONST2 = "CF";

    /** The Constant AOG_REQ_CONST2. */
    public static final String AOG_REQ_CONST2 = "AO";

    /** The Constant CRO_REQ_CONST2. */
    public static final String CRO_REQ_CONST2 = "CR";

    /** The Constant ELI_REQ_CONST2. */
    public static final String ELI_REQ_CONST2 = "EL";

    /** The Constant TOY_REQ_CONST2. */
    public static final String TOY_REQ_CONST2 = "TO";

    /** The Constant BCV_REQ_CONST3. */
    public static final String BCV_REQ_CONST3 = "BCV";

    /** The Constant ICU_REQ_CONST2. */
    public static final String ICU_REQ_CONST2 = "IC";

    /** The Constant AoCronoEliadeUniqueCharLenth. */
    public static final int AoCronoEliadeUniqueCharLenth = 8;

    /** The Constant CHUNK_SIZE. */
    public static final int CHUNK_SIZE = 25000;

    /** The Constant SUCCESS_CODE_FOR_AOGEOS_CRONOS_ELIADE. */
    public static final String SUCCESS_CODE_FOR_AOGEOS_CRONOS_ELIADE = "OKW0001";

    /** The Constant SUCCESS_CODE_FOR_CFGMOT2. */
    public static final String SUCCESS_CODE_FOR_CFGMOT2 = "OKW00001";

    /** The Constant SUCCESS_CODE_FOR_TOYOTA. */
    public static final String SUCCESS_CODE_FOR_TOYOTA = "OKW00001";

    /** The Constant SUCCESS_DESIGNATION. */
    public static final String SUCCESS_DESIGNATION = "Calculation successful";

    /** The Constant PROVIDER_REQ_ELIADE_REJECTED_FILE_WRITER_JOB_NAME. */
    public static final String PROVIDER_REQ_ELIADE_REJECTED_FILE_WRITER_JOB_NAME = "eliadeRejectedFileWriterJob";

    /** Instantiation not allowed. */
    private MarketingDaemonServiceConstants() {
    }
}
