/*
 * Creation : 5 Feb 2021
 */
package com.inetpsa.w7t.batch.shared;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Interface MarketingDaemonWltpHubService.
 */
@Service
public interface MarketingDaemonWltpHubService {

    /**
     * Call wltp hub web service.
     *
     * @param request the request
     * @return the wltp hub response representation
     */
    WltpHubResponseRepresentation callWltpHubWebService(AoCronosEliadeDto request);
}
