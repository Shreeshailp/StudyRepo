/*
 * Creation : 17 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.request;

import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.ToyotaFileRequestLstXML;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * @author E534812
 */
public class ToyotaRequestXMLFileItemProccessor implements ItemProcessor<ToyotaFileRequestLstXML, MarketingRequest> {

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(ToyotaRequestXMLFileItemProccessor.class);

    public static final String TOYOTA_ERR = "{} : Marketing toyota {} at line : {} . Failed record from file : {}";

    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The common file id. */
    String commonFileId;

    /** The common batch id. */
    String commonRequestDate;

    @Inject
    private MaturityRepository maturityRepository;

    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /**
     * Retrieve interstep data.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void retrieveInterstepData(StepExecution stepExecution) {
        this.commonFileId = stepExecution.getJobExecution().getExecutionContext().get("FILE_ID").toString();
        this.commonRequestDate = stepExecution.getJobExecution().getExecutionContext().get("REQUEST_DATE").toString();
    }

    /** The line number. */
    private int lineNumber;

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public MarketingRequest process(ToyotaFileRequestLstXML item) {
        // fixed jira-551
        logger.info("Marketing Request =[{}]", item);
        lineNumber++;
        try {
            String number = item.getNumber();

            // Check if request number is already present in databse
            if (number == null || number.isEmpty()) {
                logger.error(TOYOTA_ERR, WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_MISSING.getRuleCode(),
                        WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_MISSING.getDescription(), lineNumber, item);
                LogUtility.logTheError(logger, WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_MISSING.getRuleCode(),
                        WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_MISSING.getDescription());
                return null;
            }

            // Optional<MarketingRequest> marketingRequest = getToyotaReqByRequestId(number.trim());
            // if (marketingRequest.isPresent()) {
            // logger.error(TOYOTA_ERR, WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_NOT_UNIQUE.getRuleCode(),
            // WltpRequestErrorCode.TOYOTA_REQUEST_NUMBER_NOT_UNIQUE.getDescription(), lineNumber, item);
            // return null;
            // }
            return ToyotaUtility.getInstance().createMarketingRequest(item, lineNumber, commonFileId, maturityRepository, clientMaturityRepository);

        } catch (EmptyResultDataAccessException e) {
            logger.error(e.getMessage(), e);
            logger.error(TOYOTA_ERR, WltpRequestErrorCode.UNKNOW_MARKETING_REQUEST.getRuleCode(),
                    WltpRequestErrorCode.UNKNOW_MARKETING_REQUEST.getDescription(), lineNumber, item);
            LogUtility.logTheError(logger, WltpRequestErrorCode.UNKNOW_MARKETING_REQUEST.getRuleCode(),
                    WltpRequestErrorCode.UNKNOW_MARKETING_REQUEST.getDescription());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            logger.error("Exception parsing at line {}. Failed record from file: {} ", lineNumber, item);
        }
        return null;
    }

    /**
     * Getv requestId from database
     * 
     * @param requestId
     * @return
     * @throws Exception
     */
    private Optional<MarketingRequest> getToyotaReqByRequestId(String requestId) throws Exception {
        return marketingRequestRepository.byClientRequestId(requestId, MarketingDaemonServiceConstants.TOYOTA.toUpperCase());
    }
}
