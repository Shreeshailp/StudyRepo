/*
 * Creation : 2 Dec 2020
 */
package com.inetpsa.w7t.wltphub.ws;

/**
 * The Class WltpHubRequestRepresentation.
 */
public class WltpHubRequestRepresentation {

    /** The request. */
    private WltpHubRequest request;

    /**
     * Gets the request.
     *
     * @return the request
     */
    public WltpHubRequest getRequest() {
        return request;
    }

    /**
     * Sets the request.
     *
     * @param request the new request
     */
    public void setRequest(WltpHubRequest request) {
        this.request = request;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "HubRequestRepresentation [request=" + request + "]";
    }

}
