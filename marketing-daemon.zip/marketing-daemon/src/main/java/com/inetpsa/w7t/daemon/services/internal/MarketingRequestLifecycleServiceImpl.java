/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import javax.inject.Inject;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.util.BatchJobEntry;
import com.inetpsa.w7t.daemon.services.MarketingDaemonService;
import com.inetpsa.w7t.daemon.services.MarketingRequestLifecycleService;

/**
 * The Class RequestLifecycleServiceImpl.
 */
public class MarketingRequestLifecycleServiceImpl implements MarketingRequestLifecycleService {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The refresh interval. */
    @Configuration("marketingDaemon.lifecycleRefreshInterval")
    private int refreshInterval;

    /** The step count. */
    @Configuration("marketingDaemon.lifecycleStepCount")
    private int stepCount;

    /** The timeout. */
    @Configuration("marketingDaemon.clients.configMot2.timeout")
    private int timeout;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The engine daemon service. */
    @Inject
    private MarketingDaemonService engineDaemonService;

    /**
     * Gets the primitive type for null.
     *
     * @param value the value
     * @return the primitive type for null
     */
    private double getPrimitiveTypeForNULL(Double value) {
        if (value == null)
            return 0.0;
        return value.doubleValue();
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub

    }
}
