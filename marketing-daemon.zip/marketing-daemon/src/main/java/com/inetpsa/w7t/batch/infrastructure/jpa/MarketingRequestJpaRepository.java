/*
 * Creation : 2 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.infrastructure.jpa;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.collections4.ListUtils;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;

/**
 * The Class MarketingRequestJpaRepository.
 *
 * @author E534811
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class MarketingRequestJpaRepository extends BaseJpaRepository<MarketingRequest, String> implements MarketingRequestRepository {

    /** The Constant REQUEST_DATE. */
    private static final String REQUEST_DATE = "requestDate";

    /** The Constant REQUEST_ID. */
    private static final String REQUEST_ID = "requestID";

    /** The Constant VERSION16. */
    private static final String VERSION16 = "Version16";

    /** The Constant COLOR_EXT_INT. */
    private static final String COLOR_EXT_INT = "colorExtInt";

    /** The Constant OPTIONS7C. */
    private static final String OPTIONS7C = "options7C";

    /** The Constant EXTENSION_DATE. */
    private static final String EXTENSION_DATE = "extensionDate";

    /** The Constant FILEID. */
    private static final String FILEID = "fileId";

    /** The Constant CLIENT. */
    private static final String CLIENT = "client";

    /** The Constant STATUS. */
    private static final String STATUS = "status";

    /** The Constant INTERNAL_REQUEST_ID. */
    private static final String INTERNAL_REQUEST_ID = "internalReqId";

    /** The logger. */
    private static final Logger logger = LoggerFactory.getLogger(MarketingRequestJpaRepository.class);

    /** The Constant CLASS_NAME. */
    private static final String CLASS_NAME = "MarketingRequestJpaRepository";

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */

    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The Constant MARKETING_ANSWER_SENT_LOG. */
    private static final String MARKETING_ANSWER_SENT_LOG = "Marketing Request=[{}], AnswerCode=[{}], AnswerDesignation=[{}]";

    // @Override
    // public Optional<MarketingRequest> bytodayLastRequest(String today, String clientName) {
    // CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    // CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
    // Root<MarketingRequest> root = q.from(aggregateRootClass);
    //
    // Subquery<String> maxSubQuery = q.subquery(String.class);
    // Root<MarketingRequest> subRoot = maxSubQuery.from(MarketingRequest.class);
    // Expression<String> requestDate = subRoot.get(REQUEST_DATE);
    // maxSubQuery.select(cb.greatest(requestDate));
    //
    // q.where(cb.equal(root.get(REQUEST_DATE), maxSubQuery), cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)));
    // q.orderBy(cb.desc(root.get(REQUEST_ID)));
    //
    // TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
    // // query.setParameter(REQUEST_DATE, today);
    // query.setParameter(CLIENT, clientName);
    // query.setMaxResults(1);
    //
    // if (!query.getResultList().isEmpty())
    // return Optional.ofNullable(query.getSingleResult());
    // return Optional.empty();
    // }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#bySemiExtendeTitle(java.lang.String, java.lang.String, java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public List<MarketingRequest> bySemiExtendeTitle(String version16c, String colorExtInt, String extensionDate, String options7c, String today) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        if (!extensionDate.isEmpty()) {
            q.where(cb.and(cb.equal(root.get(VERSION16), cb.parameter(String.class, VERSION16)),
                    cb.equal(root.get(COLOR_EXT_INT), cb.parameter(String.class, COLOR_EXT_INT)),
                    cb.equal(root.get(OPTIONS7C), cb.parameter(String.class, OPTIONS7C)),
                    cb.equal(root.get(EXTENSION_DATE), cb.parameter(String.class, EXTENSION_DATE)),
                    cb.equal(root.get(REQUEST_DATE), cb.parameter(String.class, REQUEST_DATE))));
        } else {
            q.where(cb.and(cb.equal(root.get(VERSION16), cb.parameter(String.class, VERSION16)),
                    cb.equal(root.get(COLOR_EXT_INT), cb.parameter(String.class, COLOR_EXT_INT)),
                    cb.equal(root.get(OPTIONS7C), cb.parameter(String.class, OPTIONS7C)),
                    cb.equal(root.get(REQUEST_DATE), cb.parameter(String.class, REQUEST_DATE))));
        }

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(VERSION16, version16c);
        query.setParameter(COLOR_EXT_INT, colorExtInt);
        query.setParameter(OPTIONS7C, options7c);
        if (!extensionDate.isEmpty())
            query.setParameter(EXTENSION_DATE, extensionDate);
        query.setParameter(REQUEST_DATE, today);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byRequestId(java.lang.String)
     */
    @Override
    public MarketingRequest byRequestId(String requestId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQUEST_ID), cb.parameter(String.class, REQUEST_ID)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(REQUEST_ID, requestId);

        return query.getResultList().isEmpty() ? null : query.getResultList().get(0);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byInternalRequestId(java.lang.String)
     */
    @Override
    public MarketingRequest byInternalRequestId(String internalRequestId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(INTERNAL_REQUEST_ID), cb.parameter(String.class, INTERNAL_REQUEST_ID)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(INTERNAL_REQUEST_ID, internalRequestId);

        return query.getResultList().isEmpty() ? null : query.getResultList().get(0);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byRequestIdWithNative(java.lang.String)
     */
    @Override
    public boolean byRequestIdWithNative(String requestId) {
        String q = "select count(1) from W7TQTMRQ where REQUEST_ID =?";

        Query query = entityManager.createNativeQuery(q);
        query.setParameter(1, requestId);

        BigInteger result = (BigInteger) query.getSingleResult();
        return result.longValue() > 0 ? true : false;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byFileId(java.lang.String)
     */
    @Override
    public Optional<MarketingRequest> byFileId(String fileId) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(FILEID, fileId);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byClientRequestId(java.lang.String, java.lang.String)
     */
    @Override
    public Optional<MarketingRequest> byClientRequestId(String requestId, String clientName) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQUEST_ID), cb.parameter(String.class, REQUEST_ID)),
                cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(REQUEST_ID, requestId);
        query.setParameter(CLIENT, clientName);

        return query.getResultList().stream().findFirst();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#saveEntity(com.inetpsa.w7t.domain.model.MarketingRequest)
     */
    @Override
    public void saveEntity(MarketingRequest marketingRequest) {
        entityManager.merge(marketingRequest);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byStatusCode(java.lang.String)
     */
    @Override
    public List<MarketingRequest> byStatusCode(String status) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(STATUS), cb.parameter(String.class, STATUS)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(STATUS, status);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byClientAndStatus(java.lang.String, java.lang.String)
     */
    @Override
    public List<MarketingRequest> byClientAndStatus(String client, String status) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)), cb.equal(root.get(STATUS), cb.parameter(String.class, STATUS)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(CLIENT, client);
        query.setParameter(STATUS, status);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#bytodayLastRequest(java.lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    public Optional<MarketingRequest> bytodayLastRequest(String today, String clientName) {
        // Added below lines as part of JIRA-557 and jira-565 Fix
        MarketingRequest request = null;
        Object[] internalReqId = null;
//        Query query = entityManager.createNativeQuery(
//                "SELECT max(substring(FILE_ID,4,length(FILE_ID))) as FILE_ID, max(substring(INTERNAL_REQUEST_ID,4,length(INTERNAL_REQUEST_ID))) as INTERNAL_REQUEST_ID FROM W7TQTMRQ where CLIENT=? AND REQUEST_DATE like? order by REQUEST_DATE desc limit 1");

        // This below query has been modified to fix the PROD incident INCI10540535 - CRONOS file 25/11 20:42
        Query query = entityManager.createNativeQuery(
                "SELECT max(CONVERT(SUBSTRING(FILE_ID, 4), SIGNED INTEGER)) as FILE_ID, max(CONVERT(SUBSTRING(INTERNAL_REQUEST_ID, 4), SIGNED INTEGER)) as INTERNAL_REQUEST_ID from W7TQTMRQ where CLIENT=? AND REQUEST_DATE like? order by REQUEST_DATE desc limit 1");
        query.setParameter(1, clientName);
        query.setParameter(2, '%' + today + '%');

        List<Object[]> list = query.getResultList();
        internalReqId = (list.isEmpty() ? null : list.get(0));
        if (internalReqId != null) {
            request = new MarketingRequest();
            if (internalReqId[0] != null) {
                request.setFileId(internalReqId[0].toString());
            }
            if (internalReqId[1] != null) {
                request.setInternalReqId(internalReqId[1].toString());
            }
        }
        return Optional.ofNullable(request);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#saveRecordsBatchwise(java.util.List)
     */
    @Override
    public void saveRecordsBatchwise(List<MarketingRequest> marketingRequestList) {
        // logger.info("Inside saveRecordsBatchwise()[IN]");
        // final AtomicInteger counter = new AtomicInteger(0);
        // final int size = 2500;
        try {
            // final Collection<List<MarketingRequest>> partitionedList = marketingRequestList.stream()
            // .collect(Collectors.groupingBy(it -> counter.getAndIncrement() / size)).values();
            // for (List<MarketingRequest> subList : partitionedList) {
            // for (MarketingRequest marketingRequest : subList) {
            // entityManager.merge(marketingRequest);
            // }
            // entityManager.flush();
            // entityManager.clear();
            // logger.info("Entity manager has been flushed for the records [{}] ", size);
            // }
            for (MarketingRequest marketingRequest : marketingRequestList) {
                entityManager.persist(marketingRequest);
            }

        } catch (Exception e) {
            logger.error("ERROR while saving the records  batch wise {} ", e.getMessage());
        }
        // logger.info("saveRecordsBatchwise()[OUT]");

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byClientAndStatusAndFileId(java.lang.String, java.lang.String,
     *      java.lang.String)
     */
    @Override
    public List<MarketingRequest> byClientAndStatusAndFileId(String client, String status, String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)), cb.equal(root.get(STATUS), cb.parameter(String.class, STATUS)),
                cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(CLIENT, client);
        query.setParameter(STATUS, status);
        query.setParameter(FILEID, fileId);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateStatusByInternalRequestId(java.lang.String, java.lang.String)
     */
    @Override
    public int updateStatusByInternalRequestId(String status, String internalRequestId) {

        Query query = entityManager.createQuery("UPDATE MarketingRequest mr SET mr.status = :STATUS where mr.internalReqId = :INTERNAL_REQUEST_ID");
        query.setParameter("STATUS", status);
        query.setParameter("INTERNAL_REQUEST_ID", internalRequestId);
        return query.executeUpdate();

        // CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        // CriteriaUpdate update = cb.createCriteriaUpdate(MarketingRequest.class);
        //
        // Root root = update.from(MarketingRequest.class);
        // update.set(root.get("status"), status);
        // update.where(cb.equal(root.get("requestID"), requestId));
        //
        // Query query = entityManager.createQuery(update);
        // return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateByRequestId(java.lang.String, java.lang.String, boolean,
     *      java.lang.String)
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public int updateByRequestId(String status, String requestId, boolean isAnswerSent, String todaysDate) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaUpdate update = cb.createCriteriaUpdate(MarketingRequest.class);

        Root root = update.from(MarketingRequest.class);
        update.set(root.get("status"), status);
        update.set(root.get("isAnswerSent"), isAnswerSent);
        update.set(root.get("answerDate"), todaysDate);
        update.where(cb.equal(root.get("requestID"), requestId));

        Query query = entityManager.createQuery(update);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateByReqId(java.lang.String, java.lang.String, boolean,
     *      java.lang.String)
     */
    // Added for Performance improvement
    @Override
    public int updateByReqId(String status, String requestId, boolean isAnswerSent, String todaysDate) {

        Query query = entityManager.createQuery(
                "UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.isAnswerSent = :IS_ANSWER_SENT, mr.answerDate = :ANSWER_DATE where mr.requestID = :REQUEST_ID");
        query.setParameter("STATUS", status);
        query.setParameter("IS_ANSWER_SENT", isAnswerSent);
        query.setParameter("ANSWER_DATE", todaysDate);
        query.setParameter("REQUEST_ID", requestId);
        return query.executeUpdate();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byFileIdAndStatusAndBcvReqCountAndLimit(java.lang.String, java.util.List,
     *      java.lang.Long, int, int)
     */
    @Override
    public List<MarketingRequest> byFileIdAndStatusAndBcvReqCountAndLimit(String fileId, List<String> statusList, Long brqCount, int startPosition,
            int limit) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        Expression<String> statusExpression = root.get(STATUS);
        Predicate statusPredicate = statusExpression.in(statusList);
        q.where(cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)), statusPredicate);

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(FILEID, fileId);
        query.setParameter(STATUS, statusList);
        query.setFirstResult(startPosition);
        query.setMaxResults(limit);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateAnswerSentStatusInMRQ(java.lang.String, java.lang.String, boolean)
     */
    @Override
    public int updateAnswerSentStatusInMRQ(String requestId, String status, boolean isAnswerSent) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaUpdate<MarketingRequest> update = cb.createCriteriaUpdate(MarketingRequest.class);
        Root<MarketingRequest> root = update.from(MarketingRequest.class);
        update.set(root.get("status"), status);
        update.set(root.get("isAnswerSent"), isAnswerSent);
        update.where(cb.equal(root.get("requestID"), requestId));
        Query query = entityManager.createQuery(update);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateMarketingRequestCalculationDetails(java.lang.String,
     *      java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public int updateMarketingRequestCalculationDetails(String requestId, String answerCode, String answerDesig, String status) {

        Query query = entityManager.createQuery(
                "UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.answerDate = :ANSWER_DATE, mr.answerCode = :ANSWER_CODE,mr.answerDesig= :ANSWER_DESIG where mr.requestID = :REQUEST_ID");
        query.setParameter("STATUS", status);
        query.setParameter("ANSWER_DATE", MarketingDateUtil.getTodaysDate());
        query.setParameter("ANSWER_CODE", answerCode);
        query.setParameter("ANSWER_DESIG", answerDesig);
        query.setParameter("REQUEST_ID", requestId);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#getMarketingRequestsByFileId(java.lang.String, java.lang.String)
     */
    @Override
    public List<MarketingRequest> getMarketingRequestsByFileId(String client, String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(CLIENT), cb.parameter(String.class, CLIENT)), cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)));
        q.orderBy(cb.asc(root.get("requestID")));
        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(CLIENT, client);
        query.setParameter(FILEID, fileId);

        return query.getResultList();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#persistEntity(com.inetpsa.w7t.domain.model.MarketingRequest)
     */
    @Override
    public void persistEntity(MarketingRequest marketingRequest) {
        entityManager.persist(marketingRequest);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateByReqId(java.lang.String, java.lang.String)
     */
    // Added for Performance improvement
    @Override
    public int updateByReqId(String status, String requestId) {
        Query query = entityManager.createQuery("UPDATE MarketingRequest mr SET mr.status = :STATUS where mr.requestID = :REQUEST_ID");
        query.setParameter("STATUS", status);
        query.setParameter("REQUEST_ID", requestId);
        return query.executeUpdate();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateByRequest(java.util.List, java.lang.String)
     */
    public void updateByRequest(List<MarketingRequest> list, String status) {
        for (MarketingRequest request : list) {
            Query query = entityManager.createQuery("UPDATE MarketingRequest mr SET mr.status = :STATUS where mr.requestID = :REQUEST_ID");
            query.setParameter("STATUS", request.getStatus());
            query.setParameter("REQUEST_ID", request.getRequestID());
            query.executeUpdate();
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#saveMarketingRequest(java.util.List,
     *      com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository)
     */
    @Override
    public void saveMarketingRequest(List<MarketingRequest> marketingRequestsList, ThreadPoolMasterRepository threadPoolMasterRepository) {
        int chunkSize = 100;

        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(CLASS_NAME);
        logger.info(" thread pool size : [{}]", threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        String fileId = "";
        try {
            List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
            List<List<MarketingRequest>> splitedList = ListUtils.partition(marketingRequestsList, chunkSize);

            if (splitedList != null && !splitedList.isEmpty()) {
                logger.info("Splited List Size : [{}] ", splitedList.size());
                splitedList.forEach(list -> {
                    Future<Integer> future = executorService.submit(() -> processParallelList(list));
                    futuresList.add(future);
                });
            }

            for (Future<Integer> future : futuresList) {

                future.get();
            }
        } catch (Exception e) {
            logger.error("ERROR in MarkertingDaemonUtility saveMarketingRequest : [{}]", e);
        } finally {
            executorService.shutdown();
        }
        logger.info("File Id - [{}]", fileId);
    }

    /**
     * Process parallel list.
     *
     * @param list the list
     * @return the int
     */
    public int processParallelList(List<MarketingRequest> list) {
        list.forEach(markeringRequest -> persistEntity(markeringRequest));
        return 1;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#persistEntityBatch(java.util.List)
     */
    @Override
    public void persistEntityBatch(List<MarketingRequest> list) {
        list.forEach(marketingRequest -> entityManager.persist(marketingRequest));
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateStatusCalculationOkInMRQ(java.util.List, java.lang.String,
     *      java.lang.String, java.lang.String)
     */
    @Override
    public void updateStatusCalculationOkInMRQ(List<String[]> mrqIds, String status, String answerCode, String answerDesig) {
        Query query = entityManager.createQuery(
                "UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.isAnswerSent = :IS_ANSWER_SENT, mr.answerDate = :ANSWER_DATE, mr.answerCode = :ANSWER_CODE,mr.answerDesig= :ANSWER_DESIG where mr.requestID = :REQUEST_ID");
        for (String[] strings : mrqIds) {
            query.setParameter("STATUS", status);
            query.setParameter("IS_ANSWER_SENT", true);
            query.setParameter("ANSWER_DATE", MarketingDateUtil.getTodaysDate());
            query.setParameter("ANSWER_CODE", answerCode);
            query.setParameter("ANSWER_DESIG", answerDesig);
            query.setParameter("REQUEST_ID", strings[0]);
            int updatedDetailsInMRQ = query.executeUpdate();
            if (updatedDetailsInMRQ > 0) {
                logger.info(MARKETING_STATUS_CHANGE_LOG, strings[0], strings[1], status);
                logger.info(MARKETING_ANSWER_SENT_LOG, strings[0], answerCode, answerDesig);
            }

        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateAnswerSentStatus(java.util.List)
     */
    @Override
    public void updateAnswerSentStatus(List<MarketingRequest> marketingRequestList) {
        Query query = entityManager.createQuery(
                "UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.isAnswerSent = :IS_ANSWER_SENT where mr.requestID = :REQUEST_ID and mr.internalReqId = :INTERNAL_REQUEST_ID and mr.fileId= :FILE_ID");
        String status = null;
        for (MarketingRequest marketingRequest : marketingRequestList) {
            status = String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
            query.setParameter("STATUS", status);
            query.setParameter("IS_ANSWER_SENT", true);
            query.setParameter("REQUEST_ID", marketingRequest.getRequestID());
            query.setParameter("INTERNAL_REQUEST_ID", marketingRequest.getInternalReqId());
            query.setParameter("FILE_ID", marketingRequest.getFileId());
            int updatedMRQ = query.executeUpdate();
            if (updatedMRQ > 0) {
                logger.info("Marketing Request=[{}], INTERNAL_REQUEST_ID =[{}], FILE_ID=[{}], Status=[{}]", marketingRequest.getRequestID(),
                        marketingRequest.getInternalReqId(), marketingRequest.getFileId(), status);
            }
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateAnswerDetailsMRQ(java.util.List)
     */
    @Override
    public void updateAnswerDetailsMRQ(List<MarketingRequestDto> marketingRequestDtosList) {
        Query query = entityManager
                .createQuery("UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.isAnswerSent = :IS_ANSWER_SENT, mr.answerDate = :ANSWER_DATE, "
                        + "mr.answerCode = :ANSWER_CODE  , mr.answerDesig = :ANSWER_DESIG  where mr.requestID = :REQUEST_ID");
        String status = null;
        for (MarketingRequestDto marketingRequestDto : marketingRequestDtosList) {
            status = String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
            query.setParameter("STATUS", status);
            query.setParameter("IS_ANSWER_SENT", true);
            query.setParameter("ANSWER_DATE", MarketingDateUtil.getTodaysDate());
            query.setParameter("ANSWER_CODE", marketingRequestDto.getAnswerCode());
            query.setParameter("ANSWER_DESIG", marketingRequestDto.getAnswerDesig());
            query.setParameter("REQUEST_ID", marketingRequestDto.getRequestID());
            int updatedMRQ = query.executeUpdate();
            if (updatedMRQ > 0) {
                logger.info("Marketing Request=[{}],Status=[{}]", marketingRequestDto.getRequestID(), status);
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getAnswerCode(),
                        marketingRequestDto.getAnswerDesig());
            }
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#updateCalculationStatusDetailsInMRQ(java.util.List)
     */
    @Override
    public void updateCalculationStatusDetailsInMRQ(List<CalculationStatusDto> calculationStatusDtoList) {
        Query query = entityManager.createQuery(
                "UPDATE MarketingRequest mr SET mr.status = :STATUS, mr.answerDate = :ANSWER_DATE, mr.answerCode = :ANSWER_CODE,mr.answerDesig= :ANSWER_DESIG where mr.requestID = :REQUEST_ID and mr.fileId= :FILE_ID");
        for (CalculationStatusDto calculationStatusDto : calculationStatusDtoList) {
            query.setParameter("STATUS", calculationStatusDto.getCurrentStatus());
            query.setParameter("ANSWER_DATE", calculationStatusDto.getAnswerDate());
            query.setParameter("ANSWER_CODE", calculationStatusDto.getAnswerCode());
            query.setParameter("ANSWER_DESIG", calculationStatusDto.getAnswerDesignation());
            query.setParameter("REQUEST_ID", calculationStatusDto.getRequestId());
            query.setParameter("FILE_ID", calculationStatusDto.getFileId());
            int updatedDetailsInMRQ = query.executeUpdate();
            if (updatedDetailsInMRQ > 0) {
                logger.info(MARKETING_STATUS_CHANGE_LOG, calculationStatusDto.getRequestId(), calculationStatusDto.getPreviousStatus(),
                        calculationStatusDto.getCurrentStatus());
                logger.info(MARKETING_ANSWER_SENT_LOG, calculationStatusDto.getRequestId(), calculationStatusDto.getAnswerCode(),
                        calculationStatusDto.getAnswerDesignation());
            }
        }

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byFileIDRequestId(java.lang.String, java.lang.String)
     */
    @Override
    public MarketingRequest byFileIDRequestId(String reqId, String fileId) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        q.where(cb.equal(root.get(REQUEST_ID), cb.parameter(String.class, REQUEST_ID)),
                cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)));

        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);
        query.setParameter(REQUEST_ID, reqId);
        query.setParameter(FILEID, fileId);

        return query.getResultList().isEmpty() ? null : query.getResultList().get(0);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository#byFileIdAndStatusAndMrqCountAndLimit(java.lang.String, java.util.List,
     *      long, int, int)
     */
    @Override
    public List<MarketingRequest> byFileIdAndStatusAndMrqCountAndLimit(String fileId, List<String> statusList, long mrqCount, int offset,
            int chunkSize) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<MarketingRequest> q = cb.createQuery(aggregateRootClass);
        Root<MarketingRequest> root = q.from(aggregateRootClass);
        Expression<String> statusExpression = root.get(STATUS);
        Predicate statusPredicate = statusExpression.in(statusList);
        q.where(cb.equal(root.get(FILEID), cb.parameter(String.class, FILEID)), statusPredicate);
        TypedQuery<MarketingRequest> query = entityManager.createQuery(q);

        query.setParameter(FILEID, fileId);
        query.setFirstResult(offset);
        query.setMaxResults(chunkSize);

        return query.getResultList();
    }

}
