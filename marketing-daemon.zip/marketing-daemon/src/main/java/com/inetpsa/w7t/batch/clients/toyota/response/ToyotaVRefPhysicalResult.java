/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVRefPhysicalResult" })
@XmlRootElement(name = "VREF")
public class ToyotaVRefPhysicalResult {
    @XmlElement(name = "phys_result", required = true)
    protected List<ToyotaPhysicalResult> toyotaVRefPhysicalResult;

    public ToyotaVRefPhysicalResult() {
        super();
    }

    public ToyotaVRefPhysicalResult(List<ToyotaPhysicalResult> toyotaVRefPhysicalResult) {
        super();
        this.toyotaVRefPhysicalResult = toyotaVRefPhysicalResult;
    }

    public List<ToyotaPhysicalResult> getToyotaVRefPhysicalResult() {
        return toyotaVRefPhysicalResult;
    }

    public void setToyotaVRefPhysicalResult(List<ToyotaPhysicalResult> toyotaVRefPhysicalResult) {
        this.toyotaVRefPhysicalResult = toyotaVRefPhysicalResult;
    }

}
