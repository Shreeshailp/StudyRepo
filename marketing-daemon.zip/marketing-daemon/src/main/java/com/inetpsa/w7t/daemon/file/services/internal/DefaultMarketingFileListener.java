/*
 * Creation : 20 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import java.io.File;
import java.util.Optional;

import com.inetpsa.w7t.daemon.file.services.MarketingFileListener;

public abstract class DefaultMarketingFileListener implements MarketingFileListener {

    protected String name;
    protected File inputDirectory;
    protected File outputDirectory;
    protected String inputFileNamePattern;
    protected Integer refreshInterval;
    protected String outputfileNamePattern;
    protected String bcvNewtonForClient;
    protected Long processChunkSize;

    public DefaultMarketingFileListener() {
    }

    DefaultMarketingFileListener(String name, File inputDirectory, File outputDirectory, String inputFileNamePattern, Integer refreshInterval,
            String outputfileNamePattern, String bcvNewtonForClient, Long processChunkSize) {
        super();
        this.name = name;
        this.inputDirectory = inputDirectory;
        this.outputDirectory = outputDirectory;
        this.inputFileNamePattern = inputFileNamePattern;
        this.refreshInterval = refreshInterval;
        this.outputfileNamePattern = outputfileNamePattern;
        this.bcvNewtonForClient = bcvNewtonForClient;
        this.processChunkSize = processChunkSize;
    }

    public DefaultMarketingFileListener(String name, File inputDirectory, File outputDirectory, String inputFileNamePattern, Integer refreshInterval,
            String outputfileNamePattern, Long processChunkSize) {
        super();
        this.name = name;
        this.inputDirectory = inputDirectory;
        this.outputDirectory = outputDirectory;
        this.inputFileNamePattern = inputFileNamePattern;
        this.refreshInterval = refreshInterval;
        this.outputfileNamePattern = outputfileNamePattern;
        this.processChunkSize = processChunkSize;
    }

    protected abstract Optional<File> retrieveFile();

    protected abstract void parseFile(File file);
}
