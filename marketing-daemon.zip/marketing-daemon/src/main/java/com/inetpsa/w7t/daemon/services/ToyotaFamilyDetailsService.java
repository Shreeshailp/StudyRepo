/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.daemon.services;

import java.util.List;
import java.util.Map;

import org.seedstack.business.Service;

import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhase;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhysicalResult;

@Service
public interface ToyotaFamilyDetailsService {

    /**
     * Gets the vehicle characteristics.
     *
     * @param code the code
     * @param index the index
     * @return the vehicle characteristics
     */
    Map<String, List<ToyotaPhysicalResult>> getVehicleCharacteristics(String code, int index);

    /**
     * Gets the vehicle test results.
     *
     * @param code the code
     * @param index the index
     * @return the vehicle test results
     */
    Map<String, List<ToyotaPhase>> getVehicleTestResults(String code, int index);
}
