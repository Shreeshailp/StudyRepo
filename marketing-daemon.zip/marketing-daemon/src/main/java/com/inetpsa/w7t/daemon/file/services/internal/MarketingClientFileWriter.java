/*
 * Creation : 20 Aug 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import javax.inject.Named;

import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * @author E534811
 */
@Named("marketingClient")
public class MarketingClientFileWriter extends DefaultMarketingFileWriter {

    @Override
    public void serialize(MarketingRequest request) {

    }

    @Override
    public void publish() {

    }

    public MarketingClientFileWriter() {
        super();
    }

    public MarketingClientFileWriter(String name, MarketingDaemonClientConfig config) {
        super(name, config.getOutputDirectory(), config.getInputFilename());
    }

}
