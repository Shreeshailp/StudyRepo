/*
 * Creation : 24 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.request;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.hibernate.validator.constraints.NotEmpty;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * The Class CpdsDto.
 */
public class CpdsDto implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The request id. */
    private String requestId;

    /** The file id. */
    private String fileId;

    /** The request date. */
    private String requestDate;

    /** The request type. */
    private String requestType;

    /** The ecom date. */
    private String ecomDate;

    /** The vehicle mass. */
    private Double vehicleMass;

    /** The vehicle SCX. */
    private Double vehicleSCX;

    /** The vehicle CRR. */
    private Double vehicleCRR;

    /** The country. */
    private String country;

    /** The version 16. */
    private String version16;

    /** The color ext int. */
    private String colorExtInt;

    /** The ext attr. */
    private String extAttr;

    /** The filler. */
    private String filler;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The physical quantities. */
    private List<EnginePhysicalQuantity> physicalQuantities;

    /** The answer code. */
    private String answerCode;

    /** The answer designation. */
    private String answerDesignation;

    /** The status. */
    private String status;

    /** The maturity. */
    private String maturity;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the answer code.
     *
     * @return the answer code
     */
    public String getAnswerCode() {
        return answerCode;
    }

    /**
     * Sets the answer code.
     *
     * @param answerCode the new answer code
     */
    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    /**
     * Gets the answer designation.
     *
     * @return the answer designation
     */
    public String getAnswerDesignation() {
        return answerDesignation;
    }

    /**
     * Sets the answer designation.
     *
     * @param answerDesignation the new answer designation
     */
    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<EnginePhysicalQuantity> getPhysicalQuantities() {
        return physicalQuantities;
    }

    /**
     * Sets the physical quantities.
     *
     * @param physicalQuantities the new physical quantities
     */
    public void setPhysicalQuantities(List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
    }

    /**
     * Update physical quantities.
     *
     * @param physicalQuantities the physical quantities
     * @return the co 2 min max dto
     */
    public CpdsDto updatePhysicalQuantities(
            @NotEmpty(message = "When updating the physical quantities, the list must neither be null nor empty") List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
        return this;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the ecom date.
     *
     * @return the ecom date
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Sets the ecom date.
     *
     * @param ecomDate the new ecom date
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Gets the vehicle mass.
     *
     * @return the vehicle mass
     */
    public Double getVehicleMass() {
        return vehicleMass;
    }

    /**
     * Sets the vehicle mass.
     *
     * @param vehicleMass the new vehicle mass
     */
    public void setVehicleMass(Double vehicleMass) {
        this.vehicleMass = vehicleMass;
    }

    /**
     * Gets the vehicle SCX.
     *
     * @return the vehicle SCX
     */
    public Double getVehicleSCX() {
        return vehicleSCX;
    }

    /**
     * Sets the vehicle SCX.
     *
     * @param vehicleSCX the new vehicle SCX
     */
    public void setVehicleSCX(Double vehicleSCX) {
        this.vehicleSCX = vehicleSCX;
    }

    /**
     * Gets the vehicle CRR.
     *
     * @return the vehicle CRR
     */
    public Double getVehicleCRR() {
        return vehicleCRR;
    }

    /**
     * Sets the vehicle CRR.
     *
     * @param vehicleCRR the new vehicle CRR
     */
    public void setVehicleCRR(Double vehicleCRR) {
        this.vehicleCRR = vehicleCRR;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * Gets the version 16.
     *
     * @return the version 16
     */
    public String getVersion16() {
        return version16;
    }

    /**
     * Sets the version 16.
     *
     * @param version16 the new version 16
     */
    public void setVersion16(String version16) {
        this.version16 = version16;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the ext attr.
     *
     * @return the ext attr
     */
    public String getExtAttr() {
        return extAttr;
    }

    /**
     * Sets the ext attr.
     *
     * @param extAttr the new ext attr
     */
    public void setExtAttr(String extAttr) {
        this.extAttr = extAttr;
    }

    /**
     * Gets the filler.
     *
     * @return the filler
     */
    public String getFiller() {
        return filler;
    }

    /**
     * Sets the filler.
     *
     * @param filler the new filler
     */
    public void setFiller(String filler) {
        this.filler = filler;
    }

    /**
     * Getter maturity.
     *
     * @return the maturity
     */
    public String getMaturity() {
        return maturity;
    }

    /**
     * Setter maturity.
     *
     * @param maturity the maturity to set
     */
    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CpdsDto [requestId=" + requestId + ", requestDate=" + requestDate + ", requestType=" + requestType + ", ecomDate=" + ecomDate
                + ", vehicleMass=" + vehicleMass + ", vehicleSCX=" + vehicleSCX + ", vehicleCRR=" + vehicleCRR + ", country=" + country
                + ", version16=" + version16 + ", colorExtInt=" + colorExtInt + ", extAttr=" + extAttr + ", filler=" + filler + "]";
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((requestId == null) ? 0 : requestId.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CpdsDto other = (CpdsDto) obj;
        if (requestId == null) {
            if (other.requestId != null)
                return false;
        } else if (!requestId.equals(other.requestId))
            return false;
        return true;
    }

    /**
     * Physical quantities.
     *
     * @return the optional
     */
    public Optional<List<EnginePhysicalQuantity>> physicalQuantities() {
        if (this.physicalQuantities == null)
            return Optional.empty();
        return Optional.of(this.physicalQuantities);
    }
}
