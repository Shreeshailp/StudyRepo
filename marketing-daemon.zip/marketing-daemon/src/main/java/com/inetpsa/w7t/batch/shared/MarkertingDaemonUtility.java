/*
 * Creation : 22 Jan 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.clients.aogeos.request.AogeosRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.CronosRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.EliadeRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.IcubeRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.clients.cfgmot2.request.WltpJsonBatchRequestObject;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestTrackerDTO;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.model.Country;
import com.inetpsa.w7t.domains.references.model.DestinationCountry;

/**
 * The Class MarkertingDaemonUtility.
 *
 * @author E534811
 */
public final class MarkertingDaemonUtility {

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(MarkertingDaemonUtility.class);

    /** The Constant CLASS_NAME. */
    private static final String CLASS_NAME = "MarkertingDaemonUtility";

    /** The file id. */
    private static String fileId = null;

    /**
     * Instantiates a new markerting daemon utility.
     */
    private MarkertingDaemonUtility() {

    }

    /**
     * Generate file id.
     *
     * @param clientForAll            the client for all
     * @param sameDayMarketingRequest the same day marketing request
     * @param uniqueIdentifier        the unique identifier
     * @return the string
     */
    public static String generateFileId(String clientForAll, Optional<MarketingRequest> sameDayMarketingRequest, String uniqueIdentifier) {
        String currentDateStr = DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH).format(LocalDate.now());
        if (clientForAll.equalsIgnoreCase(MarketingDaemonServiceConstants.CONFIG_MOT2)) {
            clientForAll = MarketingDaemonServiceConstants.CFG_REQ_CONST2;
        }
        String client = clientForAll.substring(0, 2);
        Integer fileCount = 1;
        if (sameDayMarketingRequest.isPresent()) {
            String fileId = sameDayMarketingRequest.get().getFileId();
            if (fileId != null && !fileId.isEmpty()) {
                String fileId1 = client + uniqueIdentifier + fileId;
                logger.info("Same Day MarketingRequest latest File Id from database: {}", fileId1);
                fileCount = Integer.valueOf(fileId.substring(currentDateStr.length(), fileId.length()));
                ++fileCount;
            }
        }

        // fixed jira-579 starts here
        String strFileCount = fileCount.toString();
        // This below lines has been added to fix the PROD incident INCI10540535 - CRONOS file 25/11 20:42 -Starts Here
        char lastCharOfFileId = strFileCount.charAt(strFileCount.length() - 1);
        if (lastCharOfFileId == '0') {
            ++fileCount;
            strFileCount = fileCount.toString();
        }
        // PROD incident INCI10540535 - CRONOS file 25/11 20:42 -Ends Here

        logger.info("File Count : {}", fileCount);
        if (strFileCount.length() == 1) {
            strFileCount = "0" + strFileCount;
        } // fixed jira-579 ends here
        String generatedFileId = client + uniqueIdentifier + currentDateStr + strFileCount;
        logger.info("Generated File Id(client + uniqueIdentifier + currentDateStr + fileCount) : {}", generatedFileId);
        return generatedFileId;
    }

    /**
     * Update to machine name.
     *
     * @param finalFileIds                      the final file ids
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     * @param bcvResMacName                     the bcv res mac name
     */
    public static void updateToMachineName(Set<String> finalFileIds, MarketingRequestTrackerRepository marketingRequestTrackerRepository,
            String bcvResMacName) {
        marketingRequestTrackerRepository.updateToMachineName_MRT(finalFileIds, bcvResMacName);

    }

    /**
     * Creates the MRQ tracker.
     *
     * @param fileId                            the file id
     * @param client                            the client
     * @param mrqReqNumber                      the mrq req number
     * @param brqReqNumber                      the brq req number
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     * @param reqMacName                        the req mac name
     * @param originalFileId                    the original file id
     */
    public static void createMRQTracker(String fileId, String client, long mrqReqNumber, long brqReqNumber,
            MarketingRequestTrackerRepository marketingRequestTrackerRepository, String reqMacName, String originalFileId) {
        MarketingRequestTracker marketingRequestTracker = marketingRequestTrackerRepository.byFileId(fileId);

        if (marketingRequestTracker != null) {
            marketingRequestTracker.setMrqCount(marketingRequestTracker.getMrqCount() + mrqReqNumber);
            marketingRequestTracker.setValidReqCount(marketingRequestTracker.getValidReqCount() + brqReqNumber);
        } else {
            marketingRequestTracker = new MarketingRequestTracker();
            marketingRequestTracker.setGuid(UUID.randomUUID());
            marketingRequestTracker.setFileId(fileId);
            marketingRequestTracker.setClient(client);
            marketingRequestTracker.setOriginalFileId(originalFileId);
            marketingRequestTracker.setMrqCount(mrqReqNumber);
            marketingRequestTracker.setValidReqCount(brqReqNumber);
            marketingRequestTracker.setReqMacName(reqMacName);
            marketingRequestTracker.setCreatedDate(MarketingDateUtil.getTodaysDate());
            if (brqReqNumber == 0 && mrqReqNumber == brqReqNumber) {
                marketingRequestTracker.setAnswerGenerated(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequestTracker.setUpdatedDate(MarketingDateUtil.getTodaysDate());
            }
        }
        marketingRequestTrackerRepository.saveEntity(marketingRequestTracker);
        logger.info("Record inserted into MRT Table for the FILE_ID[{}]", fileId);
    }

    /**
     * Creates the MRQ tracker.
     *
     * @param fileId                            the file id
     * @param client                            the client
     * @param mrqReqNumber                      the mrq req number
     * @param brqReqNumber                      the brq req number
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     * @param reqMacName                        the req mac name
     * @param reqMacName                        the res mac name
     * @param originalFileId                    the original file id
     */
    public static void createMRQTracker(String fileId, String client, long mrqReqNumber, long brqReqNumber,
            MarketingRequestTrackerRepository marketingRequestTrackerRepository, String reqMacName, String resMacName, String originalFileId) {
        MarketingRequestTracker marketingRequestTracker = marketingRequestTrackerRepository.byFileId(fileId);

        if (marketingRequestTracker != null) {
            marketingRequestTracker.setMrqCount(marketingRequestTracker.getMrqCount() + mrqReqNumber);
            marketingRequestTracker.setValidReqCount(marketingRequestTracker.getValidReqCount() + brqReqNumber);
        } else {
            marketingRequestTracker = new MarketingRequestTracker();
            marketingRequestTracker.setGuid(UUID.randomUUID());
            marketingRequestTracker.setFileId(fileId);
            marketingRequestTracker.setClient(client);
            marketingRequestTracker.setOriginalFileId(originalFileId);
            marketingRequestTracker.setMrqCount(mrqReqNumber);
            marketingRequestTracker.setValidReqCount(brqReqNumber);
            marketingRequestTracker.setReqMacName(reqMacName);
            marketingRequestTracker.setResMacName(resMacName);
            marketingRequestTracker.setCreatedDate(MarketingDateUtil.getTodaysDate());
            if (brqReqNumber == 0 && mrqReqNumber == brqReqNumber) {
                marketingRequestTracker.setAnswerGenerated(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequestTracker.setUpdatedDate(MarketingDateUtil.getTodaysDate());
            }
        }
        marketingRequestTrackerRepository.saveEntity(marketingRequestTracker);
        logger.info("Record inserted into MRT Table for the FILE_ID[{}]", fileId);
    }

    /**
     * Creates the MRQ tracker.
     *
     * @param fileId                            the file id
     * @param client                            the client
     * @param mrqReqNumber                      the mrq req number
     * @param brqReqNumber                      the brq req number
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     */
    public static void createMRQTracker(String fileId, String client, long mrqReqNumber, long brqReqNumber,
            MarketingRequestTrackerRepository marketingRequestTrackerRepository) {
        MarketingRequestTracker marketingRequestTracker = new MarketingRequestTracker();
        marketingRequestTracker.setGuid(UUID.randomUUID());
        marketingRequestTracker.setFileId(fileId);
        marketingRequestTracker.setClient(client);
        marketingRequestTracker.setMrqCount(mrqReqNumber);
        marketingRequestTracker.setValidReqCount(brqReqNumber);
        marketingRequestTracker.setCreatedDate(MarketingDateUtil.getTodaysDate());

        marketingRequestTrackerRepository.saveEntity(marketingRequestTracker);
    }

    /**
     * Update MRQ tracker.
     *
     * @param fileId                            the file id
     * @param brqReqNumber                      the brq req number
     * @param reqMacName                        the req mac name
     * @param resMacName                        the res mac name
     * @param originalFileId                    the original file id
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     */
    public static void updateMRQTracker(String fileId, long brqReqNumber, String reqMacName, String resMacName, String originalFileId,
            MarketingRequestTrackerRepository marketingRequestTrackerRepository) {
        MarketingRequestTracker marketingRequestTracker = marketingRequestTrackerRepository.byFileId(fileId);
        if (marketingRequestTracker != null) {
            marketingRequestTracker.setValidReqCount(brqReqNumber + marketingRequestTracker.getValidReqCount());
            marketingRequestTracker.setOriginalFileId(originalFileId);
            marketingRequestTracker.setReqMacName(reqMacName);
            marketingRequestTracker.setResMacName(resMacName);
            marketingRequestTrackerRepository.saveEntity(marketingRequestTracker);
        }
    }

    /**
     * Gets the rejected request list.
     *
     * @param marketingRequestRepository the marketing request repository
     * @param client                     the client
     * @param requestRejectedStatus      the request rejected status
     * @param momentCode30               the moment code 30
     * @param fileId                     the file id
     * @return the rejected request list
     */
    public static List<AoCronosEliadeDto> getRejectedRequestList(MarketingRequestRepository marketingRequestRepository, String client,
            String requestRejectedStatus, boolean momentCode30, String fileId) {

        List<AoCronosEliadeDto> aoGeosEliadeCronosList = new ArrayList<>();
        List<MarketingRequest> marketingRequestStatusWrongList = marketingRequestRepository.byClientAndStatusAndFileId(client.toUpperCase(),
                requestRejectedStatus, fileId);

        marketingRequestStatusWrongList.forEach(marketingRequestStatusWrong -> {
            try {
                AoCronosEliadeDto rejectedAoGeosEliadeCronosDto = new AoCronosEliadeDto();
                rejectedAoGeosEliadeCronosDto.setMomentCode20("W020");
                if (momentCode30) {
                    rejectedAoGeosEliadeCronosDto.setMomentCode30("W030");
                }
                rejectedAoGeosEliadeCronosDto.setRequestId(marketingRequestStatusWrong.getRequestID());
                rejectedAoGeosEliadeCronosDto.setStatus(marketingRequestStatusWrong.getStatus());
                rejectedAoGeosEliadeCronosDto.setVehicleType("");
                rejectedAoGeosEliadeCronosDto.setValidityDate("");
                rejectedAoGeosEliadeCronosDto.setPrd(setRejectedRequestPrd(marketingRequestStatusWrong.getRequestID()));
                rejectedAoGeosEliadeCronosDto.setLotNumber(setRejectedRequestLotNumber(marketingRequestStatusWrong.getRequestID()));
                rejectedAoGeosEliadeCronosDto.setLineNumber(setRejectedRequestLineNumber(marketingRequestStatusWrong.getRequestID()));
                logger.info("REJECTED REQUEST ID :[{}]", marketingRequestStatusWrong.getRequestID());

                getConditions(aoGeosEliadeCronosList, marketingRequestStatusWrong, rejectedAoGeosEliadeCronosDto);
            } catch (Exception e) {
                logger.error("{}", e);
            }
        });
        return aoGeosEliadeCronosList;
    }

    /**
     * Gets the conditions.
     *
     * @param aoGeosEliadeCronosList        the ao geos eliade cronos list
     * @param marketingRequestStatusWrong   the marketing request status wrong
     * @param rejectedAoGeosEliadeCronosDto the rejected ao geos eliade cronos dto
     * @return the conditions
     */
    private static void getConditions(List<AoCronosEliadeDto> aoGeosEliadeCronosList, MarketingRequest marketingRequestStatusWrong,
            AoCronosEliadeDto rejectedAoGeosEliadeCronosDto) {
        if (marketingRequestStatusWrong != null) {
            if (marketingRequestStatusWrong.getVersion16() != null)
                rejectedAoGeosEliadeCronosDto.setVersion16(marketingRequestStatusWrong.getVersion16());
            if (marketingRequestStatusWrong.getOptions() != null)
                rejectedAoGeosEliadeCronosDto.setOptions(marketingRequestStatusWrong.getOptions());
            if (marketingRequestStatusWrong.getExtensionDate() != null)
                rejectedAoGeosEliadeCronosDto.setExtensionDate(marketingRequestStatusWrong.getExtensionDate());
            if (marketingRequestStatusWrong.getBrand() != null)
                rejectedAoGeosEliadeCronosDto.setBrand(marketingRequestStatusWrong.getBrand());
            if (marketingRequestStatusWrong.getColorExtInt() != null)
                rejectedAoGeosEliadeCronosDto.setColorExtInt(marketingRequestStatusWrong.getColorExtInt());
            if (marketingRequestStatusWrong.getOptions7C() != null)
                rejectedAoGeosEliadeCronosDto.setOptions7C(marketingRequestStatusWrong.getOptions7C());
            if (marketingRequestStatusWrong.getGestion7C() != null)
                rejectedAoGeosEliadeCronosDto.setGestion7C(marketingRequestStatusWrong.getGestion7C());
            if (marketingRequestStatusWrong.getTradingCountry() != null)
                rejectedAoGeosEliadeCronosDto.setTradingCountry(marketingRequestStatusWrong.getTradingCountry());
            if (marketingRequestStatusWrong.getAnswerCode() != null)
                rejectedAoGeosEliadeCronosDto.setAnswerCode(marketingRequestStatusWrong.getAnswerCode());
            if (marketingRequestStatusWrong.getAnswerDesig() != null)
                rejectedAoGeosEliadeCronosDto.setAnswerDesignation(marketingRequestStatusWrong.getAnswerDesig());
            if (marketingRequestStatusWrong.getMaturity() != null) {
                rejectedAoGeosEliadeCronosDto.setMaturity(marketingRequestStatusWrong.getMaturity());
            }
            aoGeosEliadeCronosList.add(rejectedAoGeosEliadeCronosDto);

        }

    }

    /**
     * Sets the rejected request prd.
     *
     * @param reqId the req id
     * @return the string
     */
    public static String setRejectedRequestPrd(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= 3) {
                return reqId.substring(0, 3);
            }
            return reqId.substring(0, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request lot number.
     *
     * @param reqId the req id
     * @return the string
     */
    public static String setRejectedRequestLotNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= 8) {
                return reqId.substring(3, 8);
            }
            return reqId.substring(3, reqId.length());
        }
        return reqId;
    }

    /**
     * Sets the rejected request line number.
     *
     * @param reqId the req id
     * @return the string
     */
    public static String setRejectedRequestLineNumber(String reqId) {
        if (reqId != null) {
            if (reqId.length() >= 20) {
                return reqId.substring(8, 20);
            }
            return reqId.substring(8, reqId.length());
        }
        return reqId;
    }

    /**
     * Update MR T valid req count.
     *
     * @param fileId                            the file id
     * @param count                             the count
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     */
    public static void updateMRT_ValidReq_Count(String fileId, int count, MarketingRequestTrackerRepository marketingRequestTrackerRepository) {
        marketingRequestTrackerRepository.updateMRT_ValidReq_Count(fileId, count);
    }

    /**
     * Partion marketing request list.
     *
     * @param marketingRequestList the marketing request list
     * @return the collection
     */
    public static Collection<List<MarketingRequest>> partionMarketingRequestList(List<MarketingRequest> marketingRequestList) {
        final AtomicInteger counter = new AtomicInteger(0);
        final int size = 500;
        return marketingRequestList.stream().collect(Collectors.groupingBy(it -> counter.getAndIncrement() / size)).values();
    }

    /**
     * Initialize valid countries.
     *
     * @param countryRepository            the country repository
     * @param destinationCountryRepository the destination country repository
     * @return the list
     */
    public static List<String> initializeValidCountries(CountryRepository countryRepository,
            DestinationCountryRepository destinationCountryRepository) {
        List<String> validCountryWithDestinations = new ArrayList<>();
        Map<UUID, String> countryMap = new HashMap<>();
        List<Country> countryList = countryRepository.allByCharacteristic("GA1");
        List<DestinationCountry> destinationCountryList = destinationCountryRepository.all();
        countryList.stream().forEach(country -> {
            countryMap.put(country.getGuid(), country.getCode());
        });
        destinationCountryList.stream().forEach(destinationCountry -> {
            UUID key = destinationCountry.getCounryId();
            if (!validCountryWithDestinations.contains(countryMap.get(key))) {
                validCountryWithDestinations.add(countryMap.get(key));
            }
        });
        return validCountryWithDestinations;
    }

    /**
     * Gets the all countries.
     *
     * @param countryRepository the country repository
     * @return the all countries
     */
    public static Map<UUID, String> getAllCountries(CountryRepository countryRepository) {
        List<Country> countryList = countryRepository.allByCharacteristic("GA1");
        Map<UUID, String> countryMap = new HashMap<>();
        countryList.stream().forEach(country -> {
            countryMap.put(country.getGuid(), country.getCode());
        });
        return countryMap;
    }

    /**
     * Gets the all countires having destinations.
     *
     * @param countryMap                   the country map
     * @param destinationCountryRepository the destination country repository
     * @return the all countires having destinations
     */
    public static List<String> getAllCountiresHavingDestinations(Map<UUID, String> countryMap,
            DestinationCountryRepository destinationCountryRepository) {
        List<DestinationCountry> destinationCountryList = destinationCountryRepository.all();
        List<String> validCountryWithDestinations = new ArrayList<>();

        if (!countryMap.isEmpty()) {
            destinationCountryList.stream().forEach(destinationCountry -> {
                UUID key = destinationCountry.getCounryId();
                if (!validCountryWithDestinations.contains(countryMap.get(key))) {
                    validCountryWithDestinations.add(countryMap.get(key));
                }
            });
        }
        return validCountryWithDestinations;
    }

    /**
     * Save marketing request.
     *
     * @param marketingRequestsList      the marketing requests list
     * @param marketingRequestRepository the marketing request repository
     * @param threadPoolMasterRepository the thread pool master repository
     * @return the string
     */
    public static String saveMarketingRequest(List<MarketingRequest> marketingRequestsList, MarketingRequestRepository marketingRequestRepository,
            ThreadPoolMasterRepository threadPoolMasterRepository) {

        int chunkSize = 500;

        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(CLASS_NAME);
        logger.info(" thread pool size : [{}]", threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        try {
            List<Future<String>> futuresList = new CopyOnWriteArrayList<>();
            List<List<MarketingRequest>> splitedList = ListUtils.partition(marketingRequestsList, chunkSize);

            if (splitedList != null && !splitedList.isEmpty()) {
                logger.info("Splited List Size : [{}] ", splitedList.size());
                splitedList.forEach(list -> {
                    Future<String> future = executorService.submit(() -> processParallelList(list, marketingRequestRepository));
                    futuresList.add(future);
                });

            }

            for (Future<String> future : futuresList) {

                fileId = future.get();
            }
        } catch (Exception e) {
            logger.error("ERROR in MarkertingDaemonUtility saveMarketingRequest : [{}]", e);
        } finally {
            executorService.shutdown();
        }
        return fileId;
    }

    /**
     * Process parallel list.
     *
     * @param list                       the list
     * @param marketingRequestRepository the marketing request repository
     * @return the string
     */
    private static String processParallelList(List<MarketingRequest> list, MarketingRequestRepository marketingRequestRepository) {
        String fileId = null;
        marketingRequestRepository.persistEntityBatch(list);
        return fileId;
    }

    /**
     * Process.
     *
     * @param markeringRequest           the markering request
     * @param marketingRequestRepository the marketing request repository
     * @return the string
     */
    public static String process(MarketingRequest markeringRequest, MarketingRequestRepository marketingRequestRepository) {
        boolean isUniqueRequest = true;
        String fileId = null;
        try {
            marketingRequestRepository.persistEntity(markeringRequest);
        } catch (Exception e) {
            isUniqueRequest = false;
            logger.error("Error in process() {}", e);
        }
        if (isUniqueRequest) {
            fileId = markeringRequest.getFileId();

        }
        return fileId;
    }

    /**
     * Gets the cronos last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the cronos last request number from MRS
     */
    public static long getCronosLastRequestNumberFromMRS(Set<CronosRequestDTO> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Gets the aogeos last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the aogeos last request number from MRS
     */
    public static long getAogeosLastRequestNumberFromMRS(Set<AogeosRequestDTO> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Gets the eliade last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the eliade last request number from MRS
     */
    public static long getEliadeLastRequestNumberFromMRS(Set<EliadeRequestDTO> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Gets the icube last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the icube last request number from MRS
     */
    public static long getIcubeLastRequestNumberFromMRS(Set<IcubeRequestDTO> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Gets the last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the last request number from MRS
     */
    public static long getLastRequestNumberFromMRS(List<WltpJsonBatchRequestObject> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Gets the toyota last request number from MRS.
     *
     * @param dtosList                   the dtos list
     * @param prevReqNumber              the prev req number
     * @param threadPoolMasterRepository the thread pool master repository
     * @param client                     the client
     * @param fileId                     the file id
     * @return the toyota last request number from MRS
     */
    public static long getToyotaLastRequestNumberFromMRS(List<MarketingRequest> dtosList, long prevReqNumber,
            ThreadPoolMasterRepository threadPoolMasterRepository, String client, String fileId) {
        if (dtosList.stream().findFirst().isPresent()) {
            prevReqNumber = threadPoolMasterRepository.getLastRequestNumber(client, MarketingDaemonConfig.getReqMachine(), fileId);
            if (prevReqNumber == 0)
                threadPoolMasterRepository.createMRS(client, dtosList.size(), MarketingDaemonConfig.getReqMachine(), fileId);
            threadPoolMasterRepository.updateMRS(client, (prevReqNumber + dtosList.size()), MarketingDaemonConfig.getReqMachine(), fileId);
        }
        return prevReqNumber;
    }

    /**
     * Write into file.
     *
     * @param sourceFile the source file
     * @param records    the records
     */
    public static void writeIntoFile(File sourceFile, List<String> records) {
        Path path = Paths.get(sourceFile.getAbsolutePath());
        try (BufferedWriter writer = Files.newBufferedWriter(path, Charset.forName("UTF-8"))) {
            write(records, writer);
        } catch (IOException ex) {
            logger.error("Error while writing file {}", ex);
        }
    }

    /**
     * Write.
     *
     * @param records the records
     * @param writer  the writer
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private static void write(List<String> records, Writer writer) throws IOException {
        for (String record : records) {
            writer.write(record);
        }
        writer.flush();
        writer.close();
    }

    /**
     * Generate internal request id.
     *
     * @param prevReqNumber the prev req number
     * @param fileId        the file id
     * @return the string
     */
    public static String generateInternalRequestId(long prevReqNumber, String fileId) {
        StringBuilder constantOfZeros = new StringBuilder();
        int numOfZerosToBeConcat = 20 - fileId.length();
        for (int i = 1; i <= numOfZerosToBeConcat; i++) {
            constantOfZeros.append("0");
        }
        String constantZero = constantOfZeros.toString();

        return fileId + constantZero.substring(0, constantZero.length() - String.valueOf(prevReqNumber).length()) + prevReqNumber;
    }

    /**
     * Gets the unique ao crono eliade list.
     *
     * @param list the list
     * @return the unique ao crono eliade list
     */
    // fix of jira-557
    public static List<AoCronosEliadeDto> getUniqueAoCronoEliadeList(List<AoCronosEliadeDto> list) {
        Map<String, List<AoCronosEliadeDto>> groupByFileIdList = list.stream().collect(Collectors.groupingBy(AoCronosEliadeDto::getFileId));
        Map<String, List<AoCronosEliadeDto>> sortedMap = groupByFileIdList.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
        logger.info("Keys of sorted Map : [{}]", sortedMap.keySet());
        String key = (String) sortedMap.keySet().toArray()[0];
        return sortedMap.get(key);
    }

    /**
     * Generate file id for cpds.
     *
     * @param sameDayMarketingRequest the same day marketing request
     * @param cpds                    the cpds
     * @param uniqueIdentifier        the unique identifier
     * @return the string
     */
    public static String generateFileIdForCpds(Optional<MarketingRequestTracker> sameDayMarketingRequest, String cpds, String uniqueIdentifier) {
        Integer fileCount = 1;
        String client = cpds.substring(0, 2);
        String currentDateStr = DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH).format(LocalDate.now());
        if (sameDayMarketingRequest.isPresent()) {
            String fileId = sameDayMarketingRequest.get().getFileId();
            if (fileId != null) {
                fileCount = Integer.valueOf(fileId.substring(currentDateStr.length(), fileId.length()));
                ++fileCount;
            }
        }
        if (fileCount > 0 && fileCount < 10) {
            return client + uniqueIdentifier + currentDateStr + "0" + fileCount;
        }
        return client + uniqueIdentifier + currentDateStr + fileCount;
    }

    public static List<MarketingRequest> getMarketingRequestByChunk(MarketingRequestTrackerDTO marketingRequestTrackerDTO,
            MarketingRequestRepository marketingRequestRepository) {
        List<MarketingRequest> allMarketingRequestList = new ArrayList<>();
        int offset = 0;
        int chunkSize = MarketingDaemonServiceConstants.CHUNK_SIZE;
        List<String> statusList = new ArrayList<>();
        statusList.add(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));

        List<MarketingRequest> marketingRequestList = marketingRequestRepository.byFileIdAndStatusAndMrqCountAndLimit(
                marketingRequestTrackerDTO.getFileId(), statusList, marketingRequestTrackerDTO.getMrqCount(), offset, chunkSize);
        allMarketingRequestList.addAll(marketingRequestList);

        while (marketingRequestList != null && !marketingRequestList.isEmpty() && marketingRequestList.size() == chunkSize) {
            logger.info("Offset[{}]", offset);
            logger.info("Chunk Size[{}]", chunkSize);
            offset += chunkSize;
            marketingRequestList = marketingRequestRepository.byFileIdAndStatusAndMrqCountAndLimit(marketingRequestTrackerDTO.getFileId(), statusList,
                    marketingRequestTrackerDTO.getMrqCount(), offset, chunkSize);
            if (CollectionUtils.isNotEmpty(marketingRequestList)) {
                allMarketingRequestList.addAll(marketingRequestList);
                logger.info("Added next [{}] records", offset);
            }
        }
        if (allMarketingRequestList.size() == marketingRequestTrackerDTO.getValidReqCount()) {
            logger.info("Valid Request count matches to MRT-MRQ count for the FILE_ID [{}]", marketingRequestTrackerDTO.getFileId());
            return allMarketingRequestList;
        }
        return Collections.<MarketingRequest>emptyList();
    }
}
