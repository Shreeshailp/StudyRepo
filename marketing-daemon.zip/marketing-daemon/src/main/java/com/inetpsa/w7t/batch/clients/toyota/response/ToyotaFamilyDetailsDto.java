/*
 * Creation : 26 Oct 2021
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

/**
 * The Class ToyotaFamilyDetailsDto.
 *
 * @author E562493
 */
public class ToyotaFamilyDetailsDto {

    /** The code. */
    private String code;

    /** The index. */
    private int index;

    /** The label. */
    private String label;

    /** The pmax. */
    private String pmax;

    /**
     * Getter code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter code.
     *
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Getter index.
     *
     * @return the index
     */
    public int getIndex() {
        return index;
    }

    /**
     * Setter index.
     *
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }

    /**
     * Getter label.
     *
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * Setter label.
     *
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Getter pmax.
     *
     * @return the pmax
     */
    public String getPmax() {
        return pmax;
    }

    /**
     * Setter pmax.
     *
     * @param pmax the pmax to set
     */
    public void setPmax(String pmax) {
        this.pmax = pmax;
    }

}
