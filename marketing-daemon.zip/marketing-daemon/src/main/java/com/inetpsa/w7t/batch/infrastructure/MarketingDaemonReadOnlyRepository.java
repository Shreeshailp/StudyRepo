/*
 * Creation : 6 Sep 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.infrastructure;

import java.util.Set;

import org.seedstack.business.finder.Finder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

/**
 * The Interface MarketingDaemonReadOnlyRepository.
 *
 * @author E534811
 */
@Finder
@Transactional(readOnly = true)
@JpaUnit("wltp-domain-jpa-unit")
public interface MarketingDaemonReadOnlyRepository {

    /**
     * Find file I ds by reqest ids.
     *
     * @param requestIds the request ids
     * @return the sets the
     */
    Set<String> findFileIDsByReqestIds(Set<String> requestIds);

}
