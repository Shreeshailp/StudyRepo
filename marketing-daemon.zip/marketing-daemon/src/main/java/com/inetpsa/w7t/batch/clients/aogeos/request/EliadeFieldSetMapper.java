/*
 * Creation : 7 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

/**
 * The Class AoGeosFieldSetMapper.
 */
public class EliadeFieldSetMapper implements FieldSetMapper<EliadeRequestDTO> {

    /** The file id. */
    private String fileId;

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the file id.
     *
     * @return the file id
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Sets the file id.
     *
     * @param fileId the new file id
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * Retrieve interstep data.
     *
     * @param stepExecution the step execution
     */
    @BeforeStep
    public void retrieveInterstepData(StepExecution stepExecution) {
        this.fileId = stepExecution.getJobExecution().getExecutionContext().get("FILE_ID").toString();
        this.uniqueIdentifier = stepExecution.getJobExecution().getExecutionContext().get("UNIQUE_IDENTIFIER").toString();
        // jira-660 fix
        this.fsFlagFileName = stepExecution.getJobExecution().getExecutionContext().get("FS_FLAG_FILE_NAME").toString();

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.file.mapping.FieldSetMapper#mapFieldSet(org.springframework.batch.item.file.transform.FieldSet)
     */
    @Override
    public EliadeRequestDTO mapFieldSet(FieldSet fieldSet) throws BindException {

        EliadeRequestDTO eliadeRequestResponse = new EliadeRequestDTO();
        eliadeRequestResponse.setMovementCode(fieldSet.readRawString("movementCode"));
        eliadeRequestResponse.setLotNumber(fieldSet.readRawString("lotNumber"));
        eliadeRequestResponse.setLineNumber(fieldSet.readRawString("lineNumber"));
        eliadeRequestResponse.setPrd(fieldSet.readRawString("prd"));
        eliadeRequestResponse.setBrand(fieldSet.readRawString("brand"));
        eliadeRequestResponse.setExtensionDate(fieldSet.readRawString("extensionDate").trim());
        eliadeRequestResponse.setHabillage_Ext(fieldSet.readRawString("habillage_Ext"));
        String options7c = fieldSet.readRawString("options7c").trim();
        String gestion7c = fieldSet.readRawString("gestion");
        eliadeRequestResponse.setOptions7c(options7c);
        eliadeRequestResponse.setGestion7c(gestion7c);
        eliadeRequestResponse.setVersion(fieldSet.readRawString("version"));
        eliadeRequestResponse.setHabillage_Int(fieldSet.readRawString("habillage_Int"));
        eliadeRequestResponse.setCountry(fieldSet.readRawString("country"));
        eliadeRequestResponse.setFiller(fieldSet.readRawString("filler").trim());
        String requestId = eliadeRequestResponse.getPrd() + eliadeRequestResponse.getLotNumber() + eliadeRequestResponse.getLineNumber();
        eliadeRequestResponse.setRequestId(requestId);
        eliadeRequestResponse.setFileId(this.fileId);
        eliadeRequestResponse.setUniqueIdentifier(this.uniqueIdentifier);
        // jira-660 fix
        eliadeRequestResponse.setFsFlagFileName(this.fsFlagFileName);
        return eliadeRequestResponse;
    }

}
