/*
 * Creation : 17 Oct 2018
 */
package com.inetpsa.w7t.batch.infrastructure;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.google.inject.Inject;

public class VlowVHighCombinedResultJpaFinder implements VlowVHighCombinedResultFinder {
    @Inject
    EntityManager entityManager;
    @Logging
    private Logger logger;

    @Override
    public String getCombValues(String co2, String comb, String code, String index) {
        String sqlQuery = "SELECT mvl.value FROM W7TQTMVL mvl INNER JOIN  W7TQTMTP mtp ON mtp.id=mvl.type and mtp.code=? INNER JOIN W7TQTCPH cph ON mvl.phase=cph.id and cph.code='COMB' INNER JOIN W7TQTTVH tvh ON mvl.vehicle_id=tvh.id INNER JOIN W7TQTFAM fam ON tvh.family_id= fam.id INNER JOIN W7TQTTVT tvt ON tvt.id=tvh.type and tvt.code=? where fam.code=? and fam.ind=? ";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, co2);
        q.setParameter(2, comb);
        q.setParameter(3, code);
        q.setParameter(4, index);
        logger.debug("Fetched Combo Value");
        return q.getResultList().isEmpty() ? "" : q.getResultList().get(0).toString();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<String[]> getCombValuesByCodeAndIndex(String code, String index) {
        String sqlQuery = "SELECT mvl.value,mtp.code as MeasureValue,tvt.code as VehicleTypeCode,fam.code as FamilyCode,fam.ind as FamilyIndex FROM W7TQTMVL mvl INNER JOIN  W7TQTMTP mtp ON mtp.id=mvl.type "
                + "INNER JOIN W7TQTCPH cph ON mvl.phase=cph.id and cph.code='COMB' INNER JOIN W7TQTTVH tvh ON mvl.vehicle_id=tvh.id "
                + "INNER JOIN W7TQTFAM fam ON tvh.family_id= fam.id "
                + "INNER JOIN W7TQTTVT tvt ON tvt.id=tvh.type where fam.code=? and fam.ind=? and tvt.code in('VLOW','VHIGH')";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, code);
        q.setParameter(2, index);
        logger.debug("Fetched Combo Value");
        return q.getResultList();
    }

}
