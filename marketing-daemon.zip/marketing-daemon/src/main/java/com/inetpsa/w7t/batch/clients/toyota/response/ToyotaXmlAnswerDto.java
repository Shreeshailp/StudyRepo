/*
 * Creation : 4 Oct 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;
import java.util.Optional;

import org.hibernate.validator.constraints.NotEmpty;

import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;

/**
 * @author E534811
 */
public class ToyotaXmlAnswerDto {

    /** The Version 16. */
    private String Version16 = "";

    /** The color ext int. */
    private String colorExtInt = "";

    /** The options. */
    private String options = "";

    /** The options 5 C. */
    private String options5C = "";

    /** The options 7 C. */
    private String options7C = "";

    /** The gestion 5 C. */
    private String gestion5C = "";

    /** The gestion 7 C. */
    private String gestion7C = "";

    /** The trading country. */
    private String tradingCountry = "";

    /** The request type. */
    private String requestType = "";

    /** The extension date. */
    private String extensionDate = "";

    /** The mounting center. */
    private String mountingCenter = "";

    /** The ext attr. */
    private String extAttr = "";

    /** The mass socle. */
    private String massSocle = "";

    /** The mass equip. */
    private String massEquip = "";

    /** The mass vehic. */
    private String massVehic = "";

    /** The scx socle. */
    private String scxSocle = "";

    /** The scx equip. */
    private String scxEquip = "";

    /** The scx vehic. */
    private String scxVehic = "";

    /** The crr vehic. */
    private String crrVehic = "";

    /** The status. */
    private String status = "";

    /** The request date. */
    private String requestDate = "";

    /** The nb options. */
    private String nbOptions = "";

    /** The nb gestion. */
    private String nbGestion = "";
    private String answerCode = "";
    private String answerDesignation = "";

    private String ecomDate = "";

    private String fileId;

    private String answerDate;

    /** The cfg mot 2 json response. */
    private ToyotaXmlAnswerResponse toyotaXmlAnswerResponse;

    /**
     * Gets the nb options.
     *
     * @return the nb options
     */
    public String getNbOptions() {
        return nbOptions;
    }

    /**
     * Sets the nb options.
     *
     * @param nbOptions the new nb options
     */
    public void setNbOptions(String nbOptions) {
        this.nbOptions = nbOptions;
    }

    /**
     * Gets the nb gestion.
     *
     * @return the nb gestion
     */
    public String getNbGestion() {
        return nbGestion;
    }

    /**
     * Sets the nb gestion.
     *
     * @param nbGestion the new nb gestion
     */
    public void setNbGestion(String nbGestion) {
        this.nbGestion = nbGestion;
    }

    /** The gestion. */
    private String gestion;

    /** The request id. */
    private String requestId = "";

    /** The physical quantities. */
    private List<EnginePhysicalQuantity> physicalQuantities;

    /**
     * Gets the physical quantities.
     *
     * @return the physical quantities
     */
    public List<EnginePhysicalQuantity> getPhysicalQuantities() {
        return physicalQuantities;
    }

    /**
     * Sets the physical quantities.
     *
     * @param physicalQuantities the new physical quantities
     */
    public void setPhysicalQuantities(List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
    }

    /**
     * Gets the version 16.
     *
     * @return the version 16
     */
    public String getVersion16() {
        return Version16;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Sets the version 16.
     *
     * @param version16 the new version 16
     */
    public void setVersion16(String version16) {
        Version16 = version16;
    }

    /**
     * Gets the color ext int.
     *
     * @return the color ext int
     */
    public String getColorExtInt() {
        return colorExtInt;
    }

    /**
     * Sets the color ext int.
     *
     * @param colorExtInt the new color ext int
     */
    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    /**
     * Gets the options.
     *
     * @return the options
     */
    public String getOptions() {
        return options;
    }

    /**
     * Sets the options.
     *
     * @param options the new options
     */
    public void setOptions(String options) {
        this.options = options;
    }

    /**
     * Gets the options 5 C.
     *
     * @return the options 5 C
     */
    public String getOptions5C() {
        return options5C;
    }

    /**
     * Sets the options 5 C.
     *
     * @param options5c the new options 5 C
     */
    public void setOptions5C(String options5c) {
        options5C = options5c;
    }

    /**
     * Gets the options 7 C.
     *
     * @return the options 7 C
     */
    public String getOptions7C() {
        return options7C;
    }

    /**
     * Sets the options 7 C.
     *
     * @param options7c the new options 7 C
     */
    public void setOptions7C(String options7c) {
        options7C = options7c;
    }

    /**
     * Gets the gestion 5 C.
     *
     * @return the gestion 5 C
     */
    public String getGestion5C() {
        return gestion5C;
    }

    /**
     * Sets the gestion 5 C.
     *
     * @param gestion5c the new gestion 5 C
     */
    public void setGestion5C(String gestion5c) {
        gestion5C = gestion5c;
    }

    /**
     * Gets the gestion 7 C.
     *
     * @return the gestion 7 C
     */
    public String getGestion7C() {
        return gestion7C;
    }

    /**
     * Sets the gestion 7 C.
     *
     * @param gestion7c the new gestion 7 C
     */
    public void setGestion7C(String gestion7c) {
        gestion7C = gestion7c;
    }

    /**
     * Gets the trading country.
     *
     * @return the trading country
     */
    public String getTradingCountry() {
        return tradingCountry;
    }

    /**
     * Sets the trading country.
     *
     * @param tradingCountry the new trading country
     */
    public void setTradingCountry(String tradingCountry) {
        this.tradingCountry = tradingCountry;
    }

    /**
     * Gets the request type.
     *
     * @return the request type
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * Sets the request type.
     *
     * @param requestType the new request type
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * Gets the extension date.
     *
     * @return the extension date
     */
    public String getExtensionDate() {
        return extensionDate;
    }

    /**
     * Sets the extension date.
     *
     * @param extensionDate the new extension date
     */
    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    /**
     * Gets the mounting center.
     *
     * @return the mounting center
     */
    public String getMountingCenter() {
        return mountingCenter;
    }

    /**
     * Sets the mounting center.
     *
     * @param mountingCenter the new mounting center
     */
    public void setMountingCenter(String mountingCenter) {
        this.mountingCenter = mountingCenter;
    }

    /**
     * Gets the ext attr.
     *
     * @return the ext attr
     */
    public String getExtAttr() {
        return extAttr;
    }

    /**
     * Sets the ext attr.
     *
     * @param extAttr the new ext attr
     */
    public void setExtAttr(String extAttr) {
        this.extAttr = extAttr;
    }

    /**
     * Gets the mass socle.
     *
     * @return the mass socle
     */
    public String getMassSocle() {
        return massSocle;
    }

    /**
     * Sets the mass socle.
     *
     * @param massSocle the new mass socle
     */
    public void setMassSocle(String massSocle) {
        this.massSocle = massSocle;
    }

    /**
     * Gets the mass equip.
     *
     * @return the mass equip
     */
    public String getMassEquip() {
        return massEquip;
    }

    /**
     * Sets the mass equip.
     *
     * @param massEquip the new mass equip
     */
    public void setMassEquip(String massEquip) {
        this.massEquip = massEquip;
    }

    /**
     * Gets the mass vehic.
     *
     * @return the mass vehic
     */
    public String getMassVehic() {
        return massVehic;
    }

    /**
     * Sets the mass vehic.
     *
     * @param massVehic the new mass vehic
     */
    public void setMassVehic(String massVehic) {
        this.massVehic = massVehic;
    }

    /**
     * Gets the scx socle.
     *
     * @return the scx socle
     */
    public String getScxSocle() {
        return scxSocle;
    }

    /**
     * Sets the scx socle.
     *
     * @param scxSocle the new scx socle
     */
    public void setScxSocle(String scxSocle) {
        this.scxSocle = scxSocle;
    }

    /**
     * Gets the scx equip.
     *
     * @return the scx equip
     */
    public String getScxEquip() {
        return scxEquip;
    }

    /**
     * Sets the scx equip.
     *
     * @param scxEquip the new scx equip
     */
    public void setScxEquip(String scxEquip) {
        this.scxEquip = scxEquip;
    }

    /**
     * Gets the scx vehic.
     *
     * @return the scx vehic
     */
    public String getScxVehic() {
        return scxVehic;
    }

    /**
     * Sets the scx vehic.
     *
     * @param scxVehic the new scx vehic
     */
    public void setScxVehic(String scxVehic) {
        this.scxVehic = scxVehic;
    }

    /**
     * Gets the crr vehic.
     *
     * @return the crr vehic
     */
    public String getCrrVehic() {
        return crrVehic;
    }

    /**
     * Sets the crr vehic.
     *
     * @param crrVehic the new crr vehic
     */
    public void setCrrVehic(String crrVehic) {
        this.crrVehic = crrVehic;
    }

    /**
     * Gets the request date.
     *
     * @return the request date
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the request date.
     *
     * @param requestDate the new request date
     */
    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    /**
     * Gets the gestion.
     *
     * @return the gestion
     */
    public String getGestion() {
        return gestion;
    }

    /**
     * Sets the gestion.
     *
     * @param gestion the new gestion
     */
    public void setGestion(String gestion) {
        this.gestion = gestion;
    }

    /**
     * Gets the request id.
     *
     * @return the request id
     */
    public String getRequestId() {
        return requestId;
    }

    public String getAnswerCode() {
        return answerCode;
    }

    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    public String getAnswerDesignation() {
        return answerDesignation;
    }

    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    /**
     * Sets the request id.
     *
     * @param requestId the new request id
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * Physical quantities.
     *
     * @return the optional
     */
    public Optional<List<EnginePhysicalQuantity>> physicalQuantities() {
        if (this.physicalQuantities == null)
            return Optional.empty();
        return Optional.of(this.physicalQuantities);
    }

    /**
     * Update physical quantities.
     *
     * @param physicalQuantities the physical quantities
     * @return the cfg mot 2 answer dto
     */
    public ToyotaXmlAnswerDto updatePhysicalQuantities(
            @NotEmpty(message = "When updating the physical quantities, the list must neither be null nor empty") List<EnginePhysicalQuantity> physicalQuantities) {
        this.physicalQuantities = physicalQuantities;
        return this;
    }

    /**
     * Getter ecomDate
     * 
     * @return the ecomDate
     */
    public String getEcomDate() {
        return ecomDate;
    }

    /**
     * Setter ecomDate
     * 
     * @param ecomDate the ecomDate to set
     */
    public void setEcomDate(String ecomDate) {
        this.ecomDate = ecomDate;
    }

    /**
     * Getter fileId
     * 
     * @return the fileId
     */
    public String getFileId() {
        return fileId;
    }

    /**
     * Setter fileId
     * 
     * @param fileId the fileId to set
     */
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    /**
     * Getter answerDate
     * 
     * @return the answerDate
     */
    public String getAnswerDate() {
        return answerDate;
    }

    /**
     * Setter answerDate
     * 
     * @param answerDate the answerDate to set
     */
    public void setAnswerDate(String answerDate) {
        this.answerDate = answerDate;
    }

    /**
     * Instantiates a new toyota answer dto.
     */
    public ToyotaXmlAnswerDto() {
    }

    /**
     * Getter toyotaXmlAnswerResponse
     * 
     * @return the toyotaXmlAnswerResponse
     */
    public ToyotaXmlAnswerResponse getToyotaXmlAnswerResponse() {
        return toyotaXmlAnswerResponse;
    }

    /**
     * Setter toyotaXmlAnswerResponse
     * 
     * @param toyotaXmlAnswerResponse the toyotaXmlAnswerResponse to set
     */
    public void setToyotaXmlAnswerResponse(ToyotaXmlAnswerResponse toyotaXmlAnswerResponse) {
        this.toyotaXmlAnswerResponse = toyotaXmlAnswerResponse;
    }

    /**
     * Instantiates a new toyota answer dto.
     *
     * @param requestType the request type
     * @param extensionDate the extension date
     * @param extAttr the ext attr
     */
    public ToyotaXmlAnswerDto(String requestType, String extensionDate, String extAttr) {
        super();
        this.requestType = requestType;
        this.extensionDate = extensionDate;
        this.extAttr = extAttr;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaXmlAnswerDto [Version16=" + Version16 + ", colorExtInt=" + colorExtInt + ", options=" + options + ", options5C=" + options5C
                + ", options7C=" + options7C + ", gestion5C=" + gestion5C + ", gestion7C=" + gestion7C + ", tradingCountry=" + tradingCountry
                + ", requestType=" + requestType + ", extensionDate=" + extensionDate + ", mountingCenter=" + mountingCenter + ", extAttr=" + extAttr
                + ", massSocle=" + massSocle + ", massEquip=" + massEquip + ", massVehic=" + massVehic + ", scxSocle=" + scxSocle + ", scxEquip="
                + scxEquip + ", scxVehic=" + scxVehic + ", crrVehic=" + crrVehic + ", status=" + status + ", requestDate=" + requestDate
                + ", nbOptions=" + nbOptions + ", nbGestion=" + nbGestion + ", answerCode=" + answerCode + ", answerDesignation=" + answerDesignation
                + ", ecomDate=" + ecomDate + ", fileId=" + fileId + ", answerDate=" + answerDate + ", toyotaXmlAnswerResponse="
                + toyotaXmlAnswerResponse + ", gestion=" + gestion + ", requestId=" + requestId + ", physicalQuantities=" + physicalQuantities + "]";
    }

}
