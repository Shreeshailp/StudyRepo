/**
 * 
 */
package com.inetpsa.w7t.domain.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * @author E534811
 */
@Entity
@Table(name = "W7TQT_MarketingResult")
public class MarketingResult extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "answerCode")
    private String answerCode;

    @Column(name = "answerDesignation")
    private String answerDesignation;

    @Column(name = "resultDateTime")
    private String resultDateTime;

    @Column(name = "resultValidityDateTime")
    private String resultValidityDateTime;

    @Column(name = "resultValidityDate")
    private String resultValidityDate;

    @Column(name = "resultDestination")
    private String resultDestination;

    public String getAnswerCode() {
        return answerCode;
    }

    public void setAnswerCode(String answerCode) {
        this.answerCode = answerCode;
    }

    public String getAnswerDesignation() {
        return answerDesignation;
    }

    public void setAnswerDesignation(String answerDesignation) {
        this.answerDesignation = answerDesignation;
    }

    public String getResultDateTime() {
        return resultDateTime;
    }

    public void setResultDateTime(String resultDateTime) {
        this.resultDateTime = resultDateTime;
    }

    public String getResultValidityDate() {
        return resultValidityDate;
    }

    public void setResultValidityDate(String resultValidityDate) {
        this.resultValidityDate = resultValidityDate;
    }

    public String getResultDestination() {
        return resultDestination;
    }

    public void setResultDestination(String resultDestination) {
        this.resultDestination = resultDestination;
    }

    @Override
    public UUID getEntityId() {
        return this.guid;
    }

}
