/*
 * Creation : 3 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import javax.inject.Inject;

import org.seedstack.business.assembler.FluentAssembler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestTrackerDTO;

public class CfgMot2JsonAnswerItemProcessor implements ItemProcessor<MarketingRequestTrackerDTO, MarketingRequestAnswerDTO> {

    @Inject
    FluentAssembler fluentAssembler;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public MarketingRequestAnswerDTO process(MarketingRequestTrackerDTO marketingRequestTrackerDTO) throws Exception {
        MarketingRequestAnswerDTO marketingRequestAnswerDTO = new MarketingRequestAnswerDTO();
        return marketingRequestAnswerDTO;
    }

}
