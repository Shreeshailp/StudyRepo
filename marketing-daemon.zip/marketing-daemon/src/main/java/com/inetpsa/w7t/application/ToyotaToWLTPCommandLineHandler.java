/*
 * Creation : 17 Sep 2018
 */
package com.inetpsa.w7t.application;

import java.io.File;
import java.io.FileFilter;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;

import javax.inject.Inject;

import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.cli.CliCommand;
import org.seedstack.seed.cli.CommandLineHandler;
import org.slf4j.Logger;

import com.inetpsa.w7t.batch.clients.toyota.request.ToyotaFileFilter;
import com.inetpsa.w7t.batch.util.BatchJobEntry;

/**
 * The Class ToyotaToWLTPCommandLineHandler.
 */
@CliCommand("toyota-to-wltp-marketing-batch")
public class ToyotaToWLTPCommandLineHandler implements CommandLineHandler {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The toyota in dir. */
    @Configuration("marketingDaemon.clients.toyota.inputDirectory")
    private File toyotaInDir;

    /** The pattern. */
    @Configuration("marketingDaemon.clients.toyota.filenamePattern")
    private String pattern;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "toyotaRequestXMLFileToDatabaseJob";

    /**
     * {@inheritDoc}
     * 
     * @see java.util.concurrent.Callable#call()
     */
    @Override
    public Integer call() throws Exception {
        logger.info("*****GO*****");

        LocalDateTime startTime = LocalDateTime.now();
        logger.info("Starting Toyota to WLTP writer job : {}", startTime);
        File outFile = getTheOldestFile(toyotaInDir, pattern);
        if (outFile != null) {
            batchJobEntry.runJob(JOB_NAME, outFile.getAbsolutePath());
        } else
            logger.info("No file availble to read");

        logger.info("File Directory {}", outFile);

        LocalDateTime endTime = LocalDateTime.now();
        logger.info("Spring Parsing End Time : {}", endTime);
        long minutes = ChronoUnit.SECONDS.between(startTime, endTime);
        logger.info("Spring Total time taken : {}", minutes);

        logger.info("*****FIN*****");
        return 0;
    }

    /**
     * Gets the the oldest file.
     *
     * @param filePath the file path
     * @param pattern the pattern
     * @return the the oldest file
     */
    public static File getTheOldestFile(File filePath, String pattern) {
        if (filePath != null && pattern != null) {
            FileFilter fileFilter = new ToyotaFileFilter(pattern);
            File[] files = filePath.listFiles(fileFilter);

            if (files != null && files.length > 0) {
                return getSortResult(files);
            }
        }
        return null;
    }

    /**
     * Gets the sort result.
     *
     * @param files the files
     * @return the sort result
     */
    private static File getSortResult(File[] files) {
        Arrays.sort(files, (File f1, File f2) -> {
            if (f2.lastModified() > f1.lastModified())
                return 1;
            if (f2.lastModified() == f1.lastModified())
                return 0;
            return -1;
        });
        return files[0];
    }

}
