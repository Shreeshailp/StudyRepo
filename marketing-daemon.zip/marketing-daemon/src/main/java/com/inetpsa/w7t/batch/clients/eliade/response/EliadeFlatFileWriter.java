/*
 * Creation : 19 Oct 2018
 */
package com.inetpsa.w7t.batch.clients.eliade.response;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeUtility;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository;

/**
 * The Class EliadeFlatFileWriter.
 */
public class EliadeFlatFileWriter implements ItemWriter<MarketingRequestAnswerDTO> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The number of movements. */
    private String NUMBER_OF_MOVEMENTS = "00000000"; // 8 char

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The MarketingDaemonCalculatorService. */
    @Inject
    private MarketingDaemonCalculatorService marketingDaemonCalculatorService;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service. */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "eliadeDatabaseToFlatFileJob";

    /** The total record count. */
    private volatile int totalRecordCount = 0;

    /** The record count. */
    private int recordCount = 0;

    /** The chunk size. */
    private int chunkSize = 500;

    /** The final list to write in file. */
    private CopyOnWriteArrayList<AoCronosEliadeDto> finalListToWriteInFile = new CopyOnWriteArrayList<>();

    // fix for big file issue
    /** The final list to update calculation status. */
    private CopyOnWriteArrayList<CalculationStatusDto> finalListToUpdateCalculationStatus = new CopyOnWriteArrayList<>();

    /** The final list to update status in MRQ. */
    private CopyOnWriteArrayList<MarketingRequest> finalListToUpdateStatusInMRQ = new CopyOnWriteArrayList<>();

    /** The records list. */
    private List<String> recordsList = new ArrayList<>();

    /** The avoid cache repository. */
    @Inject
    private AvoidCacheRepository avoidCacheRepository;

    /** The resource. */
    private EliadeFlatFileResource resource;

    /** The thread pool log. */
    private static final String THREAD_POOL_LOG = "eliadeDatabaseToFlatFileJob thread pool size : [{}]";

    private Map<String, AoCronosEliadeDto> uniqueMap = new ConcurrentHashMap<String, AoCronosEliadeDto>();

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public EliadeFlatFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(EliadeFlatFileResource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends MarketingRequestAnswerDTO> request) throws Exception {
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
        logger.debug(THREAD_POOL_LOG, threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        logger.debug("inside write()[START]");
        totalRecordCount = 0;
        recordCount = 0;
        int originalListCount = 0;
        String fsFlagFileName = null;
        boolean avoidCacheValue;
        AoCronosEliadeDto eliadeHeaderFooterDto = null;
        List<AoCronosEliadeDto> elidesList = new CopyOnWriteArrayList<>(request.get(0).getAoCronoEliadeAnswerDto());
        logger.info("The request count received from processor : {}", elidesList.size());

        if (CollectionUtils.isNotEmpty(elidesList)) {
            MarketingRequestTracker mrt = marketingRequestTrackerRepository.byFileId(elidesList.get(0).getFileId());
            avoidCacheValue = avoidCacheRepository.getAdcValueByClient(MarketingDaemonServiceConstants.ELIADE.toUpperCase());
            List<AoCronosEliadeDto> newElidesList = MarkertingDaemonUtility.getUniqueAoCronoEliadeList(elidesList);
            eliadeHeaderFooterDto = newElidesList.get(0);
            originalListCount = newElidesList.size();
            logger.info("Total request count for calculation for the FILE ID [{}] is : [{}]", newElidesList.get(0).getFileId(), originalListCount);

            try {
                logger.info("Parallel Processing Starts Here ...");
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<AoCronosEliadeDto>> splitedList = ListUtils.partition(newElidesList, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelList(list, avoidCacheValue));
                        futuresList.add(future);
                    });
                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }

            } catch (Exception e) {
                logger.error("Error when executing parallel request processing for calcualtion : {}", e);
            } finally {
                executorService.shutdown();
            }

            logger.info("Parallel Processing Ends Here ...");

            if (!finalListToWriteInFile.isEmpty()) {
                try {
                    logger.info("Calculated records count for the FILE ID [{}] is : [{}] and originoal count is : [{}]",
                            newElidesList.get(0).getFileId(), totalRecordCount, originalListCount);

                    recordsList.add(writeToHeader(eliadeHeaderFooterDto));

                    writeRecordsIntoFile(request.get(0).getAoCronoEliadeAnswerDto().get(0));

                    recordsList.add(writeToFooter(recordCount, eliadeHeaderFooterDto));

                    if (!recordsList.isEmpty() && recordsList.size() - 2 == mrt.getMrqCount()) {
                        File sourceFile = new File(getResource().getFile().getAbsolutePath());
                        Path newFile = Paths.get(sourceFile.getAbsolutePath());

                        // added below method to fix big file issue
                        updateCalculationStatusInMRQ();

                        MarkertingDaemonUtility.writeIntoFile(sourceFile, recordsList);

                        updateFinalStatusInMRQ();

                        logger.info("Records written in the file for the FILE ID [{}] is : [{}]", newElidesList.get(0).getFileId(), recordCount);
                        logger.info("Removing the .part ");
                        int lastIndex = sourceFile.getName().lastIndexOf('.');
                        String newFileName = sourceFile.getName().substring(0, lastIndex);

                        Files.move(newFile, newFile.resolveSibling(newFileName));
                        marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                                String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                                request.get(0).getAoCronoEliadeAnswerDto().get(0).getFileId());
                        // jira-734 fix
                        uniqueMap.clear();

                        List<String> fileIds = marketingRequestTrackerRepository.get3DaysAnswerSentFileIds();
                        fileIds.forEach(fileId -> MarketingDaemonServiceUtils.resetEliadeHeader(fileId));
                        fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(newElidesList.get(0).getFileId());
                        logger.info("FsFlagFileName: [{}]", fsFlagFileName);
                        if (fileConfigUtilService != null && fsFlagFileName != null) {
                            // Added below code as part of jira-660 fix -- start
                            MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "eliade", fsFlagFileName);
                            int result = fsFlagFileService.deleteFsFlagFileByFileId(newElidesList.get(0).getFileId());
                            if (result > 0) {
                                logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                            }
                            // jira-660 fix -- end
                        }
                    }
                } catch (Exception e) {
                    logger.error("{} ", e);
                }

            } else {
                logger.info("Final List To Write In File is empty for FILE ID [{}]", eliadeHeaderFooterDto.getFileId());
            }
        }
        logger.debug("inside write()[END]");
    }

    /**
     * Update calculation status in MRQ.
     */
    private void updateCalculationStatusInMRQ() {
        if (!finalListToUpdateCalculationStatus.isEmpty()) {
            Set<CalculationStatusDto> set = new HashSet<>(finalListToUpdateCalculationStatus);
            finalListToUpdateCalculationStatus.clear();
            finalListToUpdateCalculationStatus.addAll(set);
            int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
            logger.debug(THREAD_POOL_LOG, threadPoolSize);
            ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
            try {
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<CalculationStatusDto>> splitedList = ListUtils.partition(finalListToUpdateCalculationStatus, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateCalculationStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            } finally {
                executorService.shutdown();
            }

        }

    }

    /**
     * Process parallel list to update calculation status.
     *
     * @param marketingRequestList the marketing request list
     * @return the int
     */
    private int processParallelListToUpdateCalculationStatus(List<CalculationStatusDto> marketingRequestList) {
        marketingDaemonCalculatorService.updateStatusCalculationStatusInMRQ(marketingRequestList);
        return 1;
    }

    /**
     * Update final status in MRQ.
     */
    private void updateFinalStatusInMRQ() {

        if (!finalListToUpdateStatusInMRQ.isEmpty()) {
            int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
            logger.debug(THREAD_POOL_LOG, threadPoolSize);
            ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
            try {
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<MarketingRequest>> splitedList = ListUtils.partition(finalListToUpdateStatusInMRQ, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            } finally {
                executorService.shutdown();
            }

        }

    }

    /**
     * Process parallel list to update status.
     *
     * @param marketingRequestList the marketing request list
     * @return the int
     */
    private int processParallelListToUpdateStatus(List<MarketingRequest> marketingRequestList) {
        marketingDaemonCalculatorService.updateAnswerSentStatus(marketingRequestList);
        return 1;
    }

    /**
     * Process parallel list.
     *
     * @param list the list
     * @param avoidCacheValue the avoid cache value
     * @return the int
     */
    private int processParallelList(List<AoCronosEliadeDto> list, boolean avoidCacheValue) {
        AoCronosEliadeDto dto = null;
        for (AoCronosEliadeDto aoCronosEliadeDto : list) {
            aoCronosEliadeDto.setAvoidCache(avoidCacheValue);
            dto = process(aoCronosEliadeDto);
            if (dto != null) {
                AoCronosEliadeDto eliadeDto = dto;
                if (eliadeDto != null && (eliadeDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()))
                        || eliadeDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode())))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(eliadeDto.getFileId());
                    calculationStatusDto.setRequestId(eliadeDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(eliadeDto.getStatus());
                    calculationStatusDto.setAnswerDate(eliadeDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(eliadeDto.getAnswerCode());
                    calculationStatusDto.setAnswerDesignation(eliadeDto.getAnswerDesignation());
                    eliadeDto.setStatus(calculationStatusDto.getCurrentStatus());
                    eliadeDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    eliadeDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    eliadeDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);
                } else if (eliadeDto != null
                        && eliadeDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(eliadeDto.getFileId());
                    calculationStatusDto.setRequestId(eliadeDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));
                    calculationStatusDto.setAnswerDate(eliadeDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_AOGEOS_CRONOS_ELIADE);
                    calculationStatusDto.setAnswerDesignation(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
                    calculationStatusDto.setAnswerDate(MarketingDateUtil.getTodaysDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);

                    eliadeDto.setStatus(calculationStatusDto.getCurrentStatus());
                    eliadeDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    eliadeDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    eliadeDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                }

                finalListToWriteInFile.add(eliadeDto);
                totalRecordCount++;
            }
        }
        // wltp hub changes -> removed calculation status update part to resolve big file issue

        return 1;
    }

    /**
     * Process.
     *
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the ao cronos eliade dto
     */
    private AoCronosEliadeDto process(AoCronosEliadeDto aoCronosEliadeDto) {
        AoCronosEliadeDto dto = null;
        // jira-734 fix
        if (!uniqueMap.containsKey(aoCronosEliadeDto.getRequestId())) {
            uniqueMap.put(aoCronosEliadeDto.getRequestId(), aoCronosEliadeDto);

            try {
                dto = marketingDaemonCalculatorService.calculateAoGeosCronosEliade(uniqueMap.get(aoCronosEliadeDto.getRequestId()));
            } catch (Exception e) {
                logger.error("{}", e);
            }
        }
        return dto;
    }

    /**
     * Write to header.
     *
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToHeader(AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        return AoCronoEliadeUtility.generateHeader(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), aoCronosEliadeDto.getLotDate());
    }

    /**
     * Write to footer.
     *
     * @param count the count
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToFooter(int count, AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        String result = generateMovementCount(NUMBER_OF_MOVEMENTS, count);
        return AoCronoEliadeUtility.generateFooter(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), result);
    }

    /**
     * Generate movement count.
     *
     * @param NUMBER_OF_MOVEMENTS the number of movements
     * @param count the count
     * @return the string
     */
    private String generateMovementCount(String NUMBER_OF_MOVEMENTS, int count) {
        if (NUMBER_OF_MOVEMENTS.length() >= Integer.toString(count).length()) {

            String movementCount = NUMBER_OF_MOVEMENTS.substring(0, NUMBER_OF_MOVEMENTS.length() - (Integer.toString(count).length()));

            return movementCount + count;
        }
        return NUMBER_OF_MOVEMENTS;
    }

    /**
     * Write records into file.
     *
     * @param eliDto the eli dto
     */
    private void writeRecordsIntoFile(AoCronosEliadeDto eliDto) {
        List<AoCronosEliadeDto> rejectedRequestList = MarkertingDaemonUtility.getRejectedRequestList(marketingRequestRepository,
                MarketingDaemonServiceConstants.ELIADE.toUpperCase(), String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()),
                false, eliDto.getFileId());
        if (rejectedRequestList != null && !rejectedRequestList.isEmpty()) {
            finalListToWriteInFile.addAll(rejectedRequestList);
        }

        List<AoCronosEliadeDto> sortedList = finalListToWriteInFile.stream().sorted(Comparator.comparing(AoCronosEliadeDto::getRequestId))
                .collect(Collectors.toList());
        sortedList.stream().forEach(elidesDto -> {

            try {

                if (!elidesDto.getAnswerCode().isEmpty()
                        && (elidesDto.getAnswerCode().contains("ERR") || !elidesDto.getAnswerCode().startsWith("OK"))) {
                    elidesDto.setVehicleType("");
                    elidesDto.setValidityDate("");
                }
                recordsList.add(elidesDto.toString());
                recordCount++;
                MarketingRequest marketingRequest = new MarketingRequest();
                marketingRequest.setRequestID(elidesDto.getRequestId());
                marketingRequest.setInternalReqId(elidesDto.getInternalRequestId());
                marketingRequest.setFileId(elidesDto.getFileId());
                finalListToUpdateStatusInMRQ.add(marketingRequest);
                marketingRequest = null;
            } catch (Exception e) {
                logger.error("{}", e);
            }

        });
    }

}