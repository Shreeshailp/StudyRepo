/*
 * Creation : 1 Nov 2021
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

/**
 * The Class ToyotaVehicleTestResultDto.
 *
 * @author E562493
 */
public class ToyotaVehicleTestResultDto {

    /** The vehicle code. */
    private String vehicleCode;

    /** The phase code. */
    private String phaseCode;

    /** The result code. */
    private String resultCode;

    /** The result value. */
    private String resultValue;

    /**
     * Getter vehicleCode.
     *
     * @return the vehicleCode
     */
    public String getVehicleCode() {
        return vehicleCode;
    }

    /**
     * Setter vehicleCode.
     *
     * @param vehicleCode the vehicleCode to set
     */
    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    /**
     * Getter phaseCode.
     *
     * @return the phaseCode
     */
    public String getPhaseCode() {
        return phaseCode;
    }

    /**
     * Setter phaseCode.
     *
     * @param phaseCode the phaseCode to set
     */
    public void setPhaseCode(String phaseCode) {
        this.phaseCode = phaseCode;
    }

    /**
     * Getter resultCode.
     *
     * @return the resultCode
     */
    public String getResultCode() {
        return resultCode;
    }

    /**
     * Setter resultCode.
     *
     * @param resultCode the resultCode to set
     */
    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    /**
     * Getter resultValue.
     *
     * @return the resultValue
     */
    public String getResultValue() {
        return resultValue;
    }

    /**
     * Setter resultValue.
     *
     * @param resultValue the resultValue to set
     */
    public void setResultValue(String resultValue) {
        this.resultValue = resultValue;
    }

}
