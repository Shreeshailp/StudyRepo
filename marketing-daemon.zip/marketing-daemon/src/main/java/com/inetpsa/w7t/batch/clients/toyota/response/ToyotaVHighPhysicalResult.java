/*
 * Creation : 22 Oct 2021
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVHighPhysicalResult" })
@XmlRootElement(name = "VHIGH")
public class ToyotaVHighPhysicalResult {
    @XmlElement(name = "phys_result", required = true)
    protected List<ToyotaPhysicalResult> toyotaVHighPhysicalResult;

    public ToyotaVHighPhysicalResult() {
        super();
    }

    public ToyotaVHighPhysicalResult(List<ToyotaPhysicalResult> toyotaVHighPhysicalResult) {
        super();
        this.toyotaVHighPhysicalResult = toyotaVHighPhysicalResult;
    }

    public List<ToyotaPhysicalResult> getToyotaVHighPhysicalResult() {
        return toyotaVHighPhysicalResult;
    }

    public void setToyotaVHighPhysicalResult(List<ToyotaPhysicalResult> toyotaVHighPhysicalResult) {
        this.toyotaVHighPhysicalResult = toyotaVHighPhysicalResult;
    }

}
