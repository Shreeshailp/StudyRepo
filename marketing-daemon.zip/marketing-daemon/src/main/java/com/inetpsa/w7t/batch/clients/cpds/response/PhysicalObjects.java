/*
 * Creation : 27 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

/**
 * The Class PhysicalObjects.
 */
public class PhysicalObjects {

    /** The property name. */
    private String propertyName;

    /** The value. */
    private String value;

    /**
     * Instantiates a new physical objects.
     */
    public PhysicalObjects() {
        super();
    }

    /**
     * Gets the property name.
     *
     * @return the property name
     */
    public String getPropertyName() {
        return propertyName;
    }

    /**
     * Sets the property name.
     *
     * @param propertyName the new property name
     */
    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "PhysicalObjects [propertyName=" + propertyName + ", value=" + value + "]";
    }

}
