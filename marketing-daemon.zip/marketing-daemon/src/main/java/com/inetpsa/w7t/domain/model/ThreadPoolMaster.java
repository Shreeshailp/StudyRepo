/*
 * Creation : 2 Aug 2019
 */
package com.inetpsa.w7t.domain.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;

/**
 * The Class ThreadPoolMaster.
 */
@Entity
@Table(name = "W7TQTTPM")
public class ThreadPoolMaster extends BaseAggregateRoot<String> {

    /** The id. */
    @Id
    @Column(name = "ID")
    private String id;

    /** The job name. */
    @Column(name = "JOB_NAME")
    private String jobName;

    /** The thread pool size. */
    @Column(name = "THREAD_POOL_SIZE")
    private String threadPoolSize = "";

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the job name.
     *
     * @return the job name
     */
    public String getJobName() {
        return jobName;
    }

    /**
     * Sets the job name.
     *
     * @param jobName the new job name
     */
    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    /**
     * Gets the thread pool size.
     *
     * @return the thread pool size
     */
    public String getThreadPoolSize() {
        return threadPoolSize;
    }

    /**
     * Sets the thread pool size.
     *
     * @param threadPoolSize the new thread pool size
     */
    public void setThreadPoolSize(String threadPoolSize) {
        this.threadPoolSize = threadPoolSize;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.seedstack.business.domain.BaseEntity#getEntityId()
     */
    @Override
    public String getEntityId() {
        // TODO Auto-generated method stub
        return this.id;
    }

}
