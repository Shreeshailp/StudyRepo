/*
 * Creation : 12 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.inetpsa.w7t.domain.model.dto.MarketingRequestTrackerDTO;

/**
 * @author E534811
 */
public class MarketingRequestTrackerRowMapper implements RowMapper<MarketingRequestTrackerDTO> {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public MarketingRequestTrackerDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        MarketingRequestTrackerDTO request = new MarketingRequestTrackerDTO();
        request.setClient(rs.getString("CLIENT"));
        request.setFileId(rs.getString("FILE_ID"));
        request.setMrqCount(Long.parseLong(rs.getString("MRQ_COUNT")));
        request.setValidReqCount(Long.parseLong(rs.getString("VALID_REQ_COUNT")));
        request.setAnswerGenerated(rs.getString("ANSWER_GENERATED"));
        return request;
    }

}
