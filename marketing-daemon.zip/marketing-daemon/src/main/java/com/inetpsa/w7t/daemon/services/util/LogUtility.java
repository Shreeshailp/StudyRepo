/*
 * Creation : 17 Jun 2019
 */
package com.inetpsa.w7t.daemon.services.util;

import org.slf4j.Logger;

/**
 * The Class LogUtility.
 */
public final class LogUtility {

    /**
     * Log the error.
     *
     * @param logger the logger
     * @param requestId the request id
     * @param errorCode the error code
     * @param errorDesignation the error designation
     */
    public static void logTheError(Logger logger, String requestId, String errorCode, String errorDesignation) {
        logger.error("Request ID[{}]: [{}] : [{}]", requestId, errorCode, errorDesignation);
    }

    /**
     * Instantiates a new log utility.
     */
    private LogUtility() {

    }

    /**
     * Log the error.
     *
     * @param logger the logger
     * @param ruleCode the rule code
     * @param description the description
     */
    public static void logTheError(Logger logger, String ruleCode, String description) {
        logger.error("[{}] : [{}]", ruleCode, description);
    }

}
