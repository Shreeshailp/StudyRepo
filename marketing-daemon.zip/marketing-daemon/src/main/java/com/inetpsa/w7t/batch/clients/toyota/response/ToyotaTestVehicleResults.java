/*
 * Creation : 9 Nov 2021
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * The Class ToyotaTestVehicleResults.
 *
 * @author E562493
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "toyotaVLowTestResult", "toyotaVMedTestResult", "toyotaVHighTestResult" })
@XmlRootElement(name = "TEST_VEHICLE_RESULTS")
public class ToyotaTestVehicleResults {
    /** The toyota V low test result. */
    @XmlElement(name = "VLOW", required = true)
    protected ToyotaVLowTestResult toyotaVLowTestResult;

    /** The toyota V med test result. */
    @XmlElement(name = "VMED", required = true)
    protected ToyotaVMedTestResult toyotaVMedTestResult;

    /** The toyota V high test result. */
    @XmlElement(name = "VHIGH", required = true)
    protected ToyotaVHighTestResult toyotaVHighTestResult;

    /**
     * Getter toyotaVLowTestResult
     * 
     * @return the toyotaVLowTestResult
     */
    public ToyotaVLowTestResult getToyotaVLowTestResult() {
        return toyotaVLowTestResult;
    }

    /**
     * Setter toyotaVLowTestResult
     * 
     * @param toyotaVLowTestResult the toyotaVLowTestResult to set
     */
    public void setToyotaVLowTestResult(ToyotaVLowTestResult toyotaVLowTestResult) {
        this.toyotaVLowTestResult = toyotaVLowTestResult;
    }

    /**
     * Getter toyotaVMedTestResult
     * 
     * @return the toyotaVMedTestResult
     */
    public ToyotaVMedTestResult getToyotaVMedTestResult() {
        return toyotaVMedTestResult;
    }

    /**
     * Setter toyotaVMedTestResult
     * 
     * @param toyotaVMedTestResult the toyotaVMedTestResult to set
     */
    public void setToyotaVMedTestResult(ToyotaVMedTestResult toyotaVMedTestResult) {
        this.toyotaVMedTestResult = toyotaVMedTestResult;
    }

    /**
     * Getter toyotaVHighTestResult
     * 
     * @return the toyotaVHighTestResult
     */
    public ToyotaVHighTestResult getToyotaVHighTestResult() {
        return toyotaVHighTestResult;
    }

    /**
     * Setter toyotaVHighTestResult
     * 
     * @param toyotaVHighTestResult the toyotaVHighTestResult to set
     */
    public void setToyotaVHighTestResult(ToyotaVHighTestResult toyotaVHighTestResult) {
        this.toyotaVHighTestResult = toyotaVHighTestResult;
    }

    /**
     * Instantiates a new toyota test vehicle results.
     */
    public ToyotaTestVehicleResults() {
        super();
    }

}
