/*
 * Creation : 3 Jan 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

/**
 * The Class AoCronoEliadeCalculationConstants.
 *
 * @author E534811
 */
public final class AoCronoEliadeCalculationConstants {

    /** The Constant FCCD. */
    public static final String FCCD = "FCCD";

    /** The Constant CO2B. */
    public static final String CO2B = "CO2B";

    /** The Constant FCG. */
    public static final String FCG = "FCG";

    /** The Constant CO2G. */
    public static final String CO2G = "CO2G";

    /** The Constant FCB. */
    public static final String FCB = "FCB";

    /** The Constant CRCD. */
    public static final String CRCD = "CRCD";

    /** The Constant CE. */
    public static final String CE = "CE";

    /** The Constant WCCO2. */
    public static final String WCCO2 = "WCCO2";

    /** The Constant FC. */
    public static final String FC = "FC";

    /** The Constant WCFC. */
    public static final String WCFC = "WCFC";

    /** The Constant AERCD. */
    public static final String AERCD = "AERCD";

    /** The Constant UFECC. */
    public static final String UFECC = "UFECC";

    /** The Constant FCCS. */
    public static final String FCCS = "FCCS";

    /** The Constant AER. */
    public static final String AER = "AER";

    /** The Constant PER. */
    public static final String PER = "PER";

    /** The Constant UFEC. */
    public static final String UFEC = "UFEC";

    /** The Constant CO2CD. */
    public static final String CO2CD = "CO2CD";

    /** The Constant EAER. */
    public static final String EAER = "EAER";

    /** The Constant CO2CS. */
    public static final String CO2CS = "CO2CS";

    /** The Constant CO2. */
    public static final String CO2 = "CO2";

    /** The Constant ECCD. */
    public static final String ECCD = "ECCD";

    /** The Constant EC. */
    public static final String EC = "EC";

    /** The Constant HYRE_VEHICLE_TYPE. */
    public static final String HYRE_VEHICLE_TYPE = "HYRE";

    /** The Constant ELEC_VEHICLE_TYPE. */
    public static final String ELEC_VEHICLE_TYPE = "ELEC";

    /**
     * Instantiates a new ao crono eliade calculation constants.
     */
    private AoCronoEliadeCalculationConstants() {

    }
}
