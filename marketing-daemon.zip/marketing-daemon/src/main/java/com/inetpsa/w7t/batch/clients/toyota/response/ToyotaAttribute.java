/*
 * Creation : 4 Oct 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class ToyotaAttribute.
 *
 * @author E534811
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "attribute")
public class ToyotaAttribute {

    /** The code. */
    @XmlAttribute(name = "code", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    private String code;

    /** The value. */
    @XmlAttribute(name = "value", required = true)
    private String value;

    /**
     * Getter code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter code.
     *
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Getter value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Setter value.
     *
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotoAttribute [code=" + code + ", value=" + value + "]";
    }

    /**
     * Instantiates a new toyota attribute.
     *
     * @param code the code
     * @param value the value
     */
    public ToyotaAttribute(String code, String value) {
        super();
        this.code = code;
        this.value = value;
    }

    /**
     * Instantiates a new toyota attribute.
     */
    public ToyotaAttribute() {
    }

}
