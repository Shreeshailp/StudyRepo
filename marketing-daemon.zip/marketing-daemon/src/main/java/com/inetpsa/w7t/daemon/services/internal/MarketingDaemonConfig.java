/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services.internal;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.seedstack.coffig.Config;

/**
 * The Class MarketingDaemonConfig.
 */
@Config("marketingDaemon")
public class MarketingDaemonConfig {

    /** The file listener refresh interval for config mot 2. */
    // JIRA-455 Fix Starts Here
    private int fileListenerRefreshIntervalForConfigMot2;

    /** The file listener refresh interval for toyota. */
    private int fileListenerRefreshIntervalForToyota;

    /** The file listener refresh interval for ao geos. */
    private int fileListenerRefreshIntervalForAoGeos;

    /** The file listener refresh interval for cronos. */
    private int fileListenerRefreshIntervalForCronos;

    /** The file listener refresh interval for eliade. */
    private int fileListenerRefreshIntervalForEliade;

    /** The file listener refresh interval for icube. */
    private int fileListenerRefreshIntervalForIcube;

    /** The file listener refresh interval for cpds. */
    private int fileListenerRefreshIntervalForCpds;

    /** The provider file listener refresh interval for config mot 2. */
    private int providerFileListenerRefreshIntervalForConfigMot2;

    /** The provider file listener refresh interval for toyota. */
    private int providerFileListenerRefreshIntervalForToyota;

    /** The provider file listener refresh interval for ao geos. */
    private int providerFileListenerRefreshIntervalForAoGeos;

    /** The provider file listener refresh interval for cronos. */
    private int providerFileListenerRefreshIntervalForCronos;

    /** The provider file listener refresh interval for eliade. */
    private int providerFileListenerRefreshIntervalForEliade;

    /** The provider file listener refresh interval for icube. */
    private int providerFileListenerRefreshIntervalForIcube;

    /** The provider file listener refresh interval for cpds. */
    private int providerFileListenerRefreshIntervalForCpds;

    // JIRA-455 Fix Ends Here

    /** The lifecycle step count. */
    private int lifecycleStepCount;

    /** The temp directory. */
    private File tempDirectory;

    /** The req mac name. */
    private String reqMacName;

    /** The req machine. */
    private static String reqMachine = "";

    /** The res mac name. */
    private String resMacName;

    /** The res machine. */
    private static String resMachine = "";

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The indus fs flag path. */
    private String indusFsFlagPath;

    /** The clients. */
    private Map<String, MarketingDaemonClientConfig> clients = new HashMap<>();

    /** The providers. */
    private Map<String, MarketingDaemonProviderConfig> providers = new HashMap<>();

    /**
     * Getter fileListenerRefreshIntervalForCpds
     * 
     * @return the fileListenerRefreshIntervalForCpds
     */
    public int getFileListenerRefreshIntervalForCpds() {
        return fileListenerRefreshIntervalForCpds;
    }

    /**
     * Setter fileListenerRefreshIntervalForCpds
     * 
     * @param fileListenerRefreshIntervalForCpds the fileListenerRefreshIntervalForCpds to set
     */
    public void setFileListenerRefreshIntervalForCpds(int fileListenerRefreshIntervalForCpds) {
        this.fileListenerRefreshIntervalForCpds = fileListenerRefreshIntervalForCpds;
    }

    /**
     * Getter providerFileListenerRefreshIntervalForCpds
     * 
     * @return the providerFileListenerRefreshIntervalForCpds
     */
    public int getProviderFileListenerRefreshIntervalForCpds() {
        return providerFileListenerRefreshIntervalForCpds;
    }

    /**
     * Setter providerFileListenerRefreshIntervalForCpds
     * 
     * @param providerFileListenerRefreshIntervalForCpds the providerFileListenerRefreshIntervalForCpds to set
     */
    public void setProviderFileListenerRefreshIntervalForCpds(int providerFileListenerRefreshIntervalForCpds) {
        this.providerFileListenerRefreshIntervalForCpds = providerFileListenerRefreshIntervalForCpds;
    }

    /**
     * Gets the file listener refresh interval for icube.
     *
     * @return the file listener refresh interval for icube
     */
    public int getFileListenerRefreshIntervalForIcube() {
        return fileListenerRefreshIntervalForIcube;
    }

    /**
     * Sets the file listener refresh interval for icube.
     *
     * @param fileListenerRefreshIntervalForIcube the new file listener refresh interval for icube
     */
    public void setFileListenerRefreshIntervalForIcube(int fileListenerRefreshIntervalForIcube) {
        this.fileListenerRefreshIntervalForIcube = fileListenerRefreshIntervalForIcube;
    }

    /**
     * Gets the provider file listener refresh interval for icube.
     *
     * @return the provider file listener refresh interval for icube
     */
    public int getProviderFileListenerRefreshIntervalForIcube() {
        return providerFileListenerRefreshIntervalForIcube;
    }

    /**
     * Sets the provider file listener refresh interval for icube.
     *
     * @param providerFileListenerRefreshIntervalForIcube the new provider file listener refresh interval for icube
     */
    public void setProviderFileListenerRefreshIntervalForIcube(int providerFileListenerRefreshIntervalForIcube) {
        this.providerFileListenerRefreshIntervalForIcube = providerFileListenerRefreshIntervalForIcube;
    }

    /**
     * Gets the indus fs flag path.
     *
     * @return the indus fs flag path
     */
    public String getIndusFsFlagPath() {
        return indusFsFlagPath;
    }

    /**
     * Sets the indus fs flag path.
     *
     * @param indusFsFlagPath the new indus fs flag path
     */
    public void setIndusFsFlagPath(String indusFsFlagPath) {
        this.indusFsFlagPath = indusFsFlagPath;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the file listener refresh interval for config mot 2.
     *
     * @return the file listener refresh interval for config mot 2
     */
    // JIRA-455 Fix Starts Here
    public int getFileListenerRefreshIntervalForConfigMot2() {
        return fileListenerRefreshIntervalForConfigMot2;
    }

    /**
     * Sets the file listener refresh interval for config mot 2.
     *
     * @param fileListenerRefreshIntervalForConfigMot2 the new file listener refresh interval for config mot 2
     */
    public void setFileListenerRefreshIntervalForConfigMot2(int fileListenerRefreshIntervalForConfigMot2) {
        this.fileListenerRefreshIntervalForConfigMot2 = fileListenerRefreshIntervalForConfigMot2;
    }

    /**
     * Gets the file listener refresh interval for toyota.
     *
     * @return the file listener refresh interval for toyota
     */
    public int getFileListenerRefreshIntervalForToyota() {
        return fileListenerRefreshIntervalForToyota;
    }

    /**
     * Sets the file listener refresh interval for toyota.
     *
     * @param fileListenerRefreshIntervalForToyota the new file listener refresh interval for toyota
     */
    public void setFileListenerRefreshIntervalForToyota(int fileListenerRefreshIntervalForToyota) {
        this.fileListenerRefreshIntervalForToyota = fileListenerRefreshIntervalForToyota;
    }

    /**
     * Gets the file listener refresh interval for ao geos.
     *
     * @return the file listener refresh interval for ao geos
     */
    public int getFileListenerRefreshIntervalForAoGeos() {
        return fileListenerRefreshIntervalForAoGeos;
    }

    /**
     * Sets the file listener refresh interval for ao geos.
     *
     * @param fileListenerRefreshIntervalForAoGeos the new file listener refresh interval for ao geos
     */
    public void setFileListenerRefreshIntervalForAoGeos(int fileListenerRefreshIntervalForAoGeos) {
        this.fileListenerRefreshIntervalForAoGeos = fileListenerRefreshIntervalForAoGeos;
    }

    /**
     * Gets the file listener refresh interval for cronos.
     *
     * @return the file listener refresh interval for cronos
     */
    public int getFileListenerRefreshIntervalForCronos() {
        return fileListenerRefreshIntervalForCronos;
    }

    /**
     * Sets the file listener refresh interval for cronos.
     *
     * @param fileListenerRefreshIntervalForCronos the new file listener refresh interval for cronos
     */
    public void setFileListenerRefreshIntervalForCronos(int fileListenerRefreshIntervalForCronos) {
        this.fileListenerRefreshIntervalForCronos = fileListenerRefreshIntervalForCronos;
    }

    /**
     * Gets the file listener refresh interval for eliade.
     *
     * @return the file listener refresh interval for eliade
     */
    public int getFileListenerRefreshIntervalForEliade() {
        return fileListenerRefreshIntervalForEliade;
    }

    /**
     * Sets the file listener refresh interval for eliade.
     *
     * @param fileListenerRefreshIntervalForEliade the new file listener refresh interval for eliade
     */
    public void setFileListenerRefreshIntervalForEliade(int fileListenerRefreshIntervalForEliade) {
        this.fileListenerRefreshIntervalForEliade = fileListenerRefreshIntervalForEliade;
    }

    // JIRA-455 Fix Ends Here

    /**
     * Gets the provider file listener refresh interval for config mot 2.
     *
     * @return the provider file listener refresh interval for config mot 2
     */
    public int getProviderFileListenerRefreshIntervalForConfigMot2() {
        return providerFileListenerRefreshIntervalForConfigMot2;
    }

    /**
     * Sets the provider file listener refresh interval for config mot 2.
     *
     * @param providerFileListenerRefreshIntervalForConfigMot2 the new provider file listener refresh interval for config mot 2
     */
    public void setProviderFileListenerRefreshIntervalForConfigMot2(int providerFileListenerRefreshIntervalForConfigMot2) {
        this.providerFileListenerRefreshIntervalForConfigMot2 = providerFileListenerRefreshIntervalForConfigMot2;
    }

    /**
     * Gets the provider file listener refresh interval for toyota.
     *
     * @return the provider file listener refresh interval for toyota
     */
    public int getProviderFileListenerRefreshIntervalForToyota() {
        return providerFileListenerRefreshIntervalForToyota;
    }

    /**
     * Sets the provider file listener refresh interval for toyota.
     *
     * @param providerFileListenerRefreshIntervalForToyota the new provider file listener refresh interval for toyota
     */
    public void setProviderFileListenerRefreshIntervalForToyota(int providerFileListenerRefreshIntervalForToyota) {
        this.providerFileListenerRefreshIntervalForToyota = providerFileListenerRefreshIntervalForToyota;
    }

    /**
     * Gets the provider file listener refresh interval for ao geos.
     *
     * @return the provider file listener refresh interval for ao geos
     */
    public int getProviderFileListenerRefreshIntervalForAoGeos() {
        return providerFileListenerRefreshIntervalForAoGeos;
    }

    /**
     * Sets the provider file listener refresh interval for ao geos.
     *
     * @param providerFileListenerRefreshIntervalForAoGeos the new provider file listener refresh interval for ao geos
     */
    public void setProviderFileListenerRefreshIntervalForAoGeos(int providerFileListenerRefreshIntervalForAoGeos) {
        this.providerFileListenerRefreshIntervalForAoGeos = providerFileListenerRefreshIntervalForAoGeos;
    }

    /**
     * Gets the provider file listener refresh interval for cronos.
     *
     * @return the provider file listener refresh interval for cronos
     */
    public int getProviderFileListenerRefreshIntervalForCronos() {
        return providerFileListenerRefreshIntervalForCronos;
    }

    /**
     * Sets the provider file listener refresh interval for cronos.
     *
     * @param providerFileListenerRefreshIntervalForCronos the new provider file listener refresh interval for cronos
     */
    public void setProviderFileListenerRefreshIntervalForCronos(int providerFileListenerRefreshIntervalForCronos) {
        this.providerFileListenerRefreshIntervalForCronos = providerFileListenerRefreshIntervalForCronos;
    }

    /**
     * Gets the provider file listener refresh interval for eliade.
     *
     * @return the provider file listener refresh interval for eliade
     */
    public int getProviderFileListenerRefreshIntervalForEliade() {
        return providerFileListenerRefreshIntervalForEliade;
    }

    /**
     * Sets the provider file listener refresh interval for eliade.
     *
     * @param providerFileListenerRefreshIntervalForEliade the new provider file listener refresh interval for eliade
     */
    public void setProviderFileListenerRefreshIntervalForEliade(int providerFileListenerRefreshIntervalForEliade) {
        this.providerFileListenerRefreshIntervalForEliade = providerFileListenerRefreshIntervalForEliade;
    }

    /**
     * Sets the req machine.
     *
     * @param reqMacName the new req machine
     */
    public static void setReqMachine(String reqMacName) {
        reqMachine = reqMacName;
    }

    /**
     * Sets the req mac name.
     *
     * @param reqMacName the new req mac name
     */
    public void setReqMacName(String reqMacName) {
        MarketingDaemonConfig.setReqMachine(reqMacName);
    }

    /**
     * Gets the req machine.
     *
     * @return the req machine
     */
    public static String getReqMachine() {
        return reqMachine;
    }

    /**
     * Gets the req mac name.
     *
     * @return the req mac name
     */
    public String getReqMacName() {
        return reqMacName;
    }

    /**
     * Getter resMacName
     * 
     * @return the resMacName
     */
    public String getResMacName() {
        return resMacName;
    }

    /**
     * Setter resMacName
     * 
     * @param resMacName the resMacName to set
     */
    public void setResMacName(String resMacName) {
        MarketingDaemonConfig.setResMachine(resMacName);
    }

    /**
     * Getter resMachine
     * 
     * @return the resMachine
     */
    public static String getResMachine() {
        return resMachine;
    }

    /**
     * Setter resMachine
     * 
     * @param resMachine the resMachine to set
     */
    public static void setResMachine(String resMacName) {
        resMachine = resMacName;
    }

    /**
     * Gets the lifecycle step count.
     *
     * @return the lifecycle step count
     */
    public int getLifecycleStepCount() {
        return lifecycleStepCount;
    }

    /**
     * Sets the lifecycle step count.
     *
     * @param lifecycleStepCount the new lifecycle step count
     */
    public void setLifecycleStepCount(int lifecycleStepCount) {
        this.lifecycleStepCount = lifecycleStepCount;
    }

    /**
     * Gets the temp directory.
     *
     * @return the temp directory
     */
    public File getTempDirectory() {
        return tempDirectory;
    }

    /**
     * Sets the temp directory.
     *
     * @param tempDirectory the new temp directory
     */
    public void setTempDirectory(File tempDirectory) {
        this.tempDirectory = tempDirectory;
    }

    /**
     * Gets the clients.
     *
     * @return the clients
     */
    public Map<String, MarketingDaemonClientConfig> getClients() {
        return clients;
    }

    /**
     * Sets the clients.
     *
     * @param clients the clients
     */
    public void setClients(Map<String, MarketingDaemonClientConfig> clients) {
        this.clients = clients;
    }

    /**
     * Gets the providers.
     *
     * @return the providers
     */
    public Map<String, MarketingDaemonProviderConfig> getProviders() {
        return providers;
    }

    /**
     * Sets the providers.
     *
     * @param providers the providers
     */
    public void setProviders(Map<String, MarketingDaemonProviderConfig> providers) {
        this.providers = providers;
    }

    /**
     * The Class MarketingDaemonClientConfig.
     */
    public static class MarketingDaemonClientConfig {

        /** The input directory. */
        private File inputDirectory;

        /** The output directory. */
        private File outputDirectory;

        /** The input filename. */
        private String inputFilename;

        /** The timeout. */
        private int timeout;

        /** The output filename. */
        private String outputFilename;

        /** The process chunk size. */
        private Long processChunkSize;

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "MarketingDaemonClientConfig [inputDirectory=" + inputDirectory + ", outputDirectory=" + outputDirectory + ", inputFilename="
                    + inputFilename + ", timeout=" + timeout + ", outputFilename=" + outputFilename + ", processChunkSize=" + processChunkSize + "]";
        }

        /**
         * Gets the process chunk size.
         *
         * @return the process chunk size
         */
        public Long getProcessChunkSize() {
            return processChunkSize;
        }

        /**
         * Sets the process chunk size.
         *
         * @param processChunkSize the new process chunk size
         */
        public void setProcessChunkSize(Long processChunkSize) {
            this.processChunkSize = processChunkSize;
        }

        /**
         * Gets the input directory.
         *
         * @return the input directory
         */
        public File getInputDirectory() {
            return inputDirectory;
        }

        /**
         * Sets the input directory.
         *
         * @param inputDirectory the new input directory
         */
        public void setInputDirectory(File inputDirectory) {
            this.inputDirectory = inputDirectory;
        }

        /**
         * Gets the output directory.
         *
         * @return the output directory
         */
        public File getOutputDirectory() {
            return outputDirectory;
        }

        /**
         * Sets the output directory.
         *
         * @param outputDirectory the new output directory
         */
        public void setOutputDirectory(File outputDirectory) {
            this.outputDirectory = outputDirectory;
        }

        /**
         * Gets the input filename.
         *
         * @return the input filename
         */
        public String getInputFilename() {
            return inputFilename;
        }

        /**
         * Sets the input filename.
         *
         * @param inputFilename the new input filename
         */
        public void setInputFilename(String inputFilename) {
            this.inputFilename = inputFilename;
        }

        /**
         * Gets the timeout.
         *
         * @return the timeout
         */
        public int getTimeout() {
            return timeout;
        }

        /**
         * Sets the timeout.
         *
         * @param timeout the new timeout
         */
        public void setTimeout(int timeout) {
            this.timeout = timeout;
        }

        /**
         * Gets the output filename.
         *
         * @return the output filename
         */
        public String getOutputFilename() {
            return outputFilename;
        }

        /**
         * Sets the output filename.
         *
         * @param outputFilename the new output filename
         */
        public void setOutputFilename(String outputFilename) {
            this.outputFilename = outputFilename;
        }
    }

    /**
     * The Class MarketingDaemonProviderConfig.
     */
    public static class MarketingDaemonProviderConfig {

        /** The output directory. */
        private File outputDirectory;

        /** The input directory. */
        private File inputDirectory;

        /** The process interval. */
        private int processInterval;

        /** The input filename. */
        private String inputFilename;

        /** The output filename. */
        private String outputFilename;

        /** The bcv newton for client. */
        private String bcvNewtonForClient;

        /** The process chunk size. */
        private Long processChunkSize;

        /**
         * Gets the output directory.
         *
         * @return the output directory
         */
        public File getOutputDirectory() {
            return outputDirectory;
        }

        /**
         * Sets the output directory.
         *
         * @param outputDirectory the new output directory
         */
        public void setOutputDirectory(File outputDirectory) {
            this.outputDirectory = outputDirectory;
        }

        /**
         * Gets the input directory.
         *
         * @return the input directory
         */
        public File getInputDirectory() {
            return inputDirectory;
        }

        /**
         * Sets the input directory.
         *
         * @param inputDirectory the new input directory
         */
        public void setInputDirectory(File inputDirectory) {
            this.inputDirectory = inputDirectory;
        }

        /**
         * Gets the process interval.
         *
         * @return the process interval
         */
        public int getProcessInterval() {
            return processInterval;
        }

        /**
         * Sets the process interval.
         *
         * @param processInterval the new process interval
         */
        public void setProcessInterval(int processInterval) {
            this.processInterval = processInterval;
        }

        /**
         * Gets the input filename.
         *
         * @return the input filename
         */
        public String getInputFilename() {
            return inputFilename;
        }

        /**
         * Sets the input filename.
         *
         * @param inputFilename the new input filename
         */
        public void setInputFilename(String inputFilename) {
            this.inputFilename = inputFilename;
        }

        /**
         * Gets the output filename.
         *
         * @return the output filename
         */
        public String getOutputFilename() {
            return outputFilename;
        }

        /**
         * Sets the output filename.
         *
         * @param outputFilename the new output filename
         */
        public void setOutputFilename(String outputFilename) {
            this.outputFilename = outputFilename;
        }

        /**
         * Gets the bcv newton for.
         *
         * @return the bcv newton for
         */
        public String getBcvNewtonFor() {
            return bcvNewtonForClient;
        }

        /**
         * Sets the bcv newton for.
         *
         * @param bcvNewtonForClient the new bcv newton for
         */
        public void setBcvNewtonFor(String bcvNewtonForClient) {
            this.bcvNewtonForClient = bcvNewtonForClient;
        }

        /**
         * Gets the process chunk size.
         *
         * @return the process chunk size
         */
        public Long getProcessChunkSize() {
            return processChunkSize;
        }

        /**
         * Sets the process chunk size.
         *
         * @param processChunkSize the new process chunk size
         */
        public void setProcessChunkSize(Long processChunkSize) {
            this.processChunkSize = processChunkSize;
        }

        /**
         * {@inheritDoc}
         * 
         * @see java.lang.Object#toString()
         */
        @Override
        public String toString() {
            return "MarketingDaemonProviderConfig [outputDirectory=" + outputDirectory + ", inputDirectory=" + inputDirectory + ", processInterval="
                    + processInterval + ", inputFilename=" + inputFilename + ", outputFilename=" + outputFilename + ", bcvNewtonForClient="
                    + bcvNewtonForClient + ", processChunkSize=" + processChunkSize + "]";
        }

    }

}
