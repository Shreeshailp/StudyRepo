/*
 * Creation : 2 Aug 2019
 */
package com.inetpsa.w7t.batch.infrastructure;

import org.seedstack.business.domain.GenericRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.domain.model.ThreadPoolMaster;

/**
 * The Interface ThreadPoolMasterRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")

public interface ThreadPoolMasterRepository extends GenericRepository<ThreadPoolMaster, String> {

    /**
     * Gets the thread pool size.
     *
     * @param jobName the job name
     * @return the thread pool size
     */
    public int getThreadPoolSize(String jobName);

    /**
     * Gets the last request number.
     *
     * @param client the client
     * @param reqMachine the req machine
     * @param fileId the file id
     * @return the last request number
     */
    public long getLastRequestNumber(String client, String reqMachine, String fileId);

    /**
     * Update MRS.
     *
     * @param client the client
     * @param prevReqNumber the prev req number
     * @param reqMachine the req machine
     * @param fileId the file id
     */
    public void updateMRS(String client, long prevReqNumber, String reqMachine, String fileId);

    /**
     * Creates the MRS.
     *
     * @param client the client
     * @param reqCount the req count
     * @param reqMachine the req machine
     * @param fileId the file id
     */
    public void createMRS(String client, long reqCount, String reqMachine, String fileId);
}
