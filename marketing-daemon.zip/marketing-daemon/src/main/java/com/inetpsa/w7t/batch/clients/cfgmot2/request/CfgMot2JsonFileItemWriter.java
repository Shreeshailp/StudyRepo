/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inetpsa.w7t.batch.clients.cfgmot2.response.CfgMot2JsonAnswer;
import com.inetpsa.w7t.batch.clients.cfgmot2.response.CfgMot2JsonAnswerRequest;
import com.inetpsa.w7t.batch.clients.cfgmot2.response.CfgMot2JsonFileResource;
import com.inetpsa.w7t.batch.clients.cfgmot2.response.CfgMot2JsonResponse;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * The Class CfgMot2JsonFileItemWriter.
 *
 * @author E534811
 */
public class CfgMot2JsonFileItemWriter extends JpaItemWriter<Object> {

    /** The wltp json request batch object list. */
    List<WltpJsonBatchObject> wltpJsonRequestBatchObjectList;

    /** The req number. */
    private volatile long reqNumber = 0;

    /** The invalid req number. */
    private AtomicLong invalidReqNumber = null;

    /** The prev req number. */
    private static volatile long prevReqNumber = 0;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The resource. */
    private CfgMot2JsonFileResource resource;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The executor service. */
    ExecutorService executorService = Executors.newFixedThreadPool(1000);

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */
    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The unique identifier. */
    private String uniqueIdentifier;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @SuppressWarnings("unchecked")
    @Override
    public void doWrite(EntityManager entityManager, List<? extends Object> items) {
        reqNumber = 0;
        invalidReqNumber = new AtomicLong(0);
        List<WltpJsonBatchObject> dtosList = (List<WltpJsonBatchObject>) items;

        List<MarketingRequest> marketingRequestList = new CopyOnWriteArrayList<>();

        logger.info("===================Start Preparing Records to Insert - [{}] ", new Date());
        Optional<MarketingRequest> sameDayMarketingRequest = marketingRequestRepository.bytodayLastRequest(LocalDate.now().toString(),
                MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase());

        String cfgmot2FileId = MarkertingDaemonUtility.generateFileId(MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase(),
                sameDayMarketingRequest, this.uniqueIdentifier);
        logger.info("FILE ID : [{}]-------Ready To Insert ", cfgmot2FileId);

        synchronized (CfgMot2JsonFileItemWriter.class) {
            if (!dtosList.isEmpty())
                CfgMot2JsonFileItemWriter.prevReqNumber = MarkertingDaemonUtility.getLastRequestNumberFromMRS(
                        dtosList.get(0).getWltpJsonBatchRequestObjectList(), this.getPrevReqNumber(), threadPoolMasterRepository,
                        MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase(), cfgmot2FileId);

            logger.info("prevReqNumber : [{}]", CfgMot2JsonFileItemWriter.prevReqNumber);
        }

        List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
        dtosList.forEach(dto -> {

            dto.getWltpJsonBatchRequestObjectList().forEach(request -> {
                ++reqNumber;
                this.setReqNumber(reqNumber);
                String requestId = generateRequestId(prevReqNumber, cfgmot2FileId);
                ++prevReqNumber;
                request.getRequest().setRequestId(requestId);
                logger.info("prevReqNumber : [{}]", prevReqNumber);
                Future<Integer> future = executorService.submit(() -> parallelProcess(request, marketingRequestList, cfgmot2FileId));
                futuresList.add(future);
            });
        });

        for (Future<Integer> future : futuresList) {

            try {
                future.get();

            } catch (Exception e) {
                logger.error("Exception : {}", e);
            }

        }
        logger.info("===================End Preparing Records to Insert - [{}] ", new Date());

        if (!marketingRequestList.isEmpty()) {
            MarkertingDaemonUtility.saveMarketingRequest(marketingRequestList, marketingRequestRepository, threadPoolMasterRepository);
            synchronized (CfgMot2JsonFileItemWriter.class) {
                MarkertingDaemonUtility.createMRQTracker(cfgmot2FileId, MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase(),
                        this.getReqNumber(), (this.getReqNumber() - invalidReqNumber.get()), marketingRequestTrackerRepository,
                        MarketingDaemonConfig.getReqMachine(), MarketingDaemonConfig.getResMachine(), cfgmot2FileId);
                logger.info("===================All Records Inserted - [{}] ", new Date());
            }
            if (this.getReqNumber() != 0)
                sendOnlyRejecedRequestFile(marketingRequestList, this.getReqNumber());
        }

    }

    /**
     * Parallel process.
     *
     * @param request the request
     * @param marketingRequestList the marketing request list
     * @param cfgmot2FileId the cfgmot 2 file id
     * @return the int
     */
    private int parallelProcess(WltpJsonBatchRequestObject request, List<MarketingRequest> marketingRequestList, String cfgmot2FileId) {

        MarketingRequest marketingRequest = new MarketingRequest();
        marketingRequest.setRequestID(request.getRequest().getRequestId());
        marketingRequest.setInternalReqId(request.getRequest().getRequestId());
        // fixed jira-579 and Jira-585
        logger.info("REQUEST_ID [{}] - INTERNAL_REQUEST_ID [{}] - {}", marketingRequest.getRequestID(), marketingRequest.getInternalReqId(), request);
        marketingRequest.setVersion16(request.getRequest().getVersion16C());
        marketingRequest.setColorExtInt(request.getRequest().getColorExtInt());

        String option = request.getRequest().getNbOptions();
        if (option == null)
            option = "00";
        marketingRequest.setOptions(option.length() == 1 ? "0" + option : option);

        marketingRequest.setOptions5C(request.getRequest().getOptions5C());
        marketingRequest.setOptions7C(request.getRequest().getOptions7C());
        marketingRequest.setTradingCountry(request.getRequest().getTradingCountry());
        marketingRequest.setExtensionDate(request.getRequest().getExtensionDate().isEmpty() ? "" : request.getRequest().getExtensionDate());
        marketingRequest.setRequestType(request.getRequest().getRequestType());
        marketingRequest.setStatus(request.getRequest().getStatus());

        marketingRequest.setRequestDate(MarketingDateUtil.getTodaysDate());
        marketingRequest.setAnswerSent(request.getRequest().isAnswerSent());
        marketingRequest.setClient(MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase());
        marketingRequest.setAnswerCode(request.getRequest().getAnswerCode());
        marketingRequest.setAnswerDesig(request.getRequest().getAnswerDesig());
        marketingRequest.setAnswerDate(request.getRequest().getAnswerDate());
        marketingRequest.setFileId(cfgmot2FileId);
        marketingRequest.setMaturity(request.getRequest().getMaturity());
        marketingRequestList.add(marketingRequest);

        if (request.getRequest().getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
            invalidReqNumber.getAndIncrement();
        }
        return 1;
    }

    /**
     * Generate request id.
     *
     * @param prevReqNumber the prev req number
     * @param cfgmot2FileId the cfgmot 2 file id
     * @return the string
     */
    private String generateRequestId(long prevReqNumber, String cfgmot2FileId) {
        String constant12 = cfgmot2FileId;
        StringBuilder constantOfZeros = new StringBuilder();
        int numOfZerosToBeConcat = 20 - constant12.length();
        for (int i = 1; i <= numOfZerosToBeConcat; i++) {
            constantOfZeros.append("0");
        }
        String constantZero = constantOfZeros.toString();

        return constant12 + constantZero.substring(0, constantZero.length() - String.valueOf(prevReqNumber).length()) + prevReqNumber;
    }

    /**
     * Send only rejeced request file.
     *
     * @param marketingRequestList the marketing request list
     * @param reqNumber the req number
     */
    private void sendOnlyRejecedRequestFile(List<MarketingRequest> marketingRequestList, long reqNumber) {
        if (reqNumber == invalidReqNumber.get()) {
            try {
                File sourceFile = new File(getResource().getFile().getAbsolutePath());
                Path newFile = Paths.get(sourceFile.getAbsolutePath());
                List<CfgMot2JsonResponse> jsonAnswerList = new ArrayList<>();
                Map<String, List<CfgMot2JsonResponse>> jsonAnswerMap = new HashMap<>();
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
                objectMapper.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

                marketingRequestList.forEach(rejectedRequest -> {
                    rejectedRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                    marketingRequestRepository.updateStatusByInternalRequestId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                            rejectedRequest.getInternalReqId());
                    logger.info(MARKETING_STATUS_CHANGE_LOG, rejectedRequest, MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(),
                            MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
                    jsonAnswerList.add(mapRequestToDto(rejectedRequest));
                    jsonAnswerMap.put("WLTP-CFGMOT2", jsonAnswerList);
                });

                if (!marketingRequestList.isEmpty()) {
                    objectMapper.writeValue(getResource().getFile(), jsonAnswerMap);
                }
                logger.info("Removing the .part ");
                int lastIndex = sourceFile.getName().lastIndexOf('.');
                String newFileName = sourceFile.getName().substring(0, lastIndex);
                String extension = sourceFile.getName().substring(lastIndex, sourceFile.getName().length());
                Files.move(newFile, newFile.resolveSibling(newFileName + MarketingDateUtil.getTodaysDateforCo2MinMax() + extension));
                logger.info("cfgMto2Answer Json Response file generated");
                // fixed jira-625
                marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                        String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), marketingRequestList.get(0).getFileId());
                if (fileConfigUtilService != null) {
                    MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "configMot2");
                }
            } catch (IOException e) {
                logger.error("Error : {}", e.getMessage());
            }
        }
    }

    /**
     * Map request to dto.
     *
     * @param rejectedRequest the rejected request
     * @return the cfg mot 2 json response
     */
    private CfgMot2JsonResponse mapRequestToDto(MarketingRequest rejectedRequest) {
        CfgMot2JsonAnswerRequest cfgMot2JsonAnswerRequest = new CfgMot2JsonAnswerRequest();
        cfgMot2JsonAnswerRequest.setVersion16C(rejectedRequest.getVersion16());
        cfgMot2JsonAnswerRequest.setColorExtInt(rejectedRequest.getColorExtInt());
        cfgMot2JsonAnswerRequest.setRequestType(rejectedRequest.getRequestType());
        cfgMot2JsonAnswerRequest.setOptions5C(rejectedRequest.getOptions5C());
        cfgMot2JsonAnswerRequest.setOptions7C(rejectedRequest.getOptions7C());
        cfgMot2JsonAnswerRequest.setNbOptions(rejectedRequest.getOptions());
        cfgMot2JsonAnswerRequest.setTradingCountry(rejectedRequest.getTradingCountry());
        return buildCfgMot2JsonAnswerObjectForError(cfgMot2JsonAnswerRequest, rejectedRequest.getAnswerCode(), rejectedRequest.getAnswerDesig());
    }

    /**
     * Builds the cfg mot 2 json answer object for error.
     *
     * @param cfgMot2RequestObject the cfg mot 2 request object
     * @param errorCode the error code
     * @param description the description
     * @return the cfg mot 2 json response
     */
    private CfgMot2JsonResponse buildCfgMot2JsonAnswerObjectForError(CfgMot2JsonAnswerRequest cfgMot2RequestObject, String errorCode,
            String description) {
        CfgMot2JsonResponse responseObject = new CfgMot2JsonResponse();
        responseObject.setRequest(cfgMot2RequestObject);
        responseObject.setAnswer(new CfgMot2JsonAnswer(errorCode, description));
        return responseObject;
    }

    /**
     * Gets the wltp json request batch object list.
     *
     * @return the wltp json request batch object list
     */
    public List<WltpJsonBatchObject> getWltpJsonRequestBatchObjectList() {
        return wltpJsonRequestBatchObjectList;
    }

    /**
     * Sets the wltp json request batch object list.
     *
     * @param wltpJsonRequestBatchObjectList the new wltp json request batch object list
     */
    public void setWltpJsonRequestBatchObjectList(List<WltpJsonBatchObject> wltpJsonRequestBatchObjectList) {
        this.wltpJsonRequestBatchObjectList = wltpJsonRequestBatchObjectList;
    }

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public CfgMot2JsonFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(CfgMot2JsonFileResource resource) {
        this.resource = resource;
    }

    /**
     * Gets the prev req number.
     *
     * @return the prev req number
     */
    public long getPrevReqNumber() {
        return prevReqNumber;
    }

    /**
     * Sets the prev req number.
     *
     * @param prevReqNumber the new prev req number
     */
    public void setPrevReqNumber(long prevReqNumber) {
        this.prevReqNumber = prevReqNumber;
    }

    /**
     * Gets the req number.
     *
     * @return the req number
     */
    public long getReqNumber() {
        return reqNumber;
    }

    /**
     * Sets the req number.
     *
     * @param reqNumber the new req number
     */
    public void setReqNumber(long reqNumber) {
        this.reqNumber = reqNumber;
    }

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

}
