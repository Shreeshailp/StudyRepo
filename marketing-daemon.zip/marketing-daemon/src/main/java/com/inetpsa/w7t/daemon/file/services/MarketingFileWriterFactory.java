/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.daemon.file.services;

import org.seedstack.business.domain.GenericFactory;

import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonClientConfig;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;

/**
 * A factory for creating MarketingFileWriter objects.
 */
public interface MarketingFileWriterFactory extends GenericFactory<MarketingFileWriter> {

    /**
     * Creates a new MarketingFileWriter object.
     *
     * @param name the name
     * @param config the config
     * @return the marketing file writer
     */
    public MarketingFileWriter createClientFileWriter(String name, MarketingDaemonClientConfig config);

    /**
     * Creates a new MarketingFileWriter object.
     *
     * @param key the key
     * @param value the value
     * @return the marketing file writer
     */
    public MarketingFileWriter createProviderFileWriter(String key, MarketingDaemonProviderConfig value);

}
