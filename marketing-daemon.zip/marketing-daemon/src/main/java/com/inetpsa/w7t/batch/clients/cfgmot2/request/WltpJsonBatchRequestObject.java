/*
 * Creation : 16 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.io.Serializable;

import javax.validation.Valid;

/**
 * @author E534811
 */
public class WltpJsonBatchRequestObject implements Serializable {

    private static final long serialVersionUID = -738180243518244103L;

    @Valid
    private WltpJsonRequest request;

    public WltpJsonRequest getRequest() {
        return request;
    }

    public void setRequest(WltpJsonRequest request) {
        this.request = request;
    }

    @Override
    public String toString() {
        return "WltpJsonBatchRequestObject [request=" + request + "]";
    }

    public WltpJsonBatchRequestObject(WltpJsonRequest request) {
        this.request = request;
    }

    public WltpJsonBatchRequestObject() {
    }

}
