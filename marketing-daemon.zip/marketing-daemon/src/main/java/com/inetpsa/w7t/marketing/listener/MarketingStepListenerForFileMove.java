/*
 * Creation : 3 mai 2017
 */
package com.inetpsa.w7t.marketing.listener;

import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;

/**
 * The Class MarketingStepListenerForFileMove.
 */
public class MarketingStepListenerForFileMove implements StepExecutionListener {

    /** The filepath. */
    private String filepath;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Instantiates a new step listener for file move.
     *
     * @param path the path
     */
    public MarketingStepListenerForFileMove(String path) {
        this.filepath = path;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#beforeStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public void beforeStep(StepExecution stepExecution) {
        // nothing to do here
    }

    /**
     * Copy completed file to processed folder {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#afterStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        try {

            // fix for file move split
            if (stepExecution != null && stepExecution.getExecutionContext() != null
                    && stepExecution.getExecutionContext().get("fileResource") != null) {

                Files.deleteIfExists(Paths.get(stepExecution.getExecutionContext().getString("fileResource")));
            }
            MarketingDaemonBatchUtils.moveProcessedFile(filepath);

        } catch (FileNotFoundException e) {
            return ExitStatus.COMPLETED;
        } catch (Exception e) {
            logger.error("Failed to copy file to processed dir ", e);
            return ExitStatus.FAILED;
        }

        return ExitStatus.COMPLETED;
    }

}
