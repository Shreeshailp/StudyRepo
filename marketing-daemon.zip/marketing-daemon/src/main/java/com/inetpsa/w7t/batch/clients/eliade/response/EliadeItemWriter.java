/*
 * Creation : 7 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.eliade.response;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.inetpsa.w7t.batch.clients.aogeos.request.EliadeRequestDTO;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;

import edu.emory.mathcs.backport.java.util.concurrent.CopyOnWriteArrayList;

/**
 * The Class AoGeosItemWriter.
 */
public class EliadeItemWriter extends JpaItemWriter<EliadeRequestDTO> {

    /** The resource. */
    private EliadeFlatFileResource resource;

    /** The original file id. */
    private String originalFileId = "";

    /** The formatter. */
    DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The thread pool master repository. */
    @Inject
    private ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The response to write all. */
    @SuppressWarnings("unchecked")
    static List<MarketingRequest> responseToWriteAll = new CopyOnWriteArrayList();

    /** The client parameter repository. */
    @Inject
    private ClientParameterFinder clientPrameterFinder;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends EliadeRequestDTO> items) {
        long reqNumber = 0;
        long invalidReqNumber = 0;
        long prevReqNumber = 0;
        Set<EliadeRequestDTO> dtosList = new HashSet<>(items);
        List<EliadeRequestDTO> eliadeDtoList = new ArrayList<>(items);
        List<MarketingRequest> responseToWrite = new ArrayList<>();
        synchronized (EliadeItemWriter.class) {
            prevReqNumber = MarkertingDaemonUtility.getEliadeLastRequestNumberFromMRS(dtosList, prevReqNumber, threadPoolMasterRepository,
                    MarketingDaemonServiceConstants.ELIADE.toUpperCase(), eliadeDtoList.get(0).getFileId());
        }

        logger.info("===================Start Preparing Records to Insert - [{}] ", new Date());

        Set<EliadeRequestDTO> duplicateSet = findDuplicates(eliadeDtoList);
        for (EliadeRequestDTO eliadeRequestDTO : duplicateSet) {
            logger.info(" Duplicate REQUEST_ID : [{}] and FILE_ID : [{}] ", eliadeRequestDTO.getRequestId(), eliadeRequestDTO.getFileId());
        }
        String fsFlagFileName = "";
        for (EliadeRequestDTO dto : dtosList) {
            MarketingRequest entity = new MarketingRequest();
            String ext = dto.getHabillage_Ext() + dto.getHabillage_Int();
            entity.setExtensionDate(dto.getExtensionDate());
            entity.setRequestDate(MarketingDateUtil.getTodaysDate());

            fsFlagFileName = dto.getFsFlagFileName();

            String requestId = dto.getPrd() + dto.getLotNumber() + dto.getLineNumber();
            logger.info("Eliade Writer requestId {}:", requestId);
            originalFileId = requestId.substring(0, MarketingDaemonServiceConstants.AoCronoEliadeUniqueCharLenth);
            entity.setBrand(dto.getBrand());
            entity.setRequestType("FULL");
            entity.setRequestID(requestId);
            entity.setInternalReqId(MarkertingDaemonUtility.generateInternalRequestId(prevReqNumber, dto.getFileId()));
            // fixed jira-579
            logger.info("REQUEST_ID [{}] - INTERNAL_REQUEST_ID [{}]", entity.getRequestID(), entity.getInternalReqId());
            entity.setColorExtInt(ext);
            String gestion = dto.getGestion();
            if (gestion == null) {
                gestion = "00";
            } else if (gestion.length() == 1) {
                gestion = "0" + gestion;
            }
            entity.setGestion(gestion);
            String option = dto.getOptions();
            if (option == null) {
                option = "00";
            } else if (option.length() == 1) {
                option = "0" + option;
            }
            entity.setOptions(option);
            entity.setVersion16(dto.getVersion());
            entity.setTradingCountry(dto.getCountry());
            entity.setStatus(dto.getStatus());
            entity.setOptions5C(dto.getOptions5C());
            entity.setOptions7C(dto.getOptions7c());
            entity.setGestion5C(dto.getGestion5c());
            entity.setGestion7C(dto.getGestion7c());
            entity.setClient(MarketingDaemonServiceConstants.ELIADE.toUpperCase());
            entity.setAnswerCode(dto.getAnswerCode());
            entity.setAnswerDesig(dto.getAnswerDesignation());
            entity.setAnswerDate(dto.getAnswerDate());
            entity.setSendingSite(dto.getSendingSite());
            entity.setSendingApplication(dto.getShippingApplication());
            entity.setLotNumber(dto.getHeaderLotNumber());
            entity.setLotDate(LocalDate.parse(dto.getLotDate(), formatter).toString());
            entity.setFileId(dto.getFileId());
            entity.setMaturity(dto.getMaturity());
            responseToWrite.add(entity);

            if (entity.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ++invalidReqNumber;
            }

            ++reqNumber;
            ++prevReqNumber;

        }

        if (!responseToWrite.isEmpty()) {
            synchronized (EliadeItemWriter.class) {
                MarkertingDaemonUtility.saveMarketingRequest(responseToWrite, marketingRequestRepository, threadPoolMasterRepository);
                MarkertingDaemonUtility.updateMRQTracker(responseToWrite.get(0).getFileId(), (reqNumber - invalidReqNumber),
                        MarketingDaemonConfig.getReqMachine(), MarketingDaemonConfig.getResMachine(), originalFileId,
                        marketingRequestTrackerRepository);
                // save data to W7TQTFSF table
                // Added below code as part of jira-660 fix -- start
                if (!fsFlagFileService.isFileIdExist(responseToWrite.get(0).getFileId())) {
                    fsFlagFileService.saveFsFlagEntity(responseToWrite.get(0).getClient(), fsFlagFileName, responseToWrite.get(0).getFileId());
                }
                // jira-660 fix -- end
                logger.info("===================All Records Inserted - [{}], MRQ Count [{}]", new Date(), reqNumber, (reqNumber - invalidReqNumber));
            }

        }

    }

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public EliadeFlatFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(EliadeFlatFileResource resource) {
        this.resource = resource;
    }

    /**
     * Find duplicates.
     *
     * @param aoCronoEliadeDtoList the ao crono eliade dto list
     * @return the sets the
     */
    private Set<EliadeRequestDTO> findDuplicates(List<EliadeRequestDTO> aoCronoEliadeDtoList) {
        Set<EliadeRequestDTO> duplicates = new LinkedHashSet<>();
        Set<EliadeRequestDTO> uniques = new HashSet<>();
        for (EliadeRequestDTO t : aoCronoEliadeDtoList) {
            if (!uniques.add(t)) {
                duplicates.add(t);
            }
        }
        return duplicates;
    }

}
