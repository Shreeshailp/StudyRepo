/*
 * Creation : 27 avr. 2017
 */
package com.inetpsa.w7t.daemon.services.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import javax.annotation.CheckForNull;
import javax.annotation.Nullable;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.batch.clients.aogeos.request.AogeosHeaderDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.CronosHeaderDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.EliadeHeaderDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.IcubeHeaderDTO;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.daemon.file.services.internal.MarketingFileFilter;
import com.inetpsa.w7t.domain.model.MarketingRequest;

/**
 * The Class DaemonServiceUtils.
 */
public final class MarketingDaemonServiceUtils {

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(MarketingDaemonServiceUtils.class);

    /** The Constant ERROR_LOG. */
    private static final String ERROR_LOG = "Error: {}";

    /** The Constant INPUT_FILE_LOG. */
    private static final String INPUT_FILE_LOG = "inputfile : {}";

    /** The Constant PATH_FILE_LOG. */
    private static final String PATH_FILE_LOG = "path : {}";

    /** The Constant NO_OF_FILE_LOG. */
    private static final String NO_OF_FILE_LOG = "No. of files to be generated : {}";

    /** The cronos header DTO map. */
    private static Map<String, CronosHeaderDTO> cronosHeaderDTOMap = new ConcurrentHashMap<>();

    /** The aogeos header DTO map. */
    private static Map<String, AogeosHeaderDTO> aogeosHeaderDTOMap = new ConcurrentHashMap<>();

    /** The eliade header DTO map. */
    private static Map<String, EliadeHeaderDTO> eliadeHeaderDTOMap = new ConcurrentHashMap<>();

    /** The icube header DTO map. */
    private static Map<String, IcubeHeaderDTO> icubeHeaderDTOMap = new ConcurrentHashMap<>();

    /**
     * Instantiates a new marketing daemon service utils.
     */
    private MarketingDaemonServiceUtils() {
        // Not to be initialized.
    }

    /**
     * Get the oldest file for a specific name and ext.
     *
     * @param filePath the file path
     * @param pattern the pattern
     * @return the the oldest file
     */
    public static File getTheOldestFile(File filePath, String pattern) {
        if (filePath != null && pattern != null) {
            FileFilter fileFilter = new MarketingFileFilter(pattern);
            File[] files = filePath.listFiles(fileFilter);

            if (files != null && files.length > 0) {
                return getSortResult(files);
            }
        }
        return null;
    }

    /**
     * Gets the sort result.
     *
     * @param files the files
     * @return the sort result
     */
    private static File getSortResult(File[] files) {
        Arrays.sort(files, (File f1, File f2) -> {
            if (f2.lastModified() > f1.lastModified())
                return 1;
            if (f2.lastModified() == f1.lastModified())
                return 0;
            return -1;
        });
        return files[0];
    }

    /**
     * Checks if is valid file path.
     *
     * @param path the path
     * @return true, if is valid file path
     */
    public static boolean isValidFilePath(String path) {
        // validated as per check-marx report
        File f = new File(path);
        try {
            f.getCanonicalPath();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Sanitize.
     *
     * @param path the path
     * @return the string
     */
    @CheckForNull
    public static String sanitize(@Nullable String path) {
        return FilenameUtils.normalize(path, true);
    }

    /**
     * Split file.
     *
     * @param inputfilepath the inputfilepath
     * @param noRecordsPerFile the no records per file
     * @param clientName the client name
     * @param marketingRequestRepository the marketing request repository
     * @param uniqueIdentifier the unique identifier
     * @return the list
     */
    @SuppressWarnings("rawtypes")
    public static List<File> splitFile(String inputfilepath, Long noRecordsPerFile, String clientName,
            MarketingRequestRepository marketingRequestRepository, String uniqueIdentifier) {
        // validated and sanitized as per check-marx report
        String inputfile = sanitize(inputfilepath);
        boolean proceed = isValidFilePath(inputfile);
        Path path = null;
        if (proceed) {
            path = Paths.get(inputfile);
            logger.info(PATH_FILE_LOG, path);
        }
        try (FileInputStream fstream = new FileInputStream(inputfile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                Stream fileLines = Files.lines(path);) {
            // Reading file and getting no. of files to be generated
            List<File> files = new ArrayList<>();
            logger.info(INPUT_FILE_LOG, inputfile);
            // validated as per check-marx report
            List<String> lines = Files.readAllLines(path, StandardCharsets.US_ASCII);

            String lineFirst = "";
            String lineLast = "";
            if (!lines.isEmpty()) {
                lineFirst = lines.get(0);
                lineLast = lines.get(lines.size() - 1);
            }
            double lineCount = fileLines.count();

            Long numberOfRecordsPerFile = null;
            if (noRecordsPerFile == null) {
                numberOfRecordsPerFile = 20000L;
            } else {
                numberOfRecordsPerFile = noRecordsPerFile;
            }
            double nol = numberOfRecordsPerFile;
            double numberOfFileRecords = lineCount - 2;
            double temp = (numberOfFileRecords / nol);
            if (temp == 0)
                temp++;
            int temp1 = (int) temp;
            int nof = 0;
            if (temp1 == temp) {
                nof = temp1;
            } else {
                nof = temp1 + 1;
            }

            long lastFileRecordCount = (long) (numberOfFileRecords % numberOfRecordsPerFile);
            if (lastFileRecordCount == 0)
                lastFileRecordCount = numberOfRecordsPerFile;
            logger.info(NO_OF_FILE_LOG, nof); // Displays no. of files to be generated.

            String today = LocalDate.now().toString();

            Optional<MarketingRequest> sameDayMarketingRequest = marketingRequestRepository.bytodayLastRequest(today, clientName);
            String fileId = MarkertingDaemonUtility.generateFileId(clientName, sameDayMarketingRequest, uniqueIdentifier);

            // ---------------------------------------------------------------------------------------------------------

            // Actual splitting of file into smaller files

            String strLine;
            String extention = "." + FilenameUtils.getExtension(inputfile);
            // fixed jira-560 and jira-511
            int startIndex = 1;
            for (int fileNumber = 1; fileNumber <= nof; fileNumber++) {
                String newFile = inputfile.replace(extention, fileNumber + extention + "_" + fileId);
                try (FileWriter fstream1 = new FileWriter(newFile); // Destination File
                        BufferedWriter out = new BufferedWriter(fstream1);) {
                    // Write header line
                    out.write(lineFirst);
                    out.newLine();

                    // Write body lines
                    for (int i = 1; i <= nol; i++) {
                        if (fileNumber == nof && i > lastFileRecordCount)
                            break;
                        // fixed jira-560 and jira-511
                        strLine = lines.get(startIndex);
                        if (strLine != null) {
                            String requestId = strLine.substring(4, 24);
                            out.write(strLine);
                            out.newLine();
                            // fixed jira-560 and jira-511
                            startIndex++;
                        } else {
                            logger.info("The record [{}] seems to be not written in the splitted file [{}]", strLine, newFile);
                        }
                    }

                    // Write footer line
                    if (fileNumber <= nof)
                        out.write(lineLast);

                    files.add(new File(newFile));

                } catch (Exception e) {
                    logger.error(ERROR_LOG, e);
                }
            }
            return files;
        } catch (

        Exception e) {
            logger.error(ERROR_LOG, e);
        }
        return Collections.emptyList();
    }

    /**
     * Split file for eliade.
     *
     * @param inputfilepath the inputfilepath
     * @param noRecordsPerFile the no records per file
     * @param clientName the client name
     * @param marketingRequestRepository the marketing request repository
     * @param uniqueIdentifier the unique identifier
     * @param marketingRequestTrackerRepository the marketing request tracker repository
     * @return the list
     */
    @SuppressWarnings("rawtypes")
    public static List<File> splitFileForEliade(String inputfilepath, Long noRecordsPerFile, String clientName,
            MarketingRequestRepository marketingRequestRepository, String uniqueIdentifier,
            MarketingRequestTrackerRepository marketingRequestTrackerRepository) {
        // validated and sanitized as per check-marx report
        String inputfile = sanitize(inputfilepath);
        boolean proceed = isValidFilePath(inputfile);
        Path path = null;
        if (proceed) {
            path = Paths.get(inputfile);
            logger.info(PATH_FILE_LOG, path);
        }
        try (FileInputStream fstream = new FileInputStream(inputfile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                Stream fileLines = Files.lines(path);) {
            // Reading file and getting no. of files to be generated
            List<File> files = new ArrayList<>();
            logger.info(INPUT_FILE_LOG, inputfile);
            // validated as per check-marx report
            List<String> lines = Files.readAllLines(path, StandardCharsets.US_ASCII);

            String lineFirst = "";
            String lineLast = "";
            if (!lines.isEmpty()) {
                lineFirst = lines.get(0);
                lineLast = lines.get(lines.size() - 1);
            }
            double lineCount = fileLines.count();

            Long numberOfRecordsPerFile = null;
            if (noRecordsPerFile == null) {
                numberOfRecordsPerFile = 20000L;
            } else {
                numberOfRecordsPerFile = noRecordsPerFile;
            }
            double nol = numberOfRecordsPerFile;
            double numberOfFileRecords = lineCount - 2;
            double temp = (numberOfFileRecords / nol);
            if (temp == 0)
                temp++;
            int temp1 = (int) temp;
            int nof = 0;
            if (temp1 == temp) {
                nof = temp1;
            } else {
                nof = temp1 + 1;
            }

            long lastFileRecordCount = (long) (numberOfFileRecords % numberOfRecordsPerFile);
            if (lastFileRecordCount == 0)
                lastFileRecordCount = numberOfRecordsPerFile;
            logger.info(NO_OF_FILE_LOG, nof); // Displays no. of files to be generated.

            String today = LocalDate.now().toString();

            Optional<MarketingRequest> sameDayMarketingRequest = marketingRequestRepository.bytodayLastRequest(today, clientName);
            String fileId = MarkertingDaemonUtility.generateFileId(clientName, sameDayMarketingRequest, uniqueIdentifier);
            long mrqCount = (long) numberOfFileRecords;
            MarkertingDaemonUtility.createMRQTracker(fileId, clientName, mrqCount, 0, marketingRequestTrackerRepository);
            // ---------------------------------------------------------------------------------------------------------

            // Actual splitting of file into smaller files

            String strLine;
            String extention = "." + FilenameUtils.getExtension(inputfile);
            // fixed jira-560 and jira-511
            int startIndex = 1;
            for (int fileNumber = 1; fileNumber <= nof; fileNumber++) {
                String newFile = inputfile.replace(extention, fileNumber + extention + "_" + fileId);
                try (FileWriter fstream1 = new FileWriter(newFile); // Destination File
                        BufferedWriter out = new BufferedWriter(fstream1);) {
                    // Write header line
                    out.write(lineFirst);
                    out.newLine();

                    // Write body lines
                    for (int i = 1; i <= nol; i++) {
                        if (fileNumber == nof && i > lastFileRecordCount)
                            break;
                        // fixed jira-560 and jira-511
                        strLine = lines.get(startIndex);
                        if (strLine != null) {
                            String requestId = strLine.substring(4, 24);
                            out.write(strLine);
                            out.newLine();
                            // fixed jira-560 and jira-511
                            startIndex++;
                        } else {
                            logger.info("The record [{}] seems to be not written in the splitted file [{}]", strLine, newFile);
                        }
                    }

                    // Write footer line
                    if (fileNumber <= nof)
                        out.write(lineLast);

                    files.add(new File(newFile));

                } catch (Exception e) {
                    logger.error(ERROR_LOG, e);
                }
            }
            return files;
        } catch (

        Exception e) {
            logger.error(ERROR_LOG, e);
        }
        return Collections.emptyList();
    }

    /**
     * Sets the cronos header.
     *
     * @param fileId the file id
     * @param headerDTO the header DTO
     */
    public static void setCronosHeader(String fileId, CronosHeaderDTO headerDTO) {
        cronosHeaderDTOMap.put(fileId, headerDTO);
    }

    /**
     * Reset cronos header.
     *
     * @param fileId the file id
     */
    public static void resetCronosHeader(String fileId) {
        cronosHeaderDTOMap.remove(fileId);
    }

    /**
     * Gets the cronos header.
     *
     * @param fileId the file id
     * @return the cronos header
     */
    public static CronosHeaderDTO getCronosHeader(String fileId) {
        return cronosHeaderDTOMap.get(fileId);
    }

    /**
     * Sets the aogeos header.
     *
     * @param fileId the file id
     * @param headerDTO the header DTO
     */
    public static void setAogeosHeader(String fileId, AogeosHeaderDTO headerDTO) {
        aogeosHeaderDTOMap.put(fileId, headerDTO);
    }

    /**
     * Reset aogeos header.
     *
     * @param fileId the file id
     */
    public static void resetAogeosHeader(String fileId) {
        aogeosHeaderDTOMap.remove(fileId);
    }

    /**
     * Gets the aogeos header.
     *
     * @param fileId the file id
     * @return the aogeos header
     */
    public static AogeosHeaderDTO getAogeosHeader(String fileId) {
        return aogeosHeaderDTOMap.get(fileId);
    }

    /**
     * Sets the eliade header.
     *
     * @param fileId the file id
     * @param headerDTO the header DTO
     */
    public static void setEliadeHeader(String fileId, EliadeHeaderDTO headerDTO) {
        eliadeHeaderDTOMap.put(fileId, headerDTO);
    }

    /**
     * Gets the eliade header.
     *
     * @param fileId the file id
     * @return the eliade header
     */
    public static EliadeHeaderDTO getEliadeHeader(String fileId) {
        return eliadeHeaderDTOMap.get(fileId);
    }

    /**
     * Reset eliade header.
     *
     * @param fileId the file id
     */
    public static void resetEliadeHeader(String fileId) {
        eliadeHeaderDTOMap.remove(fileId);
    }

    /**
     * Sets the icube header.
     *
     * @param fileId the file id
     * @param headerDTO the header DTO
     */
    public static void setIcubeHeader(String fileId, IcubeHeaderDTO headerDTO) {
        icubeHeaderDTOMap.put(fileId, headerDTO);
    }

    /**
     * Gets the icube header.
     *
     * @param fileId the file id
     * @return the icube header
     */
    public static IcubeHeaderDTO getIcubeHeader(String fileId) {
        return icubeHeaderDTOMap.get(fileId);
    }

    /**
     * Reset icube header.
     *
     * @param fileId the file id
     */
    public static void resetIcubeHeader(String fileId) {
        icubeHeaderDTOMap.remove(fileId);
    }
}
