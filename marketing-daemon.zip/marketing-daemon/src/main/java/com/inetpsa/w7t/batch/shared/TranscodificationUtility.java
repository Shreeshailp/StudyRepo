/*
 * Creation : 10 May 2021
 */
package com.inetpsa.w7t.batch.shared;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.r3pi.transcolcdv.TranscoManager57;
import com.inetpsa.r3pi.transcolcdv.TranscoManager75;
import com.inetpsa.r3pi.transcolcdv.exception.TranscoNotFoundException;
import com.inetpsa.w7t.batch.clients.aogeos.request.AogeosRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.CronosRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.EliadeRequestDTO;
import com.inetpsa.w7t.batch.clients.aogeos.request.IcubeRequestDTO;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;
import com.inetpsa.w7t.domains.references.model.ClientParameter;

/**
 * The Class TranscodificationUtility.
 */
public class TranscodificationUtility {
    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(TranscodificationUtility.class);

    /** The Constant FIVE. */
    private static final int FIVE = 5;

    /** The Constant THREE_FOUR_NINE. */
    private static final int THREE_FOUR_NINE = 349;

    /** The Constant SEVEN. */
    private static final int SEVEN = 7;

    /** The Constant OPTION7C. */
    public static final String OPTION7C = "Y";

    /** The Constant OPTION5C. */
    public static final String OPTION5C = "N";

    /**
     * Instantiates a new transcodification utility.
     */
    private TranscodificationUtility() {

    }

    /**
     * Gets the gestion as block of 7.
     *
     * @param str the str
     * @return the gestion as block of 7
     */
    public static String getGestionAsBlockOf7(String str) {
        if (str == null || str.isEmpty())
            return str;
        int beginIndex = 0;
        int endIndex = SEVEN;
        StringBuilder sb = new StringBuilder();
        final String _7BLANKS = "       ";
        while (beginIndex <= THREE_FOUR_NINE) {
            String tempStr = str.substring(beginIndex, endIndex);
            if (!tempStr.contains(_7BLANKS)) {
                sb.append(tempStr);
            }
            beginIndex = endIndex;
            endIndex += SEVEN;

        }
        return sb.toString();
    }

    /**
     * Gets the gestion as block of 5.
     *
     * @param str the str
     * @return the gestion as block of 5
     */
    public static String getGestionAsBlockOf5(String str) {
        if (str == null || str.isEmpty())
            return str;
        int beginIndex = 0;
        int endIndex = FIVE;
        StringBuilder sb = new StringBuilder();
        final String _5BLANKS = "     ";
        while (beginIndex <= THREE_FOUR_NINE) {
            String tempStr = str.substring(beginIndex, endIndex);
            if (!tempStr.contains(_5BLANKS)) {
                sb.append(tempStr);
            }
            beginIndex = endIndex;
            endIndex += FIVE;

        }
        return sb.toString();
    }

    /**
     * Transcodify.
     *
     * @param option5C the option5 c
     * @param requestId the request id
     * @return the string
     * @throws TranscoNotFoundException
     */
    public static String transcodify(String option5C, String requestId) throws TranscoNotFoundException {
        TranscoManager57 tm57 = TranscoManager57.getInstance();
        StringBuilder persValue = new StringBuilder();

        List<String> lcdvList = new ArrayList<>();
        int index = 0;
        while (index < option5C.length()) {
            lcdvList.add(" " + option5C.substring(index, index + FIVE));
            index += FIVE;
        }
        logger.info("Request ID[{}]: Transcodification module request =  [{}]", requestId, option5C);
        try {
            for (String lcdv : lcdvList)
                persValue.append(tm57.transco(lcdv));
        } catch (TranscoNotFoundException e) {
            throw e;
        }
        logger.info("Request ID[{}]: Transcodification module response =  [{}]", requestId, persValue);
        return persValue.toString();
    }

    /**
     * Transcodify 7 C to 5 C.
     *
     * @param option7C the option 7 C
     * @param requestId the request id
     * @return the string
     * @throws TranscoNotFoundException
     */
    public static String transcodify7CTo5C(String option7C, String requestId) throws TranscoNotFoundException {
        TranscoManager75 tm75 = TranscoManager75.getInstance();
        StringBuilder persValue = new StringBuilder();

        List<String> lcdvList = new ArrayList<>();
        int index = 0;
        while (index < option7C.length()) {
            lcdvList.add(" " + option7C.substring(index, index + SEVEN));
            index += SEVEN;
        }
        logger.info("Request ID[{}]: Transcodification module request =  [{}]", requestId, option7C);
        try {
            for (String lcdv : lcdvList)
                persValue.append(tm75.transco(lcdv));
        } catch (TranscoNotFoundException e) {
            throw e;
        }
        logger.info("Request ID[{}]: Transcodification module response =  [{}]", requestId, persValue);

        return persValue.toString();
    }

    /**
     * Ao geos transcodification.
     *
     * @param dtosList the dtos list
     * @param clientPrameterFinder the client prameter finder
     * @return the sets the
     */
    public static Set<AogeosRequestDTO> aoGeosTranscodification(Set<AogeosRequestDTO> dtosList, ClientParameterFinder clientPrameterFinder) {
        Set<AogeosRequestDTO> dtoList = new HashSet<>();
        for (AogeosRequestDTO item : dtosList) {
            if (!item.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
                if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
                    if (!isNullOrEMPTY(item.getOptions7c())) {
                        if (item.getOptions7c().length() % SEVEN == 0) {
                            try {
                                // CR-723 to add transcodify()
                                String option5c = TranscodificationUtility.transcodify7CTo5C(item.getOptions7c(), item.getRequestId());
                                item.setOptions(String.valueOf(option5c.length() / FIVE));
                                item.setOptions5C(option5c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        }

                    }
                } else {
                    option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
                    if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !isNullOrEMPTY(item.getOptions7c())) {
                        item.setOptions5C(item.getOptions7c().replace(" ", ""));
                        if (item.getOptions5C().length() % FIVE == 0) {
                            item.setOptions5C(item.getOptions5C());
                            try {
                                String option7c = TranscodificationUtility.transcodify(item.getOptions5C(), item.getRequestId());
                                item.setOptions(String.valueOf(option7c.length() / SEVEN));
                                item.setOptions7c(option7c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                        }
                    }

                }

                item.setOptions((!isNullOrEMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
                        ? String.valueOf(item.getOptions7c().length() / SEVEN)
                        : "");
            }
            dtoList.add(item);
        }

        return dtoList;
    }

    /**
     * Eliade transcodification.
     *
     * @param dtosList the dtos list
     * @param clientPrameterFinder the client prameter finder
     * @return the sets the
     */
    public static Set<EliadeRequestDTO> eliadeTranscodification(Set<EliadeRequestDTO> dtosList, ClientParameterFinder clientPrameterFinder) {
        Set<EliadeRequestDTO> dtoList = new HashSet<>();
        for (EliadeRequestDTO item : dtosList) {
            if (!item.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
                if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
                    if (!isNullOrEMPTY(item.getOptions7c())) {
                        if (item.getOptions7c().length() % SEVEN == 0) {
                            // CR-723 to add transcodify()
                            try {
                                String option5c = TranscodificationUtility.transcodify7CTo5C(item.getOptions7c(), item.getRequestId());
                                item.setOptions(String.valueOf(option5c.length() / FIVE));
                                item.setOptions5C(option5c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            }

                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        }

                    }
                } else {
                    option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
                    if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !isNullOrEMPTY(item.getOptions7c())) {
                        item.setOptions5C(item.getOptions7c().replace(" ", ""));
                        if (item.getOptions5C().length() % FIVE == 0) {
                            item.setOptions5C(item.getOptions5C());
                            try {
                                String option7c = TranscodificationUtility.transcodify(item.getOptions5C(), item.getRequestId());
                                item.setOptions(String.valueOf(option7c.length() / SEVEN));
                                item.setOptions7c(option7c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                        }
                    }

                }

                item.setOptions((!isNullOrEMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
                        ? String.valueOf(item.getOptions7c().length() / SEVEN)
                        : "");
            }
            dtoList.add(item);
        }

        return dtoList;
    }

    /**
     * Icubes transcodification.
     *
     * @param dtosList the dtos list
     * @param clientPrameterFinder the client prameter finder
     * @return the sets the
     */
    public static Set<IcubeRequestDTO> icubesTranscodification(Set<IcubeRequestDTO> dtosList, ClientParameterFinder clientPrameterFinder) {
        Set<IcubeRequestDTO> dtoList = new HashSet<>();
        for (IcubeRequestDTO item : dtosList) {
            if (!item.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
                if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
                    if (!isNullOrEMPTY(item.getOptions7c())) {
                        if (item.getOptions7c().length() % SEVEN == 0) {
                            // CR-723 to add transcodify()
                            try {
                                String option5c = TranscodificationUtility.transcodify7CTo5C(item.getOptions7c(), item.getRequestId());
                                item.setOptions(String.valueOf(option5c.length() / FIVE));
                                item.setOptions5C(option5c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        }

                    }
                } else {
                    option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
                    if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !isNullOrEMPTY(item.getOptions7c())) {
                        item.setOptions5C(item.getOptions7c().replace(" ", ""));
                        if (item.getOptions5C().length() % FIVE == 0) {
                            item.setOptions5C(item.getOptions5C());
                            try {
                                String option7c = TranscodificationUtility.transcodify(item.getOptions5C(), item.getRequestId());
                                item.setOptions(String.valueOf(option7c.length() / SEVEN));
                                item.setOptions7c(option7c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                        }
                    }

                }

                item.setOptions((!isNullOrEMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
                        ? String.valueOf(item.getOptions7c().length() / SEVEN)
                        : "");
            }
            dtoList.add(item);
        }

        return dtoList;
    }

    /**
     * Cronos transcodification.
     *
     * @param dtosList the dtos list
     * @param clientPrameterFinder the client prameter finder
     * @return the sets the
     */
    public static Set<CronosRequestDTO> cronosTranscodification(Set<CronosRequestDTO> dtosList, ClientParameterFinder clientPrameterFinder) {
        Set<CronosRequestDTO> dtoList = new HashSet<>();
        for (CronosRequestDTO item : dtosList) {
            if (!item.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ClientParameter option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION7C);
                if (option7CFlagObj != null && "Y".equals(option7CFlagObj.getFlag7c())) {
                    if (!isNullOrEMPTY(item.getOptions7c())) {
                        if (item.getOptions7c().length() % SEVEN == 0) {
                            // CR-723 to add transcodify()
                            try {
                                String option5c = TranscodificationUtility.transcodify7CTo5C(item.getOptions7c(), item.getRequestId());
                                item.setOptions(String.valueOf(option5c.length() / FIVE));
                                item.setOptions5C(option5c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        }

                    }
                } else {
                    option7CFlagObj = clientPrameterFinder.getFlag7C(item.getPrd(), OPTION5C);
                    if (option7CFlagObj != null && "N".equals(option7CFlagObj.getFlag7c()) && !isNullOrEMPTY(item.getOptions7c())) {
                        item.setOptions5C(item.getOptions7c().replace(" ", ""));
                        if (item.getOptions5C().length() % FIVE == 0) {
                            item.setOptions5C(item.getOptions5C());
                            try {
                                String option7c = TranscodificationUtility.transcodify(item.getOptions5C(), item.getRequestId());
                                item.setOptions(String.valueOf(option7c.length() / SEVEN));
                                item.setOptions7c(option7c);
                            } catch (TranscoNotFoundException e) {
                                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                                setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                        WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            }
                        } else {
                            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                            setErrorDetails(item, WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                            LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getRuleCode(),
                                    WltpRequestErrorCode.OPTIONS_5C_INCORRECT.getDescription());
                        }
                    }

                }

                item.setOptions((!isNullOrEMPTY(item.getOptions7c()) && item.getOptions7c().length() % SEVEN == 0)
                        ? String.valueOf(item.getOptions7c().length() / SEVEN)
                        : "");

            }
            dtoList.add(item);
        }

        return dtoList;
    }

    /**
     * Sets the error details.
     *
     * @param mrq the mrq
     * @param ruleCode the rule code
     * @param description the description
     */
    private static void setErrorDetails(EliadeRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Sets the error details.
     *
     * @param mrq the mrq
     * @param ruleCode the rule code
     * @param description the description
     */
    private static void setErrorDetails(AogeosRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Sets the error details.
     *
     * @param mrq the mrq
     * @param ruleCode the rule code
     * @param description the description
     */
    private static void setErrorDetails(CronosRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Sets the error details.
     *
     * @param mrq the mrq
     * @param ruleCode the rule code
     * @param description the description
     */
    private static void setErrorDetails(IcubeRequestDTO mrq, String ruleCode, String description) {
        // fixed jira-551
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
            mrq.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

    /**
     * Checks if is null or EMPTY.
     *
     * @param value the value
     * @return true, if is null or EMPTY
     */
    private static boolean isNullOrEMPTY(String value) {
        boolean isInvalid = false;
        if (value == null || value.isEmpty()) {
            isInvalid = true;
        }
        return isInvalid;
    }

    /**
     * Toyota transcodification.
     *
     * @param dtosList the dtos list
     * @return the list
     */
    public static List<MarketingRequest> toyotaTranscodification(List<MarketingRequest> dtosList) {
        List<MarketingRequest> dtoList = new ArrayList<>();
        for (MarketingRequest item : dtosList) {
            if (!item.getStatus().equalsIgnoreCase(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))
                    && item.getOptions7C() != null && !item.getOptions7C().isEmpty()) {
                if (item.getOptions7C().length() % 7 == 0) {
                    // CR-723 to add transcodify()
                    try {
                        String option5c = TranscodificationUtility.transcodify7CTo5C(item.getOptions7C(), item.getRequestID());
                        item.setOptions(String.valueOf(option5c.length() / FIVE));
                        item.setOptions5C(option5c);
                    } catch (TranscoNotFoundException e) {
                        item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                        setErrorDetails(item, WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                        LogUtility.logTheError(logger, item.getRequestID(), WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getRuleCode(),
                                WltpRequestErrorCode.OPTIONS_7C_INCORRECT.getDescription());
                    }
                }
            } else {
                item.setOptions("");
            }
            dtoList.add(item);
        }
        return dtoList;
    }

    private static void setErrorDetails(MarketingRequest item, String ruleCode, String description) {
        // fixed jira-551
        if (item.getAnswerCode() == null) {
            item.setAnswerCode(ruleCode);
            item.setAnswerDesig(description);
            item.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }
    }

}
