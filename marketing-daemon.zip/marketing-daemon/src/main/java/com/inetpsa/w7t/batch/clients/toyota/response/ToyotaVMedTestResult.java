/*
 * Creation : 9 Nov 2021
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author E562493
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "vmedPhaseResults" })
@XmlRootElement(name = "VMED_TEST_RESULTS")
public class ToyotaVMedTestResult {

    /** The vmed phase results. */
    @XmlElement(name = "phase_result", required = true)
    protected List<ToyotaPhase> vmedPhaseResults;

    /**
     * Getter vmedPhaseResults
     * 
     * @return the vmedPhaseResults
     */
    public List<ToyotaPhase> getVmedPhaseResults() {
        return vmedPhaseResults;
    }

    /**
     * Setter vmedPhaseResults
     * 
     * @param vmedPhaseResults the vmedPhaseResults to set
     */
    public void setVmedPhaseResults(List<ToyotaPhase> vmedPhaseResults) {
        this.vmedPhaseResults = vmedPhaseResults;
    }

}
