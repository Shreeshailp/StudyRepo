/*
 * Creation : 6 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.aogeos.request;

/**
 * The Class AoGeosRequestErrorCode.
 */
public final class AoCronoRequestErrorCode {

    /** The Constant VERSION_16C_INCORRECT. */
    public static final String VERSION_16C_INCORRECT = "ERRW601:Version 16C missing or incorrect, lineNumber ({}),Version ({}) ";

    /** The Constant COLOR_EXT_INT_INCORRECT. */
    public static final String COLOR_EXT_INT_INCORRECT = "ERRW602:Color exterior and interior missing or incorrect";

    /** The Constant PRD_CODE_INCORRECT. */
    public static final String PRD_CODE_INCORRECT = "PRD unknown lineNumber ({}),Prd ({})";

    /** The Constant NB_OPTIONS_INCORRECT. */
    public static final String NB_OPTIONS_INCORRECT = "ERRW603:nbOptions incorrect";

    /** The Constant LOTNUMBER_INCORRECT. */
    public static final String LOTNUMBER_INCORRECT = "lot number missing or incorrect : linelineNumber({}) ,lotNumber({}) ";

    /** The Constant LINENUMBER_INCORRECT. */
    public static final String LINENUMBER_INCORRECT = "line number missing or incorrect :lineNumber ({}), LineNumber  ({}) ";

    /** The Constant OPTIONS_5C_INCORRECT. */
    public static final String OPTIONS_5C_INCORRECT = "ERRW604:Options5C incorrect ,lineNumber ({}) ,options 5c({}) ";

    /** The Constant OPTIONS_7C_INCORRECT. */
    public static final String OPTIONS_7C_INCORRECT = "ERRW605:Options7C incorrect  ,lineNumber ({}) ,options 7c({})";

    /** The Constant COUNTRY_CODE_INCORRECT. */
    public static final String COUNTRY_CODE_INCORRECT = "ERRW610:incorrect trading country  lineNumber ({}), country ({}), characteristic ({})";

    /** The Constant BRAND_INCORRECT. */
    public static final String BRAND_INCORRECT = "brand missing or incorrect : lineNumber ({}),Brand ({}) ";

    /** The Constant CHARACTER_CODE_INCORRECT. */
    public static final String CHARACTER_CODE_INCORRECT = "ERRW103:unknown request type";

    /** The Constant HABILLAGE_INT_INCORRECT. */
    public static final String HABILLAGE_INT_INCORRECT = "ERRW602 : Color exterior and interior missing or incorrect lineNumber ({}), Color exterior Int ({})";

    /** The Constant HABILLAGE_EXT_INCORRECT. */
    public static final String HABILLAGE_EXT_INCORRECT = "ERRW602 : Color exterior and interior missing or incorrect lineNumber ({}), Color exterior Ext ({}) ";

    /** The Constant GESTION_5C_INCORRECT. */
    public static final String GESTION_5C_INCORRECT = "ERRW617:Gestion5C incorrect ,lineNumber ({}) ,gestions 5c({}) ";

    /** The Constant GESTION_7C_INCORRECT. */
    public static final String GESTION_7C_INCORRECT = "ERRW618 :Gestion7C incorrect ,lineNumber ({}) ,gestion 7c({}) ";

    /** The Constant EXTENSION_DATE_INCORRECT. */
    public static final String EXTENSION_DATE_INCORRECT = "ERRW606:Incorrect extension date , lineNumber ({}), extention Date ({})";

    /** The Constant COUNTRYCODE_INCORRECT. */
    public static final String COUNTRYCODE_INCORRECT = "ERRW610:incorrect trading country  lineNumber";

    /** The Constant INCORRECT_MOMENT_CODE. */
    public static final String INCORRECT_MOMENT_CODE = "ERRW103: unknown movement code at lineNumber ({}),momentcode ({})";

    /** The Constant INCORRECT_FILE. */
    public static final String INCORRECT_FILE = "ERRW104 : Incorrect  file lineNumber ({}) ";

    /**
     * Instantiates a new ao geos request error code.
     */
    private AoCronoRequestErrorCode() {
    }

}
