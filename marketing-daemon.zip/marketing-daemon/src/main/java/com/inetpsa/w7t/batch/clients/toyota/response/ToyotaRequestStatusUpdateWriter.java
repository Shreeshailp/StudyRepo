/*
 * Creation : 24 Jul 2018
 */

package com.inetpsa.w7t.batch.clients.toyota.response;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.core.io.Resource;

import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;

/**
 * The Class ToyotaRequestStatusUpdateWriter.
 */
public class ToyotaRequestStatusUpdateWriter extends JpaItemWriter<MarketingRequestAnswerDTO> {

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service. */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */
    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The resource. */
    private Resource resource;

    /** The Constant MARKETING_ANSWER_SENT_LOG. */
    private static final String MARKETING_ANSWER_SENT_LOG = "Marketing Request=[{}], AnswerCode=[{}], AnswerDesignation=[{}]";

    /** The mrq file id. */
    private String mrqFileId = "";

    /** The extended attr. */
    private String extendedAttr = "";

    /**
     * Setter resource.
     *
     * @param resource the resource to set
     */
    public void setResource(Resource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends MarketingRequestAnswerDTO> items) {

        List<MarketingRequestDto> marketingRequestDtosList = new CopyOnWriteArrayList<>(items.get(0).getToyotaAnswerDto());
        ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = null;
        List<ToyotaLCDV> toyotaLCDVList = new ArrayList<>();
        String fileId = "";
        if (!marketingRequestDtosList.isEmpty()) {
            toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();
            fileId = marketingRequestDtosList.get(0).getFileId();
            toyotaXmlAnswerResponse.setFileId(fileId);
            toyotaXmlAnswerResponse.setRequestDate(marketingRequestDtosList.get(0).getRequestDate());
            toyotaXmlAnswerResponse.setAnswerDate(MarketingDateUtil.getTodaysDate());
        }

        marketingRequestDtosList.forEach(request -> {

            if (request.getToyotaXmlAnswerResponse() != null) {
                toyotaLCDVList.addAll(request.getToyotaXmlAnswerResponse().getToyotaLCDV());
            }

            MarketingRequest marketingRequest = marketingRequestRepository.byInternalRequestId(request.getInternalReqId());
            if (marketingRequest != null) {
                mrqFileId = marketingRequest.getFileId();
                marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequest.setAnswerSent(true);
                marketingRequest.setAnswerDate(MarketingDateUtil.getTodaysDate());
                marketingRequest.setAnswerCode(request.getAnswerCode());
                marketingRequest.setAnswerDesig(request.getAnswerDesig());
                marketingRequestRepository.saveEntity(marketingRequest);
                logger.info(MARKETING_STATUS_CHANGE_LOG, request, request.getStatus(), MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequest.getRequestID(), request.getAnswerCode(), request.getAnswerDesig());
            }
        });

        List<MarketingRequest> rejectedRequestList = marketingRequestRepository.byClientAndStatusAndFileId(
                MarketingDaemonServiceConstants.TOYOTA.toUpperCase(), String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()),
                mrqFileId);
        rejectedRequestList.forEach(marketingRequest -> {
            try {
                ToyotaXmlAnswerResponse rejectedRequest = setRejectedRequest(marketingRequest);

                if (rejectedRequest != null) {
                    toyotaLCDVList.addAll(rejectedRequest.getToyotaLCDV());
                }

                marketingRequest.setStatus(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()));
                marketingRequest.setAnswerSent(true);
                marketingRequestRepository.saveEntity(marketingRequest);
                logger.info(MARKETING_STATUS_CHANGE_LOG, marketingRequest, MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode(),
                        MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode());
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequest.getRequestID(), marketingRequest.getAnswerCode(),
                        marketingRequest.getAnswerDesig());
            } catch (Exception e) {
                logger.error("Error : {}", e);
            }
        });
        MarketingRequestTracker mrt = marketingRequestTrackerRepository.byFileId(mrqFileId);
        if (toyotaXmlAnswerResponse != null && mrt != null && toyotaLCDVList.size() == mrt.getMrqCount()) {
            toyotaXmlAnswerResponse.setToyotaLCDV(toyotaLCDVList);
            serialize(toyotaXmlAnswerResponse);
            marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                    mrqFileId);

            String fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(mrqFileId);
            if (fileConfigUtilService != null && fsFlagFileName != null) {
                // Added below code as part of jira-660 fix -- start
                MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "toyota", fsFlagFileName);
                int result = fsFlagFileService.deleteFsFlagFileByFileId(mrqFileId);
                if (result > 0) {
                    logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                }
                // jira-660 fix -- end
            }

        }

    }

    /**
     * Sets the rejected request.
     *
     * @param marketingRequest the marketing request
     * @return the toyota xml answer response
     */
    private ToyotaXmlAnswerResponse setRejectedRequest(MarketingRequest marketingRequest) {
        ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();

        ToyotaLCDV toyotaLCDV = new ToyotaLCDV();

        toyotaLCDV.setNumber(marketingRequest.getRequestID());
        toyotaLCDV.setWltpStatus(marketingRequest.getAnswerCode());
        toyotaLCDV.setWltpErrorMsg(marketingRequest.getAnswerDesig());
        // fixed jira-534
        toyotaLCDV.setLcdv24(marketingRequest.getVersion16() + marketingRequest.getColorExtInt());
        toyotaLCDV.setExtendedAttribute(extendedAttr);

        toyotaXmlAnswerResponse.setToyotaLCDV(Arrays.asList(toyotaLCDV));
        LogUtility.logTheError(logger, marketingRequest.getRequestID(), marketingRequest.getAnswerCode(), marketingRequest.getAnswerDesig());

        return toyotaXmlAnswerResponse;
    }

    /**
     * Serialize.
     *
     * @param toyotaXmlAnswerResponse the toyota xml answer response
     */
    private void serialize(ToyotaXmlAnswerResponse toyotaXmlAnswerResponse) {
        logger.debug("Entering Toyota XML File Writer Serializer... ");
        try {
            JAXBContext contextObj = JAXBContext.newInstance(ToyotaXmlAnswerResponse.class);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            StringBuilder tempFilePath = new StringBuilder(resource.getFile().getAbsolutePath());

            try (FileOutputStream fos = new FileOutputStream(new File(tempFilePath.toString()), true)) {
                marshallerObj.marshal(toyotaXmlAnswerResponse, fos);
            }
            logger.info("WLTP answer written to Toyota file [{}]", tempFilePath);
        } catch (JAXBException | IOException e) {
            logger.error("Error Marshalling {} answer: ", e);
        }
    }
}
