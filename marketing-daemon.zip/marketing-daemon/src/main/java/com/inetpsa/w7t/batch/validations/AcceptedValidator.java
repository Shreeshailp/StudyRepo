/*
 * Creation : 19 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.validations;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author E534811
 */
public class AcceptedValidator implements ConstraintValidator<AcceptedValues, String> {

    private List<String> valueList;

    @Override
    public void initialize(AcceptedValues constraintAnnotation) {
        valueList = new ArrayList<>();
        for (String val : constraintAnnotation.acceptValues()) {
            valueList.add(val.toLowerCase());
        }
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (!valueList.contains(value.toLowerCase())) {
            return false;
        }
        return true;
    }
}
