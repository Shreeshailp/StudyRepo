/*
 * Creation : 17 mars 2017
 */
package com.inetpsa.w7t.daemon.services;

import java.util.List;
import java.util.Optional;

import org.seedstack.business.Service;

import com.inetpsa.w7t.application.MarketingDaemonCommandLineHandler;
import com.inetpsa.w7t.daemon.file.services.MarketingFileListener;
import com.inetpsa.w7t.daemon.file.services.MarketingFileWriter;

/**
 * This interface is used as a singleton as the main thread manager of the
 * engine daemon. It is called from the
 * {@link MarketingDaemonCommandLineHandler} to start all the
 * {@link MarketingFileListener} threads and the
 * {@link MarketingRequestLifecycleService} thread. While starting the threads,
 * it also creates the {@link MarketingFileWriter} corresponding to each
 * {@link MarketingFileListener}.
 */
@Service
public interface MarketingDaemonService {

	/**
	 * This starts all the {@link MarketingFileListener} and
	 * {@link MarketingRequestLifecycleService} threads and creates the
	 * {@link MarketingFileWriter}.
	 */
	void run();

	/**
	 * Gets the number of running threads.
	 *
	 * @return the number of running threads
	 */
	Integer getRunningThreads();

	/**
	 * Gets the number of total threads.
	 *
	 * @return the number of total threads
	 */
	Integer getTotalThreads();

	/**
	 * Checks if the engine daemon service is running.
	 *
	 * @return the running state
	 */
	Boolean isRunning();

	/**
	 * Retrieve the list of created client writers.
	 *
	 * @return the client writers
	 */
	List<MarketingFileWriter> getClientWriters();

	/**
	 * Retrieve a client writer by its name.
	 *
	 * @param name
	 *            the name
	 * @return the client writer
	 */
	Optional<MarketingFileWriter> getClientWriter(String name);

	List<MarketingFileWriter> getProviderWriters();

	Optional<MarketingFileWriter> getProviderWriter(String name);

}
