/*
 * Creation : 19 Oct 2018
 */
package com.inetpsa.w7t.batch.clients.cronos.response;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.ListUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.common.CalculationStatusDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeUtility;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.MarketingDaemonServiceUtils;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository;

/**
 * The Class AoGeosFlatFileWriter.
 */
public class CronosFlatFileWriter implements ItemWriter<MarketingRequestAnswerDTO> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The MarketingDaemonCalculatorService. */
    @Inject
    private MarketingDaemonCalculatorService marketingDaemonCalculatorService;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "cronosDatabaseToFlatFileJob";

    /** The total record count. */
    private volatile int totalRecordCount = 0;

    /** The record count. */
    private int recordCount = 0;

    /** The final list to write in file. */
    private CopyOnWriteArrayList<AoCronosEliadeDto> finalListToWriteInFile = new CopyOnWriteArrayList<>();

    private CopyOnWriteArrayList<MarketingRequest> finalListToUpdateStatusInMRQ = new CopyOnWriteArrayList<>();

    // fix for big file issue
    /** The final list to update calculation status. */
    private CopyOnWriteArrayList<CalculationStatusDto> finalListToUpdateCalculationStatus = new CopyOnWriteArrayList<>();

    /** The records list. */
    private List<String> recordsList = new ArrayList<>();

    /** The number of movements. */
    private String NUMBER_OF_MOVEMENTS = "00000000"; // 8 char

    /** The resource. */
    private CronosFlatFileResource resource;

    /** The chunk size. */
    private int chunkSize = 500;

    @Inject
    private AvoidCacheRepository avoidCacheRepository;

    /** The thread pool log. */
    private static final String THREAD_POOL_LOG = "cronosDatabaseToFlatFileJob thread pool size : [{}]";

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public CronosFlatFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(CronosFlatFileResource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends MarketingRequestAnswerDTO> request) throws Exception {
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
        logger.debug(THREAD_POOL_LOG, threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        totalRecordCount = 0;
        recordCount = 0;
        int originalListCount = 0;
        String fsFlagFileName = null;
        boolean avoidCacheValue;
        AoCronosEliadeDto cronosHeaderFooterDto = null;
        List<AoCronosEliadeDto> cronosList = new CopyOnWriteArrayList<>(request.get(0).getAoCronoEliadeAnswerDto());
        if (!cronosList.isEmpty()) {
            List<AoCronosEliadeDto> cronosNewList = MarkertingDaemonUtility.getUniqueAoCronoEliadeList(cronosList);
            cronosHeaderFooterDto = cronosNewList.get(0);
            originalListCount = cronosNewList.size();
            logger.info("Total request count for calculation for the FILE ID [{}] is : [{}]", cronosNewList.get(0).getFileId(), originalListCount);
            avoidCacheValue = avoidCacheRepository.getAdcValueByClient(MarketingDaemonServiceConstants.CRONOS.toUpperCase());
            try {
                logger.info("Parallel Processing Starts Here ...");
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<AoCronosEliadeDto>> splitedList = ListUtils.partition(cronosNewList, chunkSize);

                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelList(list, avoidCacheValue));
                        futuresList.add(future);
                    });
                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }

            } catch (Exception e) {
                logger.error("Error when executing parallel request processing for calcualtion", e);
            } finally {
                executorService.shutdown();
            }

            logger.info("Parallel Processing Ends Here ...");

            if (!finalListToWriteInFile.isEmpty()) {
                try {
                    logger.info("Calculated records count for the FILE ID [{}] is : [{}] and original count is : [{}]",
                            cronosNewList.get(0).getFileId(), totalRecordCount, originalListCount);
                    recordsList.add(writeToHeader(cronosHeaderFooterDto));
                    writeRecordsIntoFile(request.get(0).getAoCronoEliadeAnswerDto().get(0));
                    recordsList.add(writeToFooter(recordCount, cronosHeaderFooterDto));
                    MarketingRequestTracker mrt = marketingRequestTrackerRepository.byFileId(cronosList.get(0).getFileId());
                    if (!recordsList.isEmpty() && null != mrt && recordsList.size() - 2 == mrt.getMrqCount()) {
                        File sourceFile = new File(getResource().getFile().getAbsolutePath());
                        Path newFile = Paths.get(sourceFile.getAbsolutePath());

                        // added below method to fix big file issue
                        updateCalculationStatusInMRQ();

                        MarkertingDaemonUtility.writeIntoFile(sourceFile, recordsList);

                        updateFinalStatusInMRQ();
                        logger.info("Records written in the file for the FILE ID [{}] is : [{}]", cronosNewList.get(0).getFileId(), recordCount);
                        logger.info("Removing the .part ");
                        int lastIndex = sourceFile.getName().lastIndexOf('.');
                        String newFileName = sourceFile.getName().substring(0, lastIndex);

                        Files.move(newFile, newFile.resolveSibling(newFileName));
                        marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                                String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                                request.get(0).getAoCronoEliadeAnswerDto().get(0).getFileId());

                        List<String> fileIds = marketingRequestTrackerRepository.get3DaysAnswerSentFileIds();
                        fileIds.forEach(fileId -> MarketingDaemonServiceUtils.resetCronosHeader(fileId));

                        fsFlagFileName = fsFlagFileService.getFsFlagFileNameByFileId(cronosNewList.get(0).getFileId());
                        logger.info("FsFlagFileName: [{}]", fsFlagFileName);
                        if (fileConfigUtilService != null && fsFlagFileName != null) {
                            // Added below code as part of jira-660 fix -- start
                            MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "cronos", fsFlagFileName);
                            int result = fsFlagFileService.deleteFsFlagFileByFileId(cronosNewList.get(0).getFileId());
                            if (result > 0) {
                                logger.info("FsFlagFileName: [{}] deleted from database table ", fsFlagFileName);
                            }
                            // jira-660 fix -- end
                        }
                    }
                } catch (Exception e) {
                    logger.error("{} ", e);
                }

            } else {
                logger.info("Final List To Write In File is empty for FILE ID [{}]", cronosHeaderFooterDto.getFileId());
            }
        }
    }

    /**
     * Update calculation status in MRQ.
     */
    private void updateCalculationStatusInMRQ() {
        if (!finalListToUpdateCalculationStatus.isEmpty()) {
            Set<CalculationStatusDto> set = new HashSet<>(finalListToUpdateCalculationStatus);
            finalListToUpdateCalculationStatus.clear();
            finalListToUpdateCalculationStatus.addAll(set);
            int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
            logger.debug(THREAD_POOL_LOG, threadPoolSize);
            ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
            try {
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<CalculationStatusDto>> splitedList = ListUtils.partition(finalListToUpdateCalculationStatus, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateCalculationStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            } finally {
                executorService.shutdown();
            }

        }

    }

    /**
     * Process parallel list to update calculation status.
     *
     * @param marketingRequestList the marketing request list
     * @return the int
     */
    private int processParallelListToUpdateCalculationStatus(List<CalculationStatusDto> marketingRequestList) {
        marketingDaemonCalculatorService.updateStatusCalculationStatusInMRQ(marketingRequestList);
        return 1;
    }

    /**
     * Update final status in MRQ.
     */
    private void updateFinalStatusInMRQ() {

        if (!finalListToUpdateStatusInMRQ.isEmpty()) {
            try {
                int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
                logger.debug(THREAD_POOL_LOG, threadPoolSize);
                ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<MarketingRequest>> splitedList = ListUtils.partition(finalListToUpdateStatusInMRQ, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
                executorService.shutdown();
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            }

        }

    }

    private int processParallelListToUpdateStatus(List<MarketingRequest> marketingRequestList) {
        marketingDaemonCalculatorService.updateAnswerSentStatus(marketingRequestList);
        return 1;
    }

    /**
     * Process parallel list.
     *
     * @param list the list
     * @return the int
     */
    private int processParallelList(List<AoCronosEliadeDto> list, boolean adcValue) {
        AoCronosEliadeDto dto = null;
        for (AoCronosEliadeDto aoCronosEliadeDto : list) {
            aoCronosEliadeDto.setAvoidCache(adcValue);
            dto = process(aoCronosEliadeDto);
            if (dto != null) {
                AoCronosEliadeDto cronosDto = dto;
                if (cronosDto != null && (cronosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()))
                        || cronosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode())))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(cronosDto.getFileId());
                    calculationStatusDto.setRequestId(cronosDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()));
                    calculationStatusDto.setAnswerDate(cronosDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(cronosDto.getAnswerCode());
                    calculationStatusDto.setAnswerDesignation(cronosDto.getAnswerDesignation());
                    cronosDto.setStatus(calculationStatusDto.getCurrentStatus());
                    cronosDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    cronosDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    cronosDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);
                } else if (cronosDto != null
                        && cronosDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()))) {
                    CalculationStatusDto calculationStatusDto = new CalculationStatusDto();
                    calculationStatusDto.setFileId(cronosDto.getFileId());
                    calculationStatusDto.setRequestId(cronosDto.getRequestId());
                    calculationStatusDto.setPreviousStatus(String.valueOf(MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode()));
                    calculationStatusDto.setCurrentStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));
                    calculationStatusDto.setAnswerDate(cronosDto.getAnswerDate());
                    calculationStatusDto.setAnswerCode(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_AOGEOS_CRONOS_ELIADE);
                    calculationStatusDto.setAnswerDesignation(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
                    calculationStatusDto.setAnswerDate(MarketingDateUtil.getTodaysDate());
                    finalListToUpdateCalculationStatus.add(calculationStatusDto);

                    cronosDto.setStatus(calculationStatusDto.getCurrentStatus());
                    cronosDto.setAnswerCode(calculationStatusDto.getAnswerCode());
                    cronosDto.setAnswerDesignation(calculationStatusDto.getAnswerDesignation());
                    cronosDto.setAnswerDate(calculationStatusDto.getAnswerDate());
                }

                finalListToWriteInFile.add(cronosDto);
                totalRecordCount++;
            }
        }
        // wltp hub changes -> removed calculation status update part to resolve big file issue

        return 1;
    }

    private AoCronosEliadeDto process(AoCronosEliadeDto aoCronosEliadeDto) {
        AoCronosEliadeDto dto = null;
        try {
            dto = marketingDaemonCalculatorService.calculateAoGeosCronosEliade(aoCronosEliadeDto);
        } catch (Exception e) {
            logger.error("{}", e);
        }

        return dto;
    }

    /**
     * Write to header.
     *
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToHeader(AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        return AoCronoEliadeUtility.generateHeader(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), aoCronosEliadeDto.getLotDate());
    }

    /**
     * Write to footer.
     *
     * @param count the count
     * @param aoCronosEliadeDto the ao cronos eliade dto
     * @return the string
     */
    public String writeToFooter(int count, AoCronosEliadeDto aoCronosEliadeDto) {
        if (aoCronosEliadeDto == null) {
            return "";

        }
        String result = generateMovementCount(NUMBER_OF_MOVEMENTS, count);
        return AoCronoEliadeUtility.generateFooter(aoCronosEliadeDto.getSendingSite(), aoCronosEliadeDto.getSendingApplication(),
                aoCronosEliadeDto.getHeaderLotNumber(), result);
    }

    /**
     * Generate movement count.
     *
     * @param NUMBER_OF_MOVEMENTS the number of movements
     * @param count the count
     * @return the string
     */
    private String generateMovementCount(String NUMBER_OF_MOVEMENTS, int count) {
        if (NUMBER_OF_MOVEMENTS.length() >= Integer.toString(count).length()) {

            String movementCount = NUMBER_OF_MOVEMENTS.substring(0, NUMBER_OF_MOVEMENTS.length() - (Integer.toString(count).length()));

            return movementCount + count;
        }
        return NUMBER_OF_MOVEMENTS;
    }

    /**
     * Write records into file.
     *
     * @param cronoDto the crono dto
     */
    private void writeRecordsIntoFile(AoCronosEliadeDto cronoDto) {

        List<AoCronosEliadeDto> rejectedRequestList = MarkertingDaemonUtility.getRejectedRequestList(marketingRequestRepository,
                MarketingDaemonServiceConstants.CRONOS.toUpperCase(), String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()),
                false, cronoDto.getFileId());
        if (rejectedRequestList != null && !rejectedRequestList.isEmpty()) {
            finalListToWriteInFile.addAll(rejectedRequestList);
        }

        List<AoCronosEliadeDto> sortedList = finalListToWriteInFile.stream().sorted(Comparator.comparing(AoCronosEliadeDto::getRequestId))
                .collect(Collectors.toList());

        sortedList.stream().forEach(cronosDto -> {

            if (!cronosDto.getAnswerCode().isEmpty() && (cronosDto.getAnswerCode().contains("ERR") || !cronosDto.getAnswerCode().startsWith("OK"))) {
                cronosDto.setVehicleType("");
                cronosDto.setValidityDate("");
            }

            try {
                recordsList.add(cronosDto.toString());
                recordCount++;
                MarketingRequest marketingRequest = new MarketingRequest();
                marketingRequest.setRequestID(cronosDto.getRequestId());
                marketingRequest.setInternalReqId(cronosDto.getInternalRequestId());
                marketingRequest.setFileId(cronosDto.getFileId());
                finalListToUpdateStatusInMRQ.add(marketingRequest);
                marketingRequest = null;
            } catch (Exception e) {
                logger.error("{}", e);
            }
        });
    }
}