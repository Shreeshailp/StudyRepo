/*
 * Creation : 7 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.infrastructure;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.seedstack.business.domain.GenericRepository;

import com.inetpsa.w7t.domain.model.MarketingRequestTracker;

/**
 * The Interface MarketingRequestTrackerRepository.
 *
 * @author E534811
 */
public interface MarketingRequestTrackerRepository extends GenericRepository<MarketingRequestTracker, String> {

    /**
     * Save entity.
     *
     * @param marketingRequestTracker the marketing request tracker
     */
    void saveEntity(MarketingRequestTracker marketingRequestTracker);

    /**
     * Update entity.
     *
     * @param marketingRequestTracker the marketing request tracker
     */
    void updateEntity(MarketingRequestTracker marketingRequestTracker);

    /**
     * Update answer sent status by file id.
     *
     * @param answerGeneratedStatus the answer generated status
     * @param requestId the request id
     * @return the int
     */
    int updateAnswerSentStatusByFileId(String answerGeneratedStatus, String requestId);

    /**
     * Update MR T valid req count.
     *
     * @param fileId the file id
     * @param count the count
     * @return the int
     */
    int updateMRT_ValidReq_Count(String fileId, int count);

    /**
     * Update to machine name MRT.
     *
     * @param finalFileIds the final file ids
     * @param bcvResMacName the bcv res mac name
     * @return the int
     */
    int updateToMachineName_MRT(Set<String> finalFileIds, String bcvResMacName);

    /**
     * By file id.
     *
     * @param fileId the file id
     * @return the marketing request tracker
     */
    MarketingRequestTracker byFileId(String fileId);

    /**
     * Bytoday last request on machine.
     *
     * @param string the string
     * @param upperCase the upper case
     * @param reqMachine the req machine
     * @return the optional
     */
    Optional<MarketingRequestTracker> bytodayLastRequestOnMachine(String string, String upperCase, String reqMachine);

    /**
     * Gets the 3 days answer sent file ids.
     *
     * @return the 3 days answer sent file ids
     */
    List<String> get3DaysAnswerSentFileIds();

    /**
     * Gets the toyota original file id.
     *
     * @param fileId the file id
     * @return the toyota original file id
     */
    String getToyotaOriginalFileId(String fileId);
}
