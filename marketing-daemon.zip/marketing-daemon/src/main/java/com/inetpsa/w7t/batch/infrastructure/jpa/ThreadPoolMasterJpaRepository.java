/*
 * Creation : 2 Aug 2019
 */
package com.inetpsa.w7t.batch.infrastructure.jpa;

import java.time.LocalDate;
import java.util.UUID;

import javax.persistence.Query;

import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.domain.model.ThreadPoolMaster;

/**
 * The Class ThreadPoolMasterJpaRepository.
 */
@Transactional
@JpaUnit("wltp-domain-jpa-unit")
public class ThreadPoolMasterJpaRepository extends BaseJpaRepository<ThreadPoolMaster, String> implements ThreadPoolMasterRepository {

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository#getThreadPoolSize(java.lang.String)
     */
    @Override
    public int getThreadPoolSize(String jobName) {

        String sqlQuery = "SELECT THREAD_POOL_SIZE FROM W7TQTTPM WHERE JOB_NAME=?";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, jobName);
        return q.getResultList().isEmpty() ? 1 : Integer.valueOf(q.getResultList().get(0).toString());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository#getLastRequestNumber(java.lang.String, java.lang.String)
     */
    @Override
    public long getLastRequestNumber(String client, String reqMachine, String fileId) {
        String sqlQuery = "SELECT SEQUENCE FROM W7TQTMRS WHERE DATE LIKE ? AND CLIENT=? AND REQ_MAC_NAME=? AND FILE_ID = ? ORDER BY DATE DESC LIMIT 1";
        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, "%" + LocalDate.now().toString() + "%");
        q.setParameter(2, client);
        q.setParameter(3, reqMachine);
        q.setParameter(4, fileId);
        return q.getResultList().isEmpty() ? 0 : (int) q.getResultList().get(0);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository#updateMRS(java.lang.String, long, java.lang.String)
     */
    @Override
    public void updateMRS(String client, long prevReqNumber, String reqMachine, String fileId) {
        Query q = entityManager.createNativeQuery(
                "UPDATE W7TQTMRS SET SEQUENCE = ? WHERE DATE LIKE ? AND CLIENT=? AND REQ_MAC_NAME=? AND FILE_ID = ? ORDER BY DATE DESC LIMIT 1");
        q.setParameter(1, prevReqNumber);
        q.setParameter(2, "%" + LocalDate.now().toString() + "%");
        q.setParameter(3, client);
        q.setParameter(4, reqMachine);
        q.setParameter(5, fileId);
        q.executeUpdate();

    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository#createMRS(java.lang.String, long, java.lang.String)
     */
    @Override
    public void createMRS(String client, long reqCount, String reqMachine, String fileId) {
        Query q = entityManager.createNativeQuery("INSERT INTO W7TQTMRS VALUES (?, ?, ?, ?, ?, ?, ?)");
        q.setParameter(1, UUID.randomUUID().toString());
        q.setParameter(2, client);
        q.setParameter(3, LocalDate.now().toString());
        q.setParameter(4, reqMachine);
        q.setParameter(5, reqCount);
        q.setParameter(6, fileId);
        q.setParameter(7, MarketingDateUtil.getTodaysDate());
        q.executeUpdate();
    }

}
