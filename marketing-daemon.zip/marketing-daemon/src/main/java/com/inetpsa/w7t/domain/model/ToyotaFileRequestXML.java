/*
 * Creation : 10 Jul 2018
 */
package com.inetpsa.w7t.domain.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Mktg")
@XmlType(name = "", propOrder = { "fileId", "requestDate" })
public class ToyotaFileRequestXML {

    @XmlElement(name = "file_id", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String fileId;
    @XmlElement(name = "request_date", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NMTOKEN")
    protected String requestDate;

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String value) {
        this.fileId = value;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String value) {
        this.requestDate = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ToyotaFileRequestXML [fileId=" + fileId + ", requestDate=" + requestDate + "]";
    }

}
