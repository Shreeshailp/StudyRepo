/*
 * Creation : 22 mars 2017
 */
package com.inetpsa.w7t.batch.shared;

import java.util.stream.Stream;

/**
 * The Enum RequestStatus.
 */
public enum MarketingRequestStatusEnum {

    /** The request received. */
    REQUEST_RECEIVED(10),
    /** The valid request. */
    VALID_REQUEST(20),

    /** The request rejected. */
    REQUEST_REJECTED(60), CALCULATION_KO(62), CALCULATION_OK(70),

    /** The answer sent. */
    ANSWER_SENT(80);

    /** The status code. */
    private int statusCode;

    /**
     * Instantiates a new request status.
     *
     * @param statusCode the status code
     */
    MarketingRequestStatusEnum(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Returns a RequestStatus corresponding to the specified status code, or else null.
     *
     * @param statusCode the status code
     * @return the request status
     */
    public static MarketingRequestStatusEnum of(int statusCode) {
        return Stream.of(MarketingRequestStatusEnum.values()).filter(s -> s.statusCode == statusCode).findFirst().orElse(null);
    }

    /**
     * Gets the status code.
     *
     * @return the status code
     */
    public int getStatusCode() {
        return this.statusCode;
    }

    /**
     * Checks if is final status.
     *
     * @return true, if is final status
     */
    public boolean isFinalStatus() {
        return this.equals(MarketingRequestStatusEnum.ANSWER_SENT);
    }

}
