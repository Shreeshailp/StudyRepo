/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

/**
 * The Class CfgMot2JsonPhysicalResult.
 */
public class CfgMot2JsonPhysicalResult {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CfgMot2JsonPhysicalResult [code=" + code + ", value=" + value + "]";
    }

}
