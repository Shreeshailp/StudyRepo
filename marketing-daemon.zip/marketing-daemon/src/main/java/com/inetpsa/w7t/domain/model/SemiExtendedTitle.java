/**
 * 
 */
package com.inetpsa.w7t.domain.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.domain.identity.UUIDHandler;

/**
 * @author E534811
 */
@Entity
@Table(name = "W7TQT_SemiExtendedTitle")
public class SemiExtendedTitle extends BaseAggregateRoot<UUID> {

    /** The guid. */
    @Identity(handler = UUIDHandler.class)
    @Id
    @Type(type = "uuid-char")
    @Column(name = "ID")
    private UUID guid;

    @Column(name = "Version16")
    private String Version16;

    @Column(name = "colorExtInt")
    private String colorExtInt;

    @Column(name = "optionsAttributes")
    private String optionsAttributes;

    @Column(name = "gestionAttributes")
    private String gestionAttributes;

    @Column(name = "extensionDate")
    private String extensionDate;

    @Column(name = "destinationCode")
    private String destinationCode;

    public String getVersion16() {
        return Version16;
    }

    public void setVersion16(String version16) {
        Version16 = version16;
    }

    public String getColorExtInt() {
        return colorExtInt;
    }

    public void setColorExtInt(String colorExtInt) {
        this.colorExtInt = colorExtInt;
    }

    public String getOptionsAttributes() {
        return optionsAttributes;
    }

    public void setOptionsAttributes(String optionsAttributes) {
        this.optionsAttributes = optionsAttributes;
    }

    public String getGestionAttributes() {
        return gestionAttributes;
    }

    public void setGestionAttributes(String gestionAttributes) {
        this.gestionAttributes = gestionAttributes;
    }

    public String getExtensionDate() {
        return extensionDate;
    }

    public void setExtensionDate(String extensionDate) {
        this.extensionDate = extensionDate;
    }

    public String getDestinationCode() {
        return destinationCode;
    }

    public void setDestinationCode(String destinationCode) {
        this.destinationCode = destinationCode;
    }

    @Override
    public UUID getEntityId() {
        return this.guid;
    }

}
