package com.inetpsa.w7t.application;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.seedstack.seed.Logging;
import org.seedstack.seed.cli.CliCommand;
import org.seedstack.seed.cli.CommandLineHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.inetpsa.w7t.daemon.services.MarketingDaemonService;

/**
 * The Class MarketingDaemonCommandLineHandler.
 */
@CliCommand("wltp-marketing-daemon")
public class MarketingDaemonCommandLineHandler implements CommandLineHandler {

    @Logging
    private Logger logger;

    @Inject
    private MarketingDaemonService marketingDaemonService;

    private static Boolean sigintRequested = false;

    public static Boolean isSigintRequested() {
        return sigintRequested;
    }

    private static void setSigintRequested(Boolean state) {
        sigintRequested = state;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.util.concurrent.Callable#call()
     */
    @Override
    public Integer call() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                Logger log = LoggerFactory.getLogger(this.getClass());
                log.info("Marketing Daemon shutdown requested, stopping file listeners and lifecycle service...");
                setSigintRequested(true);

                Integer running;
                while ((running = marketingDaemonService.getRunningThreads()) != 0) {
                    try {
                        log.info("Waiting for application to shutdown... {}/{} workers remaining", running, marketingDaemonService.getTotalThreads());
                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException e) {
                        log.error("Error ocurred during application shutdown", e);
                        Thread.currentThread().interrupt();
                    }
                }
                log.info("Application shutdown successful");
            }
        });

        marketingDaemonService.run();

        while (marketingDaemonService.isRunning()) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                logger.error("Marketing daemon command line handler interrupted !", e);
                Thread.currentThread().interrupt();
            }
        }

        return 0;
    }
}
