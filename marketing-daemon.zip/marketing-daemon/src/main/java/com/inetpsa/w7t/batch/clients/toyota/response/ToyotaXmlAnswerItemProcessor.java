/*
 * Creation : 3 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.toyota.response;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.FluentAssembler;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.SeedException;
import org.seedstack.shed.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.shared.AoCronoEliadeCalculationConstants;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDaemonWltpHubService;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.daemon.services.ToyotaFamilyDetailsService;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestTrackerDTO;
import com.inetpsa.w7t.domains.depol.model.Depol;
import com.inetpsa.w7t.domains.depols.infrastructure.persistence.depol.jpa.DepolRepository;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyDetailsRepository;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.AvoidCacheRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CyclePhaseRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.TestVehicleTypeRepository;
import com.inetpsa.w7t.domains.tvvs.infrastructure.persistence.tvv.TVVRepository;
import com.inetpsa.w7t.domains.tvvs.model.tvv.TVV;
import com.inetpsa.w7t.wltphub.ws.WSPhase;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class ToyotaXmlAnswerItemProcessor.
 */
public class ToyotaXmlAnswerItemProcessor implements ItemProcessor<MarketingRequestTrackerDTO, MarketingRequestAnswerDTO> {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;

    @Inject
    FamilyDetailsRepository familyDetailsRepository;

    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The physical quantity type repository. */
    @Inject
    private PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /** The toyota out dir. */
    @Configuration("marketingDaemon.providers.toyota.outputDirectory")
    private File toyotaOutDir;

    /** The fluent assembler. */
    @Inject
    FluentAssembler fluentAssembler;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The depol repository. */
    @Inject
    private DepolRepository depolRepository;

    /** The marketing daemon wltp hub service. */
    @Inject
    private MarketingDaemonWltpHubService marketingDaemonWltpHubService;

    /** The tvv repository. */
    @Inject
    private TVVRepository tvvRepository;

    /** The avoid cache repository. */
    @Inject
    private AvoidCacheRepository avoidCacheRepository;

    /** The test vehicle type repository. */
    @Inject
    private TestVehicleTypeRepository testVehicleTypeRepository;

    /** The cycle phase repository. */
    @Inject
    private CyclePhaseRepository cyclePhaseRepository;

    /** The toyota family details service. */
    @Inject
    private ToyotaFamilyDetailsService toyotaFamilyDetailsService;

    /** The Constant MARKETING_STATUS_CHANGE_LOG. */
    private static final String MARKETING_STATUS_CHANGE_LOG = "Marketing Request=[{}], Old status=[{}], New status=[{}]";

    /** The Constant MARKETING_ANSWER_SENT_LOG. */
    private static final String MARKETING_ANSWER_SENT_LOG = "Marketing Request=[{}], AnswerCode=[{}], AnswerDesignation=[{}]";

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public MarketingRequestAnswerDTO process(MarketingRequestTrackerDTO marketingRequestTrackerDTO) throws Exception {

        List<MarketingRequest> allMarketingRequestList = MarkertingDaemonUtility.getMarketingRequestByChunk(marketingRequestTrackerDTO,
                marketingRequestRepository);
        logger.info("The total request count for calculation is : {}", allMarketingRequestList.size());
        List<MarketingRequestDto> toyotaDtoList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(allMarketingRequestList) && allMarketingRequestList.size() == marketingRequestTrackerDTO.getValidReqCount()) {
            boolean avoidCacheValue = avoidCacheRepository.getAdcValueByClient(MarketingDaemonServiceConstants.TOYOTA.toUpperCase());
            logger.info("The Avoid Cache value for toyota : {}", avoidCacheValue);
            toyotaDtoList = allMarketingRequestList.stream().map(this::convertToMarketingRequestDto).collect(Collectors.toList());
            toyotaDtoList.stream().forEach(toyotaDto -> {
                try {
                    processRequest(toyotaDto, avoidCacheValue);
                } catch (Exception e) {
                    logger.error("Exception : {}", e);
                }
            });

        } else
            logger.info("Request list is empty");

        MarketingRequestAnswerDTO marketingRequestAnswerDTO = new MarketingRequestAnswerDTO();
        marketingRequestAnswerDTO.setToyotaAnswerDto(toyotaDtoList);

        return marketingRequestAnswerDTO;
    }

    /**
     * Convert to marketing request dto.
     *
     * @param request the request
     * @return the marketing request dto
     */
    private MarketingRequestDto convertToMarketingRequestDto(MarketingRequest request) {
        MarketingRequestDto dto = new MarketingRequestDto();
        dto.setVersion16(request.getVersion16());
        dto.setColorExtInt(request.getColorExtInt());
        dto.setExtensionDate(request.getExtensionDate());
        dto.setRequestDate(request.getRequestDate());
        dto.setRequestID(request.getRequestID());
        dto.setRequestType(request.getRequestType());
        dto.setFileId(request.getFileId());
        dto.setInternalReqId(request.getInternalReqId());
        dto.setTradingCountry(request.getTradingCountry());
        dto.setOptions(request.getOptions());
        dto.setOptions5C(request.getOptions5C());
        dto.setStatus(request.getStatus());
        return dto;

    }

    /**
     * Process request.
     *
     * @param marketingRequestDto the marketing request dto
     * @param avoidCacheValue
     * @return the bcv newton request dto
     * @throws Exception the exception
     */
    public MarketingRequestDto processRequest(MarketingRequestDto marketingRequestDto, boolean avoidCacheValue) throws Exception {
        logger.info("REQUEST_ID =[{}] - RequestType : {} ", marketingRequestDto.getRequestID(), marketingRequestDto.getRequestType());
        WltpHubResponseRepresentation wltpHubResponseRepresentation = null;
        // Added below 2 lines as part of the JIRA-528 FIX
        String toyotaOriginalFileId = marketingRequestTrackerRepository.getToyotaOriginalFileId(marketingRequestDto.getFileId());
        marketingRequestDto.setFileId(toyotaOriginalFileId);
        AoCronosEliadeDto aoGeosDto = new AoCronosEliadeDto();
        try {
            if (aoGeosDto.getEcomDate() == null || aoGeosDto.getEcomDate().isEmpty())
                aoGeosDto.setEcomDate(LocalDate.now().toString());
            if (StringUtils.isNotBlank(marketingRequestDto.getRequestID())) {
                aoGeosDto.setRequestId(marketingRequestDto.getRequestID());
            }
            aoGeosDto.setVersion16(marketingRequestDto.getVersion16());
            aoGeosDto.setColorExtInt(marketingRequestDto.getColorExtInt());
            aoGeosDto.setTradingCountry(marketingRequestDto.getTradingCountry());
            aoGeosDto.setRequestType(marketingRequestDto.getRequestType());
            aoGeosDto.setAvoidCache(avoidCacheValue);
            aoGeosDto.setOptions(marketingRequestDto.getOptions());
            aoGeosDto.setOptions5C(marketingRequestDto.getOptions5C());
            StopWatch sw = new StopWatch();
            sw.start();
            wltpHubResponseRepresentation = marketingDaemonWltpHubService.callWltpHubWebService(aoGeosDto);
            sw.stop();
            logger.info("RequestID [{}] Time took to call WLTP HUB web service {}ms", aoGeosDto.getRequestId(), sw.getTime());
        } catch (SeedException se) {

            String ruleCode = "";
            String errordescription = "";
            ErrorCode errorCode = se.getErrorCode();
            if (errorCode instanceof WltpErrorCode) {
                WltpErrorCode wltpErrorCode = (WltpErrorCode) errorCode;
                ruleCode = "ERRW" + wltpErrorCode.getRuleCode();
                errordescription = wltpErrorCode.getDescription();
            } else if (errorCode instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode engineCalculatorErrorCode = (WltpEngineCalculatorErrorCode) errorCode;
                ruleCode = "ERRW" + engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            } else if (errorCode instanceof RequestErrorCode) {
                RequestErrorCode engineCalculatorErrorCode = (RequestErrorCode) errorCode;
                ruleCode = engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            }
            // fixed jira-558
            LogUtility.logTheError(logger, marketingRequestDto.getRequestID(), ruleCode, errordescription);

            marketingRequestDto.setAnswerCode(ruleCode);
            marketingRequestDto.setAnswerDesig(errordescription);

            marketingRequestDto.setToyotaXmlAnswerResponse(
                    buildAnswerObjectForError(marketingRequestDto, ruleCode, errordescription, wltpHubResponseRepresentation));
        }
        if (null != wltpHubResponseRepresentation) {
            if (null != wltpHubResponseRepresentation.getAnswer() && StringUtils.isNoneBlank(wltpHubResponseRepresentation.getAnswer().getCode())
                    && !wltpHubResponseRepresentation.getAnswer().getCode().startsWith("OK")) {
                logger.info(MARKETING_STATUS_CHANGE_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getStatus(),
                        MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode());
                marketingRequestDto.setToyotaXmlAnswerResponse(
                        buildAnswerObjectForError(marketingRequestDto, wltpHubResponseRepresentation.getAnswer().getCode(),
                                wltpHubResponseRepresentation.getAnswer().getDesignation(), wltpHubResponseRepresentation));
                marketingRequestDto.setAnswerCode(wltpHubResponseRepresentation.getAnswer().getCode());
                marketingRequestDto.setAnswerDesig(wltpHubResponseRepresentation.getAnswer().getDesignation());
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getAnswerCode(),
                        marketingRequestDto.getAnswerDesig());

            } else if (null != wltpHubResponseRepresentation.getAnswer()
                    && StringUtils.isNoneBlank(wltpHubResponseRepresentation.getAnswer().getCode())
                    && (wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW700")
                            || wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW701")
                            || wltpHubResponseRepresentation.getAnswer().getCode().equals("ERRW702"))) {
                logger.info(MARKETING_STATUS_CHANGE_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getStatus(),
                        MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode());
                marketingRequestDto.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                marketingRequestDto.setToyotaXmlAnswerResponse(
                        buildAnswerObjectForError(marketingRequestDto, wltpHubResponseRepresentation.getAnswer().getCode(),
                                wltpHubResponseRepresentation.getAnswer().getDesignation(), wltpHubResponseRepresentation));
                marketingRequestDto.setAnswerCode(wltpHubResponseRepresentation.getAnswer().getCode());
                marketingRequestDto.setAnswerDesig(wltpHubResponseRepresentation.getAnswer().getDesignation());
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getAnswerCode(),
                        marketingRequestDto.getAnswerDesig());

            }

            else {
                marketingRequestDto.setToyotaXmlAnswerResponse(buildAnswerObject(marketingRequestDto, wltpHubResponseRepresentation));
                marketingRequestDto.setAnswerCode(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_TOYOTA);
                marketingRequestDto.setAnswerDesig(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
                logger.info(MARKETING_STATUS_CHANGE_LOG, marketingRequestDto.getRequestID(), MarketingRequestStatusEnum.VALID_REQUEST.getStatusCode(),
                        marketingRequestDto.getStatus());
                logger.info(MARKETING_ANSWER_SENT_LOG, marketingRequestDto.getRequestID(), marketingRequestDto.getAnswerCode(),
                        marketingRequestDto.getAnswerDesig());
            }
        }

        return marketingRequestDto;
    }

    /**
     * Builds the answer object for error.
     *
     * @param marketingRequestAnswerDto the marketing request answer dto
     * @param errorCode the error code
     * @param description the description
     * @param wltpHubResponseRepresentation the wltp hub response representation
     * @return the toyota xml answer response
     * @throws ParseException the parse exception
     */
    private ToyotaXmlAnswerResponse buildAnswerObjectForError(MarketingRequestDto marketingRequestAnswerDto, String errorCode, String description,
            WltpHubResponseRepresentation wltpHubResponseRepresentation) throws ParseException {
        if (StringUtils.isNotBlank(marketingRequestAnswerDto.getStatus())
                && !marketingRequestAnswerDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
            marketingRequestAnswerDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_KO.getStatusCode()));
        }
        ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();
        toyotaXmlAnswerResponse.setFileId(marketingRequestAnswerDto.getFileId());
        toyotaXmlAnswerResponse.setRequestDate(marketingRequestAnswerDto.getRequestDate());
        toyotaXmlAnswerResponse.setAnswerDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));

        ToyotaLCDV toyotaLCDV = new ToyotaLCDV();

        toyotaLCDV.setNumber(marketingRequestAnswerDto.getRequestID());
        // fixed jira-534
        toyotaLCDV.setLcdv24(marketingRequestAnswerDto.getVersion16() + marketingRequestAnswerDto.getColorExtInt());
        if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getRequest()
                && StringUtils.isNoneBlank(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes())) {
            toyotaLCDV.setExtendedAttribute(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
        }
        toyotaLCDV.setWltpStatus(errorCode);
        toyotaLCDV.setWltpErrorMsg(description);

        toyotaXmlAnswerResponse.setToyotaLCDV(Arrays.asList(toyotaLCDV));
        // fixed jira-558
        LogUtility.logTheError(logger, marketingRequestAnswerDto.getRequestID(), errorCode, description);

        return toyotaXmlAnswerResponse;
    }

    /**
     * Builds the answer object.
     *
     * @param marketingRequestAnswerDto the marketing request answer dto
     * @param wltpHubResponseRepresentation the calculation results
     * @return the toyota xml answer response
     * @throws ParseException the parse exception
     */
    private ToyotaXmlAnswerResponse buildAnswerObject(MarketingRequestDto marketingRequestAnswerDto,
            WltpHubResponseRepresentation wltpHubResponseRepresentation) throws ParseException {
        marketingRequestAnswerDto.setStatus(String.valueOf(MarketingRequestStatusEnum.CALCULATION_OK.getStatusCode()));

        ToyotaXmlAnswerResponse toyotaXmlAnswerResponse = new ToyotaXmlAnswerResponse();
        toyotaXmlAnswerResponse.setRequestDate(marketingRequestAnswerDto.getRequestDate());
        toyotaXmlAnswerResponse.setAnswerDate(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()));

        ToyotaLCDV toyotaLCDV = new ToyotaLCDV();

        toyotaLCDV.setNumber(marketingRequestAnswerDto.getRequestID());

        // fixed jira-534
        toyotaLCDV.setLcdv24(marketingRequestAnswerDto.getVersion16() + marketingRequestAnswerDto.getColorExtInt());
        toyotaLCDV.setExtendedAttribute(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());

        toyotaLCDV.setWltpStatus(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_TOYOTA);
        toyotaLCDV.setWltpErrorMsg(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
        if (StringUtils.isNotBlank(wltpHubResponseRepresentation.getRequest().getTvv())) {
            toyotaLCDV.setTvv(wltpHubResponseRepresentation.getRequest().getTvv());
        }
        if (StringUtils.isNotBlank(wltpHubResponseRepresentation.getWltpData().getCategory())) {
            toyotaLCDV.setCategory(wltpHubResponseRepresentation.getWltpData().getCategory());
        }
        logger.info("REQUEST_ID =[{}] - Calculated answer sent to the file", marketingRequestAnswerDto.getRequestID());
        String code = getFamilyCode(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());

        logger.info("REQUEST_ID =[{}] - Family Code : {} ", marketingRequestAnswerDto.getRequestID(), code);
        Integer index = Integer.valueOf(getFamilyIndex(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes()));
        logger.info("REQUEST_ID =[{}] - Family Index : {} ", marketingRequestAnswerDto.getRequestID(), index);

        Optional<Family> fam = familyRepository.byCodeAndIndex(code, index);
        logger.info("REQUEST_ID =[{}] - WLTP Family : {} ", marketingRequestAnswerDto.getRequestID(), fam);

        if (fam.isPresent()) {
            List<ToyotaFamilyDetails> famDetailsList = new ArrayList<>();
            ToyotaFamilyDetails toyotaFamilyDetails = new ToyotaFamilyDetails();
            List<ToyotaAttribute> famAttributeList = new ArrayList<>();
            ToyotaAttribute attributeFamLabel = new ToyotaAttribute();
            attributeFamLabel.setCode("LIBELLE_FAMILLE");
            attributeFamLabel.setValue(fam.get().getLabel());
            famAttributeList.add(attributeFamLabel);
            if (StringUtils.isNotBlank(fam.get().getPmax())) {
                ToyotaAttribute attributeFamPmax = new ToyotaAttribute();
                attributeFamPmax.setCode("PMAX");
                attributeFamPmax.setValue(fam.get().getPmax());
                famAttributeList.add(attributeFamPmax);
            }
            toyotaFamilyDetails.setToyotaAttribute(famAttributeList);
            Map<String, List<ToyotaPhysicalResult>> vehCharMap = toyotaFamilyDetailsService.getVehicleCharacteristics(code, index);
            Map<String, List<ToyotaPhase>> vehTestResultsMap = toyotaFamilyDetailsService.getVehicleTestResults(code, index);

            Set<String> keys = vehCharMap.keySet();
            ToyotaTestVehiclesCharacteristics testVehiclesCharacteristics = new ToyotaTestVehiclesCharacteristics();
            for (String key : keys) {
                setVehCharacteristicDataUsingSwitchCase(key, vehCharMap, testVehiclesCharacteristics);
            }
            toyotaFamilyDetails.setTestVehiclesCharacteristics(testVehiclesCharacteristics);

            ToyotaTestVehicleResults toyotaTestVehicleResults = new ToyotaTestVehicleResults();
            Set<String> keySet = vehTestResultsMap.keySet();
            for (String key : keySet) {
                setVehTestResults(key, vehTestResultsMap, toyotaTestVehicleResults);
            }
            toyotaFamilyDetails.setToyotaTestVehicleResults(toyotaTestVehicleResults);
            famDetailsList.add(toyotaFamilyDetails);
            toyotaLCDV.setToyotaFamilyDetails(famDetailsList);
            toyotaLCDV.setType(fam.get().getType());

            String familyCode = getFamilyCode(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());
            String familyIndex = getFamilyIndex(wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes());

            List<ToyotaAttribute> attributeList = new ArrayList<>();
            ToyotaAttribute attributeFamCode = new ToyotaAttribute();
            attributeFamCode.setCode("FAMILLE_WLTP");
            attributeFamCode.setValue(familyCode);
            attributeList.add(attributeFamCode);
            ToyotaAttribute attributeFamIndex = new ToyotaAttribute();
            attributeFamIndex.setCode("INDICE_FAMILLE_WLTP");
            attributeFamIndex.setValue(familyIndex);
            attributeList.add(attributeFamIndex);

            logger.info("REQUEST_ID =[{}] - Attribute Data : {}", marketingRequestAnswerDto.getRequestID(), attributeList);
            toyotaLCDV.setToyotaAttribute(attributeList);
        }
        Double crrValue = null;
        List<ToyotaPhysicalResult> toyotaPhysicalResults = new ArrayList<>();
        wltpHubResponseRepresentation.getPhysResult().stream().forEach(physicalResult -> {
            ToyotaPhysicalResult phyResult = new ToyotaPhysicalResult();
            if (StringUtils.isNotBlank(physicalResult.getCode()) && !physicalResult.getCode().equalsIgnoreCase(CalculationConstants.MATURITY)
                    && StringUtils.isNotBlank(physicalResult.getValue())) {
                phyResult.setCode(physicalResult.getCode());
                phyResult.setValue(physicalResult.getValue());
                toyotaPhysicalResults.add(phyResult);
            }
        });
        toyotaLCDV.setToyotaPhysicalResult(toyotaPhysicalResults);

        List<ToyotaPhase> phList = new ArrayList<>();
        List<WSPhase> results = wltpHubResponseRepresentation.getPhase();
        if (CollectionUtils.isNotEmpty(results)) {
            results.forEach(calculatedPhase -> {
                ToyotaPhase ph = new ToyotaPhase();
                ph.setCode(calculatedPhase.getCode());
                List<ToyotaResult> resultList = new ArrayList<>();
                calculatedPhase.getResult().forEach(emission -> {
                    ToyotaResult result = new ToyotaResult();
                    if (!("CE".equalsIgnoreCase(emission.getCode()))) {
                        result.setCode(emission.getCode());
                        result.setValue(getPhaseResultInFormat(emission.getCode(), Double.valueOf(emission.getValue())));
                        resultList.add(result);
                    }
                    if (calculatedPhase.getCode().equals(RequestType.COMB.name())
                            && (AoCronoEliadeCalculationConstants.CO2.equalsIgnoreCase(emission.getCode()))) {
                        logger.info("Request ID[{}]: Emissions - Calcul - COMB - CO2 - {}", marketingRequestAnswerDto.getRequestID(),
                                emission.getValue());
                    }
                });
                ph.setResult(resultList);
                phList.add(ph);
            });
        }
        logger.info("REQUEST_ID =[{}] - CalculationResults : {}", marketingRequestAnswerDto.getRequestID(), phList);
        toyotaLCDV.setToyotaPhase(phList);
        toyotaXmlAnswerResponse.setToyotaLCDV(Arrays.asList(toyotaLCDV));

        for (ToyotaPhysicalResult phyResult : toyotaPhysicalResults) {
            if (CalculationConstants.CRR_CODE.equals(phyResult.getCode())) {
                crrValue = Double.valueOf(phyResult.getValue());
            }
        }
        TVV tvv = fetchTVV(toyotaLCDV, wltpHubResponseRepresentation);

        // fixed jira-577
        if (null != tvv) {
            if (StringUtils.isBlank(toyotaLCDV.getTvv())) {
                toyotaLCDV.setTvv(tvv.getTvvDesignation());
            }
            toyotaLCDV.setDepolDataSet(setDepolDataSet(marketingRequestAnswerDto.getRequestID(), tvv, crrValue));
        }
        return toyotaXmlAnswerResponse;
    }

    /**
     * Fetch TVV.
     *
     * @param toyotaLCDV the toyota LCDV
     * @param wltpHubResponseRepresentation the wltp hub response representation
     * @return the tvv
     */
    private TVV fetchTVV(ToyotaLCDV toyotaLCDV, WltpHubResponseRepresentation wltpHubResponseRepresentation) {
        String extendedTitle = wltpHubResponseRepresentation.getRequest().getVersion16C()
                + wltpHubResponseRepresentation.getRequest().getColorExtInt()
                + wltpHubResponseRepresentation.getRequest().getExtendedTitleAttributes();
        String t1a = getTvvT1A(extendedTitle);
        String t1b = getTvvT1B(extendedTitle);
        if (toyotaLCDV.getTvv() != null && !toyotaLCDV.getTvv().isEmpty()) {
            if (!tvvRepository.tvvByUniqueFields(getVehicleFamily(extendedTitle), toyotaLCDV.getTvv()).isEmpty())
                return tvvRepository.tvvByUniqueFields(getVehicleFamily(extendedTitle), toyotaLCDV.getTvv()).get(0);
        } else if (!t1a.isEmpty() && !t1b.isEmpty()) {
            if (!tvvRepository.tvvByUniqueFields(getVehicleFamily(extendedTitle), t1a, t1b).isEmpty())
                return tvvRepository.tvvByUniqueFields(getVehicleFamily(extendedTitle), t1a, t1b).get(0);
        }
        return null;
    }

    /**
     * Sets the depol data set.
     *
     * @param requestId the request id
     * @param tvv the tvv
     * @param crrValue the crr value
     * @return the list
     */
    private List<ToyotaDepol> setDepolDataSet(String requestId, TVV tvv, Double crrValue) {
        ToyotaDepol depolDataSet = new ToyotaDepol();
        String depolCode = null;
        if (null != tvv && StringUtils.isNotBlank(tvv.getTvvCodeDepol())) {
            depolCode = tvv.getTvvCodeDepol();
        }
        if (depolCode != null && !depolCode.isEmpty()) {
            List<Depol> list = depolRepository.depolByQuadrupleFields(depolCode, "N", crrValue);
            if (!list.isEmpty() && list.size() == 1) {
                Depol depol = list.get(0);
                depolDataSet.setDepolCode(depolCode);
                depolDataSet.setDepolStatus("OK");
                depolDataSet.setDepolMessage("depol data found successfully");

                List<ToyotaDepolLimitCode> limitList = new ArrayList<>();
                ToyotaDepolLimitCode rcrMin = new ToyotaDepolLimitCode();
                rcrMin.setCode("RCRRTR_MIN");
                rcrMin.setValue(depol.getCrrMin().toString());
                limitList.add(rcrMin);

                ToyotaDepolLimitCode rcrMax = new ToyotaDepolLimitCode();
                rcrMax.setCode("RCRRTR_MAX");
                rcrMax.setValue(depol.getCrrMax().toString());
                limitList.add(rcrMax);

                ToyotaDepolLimitCode mroMin = new ToyotaDepolLimitCode();
                mroMin.setCode("MROTR_MIN");
                mroMin.setValue(depol.getMroMin().toString());
                limitList.add(mroMin);

                ToyotaDepolLimitCode mroMax = new ToyotaDepolLimitCode();
                mroMax.setCode("MROTR_MAX");
                mroMax.setValue(depol.getMroMax().toString());
                limitList.add(mroMax);

                ToyotaDepolLimitCode strMin = new ToyotaDepolLimitCode();
                strMin.setCode("STR_MIN");
                strMin.setValue(depol.getFrontalAreaMin().toString());
                limitList.add(strMin);

                ToyotaDepolLimitCode strMax = new ToyotaDepolLimitCode();
                strMax.setCode("STR_MAX");
                strMax.setValue(depol.getFrontalAreaMax().toString());
                limitList.add(strMax);

                ToyotaDepolLimitCode coolStrMin = new ToyotaDepolLimitCode();
                coolStrMin.setCode("COOLSTR_MIN");
                // fix-jira-628
                coolStrMin.setValue(depol.getCoolingSurfaceMin().toString());
                limitList.add(coolStrMin);

                ToyotaDepolLimitCode coolStrMax = new ToyotaDepolLimitCode();
                coolStrMax.setCode("COOLSTR_MAX");
                // fix-jira-628
                coolStrMax.setValue(depol.getCoolingSurfaceMax().toString());
                limitList.add(coolStrMax);

                ToyotaDepolLimitCode cxMin = new ToyotaDepolLimitCode();
                cxMin.setCode("CX_MIN");
                cxMin.setValue(depol.getCxMin().toString());
                limitList.add(cxMin);

                ToyotaDepolLimitCode cxMax = new ToyotaDepolLimitCode();
                cxMax.setCode("CX_MAX");
                cxMax.setValue(depol.getCxMax().toString());
                limitList.add(cxMax);

                depolDataSet.setDepolResult(limitList);

                logger.info(
                        "RequestID : [{}] DepolDataSet : VehicleFamily:[{}], T1A:[{}], T1B:[{}], Code_Depol:[{}], Special_Flag:[{}], CRR:[{}], RCRRTR_MIN:[{}], RCRRTR_MAX:[{}], MROTR_MIN:[{}], MROTR_MAX:[{}], STR_MIN:[{}], STR_MAX:[{}], COOLSTR_MIN:[{}], COOLSTR_MAX:[{}]",
                        requestId, tvv.getVehicleFamily(), tvv.getT1AValue(), tvv.getT1BValue(), depolCode, depol.getSpecialFlag(), crrValue,
                        depol.getCrrMin(), depol.getCrrMax(), depol.getMroMin(), depol.getMroMax(), depol.getFrontalAreaMin(),
                        depol.getFrontalAreaMax(), depol.getCoolingSurfaceMin(), depol.getCoolingSurfaceMax());

            } else if (!list.isEmpty() && list.size() > 1) {
                depolDataSet.setDepolCode(depolCode);
                depolDataSet.setDepolStatus("ERRW666");
                depolDataSet.setDepolMessage("several depol data found");
                logger.info(
                        "RequestID : [{}] DepolDataSet : VehicleFamily:[{}], T1A:[{}], T1B:[{}], Code_Depol:[{}], Special_Flag:[{}], CRR:[{}], [{}]:[{}]",
                        requestId, tvv.getVehicleFamily(), tvv.getT1AValue(), tvv.getT1BValue(), depolCode, list.get(0).getSpecialFlag(), crrValue,
                        depolDataSet.getDepolStatus(), depolDataSet.getDepolMessage());
            } else {
                depolDataSet.setDepolCode(depolCode);
                depolDataSet.setDepolStatus("ERRW661");
                depolDataSet.setDepolMessage("depol data not found");
                logger.info(
                        "RequestID : [{}] DepolDataSet : VehicleFamily:[{}], T1A:[{}], T1B:[{}], Code_Depol:[{}], Special_Flag:[{}],CRR:[{}], [{}]:[{}]",
                        requestId, tvv.getVehicleFamily(), tvv.getT1AValue(), tvv.getT1BValue(), depolCode, "N", crrValue,
                        depolDataSet.getDepolStatus(), depolDataSet.getDepolMessage());
            }
        } else {
            logger.info("RequestID : [{}] DepolDataSet : VehicleFamily:[{}], T1A:[{}], T1B:[{}], depol code blank", requestId, tvv.getVehicleFamily(),
                    tvv.getT1AValue(), tvv.getT1BValue());
        }

        return Arrays.asList(depolDataSet);
    }

    /**
     * Gets the family code.
     *
     * @param extendedTitle the extended title
     * @return the family code
     */
    public String getFamilyCode(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile("(?:.{7})*(?:T8C(?<code>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("code");
        return "";
    }

    /**
     * Gets the family index.
     *
     * @param extendedTitle the extended title
     * @return the family index
     */
    public String getFamilyIndex(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile("(?:.{7})*(?:T8D(?<index>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("index");
        return "";
    }

    /**
     * Gets the phase result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the phy result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phy result in format
     */
    private String getPhyResultInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = pattern.length() < 2 ? 0 : pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * Gets the tvv T 1 A.
     *
     * @param extendedTitle the extended title
     * @return the tvv T 1 A
     */
    public String getTvvT1A(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T1A(?<t1a>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1a");

        return "";
    }

    /**
     * Gets the tvv T 1 B.
     *
     * @param extendedTitle the extended title
     * @return the tvv T 1 B
     */
    public String getTvvT1B(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile(".{24}(?:.{7})*(?:T1B(?<t1b>..)(..))(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group("t1b");
        return "";
    }

    /**
     * Gets the vehicle family.
     *
     * @param extendedTitle the extended title
     * @return the vehicle family
     */
    public String getVehicleFamily(String extendedTitle) {
        Matcher m = java.util.regex.Pattern.compile("(....).{20}(?:.{7})*").matcher(extendedTitle);
        if (m.matches())
            return m.group(1);
        return "";
    }

    /**
     * Sets the veh characteristic data using switch case.
     *
     * @param key the key
     * @param vehCharMap the veh char map
     * @param toyotaFamDetails the toyota fam details
     */
    private void setVehCharacteristicDataUsingSwitchCase(String key, Map<String, List<ToyotaPhysicalResult>> vehCharMap,
            ToyotaTestVehiclesCharacteristics toyotaTestVehiclesCharacteristics) {
        switch (key) {
        case "VLOW":
            ToyotaVLowPhysicalResult vlowPhyResult = new ToyotaVLowPhysicalResult();
            vlowPhyResult.setToyotaVlowPhysicalResult(vehCharMap.get(key));
            toyotaTestVehiclesCharacteristics.setToyotaVLowPhysicalResult(vlowPhyResult);
            break;
        case "VMED":
            ToyotaVMediumPhysicalResult vmedPhyResult = new ToyotaVMediumPhysicalResult();
            vmedPhyResult.setToyotaVMediumPhysicalResult(vehCharMap.get(key));
            toyotaTestVehiclesCharacteristics.setToyotaVMediumPhysicalResult(vmedPhyResult);
            break;
        case "VHIGH":
            ToyotaVHighPhysicalResult vhighPhyResult = new ToyotaVHighPhysicalResult();
            vhighPhyResult.setToyotaVHighPhysicalResult(vehCharMap.get(key));
            toyotaTestVehiclesCharacteristics.setToyotaVHighPhysicalResult(vhighPhyResult);
            break;
        case "VREF":
            ToyotaVRefPhysicalResult vrefPhyResult = new ToyotaVRefPhysicalResult();
            vrefPhyResult.setToyotaVRefPhysicalResult(vehCharMap.get(key));
            toyotaTestVehiclesCharacteristics.setToyotaVRefPhysicalResult(vrefPhyResult);
            break;

        default:
            // nothing
            break;
        }
    }

    /**
     * Sets the veh test results.
     *
     * @param key the key
     * @param vehTestResultsMap the veh test results map
     * @param toyotaFamDetails the toyota fam details
     */
    private void setVehTestResults(String key, Map<String, List<ToyotaPhase>> vehTestResultsMap, ToyotaTestVehicleResults toyotaTestVehicleResults) {
        switch (key) {
        case "VLOW":
            ToyotaVLowTestResult vlowPhaseResult = new ToyotaVLowTestResult();
            vlowPhaseResult.setVlowPhaseResults(vehTestResultsMap.get(key));
            toyotaTestVehicleResults.setToyotaVLowTestResult(vlowPhaseResult);
            break;

        case "VMED":
            ToyotaVMedTestResult vmedPhaseResult = new ToyotaVMedTestResult();
            vmedPhaseResult.setVmedPhaseResults(vehTestResultsMap.get(key));
            toyotaTestVehicleResults.setToyotaVMedTestResult(vmedPhaseResult);
            break;

        case "VHIGH":
            ToyotaVHighTestResult vhighPhaseResult = new ToyotaVHighTestResult();
            vhighPhaseResult.setVhighPhaseResults(vehTestResultsMap.get(key));
            toyotaTestVehicleResults.setToyotaVHighTestResult(vhighPhaseResult);
            break;

        default:
            // nothing
            break;
        }

    }
}
