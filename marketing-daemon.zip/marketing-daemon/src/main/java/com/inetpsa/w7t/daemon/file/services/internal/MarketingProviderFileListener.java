/**
 * 
 */
package com.inetpsa.w7t.daemon.file.services.internal;

import java.io.File;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import com.inetpsa.w7t.application.MarketingDaemonCommandLineHandler;
import com.inetpsa.w7t.batch.util.BatchJobEntry;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig.MarketingDaemonProviderConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;

/**
 * The listener interface for receiving marketingProviderFile events. The class that is interested in processing a marketingProviderFile event
 * implements this interface, and the object created with that class is registered with a component using the component's
 * <code>addMarketingProviderFileListener<code> method. When the marketingProviderFile event occurs, that object's appropriate method is invoked.
 *
 * @author E534811
 */
public class MarketingProviderFileListener extends DefaultMarketingFileListener {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The batch job entry. */
    @Inject
    private BatchJobEntry batchJobEntry;

    /** The Constant DIRECTORY. */
    private static final String DIRECTORY = "directory path {} ";

    /** The Constant NOT_ACTIVATED. */
    private static final String NOT_ACTIVATED = "NOT_ACTIVATED";

    /**
     * Instantiates a new marketing provider file listener.
     */
    public MarketingProviderFileListener() {
        super();
    }

    /**
     * Instantiates a new marketing provider file listener.
     *
     * @param name the name
     * @param config the config
     * @param refreshInterval the refresh interval
     */
    public MarketingProviderFileListener(String name, MarketingDaemonProviderConfig config, Integer refreshInterval) {
        super(name, config.getInputDirectory(), config.getOutputDirectory(), config.getInputFilename(), refreshInterval, config.getOutputFilename(),
                config.getBcvNewtonFor(), config.getProcessChunkSize());
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.services.FileListener#run()
     */
    @Override
    public void run() {
        Thread.currentThread().setName("provider-listener-".concat(name));
        logger.info("Provider listener {} started", this.name);

        while (!MarketingDaemonCommandLineHandler.isSigintRequested()) {
            long start = System.currentTimeMillis();
            logger.debug("Provider Listener {} loop started", this.name);
            getJobs();
            long end = System.currentTimeMillis();
            long delta = end - start;
            try {
                TimeUnit.MILLISECONDS.sleep(Math.max(refreshInterval - delta, 0));
            } catch (InterruptedException e) {
                logger.error(String.format("Provider file listener '%s' interrupted !", this.name), e);
                Thread.currentThread().interrupt();
            }
            logger.debug("Provider Listener {} loop ended", this.name);
        }
        logger.info("Provider Listener {} stopped", this.name);
    }

    /**
     * Gets the jobs.
     *
     * @return the jobs
     */
    private void getJobs() {
        String jobName = "";
        try {
            if ((MarketingDaemonServiceConstants.BCV_NEWTON).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_BCV_NEWTON_JOB_NAME;
                jobRunForClients(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern, this.bcvNewtonForClient,
                        this.processChunkSize);

            } else if ((MarketingDaemonServiceConstants.CONFIG_MOT2).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.WLTP_CFG_MOT2_JSON_ANSWER_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            } else if ((MarketingDaemonServiceConstants.TOYOTA).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.WLTP_TOYOTA_XML_ANSWER_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            } else if ((MarketingDaemonServiceConstants.AOGEOS).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_AOGEOS_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            } else if ((MarketingDaemonServiceConstants.CRONOS).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_CRONOS_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            } else if ((MarketingDaemonServiceConstants.ELIADE).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_ELIADE_REJECTED_FILE_WRITER_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_ELIADE_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            } else if ((MarketingDaemonServiceConstants.ICUBE).equalsIgnoreCase(this.name)
                    && !this.outputfileNamePattern.equalsIgnoreCase(NOT_ACTIVATED)) {

                logger.info(DIRECTORY, this.outputDirectory.getAbsolutePath());
                jobName = MarketingDaemonServiceConstants.PROVIDER_REQ_ICUBE_JOB_NAME;
                jobRun(jobName, this.outputDirectory.getAbsolutePath(), this.outputfileNamePattern);

            }
        } catch (RuntimeException e) {
            logger.error(String.format("Client file listener '%s' error !", this.name), e);
        }
    }

    /**
     * Job run for clients.
     *
     * @param jobName the job name
     * @param fileLoc the file loc
     * @param outPutFilename the out put filename
     * @param clientName the client name
     * @param processChunkSize the process chunk size
     */
    private void jobRunForClients(String jobName, String fileLoc, String outPutFilename, String clientName, Long processChunkSize) {
        batchJobEntry.runJob(jobName, fileLoc, outPutFilename, clientName, processChunkSize);
    }

    /**
     * Job run.
     *
     * @param jobName the job name
     * @param fileLoc the file loc
     * @param outPutFilename the out put filename
     */
    private void jobRun(String jobName, String fileLoc, String outPutFilename) {
        batchJobEntry.runJob(jobName, fileLoc, outPutFilename);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.file.services.internal.DefaultMarketingFileListener#retrieveFile()
     */
    @Override
    protected Optional<File> retrieveFile() {
        return Optional.empty();
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.daemon.file.services.internal.DefaultMarketingFileListener#parseFile(java.io.File)
     */
    @Override
    protected void parseFile(File file) {
        // This method is used for parsing the file.
    }
}
