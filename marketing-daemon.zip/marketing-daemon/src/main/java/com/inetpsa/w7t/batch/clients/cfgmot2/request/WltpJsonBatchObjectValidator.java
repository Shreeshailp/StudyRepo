/*
 * Creation : 19 Jul 2018
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.request;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;

import org.springframework.batch.item.validator.ValidationException;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.InitializingBean;

/**
 * @author E534811
 */
public class WltpJsonBatchObjectValidator implements Validator<WltpJsonBatchObject>, InitializingBean {

    private javax.validation.Validator validator;

    @Override
    public void afterPropertiesSet() throws Exception {
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        validator = validatorFactory.usingContext().getValidator();
    }

    @Override
    public void validate(WltpJsonBatchObject wltpJsonBatchObject) throws ValidationException {
        Set<ConstraintViolation<Object>> constraintViolations = validator.validate(wltpJsonBatchObject);

        if (!constraintViolations.isEmpty()) {
            generateValidationException(constraintViolations);
        }

    }

    private void generateValidationException(Set<ConstraintViolation<Object>> constraintViolations) {
        StringBuilder message = new StringBuilder();

        for (ConstraintViolation<Object> constraintViolation : constraintViolations) {
            message.append(constraintViolation.getMessage() + "\n");
        }

        throw new ValidationException(message.toString());
    }
}