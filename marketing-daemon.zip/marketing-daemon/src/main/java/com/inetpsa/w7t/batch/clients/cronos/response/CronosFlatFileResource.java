/*
 * Creation : 20 Sep 2018
 */
package com.inetpsa.w7t.batch.clients.cronos.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class CronosFlatFileResource.
 */
public class CronosFlatFileResource extends FileSystemResource {

    /**
     * Instantiates a new cronos flat file resource.
     *
     * @param path the path
     * @param cronosFilename the cronos filename
     */
    public CronosFlatFileResource(String path, String cronosFilename) {
        super(path + File.separator + cronosFilename);
    }
}
