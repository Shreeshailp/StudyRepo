/*
 * Creation : 9 août 2017
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

import java.util.List;

/**
 * The Class CpdsResponseRepresentation.
 */
public class CpdsResponseRepresentation extends CpdsRequestsRepresentation {

    private CpdsAnswer answer;

    private CpdsData wltpData;

    /** The phys result. */
    private List<CpdsPhysicalResult> physResult;

    private List<CpdsPhase> phase;

    /**
     * Instantiates a new cpds response representation.
     */
    public CpdsResponseRepresentation() {
        super();
    }

    /**
     * Getter answer
     * 
     * @return the answer
     */
    public CpdsAnswer getAnswer() {
        return answer;
    }

    /**
     * Setter answer
     * 
     * @param answer the answer to set
     */
    public void setAnswer(CpdsAnswer answer) {
        this.answer = answer;
    }

    /**
     * Getter wltpData
     * 
     * @return the wltpData
     */
    public CpdsData getWltpData() {
        return wltpData;
    }

    /**
     * Setter wltpData
     * 
     * @param wltpData the wltpData to set
     */
    public void setWltpData(CpdsData wltpData) {
        this.wltpData = wltpData;
    }

    /**
     * Getter physResult
     * 
     * @return the physResult
     */
    public List<CpdsPhysicalResult> getPhysResult() {
        return physResult;
    }

    /**
     * Setter physResult
     * 
     * @param physResult the physResult to set
     */
    public void setPhysResult(List<CpdsPhysicalResult> physResult) {
        this.physResult = physResult;
    }

    /**
     * Getter phase
     * 
     * @return the phase
     */
    public List<CpdsPhase> getPhase() {
        return phase;
    }

    /**
     * Setter phase
     * 
     * @param phase the phase to set
     */
    public void setPhase(List<CpdsPhase> phase) {
        this.phase = phase;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CpdsResponseRepresentation [answer=" + answer + ", wltpData=" + wltpData + ", physResult=" + physResult + ", phase=" + phase + "]";
    }

}
