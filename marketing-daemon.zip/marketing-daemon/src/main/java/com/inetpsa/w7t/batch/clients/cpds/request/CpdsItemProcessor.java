/*
 * Creation : 24 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.request;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;

import org.seedstack.seed.SeedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.dao.EmptyResultDataAccessException;

import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.shared.WltpRequestErrorCode;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.MaturityCheckUtility;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientMaturityRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.ClientParameterFinder;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.CountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.DestinationCountryRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MaturityRepository;

/**
 * The Class CpdsItemProcessor.
 */
public class CpdsItemProcessor implements ItemProcessor<CpdsDto, CpdsDto>, StepExecutionListener {

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The valid country with destinations. */
    private List<String> validCountryWithDestinations = new ArrayList<>();

    /** The destination country repository. */
    @Inject
    private DestinationCountryRepository destinationCountryRepository;

    /** The country repository. */
    @Inject
    private CountryRepository countryRepository;

    /** The Constant ERROR_LOG. */
    public static final String ERROR_LOG = "Marketing Request ({}) - {}";

    /** The Constant SIXTEEN. */
    private static final int SIXTEEN = 16;

    /** The client parameter repository. */
    @Inject
    private ClientParameterFinder clientParameterFinder;

    /** The maturity repository. */
    @Inject
    private MaturityRepository maturityRepository;

    /** The client maturity repository. */
    @Inject
    private ClientMaturityRepository clientMaturityRepository;

    /** The job execution status. */
    Boolean jobExecutionStatus = true;

    /** The line number. */
    private volatile int lineNumber;

    /** The thread local line number. */
    private static ThreadLocal<Integer> threadLocalLineNumber = new ThreadLocal<>();

    /** The Constant ONE. */
    private static final int ONE = 1;

    private static final String OPTION7C = "Y";

    /**
     * Reset line number.
     */
    @AfterStep
    public void resetLineNumber() {
        this.lineNumber = 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemProcessor#process(java.lang.Object)
     */
    @Override
    public CpdsDto process(CpdsDto item) throws Exception {
        if (jobExecutionStatus) {
            lineNumber++;
            threadLocalLineNumber.set(lineNumber);
            // fixed jira-675
            logger.info(
                    "Marketing Request =[CpdsDto[requestId={}, requestDate={}, requestType={}, ecomDate={}, vehicleMass={}, vehicleSCX={}, vehicleCRR={}, country={}, extendedtitle={}, filler={}]]",
                    item.getRequestId(), item.getRequestDate(), item.getRequestType(), item.getEcomDate(), item.getVehicleMass(),
                    item.getVehicleSCX(), item.getVehicleCRR(), item.getCountry(), item.getVersion16() + item.getColorExtInt() + item.getExtAttr(),
                    item.getFiller());
            try {
                if (!isEmptyLine(item)) {
                    if (lineNumber == ONE) {
                        validCountryWithDestinations = MarkertingDaemonUtility.initializeValidCountries(countryRepository,
                                destinationCountryRepository);
                    }

                } else {
                    item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                    setErrorDetails(item, WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(), WltpRequestErrorCode.INCORRECT_FILE.getDescription());
                    LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(),
                            WltpRequestErrorCode.INCORRECT_FILE.getDescription());
                }
            } catch (EmptyResultDataAccessException e) {
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INCORRECT_FILE.getRuleCode(),
                        WltpRequestErrorCode.INCORRECT_FILE.getDescription());
            }
            return validateRequest(item);
        }
        return null;
    }

    /**
     * Maturity check.
     *
     * @param item the item
     * @return true, if successful
     */
    private boolean maturityCheck(CpdsDto item) {
        boolean proceed = true;
        try {
            // check request type != TEST
            // fixed jira-711
            if (!item.getRequestType().equalsIgnoreCase("TEST")) {
                logger.info("inside maturityCheck....");
                String maturity = MaturityCheckUtility.determineMaturityCheckForMarketingClients(item.getRequestId(), item.getVersion16(),
                        maturityRepository, clientMaturityRepository, logger, MarketingDaemonServiceConstants.CPDS);
                item.setMaturity(maturity);
            }
        } catch (SeedException se) {
            proceed = false;
            item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
            if (se.getErrorCode() instanceof WltpErrorCode) {
                WltpErrorCode ec = (WltpErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
            } else if (se.getErrorCode() instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode ec = (WltpEngineCalculatorErrorCode) se.getErrorCode();
                item.setAnswerCode("ERRW" + ec.getRuleCode());
                item.setAnswerDesignation(ec.getDescription());
            }
            if (item.getAnswerDesignation().contains("Draft")) {
                item.setMaturity("D");
            } else if (item.getAnswerDesignation().contains("Obsolete")) {
                item.setMaturity("O");
            } else if (item.getAnswerDesignation().contains("Unknown")) {
                item.setMaturity("U");
            } else if (item.getAnswerDesignation().contains("Captive fleet")) {
                item.setMaturity("F");
            }

        }
        return proceed;
    }

    /**
     * Validate request.
     *
     * @param item the item
     * @return the cpds dto
     */
    private CpdsDto validateRequest(@Valid CpdsDto item) {

        CpdsDto requestResponseDTO = verifyCpdsData(item);

        return requestResponseDTO;
    }

    /**
     * Verify cpds data.
     *
     * @param item the item
     * @return the cpds dto
     */
    private CpdsDto verifyCpdsData(CpdsDto item) {
        boolean proceed = true;
        try {
            // fixed jira-658 and fixed jira-713
            if (item.getRequestId().trim() == null || item.getRequestId().trim().isEmpty() || item.getRequestId().trim().length() > 20
                    || clientParameterFinder.getFlag7C(item.getRequestId().trim().substring(0, 3), OPTION7C) == null) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode(),
                        RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), RequestErrorCode.REQUEST_NUMBER_INCORRECT.getRuleCode(),
                        RequestErrorCode.REQUEST_NUMBER_INCORRECT.getDescription());
            }

            if (proceed
                    && (item.getRequestType().trim() == null || item.getRequestType().trim().isEmpty() || item.getRequestType().trim().length() != 4
                            || !item.getRequestType().trim().equalsIgnoreCase(RequestType.FULL.name())
                                    && !item.getRequestType().trim().equalsIgnoreCase(RequestType.COMB.name())
                                    && !item.getRequestType().trim().equalsIgnoreCase(RequestType.TEST.name()))) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, RequestErrorCode.UNKNOWN_REQUEST_TYPE.getRuleCode(), RequestErrorCode.UNKNOWN_REQUEST_TYPE.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), RequestErrorCode.UNKNOWN_REQUEST_TYPE.getRuleCode(),
                        RequestErrorCode.UNKNOWN_REQUEST_TYPE.getDescription());
            }

            if (proceed && (item.getEcomDate().trim() == null || item.getEcomDate().trim().isEmpty() || item.getEcomDate().trim().length() != 10
                    || (!item.getEcomDate().trim().isEmpty()
                            && !item.getEcomDate().matches("\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])*")))) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(), RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), RequestErrorCode.ECOM_DATE_INCORRECT.getRuleCode(),
                        RequestErrorCode.ECOM_DATE_INCORRECT.getDescription());
            }

            if (proceed && (item.getCountry().trim() == null || item.getCountry().trim().isEmpty() || item.getCountry().trim().length() != 2
                    || (!validCountryWithDestinations.contains(item.getCountry().trim())))) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getRuleCode(),
                        WltpRequestErrorCode.INNCORRECT_TRADING_COUNTRY.getDescription());
            }

            if (proceed && (item.getVersion16().trim() == null || item.getVersion16().trim().isEmpty()
                    || item.getVersion16().trim().length() != SIXTEEN)) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.VERSION_16C_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.VERSION_16C_INCORRECT.getDescription());
            }

            if (proceed && (item.getColorExtInt().trim() == null || item.getColorExtInt().trim().isEmpty()
                    || item.getColorExtInt().trim().length() != 8)) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, WltpRequestErrorCode.COLOR_EXT_INT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.COLOR_EXT_INT_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), WltpRequestErrorCode.COLOR_EXT_INT_INCORRECT.getRuleCode(),
                        WltpRequestErrorCode.COLOR_EXT_INT_INCORRECT.getDescription());
            }

            if (proceed && (item.getExtAttr().trim() == null || item.getExtAttr().trim().isEmpty())) {
                proceed = false;
                item.setStatus(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()));
                setErrorDetails(item, RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                        RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
                LogUtility.logTheError(logger, item.getRequestId(), RequestErrorCode.EXTENDED_TITLE_INCORRECT.getRuleCode(),
                        RequestErrorCode.EXTENDED_TITLE_INCORRECT.getDescription());
            }

            // fixed jira-658
            if (proceed && !maturityCheck(item))
                return item;

        } catch (

        Exception e) {
            logger.error("Request ID[{}]: Error in CPDS Processor : {}", item.getRequestId(), e.getMessage());
        }
        return item;
    }

    /**
     * Sets the error details.
     *
     * @param mrq         the mrq
     * @param ruleCode    the rule code
     * @param description the description
     */
    private void setErrorDetails(CpdsDto mrq, String ruleCode, String description) {
        // fixed jira-551 and jira-675
        logger.info(
                "Marketing Request =[CpdsDto[requestId={}, requestDate={}, requestType={}, ecomDate={}, vehicleMass={}, vehicleSCX={}, vehicleCRR={}, country={}, extendedtitle={}, filler={}]]",
                mrq.getRequestId(), mrq.getRequestDate(), mrq.getRequestType(), mrq.getEcomDate(), mrq.getVehicleMass(), mrq.getVehicleSCX(),
                mrq.getVehicleCRR(), mrq.getCountry(), mrq.getVersion16() + mrq.getColorExtInt() + mrq.getExtAttr(), mrq.getFiller());
        if (mrq.getAnswerCode() == null) {
            mrq.setAnswerCode(ruleCode);
            mrq.setAnswerDesignation(description);
        }
    }

    /**
     * Checks if is empty line.
     *
     * @param item the item
     * @return true, if is empty line
     */
    private boolean isEmptyLine(CpdsDto item) {
        return (item.getRequestId() + item.getRequestDate() + item.getRequestType() + item.getEcomDate() + item.getVehicleMass()
                + item.getVehicleSCX() + item.getVehicleCRR() + item.getCountry() + item.getVersion16() + item.getColorExtInt() + item.getExtAttr()
                + item.getFiller()).length() == 0;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#beforeStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public void beforeStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);

    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.core.StepExecutionListener#afterStep(org.springframework.batch.core.StepExecution)
     */
    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        threadLocalLineNumber.set(0);
        if (stepExecution.getReadCount() == 0)
            logger.error("Incorrect CPDS file");
        return null;
    }
}
