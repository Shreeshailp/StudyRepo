/*
 * Creation : 12 Feb 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.domain.model.dto;

import java.util.List;
import java.util.Map;

import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaFamilyDetailsDto;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhase;
import com.inetpsa.w7t.batch.clients.toyota.response.ToyotaPhysicalResult;

/**
 * The Class MarketingRequestAnswerDTO.
 *
 * @author E534811
 */
public class MarketingRequestAnswerDTO {

    /** The cfg mot 2 answer dto. */
    List<MarketingRequestDto> cfgMot2AnswerDto;

    /** The ao crono eliade answer dto. */
    List<AoCronosEliadeDto> aoCronoEliadeAnswerDto;

    /** The toyota answer dto. */
    List<MarketingRequestDto> toyotaAnswerDto;

    /** The veh characterstic map. */
    Map<String, Map<String, List<ToyotaPhysicalResult>>> vehCharactersticMap;

    /** The fam details. */
    private List<ToyotaFamilyDetailsDto> famDetails;

    /** The veh test results map. */
    Map<String, Map<String, List<ToyotaPhase>>> vehTestResultsMap;

    /**
     * Getter famDetails
     * 
     * @return the famDetails
     */
    public List<ToyotaFamilyDetailsDto> getFamDetails() {
        return famDetails;
    }

    /**
     * Getter vehTestResultsMap
     * 
     * @return the vehTestResultsMap
     */
    public Map<String, Map<String, List<ToyotaPhase>>> getVehTestResultsMap() {
        return vehTestResultsMap;
    }

    /**
     * Setter vehTestResultsMap
     * 
     * @param vehTestResultsMap the vehTestResultsMap to set
     */
    public void setVehTestResultsMap(Map<String, Map<String, List<ToyotaPhase>>> vehTestResultsMap) {
        this.vehTestResultsMap = vehTestResultsMap;
    }

    /**
     * Setter famDetails
     * 
     * @param famDetails the famDetails to set
     */
    public void setFamDetails(List<ToyotaFamilyDetailsDto> famDetails) {
        this.famDetails = famDetails;
    }

    /**
     * Gets the cfg mot 2 answer dto.
     *
     * @return the cfg mot 2 answer dto
     */
    public List<MarketingRequestDto> getCfgMot2AnswerDto() {
        return cfgMot2AnswerDto;
    }

    /**
     * Sets the cfg mot 2 answer dto.
     *
     * @param cfgMot2AnswerDto the new cfg mot 2 answer dto
     */
    public void setCfgMot2AnswerDto(List<MarketingRequestDto> cfgMot2AnswerDto) {
        this.cfgMot2AnswerDto = cfgMot2AnswerDto;
    }

    /**
     * Gets the ao crono eliade answer dto.
     *
     * @return the ao crono eliade answer dto
     */
    public List<AoCronosEliadeDto> getAoCronoEliadeAnswerDto() {
        return aoCronoEliadeAnswerDto;
    }

    /**
     * Sets the ao crono eliade answer dto.
     *
     * @param aoCronoEliadeAnswerDto the new ao crono eliade answer dto
     */
    public void setAoCronoEliadeAnswerDto(List<AoCronosEliadeDto> aoCronoEliadeAnswerDto) {
        this.aoCronoEliadeAnswerDto = aoCronoEliadeAnswerDto;
    }

    /**
     * Gets the toyota answer dto.
     *
     * @return the toyota answer dto
     */
    public List<MarketingRequestDto> getToyotaAnswerDto() {
        return toyotaAnswerDto;
    }

    /**
     * Sets the toyota answer dto.
     *
     * @param toyotaAnswerDto the new toyota answer dto
     */
    public void setToyotaAnswerDto(List<MarketingRequestDto> toyotaAnswerDto) {
        this.toyotaAnswerDto = toyotaAnswerDto;
    }

    /**
     * Getter vehCharactersticMap
     * 
     * @return the vehCharactersticMap
     */
    public Map<String, Map<String, List<ToyotaPhysicalResult>>> getVehCharactersticMap() {
        return vehCharactersticMap;
    }

    /**
     * Setter vehCharactersticMap
     * 
     * @param vehCharactersticMap the vehCharactersticMap to set
     */
    public void setVehCharactersticMap(Map<String, Map<String, List<ToyotaPhysicalResult>>> vehCharactersticMap) {
        this.vehCharactersticMap = vehCharactersticMap;
    }

}
