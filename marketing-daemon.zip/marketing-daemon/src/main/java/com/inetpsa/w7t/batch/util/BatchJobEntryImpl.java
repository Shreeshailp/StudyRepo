/*
 * Creation : 28 avr. 2017
 */
package com.inetpsa.w7t.batch.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;

import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;

/**
 * The Class BatchJobEntryImpl.
 */
public class BatchJobEntryImpl implements BatchJobEntry {

    /** The logger. */
    @Logging
    private Logger logger;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.BatchJobEntry#runJob(java.lang.String, java.lang.String)
     */
    @Override
    public void runJob(String jobName, String fileLoc) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);

        JobParameters jobParams = new JobParametersBuilder().addString("file_location", fileLoc)
                .addString("machineId", MarketingDaemonConfig.getResMachine()).addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : " + execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {
                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                MarketingDaemonBatchUtils.moveFileToError(fileLoc);
            }
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.BatchJobEntry#runJob(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void runJob(String jobName, String fileLoc, String outPutFilename) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);

        String newFileNameStr = new StringBuilder().append(outPutFilename.split("\\.")[0])
                .append(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date())).append("." + outPutFilename.split("\\.")[1]).append(".part")
                .toString();

        logger.info(newFileNameStr);

        JobParameters jobParams = new JobParametersBuilder().addString("file_location", fileLoc).addString("file_name", newFileNameStr)
                .addString("machineId", MarketingDaemonConfig.getResMachine()).addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : " + execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {

                File sourceFile = new File(fileLoc + File.separator + newFileNameStr);
                Path newFile = Paths.get(sourceFile.getAbsolutePath());
                if (sourceFile.isFile()) {
                    int lastIndex = sourceFile.getName().lastIndexOf('.');
                    String newFileName = sourceFile.getName().substring(0, lastIndex);
                    Files.move(newFile, newFile.resolveSibling(newFileName));
                }
                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                MarketingDaemonBatchUtils.moveFileToError(fileLoc);
            }
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.BatchJobEntry#runJob(java.lang.String, java.lang.String, java.io.File)
     */
    @Override
    public void runJob(String jobName, String fileLoc, File outPutDir) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);

        JobParameters jobParams = new JobParametersBuilder().addString("file_location", fileLoc)
                .addString("out_file_location", outPutDir.getAbsolutePath()).addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : " + execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {
                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                MarketingDaemonBatchUtils.moveFileToError(fileLoc);
            }
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.BatchJobEntry#runJobWithFileDirAndFileName(java.lang.String, java.lang.String, java.io.File, java.lang.String,
     *      java.lang.Long, java.lang.String)
     */
    @Override
    public void runJobWithFileDirAndFileName(String jobName, String fileLoc, File outputDirectory, String outputfileName, Long processChunkSize,
            String clientName, String uniqueIdentifier, String fsFlagFileName) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);

        JobParameters jobParams = new JobParametersBuilder().addString("file_location", fileLoc)
                .addString("out_file_location", outputDirectory.getAbsolutePath()).addString("file_name", outputfileName)
                .addLong("NO_RECORDS_PER_FILE", processChunkSize).addString("client_name", clientName).addLong("time", System.currentTimeMillis())
                .addString("unique_identifier", uniqueIdentifier).addString("fs_flag_file_name", fsFlagFileName).toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : " + execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {
                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                MarketingDaemonBatchUtils.moveFileToError(fileLoc);
            }
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.inetpsa.w7t.batch.util.BatchJobEntry#runJob(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.Long)
     */
    @Override
    public void runJob(String jobName, String fileLoc, String outPutFilename, String clientName, Long processChunkSize) {
        ApplicationContext context = SpringContextUtil.getApplicationContext();
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean(jobName);
        String[] clients = clientName.split(",");

        StringBuilder sb = new StringBuilder();
        String prefix = "";
        for (String client : clients) {
            sb.append(prefix);
            prefix = ",";
            sb.append('\'' + client + '\'');
        }
        String newFileNameStr = new StringBuilder().append(outPutFilename.split("\\.")[0])
                .append(new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date())).append("." + outPutFilename.split("\\.")[1]).append(".part")
                .toString();

        logger.info(newFileNameStr);

        JobParameters jobParams = new JobParametersBuilder().addString("file_location", fileLoc).addString("file_name", newFileNameStr)
                .addString("client_name", sb.toString()).addLong("chunk_size", processChunkSize)
                .addString("machineId", MarketingDaemonConfig.getReqMachine()).addLong("time", System.currentTimeMillis()).toJobParameters();

        try {
            JobExecution execution = jobLauncher.run(job, jobParams);

            logger.debug("Job Exit Status : " + execution.getStatus());
            if (execution.getStatus().equals(BatchStatus.COMPLETED)) {
                File sourceFile = new File(fileLoc + File.separator + newFileNameStr);
                Path newFile = Paths.get(sourceFile.getAbsolutePath());
                if (sourceFile.isFile()) {
                    int lastIndex = sourceFile.getName().lastIndexOf('.');
                    String newFileName = sourceFile.getName().substring(0, lastIndex);
                    Files.move(newFile, newFile.resolveSibling(newFileName));
                }

                logger.debug("Job ({}) completed ", jobName);
            }
            if (execution.getStatus().equals(BatchStatus.FAILED)) {
                logger.error("Job ({}) failed with error code ({}) ", jobName, execution.getExitStatus());
                MarketingDaemonBatchUtils.moveFileToError(fileLoc);
                if (fileConfigUtilService != null) {
                    MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), clientName);
                }
            }
        } catch (JobExecutionException | IOException e) {
            logger.error("Job Exit Exception : ", e);
        }
    }

}
