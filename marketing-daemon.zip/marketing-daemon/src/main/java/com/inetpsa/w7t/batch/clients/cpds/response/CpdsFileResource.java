/*
 * Creation : 24 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class CpdsFileResource.
 */
public class CpdsFileResource extends FileSystemResource {

    /**
     * Instantiates a new cpds file resource.
     *
     * @param path the path
     * @param cpdsOtputFilename the cpds otput filename
     */
    public CpdsFileResource(String path, String cpdsOtputFilename) {
        super(path + File.separator + cpdsOtputFilename);
    }
}
