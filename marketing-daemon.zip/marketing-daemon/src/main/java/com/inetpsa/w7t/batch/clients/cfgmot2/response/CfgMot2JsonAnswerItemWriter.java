/*
 * Creation : 21 Aug 2018
 */
package com.inetpsa.w7t.batch.clients.cfgmot2.response;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Inject;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.seed.SeedException;
import org.seedstack.shed.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inetpsa.w7t.batch.clients.aogeos.response.AoCronosEliadeDto;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestRepository;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarketingDaemonCalculatorService;
import com.inetpsa.w7t.batch.shared.MarketingDaemonWltpHubService;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequest;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestAnswerDTO;
import com.inetpsa.w7t.domain.model.dto.MarketingRequestDto;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.wltphub.ws.Result;
import com.inetpsa.w7t.wltphub.ws.WltpHubResponseRepresentation;

/**
 * The Class CfgMot2JsonAnswerItemWriter.
 */

public class CfgMot2JsonAnswerItemWriter implements ItemWriter<MarketingRequestAnswerDTO> {

    /** The engine calculator service. */
    @Inject
    private EngineCalculatorService engineCalculatorService;

    /** The marketing daemon wltp hub service. */
    @Inject
    private MarketingDaemonWltpHubService marketingDaemonWltpHubService;

    /** The calculation. */
    private Calculation calculation;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;
    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The marketing request repository. */
    @Inject
    private MarketingRequestRepository marketingRequestRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The marketing daemon calculator service. */
    @Inject
    private MarketingDaemonCalculatorService marketingDaemonCalculatorService;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** The resource. */
    private CfgMot2JsonFileResource resource;

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "cfgMot2JsonFileAnswerJob";

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The total record count. */
    private AtomicInteger totalRecordCount;

    /** The json answer list. */
    private CopyOnWriteArrayList<CfgMot2JsonResponse> jsonAnswerList = new CopyOnWriteArrayList<>();

    /** The chunk size. */
    private static final int CHUNK_SIZE = 500;

    /** The Constant SEVENTY_FIVE. */
    private static final double SEVENTY_FIVE = 75.0;

    /** The cfg mot 2 final list to update status in MRQ. */
    private CopyOnWriteArrayList<MarketingRequestDto> cfgMot2FinalListToUpdateStatusInMRQ = new CopyOnWriteArrayList<>();

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public CfgMot2JsonFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(CfgMot2JsonFileResource resource) {
        this.resource = resource;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.ItemWriter#write(java.util.List)
     */
    @Override
    public void write(List<? extends MarketingRequestAnswerDTO> request) throws Exception {
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
        logger.info("cfgMot2JsonFileAnswerJob thread pool size : [{}]", threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        totalRecordCount = new AtomicInteger(0);
        int originalListCount = 0;
        List<MarketingRequestDto> cfgMot2DtoList = new CopyOnWriteArrayList<>(request.get(0).getCfgMot2AnswerDto());
        List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();

        if (!cfgMot2DtoList.isEmpty()) {
            originalListCount = cfgMot2DtoList.size();
            logger.info("Total request count for calculation for the FILE ID [{}] is : [{}]", cfgMot2DtoList.get(0), originalListCount);
            try {
                logger.info("Parallel Processing Starts Here ...");

                List<List<MarketingRequestDto>> splitedList = ListUtils.partition(cfgMot2DtoList, CHUNK_SIZE);
                for (List<MarketingRequestDto> list : splitedList) {

                    list.forEach(answerDto -> {
                        Future<Integer> future = executorService.submit(() -> process(answerDto));
                        futuresList.add(future);
                    });
                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
            } catch (Exception e) {
                logger.error("Error when executing parallel request processing for calcualtion", e);
            } finally {
                executorService.shutdown();
            }

            logger.info("Parallel Processing Ends Here ...");

            if (!jsonAnswerList.isEmpty()) {
                try {
                    File sourceFile = new File(getResource().getFile().getAbsolutePath());
                    Path newFile = Paths.get(sourceFile.getAbsolutePath());

                    logger.info("Calculated records count for the FILE ID [{}] is : [{}] and originoal count is : [{}]",
                            cfgMot2DtoList.get(0).getFileId(), totalRecordCount, originalListCount);

                    Map<String, List<CfgMot2JsonResponse>> jsonAnswerMap = new HashMap<>();
                    jsonAnswerMap.put("WLTP-CFGMOT2", jsonAnswerList);
                    writeRejectedRequestInFile(request.get(0).getAoCronoEliadeAnswerDto().get(0).getFileId());
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
                    objectMapper.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

                    if (!jsonAnswerMap.isEmpty()) {
                        objectMapper.writeValue(getResource().getFile(), jsonAnswerMap);
                    }

                    updateFinalStatusInMRQ();

                    logger.info("Removing the .part ");
                    int lastIndex = sourceFile.getName().lastIndexOf('.');
                    String newFileName = sourceFile.getName().substring(0, lastIndex);
                    Files.move(newFile, newFile.resolveSibling(newFileName));
                    marketingRequestTrackerRepository.updateAnswerSentStatusByFileId(
                            String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()),
                            request.get(0).getAoCronoEliadeAnswerDto().get(0).getFileId());

                    if (fileConfigUtilService != null) {
                        MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(), "configMot2");
                    }

                } catch (Exception e) {
                    logger.error("ERROR: {} ", e);
                }
            } else {
                logger.info("Final List To Write In File is empty for FILE ID [{}]", cfgMot2DtoList.get(0).getFileId());
            }
        }
    }

    /**
     * Update final status in MRQ.
     */
    private void updateFinalStatusInMRQ() {

        if (!cfgMot2FinalListToUpdateStatusInMRQ.isEmpty()) {
            logger.info("Inside updateFinalStatusInMRQ()");
            try {
                int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
                logger.info("eliadeDatabaseToFlatFileJob thread pool size : [{}]", threadPoolSize);
                ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<MarketingRequestDto>> splitedList = ListUtils.partition(cfgMot2FinalListToUpdateStatusInMRQ, CHUNK_SIZE);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list -> {
                        Future<Integer> future = executorService.submit(() -> processParallelListToUpdateStatus(list));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }
                executorService.shutdown();
            } catch (Exception e) {
                logger.error("Error when executing updating status parallelly: {}", e);
            }

        }

    }

    /**
     * Process parallel list to update status.
     *
     * @param bcvNewtonRequestDtosList the bcv newton request dtos list
     * @return the int
     */
    private int processParallelListToUpdateStatus(List<MarketingRequestDto> marketingRequestDtosList) {
        marketingDaemonCalculatorService.updateAnswerDetails(marketingRequestDtosList);
        return 1;
    }

    /**
     * Process.
     *
     * @param answerDto the answer dto
     * @return the integer
     */
    private Integer process(MarketingRequestDto answerDto) {
        CfgMot2JsonResponse cfgMot2RequestDto = calculate(answerDto);
        if (cfgMot2RequestDto != null) {
            jsonAnswerList.add(cfgMot2RequestDto);
            totalRecordCount.getAndIncrement();
            cfgMot2FinalListToUpdateStatusInMRQ.add(answerDto);
        }
        return 1;
    }

    /**
     * Calculate.
     *
     * @param answerDto the answer dto
     * @return the bcv newton request dto
     */
    private CfgMot2JsonResponse calculate(MarketingRequestDto answerDto) {
        WltpHubResponseRepresentation wltpHubResponseRepresentation = null;
        CfgMot2JsonAnswerRequest cfgMot2RequestObject = new CfgMot2JsonAnswerRequest();

        if (cfgMot2RequestObject.getEcomDate() == null || cfgMot2RequestObject.getEcomDate().isEmpty())
            cfgMot2RequestObject.setEcomDate(LocalDate.now().toString());

        cfgMot2RequestObject.setVersion16C(answerDto.getVersion16());
        cfgMot2RequestObject.setColorExtInt(answerDto.getColorExtInt());
        // cfgMot2RequestObject.setExtendedTitleAttributes(answerDto.getExtAttr());
        if (answerDto.getExtensionDate() == null) {
            cfgMot2RequestObject.setExtensionDate("");
        } else {
            cfgMot2RequestObject.setExtensionDate(answerDto.getExtensionDate());
        }
        cfgMot2RequestObject.setGestion5C(answerDto.getGestion5C());
        cfgMot2RequestObject.setGestion7C(answerDto.getGestion7C());
        cfgMot2RequestObject.setRequestType(answerDto.getRequestType());
        // cfgMot2RequestObject.setMountingCenter(answerDto.getMountingCenter());
        cfgMot2RequestObject.setOptions5C(answerDto.getOptions5C());
        cfgMot2RequestObject.setOptions7C(answerDto.getOptions7C());
        cfgMot2RequestObject.setNbGestion(answerDto.getGestion());
        cfgMot2RequestObject.setNbOptions(answerDto.getOptions());
        cfgMot2RequestObject.setTradingCountry(answerDto.getTradingCountry());

        AoCronosEliadeDto aoGeosDto = mapToAoCronoEliadeDto(answerDto);

        // fixed jira-559
        try {
            wltpHubResponseRepresentation = marketingDaemonWltpHubService.callWltpHubWebService(aoGeosDto);
        } catch (SeedException se) {

            String ruleCode = "";
            String errordescription = "";
            ErrorCode errorCode = se.getErrorCode();
            if (errorCode instanceof WltpErrorCode) {
                WltpErrorCode wltpErrorCode = (WltpErrorCode) errorCode;
                ruleCode = "ERRW" + wltpErrorCode.getRuleCode();
                errordescription = wltpErrorCode.getDescription();
            } else if (errorCode instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode engineCalculatorErrorCode = (WltpEngineCalculatorErrorCode) errorCode;
                ruleCode = "ERRW" + engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            } else if (errorCode instanceof RequestErrorCode) {
                RequestErrorCode engineCalculatorErrorCode = (RequestErrorCode) errorCode;
                ruleCode = engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            }
            LogUtility.logTheError(logger, answerDto.getRequestID(), ruleCode, errordescription);

            return buildCfgMot2JsonAnswerObjectForError(cfgMot2RequestObject, ruleCode, errordescription, answerDto.getRequestID());

        }
        return buildCfgMot2JsonAnswerObject(cfgMot2RequestObject, wltpHubResponseRepresentation, answerDto.getRequestID());

    }

    private AoCronosEliadeDto mapToAoCronoEliadeDto(MarketingRequestDto marketingRequestDto) {
        AoCronosEliadeDto aoGeosDto = new AoCronosEliadeDto();
        if (aoGeosDto.getEcomDate() == null || aoGeosDto.getEcomDate().isEmpty())
            aoGeosDto.setEcomDate(LocalDate.now().toString());
        if (StringUtils.isNotBlank(marketingRequestDto.getRequestID())) {
            aoGeosDto.setRequestId(marketingRequestDto.getRequestID());
        }
        aoGeosDto.setVersion16(marketingRequestDto.getVersion16());
        aoGeosDto.setColorExtInt(marketingRequestDto.getColorExtInt());
        aoGeosDto.setTradingCountry(marketingRequestDto.getTradingCountry());
        aoGeosDto.setRequestType(marketingRequestDto.getRequestType());
        // aoGeosDto.setAvoidCache(avoidCacheValue);

        return aoGeosDto;
    }

    /**
     * Builds the cfg mot 2 json answer object for error.
     *
     * @param cfgMot2RequestObject the cfg mot 2 request object
     * @param errorCode the error code
     * @param description the description
     * @param requestID the request ID
     * @return the cfg mot 2 json response
     */
    private CfgMot2JsonResponse buildCfgMot2JsonAnswerObjectForError(CfgMot2JsonAnswerRequest cfgMot2RequestObject, String errorCode,
            String description, String requestID) {
        CfgMot2JsonResponse responseObject = new CfgMot2JsonResponse();
        responseObject.setRequest(cfgMot2RequestObject);
        responseObject.setAnswer(new CfgMot2JsonAnswer(errorCode, description));
        LogUtility.logTheError(logger, requestID, errorCode, description);
        return responseObject;
    }

    /**
     * Builds the cfg mot 2 json answer object.
     *
     * @param cfgMot2JsonAnswerRequest the cfg mot 2 json answer request
     * @param wltpHubResponseRepresentation the calculation results
     * @param enginePhysicalQuantities the engine physical quantities
     * @param requestID the request ID
     * @return the cfg mot 2 json response
     */
    private CfgMot2JsonResponse buildCfgMot2JsonAnswerObject(CfgMot2JsonAnswerRequest cfgMot2JsonAnswerRequest,
            WltpHubResponseRepresentation wltpHubResponseRepresentation, String requestID) {

        CfgMot2JsonResponse responseObject = new CfgMot2JsonResponse();
        responseObject.setRequest(cfgMot2JsonAnswerRequest);
        responseObject.setAnswer(
                new CfgMot2JsonAnswer(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_CFGMOT2, MarketingDaemonServiceConstants.SUCCESS_DESIGNATION));

        if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getWltpData()) {
            CfgMot2JsonData wltpData = new CfgMot2JsonData();
            wltpData.setCategory(wltpHubResponseRepresentation.getWltpData().getCategory());
            wltpData.setDestination(wltpHubResponseRepresentation.getWltpData().getDestination());
            wltpData.setVehType(wltpHubResponseRepresentation.getWltpData().getVehType());
            responseObject.setWltpData(wltpData);
        }

        if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getAnswer()) {
            CfgMot2JsonAnswer answer = new CfgMot2JsonAnswer();
            answer.setCode(wltpHubResponseRepresentation.getAnswer().getCode());
            answer.setDesignation(wltpHubResponseRepresentation.getAnswer().getDesignation());
            responseObject.setAnswer(answer);
        }
        if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getPhase()) {
            List<CfgMot2JsonPhase> phases = new ArrayList<>();
            wltpHubResponseRepresentation.getPhase().forEach(phase -> {
                CfgMot2JsonPhase cfgmot2Phase = new CfgMot2JsonPhase();
                cfgmot2Phase.setCode(phase.getCode());
                cfgmot2Phase.setResult(getPhaseResult(phase.getResult()));
            });
            responseObject.setPhase(phases);
        }
        if (null != wltpHubResponseRepresentation && null != wltpHubResponseRepresentation.getPhysResult()) {
            List<CfgMot2JsonPhysicalResult> phyResults = new ArrayList<>();
            wltpHubResponseRepresentation.getPhysResult().forEach(phResult -> {
                CfgMot2JsonPhysicalResult cfgmot2PhyResult = new CfgMot2JsonPhysicalResult();
                cfgmot2PhyResult.setCode(phResult.getCode());
                cfgmot2PhyResult.setValue(phResult.getValue());
                phyResults.add(cfgmot2PhyResult);
            });
            responseObject.setPhysResult(phyResults);
        }

        logger.info("REQUEST_ID =[{}] - Calculated answer sent to the file", requestID);
        return responseObject;

    }

    private List<CfgMot2JsonResult> getPhaseResult(List<Result> result) {
        List<CfgMot2JsonResult> phaseResultList = new ArrayList<>();
        result.forEach(phaseResult -> {
            CfgMot2JsonResult cfgmot2Result = new CfgMot2JsonResult();
            cfgmot2Result.setCode(phaseResult.getCode());
            cfgmot2Result.setValue(phaseResult.getValue());
            phaseResultList.add(cfgmot2Result);
        });
        return phaseResultList;
    }

    /**
     * Gets the phase result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the phy result in format.
     *
     * @param code the code
     * @param value the value
     * @return the phy result in format
     */
    private String getPhyResultInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = pattern.length() < 2 ? 0 : pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * Write rejected request in file.
     *
     * @param fileId the file id
     */
    private void writeRejectedRequestInFile(String fileId) {
        List<MarketingRequest> rejectedRequestList = marketingRequestRepository.byClientAndStatusAndFileId(
                MarketingDaemonServiceConstants.CONFIG_MOT2.toUpperCase(),
                String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()), fileId);

        rejectedRequestList.forEach(rejectedRequest -> {
            jsonAnswerList.add(mapRequestToDto(rejectedRequest));
            totalRecordCount.getAndIncrement();

            MarketingRequestDto marketingRequestDto = new MarketingRequestDto();
            marketingRequestDto.setRequestID(rejectedRequest.getRequestID());
            marketingRequestDto.setStatus(rejectedRequest.getStatus());
            marketingRequestDto.setAnswerCode(rejectedRequest.getAnswerCode());
            marketingRequestDto.setAnswerDesig(rejectedRequest.getAnswerDesig());
            cfgMot2FinalListToUpdateStatusInMRQ.add(marketingRequestDto);
            // marketingRequest = null;
            marketingRequestDto = null;
        });
    }

    /**
     * Map request to dto.
     *
     * @param rejectedRequest the rejected request
     * @return the cfg mot 2 json response
     */
    private CfgMot2JsonResponse mapRequestToDto(MarketingRequest rejectedRequest) {
        CfgMot2JsonAnswerRequest cfgMot2JsonAnswerRequest = new CfgMot2JsonAnswerRequest();
        cfgMot2JsonAnswerRequest.setVersion16C(rejectedRequest.getVersion16());
        cfgMot2JsonAnswerRequest.setColorExtInt(rejectedRequest.getColorExtInt());
        cfgMot2JsonAnswerRequest.setRequestType(rejectedRequest.getRequestType());
        cfgMot2JsonAnswerRequest.setOptions5C(rejectedRequest.getOptions5C());
        cfgMot2JsonAnswerRequest.setOptions7C(rejectedRequest.getOptions7C());
        cfgMot2JsonAnswerRequest.setNbOptions(rejectedRequest.getOptions());
        cfgMot2JsonAnswerRequest.setTradingCountry(rejectedRequest.getTradingCountry());
        return buildCfgMot2JsonAnswerObjectForError(cfgMot2JsonAnswerRequest, rejectedRequest.getAnswerCode(), rejectedRequest.getAnswerDesig(),
                rejectedRequest.getRequestID());
    }

    /**
     * Log and create exception.
     *
     * @param requestId the request id
     * @param errorCode the error code
     * @return the seed exception
     */
    private SeedException logAndCreateException(String requestId, RequestErrorCode errorCode) {
        LogUtility.logTheError(logger, requestId, errorCode.getRuleCode(), errorCode.getDescription());
        return SeedException.createNew(errorCode);
    }
}
