/*
 * Creation : 14 Jan 2019
 */
/**
 * 
 */
package com.inetpsa.w7t.batch.shared;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class AoCronoEliadeUtility.
 *
 * @author E534811
 */
public class AoCronoEliadeUtility {

    /** The Constant HEADER_CODE. */
    private static final String HEADER_CODE = "0000"; // 4 char

    /** The Constant SENDING_SITE. */
    private static final String SITE = "WLTP     "; // 9 char

    /** The Constant SENDING_APPLICATION. */
    private static final String APPLICATION = "WLTP    "; // 8 char

    /** The df. */
    DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyyMMdd"); // 8 char

    /** The Constant FOOTER_CODE. */
    private static final String FOOTER_CODE = "9999"; // 4 char

    /** The logger. */
    private static Logger logger = LoggerFactory.getLogger(AoCronoEliadeUtility.class);

    private static final int NINE = 9;

    private static final int EIGHT = 8;

    private static final int FIVE = 5;

    /**
     * Generate header.
     *
     * @param sendingSite the sending site
     * @param sendingApplication the sending application
     * @param headerLotNumber the header lot number
     * @param lotDate the lot date
     * @return the string
     */
    public static String generateHeader(String sendingSite, String sendingApplication, String headerLotNumber, String lotDate) {
        String sendingSites = "";
        String sendingApp = "";
        String lotNumber = "";
        String lotDates = "";
        if (sendingSite != null && !sendingSite.isEmpty()) {
            sendingSites = sendingSite + String.join("", Collections.nCopies((NINE - sendingSite.length()), " "));
        } else {
            logger.info("The header sending site value is empty");
        }
        if (sendingApplication != null && !sendingApplication.isEmpty()) {
            sendingApp = sendingApplication + String.join("", Collections.nCopies((EIGHT - sendingApplication.length()), " "));
        } else {
            logger.info("The header sending application value is empty");
        }
        if (headerLotNumber != null && !headerLotNumber.isEmpty()) {
            lotNumber = headerLotNumber + String.join("", Collections.nCopies((FIVE - headerLotNumber.length()), " "));
        } else {
            logger.info("The header lot number is empty");
        }
        if (lotDate != null && !lotDate.isEmpty()) {
            try {
                lotDates = new SimpleDateFormat("yyyyMMdd").format(new SimpleDateFormat("yyyy-MM-dd").parse(lotDate));
            } catch (ParseException e) {
                logger.error("Exception : {}", e);
            }
        } else {
            logger.info("The header lot date is empty");
        }
        return HEADER_CODE + sendingSites + sendingApp + SITE + APPLICATION + lotNumber + lotDates + "\n";
    }

    /**
     * Generate footer.
     *
     * @param sendingSite the sending site
     * @param sendingApplication the sending application
     * @param headerLotNumber the header lot number
     * @param result the result
     * @return the string
     */
    public static String generateFooter(String sendingSite, String sendingApplication, String headerLotNumber, String result) {
        String sendingSites = "";
        String sendingApp = "";
        String lotNum = "";
        if (sendingSite != null && !sendingSite.isEmpty()) {
            sendingSites = sendingSite + String.join("", Collections.nCopies((NINE - sendingSite.length()), " "));
        } else {
            logger.info("The footer sending site value is empty");
        }
        if (sendingApplication != null && !sendingApplication.isEmpty()) {
            sendingApp = sendingApplication + String.join("", Collections.nCopies((EIGHT - sendingApplication.length()), " "));
        } else {
            logger.info("The footer sending application value is empty");
        }
        if (headerLotNumber != null && !headerLotNumber.isEmpty()) {
            lotNum = headerLotNumber + String.join("", Collections.nCopies((FIVE - headerLotNumber.length()), " "));
        } else {
            logger.info("The footer lot number is empty");
        }
        return FOOTER_CODE + sendingSites + sendingApp + SITE + APPLICATION + lotNum + result + "\n";
    }

}
