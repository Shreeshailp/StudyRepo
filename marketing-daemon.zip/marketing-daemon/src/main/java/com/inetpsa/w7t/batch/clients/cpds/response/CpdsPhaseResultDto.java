/*
 * Creation : 6 Nov 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.response;

/**
 * The Class CpdsPhaseResultDto.
 */
public class CpdsPhaseResultDto implements Comparable<CpdsPhaseResultDto> {

    /** The code. */
    private String code;

    /** The value. */
    private String value;

    /** The sort. */
    private Integer sort;

    /**
     * Instantiates a new cpds phase result dto.
     *
     * @param code the code
     * @param value the value
     * @param sort the sort
     */
    public CpdsPhaseResultDto(String code, String value, Integer sort) {
        super();
        this.code = code;
        this.value = value;
        this.sort = sort;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the code.
     *
     * @param code the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the sort.
     *
     * @return the sort
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * Sets the sort.
     *
     * @param sort the new sort
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ResultDto [code=" + code + ", value=" + value + ", sort=" + sort + "]";
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    @Override
    public int compareTo(CpdsPhaseResultDto o) {
        return this.getSort().compareTo(o.getSort());
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((sort == null) ? 0 : sort.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CpdsPhaseResultDto other = (CpdsPhaseResultDto) obj;
        if (sort == null) {
            if (other.sort != null)
                return false;
        } else if (!sort.equals(other.sort))
            return false;
        return true;
    }

}
