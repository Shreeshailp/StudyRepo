/*
 * Creation : 24 Dec 2019
 */
package com.inetpsa.w7t.batch.clients.cpds.request;

import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.phyQuantityRoundingMap;
import static com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants.resultRoundingMap;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.apache.commons.collections4.ListUtils;
import org.seedstack.seed.SeedException;
import org.seedstack.shed.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JpaItemWriter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsAnswer;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsData;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsFileResource;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsPhase;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsPhaseResultDto;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsPhysicalResult;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsRequestRepresentation;
import com.inetpsa.w7t.batch.clients.cpds.response.CpdsResponseRepresentation;
import com.inetpsa.w7t.batch.clients.cpds.response.PhysicalObjects;
import com.inetpsa.w7t.batch.clients.cpds.response.Result;
import com.inetpsa.w7t.batch.infrastructure.MarketingRequestTrackerRepository;
import com.inetpsa.w7t.batch.infrastructure.ThreadPoolMasterRepository;
import com.inetpsa.w7t.batch.shared.MarkertingDaemonUtility;
import com.inetpsa.w7t.batch.shared.MarketingDateUtil;
import com.inetpsa.w7t.batch.shared.MarketingRequestStatusEnum;
import com.inetpsa.w7t.batch.util.FileConfigUtilService;
import com.inetpsa.w7t.batch.util.MarketingDaemonBatchUtils;
import com.inetpsa.w7t.daemon.services.internal.MarketingDaemonConfig;
import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;
import com.inetpsa.w7t.daemon.services.util.LogUtility;
import com.inetpsa.w7t.domain.model.MarketingRequestTracker;
import com.inetpsa.w7t.domains.client.prd.services.FsFlagFileService;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculatedPhase.CalculatedMeasure;
import com.inetpsa.w7t.domains.engine.model.calculation.Calculation;
import com.inetpsa.w7t.domains.engine.model.calculation.CalculationConstants;
import com.inetpsa.w7t.domains.engine.model.calculation.EnginePhysicalQuantity;
import com.inetpsa.w7t.domains.engine.model.calculation.Version;
import com.inetpsa.w7t.domains.engine.model.request.RequestType;
import com.inetpsa.w7t.domains.engine.services.EngineCalculatorService;
import com.inetpsa.w7t.domains.engine.shared.RequestErrorCode;
import com.inetpsa.w7t.domains.engine.shared.WltpEngineCalculatorErrorCode;
import com.inetpsa.w7t.domains.engine.utilities.WltpErrorCode;
import com.inetpsa.w7t.domains.families.infrastructure.persistence.family.FamilyRepository;
import com.inetpsa.w7t.domains.families.model.family.Family;
import com.inetpsa.w7t.domains.references.cache.WltpCacheManager;
import com.inetpsa.w7t.domains.references.common.EmissionConstants;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.MeasureTypeRepository;
import com.inetpsa.w7t.domains.references.infrastructure.persistence.PhysicalQuantityTypeRepository;
import com.inetpsa.w7t.domains.references.model.PhysicalQuantityType;

/**
 * The Class CpdsItemWriter.
 */
public class CpdsItemWriter extends JpaItemWriter<CpdsDto> {

    /** The is code S present. */
    private boolean isCodeSPresent = false;

    /** The is code H present. */
    private boolean isCodeHPresent = false;

    /** The is code L present. */
    private boolean isCodeLPresent = false;

    /** The Constant LOW. */
    public static final String LOW = "LOW";

    /** The Constant MID. */
    public static final String MID = "MID";

    /** The Constant HIGH. */
    public static final String HIGH = "HIGH";

    /** The Constant EHIGH. */
    public static final String EHIGH = "EHIGH";

    /** The Constant COMB. */
    public static final String COMB = "COMB";

    /** The Constant CITY. */
    private static final String CITY = "CITY";

    /** The Constant JOB_NAME. */
    private static final String JOB_NAME = "cpdsJob";

    /** The resource. */
    private CpdsFileResource resource;

    /** The thread pool master repository. */
    @Inject
    ThreadPoolMasterRepository threadPoolMasterRepository;

    /** The chunk size. */
    private int chunkSize = 500;

    /** The Constant ERRW. */
    private static final String ERRW = "ERRW";

    /** The Constant SEVENTY_FIVE. */
    private static final double SEVENTY_FIVE = 75.0;

    /** The Constant NULL. */
    private static final String NULL = "null";

    /** The Constant EIGHT. */
    private static final int EIGHT = 8;

    /** The engine calculator service. */
    @Inject
    private EngineCalculatorService engineCalculatorService;

    /** The family repository. */
    @Inject
    private FamilyRepository familyRepository;
    /** The measure type repository. */
    @Inject
    private MeasureTypeRepository measureTypeRepository;

    /** The marketing request tracker repository. */
    @Inject
    private MarketingRequestTrackerRepository marketingRequestTrackerRepository;

    /** The file config util service. */
    @Inject
    private FileConfigUtilService fileConfigUtilService;

    /** the fs flag file service */
    @Inject
    private FsFlagFileService fsFlagFileService;

    /** The physical quantity type repository. */
    @Inject
    PhysicalQuantityTypeRepository physicalQuantityTypeRepository;

    /**
     * Gets the resource.
     *
     * @return the resource
     */
    public CpdsFileResource getResource() {
        return resource;
    }

    /**
     * Sets the resource.
     *
     * @param resource the new resource
     */
    public void setResource(CpdsFileResource resource) {
        this.resource = resource;
    }

    /** The logger. */
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /** The unique identifier. */
    private String uniqueIdentifier;

    /** The fs flag file name. */
    private String fsFlagFileName;

    /** The json answer list. */
    private CopyOnWriteArrayList<CpdsResponseRepresentation> jsonAnswerList = new CopyOnWriteArrayList<>();

    /**
     * Gets the unique identifier.
     *
     * @return the unique identifier
     */
    public String getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    /**
     * Sets the unique identifier.
     *
     * @param uniqueIdentifier the new unique identifier
     */
    public void setUniqueIdentifier(String uniqueIdentifier) {
        this.uniqueIdentifier = uniqueIdentifier;
    }

    /**
     * Gets the fs flag file name.
     *
     * @return the fs flag file name.
     */
    public String getFsFlagFileName() {
        return fsFlagFileName;
    }

    /**
     * Sets the fs flag file name.
     *
     * @param fsFlagFileName the fs flag file name
     */
    public void setFsFlagFileName(String fsFlagFileName) {
        this.fsFlagFileName = fsFlagFileName;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.batch.item.database.JpaItemWriter#doWrite(javax.persistence.EntityManager, java.util.List)
     */
    @Override
    public void doWrite(EntityManager entityManager, List<? extends CpdsDto> items) {
        long reqNumber = 0;
        long invalidReqNumber = 0;
        String fileId = "";
        String originalFileId = "";
        Set<CpdsDto> dtoList = new HashSet<>(items);
        List<CpdsDto> list = new CopyOnWriteArrayList<>(items);
        for (CpdsDto cpdsDto : dtoList) {
            if (cpdsDto.getStatus() != null
                    && cpdsDto.getStatus().equals(String.valueOf(MarketingRequestStatusEnum.REQUEST_REJECTED.getStatusCode()))) {
                ++invalidReqNumber;
            }

            ++reqNumber;
        }
        synchronized (CpdsItemWriter.class) {
            Optional<MarketingRequestTracker> sameDayMarketingRequest = marketingRequestTrackerRepository.bytodayLastRequestOnMachine(
                    LocalDate.now().toString(), MarketingDaemonServiceConstants.CPDS.toUpperCase(), MarketingDaemonConfig.getReqMachine());
            fileId = MarkertingDaemonUtility.generateFileIdForCpds(sameDayMarketingRequest, MarketingDaemonServiceConstants.CPDS,
                    this.uniqueIdentifier);
            originalFileId = list.get(0).getRequestId().substring(0, EIGHT);
            MarkertingDaemonUtility.createMRQTracker(fileId, MarketingDaemonServiceConstants.CPDS.toUpperCase(), reqNumber,
                    (reqNumber - invalidReqNumber), marketingRequestTrackerRepository, MarketingDaemonConfig.getReqMachine(), originalFileId);
            logger.info("===================All Records Inserted - [{}], MRQ Count [{}], BRQ count [{}]  ", new Date(), reqNumber,
                    (reqNumber - invalidReqNumber));
            // save data to W7TQTFSF table
            // Added below code as part of jira-660 fix -- start
            fsFlagFileService.saveFsFlagEntity(MarketingDaemonServiceConstants.CPDS.toUpperCase(), this.fsFlagFileName, fileId);
            // jira-660 fix -- end
        }
        int threadPoolSize = threadPoolMasterRepository.getThreadPoolSize(JOB_NAME);
        logger.info("cpdsJob thread pool size : [{}]", threadPoolSize);
        ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
        logger.debug("inside write()[START]");
        if (!list.isEmpty()) {
            try {
                logger.info("Parallel Processing Starts Here ...");
                List<Future<Integer>> futuresList = new CopyOnWriteArrayList<>();
                List<List<CpdsDto>> splitedList = ListUtils.partition(list, chunkSize);
                if (splitedList != null && !splitedList.isEmpty()) {
                    splitedList.forEach(list1 -> {
                        Future<Integer> future = executorService.submit(() -> processParallelList(list1));
                        futuresList.add(future);
                    });

                }
                for (Future<Integer> future : futuresList) {
                    future.get();

                }

            } catch (Exception e) {
                logger.error("Error when executing parallel request processing for calcualtion : {}", e);
            } finally {
                executorService.shutdown();
            }

            logger.info("Parallel Processing Ends Here ...");
            if (!jsonAnswerList.isEmpty()) {
                // fixed jira-659 starts here
                Long koCount = jsonAnswerList.stream().filter(response -> response.getAnswer().getCode().contains("ERRW")).count();
                Long okCount = jsonAnswerList.stream().filter(response -> response.getAnswer().getCode().contains("OK")).count();
                logger.info("File Summary : No. of Request Received=[{}], No. of Calculation OK=[{}], No. Of Errors=[{}], No. of Answer sent=[{}]",
                        jsonAnswerList.size(), okCount, koCount, okCount + koCount);
                // fixed jira-659 ends here

                try {

                    File sourceFile = new File(getResource().getFile().getAbsolutePath());
                    Path newFile = Paths.get(sourceFile.getAbsolutePath());

                    Map<String, List<CpdsResponseRepresentation>> jsonAnswerMap = new HashMap<>();
                    jsonAnswerMap.put("WLTP-MINMAX", jsonAnswerList);
                    ObjectMapper objectMapper = new ObjectMapper();
                    objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
                    objectMapper.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

                    if (!jsonAnswerMap.isEmpty()) {
                        objectMapper.writeValue(getResource().getFile(), jsonAnswerMap);
                        logger.info("CPDS Json Response file generated");
                    }

                    logger.info("Removing the .part ");
                    int lastIndex = sourceFile.getName().lastIndexOf('.');
                    String newFileName = sourceFile.getName().substring(0, lastIndex);
                    String extension = sourceFile.getName().substring(lastIndex, sourceFile.getName().length());
                    Files.move(newFile, newFile.resolveSibling(newFileName + MarketingDateUtil.getTodaysDateforCo2MinMax() + extension));
                    marketingRequestTrackerRepository
                            .updateAnswerSentStatusByFileId(String.valueOf(MarketingRequestStatusEnum.ANSWER_SENT.getStatusCode()), fileId);
                    if (fileConfigUtilService != null && this.fsFlagFileName != null) {
                        // Added below code as part of jira-660 fix -- start
                        MarketingDaemonBatchUtils.deleteApplicationFsFlagFile(fileConfigUtilService.getFsFlagPath(),
                                MarketingDaemonServiceConstants.CPDS.toLowerCase(), this.fsFlagFileName);
                        int result = fsFlagFileService.deleteFsFlagFileByFileId(fileId);
                        if (result > 0) {
                            logger.info("FsFlagFileName: [{}] deleted from database table ", this.fsFlagFileName);
                        }
                        // jira-660 fix -- end
                    }
                } catch (Exception e) {
                    logger.error("ERROR: {} ", e);
                }
            } else {
                logger.info("Final List To Write In File is empty ");
            }
        }
        logger.debug("inside write()[END]");
    }

    /**
     * Builds the error answer.
     *
     * @param cpdsDto    the cpds dto
     * @param errorCode  the error code
     * @param errorDesig the error desig
     * @return the cpds response representation
     */
    private CpdsResponseRepresentation buildErrorAnswer(CpdsDto cpdsDto, String errorCode, String errorDesig) {
        // fixed jira-661 and jira-666
        logger.info("Request ID[{}]: AnswerCode=[{}], AnswerDesignation=[{}]", cpdsDto.getRequestId(), errorCode, errorDesig);
        CpdsResponseRepresentation cpdsResponseRepresentation = new CpdsResponseRepresentation();
        getCpdsResponse(cpdsDto, cpdsResponseRepresentation);
        CpdsAnswer answer = new CpdsAnswer();
        answer.setCode(errorCode);
        answer.setDesignation(errorDesig);
        cpdsResponseRepresentation.setAnswer(answer);
        return cpdsResponseRepresentation;
    }

    /**
     * Gets the cpds response.
     *
     * @param cpdsDto        the cpds dto
     * @param responseObject the response object
     * @return the cpds response
     */
    private CpdsResponseRepresentation getCpdsResponse(CpdsDto cpdsDto, CpdsResponseRepresentation responseObject) {
        CpdsRequestRepresentation cpdsRequestRepresentation = new CpdsRequestRepresentation();
        cpdsRequestRepresentation.setRequestId(cpdsDto.getRequestId());
        cpdsRequestRepresentation.setVersion16C(cpdsDto.getVersion16());
        cpdsRequestRepresentation.setColorExtInt(cpdsDto.getColorExtInt());
        cpdsRequestRepresentation.setRequestType(cpdsDto.getRequestType());
        cpdsRequestRepresentation.setEcomDate(cpdsDto.getEcomDate());
        cpdsRequestRepresentation.setCountry(cpdsDto.getCountry());
        cpdsRequestRepresentation.setExtendedTitleAttributes(cpdsDto.getExtAttr());

        List<PhysicalObjects> physicalObjects = new ArrayList<>();

        PhysicalObjects phyObj1 = new PhysicalObjects();
        phyObj1.setPropertyName(CalculationConstants.MASS_CODE);
        phyObj1.setValue(cpdsDto.getVehicleMass().toString());
        physicalObjects.add(phyObj1);

        PhysicalObjects phyObj2 = new PhysicalObjects();
        phyObj2.setPropertyName(CalculationConstants.CRR_CODE);
        phyObj2.setValue(cpdsDto.getVehicleCRR().toString());
        physicalObjects.add(phyObj2);

        PhysicalObjects phyObj3 = new PhysicalObjects();
        phyObj3.setPropertyName(CalculationConstants.SCX_CODE);
        phyObj3.setValue(cpdsDto.getVehicleSCX().toString());
        physicalObjects.add(phyObj3);

        cpdsRequestRepresentation.setPhysicalObjects(physicalObjects);

        responseObject.setRequest(cpdsRequestRepresentation);
        return responseObject;
    }

    /**
     * Process parallel list.
     *
     * @param list the list
     * @return the int
     */
    private int processParallelList(List<CpdsDto> list) {
        for (CpdsDto cpdsDto : list) {
            if (cpdsDto.getStatus() == null) {
                calculate(cpdsDto);
            } else {
                jsonAnswerList.add(buildErrorAnswer(cpdsDto, cpdsDto.getAnswerCode(), cpdsDto.getAnswerDesignation()));
            }
        }
        return 1;
    }

    /**
     * Calculate.
     *
     * @param answerDto the answer dto
     */
    private void calculate(CpdsDto answerDto) {
        try {
            Calculation calculation = null;
            RequestType requestType = null;
            String tempRequestType = answerDto.getRequestType().trim();

            if (tempRequestType.equalsIgnoreCase(RequestType.FULL.name())) {
                requestType = RequestType.FULL;
            } else if (tempRequestType.equalsIgnoreCase(RequestType.COMB.name())) {
                requestType = RequestType.COMB;
            } else {
                requestType = RequestType.TEST;
            }

            logger.info("Request ID[{}]: RequestType : {} ", answerDto.getRequestId(), requestType);
            if (answerDto.getEcomDate() == null || answerDto.getEcomDate().isEmpty())
                answerDto.setEcomDate(LocalDate.now().toString());

            answerDto.setRequestType(requestType.name());
            // fixed jira-672
            logger.info("Request ID[{}]: ExtendedTitleAttributes : {} ", answerDto.getRequestId(), answerDto.getExtAttr());
            // Added the below 2 lines of the code as part of the JIRA-654 fix and ecomdate is passed to the Version constructor below..
            LocalDate ecomDate = LocalDate.parse(answerDto.getEcomDate());
            logger.info("Request ID[{}]: ECOMDATE from request file is : {} ", answerDto.getRequestId(), ecomDate);

            String fullExtendedTitle = answerDto.getVersion16() + answerDto.getColorExtInt() + answerDto.getExtAttr();
            Version version = new Version(ecomDate, fullExtendedTitle, requestType, "GA1");
            version.setTradingCountry(answerDto.getCountry());

            List<EnginePhysicalQuantity> physicalQuantities = new ArrayList<>();
            physicalQuantities.add(new EnginePhysicalQuantity(CalculationConstants.MASS_CODE, answerDto.getVehicleMass()));
            physicalQuantities.add(new EnginePhysicalQuantity(CalculationConstants.CRR_CODE, answerDto.getVehicleCRR()));
            physicalQuantities.add(new EnginePhysicalQuantity(CalculationConstants.SCX_CODE, answerDto.getVehicleSCX()));
            answerDto.setPhysicalQuantities(physicalQuantities);
            calculation = engineCalculatorService.calculate(version, answerDto.physicalQuantities().orElseThrow(
                    () -> logAndCreateException(answerDto.getRequestId(), RequestErrorCode.PHYSICAL_DATA_MISSING)), answerDto.getRequestId());
            jsonAnswerList.add(buildCpdsJsonAnswerObject(answerDto, calculation, answerDto.getPhysicalQuantities(), answerDto.getRequestId()));

        } catch (SeedException se) {
            String ruleCode = "";
            String errordescription = "";
            ErrorCode errorCode = se.getErrorCode();
            if (errorCode instanceof WltpErrorCode) {
                WltpErrorCode wltpErrorCode = (WltpErrorCode) errorCode;
                ruleCode = ERRW + wltpErrorCode.getRuleCode();
                errordescription = wltpErrorCode.getDescription();
            } else if (errorCode instanceof WltpEngineCalculatorErrorCode) {
                WltpEngineCalculatorErrorCode engineCalculatorErrorCode = (WltpEngineCalculatorErrorCode) errorCode;
                ruleCode = ERRW + engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            } else if (errorCode instanceof RequestErrorCode) {
                RequestErrorCode engineCalculatorErrorCode = (RequestErrorCode) errorCode;
                ruleCode = engineCalculatorErrorCode.getRuleCode();
                errordescription = engineCalculatorErrorCode.getDescription();
            }
            LogUtility.logTheError(logger, answerDto.getRequestId(), ruleCode, errordescription);
            jsonAnswerList.add(buildErrorAnswer(answerDto, ruleCode, errordescription));

        } catch (Exception e) {
            logger.error("Error : {}", e);
        }
    }

    /**
     * Builds the cpds json answer object.
     *
     * @param cpdsRequest              the cpds request
     * @param calculationResults       the calculation results
     * @param enginePhysicalQuantities the engine physical quantities
     * @param requestID                the request ID
     * @return the cpds response representation
     */
    private CpdsResponseRepresentation buildCpdsJsonAnswerObject(CpdsDto cpdsRequest, Calculation calculationResults,
            List<EnginePhysicalQuantity> enginePhysicalQuantities, String requestID) {
        CpdsResponseRepresentation response = new CpdsResponseRepresentation();
        response = getCpdsResponse(cpdsRequest, response);
        CpdsAnswer wsAnswer = new CpdsAnswer();
        wsAnswer.setCode(MarketingDaemonServiceConstants.SUCCESS_CODE_FOR_CFGMOT2);
        wsAnswer.setDesignation(MarketingDaemonServiceConstants.SUCCESS_DESIGNATION);
        // fixed jira-661
        logger.info("Request ID[{}]: AnswerCode=[{}], AnswerDesignation=[{}]", requestID, wsAnswer.getCode(), wsAnswer.getDesignation());
        response.setAnswer(wsAnswer);
        logger.info("Request ID[{}]: Calculated answer sent to the file", requestID);
        String code = calculationResults.getVersion().getFamily(requestID);
        logger.info("Request ID[{}]: Family Code : {} ", requestID, code);
        Integer index = Integer.valueOf(calculationResults.getVersion().getIndex(requestID));
        logger.info("Request ID[{}]: Family Index : {} ", requestID, index);
        Optional<Family> fam = familyRepository.byCodeAndIndex(code, index);
        logger.info("Request ID[{}]: WLTP Family : {} ", requestID, fam);
        if (fam.isPresent()) {
            CpdsData wData = new CpdsData();
            wData.setDestination(calculationResults.getReferences().getDestination().getLabel());
            wData.setCategory(calculationResults.getTvvDetails().getTvvVehicleCategory());
            wData.setVehType(fam.get().getType());
            logger.info("Request ID[{}]: WLTP Data : {}", requestID, wData);
            response.setWltpData(wData);
        }

        List<EnginePhysicalQuantity> engineQuantities = enginePhysicalQuantities;
        logger.info("Request ID[{}]: EnginePhysicalQuantites : {}", requestID, engineQuantities);
        calculationResults.getCalculatedData().getRoadLoad().ifPresent(engineQuantities::addAll);

        List<CpdsPhysicalResult> wltpPhyResults = new ArrayList<>();
        engineQuantities.stream().forEach(eq -> {
            CpdsPhysicalResult phyResult = new CpdsPhysicalResult();

            if (CalculationConstants.F0_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
            if (CalculationConstants.F1_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
            if (CalculationConstants.F2_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
        });

        engineQuantities.stream().forEach(eq -> {
            CpdsPhysicalResult phyResult = new CpdsPhysicalResult();
            if (CalculationConstants.MASS_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                eq.setValue(eq.getValue() + SEVENTY_FIVE);
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
        });
        calculationResults.getCalculatedData().getTestMass().map(tm -> {
            CpdsPhysicalResult pr = new CpdsPhysicalResult();
            pr.setCode(CalculationConstants.TMASS_CODE);
            pr.setValue(tm.toString());
            return pr;
        }).ifPresent(wltpPhyResults::add);

        engineQuantities.stream().forEach(eq -> {
            CpdsPhysicalResult phyResult = new CpdsPhysicalResult();

            if (CalculationConstants.SCX_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
        });

        engineQuantities.stream().forEach(eq -> {
            CpdsPhysicalResult phyResult = new CpdsPhysicalResult();
            if (CalculationConstants.CRR_CODE.equals(eq.getCode())) {
                phyResult.setCode(eq.getCode());
                phyResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                wltpPhyResults.add(phyResult);
            }
        });
        String tempSValue = "";
        String tempHValue = "";
        String tempLValue = "";
        if (enginePhysicalQuantities != null) {
            enginePhysicalQuantities.stream().forEach(eq -> {
                CpdsPhysicalResult physResult = new CpdsPhysicalResult();
                if (CalculationConstants.S.equals(eq.getCode())) {
                    physResult.setCode(eq.getCode());
                    physResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                    wltpPhyResults.add(physResult);
                    isCodeSPresent = true;
                }
                if (CalculationConstants.H.equals(eq.getCode())) {
                    physResult.setCode(eq.getCode());
                    physResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                    wltpPhyResults.add(physResult);
                    isCodeHPresent = true;
                }
                if (CalculationConstants.L.equals(eq.getCode())) {
                    physResult.setCode(eq.getCode());
                    physResult.setValue(getPhyResultInFormat(eq.getCode(), eq.getValue()));
                    wltpPhyResults.add(physResult);
                    isCodeLPresent = true;
                }

            });
        }

        // JIRA-CALCULWLTP-480 Fix Ends here
        if (calculationResults.getTvvDetails() != null) {
            tempSValue = String.valueOf(calculationResults.getTvvDetails().getTvvAf());
            tempLValue = String.valueOf(calculationResults.getTvvDetails().getTvvWidth());
            tempHValue = String.valueOf(calculationResults.getTvvDetails().getTvvHeigth());
        }
        if (!isCodeSPresent && !tempSValue.equalsIgnoreCase(NULL) && !tempSValue.isEmpty()) {
            CpdsPhysicalResult sPhysicalResult = new CpdsPhysicalResult();
            sPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.S));
            sPhysicalResult.setValue(tempSValue);
            wltpPhyResults.add(sPhysicalResult);

        }

        if (!isCodeHPresent && !tempHValue.equalsIgnoreCase(NULL) && !tempHValue.isEmpty()) {
            CpdsPhysicalResult hPhysicalResult = new CpdsPhysicalResult();
            hPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.H));
            hPhysicalResult.setValue(tempHValue);
            wltpPhyResults.add(hPhysicalResult);

        }

        if (!isCodeLPresent && !tempLValue.equalsIgnoreCase(NULL) && !tempLValue.isEmpty()) {
            CpdsPhysicalResult lPhysicalResult = new CpdsPhysicalResult();
            lPhysicalResult.setCode(getPhysicalQuantityTypeCode(CalculationConstants.L));
            lPhysicalResult.setValue(tempLValue);
            wltpPhyResults.add(lPhysicalResult);
        }

        if (fam.isPresent()) {
            CpdsPhysicalResult pr = new CpdsPhysicalResult();
            pr.setCode(CalculationConstants.ROADLOAD_TYPE);
            pr.setValue(fam.get().getRoadLoad());
            wltpPhyResults.add(pr);
        }

        if (calculationResults.getTvvDetails().getTvvCompleteFlag() != null) {
            String complFlag = calculationResults.getTvvDetails().getTvvCompleteFlag();
            CpdsPhysicalResult cfl = new CpdsPhysicalResult();
            cfl.setCode(CalculationConstants.COMPL);
            cfl.setValue(complFlag);
            wltpPhyResults.add(cfl);
        }

        CpdsPhysicalResult mtac = new CpdsPhysicalResult();
        mtac.setCode(CalculationConstants.MTAC);
        mtac.setValue(calculationResults.getmTac());
        wltpPhyResults.add(mtac);

        CpdsPhysicalResult mOPT = new CpdsPhysicalResult();
        mOPT.setCode(CalculationConstants.MOPT);
        mOPT.setValue(calculationResults.getmOPT());
        wltpPhyResults.add(mOPT);

        CpdsPhysicalResult emptyMass = new CpdsPhysicalResult();
        emptyMass.setCode(CalculationConstants.EMPTYM);
        emptyMass.setValue(calculationResults.getEmptyMass());
        wltpPhyResults.add(emptyMass);

        if (!calculationResults.getCalculatedData().getSpeedLimitFlag().isEmpty()) {
            String speedLimitFlag = calculationResults.getCalculatedData().getSpeedLimitFlag();
            CpdsPhysicalResult speedLimit = new CpdsPhysicalResult();
            speedLimit.setCode(CalculationConstants.SPEEDLIMIT);
            speedLimit.setValue(speedLimitFlag);
            wltpPhyResults.add(speedLimit);
        }

        if (calculationResults.getCalculatedData().getfDownScale() != null) {
            String fDownscale = String.valueOf(calculationResults.getCalculatedData().getfDownScale());
            CpdsPhysicalResult fdsc = new CpdsPhysicalResult();
            fdsc.setCode(CalculationConstants.FDSC);
            fdsc.setValue(fDownscale);
            wltpPhyResults.add(fdsc);
        }

        if (!calculationResults.getCalculatedData().getvMax().isEmpty()) {
            String vMaxValue = calculationResults.getCalculatedData().getvMax();
            CpdsPhysicalResult vmax = new CpdsPhysicalResult();
            vmax.setCode(CalculationConstants.VMAX);
            vmax.setValue(vMaxValue);
            wltpPhyResults.add(vmax);
        }
        if (cpdsRequest.getMaturity() != null && !cpdsRequest.getMaturity().isEmpty()) {
            CpdsPhysicalResult maturity = new CpdsPhysicalResult();
            maturity.setCode(CalculationConstants.MATURITY);
            maturity.setValue(cpdsRequest.getMaturity());
            wltpPhyResults.add(maturity);
        }
        response.setPhysResult(wltpPhyResults);

        logger.info("Request ID[{}]: Physical Results : {}", requestID, wltpPhyResults);
        response.setPhysResult(wltpPhyResults);

        List<CpdsPhase> phList = new ArrayList<>();
        Optional<List<CalculatedPhase>> results = calculationResults.getCalculatedData().getCalculatedPhases();
        if (results.isPresent()) {
            List<CalculatedPhase> calculatedPhases = results.get();
            calculatedPhases.forEach(calculatedPhase -> {
                CpdsPhase ph = new CpdsPhase();
                ph.setCode(calculatedPhase.getPhaseCode());
                ph.setResult(getPhaseResults(calculatedPhase.emissions()));
                phList.add(ph);
            });
            logger.info("Request ID[{}]: CalculationResults : {}", requestID, phList);

            response.setPhase(getSortedPhaseList(phList));
        }
        return response;
    }

    /**
     * Gets the phase results.
     *
     * @param emissions the emissions
     * @return the phase results
     */
    private List<Result> getPhaseResults(List<CalculatedMeasure> emissions) {
        List<Result> phaseResultList = new ArrayList<>();
        Set<CpdsPhaseResultDto> emissionSet = new TreeSet<>();
        emissions.forEach(e -> {
            getSortedEmissions(e, emissionSet);

        });
        List<CpdsPhaseResultDto> resultList = new ArrayList<>(emissionSet);
        resultList.stream().forEach(r -> {
            Result phaseResult = new Result();
            phaseResult.setCode(r.getCode());
            phaseResult.setValue(getPhaseResultInFormat(r.getCode(), Double.valueOf(r.getValue())));

            phaseResultList.add(phaseResult);
        });

        return phaseResultList;
    }

    /**
     * Gets the sorted emissions.
     *
     * @param emission    the emission
     * @param emissionSet the emission set
     * @return the sorted emissions
     */
    private void getSortedEmissions(CalculatedMeasure emission, Set<CpdsPhaseResultDto> emissionSet) {

        if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CE)) {
            CpdsPhaseResultDto resultCE = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 0);
            emissionSet.add(resultCE);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FC)) {
            CpdsPhaseResultDto resultFC = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 1);
            emissionSet.add(resultFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCB)) {
            CpdsPhaseResultDto resultFCB = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 2);
            emissionSet.add(resultFCB);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCG)) {
            CpdsPhaseResultDto resultFCG = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 3);
            emissionSet.add(resultFCG);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2)) {
            CpdsPhaseResultDto resultCO2 = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 4);
            emissionSet.add(resultCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2B)) {
            CpdsPhaseResultDto resultCO2B = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 5);
            emissionSet.add(resultCO2B);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2G)) {
            CpdsPhaseResultDto resultCO2G = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 6);
            emissionSet.add(resultCO2G);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EC)) {
            CpdsPhaseResultDto resultEC = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 7);
            emissionSet.add(resultEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.PER)) {
            CpdsPhaseResultDto resultPER = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 8);
            emissionSet.add(resultPER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCS)) {
            CpdsPhaseResultDto resultFCCS = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 9);
            emissionSet.add(resultFCCS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CS)) {
            CpdsPhaseResultDto resultCO2CS = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 10);
            emissionSet.add(resultCO2CS);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.FCCD)) {
            CpdsPhaseResultDto resultFCCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 11);
            emissionSet.add(resultFCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CO2CD)) {
            CpdsPhaseResultDto resultCO2CD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 12);
            emissionSet.add(resultCO2CD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECCD)) {
            CpdsPhaseResultDto resultECCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 13);
            emissionSet.add(resultECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFECCD)) {
            CpdsPhaseResultDto resultUFECCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 14);
            emissionSet.add(resultUFECCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCFC)) {
            CpdsPhaseResultDto resultWCFC = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 15);
            emissionSet.add(resultWCFC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.WCCO2)) {
            CpdsPhaseResultDto resultWCCO2 = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 16);
            emissionSet.add(resultWCCO2);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.UFEC)) {
            CpdsPhaseResultDto resultUFEC = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 17);
            emissionSet.add(resultUFEC);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AER)) {
            CpdsPhaseResultDto resultAER = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 18);
            emissionSet.add(resultAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.EAER)) {
            CpdsPhaseResultDto resultEAER = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 19);
            emissionSet.add(resultEAER);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.AERCD)) {
            CpdsPhaseResultDto resultAERCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 20);
            emissionSet.add(resultAERCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.CRCD)) {
            CpdsPhaseResultDto resultCRCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 21);
            emissionSet.add(resultCRCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDCCD)) {
            CpdsPhaseResultDto resultECDCCD = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 22);
            emissionSet.add(resultECDCCD);
        } else if (emission.getMeasureTypeCode().equalsIgnoreCase(EmissionConstants.ECDC)) {
            CpdsPhaseResultDto resultECDC = new CpdsPhaseResultDto(emission.getMeasureTypeCode(), String.valueOf(emission.getValue()), 23);
            emissionSet.add(resultECDC);
        }
    }

    /**
     * Gets the sorted phase list.
     *
     * @param phList the ph list
     * @return the sorted phase list
     */
    private List<CpdsPhase> getSortedPhaseList(List<CpdsPhase> phList) {
        List<CpdsPhase> sortedPhasesList = new ArrayList<>(6);
        sortedPhasesList.addAll(phList);
        if (!phList.isEmpty() && phList.size() == 1) {
            sortedPhasesList.set(0, phList.get(0));
        } else if (!phList.isEmpty() && phList.size() <= 2) {
            for (CpdsPhase phases : phList) {
                if (phases.getCode().equalsIgnoreCase(CITY)) {
                    sortedPhasesList.set(0, phases);
                } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                    sortedPhasesList.set(1, phases);
                }
            }
        } else if (!phList.isEmpty() && phList.size() <= 5) {
            for (CpdsPhase phases : phList) {
                if (phases.getCode().equalsIgnoreCase(LOW)) {
                    sortedPhasesList.set(0, phases);
                } else if (phases.getCode().equalsIgnoreCase(MID)) {
                    sortedPhasesList.set(1, phases);
                } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                    sortedPhasesList.set(2, phases);
                } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                    sortedPhasesList.set(3, phases);
                } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                    sortedPhasesList.set(4, phases);
                }
            }

        } else if (!phList.isEmpty() && phList.size() <= 6) {
            for (CpdsPhase phases : phList) {
                if (phases.getCode().equalsIgnoreCase(LOW)) {
                    sortedPhasesList.set(0, phases);
                } else if (phases.getCode().equalsIgnoreCase(MID)) {
                    sortedPhasesList.set(1, phases);
                } else if (phases.getCode().equalsIgnoreCase(HIGH)) {
                    sortedPhasesList.set(2, phases);
                } else if (phases.getCode().equalsIgnoreCase(EHIGH)) {
                    sortedPhasesList.set(3, phases);
                } else if (phases.getCode().equalsIgnoreCase(CITY)) {
                    sortedPhasesList.set(4, phases);
                } else if (phases.getCode().equalsIgnoreCase(COMB)) {
                    sortedPhasesList.set(5, phases);
                }
            }
        }
        return sortedPhasesList;
    }

    /**
     * Gets the phase result in format.
     *
     * @param code  the code
     * @param value the value
     * @return the phase result in format
     */
    private String getPhaseResultInFormat(String code, double value) {
        int roundingDigit = measureTypeRepository.roundingDigitByCode(code);
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        Double roundedValue = BigDecimal.valueOf(value).setScale(roundingDigit, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(resultRoundingMap.get(roundingDigit));
        return formatter.format(roundedValue);
    }

    /**
     * Gets the phy result in format.
     *
     * @param code  the code
     * @param value the value
     * @return the phy result in format
     */
    private String getPhyResultInFormat(String code, double value) {
        DecimalFormat formatter = (DecimalFormat) DecimalFormat.getInstance(Locale.ENGLISH);
        String pattern = phyQuantityRoundingMap.get(code);
        int scale = pattern.length() < 2 ? 0 : pattern.length() - 2;
        Double roundedValue = BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).doubleValue();
        formatter.applyPattern(pattern);
        return formatter.format(roundedValue);
    }

    /**
     * Gets the physical quantity type code.
     *
     * @param code the code
     * @return the physical quantity type code
     */
    private String getPhysicalQuantityTypeCode(String code) {
        String pqtCode = null;
        WltpCacheManager<PhysicalQuantityType> wltpCacheManager = WltpCacheManager.getInstance(PhysicalQuantityType.class);
        String key = "PQT";
        List<PhysicalQuantityType> pqtsList = wltpCacheManager.getListItem(key);
        if (pqtsList != null && !pqtsList.isEmpty()) {
            pqtCode = pqtsList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
            return pqtCode;
        }
        List<PhysicalQuantityType> pqtList = physicalQuantityTypeRepository.all();
        wltpCacheManager.putListItem(key, pqtList);
        if (pqtList != null && !pqtList.isEmpty()) {
            pqtCode = pqtList.stream().filter(pqt -> pqt.getCode().equals(code)).map(PhysicalQuantityType::getCode).findAny().orElse(null);
        }
        if (pqtCode == null) {
            logger.warn("Physical Quantity Type code '{}' is missing. Please verify the database", code);
        }
        return pqtCode;
    }

    /**
     * Log and create exception.
     *
     * @param requestId the request id
     * @param errorCode the error code
     * @return the seed exception
     */
    private SeedException logAndCreateException(String requestId, RequestErrorCode errorCode) {
        LogUtility.logTheError(logger, requestId, errorCode.getRuleCode(), errorCode.getDescription());
        return SeedException.createNew(errorCode);
    }
}
