/*
 * Creation : 29 Nov 2019
 */
package com.inetpsa.w7t.batch.clients.icube.response;

import java.io.File;

import org.springframework.core.io.FileSystemResource;

/**
 * The Class IcubeFileResource.
 */
public class IcubeFileResource extends FileSystemResource {

    /**
     * Instantiates a new icube file resource.
     *
     * @param path the path
     * @param icubeFileName the icube file name
     */
    public IcubeFileResource(String path, String icubeFileName) {
        super(path + File.separator + icubeFileName);
    }
}
