/*
 * Creation : 8 juin 2017
 */
package com.inetpsa.w7t.batch.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * The Class SpringContextUtil.
 */
public final class SpringContextUtil implements ApplicationContextAware {

    /** The application context. */
    private static ApplicationContext context;

    /**
     * {@inheritDoc}
     * 
     * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        setContext(applicationContext);
    }

    /**
     * Gets the application context.
     *
     * @return the application context
     */
    public static ApplicationContext getApplicationContext() {
        return context;
    }

    /**
     * Sets the context.
     *
     * @param applicationContext the application context
     * @return the application context
     */
    private static ApplicationContext setContext(ApplicationContext applicationContext) {
        context = applicationContext;
        return context;
    }

    /**
     * Instantiates a new spring context util.
     */
    private SpringContextUtil() {

    }

}
