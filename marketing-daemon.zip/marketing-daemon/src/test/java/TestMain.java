import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import com.inetpsa.w7t.daemon.services.misc.MarketingDaemonServiceConstants;

/*
 * Creation : 12 Feb 2020
 */

public class TestMain {
    static boolean isSameDayFile = false;

    public static void main(String[] args) {
        long prevReqNumber = 0;
        String reqId = "20200212900001549";
        for (int i = 0; i < 12; i++) {
            String fileId = "CRA";
            System.out.println(generateId(fileId, prevReqNumber, reqId));
            ++prevReqNumber;
        }
    }

    private static String generateId(String clientReqConst3, long prevReqNumber, String reqId) {

        String currentDateStr = DateTimeFormatter.ofPattern("yyyyMMdd", Locale.ENGLISH).format(LocalDate.now());
        String constant11 = clientReqConst3 + currentDateStr;
        String constant9 = MarketingDaemonServiceConstants.REQ_CONST9;
        if (!TestMain.isSameDayFile) {
            TestMain.isSameDayFile = true;
            String tempReqIDDate = reqId.substring(3, 11);
            if (currentDateStr.equals(tempReqIDDate)) {
                constant9 = reqId.substring(reqId.length() - constant9.length());
                if (constant9.chars().allMatch(Character::isDigit)) {
                    prevReqNumber = Long.parseLong(constant9) + 1;
                }
            }

        }
        return constant11 + constant9.substring(0, constant9.length() - String.valueOf(prevReqNumber).length()) + prevReqNumber;
    }
}
