printf "Launching WLTP marketing daemon..."


CLASSPATH=/usersdev2/w7t/data/marketing-daemon/config:/usersdev2/w7t/java/${pom.artifactId}-${pom.version}.jar:${marketing-daemon.generatedClasspath}

/usr/java/jdk1.8.0_77/bin/java -Xms256m -Xmx10G -Xdebug -agentlib:jdwp=transport=dt_socket,address=1044,server=y,suspend=n -Dcom.sun.management.jmxremote.port=1045 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -cp ${CLASSPATH} org.seedstack.seed.core.SeedMain wltp-marketing-daemon

