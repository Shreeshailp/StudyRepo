#!/bin/ksh



if [[ $(echo $1 | grep 'dev' | wc -l) == 1 ]]
    then
        cd /usersdev2/w7t

		PIDS=$( ps aux | grep marketing-daemon | grep java | awk '{print $2}' )
        
        echo killing $PIDS
        kill -15 $PIDS
        while kill -0 $PIDS 2> /dev/null; do sleep 1; done;
        
        #rm -rf ./delivery/*
        rm -rf ./lib/*
        rm -rf ./data/marketing-daemon/*
        rm -rf ./data/w7t-sql/*
        rm -rf ./sql/*
        
        tar -xf /usersdev2/w7t/w7t00etuind/$1
        
        
        cd data/marketing-daemon
        mkdir clients
        mkdir providers
        cd clients
        mkdir configMot2
        mkdir toyota
        mkdir aoGeos
        mkdir cronos
        mkdir eliade
        mkdir icube
        cd configMot2
        mkdir in
        mkdir out
        cd ../toyota
        mkdir in
        mkdir out
        cd ../aoGeos
        mkdir in
        mkdir out
        cd ../cronos
        mkdir in
        mkdir out
        cd ../eliade
        mkdir in
        mkdir out
        cd ../icube
        mkdir in
        mkdir out
        cd ../../providers
        mkdir bcvNewton
        cd bcvNewton
        mkdir in
        mkdir out
        cd ../../
        chmod 777 -R clients providers
        
        /usersdev2/marketing-daemon/data/w7t-sql/flyway/w7t-flyway-migration.sh
        
        echo Launching Marketing Daemon
        nohup /usersdev2/w7t/delivery/wltp-marketing-daemon.sh  > /usersdev2/w7t/log/marketing-daemon.log 2>&1 &
        echo Launched Marketing Daemon
    else
        printf "No deployment for this release (deploy only for *dev.tar)"
fi
